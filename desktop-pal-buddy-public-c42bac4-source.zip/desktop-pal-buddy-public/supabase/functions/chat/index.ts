import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import {
  assertAllowedOrigin,
  assertPersistentRateLimit,
  buildCorsHeaders,
  getBearerToken,
  jsonResponse,
  parseAllowedOrigins,
  validateChatPayload,
} from "../_shared/requestGuards.ts";

const DEFAULT_ALLOWED_ORIGINS = "http://localhost:8080,http://127.0.0.1:8080,null";
const RATE_LIMIT_WINDOW_MS = 60_000;
const CODEX_BRIDGE_DISABLED_MESSAGE =
  "실서비스 비서 실행은 Hermes/Codex 운영 브리지에서 처리됩니다. 현재 앱 내부 LLM gateway는 비활성화되어 있습니다.";

function readPositiveInt(value: string | undefined, fallback: number) {
  const parsed = Number(value);
  return Number.isFinite(parsed) && parsed > 0 ? Math.floor(parsed) : fallback;
}

const CHAT_RATE_LIMIT_PER_MINUTE = readPositiveInt(Deno.env.get("CHAT_RATE_LIMIT_PER_MINUTE"), 30);

async function requireUser(req: Request) {
  const token = getBearerToken(req);
  if (!token) return { ok: false as const, status: 401, error: "로그인이 필요합니다." };

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY") ?? Deno.env.get("SUPABASE_PUBLISHABLE_KEY");
  if (!supabaseUrl || !supabaseAnonKey) {
    return { ok: false as const, status: 500, error: "Supabase Auth 설정이 필요합니다." };
  }

  const authClient = createClient(supabaseUrl, supabaseAnonKey, {
    global: { headers: { Authorization: `Bearer ${token}` } },
    auth: { persistSession: false, autoRefreshToken: false },
  });
  const { data, error } = await authClient.auth.getUser(token);
  if (error || !data.user) return { ok: false as const, status: 401, error: "유효하지 않은 로그인 토큰입니다." };

  return { ok: true as const, user: data.user };
}

serve(async (req) => {
  const allowedOrigins = parseAllowedOrigins(Deno.env.get("ALLOWED_ORIGINS") ?? DEFAULT_ALLOWED_ORIGINS);
  const corsHeaders = buildCorsHeaders(req, allowedOrigins);

  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  try {
    const originGuard = assertAllowedOrigin(req, allowedOrigins);
    if (!originGuard.ok) return jsonResponse({ error: originGuard.error }, originGuard.status, corsHeaders);

    const userGuard = await requireUser(req);
    if (!userGuard.ok) return jsonResponse({ error: userGuard.error }, userGuard.status, corsHeaders);

    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!supabaseUrl || !supabaseServiceKey) {
      return jsonResponse({ error: "Supabase rate limit 설정이 필요합니다." }, 500, corsHeaders);
    }
    const adminSupabase = createClient(supabaseUrl, supabaseServiceKey, {
      auth: { persistSession: false, autoRefreshToken: false },
    });

    const rateLimitGuard = await assertPersistentRateLimit(adminSupabase, {
      userId: userGuard.user.id,
      scope: "chat",
      maxRequests: CHAT_RATE_LIMIT_PER_MINUTE,
      windowMs: RATE_LIMIT_WINDOW_MS,
    });
    if (!rateLimitGuard.ok) return jsonResponse({ error: rateLimitGuard.error }, rateLimitGuard.status, corsHeaders);

    const payload = validateChatPayload(await req.json());
    if (!payload.ok) return jsonResponse({ error: payload.error }, payload.status, corsHeaders);

    return jsonResponse({ error: CODEX_BRIDGE_DISABLED_MESSAGE }, 501, corsHeaders);
  } catch (e) {
    console.error("chat error:", e);
    return jsonResponse({ error: e instanceof Error ? e.message : "알 수 없는 오류" }, 500, corsHeaders);
  }
});
