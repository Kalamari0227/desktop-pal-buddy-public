import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const functionPath = path.join(path.dirname(fileURLToPath(import.meta.url)), "index.ts");
const functionSource = readFileSync(functionPath, "utf8");

describe("chat provider independence", () => {
  it("does not depend on the former gateway or direct OpenAI API calls", () => {
    expect(functionSource).toContain("Hermes/Codex 운영 브리지");
    expect(functionSource).not.toContain("LOVABLE_API_KEY");
    expect(functionSource).not.toContain("ai.gateway.lovable.dev");
    expect(functionSource).not.toContain("OPENAI_API_KEY");
    expect(functionSource).not.toContain("api.openai.com");
  });
});
