import { describe, expect, it } from "vitest";
import { sanitizeReadonlySql } from "./sqlSafety";

describe("sanitizeReadonlySql", () => {
  it("allows SELECT queries against allowlisted tables and adds a row limit", () => {
    expect(
      sanitizeReadonlySql("SELECT id, title FROM tasks WHERE status = 'pending'", {
        allowedTables: ["tasks"],
        maxRows: 100,
      })
    ).toEqual("SELECT id, title FROM tasks WHERE status = 'pending' LIMIT 100");
  });

  it("caps an existing LIMIT above the configured maximum", () => {
    expect(
      sanitizeReadonlySql("select * from public.tasks limit 500", {
        allowedTables: ["tasks"],
        maxRows: 50,
      })
    ).toBe("select * from public.tasks LIMIT 50");
  });

  it("rejects modification statements, comments, multiple statements, and unknown tables", () => {
    const options = { allowedTables: ["tasks"], maxRows: 100 };

    expect(() => sanitizeReadonlySql("delete from tasks", options)).toThrow("Only SELECT queries are allowed");
    expect(() => sanitizeReadonlySql("select * from tasks; select * from auth.users", options)).toThrow(
      "Multiple statements are not allowed"
    );
    expect(() => sanitizeReadonlySql("select * from tasks -- sneak", options)).toThrow("SQL comments are not allowed");
    expect(() => sanitizeReadonlySql("select * from auth.users", options)).toThrow(
      "Only allowlisted tables can be queried"
    );
  });

  it("ignores fake table references inside strings and blocks unsafe expressions", () => {
    const options = { allowedTables: ["tasks"], maxRows: 100 };

    expect(() => sanitizeReadonlySql("select version(), 'from tasks'", options)).toThrow(
      "Query is outside the readonly allowlist"
    );
    expect(() => sanitizeReadonlySql("select pg_sleep(1) from tasks", options)).toThrow(
      "Only count() function calls are allowed"
    );
    expect(() => sanitizeReadonlySql("select * from tasks union select * from auth.users", options)).toThrow(
      "Query is outside the readonly allowlist"
    );
    expect(() => sanitizeReadonlySql("select * from tasks, auth.users", options)).toThrow(
      "Joins and multi-table queries are not allowed"
    );
  });

  it("still allows simple count aggregations on tasks", () => {
    expect(
      sanitizeReadonlySql("select status, count(*) as total from tasks group by status limit 100", {
        allowedTables: ["tasks"],
        maxRows: 100,
      })
    ).toBe("select status, count(*) as total from tasks group by status limit 100");
  });

  it("allows basic IN filters while still enforcing the outer row cap", () => {
    expect(
      sanitizeReadonlySql("select id, title from tasks where status in ('pending', 'in_progress')", {
        allowedTables: ["tasks"],
        maxRows: 25,
      })
    ).toBe("select id, title from tasks where status in ('pending', 'in_progress') LIMIT 25");
  });
});
