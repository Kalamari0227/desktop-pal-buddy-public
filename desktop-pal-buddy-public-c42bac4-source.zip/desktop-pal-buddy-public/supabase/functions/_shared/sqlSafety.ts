export type SqlSafetyOptions = {
  allowedTables: string[];
  maxRows: number;
};

const DANGEROUS_KEYWORDS =
  /\b(insert|update|delete|drop|alter|create|truncate|grant|revoke|execute|exec|copy|call|do|merge|vacuum|analyze|union|intersect|except|with)\b/i;
const BLOCKED_SCHEMAS = /\b(auth|storage|supabase_functions|information_schema|pg_catalog)\s*\./i;
const BLOCKED_SYSTEM_IDENTIFIERS = /\b(current_user|session_user|current_database|current_schema|version)\b/i;
const DOLLAR_QUOTE = /\$[a-z0-9_]*\$/i;
const FUNCTION_CALL = /\b([a-z_][a-z0-9_]*)\s*\(/gi;

function stripSqlStringLiterals(sql: string): string {
  return sql.replace(/'([^']|'')*'/g, "");
}

function stripIdentifier(identifier: string): string {
  return identifier.replace(/"/g, "").split(".").pop()?.toLowerCase() ?? identifier.toLowerCase();
}

function referencedTables(sql: string): string[] {
  const refs = sql.matchAll(/\b(?:from|join)\s+("?[\w]+"?(?:\."?[\w]+"?)?)/gi);
  return [...refs].map((match) => stripIdentifier(match[1]));
}

export function sanitizeReadonlySql(sql: string, options: SqlSafetyOptions): string {
  const trimmed = sql.replace(/;\s*$/, "").trim();
  const lowered = trimmed.toLowerCase();
  const structuralSql = stripSqlStringLiterals(lowered);

  if (!trimmed || !lowered.startsWith("select")) {
    throw new Error("Only SELECT queries are allowed");
  }
  if (trimmed.includes(";")) {
    throw new Error("Multiple statements are not allowed");
  }
  if (trimmed.includes("--") || trimmed.includes("/*") || trimmed.includes("*/")) {
    throw new Error("SQL comments are not allowed");
  }
  if (DOLLAR_QUOTE.test(trimmed)) {
    throw new Error("Dollar-quoted SQL strings are not allowed");
  }
  if (
    trimmed.length > 3000 ||
    DANGEROUS_KEYWORDS.test(structuralSql) ||
    BLOCKED_SYSTEM_IDENTIFIERS.test(structuralSql)
  ) {
    throw new Error("Query is outside the readonly allowlist");
  }

  const allowedTables = new Set(options.allowedTables.map((table) => table.toLowerCase()));
  if (/\bjoin\b/i.test(structuralSql) || /\bfrom\s+("?[\w]+"?(?:\."?[\w]+"?)?)(\s+[a-z_][a-z0-9_]*)?\s*,/i.test(structuralSql)) {
    throw new Error("Joins and multi-table queries are not allowed");
  }

  const tables = referencedTables(structuralSql);
  if (tables.length !== 1 || tables.some((table) => !allowedTables.has(table))) {
    throw new Error("Only allowlisted tables can be queried");
  }
  if (BLOCKED_SCHEMAS.test(structuralSql)) {
    throw new Error("Query is outside the readonly allowlist");
  }

  const functions = [...structuralSql.matchAll(FUNCTION_CALL)].map((match) => match[1]);
  if (functions.some((fn) => fn !== "count" && fn !== "in")) {
    throw new Error("Only count() function calls are allowed");
  }

  const limitMatch = structuralSql.match(/\blimit\s+(\d+)\s*$/i);
  if (!limitMatch) {
    return `${trimmed} LIMIT ${options.maxRows}`;
  }

  const requestedLimit = Number(limitMatch[1]);
  if (Number.isFinite(requestedLimit) && requestedLimit <= options.maxRows) {
    return trimmed;
  }

  return trimmed.replace(/\blimit\s+\d+\s*$/i, `LIMIT ${options.maxRows}`);
}
