export type ChatMessage = {
  role: "user" | "assistant";
  content: string;
};

export type GuardResult<T> =
  | { ok: true; value: T }
  | { ok: false; status: number; error: string };

export type RateLimitOptions = {
  maxRequests: number;
  windowMs: number;
};

export type PersistentRateLimitOptions = RateLimitOptions & {
  userId: string;
  scope: "chat" | "data_query";
  nowMs?: number;
};

type RateLimitBucket = {
  count: number;
  resetAt: number;
};

type RateLimitError = { message: string };
type RateLimitResult = { error?: RateLimitError | null; count?: number | null };
type RateLimitDeleteBuilder = {
  lt(column: string, value: string): Promise<RateLimitResult>;
};
type RateLimitSelectBuilder = {
  eq(column: string, value: string): RateLimitSelectBuilder;
  gte(column: string, value: string): Promise<RateLimitResult>;
};
type RateLimitTable = {
  delete(): RateLimitDeleteBuilder;
  insert(payload: Record<string, string>): Promise<RateLimitResult>;
  select(columns: string, options: { count: "exact"; head: true }): RateLimitSelectBuilder;
};
export type PersistentRateLimitClient = {
  from(table: string): RateLimitTable;
};

const ALLOWED_HEADERS =
  "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version";

export function parseAllowedOrigins(raw: string | null | undefined): string[] {
  return (raw ?? "")
    .split(",")
    .map((origin) => origin.trim())
    .filter(Boolean);
}

export function buildCorsHeaders(req: Request, allowedOrigins: string[]): Record<string, string> {
  const origin = req.headers.get("Origin");
  const allowAll = allowedOrigins.includes("*");
  const allowedOrigin =
    allowAll ? origin ?? "*" : origin && allowedOrigins.includes(origin) ? origin : allowedOrigins[0] ?? "null";

  return {
    "Access-Control-Allow-Origin": allowedOrigin,
    "Access-Control-Allow-Headers": ALLOWED_HEADERS,
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    Vary: "Origin",
  };
}

export function assertAllowedOrigin(req: Request, allowedOrigins: string[]): GuardResult<null> {
  const origin = req.headers.get("Origin");
  if (!origin || allowedOrigins.length === 0 || allowedOrigins.includes("*") || allowedOrigins.includes(origin)) {
    return { ok: true, value: null };
  }

  return { ok: false, status: 403, error: "Origin is not allowed" };
}

export function getBearerToken(req: Request): string | null {
  const header = req.headers.get("Authorization");
  const match = header?.match(/^Bearer\s+(.+)$/i);
  return match?.[1]?.trim() || null;
}

export function jsonResponse(
  body: Record<string, unknown>,
  status: number,
  corsHeaders: Record<string, string>
): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

export function createMemoryRateLimiter({ maxRequests, windowMs }: RateLimitOptions) {
  const buckets = new Map<string, RateLimitBucket>();

  return function assertRateLimit(key: string, nowMs = Date.now()): GuardResult<{ remaining: number; resetAt: number }> {
    const existing = buckets.get(key);
    if (!existing || existing.resetAt <= nowMs) {
      const resetAt = nowMs + windowMs;
      buckets.set(key, { count: 1, resetAt });
      return { ok: true, value: { remaining: Math.max(maxRequests - 1, 0), resetAt } };
    }

    if (existing.count >= maxRequests) {
      return { ok: false, status: 429, error: "요청이 너무 많습니다. 잠시 후 다시 시도해주세요." };
    }

    existing.count += 1;
    return { ok: true, value: { remaining: Math.max(maxRequests - existing.count, 0), resetAt: existing.resetAt } };
  };
}

export async function assertPersistentRateLimit(
  client: PersistentRateLimitClient,
  { userId, scope, maxRequests, windowMs, nowMs = Date.now() }: PersistentRateLimitOptions
): Promise<GuardResult<{ remaining: number; resetAt: number }>> {
  const resetAt = nowMs + windowMs;
  const cutoff = new Date(nowMs - windowMs).toISOString();
  const table = client.from("edge_rate_limit_events");

  const cleanup = await table.delete().lt("created_at", cutoff);
  if (cleanup.error) {
    return { ok: false, status: 503, error: "요청 제한 상태를 확인하지 못했습니다." };
  }

  const countResult = await table
    .select("id", { count: "exact", head: true })
    .eq("user_id", userId)
    .eq("scope", scope)
    .gte("created_at", cutoff);
  if (countResult.error) {
    return { ok: false, status: 503, error: "요청 제한 상태를 확인하지 못했습니다." };
  }

  const currentCount = countResult.count ?? 0;
  if (currentCount >= maxRequests) {
    return { ok: false, status: 429, error: "요청이 너무 많습니다. 잠시 후 다시 시도해주세요." };
  }

  const insertResult = await table.insert({
    user_id: userId,
    scope,
    created_at: new Date(nowMs).toISOString(),
  });
  if (insertResult.error) {
    return { ok: false, status: 503, error: "요청 제한 상태를 기록하지 못했습니다." };
  }

  return { ok: true, value: { remaining: Math.max(maxRequests - currentCount - 1, 0), resetAt } };
}

export function validateChatPayload(payload: unknown): GuardResult<{ messages: ChatMessage[] }> {
  if (!payload || typeof payload !== "object" || !("messages" in payload)) {
    return { ok: false, status: 400, error: "messages 배열이 필요합니다." };
  }

  const messages = (payload as { messages?: unknown }).messages;
  if (!Array.isArray(messages) || messages.length === 0 || messages.length > 20) {
    return { ok: false, status: 400, error: "messages는 1~20개 사이여야 합니다." };
  }

  const validated: ChatMessage[] = [];
  for (const message of messages) {
    if (!message || typeof message !== "object") {
      return { ok: false, status: 400, error: "각 message는 객체여야 합니다." };
    }

    const { role, content } = message as { role?: unknown; content?: unknown };
    if (role !== "user" && role !== "assistant") {
      return { ok: false, status: 400, error: "허용되지 않은 message role입니다." };
    }
    if (typeof content !== "string" || content.trim().length === 0 || content.length > 4000) {
      return { ok: false, status: 400, error: "message content는 1~4000자여야 합니다." };
    }

    validated.push({ role, content: content.trim() });
  }

  return { ok: true, value: { messages: validated } };
}

export function validateDataQueryPayload(payload: unknown): GuardResult<{ question: string }> {
  if (!payload || typeof payload !== "object" || !("question" in payload)) {
    return { ok: false, status: 400, error: "질문을 입력해주세요." };
  }

  const question = (payload as { question?: unknown }).question;
  if (typeof question !== "string" || question.trim().length === 0 || question.length > 500) {
    return { ok: false, status: 400, error: "question은 1~500자 사이여야 합니다." };
  }

  return { ok: true, value: { question: question.trim() } };
}
