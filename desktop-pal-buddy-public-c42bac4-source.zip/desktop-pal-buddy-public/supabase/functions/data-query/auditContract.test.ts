import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const functionPath = path.join(path.dirname(fileURLToPath(import.meta.url)), "index.ts");
const functionSource = readFileSync(functionPath, "utf8");

describe("data-query audit contract", () => {
  it("records disabled bridge rejections and unexpected query errors", () => {
    expect(functionSource).toContain("writeDataQueryAudit");
    expect(functionSource).toContain("assertPersistentRateLimit");
    expect(functionSource).toContain('scope: "data_query"');
    expect(functionSource).toContain('status: "rejected"');
    expect(functionSource).toContain('status: "query_error"');
  });

  it("does not write audit columns that are absent from the hardening migration", () => {
    expect(functionSource).not.toContain("normalized_query");
    expect(functionSource).not.toContain("sql_generation_rate_limited");
    expect(functionSource).not.toContain("sql_generation_payment_required");
    expect(functionSource).not.toContain("let auditBase: { user_id: string; query_text: string; row_limit: number }");
  });

  it("does not depend on the former gateway or direct OpenAI API calls", () => {
    expect(functionSource).toContain("Hermes/Codex 운영 브리지");
    expect(functionSource).not.toContain("LOVABLE_API_KEY");
    expect(functionSource).not.toContain("ai.gateway.lovable.dev");
    expect(functionSource).not.toContain("OPENAI_API_KEY");
    expect(functionSource).not.toContain("api.openai.com");
  });
});
