CREATE TABLE IF NOT EXISTS public.agent_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid NOT NULL REFERENCES public.tasks(id) ON DELETE CASCADE,
  packet_task_id text NOT NULL,
  outcome text NOT NULL CHECK (
    outcome IN (
      'passed',
      'passed_with_warnings',
      'blocked',
      'failed',
      'advisory_only'
    )
  ),
  summary text NOT NULL CHECK (btrim(summary) <> ''),
  details text,
  changed_paths jsonb NOT NULL DEFAULT '[]'::jsonb CHECK (jsonb_typeof(changed_paths) = 'array'),
  checked_refs jsonb NOT NULL DEFAULT '[]'::jsonb CHECK (jsonb_typeof(checked_refs) = 'array'),
  risks jsonb NOT NULL DEFAULT '[]'::jsonb CHECK (jsonb_typeof(risks) = 'array'),
  blockers jsonb NOT NULL DEFAULT '[]'::jsonb CHECK (jsonb_typeof(blockers) = 'array'),
  next_action text,
  retention_decision jsonb CHECK (retention_decision IS NULL OR jsonb_typeof(retention_decision) = 'object'),
  owner_id uuid REFERENCES auth.users(id) ON DELETE SET NULL DEFAULT auth.uid(),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_agent_results_owner_task_created
  ON public.agent_results (owner_id, task_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_agent_results_packet_task
  ON public.agent_results (packet_task_id);

ALTER TABLE public.agent_results ENABLE ROW LEVEL SECURITY;

REVOKE SELECT, INSERT, UPDATE, DELETE ON public.agent_results FROM PUBLIC, anon, authenticated;
GRANT SELECT, INSERT, DELETE ON public.agent_results TO authenticated;

DROP POLICY IF EXISTS "agent_results_select_owned_task" ON public.agent_results;
CREATE POLICY "agent_results_select_owned_task"
  ON public.agent_results
  FOR SELECT
  TO authenticated
  USING (
    owner_id = auth.uid()
    AND EXISTS (
      SELECT 1
      FROM public.tasks
      WHERE tasks.id = agent_results.task_id
        AND tasks.owner_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "agent_results_insert_owned_task" ON public.agent_results;
CREATE POLICY "agent_results_insert_owned_task"
  ON public.agent_results
  FOR INSERT
  TO authenticated
  WITH CHECK (
    owner_id = auth.uid()
    AND EXISTS (
      SELECT 1
      FROM public.tasks
      WHERE tasks.id = agent_results.task_id
        AND tasks.owner_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "agent_results_delete_owned_task" ON public.agent_results;
CREATE POLICY "agent_results_delete_owned_task"
  ON public.agent_results
  FOR DELETE
  TO authenticated
  USING (
    owner_id = auth.uid()
    AND EXISTS (
      SELECT 1
      FROM public.tasks
      WHERE tasks.id = agent_results.task_id
        AND tasks.owner_id = auth.uid()
    )
  );
