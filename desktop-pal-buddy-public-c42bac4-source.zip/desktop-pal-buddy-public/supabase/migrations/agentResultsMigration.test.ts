import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const migrationSql = readFileSync(
  path.join(
    path.dirname(fileURLToPath(import.meta.url)),
    "20260704200000_create_agent_results.sql"
  ),
  "utf8"
);

describe("agent results migration", () => {
  it("creates an owner-scoped worker result ledger tied to tasks", () => {
    expect(migrationSql).toContain("CREATE TABLE IF NOT EXISTS public.agent_results");
    expect(migrationSql).toContain("task_id uuid NOT NULL REFERENCES public.tasks(id) ON DELETE CASCADE");
    expect(migrationSql).toContain("packet_task_id text NOT NULL");
    expect(migrationSql).toContain("outcome text NOT NULL CHECK");
    expect(migrationSql).toContain("owner_id uuid REFERENCES auth.users(id) ON DELETE SET NULL DEFAULT auth.uid()");
  });

  it("keeps result writes authenticated and owner checked", () => {
    expect(migrationSql).toContain("REVOKE SELECT, INSERT, UPDATE, DELETE ON public.agent_results FROM PUBLIC, anon, authenticated;");
    expect(migrationSql).toContain("GRANT SELECT, INSERT, DELETE ON public.agent_results TO authenticated;");
    expect(migrationSql).toContain("agent_results_select_owned_task");
    expect(migrationSql).toContain("agent_results_insert_owned_task");
    expect(migrationSql).toContain("tasks.owner_id = auth.uid()");
  });

  it("keeps JSON fields shaped as arrays or objects", () => {
    expect(migrationSql).toContain("changed_paths jsonb NOT NULL DEFAULT '[]'::jsonb CHECK (jsonb_typeof(changed_paths) = 'array')");
    expect(migrationSql).toContain("checked_refs jsonb NOT NULL DEFAULT '[]'::jsonb CHECK (jsonb_typeof(checked_refs) = 'array')");
    expect(migrationSql).toContain("blockers jsonb NOT NULL DEFAULT '[]'::jsonb CHECK (jsonb_typeof(blockers) = 'array')");
    expect(migrationSql).toContain("retention_decision jsonb CHECK (retention_decision IS NULL OR jsonb_typeof(retention_decision) = 'object')");
  });
});
