
CREATE TABLE public.marketplace_agents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  category text NOT NULL DEFAULT 'general',
  icon text DEFAULT 'Bot',
  prompt_template text,
  creator_name text DEFAULT '익명',
  installs integer DEFAULT 0,
  rating numeric(2,1) DEFAULT 0,
  tags text[] DEFAULT '{}',
  is_featured boolean DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.marketplace_agents ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public read/write on marketplace_agents"
  ON public.marketplace_agents
  FOR ALL
  USING (true)
  WITH CHECK (true);
