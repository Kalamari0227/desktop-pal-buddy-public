
CREATE TABLE public.installed_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  item_id uuid NOT NULL,
  item_type text NOT NULL CHECK (item_type IN ('agent', 'skill', 'mcp', 'workflow', 'plugin')),
  item_name text NOT NULL,
  item_icon text DEFAULT 'Bot',
  item_description text,
  is_active boolean NOT NULL DEFAULT true,
  installed_at timestamp with time zone NOT NULL DEFAULT now(),
  config jsonb DEFAULT '{}'::jsonb
);

ALTER TABLE public.installed_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public read/write on installed_items" ON public.installed_items FOR ALL USING (true) WITH CHECK (true);

CREATE UNIQUE INDEX idx_installed_items_unique ON public.installed_items (item_id, item_type);
