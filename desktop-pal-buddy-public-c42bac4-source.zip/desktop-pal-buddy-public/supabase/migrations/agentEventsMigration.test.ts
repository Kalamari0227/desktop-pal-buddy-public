import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const migrationSql = readFileSync(
  path.join(
    path.dirname(fileURLToPath(import.meta.url)),
    "20260704194500_create_agent_events.sql"
  ),
  "utf8"
);

describe("agent events migration", () => {
  it("creates an owner-scoped worker event ledger tied to tasks", () => {
    expect(migrationSql).toContain("CREATE TABLE IF NOT EXISTS public.agent_events");
    expect(migrationSql).toContain("task_id uuid NOT NULL REFERENCES public.tasks(id) ON DELETE CASCADE");
    expect(migrationSql).toContain("packet_task_id text NOT NULL");
    expect(migrationSql).toContain("event_id text NOT NULL");
    expect(migrationSql).toContain("owner_id uuid REFERENCES auth.users(id) ON DELETE SET NULL DEFAULT auth.uid()");
    expect(migrationSql).toContain("CONSTRAINT agent_events_owner_event_unique UNIQUE (owner_id, event_id)");
  });

  it("keeps event writes authenticated and owner checked", () => {
    expect(migrationSql).toContain("REVOKE SELECT, INSERT, UPDATE, DELETE ON public.agent_events FROM PUBLIC, anon, authenticated;");
    expect(migrationSql).toContain("GRANT SELECT, INSERT, DELETE ON public.agent_events TO authenticated;");
    expect(migrationSql).toContain("agent_events_select_owned_task");
    expect(migrationSql).toContain("agent_events_insert_owned_task");
    expect(migrationSql).toContain("tasks.owner_id = auth.uid()");
  });

  it("constrains event values to the WorkerEvent contract", () => {
    expect(migrationSql).toContain("'approval_required'");
    expect(migrationSql).toContain("'evidence_added'");
    expect(migrationSql).toContain("'verification_passed'");
    expect(migrationSql).toContain("severity text CHECK (severity IS NULL OR severity IN ('info', 'warning', 'error'))");
    expect(migrationSql).toContain("requires_user_action boolean NOT NULL DEFAULT false");
  });
});
