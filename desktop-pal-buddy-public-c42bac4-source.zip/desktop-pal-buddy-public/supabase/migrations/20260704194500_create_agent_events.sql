CREATE TABLE IF NOT EXISTS public.agent_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid NOT NULL REFERENCES public.tasks(id) ON DELETE CASCADE,
  packet_task_id text NOT NULL,
  event_id text NOT NULL,
  event_type text NOT NULL CHECK (
    event_type IN (
      'accepted',
      'plan_created',
      'approval_required',
      'started',
      'progress',
      'evidence_added',
      'blocked',
      'verification_started',
      'verification_passed',
      'verification_failed',
      'completed',
      'failed'
    )
  ),
  message text NOT NULL CHECK (btrim(message) <> ''),
  evidence_ref_id text,
  severity text CHECK (severity IS NULL OR severity IN ('info', 'warning', 'error')),
  requires_user_action boolean NOT NULL DEFAULT false,
  owner_id uuid REFERENCES auth.users(id) ON DELETE SET NULL DEFAULT auth.uid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT agent_events_owner_event_unique UNIQUE (owner_id, event_id)
);

CREATE INDEX IF NOT EXISTS idx_agent_events_owner_task_created
  ON public.agent_events (owner_id, task_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_agent_events_packet_task
  ON public.agent_events (packet_task_id);

ALTER TABLE public.agent_events ENABLE ROW LEVEL SECURITY;

REVOKE SELECT, INSERT, UPDATE, DELETE ON public.agent_events FROM PUBLIC, anon, authenticated;
GRANT SELECT, INSERT, DELETE ON public.agent_events TO authenticated;

DROP POLICY IF EXISTS "agent_events_select_owned_task" ON public.agent_events;
CREATE POLICY "agent_events_select_owned_task"
  ON public.agent_events
  FOR SELECT
  TO authenticated
  USING (
    owner_id = auth.uid()
    AND EXISTS (
      SELECT 1
      FROM public.tasks
      WHERE tasks.id = agent_events.task_id
        AND tasks.owner_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "agent_events_insert_owned_task" ON public.agent_events;
CREATE POLICY "agent_events_insert_owned_task"
  ON public.agent_events
  FOR INSERT
  TO authenticated
  WITH CHECK (
    owner_id = auth.uid()
    AND EXISTS (
      SELECT 1
      FROM public.tasks
      WHERE tasks.id = agent_events.task_id
        AND tasks.owner_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "agent_events_delete_owned_task" ON public.agent_events;
CREATE POLICY "agent_events_delete_owned_task"
  ON public.agent_events
  FOR DELETE
  TO authenticated
  USING (
    owner_id = auth.uid()
    AND EXISTS (
      SELECT 1
      FROM public.tasks
      WHERE tasks.id = agent_events.task_id
        AND tasks.owner_id = auth.uid()
    )
  );
