import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const migrationSql = readFileSync(
  path.join(
    path.dirname(fileURLToPath(import.meta.url)),
    "20260704193000_create_agent_approvals.sql"
  ),
  "utf8"
);

describe("agent approvals migration", () => {
  it("creates an owner-scoped approval event ledger tied to tasks", () => {
    expect(migrationSql).toContain("CREATE TABLE IF NOT EXISTS public.agent_approvals");
    expect(migrationSql).toContain("task_id uuid NOT NULL REFERENCES public.tasks(id) ON DELETE CASCADE");
    expect(migrationSql).toContain("packet_task_id text NOT NULL");
    expect(migrationSql).toContain("decision text NOT NULL CHECK (decision IN ('approved', 'rejected'))");
    expect(migrationSql).toContain("owner_id uuid REFERENCES auth.users(id) ON DELETE SET NULL DEFAULT auth.uid()");
  });

  it("keeps approval records authenticated and owner checked", () => {
    expect(migrationSql).toContain("REVOKE SELECT, INSERT, UPDATE, DELETE ON public.agent_approvals FROM PUBLIC, anon, authenticated;");
    expect(migrationSql).toContain("GRANT SELECT, INSERT, DELETE ON public.agent_approvals TO authenticated;");
    expect(migrationSql).toContain("agent_approvals_select_owned_task");
    expect(migrationSql).toContain("agent_approvals_insert_owned_task");
    expect(migrationSql).toContain("tasks.owner_id = auth.uid()");
  });

  it("constrains approval actions to the policy contract", () => {
    expect(migrationSql).toContain("'external_message'");
    expect(migrationSql).toContain("'database_migration'");
    expect(migrationSql).toContain("'permission_change'");
    expect(migrationSql).toContain("approval_reason text NOT NULL CHECK (btrim(approval_reason) <> '')");
    expect(migrationSql).toContain("approved_scope text NOT NULL CHECK (btrim(approved_scope) <> '')");
  });
});
