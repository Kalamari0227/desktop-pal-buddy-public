
CREATE OR REPLACE FUNCTION public.execute_readonly_query(query_text text)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  result json;
  trimmed text;
BEGIN
  trimmed := btrim(lower(query_text));
  
  -- Only allow SELECT statements
  IF NOT (trimmed LIKE 'select%') THEN
    RAISE EXCEPTION 'Only SELECT queries are allowed';
  END IF;
  
  -- Block dangerous keywords
  IF trimmed ~ '(insert|update|delete|drop|alter|create|truncate|grant|revoke|execute|exec)' THEN
    RAISE EXCEPTION 'Modification queries are not allowed';
  END IF;
  
  -- Block access to auth and other internal schemas
  IF trimmed ~ '(auth\.|storage\.|supabase_functions\.|pg_|information_schema)' THEN
    RAISE EXCEPTION 'Access to system schemas is not allowed';
  END IF;

  EXECUTE format('SELECT json_agg(row_to_json(t)) FROM (%s) t', query_text) INTO result;
  
  RETURN COALESCE(result, '[]'::json);
END;
$$;
