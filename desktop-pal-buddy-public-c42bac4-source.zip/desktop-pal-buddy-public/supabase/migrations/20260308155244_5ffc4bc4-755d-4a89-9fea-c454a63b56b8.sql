
CREATE TABLE public.marketplace_workflows (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  category text NOT NULL DEFAULT 'automation',
  trigger_type text DEFAULT 'manual',
  steps jsonb DEFAULT '[]'::jsonb,
  creator_name text DEFAULT '익명',
  installs integer DEFAULT 0,
  rating numeric(2,1) DEFAULT 0,
  tags text[] DEFAULT '{}',
  is_featured boolean DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.marketplace_workflows ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public read/write on marketplace_workflows"
  ON public.marketplace_workflows
  FOR ALL
  USING (true)
  WITH CHECK (true);

CREATE TABLE public.marketplace_workflow_reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  workflow_id uuid NOT NULL REFERENCES public.marketplace_workflows(id) ON DELETE CASCADE,
  reviewer_name text NOT NULL DEFAULT '익명',
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment text,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.marketplace_workflow_reviews ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public read/write on marketplace_workflow_reviews"
  ON public.marketplace_workflow_reviews
  FOR ALL
  USING (true)
  WITH CHECK (true);

CREATE OR REPLACE FUNCTION public.update_workflow_rating()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  UPDATE public.marketplace_workflows
  SET rating = (
    SELECT COALESCE(ROUND(AVG(rating)::numeric, 1), 0)
    FROM public.marketplace_workflow_reviews
    WHERE workflow_id = COALESCE(NEW.workflow_id, OLD.workflow_id)
  )
  WHERE id = COALESCE(NEW.workflow_id, OLD.workflow_id);
  RETURN COALESCE(NEW, OLD);
END;
$$;

CREATE TRIGGER trg_update_workflow_rating
AFTER INSERT OR UPDATE OR DELETE ON public.marketplace_workflow_reviews
FOR EACH ROW EXECUTE FUNCTION public.update_workflow_rating();
