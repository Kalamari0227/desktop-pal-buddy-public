-- Harden the demo-friendly public policies before production/staging data is connected.

DO $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public'
      AND p.proname = 'rls_auto_enable'
      AND pg_get_function_identity_arguments(p.oid) = ''
  ) THEN
    REVOKE EXECUTE ON FUNCTION public.rls_auto_enable() FROM PUBLIC, anon, authenticated;
  END IF;
END;
$$;

CREATE TABLE IF NOT EXISTS public.data_query_audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  question text NOT NULL,
  generated_sql text,
  row_count integer NOT NULL DEFAULT 0,
  status text NOT NULL CHECK (status IN ('generated', 'success', 'query_error', 'rejected')),
  error_message text,
  latency_ms integer,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.data_query_audit_logs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "data_query_audit_logs_select_own" ON public.data_query_audit_logs;
CREATE POLICY "data_query_audit_logs_select_own"
  ON public.data_query_audit_logs
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE TABLE IF NOT EXISTS public.edge_rate_limit_events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  scope text NOT NULL CHECK (scope IN ('chat', 'data_query')),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_edge_rate_limit_events_user_scope_created
  ON public.edge_rate_limit_events (user_id, scope, created_at DESC);

ALTER TABLE public.edge_rate_limit_events ENABLE ROW LEVEL SECURITY;
REVOKE SELECT, INSERT, UPDATE, DELETE ON public.edge_rate_limit_events FROM PUBLIC, anon, authenticated;

ALTER TABLE public.tasks ADD COLUMN IF NOT EXISTS owner_id uuid REFERENCES auth.users(id) ON DELETE SET NULL;
ALTER TABLE public.tasks ALTER COLUMN owner_id SET DEFAULT auth.uid();
DROP POLICY IF EXISTS "Allow public read/write on tasks" ON public.tasks;
CREATE POLICY "tasks_select_owned_or_seed"
  ON public.tasks FOR SELECT TO authenticated
  USING (owner_id = auth.uid());
CREATE POLICY "tasks_insert_own"
  ON public.tasks FOR INSERT TO authenticated
  WITH CHECK (owner_id = auth.uid());
CREATE POLICY "tasks_update_own"
  ON public.tasks FOR UPDATE TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());
CREATE POLICY "tasks_delete_own"
  ON public.tasks FOR DELETE TO authenticated
  USING (owner_id = auth.uid());

ALTER TABLE public.alert_dismissals ADD COLUMN IF NOT EXISTS owner_id uuid REFERENCES auth.users(id) ON DELETE SET NULL;
ALTER TABLE public.alert_dismissals ALTER COLUMN owner_id SET DEFAULT auth.uid();
ALTER TABLE public.alert_dismissals DROP CONSTRAINT IF EXISTS alert_dismissals_task_id_key;
CREATE UNIQUE INDEX IF NOT EXISTS idx_alert_dismissals_owner_task_unique
  ON public.alert_dismissals (owner_id, task_id);
DROP POLICY IF EXISTS "Allow public read/write on alert_dismissals" ON public.alert_dismissals;
CREATE POLICY "alert_dismissals_select_owned"
  ON public.alert_dismissals FOR SELECT TO authenticated
  USING (owner_id = auth.uid());
CREATE POLICY "alert_dismissals_insert_own"
  ON public.alert_dismissals FOR INSERT TO authenticated
  WITH CHECK (owner_id = auth.uid());
CREATE POLICY "alert_dismissals_delete_own"
  ON public.alert_dismissals FOR DELETE TO authenticated
  USING (owner_id = auth.uid());

ALTER TABLE public.installed_items ADD COLUMN IF NOT EXISTS owner_id uuid REFERENCES auth.users(id) ON DELETE SET NULL;
ALTER TABLE public.installed_items ALTER COLUMN owner_id SET DEFAULT auth.uid();
DROP INDEX IF EXISTS public.idx_installed_items_unique;
ALTER TABLE public.installed_items DROP CONSTRAINT IF EXISTS installed_items_item_id_item_type_key;
CREATE UNIQUE INDEX IF NOT EXISTS idx_installed_items_owner_item_unique
  ON public.installed_items (owner_id, item_id, item_type);
DROP POLICY IF EXISTS "Allow public read/write on installed_items" ON public.installed_items;
CREATE POLICY "installed_items_select_owned"
  ON public.installed_items FOR SELECT TO authenticated
  USING (owner_id = auth.uid());
CREATE POLICY "installed_items_insert_own"
  ON public.installed_items FOR INSERT TO authenticated
  WITH CHECK (owner_id = auth.uid());
CREATE POLICY "installed_items_update_own"
  ON public.installed_items FOR UPDATE TO authenticated
  USING (owner_id = auth.uid())
  WITH CHECK (owner_id = auth.uid());
CREATE POLICY "installed_items_delete_own"
  ON public.installed_items FOR DELETE TO authenticated
  USING (owner_id = auth.uid());

ALTER TABLE public.debate_history ADD COLUMN IF NOT EXISTS owner_id uuid REFERENCES auth.users(id) ON DELETE SET NULL;
ALTER TABLE public.debate_history ALTER COLUMN owner_id SET DEFAULT auth.uid();
DROP POLICY IF EXISTS "Allow public read/write on debate_history" ON public.debate_history;
CREATE POLICY "debate_history_select_owned"
  ON public.debate_history FOR SELECT TO authenticated
  USING (owner_id = auth.uid());
CREATE POLICY "debate_history_insert_own"
  ON public.debate_history FOR INSERT TO authenticated
  WITH CHECK (owner_id = auth.uid());

ALTER TABLE public.canvas_nodes ADD COLUMN IF NOT EXISTS owner_id uuid REFERENCES auth.users(id) ON DELETE SET NULL;
ALTER TABLE public.canvas_edges ADD COLUMN IF NOT EXISTS owner_id uuid REFERENCES auth.users(id) ON DELETE SET NULL;
ALTER TABLE public.canvas_evidences ADD COLUMN IF NOT EXISTS owner_id uuid REFERENCES auth.users(id) ON DELETE SET NULL;
ALTER TABLE public.canvas_review_decisions ADD COLUMN IF NOT EXISTS owner_id uuid REFERENCES auth.users(id) ON DELETE SET NULL;
ALTER TABLE public.canvas_graph_snapshots ADD COLUMN IF NOT EXISTS owner_id uuid REFERENCES auth.users(id) ON DELETE SET NULL;
ALTER TABLE public.canvas_nodes ALTER COLUMN owner_id SET DEFAULT auth.uid();
ALTER TABLE public.canvas_edges ALTER COLUMN owner_id SET DEFAULT auth.uid();
ALTER TABLE public.canvas_evidences ALTER COLUMN owner_id SET DEFAULT auth.uid();
ALTER TABLE public.canvas_review_decisions ALTER COLUMN owner_id SET DEFAULT auth.uid();
ALTER TABLE public.canvas_graph_snapshots ALTER COLUMN owner_id SET DEFAULT auth.uid();

DROP POLICY IF EXISTS "Allow public read/write on canvas_nodes" ON public.canvas_nodes;
CREATE POLICY "canvas_nodes_select_owned" ON public.canvas_nodes FOR SELECT TO authenticated USING (owner_id = auth.uid());
CREATE POLICY "canvas_nodes_insert_own" ON public.canvas_nodes FOR INSERT TO authenticated WITH CHECK (owner_id = auth.uid());
CREATE POLICY "canvas_nodes_update_own" ON public.canvas_nodes FOR UPDATE TO authenticated USING (owner_id = auth.uid()) WITH CHECK (owner_id = auth.uid());
CREATE POLICY "canvas_nodes_delete_own" ON public.canvas_nodes FOR DELETE TO authenticated USING (owner_id = auth.uid());

DROP POLICY IF EXISTS "Allow public read/write on canvas_edges" ON public.canvas_edges;
CREATE POLICY "canvas_edges_select_owned" ON public.canvas_edges FOR SELECT TO authenticated USING (owner_id = auth.uid());
CREATE POLICY "canvas_edges_insert_own" ON public.canvas_edges FOR INSERT TO authenticated WITH CHECK (owner_id = auth.uid());
CREATE POLICY "canvas_edges_update_own" ON public.canvas_edges FOR UPDATE TO authenticated USING (owner_id = auth.uid()) WITH CHECK (owner_id = auth.uid());
CREATE POLICY "canvas_edges_delete_own" ON public.canvas_edges FOR DELETE TO authenticated USING (owner_id = auth.uid());

DROP POLICY IF EXISTS "Allow public read/write on canvas_evidences" ON public.canvas_evidences;
CREATE POLICY "canvas_evidences_select_owned" ON public.canvas_evidences FOR SELECT TO authenticated USING (owner_id = auth.uid());
CREATE POLICY "canvas_evidences_insert_own" ON public.canvas_evidences FOR INSERT TO authenticated WITH CHECK (owner_id = auth.uid());
CREATE POLICY "canvas_evidences_update_own" ON public.canvas_evidences FOR UPDATE TO authenticated USING (owner_id = auth.uid()) WITH CHECK (owner_id = auth.uid());
CREATE POLICY "canvas_evidences_delete_own" ON public.canvas_evidences FOR DELETE TO authenticated USING (owner_id = auth.uid());

DROP POLICY IF EXISTS "Allow public read/write on canvas_review_decisions" ON public.canvas_review_decisions;
CREATE POLICY "canvas_review_decisions_select_owned" ON public.canvas_review_decisions FOR SELECT TO authenticated USING (owner_id = auth.uid());
CREATE POLICY "canvas_review_decisions_insert_own" ON public.canvas_review_decisions FOR INSERT TO authenticated WITH CHECK (owner_id = auth.uid());
CREATE POLICY "canvas_review_decisions_update_own" ON public.canvas_review_decisions FOR UPDATE TO authenticated USING (owner_id = auth.uid()) WITH CHECK (owner_id = auth.uid());
CREATE POLICY "canvas_review_decisions_delete_own" ON public.canvas_review_decisions FOR DELETE TO authenticated USING (owner_id = auth.uid());

DROP POLICY IF EXISTS "Allow public read/write on canvas_graph_snapshots" ON public.canvas_graph_snapshots;
CREATE POLICY "canvas_graph_snapshots_select_owned" ON public.canvas_graph_snapshots FOR SELECT TO authenticated USING (owner_id = auth.uid());
CREATE POLICY "canvas_graph_snapshots_insert_own" ON public.canvas_graph_snapshots FOR INSERT TO authenticated WITH CHECK (owner_id = auth.uid());
CREATE POLICY "canvas_graph_snapshots_update_own" ON public.canvas_graph_snapshots FOR UPDATE TO authenticated USING (owner_id = auth.uid()) WITH CHECK (owner_id = auth.uid());
CREATE POLICY "canvas_graph_snapshots_delete_own" ON public.canvas_graph_snapshots FOR DELETE TO authenticated USING (owner_id = auth.uid());

DROP POLICY IF EXISTS "Allow public read/write on marketplace_agents" ON public.marketplace_agents;
DROP POLICY IF EXISTS "Allow public read/write on marketplace_workflows" ON public.marketplace_workflows;
DROP POLICY IF EXISTS "Allow public read/write on marketplace_skills" ON public.marketplace_skills;
DROP POLICY IF EXISTS "Allow public read/write on marketplace_plugins" ON public.marketplace_plugins;
DROP POLICY IF EXISTS "Allow public read/write on marketplace_mcps" ON public.marketplace_mcps;

CREATE POLICY "marketplace_agents_public_select" ON public.marketplace_agents FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "marketplace_workflows_public_select" ON public.marketplace_workflows FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "marketplace_skills_public_select" ON public.marketplace_skills FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "marketplace_plugins_public_select" ON public.marketplace_plugins FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "marketplace_mcps_public_select" ON public.marketplace_mcps FOR SELECT TO anon, authenticated USING (true);

ALTER TABLE public.marketplace_reviews ADD COLUMN IF NOT EXISTS owner_id uuid REFERENCES auth.users(id) ON DELETE SET NULL;
ALTER TABLE public.marketplace_workflow_reviews ADD COLUMN IF NOT EXISTS owner_id uuid REFERENCES auth.users(id) ON DELETE SET NULL;
ALTER TABLE public.marketplace_skill_reviews ADD COLUMN IF NOT EXISTS owner_id uuid REFERENCES auth.users(id) ON DELETE SET NULL;
ALTER TABLE public.marketplace_mcp_reviews ADD COLUMN IF NOT EXISTS owner_id uuid REFERENCES auth.users(id) ON DELETE SET NULL;
ALTER TABLE public.marketplace_reviews ALTER COLUMN owner_id SET DEFAULT auth.uid();
ALTER TABLE public.marketplace_workflow_reviews ALTER COLUMN owner_id SET DEFAULT auth.uid();
ALTER TABLE public.marketplace_skill_reviews ALTER COLUMN owner_id SET DEFAULT auth.uid();
ALTER TABLE public.marketplace_mcp_reviews ALTER COLUMN owner_id SET DEFAULT auth.uid();

REVOKE SELECT, INSERT, UPDATE, DELETE ON public.marketplace_reviews FROM PUBLIC, anon, authenticated;
REVOKE SELECT, INSERT, UPDATE, DELETE ON public.marketplace_workflow_reviews FROM PUBLIC, anon, authenticated;
REVOKE SELECT, INSERT, UPDATE, DELETE ON public.marketplace_skill_reviews FROM PUBLIC, anon, authenticated;
REVOKE SELECT, INSERT, UPDATE, DELETE ON public.marketplace_mcp_reviews FROM PUBLIC, anon, authenticated;

GRANT SELECT (id, agent_id, reviewer_name, rating, comment, created_at)
  ON public.marketplace_reviews TO anon, authenticated;
GRANT SELECT (id, workflow_id, reviewer_name, rating, comment, created_at)
  ON public.marketplace_workflow_reviews TO anon, authenticated;
GRANT SELECT (id, skill_id, reviewer_name, rating, comment, created_at)
  ON public.marketplace_skill_reviews TO anon, authenticated;
GRANT SELECT (id, mcp_id, reviewer_name, rating, comment, created_at)
  ON public.marketplace_mcp_reviews TO anon, authenticated;

GRANT INSERT (agent_id, reviewer_name, rating, comment)
  ON public.marketplace_reviews TO authenticated;
GRANT INSERT (workflow_id, reviewer_name, rating, comment)
  ON public.marketplace_workflow_reviews TO authenticated;
GRANT INSERT (skill_id, reviewer_name, rating, comment)
  ON public.marketplace_skill_reviews TO authenticated;
GRANT INSERT (mcp_id, reviewer_name, rating, comment)
  ON public.marketplace_mcp_reviews TO authenticated;

GRANT UPDATE (reviewer_name, rating, comment)
  ON public.marketplace_reviews TO authenticated;
GRANT UPDATE (reviewer_name, rating, comment)
  ON public.marketplace_workflow_reviews TO authenticated;
GRANT UPDATE (reviewer_name, rating, comment)
  ON public.marketplace_skill_reviews TO authenticated;
GRANT UPDATE (reviewer_name, rating, comment)
  ON public.marketplace_mcp_reviews TO authenticated;

GRANT DELETE ON public.marketplace_reviews TO authenticated;
GRANT DELETE ON public.marketplace_workflow_reviews TO authenticated;
GRANT DELETE ON public.marketplace_skill_reviews TO authenticated;
GRANT DELETE ON public.marketplace_mcp_reviews TO authenticated;

DROP POLICY IF EXISTS "Allow public read/write on marketplace_reviews" ON public.marketplace_reviews;
DROP POLICY IF EXISTS "Allow public read/write on marketplace_workflow_reviews" ON public.marketplace_workflow_reviews;
DROP POLICY IF EXISTS "Allow public read/write on marketplace_skill_reviews" ON public.marketplace_skill_reviews;
DROP POLICY IF EXISTS "Allow public read/write on marketplace_mcp_reviews" ON public.marketplace_mcp_reviews;

CREATE POLICY "marketplace_reviews_public_select" ON public.marketplace_reviews FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "marketplace_reviews_insert_own" ON public.marketplace_reviews FOR INSERT TO authenticated WITH CHECK (owner_id = auth.uid());
CREATE POLICY "marketplace_reviews_update_own" ON public.marketplace_reviews FOR UPDATE TO authenticated USING (owner_id = auth.uid()) WITH CHECK (owner_id = auth.uid());
CREATE POLICY "marketplace_reviews_delete_own" ON public.marketplace_reviews FOR DELETE TO authenticated USING (owner_id = auth.uid());

CREATE POLICY "marketplace_workflow_reviews_public_select" ON public.marketplace_workflow_reviews FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "marketplace_workflow_reviews_insert_own" ON public.marketplace_workflow_reviews FOR INSERT TO authenticated WITH CHECK (owner_id = auth.uid());
CREATE POLICY "marketplace_workflow_reviews_update_own" ON public.marketplace_workflow_reviews FOR UPDATE TO authenticated USING (owner_id = auth.uid()) WITH CHECK (owner_id = auth.uid());
CREATE POLICY "marketplace_workflow_reviews_delete_own" ON public.marketplace_workflow_reviews FOR DELETE TO authenticated USING (owner_id = auth.uid());

CREATE POLICY "marketplace_skill_reviews_public_select" ON public.marketplace_skill_reviews FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "marketplace_skill_reviews_insert_own" ON public.marketplace_skill_reviews FOR INSERT TO authenticated WITH CHECK (owner_id = auth.uid());
CREATE POLICY "marketplace_skill_reviews_update_own" ON public.marketplace_skill_reviews FOR UPDATE TO authenticated USING (owner_id = auth.uid()) WITH CHECK (owner_id = auth.uid());
CREATE POLICY "marketplace_skill_reviews_delete_own" ON public.marketplace_skill_reviews FOR DELETE TO authenticated USING (owner_id = auth.uid());

CREATE POLICY "marketplace_mcp_reviews_public_select" ON public.marketplace_mcp_reviews FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "marketplace_mcp_reviews_insert_own" ON public.marketplace_mcp_reviews FOR INSERT TO authenticated WITH CHECK (owner_id = auth.uid());
CREATE POLICY "marketplace_mcp_reviews_update_own" ON public.marketplace_mcp_reviews FOR UPDATE TO authenticated USING (owner_id = auth.uid()) WITH CHECK (owner_id = auth.uid());
CREATE POLICY "marketplace_mcp_reviews_delete_own" ON public.marketplace_mcp_reviews FOR DELETE TO authenticated USING (owner_id = auth.uid());

DROP FUNCTION IF EXISTS public.execute_readonly_query(text);

CREATE OR REPLACE FUNCTION public.execute_readonly_query(query_text text, max_rows integer DEFAULT 100)
RETURNS json
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public
AS $$
DECLARE
  result json;
  trimmed text;
  lowered text;
  stripped text;
  bounded_max_rows integer;
  table_refs text[];
  function_refs text[];
BEGIN
  trimmed := btrim(query_text);
  lowered := lower(trimmed);
  stripped := regexp_replace(lowered, '''([^'']|'''')*''', '', 'g');
  bounded_max_rows := least(greatest(coalesce(max_rows, 100), 1), 1000);

  IF trimmed = '' OR NOT (lowered LIKE 'select%') THEN
    RAISE EXCEPTION 'Only SELECT queries are allowed';
  END IF;

  IF trimmed ~ ';' OR lowered ~ '--|/\*|\*/' THEN
    RAISE EXCEPTION 'Multiple statements and comments are not allowed';
  END IF;

  IF trimmed ~ '\$[a-zA-Z0-9_]*\$' THEN
    RAISE EXCEPTION 'Dollar-quoted SQL strings are not allowed';
  END IF;

  IF stripped ~ '\m(insert|update|delete|drop|alter|create|truncate|grant|revoke|execute|exec|copy|call|do|merge|vacuum|analyze|union|intersect|except|with)\M' THEN
    RAISE EXCEPTION 'Modification queries are not allowed';
  END IF;

  IF stripped ~ '\m(current_user|session_user|current_database|current_schema|version)\M' THEN
    RAISE EXCEPTION 'Query is outside the readonly allowlist';
  END IF;

  IF stripped ~ '\mjoin\M' OR stripped ~ '\mfrom\s+("?[a-z_][a-z0-9_]*"?(?:\."?[a-z_][a-z0-9_]*"?)?)(\s+[a-z_][a-z0-9_]*)?\s*,' THEN
    RAISE EXCEPTION 'Joins and multi-table queries are not allowed';
  END IF;

  SELECT array_agg(replace((m)[1], '"', ''))
    INTO table_refs
    FROM regexp_matches(stripped, '\mfrom\s+("?[a-z_][a-z0-9_]*"?(?:\."?[a-z_][a-z0-9_]*"?)?)', 'g') AS m;

  IF table_refs IS NULL OR array_length(table_refs, 1) <> 1 OR EXISTS (
    SELECT 1 FROM unnest(table_refs) AS ref
    WHERE ref NOT IN ('tasks', 'public.tasks')
  ) THEN
    RAISE EXCEPTION 'Only allowlisted tables can be queried';
  END IF;

  IF stripped ~ '\m(auth|storage|supabase_functions|information_schema|pg_catalog)\s*\.' THEN
    RAISE EXCEPTION 'Access to system schemas is not allowed';
  END IF;

  SELECT array_agg((m)[1])
    INTO function_refs
    FROM regexp_matches(stripped, '\m([a-z_][a-z0-9_]*)\s*\(', 'g') AS m;

  IF function_refs IS NOT NULL AND EXISTS (
    SELECT 1 FROM unnest(function_refs) AS fn(name)
    WHERE name NOT IN ('count', 'in')
  ) THEN
    RAISE EXCEPTION 'Only count() function calls are allowed';
  END IF;

  PERFORM set_config('statement_timeout', '3000', true);

  EXECUTE format(
    'SELECT json_agg(row_to_json(t)) FROM (SELECT * FROM (%s) limited_query LIMIT %s) t',
    trimmed,
    bounded_max_rows
  ) INTO result;

  RETURN COALESCE(result, '[]'::json);
END;
$$;

REVOKE EXECUTE ON FUNCTION public.execute_readonly_query(text, integer) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.execute_readonly_query(text, integer) FROM anon;
GRANT EXECUTE ON FUNCTION public.execute_readonly_query(text, integer) TO authenticated;
