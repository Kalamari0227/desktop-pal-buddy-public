
-- Canvas Node Types enum
CREATE TYPE public.canvas_node_type AS ENUM (
  'memo', 'meeting', 'customer', 'document', 'action',
  'product', 'issue', 'risk', 'ai_insight', 'project', 'report'
);

-- Canvas Node Status enum
CREATE TYPE public.canvas_node_status AS ENUM ('active', 'archived', 'deleted', 'needs_review');

-- Canvas Edge Type enum
CREATE TYPE public.canvas_edge_type AS ENUM (
  'related', 'same_customer', 'same_project', 'follow_up',
  'cause_effect', 'evidence', 'conflict', 'derived_from', 'mentioned_in'
);

-- Canvas Edge Status enum
CREATE TYPE public.canvas_edge_status AS ENUM ('suggested', 'confirmed', 'rejected', 'hidden', 'archived');

-- Canvas Evidence Type enum
CREATE TYPE public.canvas_evidence_type AS ENUM (
  'shared_entity', 'shared_keyword', 'embedding_similarity',
  'same_document', 'temporal_proximity', 'user_confirmed', 'ai_reasoning'
);

-- Canvas Review Decision enum
CREATE TYPE public.canvas_review_decision AS ENUM ('approved', 'rejected', 'edited', 'deferred');

-- 1. canvas_nodes
CREATE TABLE public.canvas_nodes (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  type canvas_node_type NOT NULL DEFAULT 'memo',
  title TEXT NOT NULL,
  content TEXT,
  summary TEXT,
  tags TEXT[] DEFAULT '{}',
  status canvas_node_status NOT NULL DEFAULT 'active',
  importance_score NUMERIC DEFAULT 0.5,
  confidence_score NUMERIC DEFAULT 1.0,
  customer_id TEXT,
  project_id TEXT,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.canvas_nodes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Allow public read/write on canvas_nodes" ON public.canvas_nodes FOR ALL TO public USING (true) WITH CHECK (true);

-- 2. canvas_edges
CREATE TABLE public.canvas_edges (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  source_id UUID NOT NULL REFERENCES public.canvas_nodes(id) ON DELETE CASCADE,
  target_id UUID NOT NULL REFERENCES public.canvas_nodes(id) ON DELETE CASCADE,
  type canvas_edge_type NOT NULL DEFAULT 'related',
  status canvas_edge_status NOT NULL DEFAULT 'suggested',
  confidence_score NUMERIC DEFAULT 0.5,
  weight NUMERIC DEFAULT 0.5,
  explanation TEXT,
  created_by TEXT NOT NULL DEFAULT 'ai',
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT canvas_edges_no_self_loop CHECK (source_id != target_id)
);

ALTER TABLE public.canvas_edges ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Allow public read/write on canvas_edges" ON public.canvas_edges FOR ALL TO public USING (true) WITH CHECK (true);

-- 3. canvas_evidences
CREATE TABLE public.canvas_evidences (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  edge_id UUID REFERENCES public.canvas_edges(id) ON DELETE CASCADE,
  type canvas_evidence_type NOT NULL DEFAULT 'shared_entity',
  label TEXT NOT NULL,
  description TEXT,
  score NUMERIC DEFAULT 0.5,
  source_refs TEXT[] DEFAULT '{}',
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.canvas_evidences ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Allow public read/write on canvas_evidences" ON public.canvas_evidences FOR ALL TO public USING (true) WITH CHECK (true);

-- 4. canvas_review_decisions
CREATE TABLE public.canvas_review_decisions (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  target_type TEXT NOT NULL DEFAULT 'edge',
  target_id UUID NOT NULL,
  decision canvas_review_decision NOT NULL DEFAULT 'deferred',
  reason TEXT,
  reviewed_by TEXT,
  reviewed_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.canvas_review_decisions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Allow public read/write on canvas_review_decisions" ON public.canvas_review_decisions FOR ALL TO public USING (true) WITH CHECK (true);

-- 5. canvas_graph_snapshots
CREATE TABLE public.canvas_graph_snapshots (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  node_ids UUID[] DEFAULT '{}',
  edge_ids UUID[] DEFAULT '{}',
  filters JSONB DEFAULT '{}',
  layout JSONB DEFAULT '{}',
  created_by TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.canvas_graph_snapshots ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Allow public read/write on canvas_graph_snapshots" ON public.canvas_graph_snapshots FOR ALL TO public USING (true) WITH CHECK (true);
