CREATE TABLE IF NOT EXISTS public.agent_approvals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid NOT NULL REFERENCES public.tasks(id) ON DELETE CASCADE,
  packet_task_id text NOT NULL,
  decision text NOT NULL CHECK (decision IN ('approved', 'rejected')),
  action_type text CHECK (
    action_type IS NULL OR action_type IN (
      'external_message',
      'file_delete_or_move',
      'production_deploy',
      'database_migration',
      'service_restart',
      'oauth_or_gateway_config_change',
      'paid_resource_creation',
      'secret_create_or_store',
      'permission_change'
    )
  ),
  approval_reason text NOT NULL CHECK (btrim(approval_reason) <> ''),
  approved_scope text NOT NULL CHECK (btrim(approved_scope) <> ''),
  owner_id uuid REFERENCES auth.users(id) ON DELETE SET NULL DEFAULT auth.uid(),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_agent_approvals_owner_task_created
  ON public.agent_approvals (owner_id, task_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_agent_approvals_packet_task
  ON public.agent_approvals (packet_task_id);

ALTER TABLE public.agent_approvals ENABLE ROW LEVEL SECURITY;

REVOKE SELECT, INSERT, UPDATE, DELETE ON public.agent_approvals FROM PUBLIC, anon, authenticated;
GRANT SELECT, INSERT, DELETE ON public.agent_approvals TO authenticated;

DROP POLICY IF EXISTS "agent_approvals_select_owned_task" ON public.agent_approvals;
CREATE POLICY "agent_approvals_select_owned_task"
  ON public.agent_approvals
  FOR SELECT
  TO authenticated
  USING (
    owner_id = auth.uid()
    AND EXISTS (
      SELECT 1
      FROM public.tasks
      WHERE tasks.id = agent_approvals.task_id
        AND tasks.owner_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "agent_approvals_insert_owned_task" ON public.agent_approvals;
CREATE POLICY "agent_approvals_insert_owned_task"
  ON public.agent_approvals
  FOR INSERT
  TO authenticated
  WITH CHECK (
    owner_id = auth.uid()
    AND EXISTS (
      SELECT 1
      FROM public.tasks
      WHERE tasks.id = agent_approvals.task_id
        AND tasks.owner_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "agent_approvals_delete_owned_task" ON public.agent_approvals;
CREATE POLICY "agent_approvals_delete_owned_task"
  ON public.agent_approvals
  FOR DELETE
  TO authenticated
  USING (
    owner_id = auth.uid()
    AND EXISTS (
      SELECT 1
      FROM public.tasks
      WHERE tasks.id = agent_approvals.task_id
        AND tasks.owner_id = auth.uid()
    )
  );
