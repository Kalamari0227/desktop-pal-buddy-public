import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const migrationPath = path.join(
  path.dirname(fileURLToPath(import.meta.url)),
  "20260702150000_harden_data_access_and_queries.sql"
);
const migrationSql = readFileSync(migrationPath, "utf8");
const restrictRatingTriggerFunctionsSql = readFileSync(
  path.join(
    path.dirname(fileURLToPath(import.meta.url)),
    "20260702233345_restrict_rating_trigger_function_execution.sql"
  ),
  "utf8"
);

describe("hardening migration", () => {
  it("keeps review owner ids out of public select grants", () => {
    const grantMatches = [
      ...migrationSql.matchAll(
        /GRANT SELECT \(([^)]+)\)\s+ON public\.(marketplace(?:_[a-z]+)?_reviews) TO anon, authenticated;/g
      ),
    ];

    expect(grantMatches).toHaveLength(4);
    for (const [, columns] of grantMatches) {
      expect(columns).not.toContain("owner_id");
    }
    expect(migrationSql).toContain(
      "REVOKE SELECT, INSERT, UPDATE, DELETE ON public.marketplace_reviews FROM PUBLIC, anon, authenticated;"
    );
  });

  it("makes installed item uniqueness user scoped", () => {
    expect(migrationSql).toContain("DROP INDEX IF EXISTS public.idx_installed_items_unique;");
    expect(migrationSql).toContain(
      "ALTER TABLE public.installed_items DROP CONSTRAINT IF EXISTS installed_items_item_id_item_type_key;"
    );
    expect(migrationSql).toContain("ON public.installed_items (owner_id, item_id, item_type);");
  });

  it("makes alert dismissals user scoped", () => {
    expect(migrationSql).toContain(
      "ALTER TABLE public.alert_dismissals DROP CONSTRAINT IF EXISTS alert_dismissals_task_id_key;"
    );
    expect(migrationSql).toContain("ON public.alert_dismissals (owner_id, task_id);");
  });

  it("creates the data query audit table used by the Edge Function", () => {
    expect(migrationSql).toContain("CREATE TABLE IF NOT EXISTS public.data_query_audit_logs");
    expect(migrationSql).toContain("question text NOT NULL");
    expect(migrationSql).toContain("generated_sql text");
    expect(migrationSql).toContain("row_count integer NOT NULL DEFAULT 0");
    expect(migrationSql).toContain("status text NOT NULL");
    expect(migrationSql).toContain("error_message text");
    expect(migrationSql).toContain("latency_ms integer");
  });

  it("creates a service-side rate limit event table for Edge Functions", () => {
    expect(migrationSql).toContain("CREATE TABLE IF NOT EXISTS public.edge_rate_limit_events");
    expect(migrationSql).toContain("scope text NOT NULL CHECK (scope IN ('chat', 'data_query'))");
    expect(migrationSql).toContain("idx_edge_rate_limit_events_user_scope_created");
    expect(migrationSql).toContain(
      "REVOKE SELECT, INSERT, UPDATE, DELETE ON public.edge_rate_limit_events FROM PUBLIC, anon, authenticated;"
    );
  });

  it("keeps the readonly query RPC constrained to a single tasks table query", () => {
    expect(migrationSql).toContain("stripped := regexp_replace");
    expect(migrationSql).toContain("Joins and multi-table queries are not allowed");
    expect(migrationSql).toContain("array_length(table_refs, 1) <> 1");
    expect(migrationSql).toContain("Only count() function calls are allowed");
    expect(migrationSql).toContain("union|intersect|except|with");
  });

  it("prevents rating trigger functions from becoming public RPC endpoints", () => {
    for (const functionName of [
      "update_agent_rating",
      "update_workflow_rating",
      "update_skill_rating",
      "update_mcp_rating",
    ]) {
      expect(restrictRatingTriggerFunctionsSql).toContain(
        `REVOKE EXECUTE ON FUNCTION public.${functionName}() FROM PUBLIC, anon, authenticated;`
      );
    }
  });
});
