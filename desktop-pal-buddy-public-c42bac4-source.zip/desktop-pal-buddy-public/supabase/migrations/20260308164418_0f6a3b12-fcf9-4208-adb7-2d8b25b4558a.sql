-- Skills table
CREATE TABLE public.marketplace_skills (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  description text,
  category text NOT NULL DEFAULT 'general',
  icon text DEFAULT 'Zap',
  skill_type text NOT NULL DEFAULT 'transform',
  input_schema jsonb DEFAULT '{}',
  output_schema jsonb DEFAULT '{}',
  implementation text,
  creator_name text DEFAULT '익명',
  installs integer DEFAULT 0,
  rating numeric DEFAULT 0,
  tags text[] DEFAULT '{}',
  is_featured boolean DEFAULT false,
  is_composable boolean DEFAULT true,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.marketplace_skills ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Allow public read/write on marketplace_skills"
  ON public.marketplace_skills FOR ALL USING (true) WITH CHECK (true);

-- Skill reviews
CREATE TABLE public.marketplace_skill_reviews (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  skill_id uuid NOT NULL REFERENCES public.marketplace_skills(id) ON DELETE CASCADE,
  rating integer NOT NULL,
  comment text,
  reviewer_name text NOT NULL DEFAULT '익명',
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.marketplace_skill_reviews ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Allow public read/write on marketplace_skill_reviews"
  ON public.marketplace_skill_reviews FOR ALL USING (true) WITH CHECK (true);

-- Skill Plugins (composed from multiple skills)
CREATE TABLE public.marketplace_plugins (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  description text,
  skill_ids text[] NOT NULL DEFAULT '{}',
  skill_config jsonb DEFAULT '[]',
  creator_name text DEFAULT '익명',
  installs integer DEFAULT 0,
  rating numeric DEFAULT 0,
  tags text[] DEFAULT '{}',
  is_featured boolean DEFAULT false,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.marketplace_plugins ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Allow public read/write on marketplace_plugins"
  ON public.marketplace_plugins FOR ALL USING (true) WITH CHECK (true);

-- MCP Servers table
CREATE TABLE public.marketplace_mcps (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name text NOT NULL,
  description text,
  category text NOT NULL DEFAULT 'general',
  icon text DEFAULT 'Server',
  server_url text,
  auth_type text DEFAULT 'none',
  tools_count integer DEFAULT 0,
  tools_schema jsonb DEFAULT '[]',
  creator_name text DEFAULT '익명',
  installs integer DEFAULT 0,
  rating numeric DEFAULT 0,
  tags text[] DEFAULT '{}',
  is_featured boolean DEFAULT false,
  is_verified boolean DEFAULT false,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.marketplace_mcps ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Allow public read/write on marketplace_mcps"
  ON public.marketplace_mcps FOR ALL USING (true) WITH CHECK (true);

-- MCP reviews
CREATE TABLE public.marketplace_mcp_reviews (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  mcp_id uuid NOT NULL REFERENCES public.marketplace_mcps(id) ON DELETE CASCADE,
  rating integer NOT NULL,
  comment text,
  reviewer_name text NOT NULL DEFAULT '익명',
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.marketplace_mcp_reviews ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Allow public read/write on marketplace_mcp_reviews"
  ON public.marketplace_mcp_reviews FOR ALL USING (true) WITH CHECK (true);

-- Rating triggers for skills
CREATE OR REPLACE FUNCTION public.update_skill_rating()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  UPDATE public.marketplace_skills
  SET rating = (SELECT COALESCE(ROUND(AVG(rating)::numeric, 1), 0) FROM public.marketplace_skill_reviews WHERE skill_id = COALESCE(NEW.skill_id, OLD.skill_id))
  WHERE id = COALESCE(NEW.skill_id, OLD.skill_id);
  RETURN COALESCE(NEW, OLD);
END;
$$;

CREATE TRIGGER on_skill_review_change
  AFTER INSERT OR UPDATE OR DELETE ON public.marketplace_skill_reviews
  FOR EACH ROW EXECUTE FUNCTION public.update_skill_rating();

-- Rating triggers for MCPs
CREATE OR REPLACE FUNCTION public.update_mcp_rating()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  UPDATE public.marketplace_mcps
  SET rating = (SELECT COALESCE(ROUND(AVG(rating)::numeric, 1), 0) FROM public.marketplace_mcp_reviews WHERE mcp_id = COALESCE(NEW.mcp_id, OLD.mcp_id))
  WHERE id = COALESCE(NEW.mcp_id, OLD.mcp_id);
  RETURN COALESCE(NEW, OLD);
END;
$$;