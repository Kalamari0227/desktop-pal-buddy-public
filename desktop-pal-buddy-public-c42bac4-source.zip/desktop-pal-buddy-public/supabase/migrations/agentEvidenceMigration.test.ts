import { readFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";

const migrationSql = readFileSync(
  path.join(
    path.dirname(fileURLToPath(import.meta.url)),
    "20260704185000_create_agent_evidence_ledger.sql"
  ),
  "utf8"
);

describe("agent evidence migration", () => {
  it("creates an owner-scoped evidence ledger table tied to tasks", () => {
    expect(migrationSql).toContain("CREATE TABLE IF NOT EXISTS public.agent_evidence");
    expect(migrationSql).toContain("task_id uuid NOT NULL REFERENCES public.tasks(id) ON DELETE CASCADE");
    expect(migrationSql).toContain("packet_task_id text NOT NULL");
    expect(migrationSql).toContain("owner_id uuid REFERENCES auth.users(id) ON DELETE SET NULL DEFAULT auth.uid()");
    expect(migrationSql).toContain("CONSTRAINT agent_evidence_owner_evidence_unique UNIQUE (owner_id, evidence_id)");
  });

  it("keeps evidence writes authenticated and owner checked", () => {
    expect(migrationSql).toContain("REVOKE SELECT, INSERT, UPDATE, DELETE ON public.agent_evidence FROM PUBLIC, anon, authenticated;");
    expect(migrationSql).toContain("GRANT SELECT, INSERT, UPDATE, DELETE ON public.agent_evidence TO authenticated;");
    expect(migrationSql).toContain("agent_evidence_select_owned_task");
    expect(migrationSql).toContain("agent_evidence_insert_owned_task");
    expect(migrationSql).toContain("tasks.owner_id = auth.uid()");
  });

  it("keeps evidence values constrained to the Agentic OS contract", () => {
    expect(migrationSql).toContain("'manual_observation'");
    expect(migrationSql).toContain("'delivery_schedule'");
    expect(migrationSql).toContain("'risk_assessment'");
    expect(migrationSql).toContain("source_system IN");
    expect(migrationSql).toContain("status text NOT NULL CHECK (status IN ('passed', 'failed', 'warning', 'info'))");
    expect(migrationSql).toContain("raw_excerpt text CHECK (raw_excerpt IS NULL OR char_length(raw_excerpt) <= 4000)");
  });
});
