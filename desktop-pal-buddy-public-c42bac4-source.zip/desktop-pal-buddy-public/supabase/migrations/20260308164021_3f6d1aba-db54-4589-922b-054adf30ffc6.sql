CREATE TABLE public.debate_history (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  topic text NOT NULL,
  pro_agent_id text NOT NULL,
  con_agent_id text NOT NULL,
  judge_agent_id text,
  debate_rounds integer NOT NULL DEFAULT 3,
  messages jsonb NOT NULL DEFAULT '[]'::jsonb,
  verdict text,
  verdict_reason text,
  summary text,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.debate_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public read/write on debate_history"
  ON public.debate_history
  FOR ALL
  USING (true)
  WITH CHECK (true);