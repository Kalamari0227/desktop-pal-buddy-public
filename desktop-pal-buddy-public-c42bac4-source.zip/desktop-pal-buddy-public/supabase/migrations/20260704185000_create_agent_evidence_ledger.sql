CREATE TABLE IF NOT EXISTS public.agent_evidence (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  task_id uuid NOT NULL REFERENCES public.tasks(id) ON DELETE CASCADE,
  packet_task_id text NOT NULL,
  evidence_id text NOT NULL,
  evidence_type text NOT NULL CHECK (
    evidence_type IN (
      'command_output',
      'test_result',
      'ci_status',
      'github_pr',
      'github_commit',
      'file_diff',
      'supabase_project_status',
      'supabase_migration_status',
      'edge_function_status',
      'advisor_result',
      'generated_document',
      'manual_observation',
      'inventory_snapshot',
      'order_status',
      'delivery_schedule',
      'risk_assessment',
      'generated_reply',
      'substitution_option'
    )
  ),
  summary text NOT NULL CHECK (btrim(summary) <> ''),
  source_system text NOT NULL CHECK (
    source_system IN (
      'github',
      'supabase',
      'local_shell',
      'repo',
      'gateway',
      'codex_worker',
      'user',
      'erp',
      'crm',
      'spreadsheet'
    )
  ),
  source_url text,
  source_path text,
  source_command text,
  source_ref text,
  status text NOT NULL CHECK (status IN ('passed', 'failed', 'warning', 'info')),
  raw_excerpt text CHECK (raw_excerpt IS NULL OR char_length(raw_excerpt) <= 4000),
  artifact_path text,
  owner_id uuid REFERENCES auth.users(id) ON DELETE SET NULL DEFAULT auth.uid(),
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT agent_evidence_owner_evidence_unique UNIQUE (owner_id, evidence_id)
);

CREATE INDEX IF NOT EXISTS idx_agent_evidence_owner_task_created
  ON public.agent_evidence (owner_id, task_id, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_agent_evidence_packet_task
  ON public.agent_evidence (packet_task_id);

ALTER TABLE public.agent_evidence ENABLE ROW LEVEL SECURITY;

REVOKE SELECT, INSERT, UPDATE, DELETE ON public.agent_evidence FROM PUBLIC, anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.agent_evidence TO authenticated;

DROP POLICY IF EXISTS "agent_evidence_select_owned_task" ON public.agent_evidence;
CREATE POLICY "agent_evidence_select_owned_task"
  ON public.agent_evidence
  FOR SELECT
  TO authenticated
  USING (
    owner_id = auth.uid()
    AND EXISTS (
      SELECT 1
      FROM public.tasks
      WHERE tasks.id = agent_evidence.task_id
        AND tasks.owner_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "agent_evidence_insert_owned_task" ON public.agent_evidence;
CREATE POLICY "agent_evidence_insert_owned_task"
  ON public.agent_evidence
  FOR INSERT
  TO authenticated
  WITH CHECK (
    owner_id = auth.uid()
    AND EXISTS (
      SELECT 1
      FROM public.tasks
      WHERE tasks.id = agent_evidence.task_id
        AND tasks.owner_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "agent_evidence_update_owned_task" ON public.agent_evidence;
CREATE POLICY "agent_evidence_update_owned_task"
  ON public.agent_evidence
  FOR UPDATE
  TO authenticated
  USING (
    owner_id = auth.uid()
    AND EXISTS (
      SELECT 1
      FROM public.tasks
      WHERE tasks.id = agent_evidence.task_id
        AND tasks.owner_id = auth.uid()
    )
  )
  WITH CHECK (
    owner_id = auth.uid()
    AND EXISTS (
      SELECT 1
      FROM public.tasks
      WHERE tasks.id = agent_evidence.task_id
        AND tasks.owner_id = auth.uid()
    )
  );

DROP POLICY IF EXISTS "agent_evidence_delete_owned_task" ON public.agent_evidence;
CREATE POLICY "agent_evidence_delete_owned_task"
  ON public.agent_evidence
  FOR DELETE
  TO authenticated
  USING (
    owner_id = auth.uid()
    AND EXISTS (
      SELECT 1
      FROM public.tasks
      WHERE tasks.id = agent_evidence.task_id
        AND tasks.owner_id = auth.uid()
    )
  );
