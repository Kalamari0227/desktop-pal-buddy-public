# Supabase Scope Guide

This guide adds local context to the root `AGENTS.md` for `supabase/`.
Local paths are relative to `supabase/`; `src/` paths are repository-relative.

## Code Map

- `functions/chat/index.ts` and `functions/data-query/index.ts` are Deno Edge Function entrypoints.
- They use URL imports, `Deno.env`, and `serve`; do not treat them as Node application modules.
- `functions/_shared/requestGuards.ts` owns CORS, bearer parsing, payload checks, and rate-limit helpers.
- `functions/_shared/sqlSafety.ts` contains a readonly SQL sanitizer with direct unit tests.
- `migrations/` contains ordered SQL history and colocated source-contract tests.
- Frontend client and generated database types live outside this scope in `src/integrations/supabase/`.
- Agent ledger row mappings live in `src/lib/agentic/*Persistence.ts`.

## Current Handler Contracts

- Both handlers answer `OPTIONS` before running the normal request guards.
- Normal requests check origin, verify the bearer token with Supabase Auth, apply the persistent rate limit, then validate the payload.
- Keep that sequence explicit when changing request handling; bearer parsing alone is not authentication.
- Both handler code paths use `assertPersistentRateLimit`, backed by `edge_rate_limit_events` and scoped by user and operation.
- The memory limiter is a separate helper, not the limiter currently used by either handler.
- Persistent limiter storage errors return 503; exhausted limits return 429.
- After valid input, both handlers currently return 501 with a disabled Hermes/Codex bridge message.
- Neither handler currently executes AI calls; `data-query` does not generate or execute SQL.
- This describes the current implementation, not a permanent restriction on future approved bridge work.
- `data-query` attempts a `rejected` audit entry after valid input and a `query_error` entry when an exception occurs after audit context exists.
- Audit insertion errors returned by Supabase are logged; successful audit persistence is not guaranteed before the response.
- Keep audit fields aligned with `data_query_audit_logs`: `question`, `generated_sql`, `row_count`, `status`, `error_message`, and `latency_ms`.

## Migration and Ledger Contracts

- The hardening migration is `migrations/20260702150000_harden_data_access_and_queries.sql`.
- It defines owner-scoped task access, private rate-limit events, audit rows, and the readonly-query RPC.
- Its `execute_readonly_query(text, integer)` uses `SECURITY INVOKER`, allows authenticated execution, and limits reads to `tasks`.
- SQL helper and RPC checks are separate implementations; inspect both when changing readonly-query constraints.
- Local SQL files describe intended schema and exposure; their presence does not establish deployment state.
- Four later migrations define `agent_evidence`, `agent_approvals`, `agent_events`, and `agent_results`.
- Each ledger links `task_id` to `public.tasks(id)` and requires both ledger ownership and linked task ownership in its authenticated RLS policies.
- Database `task_id` is the Workboard task UUID; `packet_task_id` is the Agentic OS packet identifier. Do not interchange them.
- Evidence grants authenticated SELECT, INSERT, UPDATE, and DELETE; approvals, events, and results grant SELECT, INSERT, and DELETE only.
- Evidence and events have owner-scoped external ID uniqueness constraints; preserve their persistence mapping semantics.
- Check SQL CHECK constraints against `src/lib/agentic/types.ts`, `src/lib/agentic/schemas.ts`, and the affected persistence mapper when contracts change.
- Generated database types are in `src/integrations/supabase/types.ts`; follow the root generated-file rule rather than treating them as the schema source.

## Focused Verification

- Run these commands from the repository root, selecting only the relevant group:
  - `npm test -- supabase/functions/_shared/requestGuards.test.ts`
  - `npm test -- supabase/functions/_shared/sqlSafety.test.ts`
  - `npm test -- supabase/functions/chat/providerIndependence.test.ts supabase/functions/data-query/auditContract.test.ts`
  - `npm test -- supabase/migrations`
- These tests run through Node/Vitest with the root jsdom configuration, not the Deno Edge runtime.
- Shared helper tests exercise imported functions; handler contract tests inspect source text instead of serving requests.
- Migration tests inspect SQL text. Passing them does not prove migrations apply or RLS denies another user's access.
- For database execution evidence, use the existing verification commands and Docker/reset cautions in the root `AGENTS.md`.
- Report source checks, helper tests, database verification, and deployed behavior as distinct evidence.
