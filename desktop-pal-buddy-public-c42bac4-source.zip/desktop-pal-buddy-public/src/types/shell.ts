export type ViewMode = "ambient" | "chat" | "workspace";

export type ShellMode = "browser" | "dock" | "workspace";

export interface WorkspaceLaunchState {
  initialMode?: string;
  initialContext: Record<string, string>;
  initialPrompt?: string;
  initialPromptId: number;
}
