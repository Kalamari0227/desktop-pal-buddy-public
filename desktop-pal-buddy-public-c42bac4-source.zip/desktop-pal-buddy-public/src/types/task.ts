import type { Database } from "@/integrations/supabase/types";

export type TaskRecord = Database["public"]["Tables"]["tasks"]["Row"];
export type TaskInsert = Database["public"]["Tables"]["tasks"]["Insert"];
