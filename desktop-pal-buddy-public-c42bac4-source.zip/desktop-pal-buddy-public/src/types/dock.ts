// Dock state machine types per spec

export type DockState =
  | "idle"
  | "hovered"
  | "expanded"
  | "listening"
  | "thinking"
  | "dispatching"
  | "working"
  | "needs_review"
  | "alert"
  | "completed"
  | "error";

export type AgentId = "market" | "risk" | "docs" | "sales" | "planner";

export type AgentState =
  | "hidden"
  | "inactive"
  | "available"
  | "activated"
  | "focused"
  | "needs_review"
  | "alert_linked"
  | "completed";

export interface Agent {
  id: AgentId;
  name: string;
  nameKo: string;
  description: string;
  state: AgentState;
  badge?: number;
}

export interface QuickAction {
  id: string;
  label: string;
  icon: string; // lucide icon name
  agentId?: AgentId;
}

export interface DockAlert {
  id: string;
  type: "risk" | "review" | "info";
  title: string;
  customer?: string;
  severity: "low" | "medium" | "high";
  agentId: AgentId;
}

// State transition labels per spec
export const STATE_LABELS: Record<DockState, string> = {
  idle: "대기",
  hovered: "대기",
  expanded: "대기",
  listening: "입력 대기 중",
  thinking: "분석 중",
  dispatching: "에이전트 배정 중",
  working: "작업 수행 중",
  needs_review: "검토 필요",
  alert: "주의 필요",
  completed: "완료",
  error: "오류 발생",
};

export const DEFAULT_AGENTS: Agent[] = [
  {
    id: "market",
    name: "Market",
    nameKo: "시장 분석",
    description: "고객/시장/브리핑 관련",
    state: "available",
  },
  {
    id: "risk",
    name: "Risk",
    nameKo: "리스크 감지",
    description: "경고/납기/품질/이슈",
    state: "available",
  },
  {
    id: "docs",
    name: "Docs",
    nameKo: "문서 탐색",
    description: "문서 검색/요약",
    state: "available",
  },
];

export const QUICK_ACTIONS: QuickAction[] = [
  { id: "briefing", label: "오늘 브리핑", icon: "Calendar", agentId: "market" },
  { id: "draft", label: "회신 초안", icon: "PenLine", agentId: "docs" },
  { id: "search", label: "문서 찾기", icon: "Search", agentId: "docs" },
  { id: "risk", label: "리스크 보기", icon: "ShieldAlert", agentId: "risk" },
  { id: "workspace", label: "워크스페이스", icon: "LayoutDashboard" },
];
