import { describe, expect, it } from "vitest";
import { getDockPrompt, resolveWorkspaceMode } from "./dockActions";

describe("dock action config", () => {
  it("maps dock action ids to workspace modes", () => {
    expect(resolveWorkspaceMode("briefing")).toBe("meeting");
    expect(resolveWorkspaceMode("draft")).toBe("response");
    expect(resolveWorkspaceMode("unknown-mode")).toBe("unknown-mode");
    expect(resolveWorkspaceMode()).toBeUndefined();
  });

  it("returns a specific prompt before falling back to a generic one", () => {
    expect(getDockPrompt("risk")).toContain("리스크");
    expect(getDockPrompt("custom")).toContain("자동차 강판 영업 상황");
  });
});
