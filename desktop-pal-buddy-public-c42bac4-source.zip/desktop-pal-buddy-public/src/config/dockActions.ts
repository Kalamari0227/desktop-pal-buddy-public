export const ELECTRON_WORKSPACE_MODE_MAP: Record<string, string | undefined> = {
  briefing: "meeting",
  draft: "response",
  search: "search",
  risk: "risk",
  workspace: undefined,
  market: "meeting",
  docs: "search",
};

export const DOCK_ENTRY_LABELS: Record<string, string> = {
  briefing: "오늘 브리핑",
  draft: "회신 초안",
  search: "문서 찾기",
  risk: "리스크 보기",
  workspace: "워크스페이스",
  market: "시장 브리핑",
  docs: "문서 탐색",
};

export const QUICK_ACTION_PROMPTS: Record<string, string> = {
  briefing: "오늘의 업무 브리핑을 정리해줘. 자동차 강판 고객사별 주요 이슈와 오늘 일정을 포함해서.",
  draft: "회신 초안 스테이션을 열어줘. 내가 가진 메일 몇 개를 보고, 그중 이런 메일은 이렇게 답하면 좋겠다는 추천 답장 초안을 보여줘.",
  search: "문서 스테이션을 열어줘. 내가 어떤 글을 찾고 있는지 물어보고, 이런 문서를 원한 것 아니냐는 추천 후보를 보여줘.",
  risk: "현재 납기, 품질, 가격 관련 리스크 항목을 점검해줘.",
  market: "시장 분석 스테이션을 열어줘. 자동차 강판 시장 신호, 고객사 움직임, 가격/수요 흐름을 분석해줘.",
  docs: "문서 스테이션을 열어줘. 내가 어떤 글을 찾고 있는지 물어보고, 이런 문서를 원한 것 아니냐는 추천 후보를 보여줘.",
};

export function getDockPrompt(actionId: string) {
  return QUICK_ACTION_PROMPTS[actionId] || `${DOCK_ENTRY_LABELS[actionId] || "업무"}를 열어줘. 자동차 강판 영업 상황에 맞춰 바로 실행할 수 있게 정리해줘.`;
}

export function resolveWorkspaceMode(initialMode?: string) {
  if (!initialMode) return undefined;
  if (Object.prototype.hasOwnProperty.call(ELECTRON_WORKSPACE_MODE_MAP, initialMode)) {
    return ELECTRON_WORKSPACE_MODE_MAP[initialMode];
  }
  return initialMode;
}
