import { create } from "zustand";

/* ── Canvas Transition State ── */
export type CanvasTransitionState =
  | "boot"
  | "network_forming"
  | "network_expand"
  | "flatten"
  | "canvas_init"
  | "workspace_ready";

/* ── App Mode ── */
export type CanvasMode = "ambient" | "workspace" | "focus" | "analysis";

/* ── Graph node/edge minimal types for UI state ── */
export interface CanvasNodeUI {
  id: string;
  type: string;
  title: string;
  x: number;
  y: number;
  z: number;
  importance_score: number;
  status: string;
}

export interface CanvasEdgeUI {
  id: string;
  source_id: string;
  target_id: string;
  type: string;
  status: string;
  confidence_score: number;
}

/* ── Viewport ── */
export interface CanvasViewport {
  x: number;
  y: number;
  zoom: number;
}

/* ── UI State Slice ── */
interface UIState {
  mode: CanvasMode;
  transitionState: CanvasTransitionState;
  selectedNodeIds: Set<string>;
  selectedClusterId: string | null;
  activeFilters: Record<string, string[]>;
  panelVisibility: {
    filters: boolean;
    detail: boolean;
    search: boolean;
  };
}

/* ── Graph State Slice ── */
interface GraphState {
  nodes: CanvasNodeUI[];
  edges: CanvasEdgeUI[];
  viewport: CanvasViewport;
  layoutVersion: number;
  hiddenIds: Set<string>;
  suggestedLinkIds: Set<string>;
}

/* ── Data Sync State Slice ── */
interface DataSyncState {
  loading: boolean;
  stale: boolean;
  syncing: boolean;
  error: string | null;
  lastRefreshedAt: Date | null;
}

/* ── Combined Store ── */
interface CanvasStore {
  // UI
  ui: UIState;
  setMode: (mode: CanvasMode) => void;
  setTransitionState: (state: CanvasTransitionState) => void;
  selectNode: (id: string) => void;
  deselectNode: (id: string) => void;
  clearSelection: () => void;
  togglePanel: (panel: keyof UIState["panelVisibility"]) => void;

  // Graph
  graph: GraphState;
  setNodes: (nodes: CanvasNodeUI[]) => void;
  setEdges: (edges: CanvasEdgeUI[]) => void;
  setViewport: (viewport: Partial<CanvasViewport>) => void;
  bumpLayoutVersion: () => void;

  // Sync
  sync: DataSyncState;
  setSyncState: (patch: Partial<DataSyncState>) => void;
}

export const useCanvasStore = create<CanvasStore>((set) => ({
  // ── UI State ──
  ui: {
    mode: "ambient",
    transitionState: "boot",
    selectedNodeIds: new Set(),
    selectedClusterId: null,
    activeFilters: {},
    panelVisibility: { filters: false, detail: false, search: false },
  },
  setMode: (mode) =>
    set((s) => ({ ui: { ...s.ui, mode } })),
  setTransitionState: (transitionState) =>
    set((s) => ({ ui: { ...s.ui, transitionState } })),
  selectNode: (id) =>
    set((s) => {
      const next = new Set(s.ui.selectedNodeIds);
      next.add(id);
      return { ui: { ...s.ui, selectedNodeIds: next } };
    }),
  deselectNode: (id) =>
    set((s) => {
      const next = new Set(s.ui.selectedNodeIds);
      next.delete(id);
      return { ui: { ...s.ui, selectedNodeIds: next } };
    }),
  clearSelection: () =>
    set((s) => ({ ui: { ...s.ui, selectedNodeIds: new Set(), selectedClusterId: null } })),
  togglePanel: (panel) =>
    set((s) => ({
      ui: {
        ...s.ui,
        panelVisibility: {
          ...s.ui.panelVisibility,
          [panel]: !s.ui.panelVisibility[panel],
        },
      },
    })),

  // ── Graph State ──
  graph: {
    nodes: [],
    edges: [],
    viewport: { x: 0, y: 0, zoom: 1 },
    layoutVersion: 0,
    hiddenIds: new Set(),
    suggestedLinkIds: new Set(),
  },
  setNodes: (nodes) =>
    set((s) => ({ graph: { ...s.graph, nodes } })),
  setEdges: (edges) =>
    set((s) => ({ graph: { ...s.graph, edges } })),
  setViewport: (viewport) =>
    set((s) => ({ graph: { ...s.graph, viewport: { ...s.graph.viewport, ...viewport } } })),
  bumpLayoutVersion: () =>
    set((s) => ({ graph: { ...s.graph, layoutVersion: s.graph.layoutVersion + 1 } })),

  // ── Sync State ──
  sync: {
    loading: false,
    stale: false,
    syncing: false,
    error: null,
    lastRefreshedAt: null,
  },
  setSyncState: (patch) =>
    set((s) => ({ sync: { ...s.sync, ...patch } })),
}));
