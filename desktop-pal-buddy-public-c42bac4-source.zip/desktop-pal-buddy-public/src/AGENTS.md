# Renderer Guide

This guide adds renderer-specific rules to the repository guide. Paths below are relative to `src/` unless prefixed with `../`.
Workspace behavior, shared UI primitives, and Agentic domain rules belong in their respective child guides.

## Startup and Navigation

- Follow `main.tsx` → `App.tsx` → `pages/Index.tsx` when changing startup: theme deferral, application providers/routes, then the landing/desktop shell.
- `App.tsx` owns the shared QueryClient, toast and tooltip providers, and lazy routes. Keep new URL routes above the catch-all.
- Workspace modes are internal state in `components/workspace/WorkspaceLayout.tsx`, with launch context supplied through `hooks/useShellController.ts`; they are not individual React Router routes.
- `pages/Index.tsx` reads `?workspace=` as an initial preview launch and query flags for canvas debugging. Do not treat those parameters as continuously synchronized workspace state.
- Keep browser and Electron shell transitions in the shell hooks; consult the workspace guide for mode-specific navigation.

## Types and Styling

- `@/` resolves to this directory in Vite and `../tsconfig.app.json`; use it for cross-directory renderer imports.
- The app compiler enables `strict`, `noImplicitAny`, `noUnusedLocals`, and `noUnusedParameters`. Preserve typed provider boundaries and remove unused imports rather than weakening compiler options.
- `index.css` is imported by `main.tsx` and defines dark `:root`, `.light`, semantic status/agent colors, glass surfaces, and root background behavior.
- Use the existing semantic tokens for shared colors and surfaces. Keep light/dark token counterparts aligned when adding a shared token.
- `App.css` contains unused Vite starter styling. Importing it would constrain `#root` with padding and a maximum width; do not use it as the application stylesheet.
- Boot background locking and deferred theme application span `main.tsx`, `pages/Index.tsx`, and shell background cleanup. Preserve the boot and transparent Electron dock behavior when adjusting global CSS.

## Runtime and Service Boundaries

- Resolve `demo`, `staging`, and `production` through `lib/runtimeMode.ts`; do not invent component-local mode checks.
- Mode resolution reads `VITE_APP_MODE`, then `VITE_RUNTIME_MODE`; the legacy fallback is production only when `VITE_DEMO_MODE === "false"`, otherwise demo.
- `lib/streamChat.ts`, `lib/dataQueryProvider.ts`, and `lib/marketplaceProvider.ts` select demo or service implementations from that resolved mode. Preserve their public contracts when changing transport behavior.
- `integrations/supabase/client.ts` uses `integrations/supabase/demoClient.ts` both for demo mode and as a compatibility fallback when Supabase configuration is missing. That fallback does not turn staging/production into explicit demo mode.
- Strategy fixtures are enabled only by `includeStrategyFixtures: DEMO_MODE`; keep missing configuration distinct from intentional demo fixtures.
- A service provider or a "Live" connection label does not prove working AI execution. The current `../supabase/functions/chat/index.ts` and `../supabase/functions/data-query/index.ts` execution paths return 501 for the disabled Codex bridge after their guards.
- Treat `integrations/supabase/types.ts` as generated database schema output. Change the schema/generation source instead of hand-editing its declarations.

## Hooks and Canvas

- Effects that register DOM/Electron events, timers, or subscriptions must release them on dependency changes and unmount. `hooks/useElectronShellSync.ts` also guards delayed responses and restores prior document backgrounds.
- Follow the existing cleanup patterns in `hooks/useCurrentTime.ts`, `hooks/use-mobile.tsx`, and `hooks/useElectronShellSync.ts`; keep cleanup coupled to the effect that acquires the resource.
- Canvas database reads and row-to-UI mapping belong in `hooks/useCanvasData.ts`; `stores/canvasStore.ts` owns UI, graph, and sync state.
- `components/canvas/UnifiedCanvas.tsx` starts data loading after boot, while `components/canvas/KnowledgeLayer.tsx` consumes graph state for rendering. Keep service calls out of rendering/animation loops.
- Preserve deterministic node layout and the store's immutable selection updates when extending graph behavior.

## Focused Verification

- Runtime/provider tests sit beside their modules: `lib/runtimeMode.test.ts`, `lib/streamChat.test.ts`, `lib/dataQueryProvider.test.ts`, and `lib/marketplaceProvider.test.ts`.
- Client/fixture boundaries are covered by `integrations/supabase/client.test.ts` and `integrations/supabase/demoClient.test.ts`; include staging/production without configuration when changing fallback behavior.
- Shell and boot tests live in `hooks/*.test.ts`; canvas checks live in `components/canvas/UnifiedCanvas.test.ts`. Workspace and domain suites are described by their child guides.
- `test/setup.ts` supplies jest-dom matchers and a `matchMedia` stub. Extend a local test's browser mocks when its behavior requires more than that stub.
- From the repository root, a focused runtime check is `npm test -- src/lib/runtimeMode.test.ts src/integrations/supabase/client.test.ts`.
