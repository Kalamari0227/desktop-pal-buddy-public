import { describe, expect, it } from "vitest";
import { createChatProvider, streamChat, type Msg } from "./streamChat";

async function collectDemoResponse(messages: Msg[]) {
  let text = "";
  await streamChat({
    messages,
    onDelta: (chunk) => {
      text += chunk;
    },
    onDone: () => undefined,
  });
  return text;
}

describe("streamChat demo responses", () => {
  it("selects the demo provider in demo runtime mode", () => {
    expect(createChatProvider("demo").mode).toBe("demo");
  });

  it("returns the market-analysis flow for the market dock agent", async () => {
    const response = await collectDemoResponse([
      {
        role: "user",
        content: "시장 분석 스테이션을 열어줘. 자동차 강판 시장 신호, 고객사 움직임, 가격/수요 흐름을 분석해줘.",
      },
    ]);

    expect(response).toContain("시장 분석 스테이션입니다");
    expect(response).toContain("시장 신호");
    expect(response).toContain("고객사별 해석");
    expect(response).not.toContain("오늘의 자동차 강판 영업 브리핑입니다");
  });

  it("returns an email-reply recommendation flow for the draft dock action", async () => {
    const response = await collectDemoResponse([
      {
        role: "user",
        content: "회신 초안 스테이션을 열어줘. 내가 가진 메일 몇 개를 보고, 그중 이런 메일은 이렇게 답하면 좋겠다는 추천 답장 초안을 보여줘.",
      },
    ]);

    expect(response).toContain("회신 초안 스테이션입니다");
    expect(response).toContain("확인된 메일 후보");
    expect(response).toContain("현대자동차 구매팀");
    expect(response).toContain("이렇게 답하면 좋을 것 같습니다");
    expect(response).not.toContain("Prometheus 데모 응답입니다");
  });

  it("returns a document-station recommendation flow for the dock documents menu", async () => {
    const response = await collectDemoResponse([
      {
        role: "user",
        content:
          "문서 스테이션을 열어줘. 내가 어떤 글을 찾고 있는지 물어보고, 이런 문서를 원한 것 아니냐는 추천 후보를 보여줘.",
      },
    ]);

    expect(response).toContain("문서 스테이션입니다");
    expect(response).toContain("어떤 글을 찾고 계신가요?");
    expect(response).toContain("혹시 이런 글을 원하신 건가요?");
    expect(response).toContain("현대자동차 GA 강판 품질 재검 브리핑");
    expect(response).not.toContain("오늘의 자동차 강판 영업 브리핑입니다");
    expect(response).not.toContain("시장 분석 에이전트 관점");
  });
});
