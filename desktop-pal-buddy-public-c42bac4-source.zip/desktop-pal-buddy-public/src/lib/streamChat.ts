import { supabase } from "@/integrations/supabase/client";
import { type AppRuntimeMode, resolveAppRuntimeMode } from "./runtimeMode";

export type Msg = { role: "user" | "assistant"; content: string };

export type ChatStreamInput = {
  messages: Msg[];
  onDelta: (deltaText: string) => void;
  onDone: () => void;
  onError?: (error: string) => void;
};

export interface ChatProvider {
  mode: AppRuntimeMode;
  stream(input: ChatStreamInput): Promise<void>;
}

const DEMO_CONTEXT = {
  headline: "현대자동차 GA 강판 품질 재검 및 출하 일정 조정",
  risks: [
    "현대자동차: GA 강판 품질 재검 + 3월 납기 2주 지연 가능성",
    "기아: 신규 모델 강판 사양 확정 지연 + 2분기 가격 재협상 압박",
    "Toyota: 수출 강판 JIS 규격 확인 및 재발 방지 브리핑 필요",
    "GM Korea: DP780 공급 확대 요청 대비 생산 여력 확인 필요",
  ],
};

const DEMO_RESPONSES = [
  {
    keywords: ["시장 분석 스테이션", "시장 분석", "시장", "수요", "원자재", "market"],
    response: `시장 분석 스테이션입니다. 공개 데모에서는 실제 외부 데이터를 조회하지 않고, 자동차 강판 영업 맥락에 맞춘 **하드코딩 시장 분석 흐름**을 보여드립니다.

## 시장 신호
- **수요**: EV 신규 모델과 고장력강 사양 협의가 늘어나는 흐름입니다.
- **가격**: 고객사는 단가 인하를 요구하지만, 품질/납기 안정성 프리미엄은 여전히 협상 카드입니다.
- **공급**: 열연 라인 정비와 품질 재검 이슈가 단기 공급 안정성에 영향을 줄 수 있습니다.
- **수출**: Toyota 계열 수출 건은 JIS 규격 증빙과 시험 성적서 완성도가 핵심입니다.

## 고객사별 해석
1. **현대자동차**
   - 품질 재검 이슈가 가격 협상 신뢰도에도 영향을 줄 수 있어 선제 브리핑이 필요합니다.
2. **기아**
   - 2분기 가격 재협상 압박이 예상되므로 원가·납기·품질을 묶은 방어 논리가 좋습니다.
3. **GM Korea**
   - DP780 공급 확대 요청은 기회지만 생산 여력 확인이 먼저입니다.

## 추천 액션
- 오늘은 현대자동차 품질/납기 리스크를 먼저 진정시키고, 기아 가격 협상 자료를 이어서 준비하세요.

_데모 모드: 실제 시장 데이터/API 호출 없이 시장 분석 UX만 시연합니다._`,
  },
  {
    keywords: ["회신 초안 스테이션", "회신 초안", "답장", "메일", "이메일", "reply"],
    response: `회신 초안 스테이션입니다. 지금은 실제 메일함을 읽지 않고, **가지고 있는 메일 몇 개를 훑어본 뒤 어떤 메일에 어떻게 답하면 좋을지 추천하는 데모**로 보여드릴게요.

## 확인된 메일 후보
1. **현대자동차 구매팀 — “GA 강판 출하 일정 확인 요청”**
   - 의도: 3월 납기 영향과 대체 출하 가능일 확인
   - 추천 답변 방향: 지연 가능성을 먼저 말하기보다 **대체 출하 캘린더 + 우선 배정 물량**을 제시

2. **기아 구매팀 — “2분기 단가 조정 재협의”**
   - 의도: 경쟁사 가격 인하를 근거로 단가 인하 요구
   - 추천 답변 방향: 단순 거절보다 **원가 변동, 품질 안정성, 물량 조건별 견적안**으로 분리 대응

3. **Toyota 품질 담당 — “JIS 규격 증빙 자료 요청”**
   - 의도: 수출 강판 출하 전 시험 성적서와 규격 적합성 확인
   - 추천 답변 방향: 시험 성적서, LOT 정보, 출하 전 승인 절차를 묶어 전달

## 이렇게 답하면 좋을 것 같습니다
**현대자동차 건 우선 답장 초안**

안녕하세요. 요청 주신 GA 강판 출하 일정 관련해 현재 품질 재검과 출하 가능 일정을 함께 확인 중입니다.  
우선 고객사 생산 일정에 영향이 최소화되도록 대체 출하 캘린더와 우선 배정 가능 물량을 정리해 금일 중 공유드리겠습니다.  
재검 완료 LOT부터 순차 출하하는 안과, 필요 시 일부 물량 선배정 가능 여부도 함께 검토하겠습니다.

## 다음으로 고를 수 있는 액션
- “기아 단가 조정 메일 답장도 보여줘”
- “Toyota 규격 증빙 요청 답장으로 바꿔줘”
- “더 짧고 공식적인 톤으로 줄여줘”

_공개 데모 모드: 실제 Gmail/메일 API를 호출하지 않고 회신 추천 UX만 하드코딩으로 시연합니다._`,
  },
  {
    keywords: ["납기", "지연", "delivery"],
    response: `현재 데모 데이터 기준 납기 리스크 1순위는 **현대자동차 GA 강판 출하 일정**입니다.

## 판단
- 위험도: 높음
- 예상 영향: 약 1,200톤 출하 일정 조정 가능성
- 원인: 열연 라인 정비 + 품질 재검 대기

## 권장 액션
1. 현대자동차에는 “지연 가능성”보다 **대체 출하 캘린더**를 먼저 제시합니다.
2. 품질팀에는 재검 완료 시점과 LOT별 검사 결과를 요청합니다.
3. 영업팀은 보상 옵션보다 **우선 배정 물량**을 먼저 협의하는 편이 좋습니다.

_데모 모드: 실제 LLM/API/DB 호출 없이 에이전트 대화 흐름만 시연합니다._`,
  },
  {
    keywords: ["가격", "단가", "마진", "price"],
    response: `가격/마진 관점에서는 **기아 신규 모델 강판 사양 협의**가 우선입니다.

## 핵심 쟁점
- 기아 구매팀이 2분기 3% 인하를 재요구하는 시나리오입니다.
- 경쟁사 가격 인하 언급 때문에 방어 논리가 필요합니다.
- 원자재가 변동분과 공급 안정성 프리미엄을 분리해서 설명해야 합니다.

## 추천 회신 구조
1. 원가 변동 근거
2. 품질/납기 안정성 가치
3. 물량 조건별 3단계 견적안

_데모 모드 응답입니다._`,
  },
  {
    keywords: ["품질", "불량", "qa", "quality"],
    response: `품질 이슈는 **현대자동차 GA 강판 표면 품질**과 **Toyota JIS 규격 확인**을 분리해서 봐야 합니다.

## 현대자동차
- 표면 결함률이 기준을 초과한 시나리오입니다.
- 고객 커뮤니케이션은 “재검 중”보다 **LOT별 차단/출하 기준** 중심이 안전합니다.

## Toyota
- 수출 강판은 규격 증빙과 재발 방지 문서가 핵심입니다.
- 시험 성적서, 검사 LOT, 출하 전 승인 절차를 한 묶음으로 제시하세요.

_외부 공유용 데모라 실제 고객 데이터는 조회하지 않습니다._`,
  },
  {
    keywords: ["회의", "미팅", "브리핑", "meeting", "오늘", "브리핑"],
    response: `오늘의 자동차 강판 영업 브리핑입니다.

## 1. 우선 확인할 리스크
- ${DEMO_CONTEXT.risks[0]}
- ${DEMO_CONTEXT.risks[1]}

## 2. 고객별 접근
- **현대자동차**: 품질 재검 결과 + 대체 출하 일정 제시
- **기아**: 가격 방어 근거와 신규 모델 사양 확정 일정 정리
- **Toyota**: JIS 규격 확인 자료와 재발 방지 브리핑 준비

## 3. 다음 액션
- 오전: 품질팀 LOT별 재검 결과 확인
- 오후: 현대자동차/기아 회신 초안 작성
- 퇴근 전: 리스크 카드 업데이트

_데모 모드: 실제 LLM 대신 하드코딩된 에이전트 응답을 스트리밍처럼 보여줍니다._`,
  },
  {
    keywords: ["문서 스테이션", "문서 탐색", "문서", "회의록", "찾", "검색", "docs", "document"],
    response: `문서 스테이션입니다. 지금은 실제 저장소를 뒤지는 대신, **찾으려는 글을 먼저 좁히고 추천 후보를 제안하는 데모 흐름**으로 보여드릴게요.

## 어떤 글을 찾고 계신가요?
- 고객사 미팅 전에 볼 **요약 브리핑**인가요?
- 품질/납기 이슈를 설명할 **근거 문서**인가요?
- 가격 협상 전에 필요한 **회신 초안/메일 근거**인가요?
- 내부 보고용 **리스크 정리 글**인가요?

## 혹시 이런 글을 원하신 건가요?
1. **현대자동차 GA 강판 품질 재검 브리핑**
   - 표면 결함률, LOT 차단 기준, 재검 완료 예상 시점을 1페이지로 정리한 글
2. **3월 납기 지연 가능성 고객 안내 초안**
   - “지연 통보”가 아니라 대체 출하 캘린더와 우선 배정안을 제시하는 문서
3. **기아 2분기 가격 협상 대응 메모**
   - 원자재가, 공급 안정성, 경쟁사 가격 언급에 대한 방어 논리 정리
4. **Toyota JIS 규격 증빙 체크리스트**
   - 수출 강판 규격 확인, 시험 성적서, 출하 전 승인 절차 점검용

## 다음 입력 예시
- “현대차 품질 이슈 고객 안내문 찾아줘”
- “가격 협상용 근거 글 추천해줘”
- “납기 지연 설명 메일 초안 보여줘”

_공개 데모 모드: 실제 문서 저장소/API를 호출하지 않고, 문서 탐색 UX만 하드코딩으로 시연합니다._`,
  },

  {
    keywords: ["리스크", "위험", "risk", "감지"],
    response: `리스크 감지 에이전트 결과입니다.

## Top 3 리스크
1. **현대자동차 품질/납기 복합 리스크**
   - 품질 재검과 출하 일정이 연결되어 고객 신뢰 이슈로 번질 수 있습니다.
2. **기아 가격 재협상 리스크**
   - 경쟁사 가격 인하 언급으로 단가 방어 논리가 필요합니다.
3. **Toyota 규격 증빙 리스크**
   - 수출 강판은 문서 누락이 출하 지연으로 이어질 수 있습니다.

## 제안
- 오늘은 현대자동차 건을 먼저 닫고, 기아 가격 회신 초안을 다음으로 준비하세요.

_공개 데모용 하드코딩 응답입니다._`,
  },
];

function pickDemoResponse(messages: Msg[]) {
  const lastUser = [...messages].reverse().find((m) => m.role === "user")?.content || "";
  const normalized = lastUser.toLowerCase();
  const matched = DEMO_RESPONSES.find((item) =>
    item.keywords.some((keyword) => normalized.includes(keyword.toLowerCase()))
  );

  return matched?.response || `Prometheus 데모 응답입니다.

제가 지금 보고 있는 데모 업무 맥락은 다음과 같습니다.

## 현재 상황
- 핵심 이슈: **${DEMO_CONTEXT.headline}**
- 주요 고객: 현대자동차, 기아, Toyota, GM Korea
- 업무 축: 납기, 품질, 가격, 문서 브리핑

## 다음으로 할 수 있는 일
- “현대자동차 납기 리스크 알려줘”
- “기아 가격 회신 초안 작성해줘”
- “오늘 브리핑 정리해줘”
- “관련 문서 찾아줘”

현재 외부 공유용 데모에서는 실제 LLM/API/Supabase를 호출하지 않고, 에이전트 대화 UX를 하드코딩 응답으로 시연합니다.`;
}

async function streamText(text: string, onDelta: (deltaText: string) => void) {
  const chunks = text.match(/.{1,20}(?:\s|$)/g) || [text];
  for (const chunk of chunks) {
    onDelta(chunk);
    await new Promise((resolve) => setTimeout(resolve, 16));
  }
}

export class DemoChatProvider implements ChatProvider {
  mode = "demo" as const;

  async stream({ messages, onDelta, onDone }: ChatStreamInput) {
    await streamText(pickDemoResponse(messages), onDelta);
    onDone();
  }
}

async function defaultEdgeChatTransport(messages: Msg[]) {
  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
  const publishableKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
  if (!supabaseUrl || !publishableKey) {
    throw new Error("Supabase Edge Function 설정이 필요합니다.");
  }

  const { data } = await supabase.auth.getSession();
  const accessToken = data.session?.access_token;
  if (!accessToken) {
    throw new Error("실서비스 채팅을 사용하려면 로그인이 필요합니다.");
  }

  return fetch(`${supabaseUrl}/functions/v1/chat`, {
    method: "POST",
    headers: {
      apikey: publishableKey,
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ messages }),
  });
}

export class EdgeChatProvider implements ChatProvider {
  mode: AppRuntimeMode;

  constructor(
    mode: Exclude<AppRuntimeMode, "demo">,
    private readonly transport: (messages: Msg[]) => Promise<Response> = defaultEdgeChatTransport
  ) {
    this.mode = mode;
  }

  async stream({ messages, onDelta, onDone, onError }: ChatStreamInput) {
    const response = await this.transport(messages);
    if (!response.ok) {
      const errorBody = await response.json().catch(() => null);
      const message = typeof errorBody?.error === "string" ? errorBody.error : "AI 응답을 가져오지 못했습니다.";
      onError?.(message);
      throw new Error(message);
    }

    const reader = response.body?.getReader();
    if (!reader) throw new Error("스트리밍 응답을 읽을 수 없습니다.");

    const decoder = new TextDecoder();
    let buffer = "";
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      let lineBreak: number;
      while ((lineBreak = buffer.indexOf("\n")) !== -1) {
        const line = buffer.slice(0, lineBreak).trim();
        buffer = buffer.slice(lineBreak + 1);
        if (!line.startsWith("data: ")) continue;

        const payload = line.slice(6).trim();
        if (payload === "[DONE]") {
          onDone();
          return;
        }

        try {
          const parsed = JSON.parse(payload);
          const content = parsed.choices?.[0]?.delta?.content ?? parsed.content ?? parsed.delta;
          if (typeof content === "string") onDelta(content);
        } catch {
          // Ignore non-JSON heartbeat lines from upstream SSE.
        }
      }
    }

    onDone();
  }
}

export function createChatProvider(mode: AppRuntimeMode = resolveAppRuntimeMode()): ChatProvider {
  return mode === "demo" ? new DemoChatProvider() : new EdgeChatProvider(mode);
}

export async function streamChat(input: ChatStreamInput) {
  await createChatProvider().stream(input);
}
