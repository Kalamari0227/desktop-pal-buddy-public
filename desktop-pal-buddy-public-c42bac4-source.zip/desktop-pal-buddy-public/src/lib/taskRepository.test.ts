import { describe, expect, it, vi } from "vitest";
import { createProductionPriorityChangePacket } from "./company-runtime";
import {
  createTaskRepository,
  LEGACY_MUTATION_KINDS,
  StaleTaskLoadError,
  type LegacyMutationKind,
} from "./taskRepository";
import type { CompanyRuntimeClient, CompanyRuntimeResponse } from "./companyRuntimeClient";
import type { LegacyTaskRecord } from "./company-runtime/projection";

const runtimeId = "9e650d6d-9e9f-4a09-b041-e345d16620a8";
const legacyId = "d9dc4250-556d-4ce3-b274-e95bc4357591";
const packetId = "27862353-b4b6-43d3-bec2-2e4afe57dc06";
const epoch = "f7091d6f-e310-46f5-ae2f-a761f136f36a";

function response(tasks = [runtimeTask()]): CompanyRuntimeResponse {
  return {
    schemaVersion: 1,
    requestId: crypto.randomUUID(),
    epoch,
    actorSessionRevision: 0,
    ok: true,
    payload: { snapshot: { currentEpoch: epoch, records: { tasks } } },
  };
}

function runtimeTask() {
  return {
    workboardTaskId: runtimeId,
    packetTaskId: packetId,
    epoch,
    packet: createProductionPriorityChangePacket({
      packetTaskId: packetId,
      createdAt: "2026-09-19T00:00:00.000Z",
      requesterActorId: "sales-demo",
      strategyRef: {
        strategy_id: "STRATEGY-DEMO-PRODUCTION",
        strategy_version_id: "f6846f3d-1aa0-487a-88a1-c383ba9076ea",
      },
    }),
    status: "pending",
    currentProposal: null,
    currentApprovalId: null,
    executionId: null,
    businessOutcome: {
      packetTaskId: packetId,
      status: "unobserved",
      recordedByActorId: null,
      evidenceRefs: [],
      observedAt: null,
    },
  };
}

function legacyTask(id: string): LegacyTaskRecord {
  return {
    id,
    title: `Legacy ${id}`,
    description: null,
    source: "legacy",
    source_id: null,
    severity: "medium",
    customer: null,
    category: null,
    status: "pending",
    created_at: "2026-09-19T00:00:00.000Z",
  };
}

function runtimeClient(read: () => Promise<CompanyRuntimeResponse>): CompanyRuntimeClient {
  const unavailable = vi.fn(async () => response());
  return {
    bootstrap: vi.fn(async () => response()),
    read,
    subscribe: vi.fn(() => vi.fn()),
    submit: unavailable,
    approve: unavailable,
    execute: unavailable,
    role: unavailable,
    stop: unavailable,
    resume: unavailable,
    reset: unavailable,
    cancel: unavailable,
    reconcile: unavailable,
    getContext: () => ({ epoch, actorSessionRevision: 0 }),
  };
}

describe("task repository ownership boundary", () => {
  it.each(LEGACY_MUTATION_KINDS)("blocks %s for a main-owned runtime ID before calling legacy storage", async (kind) => {
    // Given
    const legacyMutation = vi.fn(async () => "mutated");
    const repository = createTaskRepository({
      loadLegacyTasks: vi.fn(async () => []),
      runtimeClient: runtimeClient(vi.fn(async () => response())),
    });

    // When
    const result = await repository.mutateLegacy({
      kind,
      origin: "company_runtime",
      sourceId: runtimeId,
      viewKey: `company_runtime:${runtimeId}`,
      mutate: legacyMutation,
    });

    // Then
    expect(result).toEqual({ ok: false, reason: "runtime_owned" });
    expect(legacyMutation).not.toHaveBeenCalled();
  });

  it.each(LEGACY_MUTATION_KINDS)("routes %s for an authoritative non-runtime ID to legacy storage", async (kind: LegacyMutationKind) => {
    // Given
    const legacyMutation = vi.fn(async () => kind);
    const repository = createTaskRepository({
      loadLegacyTasks: vi.fn(async () => [legacyTask(legacyId)]),
      runtimeClient: runtimeClient(vi.fn(async () => response())),
    });

    // When
    const result = await repository.mutateLegacy({
      kind,
      origin: "legacy",
      sourceId: legacyId,
      viewKey: `legacy:${legacyId}`,
      mutate: legacyMutation,
    });

    // Then
    expect(result).toEqual({ ok: true, value: kind });
    expect(legacyMutation).toHaveBeenCalledTimes(1);
  });

  it.each(LEGACY_MUTATION_KINDS)(
    "routes %s for a legacy origin even when a runtime task has the same source ID",
    async (kind: LegacyMutationKind) => {
      // Given
      const legacyMutation = vi.fn(async () => kind);
      const repository = createTaskRepository({
        loadLegacyTasks: vi.fn(async () => [legacyTask(runtimeId)]),
        runtimeClient: runtimeClient(vi.fn(async () => response())),
      });

      // When
      const result = await repository.mutateLegacy({
        kind,
        origin: "legacy",
        sourceId: runtimeId,
        viewKey: `legacy:${runtimeId}`,
        mutate: legacyMutation,
      });

      // Then
      expect(result).toEqual({ ok: true, value: kind });
      expect(legacyMutation).toHaveBeenCalledTimes(1);
    },
  );

  it.each(LEGACY_MUTATION_KINDS)(
    "blocks %s when a runtime-only ID is forged as a legacy origin",
    async (kind: LegacyMutationKind) => {
      // Given
      const legacyMutation = vi.fn(async () => kind);
      const repository = createTaskRepository({
        loadLegacyTasks: vi.fn(async () => []),
        runtimeClient: runtimeClient(vi.fn(async () => response())),
      });

      // When
      const result = await repository.mutateLegacy({
        kind,
        origin: "legacy",
        sourceId: runtimeId,
        viewKey: `legacy:${runtimeId}`,
        mutate: legacyMutation,
      });

      // Then
      expect(result).toEqual({ ok: false, reason: "runtime_owned" });
      expect(legacyMutation).not.toHaveBeenCalled();
    },
  );

  it.each(LEGACY_MUTATION_KINDS)(
    "blocks %s for a runtime origin when a legacy task has the same source ID",
    async (kind: LegacyMutationKind) => {
      // Given
      const legacyMutation = vi.fn(async () => kind);
      const repository = createTaskRepository({
        loadLegacyTasks: vi.fn(async () => []),
        runtimeClient: runtimeClient(vi.fn(async () => response())),
      });

      // When
      const result = await repository.mutateLegacy({
        kind,
        origin: "company_runtime",
        sourceId: runtimeId,
        viewKey: `company_runtime:${runtimeId}`,
        mutate: legacyMutation,
      });

      // Then
      expect(result).toEqual({ ok: false, reason: "runtime_owned" });
      expect(legacyMutation).not.toHaveBeenCalled();
    },
  );

  it("fails closed when the origin and view key identify different owners", async () => {
    // Given
    const mutation = vi.fn(async () => "mutated");
    const repository = createTaskRepository({
      loadLegacyTasks: vi.fn(async () => []),
      runtimeClient: runtimeClient(vi.fn(async () => response())),
    });

    // When
    const result = await repository.mutateLegacy({
      kind: "edit",
      origin: "legacy",
      sourceId: runtimeId,
      viewKey: `company_runtime:${runtimeId}`,
      mutate: mutation,
    });

    // Then
    expect(result).toEqual({ ok: false, reason: "runtime_unavailable" });
    expect(mutation).not.toHaveBeenCalled();
  });

  it("fails closed when neither authoritative source contains a claimed legacy task", async () => {
    // Given
    const unknownId = "95f32498-3498-4b4d-9f13-a81705607038";
    const mutation = vi.fn(async () => "mutated");
    const repository = createTaskRepository({
      loadLegacyTasks: vi.fn(async () => []),
      runtimeClient: runtimeClient(vi.fn(async () => response([]))),
    });

    // When
    const result = await repository.mutateLegacy({
      kind: "edit",
      origin: "legacy",
      sourceId: unknownId,
      viewKey: `legacy:${unknownId}`,
      mutate: mutation,
    });

    // Then
    expect(result).toEqual({ ok: false, reason: "runtime_unavailable" });
    expect(mutation).not.toHaveBeenCalled();
  });

  it("fails closed when an authoritative runtime read is unavailable", async () => {
    // Given
    const unavailable: CompanyRuntimeResponse = {
      schemaVersion: 1,
      requestId: crypto.randomUUID(),
      epoch: null,
      actorSessionRevision: null,
      ok: false,
      error: { code: "unavailable", message: "desktop_runtime_unavailable" },
    };
    const read = vi.fn()
      .mockResolvedValueOnce(response())
      .mockResolvedValueOnce(unavailable);
    const mutation = vi.fn(async () => undefined);
    const repository = createTaskRepository({
      loadLegacyTasks: vi.fn(async () => []),
      runtimeClient: runtimeClient(read),
    });
    await repository.load();

    // When
    const result = await repository.mutateLegacy({
      kind: "delete",
      origin: "company_runtime",
      sourceId: runtimeId,
      viewKey: `company_runtime:${runtimeId}`,
      mutate: mutation,
    });

    // Then
    expect(result).toEqual({ ok: false, reason: "runtime_unavailable" });
    expect(mutation).not.toHaveBeenCalled();
  });

  it("discards an older task load that completes after a newer refresh", async () => {
    // Given
    let resolveFirst: ((tasks: readonly []) => void) | undefined;
    let resolveSecond: ((tasks: readonly []) => void) | undefined;
    const loadLegacyTasks = vi.fn()
      .mockImplementationOnce(() => new Promise<readonly []>((resolve) => { resolveFirst = resolve; }))
      .mockImplementationOnce(() => new Promise<readonly []>((resolve) => { resolveSecond = resolve; }));
    const repository = createTaskRepository({
      loadLegacyTasks,
      runtimeClient: runtimeClient(vi.fn(async () => response())),
    });
    const first = repository.load();
    const second = repository.load();

    // When
    resolveSecond?.([]);
    await expect(second).resolves.toMatchObject({ runtime: { state: "ready" } });
    resolveFirst?.([]);

    // Then
    await expect(first).rejects.toBeInstanceOf(StaleTaskLoadError);
  });
});
