import { describe, expect, it } from "vitest";
import {
  buildGatewayCodexPrompt,
  createGatewayCodexDraft,
  createStableTaskId,
} from "./gatewayCodexAgent";

describe("Gateway Codex agent", () => {
  it("builds an intake prompt that keeps Gateway Codex out of worker execution", () => {
    const prompt = buildGatewayCodexPrompt({
      raw_user_request: "PR #4 검증해줘",
      context_refs: [{ type: "github_pr", label: "PR #4", value: "4" }],
    });

    expect(prompt.system).toContain("not the worker executor");
    expect(prompt.system).toContain("do not run database migrations");
    expect(prompt.system).toContain("deterministic policy engine has final authority");
    expect(prompt.user).toContain("Return JSON");
    expect(prompt.user).toContain("[github_pr] PR #4: 4");
  });

  it("creates a manual-only PR verification draft and handoff", () => {
    const draft = createGatewayCodexDraft({
      raw_user_request: "PR #4 검증해줘",
      context_refs: [{ type: "github_pr", label: "PR #4", value: "4" }],
      created_at: "2026-07-03T00:00:00.000Z",
    });

    expect(draft).toMatchObject({
      agent_name: "Gateway Codex",
      bridge_status: "manual_only",
      suggestion: {
        task_type: "pr_verification",
        request_summary: "Verify the requested pull request and report readiness.",
      },
    });
    expect(draft.packet).toMatchObject({
      task_id: createStableTaskId("PR #4 검증해줘", "pr_verification"),
      task_type: "pr_verification",
      status: "queued",
      required_approval: false,
    });
    expect(draft.handoff_markdown).toContain("# Codex Task Packet");
    expect(draft.policy_notes).toContain("Gateway Codex is intake-only; worker execution remains manual in v0.");
  });

  it("creates business task drafts for inventory and urgent material workflows", () => {
    const urgentDraft = createGatewayCodexDraft({
      raw_user_request: "현대자동차 GA 강판 긴급재 위험도 따져줘",
      context_refs: [
        { type: "customer_account", label: "customer", value: "현대자동차" },
        { type: "material_item", label: "material", value: "GA 강판" },
      ],
    });

    expect(urgentDraft.packet).toMatchObject({
      task_type: "urgent_material_risk_assessment",
      risk_level: "medium",
      required_approval: false,
    });
    expect(urgentDraft.packet?.verification_requirements.map((requirement) => requirement.type)).toEqual([
      "inventory_status",
      "delivery_status",
      "risk_assessment",
    ]);

    const inventoryDraft = createGatewayCodexDraft({
      raw_user_request: "GA 강판 재고 확인해줘",
      context_refs: [{ type: "material_item", label: "material", value: "GA 강판" }],
    });

    expect(inventoryDraft.packet).toMatchObject({
      task_type: "inventory_check",
      risk_level: "medium",
    });
    expect(inventoryDraft.suggestion.request_summary).toBe("Check available inventory for the requested material and context.");
  });

  it("lets a supported Codex suggestion classify an otherwise ambiguous request", () => {
    const draft = createGatewayCodexDraft({
      raw_user_request: "이거 확인해줘",
      context_refs: [{ type: "github_pr", label: "PR #7", value: "7" }],
      codex_suggestion: {
        task_type: "pr_verification",
        request_summary: "Verify PR #7.",
        desired_outcome: "Return PR readiness.",
        reasoning_notes: ["The attached context is a GitHub PR."],
      },
    });

    expect(draft.bridge_status).toBe("manual_only");
    expect(draft.packet?.task_type).toBe("pr_verification");
    expect(draft.suggestion.reasoning_notes).toContain("The attached context is a GitHub PR.");
    expect(draft.policy_notes).toContain("The suggested task type was normalized by the policy engine.");
  });

  it("blocks unknown requests instead of creating a worker handoff", () => {
    const draft = createGatewayCodexDraft({
      raw_user_request: "오늘 뭐 하면 좋을까?",
    });

    expect(draft.bridge_status).toBe("needs_manual_review");
    expect(draft.packet).toBeNull();
    expect(draft.handoff_markdown).toBe("");
    expect(draft.blocked_reason).toBe("Unsupported or ambiguous task type.");
    expect(draft.policy_notes).toContain("No worker handoff is generated for unknown task types.");
  });

  it("forces approval gates even when a Codex suggestion sounds executable", () => {
    const draft = createGatewayCodexDraft({
      raw_user_request: "staging DB migration 실행해줘",
      codex_suggestion: {
        task_type: "supabase_staging_check",
        request_summary: "Run the staging migration now.",
        desired_outcome: "Migration is applied.",
        reasoning_notes: ["User asked for a migration."],
      },
    });

    expect(draft.packet).toMatchObject({
      task_type: "supabase_staging_check",
      risk_level: "high",
      required_approval: true,
      status: "waiting_for_approval",
      approval_reason: "Approval required for: database_migration",
    });
    expect(draft.packet?.forbidden_actions).toContain("do not perform database_migration without explicit approval");
    expect(draft.policy_notes).toContain("Approval-required work is locked to read-only preflight until explicit approval is scoped.");
  });

  it("drops empty context refs before packet creation", () => {
    const draft = createGatewayCodexDraft({
      raw_user_request: "Supabase staging 상태 확인해줘",
      context_refs: [
        { type: "supabase_project", label: "staging", value: "project-ref" },
        { type: "user_note", label: "", value: "missing label" },
      ],
    });

    expect(draft.packet?.context_refs).toEqual([
      { type: "supabase_project", label: "staging", value: "project-ref" },
    ]);
  });
});
