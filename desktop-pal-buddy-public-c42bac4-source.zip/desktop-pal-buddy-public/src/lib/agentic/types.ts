export const TASK_TYPES = [
  "pr_verification",
  "supabase_staging_check",
  "document_to_prd",
  "inventory_check",
  "urgent_material_risk_assessment",
  "delivery_delay_risk_check",
  "business_risk_review",
  "customer_reply_draft",
  "order_status_check",
  "material_substitution_review",
  "production_priority_change",
  "production_readiness_review",
  "repo_doc_update",
  "general_research",
  "unknown",
] as const;

export const CONTEXT_REF_TYPES = [
  "github_repo",
  "github_pr",
  "github_commit",
  "supabase_project",
  "uploaded_file",
  "repo_file",
  "external_link",
  "user_note",
  "customer_account",
  "material_item",
  "warehouse",
  "sales_order",
  "due_date",
] as const;

export const RISK_LEVELS = ["low", "medium", "high", "blocked"] as const;

export const TASK_STATUSES = [
  "queued",
  "triaging",
  "waiting_for_approval",
  "running",
  "blocked",
  "verifying",
  "completed",
  "failed",
  "archived",
] as const;

export const VERIFICATION_TYPES = [
  "test",
  "lint",
  "typecheck",
  "build",
  "ci_status",
  "diff_review",
  "supabase_status",
  "manual_review",
  "document_created",
  "inventory_status",
  "order_status",
  "delivery_status",
  "risk_assessment",
  "reply_draft",
  "substitution_review",
  "production_state",
] as const;

export const REPORT_DETAIL_LEVELS = ["brief", "standard", "full"] as const;

export const WORKER_OUTCOMES = [
  "passed",
  "passed_with_warnings",
  "blocked",
  "failed",
  "advisory_only",
] as const;

export const BLOCKER_TYPES = [
  "missing_context",
  "missing_credentials",
  "approval_required",
  "tool_unavailable",
  "verification_failed",
  "ambiguous_request",
  "policy_blocked",
] as const;

export const RETENTION_SAVE_DECISIONS = [
  "memory",
  "skill",
  "docs_or_wiki",
  "workboard",
  "artifact_or_log",
  "no_save",
] as const;

export const EVIDENCE_TYPES = [
  "command_output",
  "test_result",
  "ci_status",
  "github_pr",
  "github_commit",
  "file_diff",
  "supabase_project_status",
  "supabase_migration_status",
  "edge_function_status",
  "advisor_result",
  "generated_document",
  "manual_observation",
  "inventory_snapshot",
  "order_status",
  "delivery_schedule",
  "risk_assessment",
  "generated_reply",
  "substitution_option",
  "production_state",
] as const;

export const EVIDENCE_SOURCE_SYSTEMS = [
  "github",
  "supabase",
  "local_shell",
  "repo",
  "gateway",
  "codex_worker",
  "user",
  "erp",
  "crm",
  "spreadsheet",
] as const;

export const EVIDENCE_STATUSES = ["passed", "failed", "warning", "info"] as const;

export const WORKER_EVENT_TYPES = [
  "accepted",
  "plan_created",
  "approval_required",
  "started",
  "progress",
  "evidence_added",
  "blocked",
  "verification_started",
  "verification_passed",
  "verification_failed",
  "completed",
  "failed",
] as const;

export const EVENT_SEVERITIES = ["info", "warning", "error"] as const;

export const APPROVAL_ACTION_TYPES = [
  "external_message",
  "file_delete_or_move",
  "production_deploy",
  "database_migration",
  "service_restart",
  "oauth_or_gateway_config_change",
  "paid_resource_creation",
  "secret_create_or_store",
  "permission_change",
] as const;

export type TaskType = (typeof TASK_TYPES)[number];
export type ContextRefType = (typeof CONTEXT_REF_TYPES)[number];
export type RiskLevel = (typeof RISK_LEVELS)[number];
export type TaskStatus = (typeof TASK_STATUSES)[number];
export type VerificationType = (typeof VERIFICATION_TYPES)[number];
export type ReportDetailLevel = (typeof REPORT_DETAIL_LEVELS)[number];
export type WorkerOutcome = (typeof WORKER_OUTCOMES)[number];
export type BlockerType = (typeof BLOCKER_TYPES)[number];
export type RetentionSaveDecision = (typeof RETENTION_SAVE_DECISIONS)[number];
export type EvidenceType = (typeof EVIDENCE_TYPES)[number];
export type EvidenceSourceSystem = (typeof EVIDENCE_SOURCE_SYSTEMS)[number];
export type EvidenceStatus = (typeof EVIDENCE_STATUSES)[number];
export type WorkerEventType = (typeof WORKER_EVENT_TYPES)[number];
export type EventSeverity = (typeof EVENT_SEVERITIES)[number];
export type ApprovalActionType = (typeof APPROVAL_ACTION_TYPES)[number];

export interface ContextRef {
  type: ContextRefType;
  label: string;
  value: string;
}

export interface ExecutionStep {
  step_id: string;
  summary: string;
  expected_evidence?: string;
}

export interface VerificationRequirement {
  type: VerificationType;
  required: boolean;
  command_or_source?: string;
}

export interface ReportFormat {
  include_summary: boolean;
  include_evidence: boolean;
  include_blockers: boolean;
  include_next_action: boolean;
  max_detail_level: ReportDetailLevel;
}

export interface Blocker {
  blocker_id: string;
  type: BlockerType;
  summary: string;
  requires_user_action: boolean;
  suggested_resolution?: string;
}

export interface WorkerResult {
  outcome: WorkerOutcome;
  summary: string;
  details?: string;
  changed_paths?: string[];
  checked_refs?: ContextRef[];
  risks?: string[];
}

export interface RetentionDecision {
  task_id: string;
  save_decision: RetentionSaveDecision;
  reason: string;
  proposed_target?: {
    path?: string;
    table?: string;
    issue_id?: string;
    skill_name?: string;
  };
  requires_user_approval: boolean;
}

export interface EvidenceSource {
  system: EvidenceSourceSystem;
  url?: string;
  path?: string;
  command?: string;
  ref?: string;
}

export interface EvidenceItem {
  evidence_id: string;
  task_id: string;
  created_at: string;
  evidence_type: EvidenceType;
  summary: string;
  source: EvidenceSource;
  status: EvidenceStatus;
  raw_excerpt?: string;
  artifact_path?: string;
}

export interface Strategy {
  strategy_id: string;
  title: string;
}

export interface StrategyVersion {
  strategy_version_id: string;
  strategy_id: string;
  version: number;
  objective: string;
  review_question: string;
}

export interface StrategyRef {
  strategy_id: string;
  strategy_version_id: string;
}

export interface TaskPacket {
  task_id: string;
  created_at: string;
  created_by: string;
  request_summary: string;
  raw_user_request: string;
  desired_outcome: string;
  task_type: TaskType;
  context_refs: ContextRef[];
  strategy_ref?: StrategyRef;
  risk_level: RiskLevel;
  required_approval: boolean;
  approval_reason?: string;
  forbidden_actions: string[];
  execution_plan: ExecutionStep[];
  verification_requirements: VerificationRequirement[];
  report_format: ReportFormat;
  status: TaskStatus;
  evidence: EvidenceItem[];
  result?: WorkerResult;
  blockers: Blocker[];
  next_action?: string;
  retention_decision?: RetentionDecision;
}

export interface WorkerEvent {
  event_id: string;
  task_id: string;
  created_at: string;
  event_type: WorkerEventType;
  message: string;
  evidence_ref_id?: string;
  severity?: EventSeverity;
  requires_user_action?: boolean;
}

export interface ApprovalPolicy {
  action_type: ApprovalActionType;
  default_required: true;
  approval_mode: "explicit_user_confirmation";
  allowed_without_approval?: false;
}

export interface ApprovalClassification {
  risk_level: RiskLevel;
  required_approval: boolean;
  approval_actions: ApprovalActionType[];
  approval_reason?: string;
  forbidden_actions: string[];
}

export interface TaskPacketTemplate {
  task_type: TaskType;
  risk_level: RiskLevel;
  required_approval: boolean;
  approval_reason?: string;
  forbidden_actions: string[];
  execution_plan: ExecutionStep[];
  verification_requirements: VerificationRequirement[];
  report_format: ReportFormat;
}

export type DefaultTaskType =
  | "pr_verification"
  | "supabase_staging_check"
  | "document_to_prd"
  | "inventory_check"
  | "urgent_material_risk_assessment"
  | "delivery_delay_risk_check"
  | "business_risk_review"
  | "customer_reply_draft"
  | "order_status_check"
  | "material_substitution_review";

export type CreateTaskPacketInput = {
  task_id: string;
  created_at: string;
  created_by: string;
  request_summary: string;
  raw_user_request: string;
  desired_outcome: string;
  task_type: DefaultTaskType;
  context_refs?: ContextRef[];
  strategy_ref?: StrategyRef;
  status?: TaskStatus;
  evidence?: EvidenceItem[];
  blockers?: Blocker[];
  result?: WorkerResult;
  next_action?: string;
  retention_decision?: RetentionDecision;
};

export interface ValidationResult {
  valid: boolean;
  issues: string[];
}
