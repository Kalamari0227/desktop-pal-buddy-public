import { containsSensitiveRawExcerpt, validateEvidenceItem } from "./evidence";
import { blockerSchema, retentionDecisionSchema, workerResultSchema } from "./schemas";
import { suggestEvidenceTypesForTask } from "./taskEvidenceCapture";
import type {
  Blocker,
  BlockerType,
  ContextRef,
  EvidenceItem,
  EvidenceSourceSystem,
  EvidenceStatus,
  EvidenceType,
  RetentionDecision,
  RetentionSaveDecision,
  TaskPacket,
  ValidationResult,
  WorkerOutcome,
  WorkerResult,
} from "./types";

type ResultSection =
  | "summary"
  | "conclusion"
  | "details"
  | "evidence"
  | "blockers"
  | "next_action"
  | "risks"
  | "changed_paths"
  | "retention";

export interface ManualCodexResultIntakeInput {
  packet: TaskPacket;
  pasted_result: string;
  created_at?: string;
  evidence_sequence_start?: number;
  blocker_sequence_start?: number;
}

export interface ManualCodexResultIntake {
  result: WorkerResult;
  evidence: EvidenceItem[];
  blockers: Blocker[];
  next_action?: string;
  retention_decision: RetentionDecision;
  validation: ValidationResult;
}

const SECTION_ALIASES: Array<[RegExp, ResultSection]> = [
  [/\b(conclusion|result|outcome|결론|결과)\b/i, "conclusion"],
  [/\b(summary|요약)\b/i, "summary"],
  [/\b(details?|changed|checked|검토|변경)\b/i, "details"],
  [/\b(evidence|근거|증거)\b/i, "evidence"],
  [/\b(blockers?|blocked|막힌|보류|차단)\b/i, "blockers"],
  [/\b(next\s*action|follow[-\s]?up|다음\s*행동|다음\s*조치)\b/i, "next_action"],
  [/\b(risks?|warnings?|리스크|위험|경고)\b/i, "risks"],
  [/\b(changed\s*paths?|files?|paths?|변경\s*파일)\b/i, "changed_paths"],
  [/\b(retention|save|routing|저장|라우팅)\b/i, "retention"],
];

function compact(value: string): string {
  return value.replace(/\s+/g, " ").trim();
}

function stripBullet(value: string): string {
  return value
    .replace(/^\s*(?:[-*+]|\d+[.)])\s*/, "")
    .replace(/^\[[ xX]\]\s*/, "")
    .trim();
}

function stripInlineStatus(value: string): string {
  return value
    .replace(/^\s*\[(?:passed|pass|failed|fail|warning|warn|info|통과|실패|경고|정보)\]\s*/i, "")
    .replace(/^\s*(?:passed|failed|warning|info|통과|실패|경고|정보)\s*:\s*/i, "")
    .trim();
}

function sectionFromHeading(value: string): ResultSection | undefined {
  const normalized = value.replace(/^#+\s*/, "").replace(/[:#*_`]/g, " ").trim();
  return SECTION_ALIASES.find(([pattern]) => pattern.test(normalized))?.[1];
}

function splitSections(pastedResult: string): Record<ResultSection, string[]> {
  const sections: Record<ResultSection, string[]> = {
    summary: [],
    conclusion: [],
    details: [],
    evidence: [],
    blockers: [],
    next_action: [],
    risks: [],
    changed_paths: [],
    retention: [],
  };
  let current: ResultSection = "summary";

  for (const rawLine of pastedResult.split(/\r?\n/)) {
    const line = rawLine.trimEnd();
    const markdownHeading = line.match(/^\s{0,3}#{1,6}\s+(.+?)\s*#*\s*$/);
    const boldHeading = line.match(/^\s*\*\*(.+?)\*\*\s*:?\s*$/);
    const inlineHeading = line.match(/^\s*([^:]{2,48}):\s*(.*)$/);
    const heading = markdownHeading?.[1] ?? boldHeading?.[1];
    const section = heading ? sectionFromHeading(heading) : undefined;

    if (section) {
      current = section;
      continue;
    }

    if (inlineHeading && !/^\s*(?:[-*+]|\d+[.)])\s+/.test(line)) {
      const inlineSection = sectionFromHeading(inlineHeading[1]);
      if (inlineSection) {
        current = inlineSection;
        if (inlineHeading[2].trim()) {
          sections[current].push(inlineHeading[2].trim());
        }
        continue;
      }
    }

    sections[current].push(line);
  }

  return sections;
}

function sectionText(sections: Record<ResultSection, string[]>, section: ResultSection): string {
  return sections[section].map((line) => line.trim()).filter(Boolean).join("\n").trim();
}

function sectionEntries(sections: Record<ResultSection, string[]>, section: ResultSection): string[] {
  const lines = sections[section].map((line) => line.trim()).filter(Boolean);
  const bullets = lines.filter((line) => /^\s*(?:[-*+]|\d+[.)])\s+/.test(line)).map(stripBullet);

  if (bullets.length > 0) {
    return bullets.filter((line) => !/^(none|n\/a|없음|해당 없음)$/i.test(line));
  }

  const text = lines.join("\n").trim();
  if (!text || /^(none|n\/a|없음|해당 없음)$/i.test(text)) {
    return [];
  }
  return [text];
}

function inferOutcome(text: string, blockerCount: number, riskCount: number, evidence: EvidenceItem[]): WorkerOutcome {
  const normalized = text.toLowerCase();

  if (blockerCount > 0 || /blocked|approval required|missing credential|보류|승인 필요|막힘/.test(normalized)) {
    return "blocked";
  }
  if (/failed|failure|error|실패|오류/.test(normalized) || evidence.some((item) => item.status === "failed")) {
    return "failed";
  }
  if (/advisory|advice only|참고|권고/.test(normalized)) {
    return "advisory_only";
  }
  if (riskCount > 0 || /warning|warn|주의|경고/.test(normalized)) {
    return "passed_with_warnings";
  }
  return "passed";
}

function inferEvidenceStatus(text: string): EvidenceStatus {
  if (/\b(failed|fail|error)\b|실패|오류/i.test(text)) {
    return "failed";
  }
  if (/\b(warning|warn)\b|주의|경고/i.test(text)) {
    return "warning";
  }
  if (/\b(info|note)\b|정보|참고/i.test(text)) {
    return "info";
  }
  return "passed";
}

function inferEvidenceType(text: string, packet: TaskPacket, index: number): EvidenceType {
  const normalized = text.toLowerCase();

  if (/\b(ci|github action|check run|checks?)\b/.test(normalized)) return "ci_status";
  if (/\b(vitest|playwright|test|tests?)\b|테스트/.test(normalized)) return "test_result";
  if (/\b(npm|pnpm|yarn|command|shell|terminal)\b|명령/.test(normalized)) return "command_output";
  if (/\b(diff|changed file|file change|git diff)\b|변경/.test(normalized)) return "file_diff";
  if (/\b(supabase|project health)\b/.test(normalized)) return "supabase_project_status";
  if (/\b(migration|migrations)\b|마이그레이션/.test(normalized)) return "supabase_migration_status";
  if (/\b(edge function|function deployment)\b/.test(normalized)) return "edge_function_status";
  if (/\b(advisor)\b/.test(normalized)) return "advisor_result";
  if (/\b(document|prd|draft|doc)\b|문서|초안/.test(normalized)) return "generated_document";
  if (/\b(inventory|stock|warehouse)\b|재고|창고/.test(normalized)) return "inventory_snapshot";
  if (/\b(order|sales order|purchase order|so-\d+)\b|주문|오더/.test(normalized)) return "order_status";
  if (/\b(delivery|shipment|eta|schedule)\b|납기|출하|배송/.test(normalized)) return "delivery_schedule";
  if (/\b(risk|risk assessment)\b|리스크|위험/.test(normalized)) return "risk_assessment";
  if (/\b(reply|email|response draft)\b|답장|회신|메일/.test(normalized)) return "generated_reply";
  if (/\b(substitution|substitute|alternate material)\b|대체/.test(normalized)) return "substitution_option";

  return suggestEvidenceTypesForTask(packet)[index] ?? "manual_observation";
}

function inferEvidenceSource(text: string): EvidenceSourceSystem {
  const normalized = text.toLowerCase();

  if (/\bgithub|pr #|pull request|commit|ci\b/.test(normalized)) return "github";
  if (/\bsupabase|edge function|rls|migration\b/.test(normalized)) return "supabase";
  if (/\bnpm|pnpm|yarn|shell|terminal|command\b/.test(normalized)) return "local_shell";
  if (/\brepo|file|diff|path\b/.test(normalized)) return "repo";
  if (/\berp\b|\border\b|inventory|stock|warehouse|재고|창고|주문|오더/.test(normalized)) return "erp";
  if (/\bcrm\b|customer|고객/.test(normalized)) return "crm";
  if (/\bspreadsheet|sheet\b|스프레드시트/.test(normalized)) return "spreadsheet";
  return "codex_worker";
}

function parseEvidence(input: ManualCodexResultIntakeInput, sections: Record<ResultSection, string[]>): EvidenceItem[] {
  const createdAt = input.created_at ?? new Date().toISOString();
  const sequenceStart = input.evidence_sequence_start ?? 1;

  return sectionEntries(sections, "evidence").map((entry, index) => {
    const summary = compact(stripInlineStatus(entry));

    return {
      evidence_id: `${input.packet.task_id}-evidence-${sequenceStart + index}`,
      task_id: input.packet.task_id,
      created_at: createdAt,
      evidence_type: inferEvidenceType(summary, input.packet, index),
      summary,
      source: {
        system: inferEvidenceSource(summary),
        ref: "manual-codex-result",
      },
      status: inferEvidenceStatus(entry),
    };
  });
}

function inferBlockerType(text: string): BlockerType {
  const normalized = text.toLowerCase();

  if (/credential|auth|login|access|권한|인증/.test(normalized)) return "missing_credentials";
  if (/approval|승인/.test(normalized)) return "approval_required";
  if (/tool|unavailable|도구|사용 불가/.test(normalized)) return "tool_unavailable";
  if (/\bverification\b|\btest\b|\bci\b|검증|테스트|실패/.test(normalized)) return "verification_failed";
  if (/ambiguous|unclear|모호|불명확/.test(normalized)) return "ambiguous_request";
  if (/policy|forbidden|blocked by policy|정책|금지/.test(normalized)) return "policy_blocked";
  return "missing_context";
}

function parseBlockers(input: ManualCodexResultIntakeInput, sections: Record<ResultSection, string[]>): Blocker[] {
  const sequenceStart = input.blocker_sequence_start ?? 1;

  return sectionEntries(sections, "blockers").map((entry, index) => {
    const summary = compact(stripInlineStatus(entry));
    const type = inferBlockerType(summary);

    return {
      blocker_id: `${input.packet.task_id}-blocker-${sequenceStart + index}`,
      type,
      summary,
      requires_user_action: type !== "verification_failed",
      suggested_resolution: type === "missing_context" ? "필요한 맥락을 보강한 뒤 다시 실행합니다." : undefined,
    };
  });
}

function parseChangedPaths(sections: Record<ResultSection, string[]>): string[] | undefined {
  const paths = sectionEntries(sections, "changed_paths")
    .flatMap((entry) => entry.split(/[,;\n]/))
    .map((entry) => entry.replace(/[`"' ]/g, "").trim())
    .filter(Boolean);

  return paths.length > 0 ? Array.from(new Set(paths)) : undefined;
}

function parseCheckedRefs(text: string): ContextRef[] | undefined {
  const urls = Array.from(new Set(text.match(/https?:\/\/\S+/g) ?? []));
  if (urls.length === 0) {
    return undefined;
  }

  return urls.map((url, index) => ({
    type: "external_link",
    label: `Result ref ${index + 1}`,
    value: url.replace(/[),.;]+$/, ""),
  }));
}

function inferRetentionDecision(
  packet: TaskPacket,
  sections: Record<ResultSection, string[]>,
  evidence: EvidenceItem[],
  blockers: Blocker[],
  nextAction?: string,
): RetentionDecision {
  const retentionText = sectionText(sections, "retention").toLowerCase();
  let saveDecision: RetentionSaveDecision = "no_save";
  let reason = "One-time worker result; no durable save target was identified.";

  if (/memory|preference|사용자\s*선호/.test(retentionText)) {
    saveDecision = "memory";
    reason = "Result describes a stable preference or reusable context.";
  } else if (/skill|procedure|반복|절차/.test(retentionText)) {
    saveDecision = "skill";
    reason = "Result describes a repeatable procedure.";
  } else if (/docs?|wiki|문서|지식/.test(retentionText)) {
    saveDecision = "docs_or_wiki";
    reason = "Result should be kept as durable project knowledge.";
  } else if (/workboard|task|follow[-\s]?up|후속|작업/.test(retentionText)) {
    saveDecision = "workboard";
    reason = "Result leaves an active follow-up or blocker.";
  } else if (/artifact|log|evidence|증거|로그/.test(retentionText)) {
    saveDecision = "artifact_or_log";
    reason = "Result is best retained as evidence or an execution log.";
  } else if (blockers.length > 0 || nextAction) {
    saveDecision = "workboard";
    reason = "Result has active blockers or a next action.";
  } else if (packet.task_type === "document_to_prd" || evidence.some((item) => item.evidence_type === "generated_document")) {
    saveDecision = "docs_or_wiki";
    reason = "Generated document output may become durable project knowledge.";
  } else if (evidence.length > 0) {
    saveDecision = "artifact_or_log";
    reason = "Evidence-backed execution result should remain auditable.";
  }

  return {
    task_id: packet.task_id,
    save_decision: saveDecision,
    reason,
    requires_user_approval: saveDecision !== "no_save",
  };
}

function addParseIssues(input: ManualCodexResultIntakeInput, intake: Omit<ManualCodexResultIntake, "validation">): string[] {
  const issues: string[] = [];

  if (containsSensitiveRawExcerpt(input.pasted_result)) {
    issues.push("pasted result contains sensitive content");
  }

  const resultParsed = workerResultSchema.safeParse(intake.result);
  if (!resultParsed.success) {
    issues.push(...resultParsed.error.issues.map((issue) => issue.message));
  }

  for (const evidence of intake.evidence) {
    const evidenceResult = validateEvidenceItem(evidence);
    if (!evidenceResult.valid) {
      issues.push(...evidenceResult.issues);
    }
  }

  for (const blocker of intake.blockers) {
    const blockerParsed = blockerSchema.safeParse(blocker);
    if (!blockerParsed.success) {
      issues.push(...blockerParsed.error.issues.map((issue) => issue.message));
    }
  }

  const retentionParsed = retentionDecisionSchema.safeParse(intake.retention_decision);
  if (!retentionParsed.success) {
    issues.push(...retentionParsed.error.issues.map((issue) => issue.message));
  }

  if (["passed", "passed_with_warnings"].includes(intake.result.outcome) && intake.evidence.length === 0) {
    issues.push("passed worker result requires at least one evidence item");
  }

  return Array.from(new Set(issues));
}

export function parseManualCodexResult(input: ManualCodexResultIntakeInput): ManualCodexResultIntake {
  const sections = splitSections(input.pasted_result);
  const conclusion = sectionText(sections, "conclusion") || sectionText(sections, "summary");
  const details = sectionText(sections, "details") || undefined;
  const evidence = parseEvidence(input, sections);
  const blockers = parseBlockers(input, sections);
  const risks = sectionEntries(sections, "risks");
  const nextAction = compact(sectionText(sections, "next_action"));
  const resultText = [
    sectionText(sections, "conclusion"),
    sectionText(sections, "summary"),
    sectionText(sections, "details"),
    sectionText(sections, "risks"),
    sectionText(sections, "blockers"),
  ].join("\n");
  const result: WorkerResult = {
    outcome: inferOutcome(resultText, blockers.length, risks.length, evidence),
    summary: compact(conclusion) || "Worker result captured from pasted Codex output.",
    details,
    changed_paths: parseChangedPaths(sections),
    checked_refs: parseCheckedRefs(input.pasted_result),
    risks: risks.length > 0 ? risks.map(compact) : undefined,
  };
  const retentionDecision = inferRetentionDecision(input.packet, sections, evidence, blockers, nextAction || undefined);
  const intake = {
    result,
    evidence,
    blockers,
    next_action: nextAction || undefined,
    retention_decision: retentionDecision,
  };
  const issues = addParseIssues(input, intake);

  return {
    ...intake,
    validation: {
      valid: issues.length === 0,
      issues,
    },
  };
}
