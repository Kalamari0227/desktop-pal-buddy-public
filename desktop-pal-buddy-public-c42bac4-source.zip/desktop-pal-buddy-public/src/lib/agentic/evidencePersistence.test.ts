import { describe, expect, it } from "vitest";
import {
  agentEvidenceRowToEvidenceItem,
  agentEvidenceRowsToEvidenceItems,
  evidenceItemToAgentEvidenceInsert,
  type AgentEvidenceRow,
} from "./evidencePersistence";
import type { EvidenceItem } from "./types";

const evidence: EvidenceItem = {
  evidence_id: "workboard-task-1-evidence-1",
  task_id: "workboard-task-1",
  created_at: "2026-07-04T00:01:00.000Z",
  evidence_type: "order_status",
  summary: "SO-1001 is allocated.",
  source: {
    system: "erp",
    ref: "SO-1001",
  },
  status: "passed",
  raw_excerpt: "Allocated, waiting for shipment.",
};

describe("evidence persistence mapping", () => {
  it("maps an EvidenceItem into an agent_evidence insert row", () => {
    expect(evidenceItemToAgentEvidenceInsert({
      workboard_task_id: "00000000-0000-0000-0000-000000000001",
      evidence,
    })).toEqual({
      task_id: "00000000-0000-0000-0000-000000000001",
      packet_task_id: "workboard-task-1",
      evidence_id: "workboard-task-1-evidence-1",
      evidence_type: "order_status",
      summary: "SO-1001 is allocated.",
      source_system: "erp",
      source_url: null,
      source_path: null,
      source_command: null,
      source_ref: "SO-1001",
      status: "passed",
      raw_excerpt: "Allocated, waiting for shipment.",
      artifact_path: null,
      created_at: "2026-07-04T00:01:00.000Z",
    });
  });

  it("maps a database row back into an EvidenceItem", () => {
    const row: AgentEvidenceRow = {
      id: "row-1",
      owner_id: "user-1",
      task_id: "00000000-0000-0000-0000-000000000001",
      packet_task_id: "workboard-task-1",
      evidence_id: "workboard-task-1-evidence-1",
      evidence_type: "order_status",
      summary: "SO-1001 is allocated.",
      source_system: "erp",
      source_url: null,
      source_path: null,
      source_command: null,
      source_ref: "SO-1001",
      status: "passed",
      raw_excerpt: "Allocated, waiting for shipment.",
      artifact_path: null,
      created_at: "2026-07-04T00:01:00.000Z",
    };

    expect(agentEvidenceRowToEvidenceItem(row)).toEqual(evidence);
  });

  it("sorts persisted rows by creation time before rendering", () => {
    const rows: AgentEvidenceRow[] = [
      {
        id: "row-2",
        owner_id: "user-1",
        task_id: "00000000-0000-0000-0000-000000000001",
        packet_task_id: "workboard-task-1",
        evidence_id: "workboard-task-1-evidence-2",
        evidence_type: "delivery_schedule",
        summary: "ETA is Friday.",
        source_system: "spreadsheet",
        source_url: null,
        source_path: null,
        source_command: null,
        source_ref: null,
        status: "passed",
        raw_excerpt: null,
        artifact_path: null,
        created_at: "2026-07-04T00:02:00.000Z",
      },
      {
        id: "row-1",
        owner_id: "user-1",
        task_id: "00000000-0000-0000-0000-000000000001",
        packet_task_id: "workboard-task-1",
        evidence_id: "workboard-task-1-evidence-1",
        evidence_type: "order_status",
        summary: "SO-1001 is allocated.",
        source_system: "erp",
        source_url: null,
        source_path: null,
        source_command: null,
        source_ref: null,
        status: "passed",
        raw_excerpt: null,
        artifact_path: null,
        created_at: "2026-07-04T00:01:00.000Z",
      },
    ];

    expect(agentEvidenceRowsToEvidenceItems(rows).map((item) => item.evidence_id)).toEqual([
      "workboard-task-1-evidence-1",
      "workboard-task-1-evidence-2",
    ]);
  });
});
