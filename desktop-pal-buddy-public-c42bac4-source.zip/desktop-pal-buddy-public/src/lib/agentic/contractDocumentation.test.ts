import { describe, expect, it } from "vitest";
import taskPacketDocumentation from "../../../docs/agent-os/task-packet-schema.md?raw";
import evidenceLedgerDocumentation from "../../../docs/agent-os/evidence-ledger-schema.md?raw";
import { EVIDENCE_TYPES, TASK_TYPES, VERIFICATION_TYPES } from "./types";

function documentedUnion(markdown: string, typeName: string): string[] {
  const match = markdown.match(new RegExp(`export type ${typeName} =[\\s\\S]*?;`));
  if (!match) throw new Error(`Missing documented ${typeName}`);
  return [...match[0].matchAll(/\| "([^"]+)"/g)].map((entry) => entry[1]);
}

describe("agentic contract documentation", () => {
  it("publishes the same task and verification enums as the runtime contract", () => {
    const documentedTaskTypes = documentedUnion(taskPacketDocumentation, "TaskType");
    const documentedVerificationTypes = documentedUnion(taskPacketDocumentation, "VerificationType");
    expect(documentedTaskTypes).toContain("production_priority_change");
    expect(documentedTaskTypes).toContain("production_readiness_review");
    expect(documentedVerificationTypes).toContain("production_state");
    expect(documentedTaskTypes).toEqual([...TASK_TYPES]);
    expect(documentedVerificationTypes).toEqual([...VERIFICATION_TYPES]);
  });

  it("publishes the same evidence enum as the runtime contract", () => {
    const documentedEvidenceTypes = documentedUnion(evidenceLedgerDocumentation, "EvidenceType");
    expect(documentedEvidenceTypes).toContain("production_state");
    expect(documentedEvidenceTypes).toEqual([...EVIDENCE_TYPES]);
  });
});
