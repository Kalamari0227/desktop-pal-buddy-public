import type { ApprovalActionType, ApprovalPolicy } from "./types";

export const APPROVAL_POLICIES: Record<ApprovalActionType, ApprovalPolicy> = {
  external_message: {
    action_type: "external_message",
    default_required: true,
    approval_mode: "explicit_user_confirmation",
    allowed_without_approval: false,
  },
  file_delete_or_move: {
    action_type: "file_delete_or_move",
    default_required: true,
    approval_mode: "explicit_user_confirmation",
    allowed_without_approval: false,
  },
  production_deploy: {
    action_type: "production_deploy",
    default_required: true,
    approval_mode: "explicit_user_confirmation",
    allowed_without_approval: false,
  },
  database_migration: {
    action_type: "database_migration",
    default_required: true,
    approval_mode: "explicit_user_confirmation",
    allowed_without_approval: false,
  },
  service_restart: {
    action_type: "service_restart",
    default_required: true,
    approval_mode: "explicit_user_confirmation",
    allowed_without_approval: false,
  },
  oauth_or_gateway_config_change: {
    action_type: "oauth_or_gateway_config_change",
    default_required: true,
    approval_mode: "explicit_user_confirmation",
    allowed_without_approval: false,
  },
  paid_resource_creation: {
    action_type: "paid_resource_creation",
    default_required: true,
    approval_mode: "explicit_user_confirmation",
    allowed_without_approval: false,
  },
  secret_create_or_store: {
    action_type: "secret_create_or_store",
    default_required: true,
    approval_mode: "explicit_user_confirmation",
    allowed_without_approval: false,
  },
  permission_change: {
    action_type: "permission_change",
    default_required: true,
    approval_mode: "explicit_user_confirmation",
    allowed_without_approval: false,
  },
};

const MUTATION_PATTERNS = [
  /\b(send|post|publish|delete|remove|move|reorganize|merge|deploy|release|run|apply|execute|migrate|restart|create|provision|store|save|rotate|change|update|modify|grant|revoke|enable|disable)\b/i,
  /(발송|전송|게시|삭제|제거|이동|정리|병합|배포|릴리즈|실행|적용|마이그레이션|재시작|생성|프로비저닝|저장|회전|변경|수정|권한|허용|차단)/i,
];

const READ_ONLY_PATTERNS = [
  /\b(check|status|list|read|review|inspect|verify|audit|dry-run|dry run|plan|draft|summarize)\b/i,
  /(확인|조회|상태|점검|검토|리뷰|읽|계획|초안|요약)/i,
];

const matchesAny = (value: string, patterns: RegExp[]): boolean => patterns.some((pattern) => pattern.test(value));

function hasMutationIntent(request: string): boolean {
  return matchesAny(request, MUTATION_PATTERNS);
}

function isReadOnlyIntent(request: string): boolean {
  return matchesAny(request, READ_ONLY_PATTERNS) && !hasMutationIntent(request);
}

function addAction(actions: Set<ApprovalActionType>, request: string, action: ApprovalActionType): void {
  if (!isReadOnlyIntent(request)) {
    actions.add(action);
  }
}

export function detectApprovalActions(request: string): ApprovalActionType[] {
  const actions = new Set<ApprovalActionType>();
  const lower = request.toLowerCase();

  if (/(email|slack|teams|x\/twitter|twitter|tweet|dm|external message|고객|외부|메일|슬랙|팀즈|트윗|디엠)/i.test(request)) {
    addAction(actions, request, "external_message");
  }

  if (/(delete|remove|move|reorganize|rm\s|-rf|삭제|제거|이동|재정리)/i.test(request)) {
    addAction(actions, request, "file_delete_or_move");
  }

  if (/(production|prod|live|운영|프로덕션)/i.test(request) && /(deploy|release|배포|릴리즈)/i.test(request)) {
    addAction(actions, request, "production_deploy");
  }

  if (/(database|db|migration|migrate|schema|sql|데이터베이스|마이그레이션|스키마)/i.test(request)) {
    if (/(migration|migrate|마이그레이션|실행|적용|apply|run|execute)/i.test(request)) {
      addAction(actions, request, "database_migration");
    }
  }

  if (/(restart|reboot|bounce|service restart|재시작)/i.test(request)) {
    addAction(actions, request, "service_restart");
  }

  if (/(oauth|model|gateway|provider|redirect uri|callback url|config|설정|게이트웨이|모델)/i.test(request)) {
    if (/(change|update|modify|enable|disable|switch|rotate|변경|수정|교체|활성|비활성)/i.test(request)) {
      addAction(actions, request, "oauth_or_gateway_config_change");
    }
  }

  if (/(paid|billing|invoice|subscription|plan|resource|provision|create|유료|결제|구독|리소스|생성)/i.test(request)) {
    if (/(create|provision|subscribe|upgrade|buy|purchase|생성|구매|구독|업그레이드)/i.test(request)) {
      addAction(actions, request, "paid_resource_creation");
    }
  }

  if (/(secret|api key|apikey|token|credential|private key|env|\.env|시크릿|토큰|키|자격증명)/i.test(request)) {
    if (/(create|store|save|rotate|issue|generate|생성|저장|발급|회전)/i.test(request)) {
      addAction(actions, request, "secret_create_or_store");
    }
  }

  if (/(permission|role|access|grant|revoke|owner|admin|권한|접근|관리자|역할)/i.test(request)) {
    if (/(change|grant|revoke|add|remove|update|변경|부여|회수|추가|삭제|수정)/i.test(request)) {
      addAction(actions, request, "permission_change");
    }
  }

  if (lower.includes("send external message")) {
    addAction(actions, request, "external_message");
  }

  return [...actions];
}

export const classifyApprovalActions = detectApprovalActions;

export function requiresApprovalForAction(actionType: ApprovalActionType): boolean {
  return APPROVAL_POLICIES[actionType].default_required;
}

export function requiresApproval(request: string): boolean {
  return detectApprovalActions(request).length > 0;
}
