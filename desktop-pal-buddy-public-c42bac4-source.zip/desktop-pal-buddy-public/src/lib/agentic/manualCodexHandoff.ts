import { parseManualCodexResult, type ManualCodexResultIntake } from "./manualCodexResultIntake";
import { renderManualCodexResultGuide } from "./manualCodexResultGuide";
import type { TaskPacket, VerificationRequirement } from "./types";

const renderVerificationRequirement = (requirement: VerificationRequirement): string => {
  const requirementLabel = requirement.required ? "required" : "optional";
  const source = requirement.command_or_source ? `: ${requirement.command_or_source}` : "";
  return `- [${requirementLabel}] ${requirement.type}${source}`;
};

export function renderManualCodexHandoff(packet: TaskPacket): string {
  const strategyRef = packet.strategy_ref
    ? [
        "## Strategy Reference",
        `- strategy_id: ${packet.strategy_ref.strategy_id}`,
        `- strategy_version_id: ${packet.strategy_ref.strategy_version_id}`,
        "",
      ]
    : [];
  const contextRefs =
    packet.context_refs.length > 0
      ? packet.context_refs.map((ref) => `- [${ref.type}] ${ref.label}: ${ref.value}`)
      : ["- none"];
  const forbiddenActions =
    packet.forbidden_actions.length > 0 ? packet.forbidden_actions.map((action) => `- ${action}`) : ["- none"];
  const executionPlan =
    packet.execution_plan.length > 0
      ? packet.execution_plan.map((step, index) => {
          const evidence = step.expected_evidence ? ` Expected evidence: ${step.expected_evidence}` : "";
          return `${index + 1}. ${step.summary}${evidence}`;
        })
      : ["1. No execution steps were provided."];
  const verificationRequirements =
    packet.verification_requirements.length > 0
      ? packet.verification_requirements.map(renderVerificationRequirement)
      : ["- none"];

  return [
    "# Codex Task Packet",
    "",
    "## Request",
    packet.request_summary,
    "",
    "## Desired Outcome",
    packet.desired_outcome,
    "",
    ...strategyRef,
    "## Context Refs",
    ...contextRefs,
    "",
    "## Forbidden Actions",
    ...forbiddenActions,
    "",
    "## Execution Plan",
    ...executionPlan,
    "",
    "## Verification Requirements",
    ...verificationRequirements,
    "",
    "## Report Back With",
    "- conclusion",
    "- evidence",
    "- blockers",
    "- next action",
    "- retention suggestion",
    "",
    "## Result Format",
    "Use this exact section layout in the worker reply:",
    "",
    "```md",
    renderManualCodexResultGuide(packet),
    "```",
  ].join("\n");
}

export class ManualCodexAdapter {
  renderTaskPacket(packet: TaskPacket): string {
    return renderManualCodexHandoff(packet);
  }

  parseWorkerResult(packet: TaskPacket, pastedResult: string): ManualCodexResultIntake {
    return parseManualCodexResult({
      packet,
      pasted_result: pastedResult,
    });
  }
}
