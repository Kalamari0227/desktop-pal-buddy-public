import { describe, expect, it } from "vitest";
import { createTaskPacket } from "./taskTemplates";
import {
  isAgentApprovalRecorded,
  latestAgentApprovalRow,
  taskPacketToAgentApprovalInsert,
  type AgentApprovalRow,
} from "./approvalPersistence";

const approvalPacket = createTaskPacket({
  task_id: "workboard-task-approval",
  created_at: "2026-07-04T00:00:00.000Z",
  created_by: "tasks-workboard",
  request_summary: "Check and run a staging DB migration.",
  raw_user_request: "staging DB migration 실행해줘",
  desired_outcome: "Do not mutate before approval.",
  task_type: "supabase_staging_check",
});

describe("approval persistence mapping", () => {
  it("maps an approval-required Task Packet into an insert row", () => {
    expect(taskPacketToAgentApprovalInsert({
      workboard_task_id: "00000000-0000-0000-0000-000000000001",
      packet: approvalPacket,
      decision: "approved",
      approved_scope: "Approved for staging dry run only.",
      created_at: "2026-07-04T00:01:00.000Z",
    })).toEqual({
      task_id: "00000000-0000-0000-0000-000000000001",
      packet_task_id: "workboard-task-approval",
      decision: "approved",
      action_type: "database_migration",
      approval_reason: "Approval required for: database_migration",
      approved_scope: "Approved for staging dry run only.",
      created_at: "2026-07-04T00:01:00.000Z",
    });
  });

  it("uses the latest approval row as the active decision", () => {
    const rows: AgentApprovalRow[] = [
      {
        id: "row-1",
        owner_id: "user-1",
        task_id: "00000000-0000-0000-0000-000000000001",
        packet_task_id: "workboard-task-approval",
        decision: "approved",
        action_type: "database_migration",
        approval_reason: "Approval required for: database_migration",
        approved_scope: "Approved for staging dry run only.",
        created_at: "2026-07-04T00:01:00.000Z",
      },
      {
        id: "row-2",
        owner_id: "user-1",
        task_id: "00000000-0000-0000-0000-000000000001",
        packet_task_id: "workboard-task-approval",
        decision: "rejected",
        action_type: "database_migration",
        approval_reason: "Approval required for: database_migration",
        approved_scope: "Rejected before mutation.",
        created_at: "2026-07-04T00:02:00.000Z",
      },
    ];

    const latest = latestAgentApprovalRow(rows);

    expect(latest?.id).toBe("row-2");
    expect(isAgentApprovalRecorded(latest)).toBe(false);
    expect(isAgentApprovalRecorded(rows[0])).toBe(true);
  });
});
