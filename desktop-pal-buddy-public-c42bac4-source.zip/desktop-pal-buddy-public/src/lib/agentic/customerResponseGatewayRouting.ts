import { createGatewayCodexDraft, type GatewayCodexDraft } from "./gatewayCodexAgent";
import { containsSensitiveRawExcerpt } from "./evidence";
import type { ContextRef } from "./types";

export type CustomerResponseChannel = "email" | "phone" | "message";

export interface CustomerResponseRouteInput {
  customer_id: string;
  customer_name: string;
  customer_code?: string;
  inquiry_type: string;
  inquiry_label: string;
  inquiry_description: string;
  channel: CustomerResponseChannel;
  channel_label: string;
  tone: string;
  context_note?: string;
}

function compact(value: string): string {
  return value.replace(/\s+/g, " ").trim();
}

export function buildCustomerResponseContextRefs(input: CustomerResponseRouteInput): ContextRef[] {
  const refs: ContextRef[] = [
    { type: "customer_account", label: "고객", value: input.customer_name },
    { type: "user_note", label: "고객 코드", value: input.customer_code || input.customer_id },
    { type: "user_note", label: "문의 유형", value: input.inquiry_label },
    { type: "user_note", label: "회신 채널", value: input.channel_label },
    { type: "user_note", label: "톤앤매너", value: input.tone },
  ];

  const contextNote = compact(input.context_note ?? "");
  if (contextNote && !containsSensitiveRawExcerpt(contextNote)) {
    refs.push({ type: "user_note", label: "추가 맥락", value: contextNote });
  }

  return refs;
}

export function createCustomerResponseGatewayDraft(input: CustomerResponseRouteInput): GatewayCodexDraft {
  const customer = compact(input.customer_name);
  const inquiry = compact(input.inquiry_label);
  const channel = compact(input.channel_label);
  const tone = compact(input.tone);
  const contextNote = compact(input.context_note ?? "");
  const hasSensitiveContext = Boolean(contextNote && containsSensitiveRawExcerpt(contextNote));

  return createGatewayCodexDraft({
    raw_user_request: `${customer} ${inquiry} ${channel} 회신 초안 만들어줘`,
    context_refs: buildCustomerResponseContextRefs(input),
    created_by: "customer-response",
    codex_suggestion: {
      task_type: "customer_reply_draft",
      request_summary: `${customer} ${inquiry} 회신 초안을 검토 가능한 작업으로 정리합니다.`,
      desired_outcome: "외부 발송 없이 검토 가능한 회신 초안, 사실 전제, 민감 문구, 다음 행동을 보고합니다.",
      reasoning_notes: [
        `문의 유형: ${inquiry}`,
        `회신 채널: ${channel}`,
        `톤앤매너: ${tone}`,
        "고객 응답은 draft-only이며 외부 발송은 명시적 승인 전 금지됩니다.",
        hasSensitiveContext
          ? "추가 맥락은 민감 정보 패턴을 포함할 수 있어 packet context에 저장하지 않았습니다."
          : "추가 맥락은 안전한 user note context로 전달할 수 있습니다.",
      ],
    },
  });
}
