import { createGatewayCodexDraft, type GatewayCodexDraft } from "./gatewayCodexAgent";
import type { ContextRef, DefaultTaskType } from "./types";

export type BusinessRiskCategory = "delivery" | "quality" | "price";
export type BusinessRiskSeverity = "critical" | "high" | "medium" | "low";

export interface BusinessRiskRouteInput {
  id: string;
  customer: string;
  category: BusinessRiskCategory;
  title: string;
  description: string;
  severity: BusinessRiskSeverity;
  impact: string;
  dueDate?: string;
}

const MATERIAL_PATTERNS = [
  /GA\s*강판/i,
  /DP\s*780/i,
  /DP\s*강/i,
  /EV6\s*후속\s*모델\s*강판/i,
  /자동차\s*강판/i,
];

function compact(value: string): string {
  return value.replace(/\s+/g, " ").trim();
}

export function inferMaterialFromRisk(input: Pick<BusinessRiskRouteInput, "title" | "description">): string | undefined {
  const text = `${input.title} ${input.description}`;
  const match = MATERIAL_PATTERNS.map((pattern) => text.match(pattern)?.[0]).find(Boolean);
  return match ? compact(match) : undefined;
}

export function classifyRiskGatewayTask(input: BusinessRiskRouteInput): DefaultTaskType {
  const text = `${input.title} ${input.description}`.toLowerCase();

  if (/(긴급재|긴급\s*자재|공급\s*부족|재고\s*부족|available stock|inventory shortage|shortage)/i.test(text)) {
    return "urgent_material_risk_assessment";
  }

  if (input.category === "delivery" || /(납기|출하|배송|지연|delivery|shipment|delay|eta)/i.test(text)) {
    return "delivery_delay_risk_check";
  }

  if (/(대체재|대체품|대체\s*소재|사양\s*확정|substitution|substitute|alternate material)/i.test(text)) {
    return "material_substitution_review";
  }

  return "business_risk_review";
}

function requestForTask(input: BusinessRiskRouteInput, taskType: DefaultTaskType, material?: string): string {
  const subject = compact(`${input.customer} ${material ?? ""} ${input.title}`);

  if (taskType === "urgent_material_risk_assessment") {
    return `${subject} 긴급재 위험도 따져줘`;
  }
  if (taskType === "delivery_delay_risk_check") {
    return `${subject} 납기 지연 리스크 봐줘`;
  }
  if (taskType === "material_substitution_review") {
    return `${subject} 대체재 검토해줘`;
  }

  return `${subject} 리스크 점검해줘`;
}

export function buildRiskContextRefs(input: BusinessRiskRouteInput): ContextRef[] {
  const material = inferMaterialFromRisk(input);
  const refs: ContextRef[] = [
    { type: "customer_account", label: "customer", value: input.customer },
    { type: "user_note", label: "risk", value: input.title },
    { type: "user_note", label: "category", value: input.category },
    { type: "user_note", label: "severity", value: input.severity },
    { type: "user_note", label: "impact", value: input.impact },
    { type: "user_note", label: "risk id", value: input.id },
  ];

  if (material) {
    refs.push({ type: "material_item", label: "material", value: material });
  }

  if (input.dueDate) {
    refs.push({ type: "due_date", label: "due date", value: input.dueDate });
  }

  return refs;
}

export function createRiskGatewayDraft(input: BusinessRiskRouteInput): GatewayCodexDraft {
  const taskType = classifyRiskGatewayTask(input);
  const material = inferMaterialFromRisk(input);

  return createGatewayCodexDraft({
    raw_user_request: requestForTask(input, taskType, material),
    context_refs: buildRiskContextRefs(input),
    codex_suggestion: {
      task_type: taskType,
      reasoning_notes: [
        `Risk category: ${input.category}`,
        `Severity: ${input.severity}`,
        `Impact: ${input.impact}`,
      ],
    },
  });
}
