import { evidenceItemSchema, taskPacketSchema } from "./schemas";
import type { EvidenceItem, EvidenceType, TaskPacket, VerificationType, ValidationResult } from "./types";

const SECRET_PATTERNS = [
  /\b[A-Z0-9_]*(API[_-]?KEY|TOKEN|SECRET|PASSWORD|PRIVATE[_-]?KEY|CLIENT[_-]?SECRET)[A-Z0-9_]*\s*[:=]\s*\S+/i,
  /\bsk-(?:proj|live|test)?-[A-Za-z0-9_-]{6,}/i,
  /\bgh[pousr]_[A-Za-z0-9_]{12,}/i,
  /\bgithub_pat_[A-Za-z0-9_]{12,}/i,
  /\bAuthorization\s*:\s*Bearer\s+\S+/i,
  /\bBearer\s+[A-Za-z0-9._~+/-]+=*/i,
  /\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\b/,
  /https?:\/\/[^/\s:@]+:[^/\s:@]+@/i,
  /-----BEGIN [A-Z ]*PRIVATE KEY-----/i,
  /(^|[^A-Za-z0-9_])\.env(?:$|[^A-Za-z0-9_])/i,
  /\b(oauth|credential|bearer)\s*[:=]\s*\S+/i,
];

const UUID_PATTERN = "[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}";
const PRODUCTION_STATE_REF = new RegExp(`^company-runtime/(${UUID_PATTERN})/execution/(${UUID_PATTERN})$`, "i");
const SHA256_PATTERN = /^[a-f0-9]{64}$/;

export interface ProductionStateReadbackContext {
  evidence_id: string;
  packet_task_id: string;
  epoch: string;
  execution_id: string;
  read_set_digest: string;
  expected_priority: number;
  expected_version: number;
  observed_priority: number;
  observed_version: number;
  matches: true;
}

export interface EvidenceValidationContext {
  trusted_production_state_contexts?: readonly ProductionStateReadbackContext[];
}

const VERIFICATION_TO_EVIDENCE: Record<VerificationType, EvidenceType[]> = {
  test: ["test_result", "command_output"],
  lint: ["command_output"],
  typecheck: ["command_output"],
  build: ["command_output"],
  ci_status: ["ci_status"],
  diff_review: ["file_diff", "manual_observation"],
  supabase_status: [
    "supabase_project_status",
    "supabase_migration_status",
    "edge_function_status",
    "advisor_result",
  ],
  manual_review: ["manual_observation"],
  document_created: ["generated_document", "file_diff"],
  inventory_status: ["inventory_snapshot", "manual_observation"],
  order_status: ["order_status", "manual_observation"],
  delivery_status: ["delivery_schedule", "manual_observation"],
  risk_assessment: ["risk_assessment", "manual_observation"],
  reply_draft: ["generated_reply", "manual_observation"],
  substitution_review: ["substitution_option", "manual_observation"],
  production_state: ["production_state"],
};

export function containsSensitiveRawExcerpt(rawExcerpt?: string): boolean {
  if (!rawExcerpt) {
    return false;
  }

  return SECRET_PATTERNS.some((pattern) => pattern.test(rawExcerpt));
}

export function validateEvidenceItem(
  evidence: EvidenceItem,
  context: EvidenceValidationContext = {},
): ValidationResult {
  const issues: string[] = [];
  const parsed = evidenceItemSchema.safeParse(evidence);

  if (!parsed.success) {
    issues.push(...parsed.error.issues.map((issue) => issue.message));
  }

  if (containsSensitiveRawExcerpt(evidence.raw_excerpt)) {
    issues.push("raw_excerpt contains sensitive content");
  }

  if (evidence.evidence_type === "production_state") {
    if (evidence.source.system !== "erp") {
      issues.push("production_state evidence requires the ERP source system");
    }
    const ref = PRODUCTION_STATE_REF.exec(evidence.source.ref ?? "");
    if (!ref) {
      issues.push("production_state evidence requires UUID epoch and execution refs");
    }

    const readback = context.trusted_production_state_contexts?.find(
      (candidate) => candidate.evidence_id === evidence.evidence_id,
    );
    if (!readback) {
      issues.push("production_state evidence requires trusted runtime readback context");
    } else if (
      !ref
      || readback.packet_task_id !== evidence.task_id
      || readback.epoch.toLowerCase() !== ref[1].toLowerCase()
      || readback.execution_id.toLowerCase() !== ref[2].toLowerCase()
      || !SHA256_PATTERN.test(readback.read_set_digest)
      || !Number.isInteger(readback.expected_priority)
      || readback.expected_priority < 1
      || readback.expected_priority > 9
      || !Number.isInteger(readback.expected_version)
      || readback.expected_version < 1
      || readback.expected_priority !== readback.observed_priority
      || readback.expected_version !== readback.observed_version
      || readback.matches !== true
    ) {
      issues.push("production_state evidence does not match trusted runtime readback context");
    }
  }

  return { valid: issues.length === 0, issues };
}

function hasManualReviewRequirement(packet: TaskPacket): boolean {
  return packet.verification_requirements.some((requirement) => requirement.type === "manual_review");
}

function evidenceTypesForRequirement(requirement: TaskPacket["verification_requirements"][number]): EvidenceType[] {
  const source = requirement.command_or_source?.toLowerCase() ?? "";

  if (requirement.type === "supabase_status") {
    if (source.includes("project health")) {
      return ["supabase_project_status"];
    }
    if (source.includes("migration")) {
      return ["supabase_migration_status"];
    }
    if (source.includes("edge function")) {
      return ["edge_function_status"];
    }
    if (source.includes("advisor")) {
      return ["advisor_result"];
    }
  }

  if (requirement.type === "manual_review" && source.includes("advisor")) {
    return ["manual_observation", "advisor_result"];
  }

  return VERIFICATION_TO_EVIDENCE[requirement.type];
}

function hasRequiredEvidence(packet: TaskPacket, context: EvidenceValidationContext): boolean {
  const usedEvidenceIds = new Set<string>();

  return packet.verification_requirements
    .filter((requirement) => requirement.required)
    .every((requirement) => {
      const allowedEvidenceTypes = evidenceTypesForRequirement(requirement);
      const matchingEvidence = packet.evidence.find(
        (evidence) =>
          !usedEvidenceIds.has(evidence.evidence_id) &&
          evidence.task_id === packet.task_id &&
          evidence.status === "passed" &&
          allowedEvidenceTypes.includes(evidence.evidence_type) &&
          validateEvidenceItem(evidence, context).valid
      );

      if (!matchingEvidence) {
        return false;
      }

      usedEvidenceIds.add(matchingEvidence.evidence_id);
      return true;
    });
}

function forbiddenActionPattern(action: string): RegExp {
  const normalized = action.replace(/^do not\s+/i, "").toLowerCase();

  if (normalized.includes("merge pr")) {
    return /\b(?:merge|merged|merging)\s+(?:the\s+)?pr\b|\bpr\s+(?:was\s+)?merged\b/i;
  }
  if (normalized.includes("push commits")) {
    return /\b(?:push|pushed|pushing)\s+commits?\b|\bcommits?\s+(?:were\s+)?pushed\b/i;
  }
  if (normalized.includes("deploy functions")) {
    return /\b(?:deploy|deployed|deploying)\s+(?:edge\s+)?functions?\b/i;
  }
  if (normalized.includes("deploy")) {
    return /\b(?:deploy|deployed|deploying|release|released|releasing)\b/i;
  }
  if (normalized.includes("run migration")) {
    return /\b(?:run|ran|apply|applied|execute|executed)\s+(?:db\s+|database\s+)?migrations?\b|\bmigrations?\s+(?:were\s+)?(?:run|applied|executed)\b/i;
  }
  if (normalized.includes("change secrets")) {
    return /\b(?:change|changed|store|stored|create|created|rotate|rotated)\s+secrets?\b/i;
  }
  if (normalized.includes("modify production systems")) {
    return /\b(?:modify|modified|change|changed|update|updated)\s+(?:production|prod|live)\s+systems?\b/i;
  }
  if (normalized.includes("overwrite existing docs")) {
    return /\b(?:overwrite|overwrote|replace|replaced)\s+(?:existing\s+)?docs?\b/i;
  }
  if (normalized.includes("perform ")) {
    const actionType = normalized.replace(/^perform\s+/, "").replace(/\s+without explicit approval$/, "");

    if (actionType === "external_message") {
      return /\b(?:send|sent|post|posted|publish|published)\s+(?:(?:an?|the)\s+)?(?:email|message|slack|teams|dm|tweet)\b/i;
    }
    if (actionType === "file_delete_or_move") {
      return /\b(?:delete|deleted|remove|removed|move|moved|reorganize|reorganized)\s+(?:files?|folders?|paths?)\b/i;
    }
    if (actionType === "production_deploy") {
      return /\b(?:deploy|deployed|release|released)\s+(?:to\s+)?(?:production|prod|live)\b/i;
    }
    if (actionType === "database_migration") {
      return /\b(?:run|ran|apply|applied|execute|executed)\s+(?:db\s+|database\s+)?migrations?\b|\bmigrations?\s+(?:were\s+)?(?:run|applied|executed)\b/i;
    }
    if (actionType === "service_restart") {
      return /\b(?:restart|restarted|reboot|rebooted)\s+(?:the\s+)?service\b/i;
    }
    if (actionType === "oauth_or_gateway_config_change") {
      return /\b(?:change|changed|update|updated|modify|modified|switch|switched)\s+(?:oauth|gateway|model|provider|config)\b/i;
    }
    if (actionType === "paid_resource_creation") {
      return /\b(?:create|created|provision|provisioned|buy|bought|purchase|purchased)\s+(?:a\s+)?(?:paid\s+)?(?:resource|subscription|plan)\b/i;
    }
    if (actionType === "secret_create_or_store") {
      return /\b(?:create|created|store|stored|save|saved|rotate|rotated|generate|generated)\s+(?:(?:an?|the)\s+)?(?:secret|api\s*key|token|credential|private\s+key)\b/i;
    }
    if (actionType === "permission_change") {
      return /\b(?:change|changed|grant|granted|revoke|revoked|add|added|remove|removed)\s+(?:admin\s+)?(?:permission|role|access|privilege)s?\b/i;
    }

    const escaped = actionType.replace(/[.*+?^${}()|[\]\\]/g, "\\$&").replace(/_/g, "[_\\s-]");
    return new RegExp(`\\b${escaped}\\b`, "i");
  }

  const escaped = normalized.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return new RegExp(`\\b${escaped}\\b`, "i");
}

function resultMentionsForbiddenAction(packet: TaskPacket): boolean {
  const resultText = `${packet.result?.summary ?? ""}\n${packet.result?.details ?? ""}`.toLowerCase();

  return packet.forbidden_actions.some((action) => forbiddenActionPattern(action).test(resultText));
}

function addSchemaIssues(packet: TaskPacket, issues: string[]): void {
  const parsed = taskPacketSchema.safeParse(packet);

  if (!parsed.success) {
    issues.push(...parsed.error.issues.map((issue) => issue.message));
  }
}

export function validateTaskPacketForCompletion(
  packet: TaskPacket,
  context: EvidenceValidationContext = {},
): ValidationResult {
  const issues: string[] = [];

  addSchemaIssues(packet, issues);

  if (packet.task_type === "unknown" && !hasManualReviewRequirement(packet)) {
    issues.push("unknown task requires manual review");
  }

  if (packet.required_approval && !packet.approval_reason) {
    issues.push("required approval requires approval_reason");
  }

  if (packet.risk_level === "high" && ["queued", "triaging"].includes(packet.status)) {
    issues.push("high risk task must wait for approval or be in a post-approval state");
  }

  if (!packet.report_format.include_evidence) {
    issues.push("report_format.include_evidence must be true for evidence-producing tasks");
  }

  if (packet.status === "completed" && packet.evidence.length === 0) {
    issues.push("completed task requires at least one evidence item");
  }

  if (
    packet.status === "completed" &&
    packet.result?.outcome &&
    !["passed", "passed_with_warnings"].includes(packet.result.outcome)
  ) {
    issues.push("completed task requires a passed worker outcome");
  }

  for (const evidence of packet.evidence) {
    if (evidence.task_id !== packet.task_id) {
      issues.push(`evidence ${evidence.evidence_id} task_id does not match packet task_id`);
    }

    const evidenceResult = validateEvidenceItem(evidence, context);
    if (!evidenceResult.valid) {
      issues.push(...evidenceResult.issues);
    }
  }

  if (packet.status === "completed" && packet.evidence.length > 0 && !hasRequiredEvidence(packet, context)) {
    issues.push("completed task requires passing evidence for every required verification");
  }

  if (
    packet.status === "completed" &&
    packet.evidence.some((evidence) => evidence.status === "failed") &&
    packet.blockers.length === 0 &&
    (packet.result?.risks?.length ?? 0) === 0
  ) {
    issues.push("failed required verification requires a blocker or reported risk");
  }

  if (packet.status === "completed" && resultMentionsForbiddenAction(packet)) {
    issues.push("worker result reports a forbidden action");
  }

  return { valid: issues.length === 0, issues };
}
