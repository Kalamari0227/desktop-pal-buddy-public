import { describe, expect, it } from "vitest";
import {
  buildRiskContextRefs,
  classifyRiskGatewayTask,
  createRiskGatewayDraft,
  inferMaterialFromRisk,
  type BusinessRiskRouteInput,
} from "./riskGatewayRouting";

const deliveryRisk: BusinessRiskRouteInput = {
  id: "r1",
  customer: "현대자동차",
  category: "delivery",
  title: "3월 납기 지연 리스크",
  description: "열연 라인 정비로 인해 GA강판 3월 납기 2주 지연 가능성",
  severity: "critical",
  dueDate: "2025-03-20",
  impact: "약 1,200톤 영향",
};

describe("risk Gateway routing", () => {
  it("routes delivery delay risks into delivery delay task packets", () => {
    const draft = createRiskGatewayDraft(deliveryRisk);

    expect(classifyRiskGatewayTask(deliveryRisk)).toBe("delivery_delay_risk_check");
    expect(inferMaterialFromRisk(deliveryRisk)).toBe("GA강판");
    expect(draft.packet).toMatchObject({
      task_type: "delivery_delay_risk_check",
      risk_level: "medium",
      required_approval: false,
    });
    expect(draft.packet?.verification_requirements.map((requirement) => requirement.type)).toEqual([
      "order_status",
      "delivery_status",
      "risk_assessment",
    ]);
    expect(draft.packet?.context_refs).toEqual(expect.arrayContaining([
      { type: "customer_account", label: "customer", value: "현대자동차" },
      { type: "material_item", label: "material", value: "GA강판" },
      { type: "due_date", label: "due date", value: "2025-03-20" },
    ]));
  });

  it("routes stock shortage risks into urgent material risk packets", () => {
    const shortageRisk: BusinessRiskRouteInput = {
      id: "r6",
      customer: "GM Korea",
      category: "delivery",
      title: "DP강 공급 부족 가능성",
      description: "수요 확대 대비 DP780 생산 능력 부족. 설비 투자 미확정",
      severity: "medium",
      impact: "월 300톤 부족 예상",
    };

    const draft = createRiskGatewayDraft(shortageRisk);

    expect(classifyRiskGatewayTask(shortageRisk)).toBe("urgent_material_risk_assessment");
    expect(inferMaterialFromRisk(shortageRisk)).toBe("DP780");
    expect(draft.packet).toMatchObject({
      task_type: "urgent_material_risk_assessment",
      risk_level: "medium",
      status: "queued",
    });
    expect(draft.packet?.verification_requirements.map((requirement) => requirement.type)).toEqual([
      "inventory_status",
      "delivery_status",
      "risk_assessment",
    ]);
  });

  it("routes non-delivery risk items into the generic business risk review", () => {
    const priceRisk: BusinessRiskRouteInput = {
      id: "r3",
      customer: "기아",
      category: "price",
      title: "2분기 가격 재협상 압박",
      description: "기아 구매팀에서 3% 인하 재요구. 경쟁사 가격 인하 언급",
      severity: "high",
      impact: "연간 약 15억원 매출 영향",
    };

    const draft = createRiskGatewayDraft(priceRisk);

    expect(classifyRiskGatewayTask(priceRisk)).toBe("business_risk_review");
    expect(draft.packet?.task_type).toBe("business_risk_review");
    expect(draft.packet?.forbidden_actions).toContain("do not change price or customer terms");
    expect(draft.packet?.verification_requirements.map((requirement) => requirement.type)).toEqual([
      "risk_assessment",
      "manual_review",
    ]);
  });

  it("preserves risk metadata as context refs", () => {
    expect(buildRiskContextRefs(deliveryRisk)).toEqual(expect.arrayContaining([
      { type: "user_note", label: "risk id", value: "r1" },
      { type: "user_note", label: "category", value: "delivery" },
      { type: "user_note", label: "severity", value: "critical" },
      { type: "user_note", label: "impact", value: "약 1,200톤 영향" },
    ]));
  });
});
