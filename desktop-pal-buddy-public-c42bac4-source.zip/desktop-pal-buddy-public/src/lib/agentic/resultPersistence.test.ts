import { describe, expect, it } from "vitest";
import {
  agentResultRowToWorkerResultIntake,
  latestAgentResultRow,
  workerResultToAgentResultInsert,
  type AgentResultRow,
} from "./resultPersistence";
import type { Blocker, RetentionDecision } from "./types";

const blocker: Blocker = {
  blocker_id: "blocker-1",
  type: "missing_context",
  summary: "Need latest export.",
  requires_user_action: true,
};

const retentionDecision: RetentionDecision = {
  task_id: "workboard-task-1",
  save_decision: "workboard",
  reason: "Follow-up remains active.",
  requires_user_approval: true,
};

const persisted = workerResultToAgentResultInsert({
  workboard_task_id: "00000000-0000-0000-0000-000000000001",
  packet_task_id: "workboard-task-1",
  created_at: "2026-07-04T00:10:00.000Z",
  result: {
    outcome: "passed_with_warnings",
    summary: "Delivery risk is medium.",
    details: "Buffer is narrow.",
    changed_paths: ["src/example.ts"],
    checked_refs: [{ type: "external_link", label: "Result ref 1", value: "https://example.com" }],
    risks: ["Maintenance buffer is narrow."],
  },
  blockers: [blocker],
  next_action: "Ask logistics for latest export.",
  retention_decision: retentionDecision,
});

const row: AgentResultRow = {
  id: "result-row-1",
  owner_id: "user-1",
  task_id: persisted.task_id,
  packet_task_id: persisted.packet_task_id,
  outcome: persisted.outcome,
  summary: persisted.summary,
  details: persisted.details ?? null,
  changed_paths: persisted.changed_paths ?? [],
  checked_refs: persisted.checked_refs ?? [],
  risks: persisted.risks ?? [],
  blockers: persisted.blockers ?? [],
  next_action: persisted.next_action ?? null,
  retention_decision: persisted.retention_decision ?? null,
  created_at: persisted.created_at ?? "2026-07-04T00:10:00.000Z",
};

describe("result persistence mapping", () => {
  it("maps a worker result intake into an agent_results insert row", () => {
    expect(workerResultToAgentResultInsert({
      workboard_task_id: "00000000-0000-0000-0000-000000000001",
      packet_task_id: "workboard-task-1",
      created_at: "2026-07-04T00:10:00.000Z",
      result: {
        outcome: "passed_with_warnings",
        summary: "Delivery risk is medium.",
        details: "Buffer is narrow.",
        changed_paths: ["src/example.ts"],
        checked_refs: [{ type: "external_link", label: "Result ref 1", value: "https://example.com" }],
        risks: ["Maintenance buffer is narrow."],
      },
      blockers: [blocker],
      next_action: "Ask logistics for latest export.",
      retention_decision: retentionDecision,
    })).toEqual({
      task_id: "00000000-0000-0000-0000-000000000001",
      packet_task_id: "workboard-task-1",
      outcome: "passed_with_warnings",
      summary: "Delivery risk is medium.",
      details: "Buffer is narrow.",
      changed_paths: ["src/example.ts"],
      checked_refs: [{ type: "external_link", label: "Result ref 1", value: "https://example.com" }],
      risks: ["Maintenance buffer is narrow."],
      blockers: row.blockers,
      next_action: "Ask logistics for latest export.",
      retention_decision: row.retention_decision,
      created_at: "2026-07-04T00:10:00.000Z",
    });
  });

  it("maps a database row back into a worker result intake record", () => {
    expect(agentResultRowToWorkerResultIntake(row)).toMatchObject({
      result: {
        outcome: "passed_with_warnings",
        summary: "Delivery risk is medium.",
        changed_paths: ["src/example.ts"],
      },
      blockers: row.blockers,
      next_action: "Ask logistics for latest export.",
      retention_decision: row.retention_decision,
    });
  });

  it("selects the latest persisted result by creation time", () => {
    expect(latestAgentResultRow([
      { ...row, id: "older", created_at: "2026-07-04T00:01:00.000Z" },
      { ...row, id: "newer", created_at: "2026-07-04T00:02:00.000Z" },
    ])?.id).toBe("newer");
  });
});
