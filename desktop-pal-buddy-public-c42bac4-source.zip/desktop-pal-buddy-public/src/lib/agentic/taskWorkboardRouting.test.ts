import { describe, expect, it } from "vitest";
import {
  buildTaskWorkboardContextRefs,
  classifyTaskWorkboardTask,
  createTaskWorkboardDraft,
  inferMaterialFromTask,
  packetTaskIdForWorkboardTask,
  type TaskWorkboardRouteInput,
} from "./taskWorkboardRouting";

const deliveryTask: TaskWorkboardRouteInput = {
  id: "task-1",
  title: "3월 납기 지연 리스크",
  description: "열연 라인 정비로 인해 GA강판 3월 납기 2주 지연 가능성",
  source: "risk",
  source_id: "risk-1",
  severity: "critical",
  customer: "현대자동차",
  category: "delivery",
  status: "pending",
  created_at: "2026-07-04T00:00:00.000Z",
};

describe("task workboard Gateway routing", () => {
  it("routes delivery workboard tasks into delivery delay task packets", () => {
    const draft = createTaskWorkboardDraft(deliveryTask);

    expect(classifyTaskWorkboardTask(deliveryTask)).toBe("delivery_delay_risk_check");
    expect(inferMaterialFromTask(deliveryTask)).toBe("GA강판");
    expect(draft.packet).toMatchObject({
      task_id: "workboard-task-1",
      task_type: "delivery_delay_risk_check",
      risk_level: "medium",
      status: "queued",
      required_approval: false,
    });
    expect(draft.packet?.verification_requirements.map((requirement) => requirement.type)).toEqual([
      "order_status",
      "delivery_status",
      "risk_assessment",
    ]);
    expect(draft.packet?.forbidden_actions).toContain("do not change delivery schedule");
  });

  it("routes inventory and urgent material tasks before generic business risk review", () => {
    const inventoryDraft = createTaskWorkboardDraft({
      id: "task-2",
      title: "GA 강판 재고 확인",
      description: "울산 창고 가용 재고 확인 필요",
      customer: "기아",
      status: "pending",
    });

    expect(inventoryDraft.packet?.task_type).toBe("inventory_check");
    expect(inventoryDraft.packet?.verification_requirements.map((requirement) => requirement.type)).toEqual([
      "inventory_status",
      "manual_review",
    ]);

    const urgentDraft = createTaskWorkboardDraft({
      id: "task-3",
      title: "DP강 공급 부족 가능성",
      description: "긴급 자재 요청이 들어왔고 재고 부족 가능성이 높음",
      customer: "GM Korea",
      status: "pending",
    });

    expect(urgentDraft.packet?.task_type).toBe("urgent_material_risk_assessment");
    expect(urgentDraft.packet?.verification_requirements.map((requirement) => requirement.type)).toEqual([
      "inventory_status",
      "delivery_status",
      "risk_assessment",
    ]);
  });

  it("routes customer response tasks without allowing external sending", () => {
    const draft = createTaskWorkboardDraft({
      id: "task-4",
      title: "고객 납기 문의 답장",
      description: "기아 구매팀에 납기 지연 문의 답장 초안 필요",
      customer: "기아",
      status: "pending",
    });

    expect(draft.packet?.task_type).toBe("customer_reply_draft");
    expect(draft.packet?.forbidden_actions).toContain("do not send external message");
    expect(draft.handoff_markdown).toContain("# Codex Task Packet");
  });

  it("preserves workboard metadata as context refs", () => {
    expect(buildTaskWorkboardContextRefs(deliveryTask)).toEqual(expect.arrayContaining([
      { type: "user_note", label: "작업 ID", value: "task-1" },
      { type: "customer_account", label: "고객", value: "현대자동차" },
      { type: "material_item", label: "자재", value: "GA강판" },
      { type: "user_note", label: "출처 ID", value: "risk-1" },
    ]));
  });

  it("reuses the original Gateway packet id for Gateway-created workboard tasks", () => {
    const gatewayTask: TaskWorkboardRouteInput = {
      id: "task-gateway-1",
      title: "현대자동차 GA 강판 긴급재 위험도 따져줘",
      description: "Gateway 대화에서 생성된 업무",
      source: "gateway",
      source_id: "task-urgent_material_risk_assessment-20260704",
      severity: "medium",
      customer: "현대자동차",
      category: "delivery",
      status: "pending",
    };

    const draft = createTaskWorkboardDraft(gatewayTask);

    expect(packetTaskIdForWorkboardTask(gatewayTask)).toBe("task-urgent_material_risk_assessment-20260704");
    expect(draft.packet?.task_id).toBe("task-urgent_material_risk_assessment-20260704");
    expect(draft.packet?.context_refs).toEqual(expect.arrayContaining([
      { type: "user_note", label: "출처", value: "gateway" },
      { type: "user_note", label: "출처 ID", value: "task-urgent_material_risk_assessment-20260704" },
    ]));
  });
});
