import { describe, expect, it } from "vitest";
import { createTaskPacket } from "./taskTemplates";
import { parseManualCodexResult } from "./manualCodexResultIntake";

const packet = createTaskPacket({
  task_id: "workboard-task-1",
  created_at: "2026-07-04T00:00:00.000Z",
  created_by: "test",
  task_type: "delivery_delay_risk_check",
  request_summary: "Check delivery risk.",
  raw_user_request: "Check delivery risk.",
  desired_outcome: "Delivery risk with evidence and next action.",
});

describe("manual Codex result intake", () => {
  it("parses pasted result fields into WorkerResult, evidence, blockers, and retention decision", () => {
    const intake = parseManualCodexResult({
      packet,
      created_at: "2026-07-04T00:10:00.000Z",
      pasted_result: [
        "## Conclusion",
        "Delivery risk is medium and can be monitored.",
        "",
        "## Evidence",
        "- [passed] Order SO-1001 is allocated and waiting for shipment.",
        "- [passed] Delivery ETA remains Friday.",
        "- [warning] Risk assessment: maintenance buffer is narrow.",
        "",
        "## Blockers",
        "- Missing latest warehouse export.",
        "",
        "## Next Action",
        "Ask logistics for the latest warehouse export.",
        "",
        "## Retention",
        "Save to Workboard as a follow-up.",
      ].join("\n"),
    });

    expect(intake.validation.valid).toBe(true);
    expect(intake.result).toMatchObject({
      outcome: "blocked",
      summary: "Delivery risk is medium and can be monitored.",
      risks: undefined,
    });
    expect(intake.evidence.map((item) => item.evidence_type)).toEqual([
      "order_status",
      "delivery_schedule",
      "risk_assessment",
    ]);
    expect(intake.evidence[0]).toMatchObject({
      evidence_id: "workboard-task-1-evidence-1",
      task_id: "workboard-task-1",
      source: { system: "erp", ref: "manual-codex-result" },
      status: "passed",
    });
    expect(intake.blockers).toEqual([
      expect.objectContaining({
        blocker_id: "workboard-task-1-blocker-1",
        type: "missing_context",
        requires_user_action: true,
      }),
    ]);
    expect(intake.next_action).toBe("Ask logistics for the latest warehouse export.");
    expect(intake.retention_decision).toMatchObject({
      save_decision: "workboard",
      requires_user_approval: true,
    });
  });

  it("requires evidence when a pasted result claims a passed outcome", () => {
    const intake = parseManualCodexResult({
      packet,
      pasted_result: [
        "Conclusion: Completed successfully.",
        "Next Action: No action needed.",
      ].join("\n"),
    });

    expect(intake.result.outcome).toBe("passed");
    expect(intake.evidence).toEqual([]);
    expect(intake.validation.valid).toBe(false);
    expect(intake.validation.issues).toContain("passed worker result requires at least one evidence item");
  });

  it("rejects pasted result text that contains sensitive content", () => {
    const intake = parseManualCodexResult({
      packet,
      pasted_result: [
        "Conclusion: Completed successfully.",
        "Evidence:",
        "- npm test passed with API_KEY=secret-value",
      ].join("\n"),
    });

    expect(intake.validation.valid).toBe(false);
    expect(intake.validation.issues).toContain("pasted result contains sensitive content");
  });
});
