import { describe, expect, it } from "vitest";
import { createGatewayCodexDraft } from "./gatewayCodexAgent";
import { gatewayPacketToWorkboardTaskInsert } from "./gatewayWorkboardIntake";

describe("Gateway workboard intake", () => {
  it("maps a Gateway Task Packet into a workboard task insert payload", () => {
    const packet = createGatewayCodexDraft({
      raw_user_request: "현대자동차 GA 강판 긴급재 위험도 따져줘",
      context_refs: [
        { type: "customer_account", label: "고객", value: "현대자동차" },
        { type: "material_item", label: "자재", value: "GA 강판" },
      ],
      created_at: "2026-07-04T00:00:00.000Z",
    }).packet;

    expect(packet).not.toBeNull();
    expect(gatewayPacketToWorkboardTaskInsert({
      packet: packet!,
      workboard_task_id: "00000000-0000-0000-0000-000000000001",
      created_at: "2026-07-04T00:01:00.000Z",
    })).toMatchObject({
      id: "00000000-0000-0000-0000-000000000001",
      title: "현대자동차 GA 강판 긴급재 위험도 따져줘",
      source: "gateway",
      source_id: packet!.task_id,
      severity: "medium",
      customer: "현대자동차",
      category: "delivery",
      status: "pending",
      created_at: "2026-07-04T00:01:00.000Z",
      updated_at: "2026-07-04T00:01:00.000Z",
    });
  });

  it("preserves approval-gated Gateway tasks as pending high-severity workboard tasks", () => {
    const packet = createGatewayCodexDraft({
      raw_user_request: "staging DB migration 실행해줘",
      created_at: "2026-07-04T00:00:00.000Z",
    }).packet;

    expect(packet).not.toBeNull();
    const insert = gatewayPacketToWorkboardTaskInsert({
      packet: packet!,
      workboard_task_id: "00000000-0000-0000-0000-000000000002",
      created_at: "2026-07-04T00:01:00.000Z",
    });

    expect(insert).toMatchObject({
      source: "gateway",
      source_id: packet!.task_id,
      severity: "high",
      category: "quality",
      status: "pending",
    });
    expect(insert.description).toContain("승인 필요: Approval required for: database_migration");
  });
});
