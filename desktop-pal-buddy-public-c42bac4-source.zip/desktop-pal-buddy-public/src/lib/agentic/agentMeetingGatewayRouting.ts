import { z } from "zod";
import { classifyTaskType } from "./riskClassifier";
import { createGatewayCodexDraft, type GatewayCodexDraft } from "./gatewayCodexAgent";
import type { ContextRef, DefaultTaskType, TaskType } from "./types";

export interface AgentMeetingActionItem {
  title: string;
  description?: string | null;
  severity?: string | null;
  category?: string | null;
}

export interface AgentMeetingGatewayDraftInput {
  action_item: AgentMeetingActionItem;
  topic?: string | null;
  meeting_id?: string | null;
  action_id?: string | null;
  /** Positional metadata is accepted for compatibility but is never part of packet identity. */
  index?: number;
  created_at?: string;
}

const DEFAULT_MEETING_TASK_TYPE: DefaultTaskType = "business_risk_review";
const MAX_EXTRACTION_LENGTH = 50_000;
const MAX_ACTION_ITEMS = 25;

const agentMeetingActionItemSchema = z.object({
  title: z.string().trim().min(1).max(200),
  description: z.string().trim().max(2_000).optional(),
  severity: z.enum(["high", "medium", "low"]).optional(),
  category: z.enum(["delivery", "quality", "price"]).optional(),
}).strict();

const agentMeetingActionItemsSchema = z.array(agentMeetingActionItemSchema).min(1).max(MAX_ACTION_ITEMS);

export type AgentMeetingActionParseFailure =
  | "missing_array"
  | "malformed_json"
  | "empty_array"
  | "invalid_actions";

export type AgentMeetingActionParseResult =
  | { readonly ok: true; readonly action_items: readonly AgentMeetingActionItem[] }
  | { readonly ok: false; readonly reason: AgentMeetingActionParseFailure };

function compact(value: string): string {
  return value.replace(/\s+/g, " ").trim();
}

function stableHash(value: string): string {
  const hash = Array.from(value).reduce((sum, char) => ((sum * 31) + char.charCodeAt(0)) % 0xfffffff, 7);
  return hash.toString(16);
}

function normalizeIdentityPart(value?: string | null): string {
  return compact(value ?? "").toLowerCase();
}

export function parseAgentMeetingActionItems(extracted: string): AgentMeetingActionParseResult {
  if (extracted.length > MAX_EXTRACTION_LENGTH) {
    return { ok: false, reason: "invalid_actions" };
  }

  const jsonMatch = extracted.match(/\[[\s\S]*\]/);
  if (!jsonMatch) {
    return { ok: false, reason: "missing_array" };
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(jsonMatch[0]);
  } catch (error) {
    if (error instanceof SyntaxError) {
      return { ok: false, reason: "malformed_json" };
    }
    throw error;
  }

  if (Array.isArray(parsed) && parsed.length === 0) {
    return { ok: false, reason: "empty_array" };
  }

  const result = agentMeetingActionItemsSchema.safeParse(parsed);
  return result.success
    ? { ok: true, action_items: result.data }
    : { ok: false, reason: "invalid_actions" };
}

function isDefaultTaskType(taskType: TaskType): taskType is DefaultTaskType {
  return taskType !== "unknown" && taskType !== "repo_doc_update" && taskType !== "general_research";
}

function fallbackTaskTypeForCategory(category?: string | null): DefaultTaskType {
  const normalized = category?.toLowerCase().trim();

  if (normalized === "delivery") {
    return "delivery_delay_risk_check";
  }

  if (normalized === "quality" || normalized === "price") {
    return "business_risk_review";
  }

  return DEFAULT_MEETING_TASK_TYPE;
}

export function classifyAgentMeetingActionItem(input: AgentMeetingActionItem): DefaultTaskType {
  const text = compact([input.title, input.description, input.category].filter(Boolean).join(" "));
  const taskType = classifyTaskType(text);

  if (isDefaultTaskType(taskType)) {
    return taskType;
  }

  return fallbackTaskTypeForCategory(input.category);
}

export function buildAgentMeetingContextRefs(input: AgentMeetingGatewayDraftInput): ContextRef[] {
  const refs: ContextRef[] = [];
  const topic = input.topic?.trim();
  const category = input.action_item.category?.trim();
  const severity = input.action_item.severity?.trim();

  if (topic) {
    refs.push({ type: "user_note", label: "회의 주제", value: topic });
  }
  if (category) {
    refs.push({ type: "user_note", label: "회의 액션 카테고리", value: category });
  }
  if (severity) {
    refs.push({ type: "user_note", label: "회의 우선순위", value: severity });
  }

  return refs;
}

export function createAgentMeetingGatewayDraft(input: AgentMeetingGatewayDraftInput): GatewayCodexDraft {
  const title = compact(input.action_item.title);
  const description = compact(input.action_item.description ?? "");
  const category = compact(input.action_item.category ?? "");
  const severity = compact(input.action_item.severity ?? "");
  const taskType = classifyAgentMeetingActionItem(input.action_item);
  const contextRefs = buildAgentMeetingContextRefs(input);
  const stableActionIdentity = [
    input.meeting_id || input.topic,
    input.action_id || "",
    title,
    description,
    category,
    severity,
  ].map(normalizeIdentityPart).join("|");
  // Upstream currently supplies no durable action id; identical content intentionally shares lineage.
  const taskId = `meeting-${stableHash(stableActionIdentity)}`;
  const rawUserRequest = description ? `${title}: ${description}` : title;

  return createGatewayCodexDraft({
    raw_user_request: rawUserRequest,
    context_refs: contextRefs,
    created_at: input.created_at,
    created_by: "agent-meeting",
    task_id: taskId,
    codex_suggestion: {
      task_type: taskType,
      request_summary: rawUserRequest,
      desired_outcome: "Track the meeting action as a Gateway-backed Workboard task with evidence, blockers, risks, and next action.",
      context_refs: contextRefs,
      reasoning_notes: ["Meeting action item was normalized into a Gateway Task Packet."],
    },
  });
}
