import { describe, expect, it } from "vitest";
import { demoStrategyVersions } from "@/data/demoStrategyCatalog";
import { createDemoStrategyRows } from "@/data/demoStrategyData";
import { agentEvidenceRowsToEvidenceItems } from "./evidencePersistence";
import { gatewayPacketToWorkboardTaskInsert } from "./gatewayWorkboardIntake";
import { resolveDemoTaskDraft, withDemoTaskPacket } from "./demoTaskPackets";
import { createStrategyGatewayDraft } from "./strategy";
import { validateWorkboardStatusGate } from "./taskCompletionGate";
import { createTaskWorkboardDraft } from "./taskWorkboardRouting";
import type { StrategyRef } from "./types";

const refV1: StrategyRef = {
  strategy_id: "delivery-risk-early-warning",
  strategy_version_id: "delivery-risk-early-warning-v1",
};

function linkedTask() {
  const draft = createStrategyGatewayDraft({
    raw_user_request: "가상 고객 납기 지연 확인해줘",
    created_at: "2026-09-18T01:00:00.000Z",
  }, refV1, demoStrategyVersions);
  const row = gatewayPacketToWorkboardTaskInsert({
    packet: draft.packet!,
    workboard_task_id: "demo-linked-task",
    created_at: "2026-09-18T01:01:00.000Z",
  });
  return {
    draft,
    linked: withDemoTaskPacket({
      ...row,
      id: row.id!,
      title: row.title,
    }, draft.packet!),
  };
}

describe("demo task packet snapshots", () => {
  it("preserves the original request and policy when display fields change", () => {
    const { linked } = linkedTask();
    const resolved = resolveDemoTaskDraft({ ...linked, title: "수정된 표시 제목" });

    expect(resolved.packet?.raw_user_request).toBe("가상 고객 납기 지연 확인해줘");
    expect(resolved.packet?.forbidden_actions).toContain("do not change delivery schedule");
    expect(resolved.packet?.strategy_ref).toEqual(refV1);
  });

  it("clones packet snapshots on write and every read", () => {
    const { draft, linked } = linkedTask();
    draft.packet!.raw_user_request = "호출자가 바꾼 요청";
    const first = resolveDemoTaskDraft(linked);
    first.packet!.raw_user_request = "첫 읽기에서 바꾼 요청";
    const second = resolveDemoTaskDraft(linked);

    expect(second.packet?.raw_user_request).toBe("가상 고객 납기 지연 확인해줘");
  });

  it("fails closed when required metadata loses its packet", () => {
    const { linked } = linkedTask();
    const resolved = resolveDemoTaskDraft({ ...linked, demo_intake_packet: undefined });

    expect(resolved.bridge_status).toBe("needs_manual_review");
    expect(resolved.packet).toBeNull();
    expect(resolved.handoff_markdown).toBe("");
  });

  it("fails closed for corrupt, dangling, or mismatched packet metadata", () => {
    const { linked } = linkedTask();
    const corrupt = resolveDemoTaskDraft({ ...linked, demo_intake_packet: { task_id: "broken" } });
    const dangling = resolveDemoTaskDraft({ ...linked, demo_intake_required: undefined });
    const mismatched = resolveDemoTaskDraft({ ...linked, source_id: "another-packet" });

    expect(corrupt.packet).toBeNull();
    expect(dangling.packet).toBeNull();
    expect(mismatched.packet).toBeNull();
  });

  it("fails closed when the stored strategy membership no longer validates", () => {
    const { linked } = linkedTask();
    const resolved = resolveDemoTaskDraft({
      ...linked,
      demo_intake_packet: {
        ...linked.demo_intake_packet,
        strategy_ref: { strategy_id: "another-strategy", strategy_version_id: refV1.strategy_version_id },
      },
    });

    expect(resolved.packet).toBeNull();
    expect(resolved.blocked_reason).toContain("전략");
  });

  it("keeps legacy rows on the existing routing path", () => {
    const task = {
      id: "legacy-task",
      title: "가상 고객 납기 지연",
      description: "납기 상태 확인",
      category: "delivery",
      created_at: "2026-09-18T01:00:00.000Z",
    };

    expect(resolveDemoTaskDraft(task)).toEqual(createTaskWorkboardDraft(task));
  });

  it("builds a completed v1 fixture that passes the real evidence gate", () => {
    const rows = createDemoStrategyRows();
    const task = rows.tasks.find((row) => row.status === "done")!;
    const draft = resolveDemoTaskDraft(task);
    const evidence = agentEvidenceRowsToEvidenceItems(rows.evidence.filter((row) => row.task_id === task.id));
    const result = rows.results.find((row) => row.task_id === task.id)!;

    expect(validateWorkboardStatusGate({
      packet: draft.packet!,
      current_status: "in_progress",
      target_status: "done",
      evidence,
      result_summary: result.summary,
      outcome: result.outcome as "passed",
    }).allowed).toBe(true);
  });

  it("builds a pending v2 fixture without borrowed evidence", () => {
    const rows = createDemoStrategyRows();
    const task = rows.tasks.find((row) => row.status === "pending")!;
    const draft = resolveDemoTaskDraft(task);

    expect(draft.packet?.strategy_ref?.strategy_version_id).toBe("delivery-risk-early-warning-v2");
    expect(rows.evidence.filter((row) => row.task_id === task.id)).toEqual([]);
    expect(rows.results.filter((row) => row.task_id === task.id)).toEqual([]);
  });
});
