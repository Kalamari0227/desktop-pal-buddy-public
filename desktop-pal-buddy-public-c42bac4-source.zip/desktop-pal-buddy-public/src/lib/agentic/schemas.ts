import { z } from "zod";
import {
  APPROVAL_ACTION_TYPES,
  BLOCKER_TYPES,
  CONTEXT_REF_TYPES,
  EVIDENCE_SOURCE_SYSTEMS,
  EVIDENCE_STATUSES,
  EVIDENCE_TYPES,
  EVENT_SEVERITIES,
  REPORT_DETAIL_LEVELS,
  RETENTION_SAVE_DECISIONS,
  RISK_LEVELS,
  TASK_STATUSES,
  TASK_TYPES,
  VERIFICATION_TYPES,
  WORKER_EVENT_TYPES,
  WORKER_OUTCOMES,
  type ApprovalPolicy,
  type Blocker,
  type ContextRef,
  type EvidenceItem,
  type EvidenceSource,
  type ExecutionStep,
  type ReportFormat,
  type RetentionDecision,
  type Strategy,
  type StrategyRef,
  type StrategyVersion,
  type TaskPacket,
  type VerificationRequirement,
  type WorkerEvent,
  type WorkerResult,
} from "./types";

export const taskTypeSchema = z.enum(TASK_TYPES);
export const contextRefTypeSchema = z.enum(CONTEXT_REF_TYPES);
export const riskLevelSchema = z.enum(RISK_LEVELS);
export const taskStatusSchema = z.enum(TASK_STATUSES);
export const verificationTypeSchema = z.enum(VERIFICATION_TYPES);
export const reportDetailLevelSchema = z.enum(REPORT_DETAIL_LEVELS);
export const workerOutcomeSchema = z.enum(WORKER_OUTCOMES);
export const blockerTypeSchema = z.enum(BLOCKER_TYPES);
export const retentionSaveDecisionSchema = z.enum(RETENTION_SAVE_DECISIONS);
export const evidenceTypeSchema = z.enum(EVIDENCE_TYPES);
export const evidenceSourceSystemSchema = z.enum(EVIDENCE_SOURCE_SYSTEMS);
export const evidenceStatusSchema = z.enum(EVIDENCE_STATUSES);
export const workerEventTypeSchema = z.enum(WORKER_EVENT_TYPES);
export const eventSeveritySchema = z.enum(EVENT_SEVERITIES);
export const approvalActionTypeSchema = z.enum(APPROVAL_ACTION_TYPES);

const meaningfulText = z.string().trim().min(1);

export const strategySchema = z.object({
  strategy_id: meaningfulText,
  title: meaningfulText,
}).strict() satisfies z.ZodType<Strategy>;

export const strategyVersionSchema = z.object({
  strategy_version_id: meaningfulText,
  strategy_id: meaningfulText,
  version: z.number().int().positive(),
  objective: meaningfulText,
  review_question: meaningfulText,
}).strict() satisfies z.ZodType<StrategyVersion>;

export const strategyRefSchema = z.object({
  strategy_id: meaningfulText,
  strategy_version_id: meaningfulText,
}).strict() satisfies z.ZodType<StrategyRef>;

export const contextRefSchema = z.object({
  type: contextRefTypeSchema,
  label: z.string().min(1),
  value: z.string().min(1),
}) satisfies z.ZodType<ContextRef>;

export const executionStepSchema = z.object({
  step_id: z.string().min(1),
  summary: z.string().min(1),
  expected_evidence: z.string().min(1).optional(),
}) satisfies z.ZodType<ExecutionStep>;

export const verificationRequirementSchema = z.object({
  type: verificationTypeSchema,
  required: z.boolean(),
  command_or_source: z.string().min(1).optional(),
}) satisfies z.ZodType<VerificationRequirement>;

export const reportFormatSchema = z.object({
  include_summary: z.boolean(),
  include_evidence: z.boolean(),
  include_blockers: z.boolean(),
  include_next_action: z.boolean(),
  max_detail_level: reportDetailLevelSchema,
}) satisfies z.ZodType<ReportFormat>;

export const blockerSchema = z.object({
  blocker_id: z.string().min(1),
  type: blockerTypeSchema,
  summary: z.string().min(1),
  requires_user_action: z.boolean(),
  suggested_resolution: z.string().min(1).optional(),
}) satisfies z.ZodType<Blocker>;

export const workerResultSchema = z.object({
  outcome: workerOutcomeSchema,
  summary: z.string().min(1),
  details: z.string().min(1).optional(),
  changed_paths: z.array(z.string().min(1)).optional(),
  checked_refs: z.array(contextRefSchema).optional(),
  risks: z.array(z.string().min(1)).optional(),
}) satisfies z.ZodType<WorkerResult>;

export const retentionDecisionSchema = z.object({
  task_id: z.string().min(1),
  save_decision: retentionSaveDecisionSchema,
  reason: z.string().min(1),
  proposed_target: z
    .object({
      path: z.string().min(1).optional(),
      table: z.string().min(1).optional(),
      issue_id: z.string().min(1).optional(),
      skill_name: z.string().min(1).optional(),
    })
    .optional(),
  requires_user_approval: z.boolean(),
}) satisfies z.ZodType<RetentionDecision>;

export const evidenceSourceSchema = z.object({
  system: evidenceSourceSystemSchema,
  url: z.string().url().optional(),
  path: z.string().min(1).optional(),
  command: z.string().min(1).optional(),
  ref: z.string().min(1).optional(),
}) satisfies z.ZodType<EvidenceSource>;

export const evidenceItemSchema = z.object({
  evidence_id: z.string().min(1),
  task_id: z.string().min(1),
  created_at: z.string().datetime(),
  evidence_type: evidenceTypeSchema,
  summary: z.string().min(1),
  source: evidenceSourceSchema,
  status: evidenceStatusSchema,
  raw_excerpt: z.string().min(1).optional(),
  artifact_path: z.string().min(1).optional(),
}) satisfies z.ZodType<EvidenceItem>;

export const taskPacketSchema = z.object({
  task_id: z.string().min(1),
  created_at: z.string().datetime(),
  created_by: z.string().min(1),
  request_summary: z.string().min(1),
  raw_user_request: z.string().min(1),
  desired_outcome: z.string().min(1),
  task_type: taskTypeSchema,
  context_refs: z.array(contextRefSchema),
  strategy_ref: strategyRefSchema.optional(),
  risk_level: riskLevelSchema,
  required_approval: z.boolean(),
  approval_reason: z.string().min(1).optional(),
  forbidden_actions: z.array(z.string().min(1)),
  execution_plan: z.array(executionStepSchema),
  verification_requirements: z.array(verificationRequirementSchema),
  report_format: reportFormatSchema,
  status: taskStatusSchema,
  evidence: z.array(evidenceItemSchema),
  result: workerResultSchema.optional(),
  blockers: z.array(blockerSchema),
  next_action: z.string().min(1).optional(),
  retention_decision: retentionDecisionSchema.optional(),
}) satisfies z.ZodType<TaskPacket>;

export const workerEventSchema = z.object({
  event_id: z.string().min(1),
  task_id: z.string().min(1),
  created_at: z.string().datetime(),
  event_type: workerEventTypeSchema,
  message: z.string().min(1),
  evidence_ref_id: z.string().min(1).optional(),
  severity: eventSeveritySchema.optional(),
  requires_user_action: z.boolean().optional(),
}) satisfies z.ZodType<WorkerEvent>;

export const approvalPolicySchema = z.object({
  action_type: approvalActionTypeSchema,
  default_required: z.literal(true),
  approval_mode: z.literal("explicit_user_confirmation"),
  allowed_without_approval: z.literal(false).optional(),
}) satisfies z.ZodType<ApprovalPolicy>;
