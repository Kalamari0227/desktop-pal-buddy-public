import { createGatewayCodexDraft, type GatewayCodexDraft } from "./gatewayCodexAgent";
import { classifyTaskType } from "./riskClassifier";
import type { ContextRef, DefaultTaskType, TaskType } from "./types";

export interface TaskWorkboardRouteInput {
  id: string;
  title: string;
  description?: string | null;
  source?: string | null;
  source_id?: string | null;
  severity?: string | null;
  customer?: string | null;
  category?: string | null;
  status?: string | null;
  created_at?: string | null;
}

const DEFAULT_TASK_TYPES = new Set<TaskType>([
  "pr_verification",
  "supabase_staging_check",
  "document_to_prd",
  "inventory_check",
  "urgent_material_risk_assessment",
  "delivery_delay_risk_check",
  "business_risk_review",
  "customer_reply_draft",
  "order_status_check",
  "material_substitution_review",
]);

const MATERIAL_PATTERNS = [
  /GA\s*강판/i,
  /DP\s*780/i,
  /DP\s*강/i,
  /EV6\s*후속\s*모델\s*강판/i,
  /자동차\s*강판/i,
];

const TASK_COPY: Record<DefaultTaskType, { summary: string; outcome: string }> = {
  pr_verification: {
    summary: "PR 상태와 변경 범위를 확인하는 작업으로 정리합니다.",
    outcome: "병합 가능 여부, 확인 근거, 남은 리스크와 다음 행동을 보고합니다.",
  },
  supabase_staging_check: {
    summary: "Supabase 스테이징 상태를 변경 없이 확인하는 작업으로 정리합니다.",
    outcome: "상태, 경고, 막힌 항목과 다음 행동을 보고합니다.",
  },
  document_to_prd: {
    summary: "제공된 자료를 PRD 초안으로 정리하는 작업으로 분류합니다.",
    outcome: "PRD 초안, 열린 질문, 저장 제안과 검토 근거를 보고합니다.",
  },
  inventory_check: {
    summary: "자재와 고객 맥락 기준으로 재고 확인 작업을 준비합니다.",
    outcome: "사용 가능한 재고, 정보 신뢰도, 막힌 항목과 다음 행동을 보고합니다.",
  },
  urgent_material_risk_assessment: {
    summary: "긴급재 또는 공급 부족 가능성을 리스크 평가 작업으로 정리합니다.",
    outcome: "공급 제약, 일정 영향, 확인 근거와 안전한 다음 행동을 보고합니다.",
  },
  delivery_delay_risk_check: {
    summary: "납기 지연 가능성을 확인하는 작업으로 정리합니다.",
    outcome: "주문/납기 상태, 지연 영향, 리스크와 다음 행동을 보고합니다.",
  },
  business_risk_review: {
    summary: "업무 리스크를 읽기 전용으로 점검하는 작업으로 정리합니다.",
    outcome: "리스크 수준, 전제, 필요한 증거, 막힌 항목과 다음 행동을 보고합니다.",
  },
  customer_reply_draft: {
    summary: "고객 답장 초안을 만들되 외부 발송은 하지 않는 작업으로 정리합니다.",
    outcome: "검토 가능한 답장 초안, 전제, 민감 문구와 다음 행동을 보고합니다.",
  },
  order_status_check: {
    summary: "주문 상태를 변경 없이 확인하는 작업으로 정리합니다.",
    outcome: "현재 주문 상태, 확인 근거, 막힌 항목과 다음 행동을 보고합니다.",
  },
  material_substitution_review: {
    summary: "대체 자재 후보를 검토하는 작업으로 정리합니다.",
    outcome: "대체 가능성, 사양/공급 리스크, 필요한 증거와 다음 행동을 보고합니다.",
  },
};

function compact(value: string): string {
  return value.replace(/\s+/g, " ").trim();
}

function isDefaultTaskType(taskType: TaskType): taskType is DefaultTaskType {
  return DEFAULT_TASK_TYPES.has(taskType);
}

function textForTask(input: TaskWorkboardRouteInput): string {
  return compact([
    input.title,
    input.description ?? "",
    input.customer ?? "",
    input.category ?? "",
    input.severity ?? "",
    input.source ?? "",
  ].join(" "));
}

export function inferMaterialFromTask(input: Pick<TaskWorkboardRouteInput, "title" | "description">): string | undefined {
  const text = `${input.title} ${input.description ?? ""}`;
  const match = MATERIAL_PATTERNS.map((pattern) => text.match(pattern)?.[0]).find(Boolean);
  return match ? compact(match) : undefined;
}

export function classifyTaskWorkboardTask(input: TaskWorkboardRouteInput): DefaultTaskType {
  const text = textForTask(input);

  if (/(긴급재|긴급\s*자재|공급\s*부족|재고\s*부족|urgent material|expedite|hot\s*material|shortage)/i.test(text)) {
    return "urgent_material_risk_assessment";
  }

  if (/(대체재|대체품|대체\s*소재|substitution|substitute|alternate material|대체.*검토|대체.*추천)/i.test(text)) {
    return "material_substitution_review";
  }

  if (/(회신|답장|메일|이메일|customer reply|reply draft|response draft|고객.*대응|고객.*회신|고객.*답장)/i.test(text)) {
    return "customer_reply_draft";
  }

  if (/(재고|가용\s*재고|창고|inventory|stock|available stock|allocation)/i.test(text)) {
    return "inventory_check";
  }

  if (input.category === "delivery" || /(납기|출하|배송|지연|delivery|shipment|delay|late|eta)/i.test(text)) {
    return "delivery_delay_risk_check";
  }

  if (/(주문|오더|발주|수주|sales order|order status|\border\b)/i.test(text.toLowerCase())) {
    return "order_status_check";
  }

  const ruleTaskType = classifyTaskType(text);
  if (isDefaultTaskType(ruleTaskType)) {
    return ruleTaskType;
  }

  return "business_risk_review";
}

function requestForTask(input: TaskWorkboardRouteInput, taskType: DefaultTaskType, material?: string): string {
  const subject = compact([input.customer, material, input.title].filter(Boolean).join(" "));

  if (taskType === "inventory_check") {
    return `${subject} 재고 확인해줘`;
  }
  if (taskType === "urgent_material_risk_assessment") {
    return `${subject} 긴급재 위험도 따져줘`;
  }
  if (taskType === "delivery_delay_risk_check") {
    return `${subject} 납기 지연 리스크 확인해줘`;
  }
  if (taskType === "customer_reply_draft") {
    return `${subject} 고객 답장 초안 만들어줘`;
  }
  if (taskType === "order_status_check") {
    return `${subject} 주문 상태 확인해줘`;
  }
  if (taskType === "material_substitution_review") {
    return `${subject} 대체 자재 검토해줘`;
  }

  return `${subject} 업무 리스크 점검해줘`;
}

export function buildTaskWorkboardContextRefs(input: TaskWorkboardRouteInput): ContextRef[] {
  const material = inferMaterialFromTask(input);
  const refs: ContextRef[] = [
    { type: "user_note", label: "작업 ID", value: input.id },
    { type: "user_note", label: "작업 제목", value: input.title },
  ];

  if (input.description) {
    refs.push({ type: "user_note", label: "설명", value: input.description });
  }
  if (input.customer) {
    refs.push({ type: "customer_account", label: "고객", value: input.customer });
  }
  if (material) {
    refs.push({ type: "material_item", label: "자재", value: material });
  }
  if (input.category) {
    refs.push({ type: "user_note", label: "카테고리", value: input.category });
  }
  if (input.severity) {
    refs.push({ type: "user_note", label: "우선순위", value: input.severity });
  }
  if (input.status) {
    refs.push({ type: "user_note", label: "현재 상태", value: input.status });
  }
  if (input.source) {
    refs.push({ type: "user_note", label: "출처", value: input.source });
  }
  if (input.source_id) {
    refs.push({ type: "user_note", label: "출처 ID", value: input.source_id });
  }

  return refs;
}

export function packetTaskIdForWorkboardTask(input: Pick<TaskWorkboardRouteInput, "id" | "source" | "source_id">): string {
  if (input.source === "gateway" && input.source_id) {
    return input.source_id;
  }

  return `workboard-${input.id}`;
}

export function createTaskWorkboardDraft(input: TaskWorkboardRouteInput): GatewayCodexDraft {
  const taskType = classifyTaskWorkboardTask(input);
  const material = inferMaterialFromTask(input);
  const copy = TASK_COPY[taskType];

  return createGatewayCodexDraft({
    raw_user_request: requestForTask(input, taskType, material),
    context_refs: buildTaskWorkboardContextRefs(input),
    created_at: input.created_at ?? undefined,
    created_by: "tasks-workboard",
    task_id: packetTaskIdForWorkboardTask(input),
    codex_suggestion: {
      task_type: taskType,
      request_summary: copy.summary,
      desired_outcome: copy.outcome,
      reasoning_notes: [
        `작업 화면 항목: ${input.title}`,
        input.category ? `카테고리: ${input.category}` : "카테고리 없음",
        input.severity ? `우선순위: ${input.severity}` : "우선순위 없음",
      ],
    },
  });
}
