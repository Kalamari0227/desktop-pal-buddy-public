import type { Database } from "@/integrations/supabase/types";
import { detectApprovalActions } from "./approvalPolicy";
import type { ApprovalActionType, TaskPacket } from "./types";

export type ApprovalDecision = "approved" | "rejected";
export type AgentApprovalRow = Database["public"]["Tables"]["agent_approvals"]["Row"];
export type AgentApprovalInsert = Database["public"]["Tables"]["agent_approvals"]["Insert"];

export interface PersistApprovalInput {
  workboard_task_id: string;
  packet: TaskPacket;
  decision: ApprovalDecision;
  approved_scope?: string;
  created_at?: string;
}

const DEFAULT_APPROVAL_REASON = "Approval required by Agentic OS policy.";

function firstApprovalAction(packet: TaskPacket): ApprovalActionType | null {
  return detectApprovalActions(packet.raw_user_request)[0] ?? null;
}

function defaultScope(packet: TaskPacket, decision: ApprovalDecision): string {
  if (decision === "approved") {
    return `Approved only for this Task Packet scope: ${packet.request_summary}`;
  }

  return `Rejected before mutation: ${packet.request_summary}`;
}

export function taskPacketToAgentApprovalInsert(input: PersistApprovalInput): AgentApprovalInsert {
  return {
    task_id: input.workboard_task_id,
    packet_task_id: input.packet.task_id,
    decision: input.decision,
    action_type: firstApprovalAction(input.packet),
    approval_reason: input.packet.approval_reason ?? DEFAULT_APPROVAL_REASON,
    approved_scope: input.approved_scope?.trim() || defaultScope(input.packet, input.decision),
    created_at: input.created_at ?? new Date().toISOString(),
  };
}

export function latestAgentApprovalRow(rows: AgentApprovalRow[]): AgentApprovalRow | null {
  return [...rows].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())[0] ?? null;
}

export function isAgentApprovalRecorded(row: AgentApprovalRow | null | undefined): boolean {
  return row?.decision === "approved";
}
