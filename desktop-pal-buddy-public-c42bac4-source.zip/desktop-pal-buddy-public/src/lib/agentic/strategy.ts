import { createGatewayCodexDraft, type GatewayCodexDraft, type GatewayCodexDraftInput } from "./gatewayCodexAgent";
import { renderManualCodexHandoff } from "./manualCodexHandoff";
import { strategyRefSchema, strategyVersionSchema, taskPacketSchema } from "./schemas";
import type { StrategyRef, StrategyVersion, ValidationResult } from "./types";

export function validateStrategyReference(
  ref: StrategyRef,
  versions: readonly StrategyVersion[],
): ValidationResult {
  const parsedRef = strategyRefSchema.safeParse(ref);
  if (!parsedRef.success) {
    return {
      valid: false,
      issues: parsedRef.error.issues.map((issue) => `invalid strategy reference: ${issue.message}`),
    };
  }

  const validVersions = versions
    .map((version) => strategyVersionSchema.safeParse(version))
    .filter((result) => result.success)
    .map((result) => result.data);
  const version = validVersions.find(
    (candidate) => candidate.strategy_version_id === parsedRef.data.strategy_version_id,
  );

  if (!version) {
    return {
      valid: false,
      issues: [`unknown strategy version: ${parsedRef.data.strategy_version_id}`],
    };
  }

  if (version.strategy_id !== parsedRef.data.strategy_id) {
    return {
      valid: false,
      issues: ["strategy version does not belong to the selected strategy"],
    };
  }

  return { valid: true, issues: [] };
}

function strategyTaskId(taskId: string, ref: StrategyRef): string {
  return [
    taskId,
    "strategy",
    encodeURIComponent(ref.strategy_id),
    "version",
    encodeURIComponent(ref.strategy_version_id),
  ].join("--");
}

export function createStrategyGatewayDraft(
  input: GatewayCodexDraftInput,
  ref: StrategyRef | undefined,
  versions: readonly StrategyVersion[],
): GatewayCodexDraft {
  if (ref === undefined) {
    return createGatewayCodexDraft(input);
  }

  const baseDraft = createGatewayCodexDraft(input);
  const validation = validateStrategyReference(ref, versions);
  if (!validation.valid) {
    return {
      ...baseDraft,
      bridge_status: "needs_manual_review",
      packet: null,
      handoff_markdown: "",
      blocked_reason: `전략 참조를 확인해야 합니다: ${validation.issues.join("; ")}`,
      policy_notes: [
        ...baseDraft.policy_notes,
        "유효하지 않은 전략 참조는 worker handoff와 Workboard 저장을 차단합니다.",
      ],
    };
  }

  if (!baseDraft.packet) {
    return baseDraft;
  }

  const parsedRef = strategyRefSchema.parse(ref);
  const packet = taskPacketSchema.parse({
    ...baseDraft.packet,
    task_id: strategyTaskId(baseDraft.packet.task_id, parsedRef),
    strategy_ref: parsedRef,
  });

  return {
    ...baseDraft,
    packet,
    handoff_markdown: renderManualCodexHandoff(packet),
    policy_notes: [
      ...baseDraft.policy_notes,
      "전략 버전 참조는 작업 접수 시 고정되며 정책 판단을 변경하지 않습니다.",
    ],
  };
}
