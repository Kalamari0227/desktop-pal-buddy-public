import type {
  ApprovalActionType,
  CreateTaskPacketInput,
  DefaultTaskType,
  ReportFormat,
  TaskPacket,
  TaskPacketTemplate,
} from "./types";
import { detectApprovalActions } from "./approvalPolicy";

const STANDARD_REPORT_FORMAT: ReportFormat = {
  include_summary: true,
  include_evidence: true,
  include_blockers: true,
  include_next_action: true,
  max_detail_level: "standard",
};

const DEFAULT_TASK_TEMPLATES: Record<DefaultTaskType, TaskPacketTemplate> = {
  pr_verification: {
    task_type: "pr_verification",
    risk_level: "low",
    required_approval: false,
    forbidden_actions: ["do not merge PR", "do not push commits", "do not deploy"],
    execution_plan: [
      {
        step_id: "pr-context",
        summary: "Identify the PR, branch, latest head, and review target.",
        expected_evidence: "GitHub PR metadata or local git refs",
      },
      {
        step_id: "pr-diff-review",
        summary: "Review the diff for correctness, risk, and scope alignment.",
        expected_evidence: "Diff review summary",
      },
      {
        step_id: "pr-verification",
        summary: "Check CI or local verification results and report merge readiness.",
        expected_evidence: "CI status and manual review evidence",
      },
    ],
    verification_requirements: [
      { type: "ci_status", required: true, command_or_source: "GitHub PR checks" },
      { type: "diff_review", required: true, command_or_source: "GitHub PR diff or local git diff" },
      { type: "manual_review", required: true, command_or_source: "Codex review summary" },
    ],
    report_format: STANDARD_REPORT_FORMAT,
  },
  supabase_staging_check: {
    task_type: "supabase_staging_check",
    risk_level: "medium",
    required_approval: false,
    forbidden_actions: [
      "do not run migration",
      "do not change secrets",
      "do not deploy functions",
      "do not modify production systems",
    ],
    execution_plan: [
      {
        step_id: "supabase-project-health",
        summary: "Read staging project health without changing project state.",
        expected_evidence: "Supabase project health status",
      },
      {
        step_id: "supabase-migrations",
        summary: "Read migration status and identify drift or pending migration risk.",
        expected_evidence: "Supabase migration list or dry-run summary",
      },
      {
        step_id: "supabase-advisor",
        summary: "Classify advisor warnings and report blockers or follow-ups.",
        expected_evidence: "Advisor warning classification",
      },
    ],
    verification_requirements: [
      { type: "supabase_status", required: true, command_or_source: "Supabase project health" },
      { type: "supabase_status", required: true, command_or_source: "migration list" },
      { type: "manual_review", required: true, command_or_source: "advisor warning classification" },
    ],
    report_format: STANDARD_REPORT_FORMAT,
  },
  document_to_prd: {
    task_type: "document_to_prd",
    risk_level: "low",
    required_approval: false,
    forbidden_actions: [
      "do not overwrite existing docs without approval",
      "do not expose secrets from uploaded files",
    ],
    execution_plan: [
      {
        step_id: "source-read-through",
        summary: "Read the supplied source material and extract requirements.",
        expected_evidence: "Source read-through notes",
      },
      {
        step_id: "prd-draft",
        summary: "Draft a PRD with goals, scope, non-goals, requirements, and open questions.",
        expected_evidence: "Generated PRD draft path or content",
      },
      {
        step_id: "prd-review",
        summary: "Review the draft against the source and call out unresolved decisions.",
        expected_evidence: "Manual review summary",
      },
    ],
    verification_requirements: [
      { type: "manual_review", required: true, command_or_source: "source document read-through" },
      { type: "document_created", required: true, command_or_source: "generated draft path or draft content" },
    ],
    report_format: STANDARD_REPORT_FORMAT,
  },
  inventory_check: {
    task_type: "inventory_check",
    risk_level: "medium",
    required_approval: false,
    forbidden_actions: [
      "do not reserve inventory",
      "do not update ERP stock records",
      "do not create sales or purchase orders",
    ],
    execution_plan: [
      {
        step_id: "inventory-context",
        summary: "Identify material, warehouse, customer, and urgency context.",
        expected_evidence: "Material and warehouse context refs",
      },
      {
        step_id: "inventory-read",
        summary: "Read available stock, allocated stock, and near-term inbound quantity.",
        expected_evidence: "Inventory snapshot from ERP, spreadsheet, or operator-provided source",
      },
      {
        step_id: "inventory-report",
        summary: "Report usable quantity, confidence, gaps, and next action.",
        expected_evidence: "Inventory status summary",
      },
    ],
    verification_requirements: [
      { type: "inventory_status", required: true, command_or_source: "inventory availability source" },
      { type: "manual_review", required: true, command_or_source: "inventory confidence and data freshness review" },
    ],
    report_format: STANDARD_REPORT_FORMAT,
  },
  urgent_material_risk_assessment: {
    task_type: "urgent_material_risk_assessment",
    risk_level: "medium",
    required_approval: false,
    forbidden_actions: [
      "do not reserve inventory",
      "do not expedite shipment",
      "do not send customer commitment",
      "do not create sales or purchase orders",
    ],
    execution_plan: [
      {
        step_id: "urgent-material-context",
        summary: "Identify customer, material, due date, requested quantity, and urgency reason.",
        expected_evidence: "Customer, material, due date, and urgency context",
      },
      {
        step_id: "urgent-material-supply",
        summary: "Check stock, inbound supply, allocation pressure, and delivery constraints.",
        expected_evidence: "Inventory and delivery schedule evidence",
      },
      {
        step_id: "urgent-material-risk",
        summary: "Classify risk and propose safe next actions without committing externally.",
        expected_evidence: "Risk assessment summary",
      },
    ],
    verification_requirements: [
      { type: "inventory_status", required: true, command_or_source: "available and allocated stock" },
      { type: "delivery_status", required: true, command_or_source: "delivery or inbound schedule" },
      { type: "risk_assessment", required: true, command_or_source: "urgent material risk classification" },
    ],
    report_format: STANDARD_REPORT_FORMAT,
  },
  delivery_delay_risk_check: {
    task_type: "delivery_delay_risk_check",
    risk_level: "medium",
    required_approval: false,
    forbidden_actions: [
      "do not change delivery schedule",
      "do not send customer commitment",
      "do not create compensation offer",
    ],
    execution_plan: [
      {
        step_id: "delivery-context",
        summary: "Identify customer, order, material, due date, and delay signal.",
        expected_evidence: "Order and due date context refs",
      },
      {
        step_id: "delivery-check",
        summary: "Check order state, production or inbound schedule, and shipment constraints.",
        expected_evidence: "Order status and delivery schedule evidence",
      },
      {
        step_id: "delivery-risk",
        summary: "Classify delay risk and recommend escalation, customer update, or monitoring.",
        expected_evidence: "Delivery risk assessment",
      },
    ],
    verification_requirements: [
      { type: "order_status", required: true, command_or_source: "order or shipment status" },
      { type: "delivery_status", required: true, command_or_source: "delivery schedule" },
      { type: "risk_assessment", required: true, command_or_source: "delivery delay risk classification" },
    ],
    report_format: STANDARD_REPORT_FORMAT,
  },
  business_risk_review: {
    task_type: "business_risk_review",
    risk_level: "medium",
    required_approval: false,
    forbidden_actions: [
      "do not send customer commitment",
      "do not change delivery schedule",
      "do not change price or customer terms",
      "do not update ERP or CRM records",
    ],
    execution_plan: [
      {
        step_id: "business-risk-context",
        summary: "Identify customer, risk category, affected material or order, severity, impact, and due date.",
        expected_evidence: "Risk context refs and source notes",
      },
      {
        step_id: "business-risk-review",
        summary: "Review available context and classify business risk without changing external systems.",
        expected_evidence: "Risk assessment evidence",
      },
      {
        step_id: "business-risk-report",
        summary: "Report risk level, assumptions, blockers, and recommended next action.",
        expected_evidence: "Business risk review summary",
      },
    ],
    verification_requirements: [
      { type: "risk_assessment", required: true, command_or_source: "business risk classification" },
      { type: "manual_review", required: true, command_or_source: "risk assumptions and next-action review" },
    ],
    report_format: STANDARD_REPORT_FORMAT,
  },
  customer_reply_draft: {
    task_type: "customer_reply_draft",
    risk_level: "medium",
    required_approval: false,
    forbidden_actions: [
      "do not send external message",
      "do not make binding price or delivery commitment",
      "do not expose internal-only context",
    ],
    execution_plan: [
      {
        step_id: "reply-context",
        summary: "Identify customer, channel, inquiry type, and relevant business context.",
        expected_evidence: "Customer and inquiry context",
      },
      {
        step_id: "reply-draft",
        summary: "Draft a response that is clear, reviewable, and not sent automatically.",
        expected_evidence: "Generated reply draft",
      },
      {
        step_id: "reply-review",
        summary: "Review the draft for tone, factual claims, and approval-sensitive statements.",
        expected_evidence: "Manual review summary",
      },
    ],
    verification_requirements: [
      { type: "reply_draft", required: true, command_or_source: "generated customer reply draft" },
      { type: "manual_review", required: true, command_or_source: "external-message safety review" },
    ],
    report_format: STANDARD_REPORT_FORMAT,
  },
  order_status_check: {
    task_type: "order_status_check",
    risk_level: "medium",
    required_approval: false,
    forbidden_actions: [
      "do not change order status",
      "do not update ERP order records",
      "do not send customer commitment",
    ],
    execution_plan: [
      {
        step_id: "order-context",
        summary: "Identify sales order, customer, material, and requested status question.",
        expected_evidence: "Order context refs",
      },
      {
        step_id: "order-read",
        summary: "Read order status, allocation state, shipment state, and blockers.",
        expected_evidence: "Order status evidence",
      },
      {
        step_id: "order-report",
        summary: "Report current state, confidence, risks, and next action.",
        expected_evidence: "Order status summary",
      },
    ],
    verification_requirements: [
      { type: "order_status", required: true, command_or_source: "sales order status source" },
      { type: "manual_review", required: true, command_or_source: "order status confidence review" },
    ],
    report_format: STANDARD_REPORT_FORMAT,
  },
  material_substitution_review: {
    task_type: "material_substitution_review",
    risk_level: "medium",
    required_approval: false,
    forbidden_actions: [
      "do not approve material substitution",
      "do not change customer specification",
      "do not send customer commitment",
    ],
    execution_plan: [
      {
        step_id: "substitution-context",
        summary: "Identify original material, candidate substitute, customer, use case, and constraints.",
        expected_evidence: "Material and customer context",
      },
      {
        step_id: "substitution-check",
        summary: "Review availability, specification fit, delivery impact, and open risks.",
        expected_evidence: "Substitution option evidence",
      },
      {
        step_id: "substitution-report",
        summary: "Recommend whether to escalate, reject, or prepare a reviewed proposal.",
        expected_evidence: "Substitution review summary",
      },
    ],
    verification_requirements: [
      { type: "substitution_review", required: true, command_or_source: "material substitution comparison" },
      { type: "inventory_status", required: true, command_or_source: "substitute material availability" },
      { type: "manual_review", required: true, command_or_source: "specification and customer commitment review" },
    ],
    report_format: STANDARD_REPORT_FORMAT,
  },
};

const cloneTemplate = (template: TaskPacketTemplate): TaskPacketTemplate => ({
  ...template,
  forbidden_actions: [...template.forbidden_actions],
  execution_plan: template.execution_plan.map((step) => ({ ...step })),
  verification_requirements: template.verification_requirements.map((requirement) => ({ ...requirement })),
  report_format: { ...template.report_format },
});

const approvalForbiddenAction = (action: ApprovalActionType): string =>
  `do not perform ${action} without explicit approval`;

export function getDefaultTaskTemplate(taskType: DefaultTaskType): TaskPacketTemplate {
  return cloneTemplate(DEFAULT_TASK_TEMPLATES[taskType]);
}

export function createTaskPacket(input: CreateTaskPacketInput): TaskPacket {
  const template = getDefaultTaskTemplate(input.task_type);
  const approvalActions = detectApprovalActions(input.raw_user_request);
  const requiresApproval = approvalActions.length > 0;

  return {
    task_id: input.task_id,
    created_at: input.created_at,
    created_by: input.created_by,
    request_summary: input.request_summary,
    raw_user_request: input.raw_user_request,
    desired_outcome: input.desired_outcome,
    task_type: input.task_type,
    context_refs: input.context_refs ?? [],
    strategy_ref: input.strategy_ref ? { ...input.strategy_ref } : undefined,
    risk_level: requiresApproval ? "high" : template.risk_level,
    required_approval: requiresApproval || template.required_approval,
    approval_reason: requiresApproval
      ? `Approval required for: ${approvalActions.join(", ")}`
      : template.approval_reason,
    forbidden_actions: requiresApproval
      ? [...template.forbidden_actions, ...approvalActions.map(approvalForbiddenAction)]
      : template.forbidden_actions,
    execution_plan: template.execution_plan,
    verification_requirements: template.verification_requirements,
    report_format: template.report_format,
    status: input.status ?? (requiresApproval ? "waiting_for_approval" : "queued"),
    evidence: input.evidence ?? [],
    result: input.result,
    blockers: input.blockers ?? [],
    next_action: input.next_action,
    retention_decision: input.retention_decision,
  };
}
