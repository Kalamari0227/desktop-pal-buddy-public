import type { Database } from "@/integrations/supabase/types";
import type { ContextRef, RiskLevel, TaskPacket, TaskType } from "./types";

export type WorkboardTaskInsert = Database["public"]["Tables"]["tasks"]["Insert"];

export interface GatewayWorkboardTaskInput {
  packet: TaskPacket;
  workboard_task_id: string;
  created_at?: string;
}

const TASK_CATEGORY: Partial<Record<TaskType, string>> = {
  inventory_check: "delivery",
  urgent_material_risk_assessment: "delivery",
  delivery_delay_risk_check: "delivery",
  customer_reply_draft: "delivery",
  order_status_check: "delivery",
  material_substitution_review: "quality",
  pr_verification: "quality",
  supabase_staging_check: "quality",
  document_to_prd: "quality",
};

const RISK_TO_SEVERITY: Record<RiskLevel, string> = {
  low: "low",
  medium: "medium",
  high: "high",
  blocked: "critical",
};

function firstContextValue(contextRefs: ContextRef[], type: ContextRef["type"]): string | null {
  return contextRefs.find((ref) => ref.type === type)?.value.trim() || null;
}

function compact(value: string): string {
  return value.replace(/\s+/g, " ").trim();
}

export function gatewayPacketToWorkboardTaskInsert(input: GatewayWorkboardTaskInput): WorkboardTaskInsert {
  const { packet } = input;
  const createdAt = input.created_at ?? new Date().toISOString();
  const rawRequest = compact(packet.raw_user_request);
  const summary = compact(packet.request_summary);
  const desiredOutcome = compact(packet.desired_outcome);
  const approvalNote = packet.required_approval
    ? `승인 필요: ${packet.approval_reason ?? "명시적 사용자 승인 필요"}`
    : "승인 불필요";

  return {
    id: input.workboard_task_id,
    title: rawRequest || summary,
    description: [
      summary,
      desiredOutcome,
      `Gateway task type: ${packet.task_type}`,
      approvalNote,
    ].filter(Boolean).join("\n"),
    source: "gateway",
    source_id: packet.task_id,
    severity: RISK_TO_SEVERITY[packet.risk_level],
    customer: firstContextValue(packet.context_refs, "customer_account"),
    category: TASK_CATEGORY[packet.task_type] ?? null,
    status: "pending",
    created_at: createdAt,
    updated_at: createdAt,
  };
}
