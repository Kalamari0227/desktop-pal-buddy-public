import { classifyRiskAndApproval } from "./riskClassifier";
import { createTaskPacket } from "./taskTemplates";
import { renderManualCodexHandoff } from "./manualCodexHandoff";
import type { ContextRef, DefaultTaskType, TaskPacket, TaskType } from "./types";
import { classifyTaskType } from "./riskClassifier";

export type GatewayCodexBridgeStatus = "manual_only" | "needs_manual_review";

export interface GatewayCodexSuggestion {
  request_summary: string;
  desired_outcome: string;
  task_type: TaskType;
  context_refs: ContextRef[];
  reasoning_notes: string[];
}

export interface GatewayCodexDraftInput {
  raw_user_request: string;
  context_refs?: ContextRef[];
  created_at?: string;
  created_by?: string;
  task_id?: string;
  codex_suggestion?: Partial<GatewayCodexSuggestion>;
}

export interface GatewayCodexPrompt {
  system: string;
  user: string;
}

export interface GatewayCodexDraft {
  agent_name: "Gateway Codex";
  bridge_status: GatewayCodexBridgeStatus;
  prompt: GatewayCodexPrompt;
  suggestion: GatewayCodexSuggestion;
  packet: TaskPacket | null;
  handoff_markdown: string;
  policy_notes: string[];
  blocked_reason?: string;
}

export const GATEWAY_CODEX_SYSTEM_PROMPT = `You are Gateway Codex for Prometheus Agentic OS.

You are the conversation and task-intake subject, not the worker executor.

Your job:
- preserve the user's raw request
- identify context references
- propose task_type, request_summary, and desired_outcome
- prepare a Task Packet draft for the policy engine
- ask for manual review when the request is ambiguous

Safety boundaries:
- do not execute worker tasks
- do not merge pull requests
- do not run database migrations
- do not deploy
- do not send external messages
- do not create, store, or reveal secrets
- do not treat implied intent as approval

The deterministic policy engine has final authority over risk, approval, forbidden actions, status, evidence, and handoff output.`;

const DEFAULT_TASK_TYPES = new Set<TaskType>([
  "pr_verification",
  "supabase_staging_check",
  "document_to_prd",
  "inventory_check",
  "urgent_material_risk_assessment",
  "delivery_delay_risk_check",
  "business_risk_review",
  "customer_reply_draft",
  "order_status_check",
  "material_substitution_review",
]);

export const TASK_INTAKE_COPY: Record<DefaultTaskType, { summary: string; outcome: string }> = {
  pr_verification: {
    summary: "Verify the requested pull request and report readiness.",
    outcome: "Return PR readiness with evidence, blockers, risks, and next action.",
  },
  supabase_staging_check: {
    summary: "Check Supabase staging state without mutating project resources.",
    outcome: "Return staging health, migration status, advisor notes, blockers, and next action.",
  },
  document_to_prd: {
    summary: "Turn the supplied source material into a PRD draft.",
    outcome: "Return a PRD draft, open questions, proposed save location, and evidence.",
  },
  inventory_check: {
    summary: "Check available inventory for the requested material and context.",
    outcome: "Return usable stock, source freshness, blockers, risks, and next action.",
  },
  urgent_material_risk_assessment: {
    summary: "Assess urgent material risk for the requested customer and material.",
    outcome: "Return urgency risk, supply constraints, evidence, blockers, and safe next action.",
  },
  delivery_delay_risk_check: {
    summary: "Assess delivery delay risk for the requested customer, order, or material.",
    outcome: "Return delay risk, schedule evidence, impact, blockers, and next action.",
  },
  business_risk_review: {
    summary: "Review the requested business risk and propose safe next actions.",
    outcome: "Return risk classification, assumptions, evidence needs, blockers, and next action.",
  },
  customer_reply_draft: {
    summary: "Draft a customer response without sending it externally.",
    outcome: "Return a reviewed reply draft, factual assumptions, approval-sensitive statements, and next action.",
  },
  order_status_check: {
    summary: "Check the requested order status without changing order records.",
    outcome: "Return current order state, evidence, blockers, risks, and next action.",
  },
  material_substitution_review: {
    summary: "Review possible material substitution options for the requested context.",
    outcome: "Return candidate fit, supply impact, risks, evidence, and next action.",
  },
};

function isDefaultTaskType(taskType: TaskType): taskType is DefaultTaskType {
  return DEFAULT_TASK_TYPES.has(taskType);
}

function sanitizeContextRefs(refs: ContextRef[]): ContextRef[] {
  return refs.filter((ref) => ref.label.trim() && ref.value.trim());
}

export function createStableTaskId(request: string, taskType: TaskType): string {
  const hash = Array.from(request).reduce((sum, char) => sum + char.charCodeAt(0), 0);
  return `task-${taskType}-${hash.toString(16)}`;
}

function chooseTaskType(ruleTaskType: TaskType, suggestedTaskType?: TaskType): TaskType {
  if (ruleTaskType !== "unknown") {
    return ruleTaskType;
  }
  if (suggestedTaskType && isDefaultTaskType(suggestedTaskType)) {
    return suggestedTaskType;
  }
  return ruleTaskType;
}

export function buildGatewayCodexPrompt(input: {
  raw_user_request: string;
  context_refs?: ContextRef[];
}): GatewayCodexPrompt {
  const contextRefs = sanitizeContextRefs(input.context_refs ?? []);
  const contextLines = contextRefs.length
    ? contextRefs.map((ref) => `- [${ref.type}] ${ref.label}: ${ref.value}`).join("\n")
    : "- none";

  return {
    system: GATEWAY_CODEX_SYSTEM_PROMPT,
    user: `Create a Gateway intake draft.

Return JSON with:
- request_summary
- desired_outcome
- task_type
- context_refs
- reasoning_notes

Raw user request:
${input.raw_user_request}

Context refs:
${contextLines}`,
  };
}

function buildSuggestion(input: GatewayCodexDraftInput, taskType: TaskType): GatewayCodexSuggestion {
  const suggestion = input.codex_suggestion;
  const contextRefs = sanitizeContextRefs(suggestion?.context_refs ?? input.context_refs ?? []);
  const copy = isDefaultTaskType(taskType) ? TASK_INTAKE_COPY[taskType] : undefined;

  return {
    request_summary: suggestion?.request_summary?.trim() || copy?.summary || "Manual review is required before a task packet can be built.",
    desired_outcome: suggestion?.desired_outcome?.trim() || copy?.outcome || "Clarify the request enough to build a safe Task Packet.",
    task_type: taskType,
    context_refs: contextRefs,
    reasoning_notes: suggestion?.reasoning_notes?.length
      ? suggestion.reasoning_notes.filter((note) => note.trim())
      : [
          taskType === "unknown"
            ? "The rule classifier could not map this request to a supported v0 task type."
            : "The request matches a supported v0 Gateway task type.",
        ],
  };
}

function policyNotesFor(packet: TaskPacket | null, taskType: TaskType): string[] {
  if (!packet) {
    return [
      "Gateway Codex can propose intake fields, but unsupported requests require manual review.",
      "No worker handoff is generated for unknown task types.",
    ];
  }

  const notes = [
    "Gateway Codex is intake-only; worker execution remains manual in v0.",
    "Domain Core policy sets risk, approval, forbidden actions, status, and evidence requirements.",
  ];

  if (packet.required_approval) {
    notes.push("Approval-required work is locked to read-only preflight until explicit approval is scoped.");
  }

  if (taskType !== packet.task_type) {
    notes.push("The suggested task type was normalized by the policy engine.");
  }

  return notes;
}

export function createGatewayCodexDraft(input: GatewayCodexDraftInput): GatewayCodexDraft {
  const rawRequest = input.raw_user_request.trim();
  const ruleTaskType = classifyTaskType(rawRequest);
  const taskType = chooseTaskType(ruleTaskType, input.codex_suggestion?.task_type);
  const prompt = buildGatewayCodexPrompt({
    raw_user_request: rawRequest,
    context_refs: input.context_refs,
  });
  const suggestion = buildSuggestion(input, taskType);

  if (!isDefaultTaskType(taskType)) {
    return {
      agent_name: "Gateway Codex",
      bridge_status: "needs_manual_review",
      prompt,
      suggestion,
      packet: null,
      handoff_markdown: "",
      policy_notes: policyNotesFor(null, taskType),
      blocked_reason: "Unsupported or ambiguous task type.",
    };
  }

  const classification = classifyRiskAndApproval({ request: rawRequest, task_type: taskType });
  const packet = createTaskPacket({
    task_id: input.task_id ?? createStableTaskId(rawRequest, taskType),
    created_at: input.created_at ?? new Date().toISOString(),
    created_by: input.created_by ?? "gateway-codex",
    request_summary: suggestion.request_summary,
    raw_user_request: rawRequest,
    desired_outcome: suggestion.desired_outcome,
    task_type: taskType,
    context_refs: suggestion.context_refs,
    status: classification.required_approval ? "waiting_for_approval" : undefined,
  });

  return {
    agent_name: "Gateway Codex",
    bridge_status: "manual_only",
    prompt,
    suggestion,
    packet,
    handoff_markdown: renderManualCodexHandoff(packet),
    policy_notes: policyNotesFor(packet, ruleTaskType),
  };
}
