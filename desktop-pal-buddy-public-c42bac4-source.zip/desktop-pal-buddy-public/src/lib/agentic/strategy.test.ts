import { describe, expect, it } from "vitest";
import { demoStrategyVersions } from "@/data/demoStrategyCatalog";
import { createGatewayCodexDraft } from "./gatewayCodexAgent";
import { renderManualCodexHandoff } from "./manualCodexHandoff";
import {
  strategyRefSchema,
  strategySchema,
  strategyVersionSchema,
  taskPacketSchema,
} from "./schemas";
import { createStrategyGatewayDraft, validateStrategyReference } from "./strategy";
import type { StrategyRef, StrategyVersion } from "./types";

const refV1: StrategyRef = {
  strategy_id: "delivery-risk-early-warning",
  strategy_version_id: "delivery-risk-early-warning-v1",
};

const refV2: StrategyRef = {
  strategy_id: "delivery-risk-early-warning",
  strategy_version_id: "delivery-risk-early-warning-v2",
};

const versions: readonly StrategyVersion[] = [
  {
    strategy_version_id: refV1.strategy_version_id,
    strategy_id: refV1.strategy_id,
    version: 1,
    objective: "가상 납기 위험을 조기에 확인한다.",
    review_question: "필수 납기 증거가 충분한가?",
  },
  {
    strategy_version_id: refV2.strategy_version_id,
    strategy_id: refV2.strategy_id,
    version: 2,
    objective: "가상 주문과 공급 신호를 함께 확인한다.",
    review_question: "변경된 신호가 조기 경보를 개선하는가?",
  },
];

describe("strategy contracts", () => {
  it("rejects blank, non-positive, and unknown strategy fields", () => {
    expect(strategySchema.safeParse({ strategy_id: " ", title: "제목" }).success).toBe(false);
    expect(strategyRefSchema.safeParse({ ...refV1, extra: true }).success).toBe(false);
    expect(strategyVersionSchema.safeParse({ ...versions[0], version: 0 }).success).toBe(false);
    expect(strategyVersionSchema.safeParse({ ...versions[0], objective: "\n\t" }).success).toBe(false);
  });

  it("validates membership using both strategy and version identifiers", () => {
    expect(validateStrategyReference(refV1, versions)).toEqual({ valid: true, issues: [] });

    const mismatch = validateStrategyReference(
      { strategy_id: "another-strategy", strategy_version_id: refV1.strategy_version_id },
      versions,
    );
    expect(mismatch.valid).toBe(false);
    expect(mismatch.issues).toContain("strategy version does not belong to the selected strategy");
  });

  it("rejects malformed and unknown references at runtime", () => {
    expect(validateStrategyReference({ strategy_id: "", strategy_version_id: refV1.strategy_version_id }, versions).valid).toBe(false);
    expect(validateStrategyReference({ ...refV1, strategy_version_id: "missing-version" }, versions).issues)
      .toContain("unknown strategy version: missing-version");
  });

  it("keeps unlinked Gateway drafts exactly compatible with the existing path", () => {
    const input = {
      raw_user_request: "가상 고객 납기 지연 확인해줘",
      created_at: "2026-09-18T01:00:00.000Z",
    };

    expect(createStrategyGatewayDraft(input, undefined, versions)).toEqual(createGatewayCodexDraft(input));
  });

  it("fails closed when a runtime caller supplies null instead of an omitted reference", () => {
    const draft = createStrategyGatewayDraft(
      { raw_user_request: "가상 고객 납기 지연 확인해줘" },
      null as unknown as StrategyRef,
      versions,
    );

    expect(draft.bridge_status).toBe("needs_manual_review");
    expect(draft.packet).toBeNull();
    expect(draft.handoff_markdown).toBe("");
    expect(draft.blocked_reason).toContain("전략");
  });

  it("pins an immutable strategy reference while preserving the request and policy", () => {
    const mutableRef = { ...refV1 };
    const draft = createStrategyGatewayDraft({
      raw_user_request: "staging DB migration 실행해줘",
      created_at: "2026-09-18T01:00:00.000Z",
      codex_suggestion: {
        request_summary: "작업자 제안 요약",
        desired_outcome: "작업자 제안 결과",
        task_type: "supabase_staging_check",
      },
    }, mutableRef, versions);

    mutableRef.strategy_version_id = refV2.strategy_version_id;

    expect(draft.packet?.raw_user_request).toBe("staging DB migration 실행해줘");
    expect(draft.packet?.strategy_ref).toEqual(refV1);
    expect(draft.packet?.required_approval).toBe(true);
    expect(draft.packet?.forbidden_actions).toContain("do not perform database_migration without explicit approval");
    expect(taskPacketSchema.safeParse(draft.packet).success).toBe(true);
  });

  it("gives distinct strategy versions distinct stable Gateway task identities", () => {
    const input = {
      raw_user_request: "가상 고객 납기 지연 확인해줘",
      created_at: "2026-09-18T01:00:00.000Z",
    };
    const v1a = createStrategyGatewayDraft(input, refV1, versions);
    const v1b = createStrategyGatewayDraft(input, refV1, versions);
    const v2 = createStrategyGatewayDraft(input, refV2, versions);

    expect(v1a.packet?.task_id).toBe(v1b.packet?.task_id);
    expect(v1a.packet?.task_id).not.toBe(v2.packet?.task_id);
  });

  it("fails closed with a Korean reason for an invalid reference", () => {
    const draft = createStrategyGatewayDraft(
      { raw_user_request: "가상 고객 납기 지연 확인해줘" },
      { strategy_id: "other", strategy_version_id: refV1.strategy_version_id },
      versions,
    );

    expect(draft.bridge_status).toBe("needs_manual_review");
    expect(draft.packet).toBeNull();
    expect(draft.handoff_markdown).toBe("");
    expect(draft.blocked_reason).toContain("전략");
  });

  it("renders the pinned strategy identity in manual handoff", () => {
    const packet = createStrategyGatewayDraft(
      { raw_user_request: "가상 고객 납기 지연 확인해줘" },
      refV1,
      demoStrategyVersions,
    ).packet!;

    expect(renderManualCodexHandoff(packet)).toContain("delivery-risk-early-warning-v1");
  });

  it("continues to parse legacy packets without a strategy reference", () => {
    const packet = createGatewayCodexDraft({ raw_user_request: "가상 고객 납기 지연 확인해줘" }).packet!;
    expect(taskPacketSchema.safeParse(packet).success).toBe(true);
    expect(packet.strategy_ref).toBeUndefined();
  });
});
