import { describe, expect, it } from "vitest";
import {
  ManualCodexAdapter,
  classifyRiskAndApproval,
  classifyTaskType,
  containsSensitiveRawExcerpt,
  createTaskPacket,
  detectApprovalActions,
  getDefaultTaskTemplate,
  renderManualCodexHandoff,
  blockerSchema,
  contextRefSchema,
  retentionDecisionSchema,
  taskPacketSchema,
  validateEvidenceItem,
  validateStatusTransition,
  validateTaskPacketForCompletion,
  workerEventSchema,
  workerResultSchema,
} from "./index";

const createCompletedPrPacket = () =>
  createTaskPacket({
    task_id: "task-pr-completed",
    created_at: "2026-07-03T00:00:00.000Z",
    created_by: "user-1",
    request_summary: "Verify PR #3",
    raw_user_request: "PR #3 검증해줘",
    desired_outcome: "Return PR readiness with evidence.",
    task_type: "pr_verification",
    status: "completed",
    evidence: [
      {
        evidence_id: "ev-ci",
        task_id: "task-pr-completed",
        created_at: "2026-07-03T00:01:00.000Z",
        evidence_type: "ci_status",
        summary: "GitHub checks passed.",
        source: { system: "github", url: "https://github.com/revfactory/harness/pull/3" },
        status: "passed",
      },
      {
        evidence_id: "ev-diff",
        task_id: "task-pr-completed",
        created_at: "2026-07-03T00:02:00.000Z",
        evidence_type: "file_diff",
        summary: "Diff was reviewed.",
        source: { system: "github", url: "https://github.com/revfactory/harness/pull/3/files" },
        status: "passed",
      },
      {
        evidence_id: "ev-review",
        task_id: "task-pr-completed",
        created_at: "2026-07-03T00:03:00.000Z",
        evidence_type: "manual_observation",
        summary: "Diff review found no blockers.",
        source: { system: "codex_worker", ref: "manual-review" },
        status: "passed",
      },
    ],
  });

describe("Agentic OS domain core", () => {
  it("models canonical packet, worker event, worker result, blocker, and retention structures", () => {
    const packet = createTaskPacket({
      task_id: "task-schema-1",
      created_at: "2026-07-03T00:00:00.000Z",
      created_by: "user-1",
      request_summary: "Verify PR #1",
      raw_user_request: "PR #1 검증해줘",
      desired_outcome: "Return PR readiness with evidence.",
      task_type: "pr_verification",
    });

    expect(contextRefSchema.safeParse({ type: "repo_file", label: "schema", value: "docs/agent-os/task-packet-schema.md" }).success).toBe(true);
    expect(workerEventSchema.safeParse({
      event_id: "event-1",
      task_id: "task-schema-1",
      created_at: "2026-07-03T00:00:00.000Z",
      event_type: "approval_required",
      message: "Approval required before migration.",
      severity: "warning",
      requires_user_action: true,
    }).success).toBe(true);
    expect(workerResultSchema.safeParse({
      outcome: "passed_with_warnings",
      summary: "Checks passed with a warning.",
      risks: ["Browserslist data is outdated."],
    }).success).toBe(true);
    expect(blockerSchema.safeParse({
      blocker_id: "blocker-1",
      type: "approval_required",
      summary: "Need explicit DB migration approval.",
      requires_user_action: true,
    }).success).toBe(true);
    expect(retentionDecisionSchema.safeParse({
      task_id: "task-schema-1",
      save_decision: "docs_or_wiki",
      reason: "Durable process knowledge.",
      proposed_target: { path: "docs/agent-os/HARNESS.md" },
      requires_user_approval: true,
    }).success).toBe(true);
    expect(taskPacketSchema.safeParse({ ...packet, task_type: "bad_type" }).success).toBe(false);
  });

  it("builds a valid PR verification packet from the default template", () => {
    const packet = createTaskPacket({
      task_id: "task-pr-1",
      created_at: "2026-07-03T00:00:00.000Z",
      created_by: "user-1",
      request_summary: "Verify PR #1",
      raw_user_request: "PR #1 검증해줘",
      desired_outcome: "Return PR readiness with evidence and next action.",
      task_type: "pr_verification",
      context_refs: [{ type: "github_pr", label: "PR #1", value: "1" }],
    });

    expect(taskPacketSchema.safeParse(packet).success).toBe(true);
    expect(packet).toMatchObject({
      task_type: "pr_verification",
      risk_level: "low",
      required_approval: false,
      status: "queued",
    });
    expect(packet.forbidden_actions).toContain("do not merge PR");
    expect(packet.verification_requirements.map((item) => item.type)).toEqual([
      "ci_status",
      "diff_review",
      "manual_review",
    ]);
  });

  it("defines safe defaults for Supabase staging and document-to-PRD packets", () => {
    expect(getDefaultTaskTemplate("supabase_staging_check")).toMatchObject({
      risk_level: "medium",
      required_approval: false,
      forbidden_actions: expect.arrayContaining(["do not run migration", "do not change secrets"]),
    });

    expect(getDefaultTaskTemplate("document_to_prd")).toMatchObject({
      risk_level: "low",
      required_approval: false,
      forbidden_actions: expect.arrayContaining(["do not overwrite existing docs without approval"]),
    });

    expect(getDefaultTaskTemplate("urgent_material_risk_assessment")).toMatchObject({
      risk_level: "medium",
      required_approval: false,
      forbidden_actions: expect.arrayContaining(["do not reserve inventory", "do not send customer commitment"]),
    });

    expect(getDefaultTaskTemplate("customer_reply_draft")).toMatchObject({
      risk_level: "medium",
      required_approval: false,
      forbidden_actions: expect.arrayContaining(["do not send external message"]),
    });
  });

  it("classifies task types from natural language requests", () => {
    expect(classifyTaskType("PR #12 검증해줘")).toBe("pr_verification");
    expect(classifyTaskType("Supabase staging 상태 확인해줘")).toBe("supabase_staging_check");
    expect(classifyTaskType("이 handoff 문서 기반으로 PRD 초안 만들어줘")).toBe("document_to_prd");
    expect(classifyTaskType("GA 강판 재고 확인해줘")).toBe("inventory_check");
    expect(classifyTaskType("현대차 긴급재 위험도 따져줘")).toBe("urgent_material_risk_assessment");
    expect(classifyTaskType("3월 납기 지연 리스크 봐줘")).toBe("delivery_delay_risk_check");
    expect(classifyTaskType("고객 답장 초안 만들어줘")).toBe("customer_reply_draft");
    expect(classifyTaskType("주문 상태 확인해줘")).toBe("order_status_check");
    expect(classifyTaskType("대체재 검토해줘")).toBe("material_substitution_review");
    expect(classifyTaskType("오늘 할 일 알려줘")).toBe("unknown");
  });

  it("classifies approval-required actions without blocking read-only staging checks", () => {
    expect(
      classifyRiskAndApproval({
        request: "Supabase staging migration 상태 확인해줘",
        task_type: "supabase_staging_check",
      })
    ).toMatchObject({
      risk_level: "medium",
      required_approval: false,
    });

    const migrationRun = classifyRiskAndApproval({
      request: "staging DB migration 실행해줘",
      task_type: "supabase_staging_check",
    });
    expect(migrationRun).toMatchObject({
      risk_level: "high",
      required_approval: true,
    });
    expect(migrationRun.approval_actions).toContain("database_migration");
    expect(migrationRun.approval_reason).toContain("database_migration");
  });

  it("applies approval classification when building task packets", () => {
    const packet = createTaskPacket({
      task_id: "task-supabase-migration-1",
      created_at: "2026-07-03T00:00:00.000Z",
      created_by: "user-1",
      request_summary: "Run staging migration",
      raw_user_request: "staging DB migration 실행해줘",
      desired_outcome: "Do not run anything before explicit approval.",
      task_type: "supabase_staging_check",
    });

    expect(packet).toMatchObject({
      risk_level: "high",
      required_approval: true,
      status: "waiting_for_approval",
    });
    expect(packet.approval_reason).toContain("database_migration");
    expect(packet.forbidden_actions).toContain("do not perform database_migration without explicit approval");
  });

  it("classifies every approval-gated action type", () => {
    expect(detectApprovalActions("고객에게 이메일 발송해줘")).toContain("external_message");
    expect(detectApprovalActions("파일 삭제해줘")).toContain("file_delete_or_move");
    expect(detectApprovalActions("production deploy 실행해줘")).toContain("production_deploy");
    expect(detectApprovalActions("DB migration apply 해줘")).toContain("database_migration");
    expect(detectApprovalActions("service restart 해줘")).toContain("service_restart");
    expect(detectApprovalActions("OAuth gateway config 변경해줘")).toContain("oauth_or_gateway_config_change");
    expect(detectApprovalActions("paid resource create 해줘")).toContain("paid_resource_creation");
    expect(detectApprovalActions("API key 생성해서 저장해줘")).toContain("secret_create_or_store");
    expect(detectApprovalActions("admin permission grant 해줘")).toContain("permission_change");
  });

  it("validates status transitions for the canonical workboard model", () => {
    expect(validateStatusTransition("queued", "triaging")).toMatchObject({ valid: true });
    expect(validateStatusTransition("running", "waiting_for_approval")).toMatchObject({ valid: true });
    expect(validateStatusTransition("completed", "running")).toMatchObject({ valid: false });
    expect(validateStatusTransition("failed", "archived")).toMatchObject({ valid: true });
    expect(validateStatusTransition("blocked", "archived")).toMatchObject({ valid: false });
  });

  it("rejects completed task packets without evidence", () => {
    const packet = createTaskPacket({
      task_id: "task-pr-2",
      created_at: "2026-07-03T00:00:00.000Z",
      created_by: "user-1",
      request_summary: "Verify PR #2",
      raw_user_request: "PR #2 검증해줘",
      desired_outcome: "Return PR readiness with evidence.",
      task_type: "pr_verification",
      status: "completed",
    });

    const result = validateTaskPacketForCompletion(packet);
    expect(result.valid).toBe(false);
    expect(result.issues).toContain("completed task requires at least one evidence item");
  });

  it("rejects packets that violate task validation gates", () => {
    const validCompleted = createCompletedPrPacket();
    expect(validateTaskPacketForCompletion(validCompleted)).toMatchObject({ valid: true });

    expect(validateTaskPacketForCompletion({
      ...validCompleted,
      task_type: "unknown",
      verification_requirements: [],
    })).toMatchObject({
      valid: false,
      issues: expect.arrayContaining(["unknown task requires manual review"]),
    });

    expect(validateTaskPacketForCompletion({
      ...validCompleted,
      required_approval: true,
      approval_reason: undefined,
    })).toMatchObject({
      valid: false,
      issues: expect.arrayContaining(["required approval requires approval_reason"]),
    });

    expect(validateTaskPacketForCompletion({
      ...validCompleted,
      risk_level: "high",
      status: "queued",
    })).toMatchObject({
      valid: false,
      issues: expect.arrayContaining(["high risk task must wait for approval or be in a post-approval state"]),
    });

    expect(validateTaskPacketForCompletion({
      ...validCompleted,
      report_format: { ...validCompleted.report_format, include_evidence: false },
    })).toMatchObject({
      valid: false,
      issues: expect.arrayContaining(["report_format.include_evidence must be true for evidence-producing tasks"]),
    });
  });

  it("rejects unsafe completion evidence and forbidden worker actions", () => {
    const validCompleted = createCompletedPrPacket();

    expect(validateTaskPacketForCompletion({
      ...validCompleted,
      evidence: [{ ...validCompleted.evidence[0], task_id: "other-task" }],
    })).toMatchObject({
      valid: false,
      issues: expect.arrayContaining(["evidence ev-ci task_id does not match packet task_id"]),
    });

    expect(validateTaskPacketForCompletion({
      ...validCompleted,
      evidence: [{ ...validCompleted.evidence[0], status: "failed" }],
      result: { outcome: "failed", summary: "CI failed." },
      blockers: [],
    })).toMatchObject({
      valid: false,
      issues: expect.arrayContaining(["failed required verification requires a blocker or reported risk"]),
    });

    expect(validateTaskPacketForCompletion({
      ...validCompleted,
      result: { outcome: "passed", summary: "I did merge PR after review." },
    })).toMatchObject({
      valid: false,
      issues: expect.arrayContaining(["worker result reports a forbidden action"]),
    });
  });

  it("detects approval-derived forbidden actions in worker result prose", () => {
    const examples = [
      ["do not perform external_message without explicit approval", "I sent the email."],
      ["do not perform file_delete_or_move without explicit approval", "I deleted files."],
      ["do not perform production_deploy without explicit approval", "I deployed to production."],
      ["do not perform database_migration without explicit approval", "I applied database migration."],
      ["do not perform service_restart without explicit approval", "I restarted the service."],
      ["do not perform oauth_or_gateway_config_change without explicit approval", "I changed gateway config."],
      ["do not perform paid_resource_creation without explicit approval", "I created a paid resource."],
      ["do not perform secret_create_or_store without explicit approval", "I stored the API key."],
      ["do not perform permission_change without explicit approval", "I granted admin permission."],
    ] as const;

    for (const [forbiddenAction, resultSummary] of examples) {
      const result = validateTaskPacketForCompletion({
        ...createCompletedPrPacket(),
        forbidden_actions: [forbiddenAction],
        result: { outcome: "passed", summary: resultSummary },
      });
      expect(result.valid, `${forbiddenAction} :: ${resultSummary}`).toBe(false);
      expect(result.issues).toContain("worker result reports a forbidden action");
    }
  });

  it("requires distinct Supabase evidence for project health, migration status, and advisor review", () => {
    const basePacket = createTaskPacket({
      task_id: "task-supabase-completed",
      created_at: "2026-07-03T00:00:00.000Z",
      created_by: "user-1",
      request_summary: "Check Supabase staging",
      raw_user_request: "Supabase staging 상태 확인해줘",
      desired_outcome: "Report staging readiness.",
      task_type: "supabase_staging_check",
      status: "completed",
    });

    expect(validateTaskPacketForCompletion({
      ...basePacket,
      evidence: [
        {
          evidence_id: "ev-project",
          task_id: "task-supabase-completed",
          created_at: "2026-07-03T00:01:00.000Z",
          evidence_type: "supabase_project_status",
          summary: "Project is healthy.",
          source: { system: "supabase", ref: "project-ref" },
          status: "passed",
        },
        {
          evidence_id: "ev-review",
          task_id: "task-supabase-completed",
          created_at: "2026-07-03T00:02:00.000Z",
          evidence_type: "manual_observation",
          summary: "Advisor warnings were reviewed.",
          source: { system: "codex_worker", ref: "advisor-review" },
          status: "passed",
        },
      ],
    })).toMatchObject({
      valid: false,
      issues: expect.arrayContaining(["completed task requires passing evidence for every required verification"]),
    });

    expect(validateTaskPacketForCompletion({
      ...basePacket,
      evidence: [
        {
          evidence_id: "ev-project",
          task_id: "task-supabase-completed",
          created_at: "2026-07-03T00:01:00.000Z",
          evidence_type: "supabase_project_status",
          summary: "Project is healthy.",
          source: { system: "supabase", ref: "project-ref" },
          status: "passed",
        },
        {
          evidence_id: "ev-migrations",
          task_id: "task-supabase-completed",
          created_at: "2026-07-03T00:02:00.000Z",
          evidence_type: "supabase_migration_status",
          summary: "Migration list was checked.",
          source: { system: "supabase", ref: "migration-list" },
          status: "passed",
        },
        {
          evidence_id: "ev-review",
          task_id: "task-supabase-completed",
          created_at: "2026-07-03T00:03:00.000Z",
          evidence_type: "manual_observation",
          summary: "Advisor warnings were reviewed.",
          source: { system: "codex_worker", ref: "advisor-review" },
          status: "passed",
        },
      ],
    })).toMatchObject({ valid: true });
  });

  it("requires business evidence for urgent material risk completion", () => {
    const basePacket = createTaskPacket({
      task_id: "task-urgent-material-completed",
      created_at: "2026-07-03T00:00:00.000Z",
      created_by: "user-1",
      request_summary: "Assess urgent material risk",
      raw_user_request: "현대자동차 GA 강판 긴급재 위험도 따져줘",
      desired_outcome: "Return urgent material risk with evidence.",
      task_type: "urgent_material_risk_assessment",
      status: "completed",
    });

    expect(validateTaskPacketForCompletion({
      ...basePacket,
      evidence: [
        {
          evidence_id: "ev-stock",
          task_id: "task-urgent-material-completed",
          created_at: "2026-07-03T00:01:00.000Z",
          evidence_type: "inventory_snapshot",
          summary: "Available and allocated stock were checked.",
          source: { system: "erp", ref: "stock-snapshot" },
          status: "passed",
        },
        {
          evidence_id: "ev-risk",
          task_id: "task-urgent-material-completed",
          created_at: "2026-07-03T00:02:00.000Z",
          evidence_type: "risk_assessment",
          summary: "Urgent material risk was classified.",
          source: { system: "gateway", ref: "risk-classifier" },
          status: "passed",
        },
      ],
    })).toMatchObject({
      valid: false,
      issues: expect.arrayContaining(["completed task requires passing evidence for every required verification"]),
    });

    expect(validateTaskPacketForCompletion({
      ...basePacket,
      evidence: [
        {
          evidence_id: "ev-stock",
          task_id: "task-urgent-material-completed",
          created_at: "2026-07-03T00:01:00.000Z",
          evidence_type: "inventory_snapshot",
          summary: "Available and allocated stock were checked.",
          source: { system: "erp", ref: "stock-snapshot" },
          status: "passed",
        },
        {
          evidence_id: "ev-delivery",
          task_id: "task-urgent-material-completed",
          created_at: "2026-07-03T00:02:00.000Z",
          evidence_type: "delivery_schedule",
          summary: "Inbound and delivery schedule were checked.",
          source: { system: "spreadsheet", ref: "delivery-schedule" },
          status: "passed",
        },
        {
          evidence_id: "ev-risk",
          task_id: "task-urgent-material-completed",
          created_at: "2026-07-03T00:03:00.000Z",
          evidence_type: "risk_assessment",
          summary: "Urgent material risk was classified.",
          source: { system: "gateway", ref: "risk-classifier" },
          status: "passed",
        },
      ],
    })).toMatchObject({ valid: true });
  });

  it("rejects raw evidence excerpts containing secrets or env contents", () => {
    expect(containsSensitiveRawExcerpt("OPENAI_API_KEY=sk-proj-secret")).toBe(true);
    expect(containsSensitiveRawExcerpt("-----BEGIN PRIVATE KEY-----")).toBe(true);
    expect(containsSensitiveRawExcerpt("loaded values from .env")).toBe(true);
    expect(containsSensitiveRawExcerpt("Authorization: Bearer abc.def.ghi")).toBe(true);
    expect(containsSensitiveRawExcerpt("token ghp_abcdefghijklmnop")).toBe(true);
    expect(containsSensitiveRawExcerpt("https://user:password@example.com")).toBe(true);
    expect(containsSensitiveRawExcerpt("CI check completed successfully")).toBe(false);

    const result = validateEvidenceItem({
      evidence_id: "ev-1",
      task_id: "task-1",
      created_at: "2026-07-03T00:00:00.000Z",
      evidence_type: "command_output",
      summary: "Unsafe command output",
      source: { system: "local_shell", command: "printenv" },
      status: "failed",
      raw_excerpt: "TOKEN=secret",
    });
    expect(result.valid).toBe(false);
    expect(result.issues).toContain("raw_excerpt contains sensitive content");
  });

  it("renders a Manual Codex handoff without parsing or executing the task", () => {
    const packet = createTaskPacket({
      task_id: "task-doc-1",
      created_at: "2026-07-03T00:00:00.000Z",
      created_by: "user-1",
      request_summary: "Draft a PRD",
      raw_user_request: "이 자료 기반으로 PRD 초안 만들어줘",
      desired_outcome: "Create a PRD draft and open questions.",
      task_type: "document_to_prd",
      context_refs: [{ type: "uploaded_file", label: "handoff", value: "pasted-text.txt" }],
    });

    const markdown = renderManualCodexHandoff(packet);
    expect(markdown).toContain("# Codex Task Packet");
    expect(markdown).toContain("## Forbidden Actions");
    expect(markdown).toContain("- do not overwrite existing docs without approval");
    expect(markdown).toContain("[uploaded_file] handoff: pasted-text.txt");
    expect(markdown).toContain("## Report Back With");
    expect(markdown).toContain("## Result Format");
    expect(markdown).toContain("## Conclusion");
    expect(markdown).toContain("생성 문서 경로 또는 초안 위치");

    expect(new ManualCodexAdapter().renderTaskPacket(packet)).toBe(markdown);
  });
});
