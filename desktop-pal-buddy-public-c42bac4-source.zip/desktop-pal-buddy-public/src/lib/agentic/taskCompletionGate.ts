import { createTaskCompletionPreview, type TaskCompletionPreview } from "./taskEvidenceCapture";
import type { ProductionStateReadbackContext } from "./evidence";
import { validateStatusTransition } from "./statusMachine";
import type { EvidenceItem, TaskPacket, TaskStatus, ValidationResult, WorkerOutcome } from "./types";

export const WORKBOARD_TASK_STATUSES = ["pending", "in_progress", "done"] as const;

export type WorkboardTaskStatus = (typeof WORKBOARD_TASK_STATUSES)[number];

export interface WorkboardStatusGateInput {
  packet: TaskPacket;
  current_status: string | null | undefined;
  target_status: string;
  evidence: EvidenceItem[];
  result_summary?: string;
  result_details?: string;
  outcome?: WorkerOutcome;
  approval_recorded?: boolean;
  trusted_production_state_contexts?: readonly ProductionStateReadbackContext[];
}

export interface WorkboardStatusGateResult {
  allowed: boolean;
  issues: string[];
  canonical_path: TaskStatus[];
  completion_preview?: TaskCompletionPreview;
}

export type WorkboardResultStatusReason =
  | "completion_ready"
  | "blocked_or_failed_result"
  | "advisory_or_incomplete_result"
  | "already_done"
  | "status_gate_blocked";

export interface WorkboardResultStatusRecommendationInput extends Omit<WorkboardStatusGateInput, "target_status"> {
  blocker_count?: number;
}

export interface WorkboardResultStatusRecommendation {
  target_status: WorkboardTaskStatus | null;
  reason: WorkboardResultStatusReason;
  gate: WorkboardStatusGateResult;
}

const WORKBOARD_STATUS_TO_CANONICAL: Record<WorkboardTaskStatus, TaskStatus> = {
  pending: "queued",
  in_progress: "running",
  done: "completed",
};

function isWorkboardTaskStatus(value: string | null | undefined): value is WorkboardTaskStatus {
  return WORKBOARD_TASK_STATUSES.includes(value as WorkboardTaskStatus);
}

function canonicalStartStatus(packet: TaskPacket, workboardStatus: WorkboardTaskStatus): TaskStatus {
  if (workboardStatus === "pending" && packet.required_approval) {
    return "waiting_for_approval";
  }

  return WORKBOARD_STATUS_TO_CANONICAL[workboardStatus];
}

function canonicalPathFor(
  packet: TaskPacket,
  currentStatus: WorkboardTaskStatus,
  targetStatus: WorkboardTaskStatus,
): TaskStatus[] {
  if (currentStatus === targetStatus) {
    return [canonicalStartStatus(packet, currentStatus)];
  }

  if (currentStatus === "pending" && targetStatus === "in_progress") {
    const start = canonicalStartStatus(packet, currentStatus);
    return start === "waiting_for_approval" ? [start, "running"] : [start, "triaging", "running"];
  }

  if (currentStatus === "pending" && targetStatus === "done") {
    const start = canonicalStartStatus(packet, currentStatus);
    return start === "waiting_for_approval"
      ? [start, "running", "verifying", "completed"]
      : [start, "triaging", "running", "verifying", "completed"];
  }

  if (currentStatus === "in_progress" && targetStatus === "done") {
    return ["running", "verifying", "completed"];
  }

  return [
    WORKBOARD_STATUS_TO_CANONICAL[currentStatus],
    WORKBOARD_STATUS_TO_CANONICAL[targetStatus],
  ];
}

function validateCanonicalPath(path: TaskStatus[]): ValidationResult {
  const issues: string[] = [];

  for (let index = 0; index < path.length - 1; index += 1) {
    const result = validateStatusTransition(path[index], path[index + 1]);

    if (!result.valid) {
      issues.push(...result.issues);
    }
  }

  return {
    valid: issues.length === 0,
    issues,
  };
}

export function validateWorkboardStatusGate(input: WorkboardStatusGateInput): WorkboardStatusGateResult {
  const issues: string[] = [];

  if (!isWorkboardTaskStatus(input.current_status)) {
    return {
      allowed: false,
      issues: [`unsupported workboard status: ${input.current_status ?? "unknown"}`],
      canonical_path: [],
    };
  }

  if (!isWorkboardTaskStatus(input.target_status)) {
    return {
      allowed: false,
      issues: [`unsupported workboard status: ${input.target_status}`],
      canonical_path: [],
    };
  }

  const canonicalPath = canonicalPathFor(input.packet, input.current_status, input.target_status);
  const transition = validateCanonicalPath(canonicalPath);

  if (!transition.valid) {
    issues.push(...transition.issues);
  }

  if (
    input.packet.required_approval &&
    !input.approval_recorded &&
    input.target_status !== "pending"
  ) {
    issues.push("approval required before task can move past pending");
  }

  let completionPreview: TaskCompletionPreview | undefined;

  if (input.target_status === "done") {
    completionPreview = createTaskCompletionPreview({
      packet: input.packet,
      evidence: input.evidence,
      result_summary: input.result_summary,
      result_details: input.result_details,
      outcome: input.outcome,
      trusted_production_state_contexts: input.trusted_production_state_contexts,
    });

    if (!completionPreview.can_complete) {
      issues.push(...completionPreview.validation.issues);
    }
  }

  return {
    allowed: issues.length === 0,
    issues: Array.from(new Set(issues)),
    canonical_path: canonicalPath,
    completion_preview: completionPreview,
  };
}

function progressRecommendation(
  input: WorkboardResultStatusRecommendationInput,
  reason: WorkboardResultStatusReason,
): WorkboardResultStatusRecommendation {
  if (input.current_status === "in_progress") {
    return {
      target_status: null,
      reason,
      gate: {
        allowed: true,
        issues: [],
        canonical_path: ["running"],
      },
    };
  }

  const gate = validateWorkboardStatusGate({
    ...input,
    target_status: "in_progress",
  });

  return {
    target_status: gate.allowed ? "in_progress" : null,
    reason: gate.allowed ? reason : "status_gate_blocked",
    gate,
  };
}

export function recommendWorkboardStatusAfterResult(
  input: WorkboardResultStatusRecommendationInput,
): WorkboardResultStatusRecommendation {
  if (input.current_status === "done") {
    return {
      target_status: null,
      reason: "already_done",
      gate: {
        allowed: true,
        issues: [],
        canonical_path: ["completed"],
      },
    };
  }

  if (
    input.blocker_count ||
    input.outcome === "blocked" ||
    input.outcome === "failed" ||
    input.outcome === "advisory_only"
  ) {
    return progressRecommendation(
      input,
      input.outcome === "advisory_only" ? "advisory_or_incomplete_result" : "blocked_or_failed_result",
    );
  }

  const completionGate = validateWorkboardStatusGate({
    ...input,
    target_status: "done",
  });

  if (completionGate.allowed) {
    return {
      target_status: "done",
      reason: "completion_ready",
      gate: completionGate,
    };
  }

  return progressRecommendation(input, "advisory_or_incomplete_result");
}
