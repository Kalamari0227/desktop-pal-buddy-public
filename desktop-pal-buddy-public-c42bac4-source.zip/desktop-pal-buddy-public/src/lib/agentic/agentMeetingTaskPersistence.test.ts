import { beforeEach, describe, expect, it, vi } from "vitest";
import { deterministicWorkboardTaskId, persistAgentMeetingGatewayTasks } from "./agentMeetingTaskPersistence";

type DbRow = Record<string, unknown>;

const state = vi.hoisted(() => ({
  tasks: [] as DbRow[],
  events: [] as DbRow[],
  taskInsertAttempts: [] as string[],
  eventInsertAttempts: [] as string[],
  eventReadResolvers: [] as Array<() => void>,
}));

function rowsFor(table: string): DbRow[] {
  return table === "tasks" ? state.tasks : state.events;
}

function payloadRows(payload: DbRow | readonly DbRow[]): readonly DbRow[] {
  if (Array.isArray(payload)) return payload;
  return [payload as DbRow];
}

function createQuery(table: string) {
  let rows = rowsFor(table).map((row) => ({ ...row }));
  const primaryKey = table === "tasks" ? "id" : "event_id";
  const resolveRows = () => {
    if (table !== "agent_events") {
      return Promise.resolve({ data: rows, error: null });
    }

    return new Promise<{ data: DbRow[]; error: null }>((resolve) => {
      state.eventReadResolvers.push(() => resolve({ data: rows, error: null }));
      if (state.eventReadResolvers.length === 2) {
        const resolvers = state.eventReadResolvers.splice(0);
        resolvers.forEach((release) => release());
      }
    });
  };
  const query = {
    select: vi.fn(() => query),
    insert: vi.fn((payload: DbRow | readonly DbRow[]) => {
      const values = payloadRows(payload);
      const attempts = table === "tasks" ? state.taskInsertAttempts : state.eventInsertAttempts;
      for (const row of values) {
        const key = row[primaryKey];
        if (typeof key === "string") {
          attempts.push(key);
        }
      }
      if (values.some((row) => rowsFor(table).some((existing) => existing[primaryKey] === row[primaryKey]))) {
        return Promise.resolve({
          data: null,
          error: { code: "23505", message: "duplicate key value violates unique constraint" },
        });
      }

      rowsFor(table).push(...values.map((row) => ({ ...row })));
      return Promise.resolve({ data: null, error: null });
    }),
    eq: vi.fn((column: string, value: unknown) => {
      rows = rows.filter((row) => row[column] === value);
      return query;
    }),
    in: vi.fn((column: string, values: readonly unknown[]) => {
      rows = rows.filter((row) => values.includes(row[column]));
      return query;
    }),
    then: (resolve: (value: { data: DbRow[]; error: null }) => void) => resolveRows().then(resolve),
  };

  return query;
}

const fromMock = vi.fn((table: string) => createQuery(table));

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    from: (table: string) => fromMock(table),
  },
}));

describe("agent meeting Gateway persistence concurrency", () => {
  beforeEach(() => {
    state.tasks.length = 0;
    state.events.length = 0;
    state.taskInsertAttempts.length = 0;
    state.eventInsertAttempts.length = 0;
    state.eventReadResolvers.length = 0;
    vi.clearAllMocks();
  });

  it("treats concurrent duplicate task and event keys as one successful lineage", async () => {
    // Given: two saves race with the same action list and initially empty storage.
    const actionItems = [{
      title: "재고 확인",
      description: "가용 재고를 조회한다.",
      severity: "medium",
      category: "delivery",
    }];
    const persist = () => persistAgentMeetingGatewayTasks({
      action_items: actionItems,
      topic: "주간 실행 회의",
      created_at: "2026-07-05T00:00:00.000Z",
    });

    // When: both callers save concurrently.
    const results = await Promise.all([persist(), persist()]);

    // Then: duplicate primary/event keys are idempotent success, not false failures.
    expect(results.every((result) => result.status === "complete")).toBe(true);
    expect(state.tasks).toHaveLength(1);
    expect(state.events).toHaveLength(1);
    expect(state.taskInsertAttempts).toHaveLength(2);
    expect(new Set(state.taskInsertAttempts).size).toBe(1);
    expect(state.eventInsertAttempts).toHaveLength(2);
    expect(new Set(state.eventInsertAttempts).size).toBe(1);
    expect(new Set(state.tasks.map((row) => row.source_id)).size).toBe(1);
    expect(new Set(state.events.map((row) => row.packet_task_id)).size).toBe(1);
    expect(new Set(state.events.map((row) => row.event_id)).size).toBe(1);
    expect(state.tasks[0]?.id).toMatch(/^[0-9a-f]{8}-[0-9a-f]{4}-8[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/);
    expect(state.events[0]?.event_id).toMatch(/-event-0$/);
    const sourceId = state.tasks[0]?.source_id;
    if (typeof sourceId === "string") {
      expect(state.tasks[0]?.id).toBe(await deterministicWorkboardTaskId(sourceId));
    }
  });
});
