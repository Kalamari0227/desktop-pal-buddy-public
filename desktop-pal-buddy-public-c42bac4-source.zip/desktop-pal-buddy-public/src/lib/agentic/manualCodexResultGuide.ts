import type { TaskPacket, VerificationType } from "./types";

const VERIFICATION_GUIDE: Record<VerificationType, string> = {
  test: "테스트 결과와 통과/실패 상태",
  lint: "린트 결과와 남은 경고",
  typecheck: "타입 확인 결과",
  build: "빌드 결과",
  ci_status: "CI 상태와 실패한 job 여부",
  diff_review: "검토한 변경 범위와 리스크",
  supabase_status: "Supabase 상태와 변경 여부",
  manual_review: "수동 검토로 확인한 사실",
  document_created: "생성 문서 경로 또는 초안 위치",
  inventory_status: "재고 수량, 위치, 기준 시점",
  order_status: "주문/오더 상태와 기준 시스템",
  delivery_status: "납기, 출하, ETA 상태",
  risk_assessment: "리스크 수준과 판단 근거",
  reply_draft: "생성한 답장 초안과 검토 포인트",
  substitution_review: "대체 자재 후보와 적합성 근거",
  production_state: "가상 ERP 생산계획의 예상·관측 priority/version 재조회 상태",
};

export function renderManualCodexResultGuide(packet: Pick<TaskPacket, "required_approval" | "verification_requirements">): string {
  const evidenceLines = packet.verification_requirements.length > 0
    ? packet.verification_requirements.map((requirement) => `- [passed|warning|failed] ${VERIFICATION_GUIDE[requirement.type] ?? requirement.type}`)
    : ["- [passed|warning|failed] 확인한 근거"];

  return [
    "## Conclusion",
    "<결론 한 문장. 완료, 보류, 실패, 경고 여부를 명확히 적기>",
    "",
    "## Evidence",
    ...evidenceLines,
    "",
    "## Blockers",
    packet.required_approval ? "- 승인 전 실제 변경 작업은 보류" : "- 없음",
    "",
    "## Risks",
    "- 없음",
    "",
    "## Next Action",
    "<사용자가 바로 할 다음 행동>",
    "",
    "## Retention",
    "<artifact/log, workboard, docs/wiki, no-save 중 권장 저장 위치>",
  ].join("\n");
}
