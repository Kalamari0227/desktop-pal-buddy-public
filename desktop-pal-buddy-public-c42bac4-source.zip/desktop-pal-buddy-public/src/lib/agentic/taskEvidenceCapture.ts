import {
  validateEvidenceItem,
  validateTaskPacketForCompletion,
  type ProductionStateReadbackContext,
} from "./evidence";
import type {
  EvidenceItem,
  EvidenceSourceSystem,
  EvidenceStatus,
  EvidenceType,
  TaskPacket,
  ValidationResult,
  VerificationType,
  WorkerOutcome,
} from "./types";

export interface TaskEvidenceDraftInput {
  packet: TaskPacket;
  evidence_type: EvidenceType;
  summary: string;
  source_system: EvidenceSourceSystem;
  status?: EvidenceStatus;
  raw_excerpt?: string;
  artifact_path?: string;
  source_ref?: string;
  created_at?: string;
  sequence?: number;
}

export interface TaskCompletionPreviewInput {
  packet: TaskPacket;
  evidence: EvidenceItem[];
  result_summary?: string;
  result_details?: string;
  outcome?: WorkerOutcome;
  next_action?: string;
  trusted_production_state_contexts?: readonly ProductionStateReadbackContext[];
}

export interface TaskCompletionPreview {
  packet: TaskPacket;
  validation: ValidationResult;
  missing_verification_types: VerificationType[];
  can_complete: boolean;
}

const VERIFICATION_TO_EVIDENCE: Record<VerificationType, EvidenceType[]> = {
  test: ["test_result", "command_output"],
  lint: ["command_output"],
  typecheck: ["command_output"],
  build: ["command_output"],
  ci_status: ["ci_status"],
  diff_review: ["file_diff", "manual_observation"],
  supabase_status: [
    "supabase_project_status",
    "supabase_migration_status",
    "edge_function_status",
    "advisor_result",
  ],
  manual_review: ["manual_observation"],
  document_created: ["generated_document", "file_diff"],
  inventory_status: ["inventory_snapshot", "manual_observation"],
  order_status: ["order_status", "manual_observation"],
  delivery_status: ["delivery_schedule", "manual_observation"],
  risk_assessment: ["risk_assessment", "manual_observation"],
  reply_draft: ["generated_reply", "manual_observation"],
  substitution_review: ["substitution_option", "manual_observation"],
  production_state: ["production_state"],
};

function evidenceTypesForRequirement(requirement: TaskPacket["verification_requirements"][number]): EvidenceType[] {
  const source = requirement.command_or_source?.toLowerCase() ?? "";

  if (requirement.type === "supabase_status") {
    if (source.includes("project health")) {
      return ["supabase_project_status"];
    }
    if (source.includes("migration")) {
      return ["supabase_migration_status"];
    }
    if (source.includes("edge function")) {
      return ["edge_function_status"];
    }
    if (source.includes("advisor")) {
      return ["advisor_result"];
    }
  }

  if (requirement.type === "manual_review" && source.includes("advisor")) {
    return ["manual_observation", "advisor_result"];
  }

  return VERIFICATION_TO_EVIDENCE[requirement.type];
}

export function suggestEvidenceTypesForTask(packet: TaskPacket): EvidenceType[] {
  const suggestions = packet.verification_requirements
    .filter((requirement) => requirement.required)
    .flatMap((requirement) => evidenceTypesForRequirement(requirement));

  return Array.from(new Set(suggestions));
}

export function findMissingVerificationTypes(
  packet: TaskPacket,
  evidence: EvidenceItem[],
  productionStateContexts: readonly ProductionStateReadbackContext[] = [],
): VerificationType[] {
  return packet.verification_requirements
    .filter((requirement) => requirement.required)
    .filter((requirement) => {
      const allowedEvidenceTypes = evidenceTypesForRequirement(requirement);
      return !evidence.some(
        (item) =>
          item.task_id === packet.task_id &&
          item.status === "passed" &&
          allowedEvidenceTypes.includes(item.evidence_type) &&
          validateEvidenceItem(item, { trusted_production_state_contexts: productionStateContexts }).valid
      );
    })
    .map((requirement) => requirement.type);
}

export function suggestNextEvidenceType(packet: TaskPacket, evidence: EvidenceItem[]): EvidenceType {
  const missingRequirement = packet.verification_requirements
    .filter((requirement) => requirement.required)
    .find((requirement) => {
      const allowedEvidenceTypes = evidenceTypesForRequirement(requirement);
      return !evidence.some(
        (item) =>
          item.task_id === packet.task_id &&
          item.status === "passed" &&
          allowedEvidenceTypes.includes(item.evidence_type)
      );
    });

  return missingRequirement ? evidenceTypesForRequirement(missingRequirement)[0] : "manual_observation";
}

export function createTaskEvidenceItem(input: TaskEvidenceDraftInput): {
  evidence: EvidenceItem;
  validation: ValidationResult;
} {
  const sequence = input.sequence ?? input.packet.evidence.length + 1;
  const evidence: EvidenceItem = {
    evidence_id: `${input.packet.task_id}-evidence-${sequence}`,
    task_id: input.packet.task_id,
    created_at: input.created_at ?? new Date().toISOString(),
    evidence_type: input.evidence_type,
    summary: input.summary.trim(),
    source: {
      system: input.source_system,
      ref: input.source_ref?.trim() || undefined,
    },
    status: input.status ?? "passed",
    raw_excerpt: input.raw_excerpt?.trim() || undefined,
    artifact_path: input.artifact_path?.trim() || undefined,
  };

  return {
    evidence,
    validation: validateEvidenceItem(evidence),
  };
}

export function createTaskCompletionPreview(input: TaskCompletionPreviewInput): TaskCompletionPreview {
  const evidence = input.evidence;
  const packet: TaskPacket = {
    ...input.packet,
    status: "completed",
    evidence,
    result: {
      outcome: input.outcome ?? "passed",
      summary: input.result_summary?.trim() || "Worker result captured from the workboard.",
      details: input.result_details?.trim() || undefined,
    },
    next_action: input.next_action?.trim() || input.packet.next_action,
  };
  const validationContext = { trusted_production_state_contexts: input.trusted_production_state_contexts };
  const validation = validateTaskPacketForCompletion(packet, validationContext);
  const missingVerificationTypes = findMissingVerificationTypes(
    packet,
    evidence,
    input.trusted_production_state_contexts,
  );

  return {
    packet,
    validation,
    missing_verification_types: missingVerificationTypes,
    can_complete: validation.valid && missingVerificationTypes.length === 0,
  };
}
