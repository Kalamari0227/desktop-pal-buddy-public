import { describe, expect, it } from "vitest";
import { renderManualCodexResultGuide } from "./manualCodexResultGuide";
import { createTaskPacket } from "./taskTemplates";

describe("manual Codex result guide", () => {
  it("renders a pasted result guide from packet verification requirements", () => {
    const packet = createTaskPacket({
      task_id: "task-1",
      created_at: "2026-07-04T00:00:00.000Z",
      created_by: "test",
      task_type: "delivery_delay_risk_check",
      raw_user_request: "현대자동차 GA 강판 납기 지연 리스크 확인해줘",
      request_summary: "납기 지연 리스크 확인",
      desired_outcome: "납기 상태, 리스크, 다음 행동을 보고합니다.",
    });

    expect(renderManualCodexResultGuide(packet)).toContain("## Conclusion");
    expect(renderManualCodexResultGuide(packet)).toContain("## Evidence");
    expect(renderManualCodexResultGuide(packet)).toContain("주문/오더 상태와 기준 시스템");
    expect(renderManualCodexResultGuide(packet)).toContain("납기, 출하, ETA 상태");
    expect(renderManualCodexResultGuide(packet)).toContain("리스크 수준과 판단 근거");
    expect(renderManualCodexResultGuide(packet)).toContain("## Next Action");
  });

  it("marks approval-gated templates as blocked until approval", () => {
    const packet = createTaskPacket({
      task_id: "task-approval",
      created_at: "2026-07-04T00:00:00.000Z",
      created_by: "test",
      task_type: "supabase_staging_check",
      raw_user_request: "staging DB migration 실행해줘",
      request_summary: "스테이징 마이그레이션 요청",
      desired_outcome: "승인 전 읽기 전용 확인만 수행합니다.",
    });

    expect(renderManualCodexResultGuide(packet)).toContain("승인 전 실제 변경 작업은 보류");
  });
});
