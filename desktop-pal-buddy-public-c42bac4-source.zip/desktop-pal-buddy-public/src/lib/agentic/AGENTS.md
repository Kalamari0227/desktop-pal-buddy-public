# Agentic Domain Core

This guide adds rules for `src/lib/agentic/`; inherit repository and `src/` guidance.
Paths below are relative to this directory unless prefixed with `docs/` or `src/`.

## Contract Sources and File Map

- Canonical contracts: `docs/agent-os/task-packet-schema.md`, `docs/agent-os/evidence-ledger-schema.md`, and `docs/agent-os/approval-gate-policy.md`.
- `types.ts` declares domain shapes and enum values; `schemas.ts` validates runtime payloads with Zod.
- `taskTemplates.ts`, `riskClassifier.ts`, and `approvalPolicy.ts` own deterministic task defaults and policy classification.
- `gatewayCodexAgent.ts` builds intake drafts; `manualCodexHandoff.ts` renders the worker handoff.
- `*GatewayRouting.ts` and `taskWorkboardRouting.ts` adapt workspace inputs; `gatewayWorkboardIntake.ts` maps packets to Workboard rows.
- `strategy.ts` validates strategy/version membership and pins the reference at intake.
- `demoTaskPackets.ts` stores and resolves explicit demo packet snapshots.
- `statusMachine.ts` owns canonical transitions; `taskCompletionGate.ts` connects them to Workboard statuses.
- `evidence.ts` validates evidence and completion; `taskEvidenceCapture.ts` constructs evidence and completion previews.
- `manualCodexResultIntake.ts` parses returned worker output; `manualCodexResultGuide.ts` describes the return format.
- `approvalPersistence.ts`, `evidencePersistence.ts`, `eventPersistence.ts`, and `resultPersistence.ts` map ledger records.
- `agentMeetingTaskPersistence.ts` coordinates meeting task/event writes and reports partial persistence.

## Intake and Policy Ownership

- Preserve `raw_user_request` across routing, handoff, persistence, and rereads; never replace it with AI summaries or edited display text.
- AI suggestions may supply intake wording, context, and supported task-type suggestions; deterministic policy retains authority over risk, approval, forbidden actions, status, evidence, and handoff.
- Keep required-approval tasks behind the policy gate even when a suggestion describes them as executable.
- Gateway currently returns `manual_only` for supported drafts: it prepares intake and handoff, not automatic worker execution.
- Unsupported or ambiguous requests return `needs_manual_review` with no packet or worker handoff.
- Change TypeScript types, runtime schemas, validation logic, and relevant contract documentation together when changing a payload contract.
- Validate external or persisted payloads at runtime; TypeScript assertions alone do not establish validity.

## Strategy and Demo Identity

- `strategy_ref` is optional; omitted references must preserve the legacy unlinked path.
- A linked reference is the pair `strategy_id` and `strategy_version_id`; validate both and confirm version membership.
- Pin the selected pair at intake and preserve it on reread. Never infer it from titles, descriptions, or a newer catalog version.
- Strategy association must not alter the original request or weaken deterministic policy.
- Malformed, unknown, mismatched, or null references must fail closed: no packet, no handoff, and no Workboard save.
- Use `demo_intake_required: true` plus `demo_intake_packet` for explicit demo snapshots; clone and validate the packet on write/read.
- Validate demo `source: "gateway"`, `source_id`, evidence/retention task associations, and strategy membership against the preserved packet.
- Missing or corrupt marked metadata requires manual review; do not rebuild it from mutable display fields.
- Legacy routing is allowed only when both demo metadata fields are absent. Do not borrow evidence across strategy versions.

## Persistence and Completion

- Distinguish Workboard/database row identity from domain packet identity: ledger row `task_id` refers to the Workboard task; `packet_task_id` refers to `TaskPacket.task_id`.
- Gateway Workboard rows use `source_id` for packet identity; domain evidence/events use their `task_id` for packet identity.
- Keep evidence, results, approvals, and events associated with the intended task and packet through both mapping directions.
- Apply latest-record helpers only to records already scoped to the intended task/packet; an unrelated approval cannot unlock a gate.
- On meeting save retries or duplicate-key responses, verify task ownership and the validated persisted payload before reusing a row or repairing events.
- Deterministic IDs and duplicate acceptance alone do not prove retry correctness; preserve partial-write reporting and test the retry boundaries being changed.
- Route Workboard `pending`/`in_progress`/`done` changes through `validateWorkboardStatusGate`; do not bypass canonical transitions.
- Required approval must be recorded for the same scope before progress; completion additionally requires the evidence/result preview to pass.
- Completion needs safe, task-matched evidence and passing evidence for every required verification; preserve distinct evidence matching.
- Keep blocked, failed, advisory-only, or incomplete outcomes from becoming `done`; never substitute generated prose for verification.

## Focused Verification

- Run selected colocated tests with `npm test -- src/lib/agentic/<name>.test.ts` from the repository root.
- Contract/policy changes: start with `domainCore.test.ts`, `gatewayCodexAgent.test.ts`, and `taskCompletionGate.test.ts`.
- Strategy/demo changes: use `strategy.test.ts`, `demoTaskPackets.test.ts`, and affected routing tests.
- Persistence changes: use the matching `*Persistence.test.ts`, including meeting concurrency/retry coverage when applicable.
- For a cross-module domain change, run `npm test -- src/lib/agentic`; follow repository typecheck guidance when types change.
