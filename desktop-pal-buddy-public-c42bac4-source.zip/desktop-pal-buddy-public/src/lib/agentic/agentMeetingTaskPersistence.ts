import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";
import { createWorkerEvent, workerEventToAgentEventInsert } from "./eventPersistence";
import { gatewayPacketToWorkboardTaskInsert } from "./gatewayWorkboardIntake";
import {
  createAgentMeetingGatewayDraft,
  type AgentMeetingActionItem,
} from "./agentMeetingGatewayRouting";
import type { TaskPacket } from "./types";

export type AgentMeetingTaskPersistenceResult =
  | {
      readonly status: "complete";
      readonly created_task_count: number;
      readonly existing_task_count: number;
      readonly recorded_event_count: number;
      readonly repaired_event_count: number;
    }
  | {
      readonly status: "partial";
      readonly created_task_count: number;
      readonly existing_task_count: number;
      readonly missing_event_count: number;
    };

export interface PersistAgentMeetingTasksInput {
  readonly action_items: readonly AgentMeetingActionItem[];
  readonly topic?: string | null;
  readonly meeting_id?: string | null;
  readonly created_at?: string;
}

type WorkboardTaskInsert = Database["public"]["Tables"]["tasks"]["Insert"];

type MeetingTaskDraft = {
  readonly action_item: AgentMeetingActionItem;
  readonly packet: TaskPacket;
};

type NewMeetingTask = MeetingTaskDraft & {
  readonly workboard_task_id: string;
  readonly row: WorkboardTaskInsert;
};

export class AgentMeetingPersistenceError extends Error {
  readonly code: "packet_creation_failed" | "task_lookup_failed" | "task_insert_failed";

  constructor(code: AgentMeetingPersistenceError["code"]) {
    super(code);
    this.name = "AgentMeetingPersistenceError";
    this.code = code;
  }
}

function isDuplicateKeyError(error: { code?: string | null; details?: string | null; message: string } | null): boolean {
  return error?.code === "23505" || /duplicate key|unique constraint|already exists/i.test(
    [error?.message, error?.details].filter(Boolean).join(" "),
  );
}

export async function deterministicWorkboardTaskId(packetTaskId: string): Promise<string> {
  const digest = await globalThis.crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(`prometheus:agent-meeting-task:${packetTaskId}`),
  );
  const bytes = new Uint8Array(digest.slice(0, 16));
  // UUIDv8 custom bits identify the SHA-256-derived, deterministic UUID.
  bytes[6] = (bytes[6] & 0x0f) | 0x80;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  const hex = Array.from(bytes, (byte) => byte.toString(16).padStart(2, "0")).join("");
  return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}

function buildTaskDrafts(input: PersistAgentMeetingTasksInput, createdAt: string): readonly MeetingTaskDraft[] {
  return input.action_items.map((actionItem) => {
    const draft = createAgentMeetingGatewayDraft({
      action_item: actionItem,
      topic: input.topic,
      meeting_id: input.meeting_id,
      created_at: createdAt,
    });

    if (!draft.packet) {
      throw new AgentMeetingPersistenceError("packet_creation_failed");
    }

    return { action_item: actionItem, packet: draft.packet };
  });
}

async function buildNewMeetingTask(
  draft: MeetingTaskDraft,
  input: PersistAgentMeetingTasksInput,
  createdAt: string,
): Promise<NewMeetingTask> {
  const workboardTaskId = await deterministicWorkboardTaskId(draft.packet.task_id);
  const payload = gatewayPacketToWorkboardTaskInsert({
    packet: draft.packet,
    workboard_task_id: workboardTaskId,
    created_at: createdAt,
  });

  return {
    ...draft,
    workboard_task_id: workboardTaskId,
    row: {
      ...payload,
      title: draft.action_item.title,
      description: [
        payload.description,
        draft.action_item.description,
        `Gateway packet id: ${draft.packet.task_id}`,
        `회의 주제: ${input.topic || "미지정"}`,
        `회의 액션 카테고리: ${draft.action_item.category || "미지정"}`,
        `회의 우선순위: ${draft.action_item.severity || "미지정"}`,
        `금지 작업: ${draft.packet.forbidden_actions.join(", ")}`,
      ].filter(Boolean).join("\n\n"),
    },
  };
}

function eventRowFor(draft: MeetingTaskDraft, workboardTaskId: string, createdAt: string) {
  const requiresApproval = draft.packet.required_approval;
  return workerEventToAgentEventInsert({
    workboard_task_id: workboardTaskId,
    event: createWorkerEvent({
      packet_task_id: draft.packet.task_id,
      event_type: requiresApproval ? "approval_required" : "accepted",
      message: requiresApproval
        ? "에이전트 회의 Gateway 작업이 승인 대기 상태로 생성되었습니다."
        : "에이전트 회의에서 Gateway 작업이 생성되었습니다.",
      severity: requiresApproval ? "warning" : "info",
      requires_user_action: requiresApproval,
      created_at: createdAt,
      sequence: 0,
    }),
  });
}

export async function persistAgentMeetingGatewayTasks(
  input: PersistAgentMeetingTasksInput,
): Promise<AgentMeetingTaskPersistenceResult> {
  const createdAt = input.created_at ?? new Date().toISOString();
  const drafts = buildTaskDrafts(input, createdAt);
  const packetTaskIds = drafts.map((draft) => draft.packet.task_id);
  const { data: existingTasks, error: existingTaskError } = await supabase
    .from("tasks")
    .select("id, source_id")
    .eq("source", "gateway")
    .in("source_id", packetTaskIds);

  if (existingTaskError) {
    throw new AgentMeetingPersistenceError("task_lookup_failed");
  }

  const existingTaskIdByPacket = new Map<string, string>();
  for (const row of existingTasks ?? []) {
    if (row.source_id) {
      existingTaskIdByPacket.set(row.source_id, row.id);
    }
  }

  const newTasks = await Promise.all(drafts
    .filter((draft) => !existingTaskIdByPacket.has(draft.packet.task_id))
    .map((draft) => buildNewMeetingTask(draft, input, createdAt)));

  const taskInsertResults = await Promise.all(newTasks.map(async (task) => {
    const { error } = await supabase.from("tasks").insert(task.row);
    return {
      task,
      duplicate: isDuplicateKeyError(error),
      failed: Boolean(error && !isDuplicateKeyError(error)),
    };
  }));

  if (taskInsertResults.some((result) => result.failed)) {
    throw new AgentMeetingPersistenceError("task_insert_failed");
  }

  const insertedTaskCount = taskInsertResults.filter((result) => !result.duplicate).length;

  const taskIdByPacket = new Map(existingTaskIdByPacket);
  for (const task of newTasks) {
    taskIdByPacket.set(task.packet.task_id, task.workboard_task_id);
  }

  const { data: existingEvents, error: existingEventError } = await supabase
    .from("agent_events")
    .select("packet_task_id")
    .in("packet_task_id", packetTaskIds);

  if (existingEventError) {
    return {
      status: "partial",
      created_task_count: insertedTaskCount,
      existing_task_count: drafts.length - insertedTaskCount,
      missing_event_count: drafts.length,
    };
  }

  const packetsWithEvents = new Set((existingEvents ?? []).map((event) => event.packet_task_id));
  const draftsMissingEvents = drafts.filter((draft) => !packetsWithEvents.has(draft.packet.task_id));
  const eventRows = draftsMissingEvents.map((draft) => {
    const workboardTaskId = taskIdByPacket.get(draft.packet.task_id);
    if (!workboardTaskId) {
      throw new AgentMeetingPersistenceError("task_lookup_failed");
    }
    return eventRowFor(draft, workboardTaskId, createdAt);
  });

  const eventInsertResults = await Promise.all(eventRows.map(async (row) => {
    const { error } = await supabase.from("agent_events").insert(row);
    return {
      row,
      duplicate: isDuplicateKeyError(error),
      failed: Boolean(error && !isDuplicateKeyError(error)),
    };
  }));
  const failedEventCount = eventInsertResults.filter((result) => result.failed).length;

  if (failedEventCount > 0) {
    return {
      status: "partial",
      created_task_count: insertedTaskCount,
      existing_task_count: drafts.length - insertedTaskCount,
      missing_event_count: failedEventCount,
    };
  }

  const successfulEventResults = eventInsertResults.filter((result) => !result.duplicate);
  const repairedEventCount = successfulEventResults.filter((result) => (
    existingTaskIdByPacket.has(result.row.packet_task_id)
  )).length;

  return {
    status: "complete",
    created_task_count: insertedTaskCount,
    existing_task_count: drafts.length - insertedTaskCount,
    recorded_event_count: successfulEventResults.length,
    repaired_event_count: repairedEventCount,
  };
}
