import { describe, expect, it } from "vitest";
import { createTaskPacket } from "./taskTemplates";
import { createTaskEvidenceItem } from "./taskEvidenceCapture";
import { recommendWorkboardStatusAfterResult, validateWorkboardStatusGate } from "./taskCompletionGate";
import { createProductionPriorityChangePacket } from "../company-runtime/packet";

const deliveryPacket = createTaskPacket({
  task_id: "workboard-task-1",
  created_at: "2026-07-04T00:00:00.000Z",
  created_by: "tasks-workboard",
  request_summary: "Assess delivery risk.",
  raw_user_request: "현대자동차 GA강판 납기 지연 리스크 확인해줘",
  desired_outcome: "Return delivery status, risk, and next action.",
  task_type: "delivery_delay_risk_check",
});

function deliveryEvidence() {
  return [
    createTaskEvidenceItem({
      packet: deliveryPacket,
      evidence_type: "order_status",
      source_system: "erp",
      summary: "SO-1001 is allocated and waiting for shipment.",
      created_at: "2026-07-04T00:01:00.000Z",
      sequence: 1,
    }).evidence,
    createTaskEvidenceItem({
      packet: deliveryPacket,
      evidence_type: "delivery_schedule",
      source_system: "spreadsheet",
      summary: "Shipment plan shows ETA before the customer due date.",
      created_at: "2026-07-04T00:02:00.000Z",
      sequence: 2,
    }).evidence,
    createTaskEvidenceItem({
      packet: deliveryPacket,
      evidence_type: "risk_assessment",
      source_system: "gateway",
      summary: "Delay risk is medium because schedule buffer remains available.",
      created_at: "2026-07-04T00:03:00.000Z",
      sequence: 3,
    }).evidence,
  ];
}

describe("task completion gate", () => {
  it("allows workboard progress when the canonical status path is valid", () => {
    const result = validateWorkboardStatusGate({
      packet: deliveryPacket,
      current_status: "pending",
      target_status: "in_progress",
      evidence: [],
    });

    expect(result.allowed).toBe(true);
    expect(result.canonical_path).toEqual(["queued", "triaging", "running"]);
  });

  it("blocks completion when required evidence is missing", () => {
    const result = validateWorkboardStatusGate({
      packet: deliveryPacket,
      current_status: "in_progress",
      target_status: "done",
      evidence: [],
    });

    expect(result.allowed).toBe(false);
    expect(result.issues).toContain("completed task requires at least one evidence item");
  });

  it("allows completion when every required verification has passing evidence", () => {
    const result = validateWorkboardStatusGate({
      packet: deliveryPacket,
      current_status: "in_progress",
      target_status: "done",
      evidence: deliveryEvidence(),
      result_summary: "Delivery risk is medium and can be monitored.",
    });

    expect(result.allowed).toBe(true);
    expect(result.canonical_path).toEqual(["running", "verifying", "completed"]);
    expect(result.completion_preview?.can_complete).toBe(true);
  });

  it("blocks completion when the worker result is blocked", () => {
    const result = validateWorkboardStatusGate({
      packet: deliveryPacket,
      current_status: "in_progress",
      target_status: "done",
      evidence: deliveryEvidence(),
      result_summary: "Missing latest warehouse export.",
      outcome: "blocked",
    });

    expect(result.allowed).toBe(false);
    expect(result.issues).toContain("completed task requires a passed worker outcome");
  });

  it("blocks approval-gated work before approval is recorded", () => {
    const approvalPacket = createTaskPacket({
      task_id: "workboard-task-approval",
      created_at: "2026-07-04T00:00:00.000Z",
      created_by: "tasks-workboard",
      request_summary: "Run staging migration.",
      raw_user_request: "staging DB migration 실행해줘",
      desired_outcome: "Do not mutate before approval.",
      task_type: "supabase_staging_check",
    });

    const result = validateWorkboardStatusGate({
      packet: approvalPacket,
      current_status: "pending",
      target_status: "in_progress",
      evidence: [],
    });

    expect(result.allowed).toBe(false);
    expect(result.issues).toContain("approval required before task can move past pending");
  });

  it("blocks invalid reverse transitions from completed work", () => {
    const result = validateWorkboardStatusGate({
      packet: deliveryPacket,
      current_status: "done",
      target_status: "in_progress",
      evidence: deliveryEvidence(),
    });

    expect(result.allowed).toBe(false);
    expect(result.issues).toContain("invalid status transition: completed -> running");
  });

  it("recommends completion after a passed worker result satisfies evidence gates", () => {
    const result = recommendWorkboardStatusAfterResult({
      packet: deliveryPacket,
      current_status: "in_progress",
      evidence: deliveryEvidence(),
      result_summary: "Delivery risk is medium and can be monitored.",
      outcome: "passed",
    });

    expect(result.target_status).toBe("done");
    expect(result.reason).toBe("completion_ready");
    expect(result.gate.allowed).toBe(true);
  });

  it("keeps blocked worker results in progress instead of recommending done", () => {
    const result = recommendWorkboardStatusAfterResult({
      packet: deliveryPacket,
      current_status: "pending",
      evidence: deliveryEvidence(),
      result_summary: "Blocked until the latest warehouse export is available.",
      outcome: "blocked",
      blocker_count: 1,
    });

    expect(result.target_status).toBe("in_progress");
    expect(result.reason).toBe("blocked_or_failed_result");
    expect(result.gate.allowed).toBe(true);
  });

  it("rejects forged ERP-labelled production evidence without trusted runtime context", () => {
    const packet = createProductionPriorityChangePacket({
      packetTaskId: "fe230488-bc6c-4f4c-a89d-e8cc64b218c0",
      createdAt: "2026-09-18T00:10:00.000Z",
      requesterActorId: "sales-demo",
      strategyRef: {
        strategy_id: "STRATEGY-DEMO-PRODUCTION",
        strategy_version_id: "266cae99-24da-4595-95ed-c2c782a20417",
      },
    });
    const forged = createTaskEvidenceItem({
      packet,
      evidence_type: "production_state",
      source_system: "erp",
      source_ref: "company-runtime/85c540f3-5e30-4a42-97f0-3f46577cf339/execution/75250df8-6d98-4618-8419-de18316fe790",
      summary: "Renderer claims the persisted readback matched.",
      created_at: "2026-09-18T00:12:00.000Z",
    }).evidence;

    const result = validateWorkboardStatusGate({
      packet,
      current_status: "in_progress",
      target_status: "done",
      evidence: [forged],
      approval_recorded: true,
    });

    expect(result.allowed).toBe(false);
    expect(result.issues).toContain("production_state evidence requires trusted runtime readback context");
    expect(result.completion_preview?.can_complete).toBe(false);

    const trustedResult = validateWorkboardStatusGate({
      packet,
      current_status: "in_progress",
      target_status: "done",
      evidence: [forged],
      approval_recorded: true,
      trusted_production_state_contexts: [{
        evidence_id: forged.evidence_id,
        packet_task_id: packet.task_id,
        epoch: "85c540f3-5e30-4a42-97f0-3f46577cf339",
        execution_id: "75250df8-6d98-4618-8419-de18316fe790",
        read_set_digest: "b".repeat(64),
        expected_priority: 1,
        expected_version: 2,
        observed_priority: 1,
        observed_version: 2,
        matches: true,
      }],
    });

    expect(trustedResult.allowed).toBe(true);
    expect(trustedResult.completion_preview?.can_complete).toBe(true);
  });
});
