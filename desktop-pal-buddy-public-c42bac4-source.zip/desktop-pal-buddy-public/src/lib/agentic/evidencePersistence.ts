import type { Database } from "@/integrations/supabase/types";
import type { EvidenceItem, EvidenceSource, EvidenceSourceSystem, EvidenceStatus, EvidenceType } from "./types";

export type AgentEvidenceRow = Database["public"]["Tables"]["agent_evidence"]["Row"];
export type AgentEvidenceInsert = Database["public"]["Tables"]["agent_evidence"]["Insert"];

export interface PersistEvidenceInput {
  workboard_task_id: string;
  evidence: EvidenceItem;
}

function nullable(value?: string): string | null {
  return value?.trim() || null;
}

function compactSource(row: AgentEvidenceRow): EvidenceSource {
  return {
    system: row.source_system as EvidenceSourceSystem,
    url: row.source_url ?? undefined,
    path: row.source_path ?? undefined,
    command: row.source_command ?? undefined,
    ref: row.source_ref ?? undefined,
  };
}

export function evidenceItemToAgentEvidenceInsert(input: PersistEvidenceInput): AgentEvidenceInsert {
  const { evidence } = input;

  return {
    task_id: input.workboard_task_id,
    packet_task_id: evidence.task_id,
    evidence_id: evidence.evidence_id,
    evidence_type: evidence.evidence_type,
    summary: evidence.summary,
    source_system: evidence.source.system,
    source_url: nullable(evidence.source.url),
    source_path: nullable(evidence.source.path),
    source_command: nullable(evidence.source.command),
    source_ref: nullable(evidence.source.ref),
    status: evidence.status,
    raw_excerpt: nullable(evidence.raw_excerpt),
    artifact_path: nullable(evidence.artifact_path),
    created_at: evidence.created_at,
  };
}

export function agentEvidenceRowToEvidenceItem(row: AgentEvidenceRow): EvidenceItem {
  return {
    evidence_id: row.evidence_id,
    task_id: row.packet_task_id,
    created_at: row.created_at,
    evidence_type: row.evidence_type as EvidenceType,
    summary: row.summary,
    source: compactSource(row),
    status: row.status as EvidenceStatus,
    raw_excerpt: row.raw_excerpt ?? undefined,
    artifact_path: row.artifact_path ?? undefined,
  };
}

export function agentEvidenceRowsToEvidenceItems(rows: AgentEvidenceRow[]): EvidenceItem[] {
  return [...rows]
    .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime())
    .map(agentEvidenceRowToEvidenceItem);
}
