import type { Database, Json } from "@/integrations/supabase/types";
import type {
  Blocker,
  ContextRef,
  RetentionDecision,
  WorkerOutcome,
  WorkerResult,
} from "./types";

export type AgentResultRow = Database["public"]["Tables"]["agent_results"]["Row"];
export type AgentResultInsert = Database["public"]["Tables"]["agent_results"]["Insert"];

export interface WorkerResultIntakeRecord {
  result: WorkerResult;
  blockers: Blocker[];
  next_action?: string;
  retention_decision?: RetentionDecision;
  created_at?: string;
}

export interface PersistWorkerResultInput extends WorkerResultIntakeRecord {
  workboard_task_id: string;
  packet_task_id: string;
}

function nullable(value?: string): string | null {
  return value?.trim() || null;
}

function stringsToJson(value: string[] | undefined): Json {
  return value ?? [];
}

function contextRefsToJson(value: ContextRef[] | undefined): Json {
  return (value ?? []).map((ref) => ({
    type: ref.type,
    label: ref.label,
    value: ref.value,
  }));
}

function blockersToJson(value: Blocker[] | undefined): Json {
  return (value ?? []).map((blocker) => ({
    blocker_id: blocker.blocker_id,
    type: blocker.type,
    summary: blocker.summary,
    requires_user_action: blocker.requires_user_action,
    suggested_resolution: blocker.suggested_resolution,
  }));
}

function retentionDecisionToJson(value: RetentionDecision | undefined): Json | null {
  if (!value) {
    return null;
  }

  return {
    task_id: value.task_id,
    save_decision: value.save_decision,
    reason: value.reason,
    requires_user_approval: value.requires_user_approval,
    proposed_target: value.proposed_target
      ? {
          path: value.proposed_target.path,
          table: value.proposed_target.table,
          issue_id: value.proposed_target.issue_id,
          skill_name: value.proposed_target.skill_name,
        }
      : undefined,
  };
}

function arrayFromJson<T>(value: Json | null): T[] {
  return Array.isArray(value) ? (value as T[]) : [];
}

function objectFromJson<T>(value: Json | null): T | undefined {
  return value && typeof value === "object" && !Array.isArray(value) ? (value as T) : undefined;
}

export function workerResultToAgentResultInsert(input: PersistWorkerResultInput): AgentResultInsert {
  return {
    task_id: input.workboard_task_id,
    packet_task_id: input.packet_task_id,
    outcome: input.result.outcome,
    summary: input.result.summary,
    details: nullable(input.result.details),
    changed_paths: stringsToJson(input.result.changed_paths),
    checked_refs: contextRefsToJson(input.result.checked_refs),
    risks: stringsToJson(input.result.risks),
    blockers: blockersToJson(input.blockers),
    next_action: nullable(input.next_action),
    retention_decision: retentionDecisionToJson(input.retention_decision),
    created_at: input.created_at,
  };
}

export function agentResultRowToWorkerResultIntake(row: AgentResultRow): WorkerResultIntakeRecord {
  return {
    result: {
      outcome: row.outcome as WorkerOutcome,
      summary: row.summary,
      details: row.details ?? undefined,
      changed_paths: arrayFromJson<string>(row.changed_paths),
      checked_refs: arrayFromJson<ContextRef>(row.checked_refs),
      risks: arrayFromJson<string>(row.risks),
    },
    blockers: arrayFromJson<Blocker>(row.blockers),
    next_action: row.next_action ?? undefined,
    retention_decision: objectFromJson<RetentionDecision>(row.retention_decision),
    created_at: row.created_at,
  };
}

export function latestAgentResultRow(rows: AgentResultRow[]): AgentResultRow | null {
  return [...rows].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())[0] ?? null;
}
