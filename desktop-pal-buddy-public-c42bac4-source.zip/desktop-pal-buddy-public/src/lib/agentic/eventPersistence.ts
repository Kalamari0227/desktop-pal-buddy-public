import type { Database } from "@/integrations/supabase/types";
import type { EventSeverity, WorkerEvent, WorkerEventType } from "./types";

export type AgentEventRow = Database["public"]["Tables"]["agent_events"]["Row"];
export type AgentEventInsert = Database["public"]["Tables"]["agent_events"]["Insert"];

export interface PersistWorkerEventInput {
  workboard_task_id: string;
  event: WorkerEvent;
}

export interface CreateWorkerEventInput {
  packet_task_id: string;
  event_type: WorkerEventType;
  message: string;
  evidence_ref_id?: string;
  severity?: EventSeverity;
  requires_user_action?: boolean;
  created_at?: string;
  sequence?: number;
}

function nullable(value?: string): string | null {
  return value?.trim() || null;
}

function eventSuffix(input: CreateWorkerEventInput, createdAt: string): string {
  if (input.sequence !== undefined) {
    return input.sequence.toString();
  }

  const timestamp = createdAt.replace(/\D/g, "");
  const random = Math.random().toString(36).slice(2, 10);
  return `${timestamp}-${random}`;
}

export function createWorkerEvent(input: CreateWorkerEventInput): WorkerEvent {
  const createdAt = input.created_at ?? new Date().toISOString();

  return {
    event_id: `${input.packet_task_id}-event-${eventSuffix(input, createdAt)}`,
    task_id: input.packet_task_id,
    created_at: createdAt,
    event_type: input.event_type,
    message: input.message.trim(),
    evidence_ref_id: nullable(input.evidence_ref_id) ?? undefined,
    severity: input.severity ?? "info",
    requires_user_action: input.requires_user_action ?? false,
  };
}

export function workerEventToAgentEventInsert(input: PersistWorkerEventInput): AgentEventInsert {
  const { event } = input;

  return {
    task_id: input.workboard_task_id,
    packet_task_id: event.task_id,
    event_id: event.event_id,
    event_type: event.event_type,
    message: event.message,
    evidence_ref_id: nullable(event.evidence_ref_id),
    severity: event.severity ?? "info",
    requires_user_action: event.requires_user_action ?? false,
    created_at: event.created_at,
  };
}

export function agentEventRowToWorkerEvent(row: AgentEventRow): WorkerEvent {
  return {
    event_id: row.event_id,
    task_id: row.packet_task_id,
    created_at: row.created_at,
    event_type: row.event_type as WorkerEventType,
    message: row.message,
    evidence_ref_id: row.evidence_ref_id ?? undefined,
    severity: (row.severity ?? "info") as EventSeverity,
    requires_user_action: row.requires_user_action,
  };
}

export function agentEventRowsToWorkerEvents(rows: AgentEventRow[]): WorkerEvent[] {
  return [...rows]
    .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime())
    .map(agentEventRowToWorkerEvent);
}
