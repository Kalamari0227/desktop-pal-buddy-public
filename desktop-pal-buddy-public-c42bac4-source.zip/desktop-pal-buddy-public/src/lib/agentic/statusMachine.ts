import type { TaskStatus, ValidationResult } from "./types";

export const ALLOWED_STATUS_TRANSITIONS: Readonly<Record<TaskStatus, readonly TaskStatus[]>> = {
  queued: ["triaging"],
  triaging: ["waiting_for_approval", "running", "blocked", "failed"],
  waiting_for_approval: ["running", "blocked", "failed"],
  running: ["waiting_for_approval", "blocked", "verifying", "failed"],
  blocked: ["running", "failed"],
  verifying: ["completed", "failed", "blocked"],
  completed: ["archived"],
  failed: ["archived"],
  archived: [],
};

export function canTransitionTaskStatus(from: TaskStatus, to: TaskStatus): boolean {
  return ALLOWED_STATUS_TRANSITIONS[from].includes(to);
}

export function validateStatusTransition(from: TaskStatus, to: TaskStatus): ValidationResult {
  if (canTransitionTaskStatus(from, to)) {
    return { valid: true, issues: [] };
  }

  return {
    valid: false,
    issues: [`invalid status transition: ${from} -> ${to}`],
  };
}

export const validateTaskStatusTransition = validateStatusTransition;
