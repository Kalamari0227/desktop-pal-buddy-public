import { describe, expect, it } from "vitest";
import {
  buildCustomerResponseContextRefs,
  createCustomerResponseGatewayDraft,
  type CustomerResponseRouteInput,
} from "./customerResponseGatewayRouting";

const deliveryReply: CustomerResponseRouteInput = {
  customer_id: "hyundai",
  customer_name: "현대자동차",
  customer_code: "HYUNDAI",
  inquiry_type: "delivery",
  inquiry_label: "납기 문의",
  inquiry_description: "납기 일정 확인/조정 요청",
  channel: "email",
  channel_label: "이메일",
  tone: "정중/공식",
  context_note: "3월 셋째 주 출하 가능성을 검토 중",
};

describe("customer response Gateway routing", () => {
  it("routes customer replies into draft-only Gateway packets", () => {
    const draft = createCustomerResponseGatewayDraft(deliveryReply);

    expect(draft.packet).toMatchObject({
      task_type: "customer_reply_draft",
      risk_level: "medium",
      required_approval: false,
      status: "queued",
    });
    expect(draft.packet?.forbidden_actions).toEqual(expect.arrayContaining([
      "do not send external message",
      "do not make binding price or delivery commitment",
    ]));
    expect(draft.packet?.verification_requirements.map((requirement) => requirement.type)).toEqual([
      "reply_draft",
      "manual_review",
    ]);
    expect(draft.handoff_markdown).toContain("# Codex Task Packet");
    expect(draft.suggestion.reasoning_notes).toContain("고객 응답은 draft-only이며 외부 발송은 명시적 승인 전 금지됩니다.");
  });

  it("preserves customer response metadata as context refs", () => {
    expect(buildCustomerResponseContextRefs(deliveryReply)).toEqual(expect.arrayContaining([
      { type: "customer_account", label: "고객", value: "현대자동차" },
      { type: "user_note", label: "문의 유형", value: "납기 문의" },
      { type: "user_note", label: "회신 채널", value: "이메일" },
      { type: "user_note", label: "톤앤매너", value: "정중/공식" },
      { type: "user_note", label: "추가 맥락", value: "3월 셋째 주 출하 가능성을 검토 중" },
    ]));
  });

  it("omits sensitive free-text context from packet refs", () => {
    const refs = buildCustomerResponseContextRefs({
      ...deliveryReply,
      context_note: "API_KEY=secret-value 내용을 고객에게 설명",
    });

    expect(refs).not.toEqual(expect.arrayContaining([
      expect.objectContaining({ label: "추가 맥락" }),
    ]));
  });
});
