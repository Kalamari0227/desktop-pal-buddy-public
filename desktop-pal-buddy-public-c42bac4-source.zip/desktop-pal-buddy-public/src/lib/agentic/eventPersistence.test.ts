import { describe, expect, it } from "vitest";
import {
  agentEventRowToWorkerEvent,
  agentEventRowsToWorkerEvents,
  createWorkerEvent,
  workerEventToAgentEventInsert,
  type AgentEventRow,
} from "./eventPersistence";

const event = createWorkerEvent({
  packet_task_id: "workboard-task-1",
  event_type: "evidence_added",
  message: "Evidence was attached.",
  evidence_ref_id: "workboard-task-1-evidence-1",
  severity: "info",
  created_at: "2026-07-04T00:01:00.000Z",
  sequence: 1,
});

describe("event persistence mapping", () => {
  it("creates a WorkerEvent with stable packet scoping", () => {
    expect(event).toEqual({
      event_id: "workboard-task-1-event-1",
      task_id: "workboard-task-1",
      created_at: "2026-07-04T00:01:00.000Z",
      event_type: "evidence_added",
      message: "Evidence was attached.",
      evidence_ref_id: "workboard-task-1-evidence-1",
      severity: "info",
      requires_user_action: false,
    });
  });

  it("maps a WorkerEvent into an agent_events insert row", () => {
    expect(workerEventToAgentEventInsert({
      workboard_task_id: "00000000-0000-0000-0000-000000000001",
      event,
    })).toEqual({
      task_id: "00000000-0000-0000-0000-000000000001",
      packet_task_id: "workboard-task-1",
      event_id: "workboard-task-1-event-1",
      event_type: "evidence_added",
      message: "Evidence was attached.",
      evidence_ref_id: "workboard-task-1-evidence-1",
      severity: "info",
      requires_user_action: false,
      created_at: "2026-07-04T00:01:00.000Z",
    });
  });

  it("maps a database row back into a WorkerEvent", () => {
    const row: AgentEventRow = {
      id: "row-1",
      owner_id: "user-1",
      task_id: "00000000-0000-0000-0000-000000000001",
      packet_task_id: "workboard-task-1",
      event_id: "workboard-task-1-event-1",
      event_type: "evidence_added",
      message: "Evidence was attached.",
      evidence_ref_id: "workboard-task-1-evidence-1",
      severity: "info",
      requires_user_action: false,
      created_at: "2026-07-04T00:01:00.000Z",
    };

    expect(agentEventRowToWorkerEvent(row)).toEqual(event);
  });

  it("sorts persisted rows by creation time before rendering", () => {
    const rows: AgentEventRow[] = [
      {
        id: "row-2",
        owner_id: "user-1",
        task_id: "00000000-0000-0000-0000-000000000001",
        packet_task_id: "workboard-task-1",
        event_id: "workboard-task-1-event-2",
        event_type: "completed",
        message: "Completed.",
        evidence_ref_id: null,
        severity: "info",
        requires_user_action: false,
        created_at: "2026-07-04T00:02:00.000Z",
      },
      {
        id: "row-1",
        owner_id: "user-1",
        task_id: "00000000-0000-0000-0000-000000000001",
        packet_task_id: "workboard-task-1",
        event_id: "workboard-task-1-event-1",
        event_type: "started",
        message: "Started.",
        evidence_ref_id: null,
        severity: "info",
        requires_user_action: false,
        created_at: "2026-07-04T00:01:00.000Z",
      },
    ];

    expect(agentEventRowsToWorkerEvents(rows).map((item) => item.event_id)).toEqual([
      "workboard-task-1-event-1",
      "workboard-task-1-event-2",
    ]);
  });
});
