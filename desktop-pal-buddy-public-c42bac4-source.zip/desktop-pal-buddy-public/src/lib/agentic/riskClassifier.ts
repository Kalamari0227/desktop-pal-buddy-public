import { detectApprovalActions } from "./approvalPolicy";
import { getDefaultTaskTemplate } from "./taskTemplates";
import type { ApprovalClassification, DefaultTaskType, RiskLevel, TaskType } from "./types";

const DEFAULT_TASK_TYPES = new Set<TaskType>([
  "pr_verification",
  "supabase_staging_check",
  "document_to_prd",
  "inventory_check",
  "urgent_material_risk_assessment",
  "delivery_delay_risk_check",
  "business_risk_review",
  "customer_reply_draft",
  "order_status_check",
  "material_substitution_review",
]);

function isDefaultTaskType(taskType: TaskType): taskType is DefaultTaskType {
  return DEFAULT_TASK_TYPES.has(taskType);
}

export function classifyTaskType(request: string): TaskType {
  const text = request.toLowerCase();

  if (/(긴급재|긴급\s*자재|urgent material|expedite|hot\s*material|긴급.*위험|긴급.*리스크)/i.test(request)) {
    return "urgent_material_risk_assessment";
  }

  if (/(대체재|대체품|대체\s*소재|substitution|substitute|alternate material|대체.*검토|대체.*추천)/i.test(request)) {
    return "material_substitution_review";
  }

  if (/(회신|답장|메일|이메일|customer reply|reply draft|response draft|고객.*대응|고객.*회신|고객.*답장)/i.test(request)) {
    return "customer_reply_draft";
  }

  if (/(납기|출하|배송|지연|delivery|shipment|delay|late|eta)/i.test(request)) {
    return "delivery_delay_risk_check";
  }

  if (/(재고|가용\s*재고|창고|inventory|stock|available stock|allocation)/i.test(request)) {
    return "inventory_check";
  }

  if (/(주문|오더|발주|수주|sales order|order status|\border\b)/i.test(text)) {
    return "order_status_check";
  }

  if (/(prd|product requirement|requirements doc|handoff|uploaded file|document|문서|초안|기획서|요구사항|자료)/i.test(request)) {
    return "document_to_prd";
  }

  if (/(supabase|staging|migration|migrate|advisor|rls|edge function|마이그레이션|스테이징)/i.test(request)) {
    return "supabase_staging_check";
  }

  if (/(pull request|\bpr\b|github pr|#\d+|diff|mergeable|ci)/i.test(text)) {
    return "pr_verification";
  }

  if (/(리스크|위험|risk|점검|평가|우선순위|대응 전략)/i.test(request)) {
    return "business_risk_review";
  }

  return "unknown";
}

function baseRiskForTask(taskType: TaskType): RiskLevel {
  if (
    taskType === "supabase_staging_check" ||
    taskType === "inventory_check" ||
    taskType === "urgent_material_risk_assessment" ||
    taskType === "delivery_delay_risk_check" ||
    taskType === "business_risk_review" ||
    taskType === "customer_reply_draft" ||
    taskType === "order_status_check" ||
    taskType === "material_substitution_review"
  ) {
    return "medium";
  }
  if (taskType === "unknown") {
    return "blocked";
  }
  return "low";
}

export function classifyRiskAndApproval(input: { request: string; task_type?: TaskType }): ApprovalClassification {
  const taskType = input.task_type ?? classifyTaskType(input.request);
  const approvalActions = detectApprovalActions(input.request);
  const template = isDefaultTaskType(taskType) ? getDefaultTaskTemplate(taskType) : undefined;

  if (approvalActions.length > 0) {
    return {
      risk_level: "high",
      required_approval: true,
      approval_actions: approvalActions,
      approval_reason: `Approval required for: ${approvalActions.join(", ")}`,
      forbidden_actions: [
        ...(template?.forbidden_actions ?? []),
        ...approvalActions.map((action) => `do not perform ${action} without explicit approval`),
      ],
    };
  }

  return {
    risk_level: template?.risk_level ?? baseRiskForTask(taskType),
    required_approval: false,
    approval_actions: [],
    forbidden_actions: template?.forbidden_actions ?? [],
  };
}
