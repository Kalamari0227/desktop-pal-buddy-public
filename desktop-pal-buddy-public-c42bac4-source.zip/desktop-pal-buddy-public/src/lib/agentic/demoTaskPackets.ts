import { demoStrategyVersions } from "@/data/demoStrategyCatalog";
import { buildGatewayCodexPrompt, createGatewayCodexDraft, type GatewayCodexDraft } from "./gatewayCodexAgent";
import { renderManualCodexHandoff } from "./manualCodexHandoff";
import { taskPacketSchema } from "./schemas";
import { validateStrategyReference } from "./strategy";
import { createTaskWorkboardDraft, type TaskWorkboardRouteInput } from "./taskWorkboardRouting";
import type { TaskPacket } from "./types";

export interface DemoPacketMetadata {
  demo_intake_required: true;
  demo_intake_packet: TaskPacket;
}

type DemoTaskReadInput = TaskWorkboardRouteInput & {
  demo_intake_required?: unknown;
  demo_intake_packet?: unknown;
};

function clonePacket(packet: TaskPacket): TaskPacket {
  return taskPacketSchema.parse(packet);
}

export function withDemoTaskPacket<T extends TaskWorkboardRouteInput>(
  task: T,
  packet: TaskPacket,
): T & DemoPacketMetadata {
  return {
    ...task,
    demo_intake_required: true,
    demo_intake_packet: clonePacket(packet),
  };
}

function invalidDemoDraft(task: TaskWorkboardRouteInput, reason: string): GatewayCodexDraft {
  const fallback = createTaskWorkboardDraft(task);
  return {
    ...fallback,
    bridge_status: "needs_manual_review",
    packet: null,
    handoff_markdown: "",
    blocked_reason: reason,
    policy_notes: [
      ...fallback.policy_notes,
      "필수 데모 접수 packet을 검증할 수 없어 worker handoff를 차단했습니다.",
    ],
  };
}

function packetIdentityIssues(task: DemoTaskReadInput, packet: TaskPacket): string[] {
  const issues: string[] = [];

  if (task.source !== "gateway") {
    issues.push("source must be gateway");
  }
  if (task.source_id !== packet.task_id) {
    issues.push("source_id does not match the packet task_id");
  }
  if (packet.evidence.some((evidence) => evidence.task_id !== packet.task_id)) {
    issues.push("packet evidence task_id does not match the packet task_id");
  }
  if (packet.retention_decision && packet.retention_decision.task_id !== packet.task_id) {
    issues.push("retention task_id does not match the packet task_id");
  }

  return issues;
}

export function resolveDemoTaskDraft(task: DemoTaskReadInput): GatewayCodexDraft {
  const marker = task.demo_intake_required;
  const storedPacket = task.demo_intake_packet;

  if (marker === undefined && storedPacket === undefined) {
    return createTaskWorkboardDraft(task);
  }

  if (marker !== true || storedPacket === undefined) {
    return invalidDemoDraft(task, "필수 데모 접수 packet이 누락되었거나 연결 표시가 올바르지 않습니다.");
  }

  const parsedPacket = taskPacketSchema.safeParse(storedPacket);
  if (!parsedPacket.success) {
    return invalidDemoDraft(task, "필수 데모 접수 packet 형식이 손상되어 수동 검토가 필요합니다.");
  }

  const packet = parsedPacket.data;
  const identityIssues = packetIdentityIssues(task, packet);
  if (identityIssues.length > 0) {
    return invalidDemoDraft(task, `데모 접수 packet 식별자가 일치하지 않습니다: ${identityIssues.join("; ")}`);
  }

  if (!packet.strategy_ref) {
    return invalidDemoDraft(task, "데모 접수 packet의 전략 참조가 누락되었습니다.");
  }

  const strategyValidation = validateStrategyReference(packet.strategy_ref, demoStrategyVersions);
  if (!strategyValidation.valid) {
    return invalidDemoDraft(
      task,
      `데모 접수 packet의 전략 참조를 확인해야 합니다: ${strategyValidation.issues.join("; ")}`,
    );
  }

  const clonedPacket = clonePacket(packet);
  const baseDraft = createGatewayCodexDraft({
    raw_user_request: clonedPacket.raw_user_request,
    context_refs: clonedPacket.context_refs,
    created_at: clonedPacket.created_at,
    created_by: clonedPacket.created_by,
    task_id: clonedPacket.task_id,
    codex_suggestion: {
      request_summary: clonedPacket.request_summary,
      desired_outcome: clonedPacket.desired_outcome,
      task_type: clonedPacket.task_type,
      context_refs: clonedPacket.context_refs,
      reasoning_notes: ["보존된 데모 접수 packet을 다시 읽었습니다."],
    },
  });

  return {
    ...baseDraft,
    bridge_status: "manual_only",
    prompt: buildGatewayCodexPrompt({
      raw_user_request: clonedPacket.raw_user_request,
      context_refs: clonedPacket.context_refs,
    }),
    suggestion: {
      request_summary: clonedPacket.request_summary,
      desired_outcome: clonedPacket.desired_outcome,
      task_type: clonedPacket.task_type,
      context_refs: clonedPacket.context_refs,
      reasoning_notes: ["보존된 데모 접수 packet을 다시 읽었습니다."],
    },
    packet: clonedPacket,
    handoff_markdown: renderManualCodexHandoff(clonedPacket),
    blocked_reason: undefined,
  };
}
