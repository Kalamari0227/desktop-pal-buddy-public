import { describe, expect, it } from "vitest";
import { createTaskWorkboardDraft } from "./taskWorkboardRouting";
import {
  createTaskCompletionPreview,
  createTaskEvidenceItem,
  findMissingVerificationTypes,
  suggestEvidenceTypesForTask,
} from "./taskEvidenceCapture";

const draft = createTaskWorkboardDraft({
  id: "task-1",
  title: "3월 납기 지연 리스크",
  description: "열연 라인 정비로 인해 GA강판 3월 납기 2주 지연 가능성",
  customer: "현대자동차",
  category: "delivery",
  severity: "critical",
  status: "pending",
  created_at: "2026-07-04T00:00:00.000Z",
});

const packet = draft.packet;

describe("task evidence capture", () => {
  if (!packet) {
    throw new Error("expected task workboard draft to create a packet");
  }

  it("suggests evidence types from required verification requirements", () => {
    expect(suggestEvidenceTypesForTask(packet)).toEqual([
      "order_status",
      "manual_observation",
      "delivery_schedule",
      "risk_assessment",
    ]);
  });

  it("keeps completion blocked until every required verification has passing evidence", () => {
    const orderEvidence = createTaskEvidenceItem({
      packet,
      evidence_type: "order_status",
      source_system: "erp",
      summary: "SO-1001 is allocated and waiting for shipment.",
      created_at: "2026-07-04T00:01:00.000Z",
      sequence: 1,
    }).evidence;

    expect(findMissingVerificationTypes(packet, [orderEvidence])).toEqual([
      "delivery_status",
      "risk_assessment",
    ]);

    const preview = createTaskCompletionPreview({
      packet,
      evidence: [orderEvidence],
      result_summary: "Order status was checked.",
    });

    expect(preview.can_complete).toBe(false);
    expect(preview.validation.issues).toContain("completed task requires passing evidence for every required verification");
  });

  it("allows completion preview when all required evidence is present", () => {
    const evidence = [
      createTaskEvidenceItem({
        packet,
        evidence_type: "order_status",
        source_system: "erp",
        summary: "SO-1001 is allocated and waiting for shipment.",
        created_at: "2026-07-04T00:01:00.000Z",
        sequence: 1,
      }).evidence,
      createTaskEvidenceItem({
        packet,
        evidence_type: "delivery_schedule",
        source_system: "spreadsheet",
        summary: "Shipment plan shows ETA before the customer due date.",
        created_at: "2026-07-04T00:02:00.000Z",
        sequence: 2,
      }).evidence,
      createTaskEvidenceItem({
        packet,
        evidence_type: "risk_assessment",
        source_system: "gateway",
        summary: "Delay risk is medium because schedule buffer remains available.",
        created_at: "2026-07-04T00:03:00.000Z",
        sequence: 3,
      }).evidence,
    ];

    const preview = createTaskCompletionPreview({
      packet,
      evidence,
      result_summary: "Delivery risk is medium and can be monitored.",
    });

    expect(preview.can_complete).toBe(true);
    expect(preview.validation.valid).toBe(true);
    expect(preview.missing_verification_types).toEqual([]);
  });

  it("rejects raw excerpts that contain secrets", () => {
    const result = createTaskEvidenceItem({
      packet,
      evidence_type: "manual_observation",
      source_system: "user",
      summary: "Unsafe pasted output.",
      raw_excerpt: "OPENAI_API_KEY=sk-proj-secretvalue",
      created_at: "2026-07-04T00:04:00.000Z",
      sequence: 4,
    });

    expect(result.validation.valid).toBe(false);
    expect(result.validation.issues).toContain("raw_excerpt contains sensitive content");
  });
});
