import { describe, expect, it } from "vitest";
import { createMarketplaceProvider } from "./marketplaceProvider";

describe("marketplace provider", () => {
  it("serves marketplace rows from the demo provider without hitting backend functions", async () => {
    const provider = createMarketplaceProvider("demo");

    const agents = await provider.list<{ id: string; name: string; installs: number }>("agent");
    const recommendation = await provider.recommendAgents({
      query: "품질 리스크",
      agentNames: agents.map((agent) => agent.name),
    });

    expect(provider.mode).toBe("demo");
    expect(agents.length).toBeGreaterThan(0);
    expect(recommendation).toContain("Demo 모드");
  });

  it("keeps demo review writes scoped inside the provider", async () => {
    const provider = createMarketplaceProvider("demo");
    const [agent] = await provider.list<{ id: string }>("agent");

    await provider.submitReview("agent", agent.id, {
      reviewer_name: "QA",
      rating: 5,
      comment: "좋아요",
    });

    const reviews = await provider.listReviews("agent", agent.id);
    expect(reviews[0]).toMatchObject({ reviewer_name: "QA", rating: 5, comment: "좋아요" });
  });
});
