import { z } from "zod";
import {
  companyStateSchema,
  runtimeErrorEnvelopeSchema,
  runtimeSuccessEnvelopeSchema,
  type RuntimeErrorCode,
} from "@/lib/company-runtime";

const uuid = z.string().uuid();
const statusSchema = z.object({
  epoch: uuid,
  actorId: z.enum(["sales-demo", "production-demo", "management-demo"]),
  role: z.enum(["sales", "production", "management"]),
  actorSessionRevision: z.number().int().nonnegative(),
  stopped: z.boolean(),
}).strict();

const aiConnectionSchema = z.discriminatedUnion("state", [
  z.object({ state: z.literal("checking"), reasonCode: z.literal("checking") }).strict(),
  z.object({ state: z.literal("ready"), reasonCode: z.literal("local_profile_ready") }).strict(),
  z.object({
    state: z.literal("unavailable"),
    reasonCode: z.enum(["codex_not_found", "profile_unavailable", "discovery_failed"]),
  }).strict(),
]);

const snapshotSchema = z.object({
  formatVersion: z.literal(1),
  revision: z.number().int().nonnegative(),
  currentEpoch: uuid,
  stopped: z.boolean(),
  current: companyStateSchema,
  records: z.object({}).passthrough(),
  history: z.array(z.unknown()).optional(),
  readOnly: z.literal(true).optional(),
  projection: z.object({
    actorId: z.enum(["sales-demo", "production-demo", "management-demo"]),
    role: z.enum(["sales", "production", "management"]),
  }).strict(),
}).strict();

const bootstrapPayloadSchema = z.object({
  snapshot: snapshotSchema,
  status: statusSchema,
  aiConnection: aiConnectionSchema,
}).strict();

export const resultExplanationPayloadSchema = z.object({
  runtimeMode: z.enum(["stub", "live", "unavailable"]),
  actualAI: z.boolean(),
  explanation: z.object({
    schemaVersion: z.literal(1),
    kind: z.literal("explanation"),
    summary: z.string().trim().min(1),
    verifiedFactIds: z.array(z.string().trim().min(1)).min(1),
    citedEvidenceIds: z.array(z.string().trim().min(1)).min(1),
    uncertainties: z.array(z.string()),
    authorityClaims: z.array(z.never()).max(0),
  }).strict(),
}).strict();

export type AiConnection = z.infer<typeof aiConnectionSchema>;

export type CompanyRuntimeContext = { epoch: string; actorSessionRevision: number };
export type CompanyRuntimeResponse<T = unknown> =
  | { schemaVersion: 1; requestId: string; epoch: string; actorSessionRevision: number; ok: true; payload: T }
  | { schemaVersion: 1; requestId: string; epoch: string | null; actorSessionRevision: number | null; ok: false; error: { code: RuntimeErrorCode; message: string } };

export interface StrategyReviewCommand {
  readonly decision: "maintain" | "create_new_version";
  readonly baseStrategyRef: { readonly strategy_id: string; readonly strategy_version_id: string };
  readonly expectedBaseVersion: number;
  readonly evidenceRefs: readonly {
    readonly kind: "task" | "assessment" | "readback" | "learning";
    readonly id: string;
    readonly version: number;
  }[];
  readonly uncertainties: readonly string[];
  readonly proposedChanges: {
    readonly objective: string;
    readonly review_question: string;
    readonly execution_criteria: readonly string[];
    readonly constraints: readonly string[];
  };
}

export interface StrategyAdoptionCommand {
  readonly requestId: string;
  readonly reviewId: string;
  readonly expectedActiveRef: { readonly strategy_id: string; readonly strategy_version_id: string };
}

export interface CompanyRuntimeBridge {
  bootstrap(request: unknown): Promise<unknown>;
  read(request: unknown): Promise<unknown>;
  submit(request: unknown): Promise<unknown>;
  approve(request: unknown): Promise<unknown>;
  execute(request: unknown): Promise<unknown>;
  explainResult?(request: unknown): Promise<unknown>;
  role(request: unknown): Promise<unknown>;
  stop(request: unknown): Promise<unknown>;
  resume(request: unknown): Promise<unknown>;
  reset(request: unknown): Promise<unknown>;
  cancel(request: unknown): Promise<unknown>;
  reconcile(request: unknown): Promise<unknown>;
  experience(request: unknown): Promise<unknown>;
  learning?(request: unknown): Promise<unknown>;
  reviewReadiness(request: unknown): Promise<unknown>;
  reviewStrategy?(request: unknown): Promise<unknown>;
  adoptStrategy?(request: unknown): Promise<unknown>;
  refreshAiConnection?(request: unknown): Promise<unknown>;
  onUpdate(callback: (response: unknown) => void): () => void;
}

type Operation = Exclude<keyof CompanyRuntimeBridge, "bootstrap" | "onUpdate">;

function unavailable(message = "desktop_runtime_unavailable"): CompanyRuntimeResponse {
  return {
    schemaVersion: 1,
    requestId: crypto.randomUUID(),
    epoch: null,
    actorSessionRevision: null,
    ok: false,
    error: { code: "unavailable", message },
  };
}

function stale(context: CompanyRuntimeContext | null, requestId: string): CompanyRuntimeResponse {
  return {
    schemaVersion: 1,
    requestId,
    epoch: context?.epoch ?? null,
    actorSessionRevision: context?.actorSessionRevision ?? null,
    ok: false,
    error: { code: "stale_context", message: "stale_client_reply" },
  };
}

function parseResponse(value: unknown): CompanyRuntimeResponse | null {
  const success = runtimeSuccessEnvelopeSchema.safeParse(value);
  if (success.success) {
    const payload = success.data.payload;
    if (payload === undefined) return null;
    if (payload && typeof payload === "object" && "snapshot" in payload && !snapshotSchema.safeParse(payload.snapshot).success) return null;
    if (payload && typeof payload === "object" && "status" in payload && !statusSchema.safeParse(payload.status).success) return null;
    if (payload && typeof payload === "object" && "aiConnection" in payload && !aiConnectionSchema.safeParse(payload.aiConnection).success) return null;
    return { ...success.data, payload };
  }
  const failure = runtimeErrorEnvelopeSchema.safeParse(value);
  return failure.success ? failure.data : null;
}

export interface CompanyRuntimeClient {
  bootstrap(): Promise<CompanyRuntimeResponse>;
  read(payload?: Record<string, unknown>): Promise<CompanyRuntimeResponse>;
  submit(payload: { requestText: string }): Promise<CompanyRuntimeResponse>;
  approve(payload: { workboardTaskId: string; decision: "approved" | "rejected" | "revoked" }): Promise<CompanyRuntimeResponse>;
  execute(payload: { workboardTaskId: string; approvalId?: string }): Promise<CompanyRuntimeResponse>;
  explainResult?(payload: { workboardTaskId: string }): Promise<CompanyRuntimeResponse>;
  role(payload: { actorId: "sales-demo" | "production-demo" | "management-demo" }): Promise<CompanyRuntimeResponse>;
  stop(): Promise<CompanyRuntimeResponse>;
  resume(): Promise<CompanyRuntimeResponse>;
  reset(payload: { confirmation: "RESET" }): Promise<CompanyRuntimeResponse>;
  cancel(): Promise<CompanyRuntimeResponse>;
  reconcile(payload: { workboardTaskId: string }): Promise<CompanyRuntimeResponse>;
  saveExperienceDraft?(payload: { workboardTaskId: string; draft: unknown }): Promise<CompanyRuntimeResponse>;
  learning?(payload: Record<string, unknown>): Promise<CompanyRuntimeResponse>;
  reviewReadiness?(payload: { useLatestLearning: boolean }): Promise<CompanyRuntimeResponse>;
  reviewStrategy?(payload: StrategyReviewCommand): Promise<CompanyRuntimeResponse>;
  adoptStrategy?(payload: StrategyAdoptionCommand): Promise<CompanyRuntimeResponse>;
  refreshAiConnection?(): Promise<CompanyRuntimeResponse>;
  subscribe(callback: (response: CompanyRuntimeResponse) => void): () => void;
  getContext(): CompanyRuntimeContext | null;
}

export function createCompanyRuntimeClient(bridge: CompanyRuntimeBridge | undefined): CompanyRuntimeClient {
  let context: CompanyRuntimeContext | null = null;
  let generation = 0;
  const subscribers = new Set<(response: CompanyRuntimeResponse) => void>();
  let removeBridgeListener: (() => void) | null = null;

  const updateContext = (response: CompanyRuntimeResponse) => {
    if (response.epoch !== null && response.actorSessionRevision !== null) {
      context = { epoch: response.epoch, actorSessionRevision: response.actorSessionRevision };
    }
  };

  async function bootstrap(): Promise<CompanyRuntimeResponse> {
    if (!bridge) return unavailable();
    const requestId = crypto.randomUUID();
    const raw = await bridge.bootstrap({ schemaVersion: 1, requestId, epoch: null, actorSessionRevision: null, payload: {} });
    const parsed = parseResponse(raw);
    if (!parsed || parsed.requestId !== requestId || !parsed.ok || !bootstrapPayloadSchema.safeParse(parsed.payload).success) {
      return unavailable("invalid_runtime_response");
    }
    updateContext(parsed);
    return parsed;
  }

  async function invoke(operation: Operation, payload: unknown): Promise<CompanyRuntimeResponse> {
    if (!bridge || !context) return unavailable();
    if (["role", "stop", "reset", "cancel"].includes(operation)) generation += 1;
    const startedGeneration = generation;
    const startedContext = { ...context };
    const requestId = crypto.randomUUID();
    const operationBridge = bridge[operation];
    if (!operationBridge) return unavailable();
    const raw = await operationBridge({
      schemaVersion: 1,
      requestId,
      epoch: startedContext.epoch,
      actorSessionRevision: startedContext.actorSessionRevision,
      payload,
    });
    const parsed = parseResponse(raw);
    if (!parsed || parsed.requestId !== requestId) return unavailable("invalid_runtime_response");
    if (operation === "explainResult" && parsed.ok && !resultExplanationPayloadSchema.safeParse(parsed.payload).success) {
      return unavailable("invalid_runtime_response");
    }
    const contextChanged = context.epoch !== startedContext.epoch
      || context.actorSessionRevision !== startedContext.actorSessionRevision;
    const changesContext = operation === "role" || operation === "reset";
    const responseMatchesCurrent = parsed.epoch === context.epoch
      && parsed.actorSessionRevision === context.actorSessionRevision;
    if (generation !== startedGeneration
      || (contextChanged && (!changesContext || !responseMatchesCurrent))) {
      return stale(context, requestId);
    }
    if (parsed.ok && ["role", "reset"].includes(operation)) updateContext(parsed);
    return parsed;
  }

  const client: CompanyRuntimeClient = {
    bootstrap,
    read: (payload = {}) => invoke("read", payload),
    submit: (payload) => invoke("submit", payload),
    approve: (payload) => invoke("approve", payload),
    execute: (payload) => invoke("execute", payload),
    explainResult: (payload) => invoke("explainResult", payload),
    role: (payload) => invoke("role", payload),
    stop: () => invoke("stop", {}),
    resume: () => invoke("resume", {}),
    reset: (payload) => invoke("reset", payload),
    cancel: () => invoke("cancel", {}),
    reconcile: (payload) => invoke("reconcile", payload),
    saveExperienceDraft: (payload) => invoke("experience", payload),
    learning: (payload) => invoke("learning", payload),
    reviewReadiness: (payload) => invoke("reviewReadiness", {
      orderId: "SO-DEMO-1002",
      targetPlanId: "PP-DEMO-1002",
      useLatestLearning: payload.useLatestLearning,
    }),
    reviewStrategy: (payload) => invoke("reviewStrategy", payload),
    adoptStrategy: (payload) => invoke("adoptStrategy", payload),
    refreshAiConnection: () => invoke("refreshAiConnection", {}),
    subscribe(callback) {
      subscribers.add(callback);
      if (bridge && !removeBridgeListener) {
        removeBridgeListener = bridge.onUpdate((raw) => {
          const parsed = parseResponse(raw);
          if (!parsed || !parsed.ok || !context) return;
          if (parsed.epoch !== context.epoch || parsed.actorSessionRevision < context.actorSessionRevision) return;
          updateContext(parsed);
          for (const subscriber of subscribers) subscriber(parsed);
        });
      }
      let active = true;
      return () => {
        if (!active) return;
        active = false;
        subscribers.delete(callback);
        if (subscribers.size === 0) {
          removeBridgeListener?.();
          removeBridgeListener = null;
        }
      };
    },
    getContext: () => context ? { ...context } : null,
  };
  return client;
}

export const companyRuntimeClient = createCompanyRuntimeClient(
  typeof window === "undefined" ? undefined : window.companyRuntime,
);
