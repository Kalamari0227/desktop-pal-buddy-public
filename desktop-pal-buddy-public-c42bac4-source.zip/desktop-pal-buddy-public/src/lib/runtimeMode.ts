export type AppRuntimeMode = "demo" | "staging" | "production";

type RuntimeEnv = Record<string, string | boolean | undefined>;

export function resolveAppRuntimeMode(env: RuntimeEnv = import.meta.env): AppRuntimeMode {
  const explicit = String(env.VITE_APP_MODE ?? env.VITE_RUNTIME_MODE ?? "").toLowerCase();
  if (explicit === "demo" || explicit === "staging" || explicit === "production") {
    return explicit;
  }

  return env.VITE_DEMO_MODE === "false" ? "production" : "demo";
}

export function runtimeConnectionLabel(mode: AppRuntimeMode): string {
  if (mode === "production") return "Live";
  if (mode === "staging") return "Staging";
  return "Demo";
}

export function runtimeConnectionTone(mode: AppRuntimeMode): "neutral" | "warning" | "success" {
  if (mode === "production") return "success";
  if (mode === "staging") return "warning";
  return "neutral";
}

export type RuntimeConnectionState = {
  label: string;
  detail: string;
  tone: "neutral" | "warning" | "success" | "danger";
};

export function runtimeConnectionState({
  mode,
  isConfigured,
  isAuthenticated,
  email,
}: {
  mode: AppRuntimeMode;
  isConfigured: boolean;
  isAuthenticated: boolean;
  email?: string | null;
}): RuntimeConnectionState {
  if (mode === "demo") {
    return {
      label: "Demo",
      detail: "로컬 데모 데이터",
      tone: "neutral",
    };
  }

  if (!isConfigured) {
    return {
      label: runtimeConnectionLabel(mode),
      detail: "Supabase 설정 필요",
      tone: "danger",
    };
  }

  if (!isAuthenticated) {
    return {
      label: runtimeConnectionLabel(mode),
      detail: "로그인 필요",
      tone: "warning",
    };
  }

  return {
    label: runtimeConnectionLabel(mode),
    detail: email || "인증됨",
    tone: "success",
  };
}
