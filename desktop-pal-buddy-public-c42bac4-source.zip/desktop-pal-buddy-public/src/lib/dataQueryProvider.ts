import { supabase } from "@/integrations/supabase/client";
import { type AppRuntimeMode, resolveAppRuntimeMode } from "./runtimeMode";

export interface QueryResult {
  sql: string;
  explanation: string;
  data: Record<string, unknown>[];
  insight: string;
}

export interface DataQueryProvider {
  mode: AppRuntimeMode;
  query(question: string): Promise<QueryResult>;
}

const demoRows = [
  {
    customer: "현대자동차",
    title: "GA 강판 품질 재검 및 출하 일정 조정",
    category: "quality",
    severity: "critical",
    status: "in_progress",
    owner: "품질/영업 공동",
  },
  {
    customer: "기아",
    title: "신규 모델 강판 사양 및 가격 재협상",
    category: "price",
    severity: "high",
    status: "pending",
    owner: "마케팅",
  },
  {
    customer: "Toyota",
    title: "수출 강판 JIS 규격 확인 및 재발 방지 브리핑",
    category: "quality",
    severity: "medium",
    status: "pending",
    owner: "품질보증",
  },
  {
    customer: "GM Korea",
    title: "DP강 공급 확대 및 원가 절감 협의",
    category: "delivery",
    severity: "medium",
    status: "done",
    owner: "영업기획",
  },
];

export function buildDemoQueryResult(question: string): QueryResult {
  const normalized = question.toLowerCase();
  let data: Record<string, unknown>[] = demoRows;
  let sql = "SELECT customer, title, category, severity, status, owner FROM demo_tasks ORDER BY severity DESC;";
  let explanation = "외부 공유용 데모 데이터를 조회합니다.";

  if (normalized.includes("현대")) {
    data = demoRows.filter((row) => row.customer.includes("현대"));
    sql = "SELECT * FROM demo_tasks WHERE customer ILIKE '%현대자동차%';";
    explanation = "현대자동차 관련 데모 이슈만 필터링합니다.";
  } else if (normalized.includes("긴급") || normalized.includes("critical")) {
    data = demoRows.filter((row) => row.severity === "critical" || row.severity === "high");
    sql = "SELECT * FROM demo_tasks WHERE severity IN ('critical', 'high');";
    explanation = "긴급/고위험 데모 작업을 조회합니다.";
  } else if (normalized.includes("고객별")) {
    data = [
      { customer: "현대자동차", open_tasks: 1, highest_severity: "critical" },
      { customer: "기아", open_tasks: 1, highest_severity: "high" },
      { customer: "Toyota", open_tasks: 1, highest_severity: "medium" },
      { customer: "GM Korea", open_tasks: 0, highest_severity: "medium" },
    ];
    sql = "SELECT customer, count(*) AS open_tasks, max(severity) AS highest_severity FROM demo_tasks GROUP BY customer;";
    explanation = "고객별 미결 작업 수를 데모 집계로 보여줍니다.";
  } else if (normalized.includes("카테고리")) {
    data = [
      { category: "quality", tasks: 2, risk_note: "품질 재검/규격 확인" },
      { category: "price", tasks: 1, risk_note: "가격 재협상" },
      { category: "delivery", tasks: 1, risk_note: "공급 확대" },
    ];
    sql = "SELECT category, count(*) AS tasks FROM demo_tasks GROUP BY category;";
    explanation = "카테고리별 데모 작업 현황을 요약합니다.";
  }

  return {
    sql,
    explanation,
    data,
    insight: `이 결과는 외부 공유용 하드코딩 데모입니다. 실제 Supabase, Hermes/Codex 운영 브리지, 고객 DB를 호출하지 않습니다.\n\n- 우선순위 1순위는 현대자동차 품질/납기 리스크입니다.\n- 가격 협상 건은 기아 신규 모델 사양 협의와 함께 제시하는 흐름이 좋습니다.\n- 데모 시연에서는 생성된 쿼리와 표, AI 인사이트 UI 흐름만 확인하면 됩니다.`,
  };
}

export class DemoDataQueryProvider implements DataQueryProvider {
  mode = "demo" as const;

  async query(question: string) {
    return buildDemoQueryResult(question);
  }
}

async function defaultDataQueryTransport(question: string) {
  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
  const publishableKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;
  if (!supabaseUrl || !publishableKey) throw new Error("Supabase Edge Function 설정이 필요합니다.");

  const { data } = await supabase.auth.getSession();
  const accessToken = data.session?.access_token;
  if (!accessToken) throw new Error("실서비스 데이터 질의를 사용하려면 로그인이 필요합니다.");

  return fetch(`${supabaseUrl}/functions/v1/data-query`, {
    method: "POST",
    headers: {
      apikey: publishableKey,
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ question }),
  });
}

export class EdgeDataQueryProvider implements DataQueryProvider {
  mode: AppRuntimeMode;

  constructor(
    mode: Exclude<AppRuntimeMode, "demo">,
    private readonly transport: (question: string) => Promise<Response> = defaultDataQueryTransport
  ) {
    this.mode = mode;
  }

  async query(question: string): Promise<QueryResult> {
    const response = await this.transport(question);
    if (!response.ok) {
      const errorBody = await response.json().catch(() => null);
      throw new Error(typeof errorBody?.error === "string" ? errorBody.error : "데이터 질의에 실패했습니다.");
    }

    const contentType = response.headers.get("Content-Type") ?? "";
    if (!contentType.includes("text/event-stream")) {
      return response.json();
    }

    const reader = response.body?.getReader();
    if (!reader) throw new Error("데이터 질의 스트림을 읽을 수 없습니다.");

    const decoder = new TextDecoder();
    let buffer = "";
    let result: QueryResult = { sql: "", explanation: "", data: [], insight: "" };

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });

      let lineBreak: number;
      while ((lineBreak = buffer.indexOf("\n")) !== -1) {
        const line = buffer.slice(0, lineBreak).trim();
        buffer = buffer.slice(lineBreak + 1);
        if (!line.startsWith("data: ")) continue;

        const payload = line.slice(6).trim();
        if (payload === "[DONE]") return result;

        const parsed = JSON.parse(payload);
        if (parsed.type === "meta") {
          result = {
            sql: parsed.sql,
            explanation: parsed.explanation,
            data: parsed.data ?? [],
            insight: result.insight,
          };
        }
        if (parsed.type === "insight" && typeof parsed.content === "string") {
          result = { ...result, insight: result.insight + parsed.content };
        }
      }
    }

    return result;
  }
}

export function createDataQueryProvider(mode: AppRuntimeMode = resolveAppRuntimeMode()): DataQueryProvider {
  return mode === "demo" ? new DemoDataQueryProvider() : new EdgeDataQueryProvider(mode);
}
