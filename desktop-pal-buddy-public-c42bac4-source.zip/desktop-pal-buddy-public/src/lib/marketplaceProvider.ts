import { originalDemoMarketplaceData } from "@/data/demoMarketplaceData";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";
import { createChatProvider } from "@/lib/streamChat";
import { type AppRuntimeMode, resolveAppRuntimeMode } from "./runtimeMode";

export type MarketplaceKind = "agent" | "workflow" | "skill" | "mcp";

export type MarketplaceReview = {
  id: string;
  reviewer_name: string;
  rating: number;
  comment: string | null;
  created_at: string;
};

type MarketplaceTable = "marketplace_agents" | "marketplace_workflows" | "marketplace_skills" | "marketplace_mcps";
type MarketplaceCreateTable = MarketplaceTable | "marketplace_plugins";
type ReviewTable =
  | "marketplace_reviews"
  | "marketplace_workflow_reviews"
  | "marketplace_skill_reviews"
  | "marketplace_mcp_reviews";
type MarketplaceRow = {
  id: string;
  installs?: number | null;
  rating?: number | null;
  is_featured?: boolean | null;
  created_at?: string;
  [key: string]: unknown;
};
type MarketplaceCreatePayload = Database["public"]["Tables"][MarketplaceCreateTable]["Insert"];

const TABLE_BY_KIND: Record<MarketplaceKind, MarketplaceTable> = {
  agent: "marketplace_agents",
  workflow: "marketplace_workflows",
  skill: "marketplace_skills",
  mcp: "marketplace_mcps",
};

const REVIEW_TABLE_BY_KIND: Record<MarketplaceKind, ReviewTable> = {
  agent: "marketplace_reviews",
  workflow: "marketplace_workflow_reviews",
  skill: "marketplace_skill_reviews",
  mcp: "marketplace_mcp_reviews",
};

const REVIEW_OWNER_COLUMN_BY_KIND: Record<MarketplaceKind, string> = {
  agent: "agent_id",
  workflow: "workflow_id",
  skill: "skill_id",
  mcp: "mcp_id",
};

export interface MarketplaceProvider {
  mode: AppRuntimeMode;
  list<T>(kind: MarketplaceKind): Promise<T[]>;
  incrementInstalls(kind: MarketplaceKind, id: string, currentInstalls: number): Promise<void>;
  listReviews(kind: MarketplaceKind, itemId: string): Promise<MarketplaceReview[]>;
  submitReview(
    kind: MarketplaceKind,
    itemId: string,
    review: { reviewer_name: string; rating: number; comment: string }
  ): Promise<void>;
  getRating(kind: MarketplaceKind, id: string): Promise<number | null>;
  create(kind: MarketplaceKind | "plugin", payload: Record<string, unknown>): Promise<void>;
  recommendAgents(input: { query: string; agentNames: string[] }): Promise<string>;
  assistAgent(name: string): Promise<{ description?: string; prompt_template?: string; tags?: string[]; category?: string }>;
  assistWorkflow(name: string): Promise<{ description?: string; steps?: unknown[]; tags?: string[]; category?: string }>;
}

class DemoMarketplaceProvider implements MarketplaceProvider {
  mode = "demo" as const;
  private readonly rows: Record<MarketplaceKind, MarketplaceRow[]> = {
    agent: [...originalDemoMarketplaceData.marketplace_agents],
    workflow: [...originalDemoMarketplaceData.marketplace_workflows],
    skill: [...originalDemoMarketplaceData.marketplace_skills],
    mcp: [...originalDemoMarketplaceData.marketplace_mcps],
  };
  private readonly reviews: Record<MarketplaceKind, MarketplaceReview[]> = {
    agent: [],
    workflow: [],
    skill: [],
    mcp: [],
  };

  async list<T>(kind: MarketplaceKind): Promise<T[]> {
    return [...this.rows[kind]].sort((a, b) => Number(b.installs ?? 0) - Number(a.installs ?? 0)) as unknown as T[];
  }

  async incrementInstalls(kind: MarketplaceKind, id: string, currentInstalls: number) {
    this.rows[kind] = this.rows[kind].map((row) =>
      row.id === id ? { ...row, installs: currentInstalls + 1 } : row
    );
  }

  async listReviews(kind: MarketplaceKind) {
    return [...this.reviews[kind]].sort((a, b) => Date.parse(b.created_at) - Date.parse(a.created_at));
  }

  async submitReview(
    kind: MarketplaceKind,
    _itemId: string,
    review: { reviewer_name: string; rating: number; comment: string }
  ) {
    this.reviews[kind] = [
      {
        id: crypto.randomUUID(),
        reviewer_name: review.reviewer_name,
        rating: review.rating,
        comment: review.comment,
        created_at: new Date().toISOString(),
      },
      ...this.reviews[kind],
    ];
  }

  async getRating(kind: MarketplaceKind, id: string) {
    const row = this.rows[kind].find((item) => item.id === id);
    return typeof row?.rating === "number" ? row.rating : null;
  }

  async create(kind: MarketplaceKind | "plugin", payload: Record<string, unknown>) {
    if (kind === "plugin") return;
    this.rows[kind] = [
      {
        id: crypto.randomUUID(),
        installs: 0,
        rating: 0,
        is_featured: false,
        created_at: new Date().toISOString(),
        ...payload,
      },
      ...this.rows[kind],
    ];
  }

  async recommendAgents({ query, agentNames }: { query: string; agentNames: string[] }) {
    const names = agentNames.slice(0, 3).join(", ");
    return `"${query}"에는 ${names || "품질/영업 보조 에이전트"} 조합이 잘 맞습니다. Demo 모드라 외부 AI는 호출하지 않았고, 실제 추천 흐름만 확인할 수 있습니다.`;
  }

  async assistAgent(name: string) {
    return {
      description: `${name} 업무를 자동차 강판 영업 맥락에 맞춰 정리하고 다음 행동을 제안합니다.`,
      prompt_template: `${name}로서 고객, 품질, 납기, 가격 리스크를 요약하고 우선순위를 제안하세요.`,
      tags: ["영업", "리스크", "자동화"],
      category: "sales",
    };
  }

  async assistWorkflow(name: string) {
    return {
      description: `${name} 업무를 단계별로 자동화하는 데모용 자동화입니다.`,
      steps: [
        { type: "trigger", label: "업무 요청 수신" },
        { type: "action", label: "관련 고객/작업 수집" },
        { type: "output", label: "브리핑 초안 생성" },
      ],
      tags: ["자동화", "브리핑"],
      category: "automation",
    };
  }
}

class SupabaseMarketplaceProvider implements MarketplaceProvider {
  constructor(public readonly mode: Exclude<AppRuntimeMode, "demo">) {}

  async list<T>(kind: MarketplaceKind): Promise<T[]> {
    const { data, error } = await supabase
      .from(TABLE_BY_KIND[kind])
      .select("*")
      .order("installs", { ascending: false });
    if (error) throw error;
    return (data ?? []) as unknown as T[];
  }

  async incrementInstalls(kind: MarketplaceKind, id: string, currentInstalls: number) {
    const { error } = await supabase
      .from(TABLE_BY_KIND[kind])
      .update({ installs: currentInstalls + 1 })
      .eq("id", id);
    if (error) throw error;
  }

  async listReviews(kind: MarketplaceKind, itemId: string) {
    const ownerColumn = REVIEW_OWNER_COLUMN_BY_KIND[kind];
    const { data, error } = await supabase
      .from(REVIEW_TABLE_BY_KIND[kind])
      .select(`id, ${ownerColumn}, reviewer_name, rating, comment, created_at`)
      .eq(ownerColumn, itemId)
      .order("created_at", { ascending: false });
    if (error) throw error;
    return (data ?? []) as unknown as MarketplaceReview[];
  }

  async submitReview(
    kind: MarketplaceKind,
    itemId: string,
    review: { reviewer_name: string; rating: number; comment: string }
  ) {
    const base = {
      reviewer_name: review.reviewer_name,
      rating: review.rating,
      comment: review.comment,
    };

    const result =
      kind === "agent"
        ? await supabase.from("marketplace_reviews").insert({ agent_id: itemId, ...base })
        : kind === "workflow"
          ? await supabase.from("marketplace_workflow_reviews").insert({ workflow_id: itemId, ...base })
          : kind === "skill"
            ? await supabase.from("marketplace_skill_reviews").insert({ skill_id: itemId, ...base })
            : await supabase.from("marketplace_mcp_reviews").insert({ mcp_id: itemId, ...base });
    const { error } = result;
    if (error) throw error;
  }

  async getRating(kind: MarketplaceKind, id: string) {
    const { data, error } = await supabase.from(TABLE_BY_KIND[kind]).select("rating").eq("id", id).single();
    if (error) throw error;
    const rating = (data as { rating?: unknown } | null)?.rating;
    return typeof rating === "number" ? rating : null;
  }

  async create(kind: MarketplaceKind | "plugin", payload: Record<string, unknown>) {
    const row = payload as MarketplaceCreatePayload;
    const result =
      kind === "agent"
        ? await supabase.from("marketplace_agents").insert(row as Database["public"]["Tables"]["marketplace_agents"]["Insert"])
        : kind === "workflow"
          ? await supabase.from("marketplace_workflows").insert(row as Database["public"]["Tables"]["marketplace_workflows"]["Insert"])
          : kind === "skill"
            ? await supabase.from("marketplace_skills").insert(row as Database["public"]["Tables"]["marketplace_skills"]["Insert"])
            : kind === "mcp"
              ? await supabase.from("marketplace_mcps").insert(row as Database["public"]["Tables"]["marketplace_mcps"]["Insert"])
              : await supabase.from("marketplace_plugins").insert(row as Database["public"]["Tables"]["marketplace_plugins"]["Insert"]);
    const { error } = result;
    if (error) throw error;
  }

  async recommendAgents({ query, agentNames }: { query: string; agentNames: string[] }) {
    return collectChatResponse(
      `자동차 강판 마케팅/판매 조직용 AI 에이전트 연결 센터 추천을 2-3문장으로 해주세요.\n검색어: "${query}"\n현재 에이전트: ${agentNames.join(", ")}`,
      this.mode
    );
  }

  async assistAgent(name: string) {
    const text = await collectChatResponse(
      `에이전트 이름 "${name}"에 맞는 설명, 프롬프트 템플릿, 태그, 카테고리를 JSON으로만 생성해주세요. 형식: {"description":"...","prompt_template":"...","tags":["..."],"category":"sales|risk|quality|market|productivity"}`,
      this.mode
    );
    return parseJsonObject(text);
  }

  async assistWorkflow(name: string) {
    const text = await collectChatResponse(
      `자동화 이름 "${name}"에 맞는 설명, 단계, 태그, 카테고리를 JSON으로만 생성해주세요. 형식: {"description":"...","steps":[{"type":"trigger|action|condition|output","label":"..."}],"tags":["..."],"category":"automation|reporting|alert|quality|market|sales"}`,
      this.mode
    );
    return parseJsonObject(text);
  }
}

async function collectChatResponse(prompt: string, mode: Exclude<AppRuntimeMode, "demo">) {
  let content = "";
  await createChatProvider(mode).stream({
    messages: [{ role: "user", content: prompt }],
    onDelta: (delta) => {
      content += delta;
    },
    onDone: () => undefined,
  });
  return content;
}

function parseJsonObject<T extends Record<string, unknown>>(text: string): T {
  const match = text.match(/\{[\s\S]*\}/);
  if (!match) return {} as T;
  return JSON.parse(match[0]) as T;
}

let providerSingleton: MarketplaceProvider | null = null;

export function createMarketplaceProvider(mode: AppRuntimeMode = resolveAppRuntimeMode()): MarketplaceProvider {
  if (!providerSingleton || providerSingleton.mode !== mode) {
    providerSingleton = mode === "demo" ? new DemoMarketplaceProvider() : new SupabaseMarketplaceProvider(mode);
  }
  return providerSingleton;
}
