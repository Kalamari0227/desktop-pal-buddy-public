import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import {
  mergeWorkboardTaskViews,
  projectCompanyRuntimeSnapshot,
  projectLegacyTask,
  workboardTaskViewKey,
  type CompanyRuntimeProjection,
  type LegacyTaskRecord,
  type WorkboardTaskView,
} from "./company-runtime/projection";
import {
  companyRuntimeClient,
  type CompanyRuntimeClient,
  type CompanyRuntimeResponse,
} from "./companyRuntimeClient";

export const LEGACY_MUTATION_KINDS = [
  "edit",
  "status",
  "delete",
  "approval",
  "event",
  "manual_evidence",
  "manual_result",
  "follow_up",
  "reverification",
] as const;
export type LegacyMutationKind = (typeof LEGACY_MUTATION_KINDS)[number];

export class LegacyTaskLoadError extends Error {
  readonly code = "legacy_task_load_failed";
}

export class StaleTaskLoadError extends Error {
  readonly code = "stale_task_load";
}

export interface TaskRepositoryLoadResult {
  readonly tasks: readonly WorkboardTaskView[];
  readonly runtime: CompanyRuntimeProjection;
}

export type LegacyMutationResult<T> =
  | { readonly ok: true; readonly value: T }
  | { readonly ok: false; readonly reason: "runtime_owned" | "runtime_unavailable" };

interface TaskRepositoryDependencies {
  readonly loadLegacyTasks: () => Promise<readonly LegacyTaskRecord[]>;
  readonly runtimeClient: CompanyRuntimeClient;
}

export interface TaskRepository {
  load(): Promise<TaskRepositoryLoadResult>;
  subscribe(listener: (projection: CompanyRuntimeProjection) => void): () => void;
  mutateLegacy<T>(input: {
    readonly kind: LegacyMutationKind;
    readonly origin: WorkboardTaskView["origin"];
    readonly sourceId: string;
    readonly viewKey: WorkboardTaskView["viewKey"];
    readonly mutate: () => Promise<T>;
  }): Promise<LegacyMutationResult<T>>;
}

const payloadSchema = z.object({ snapshot: z.unknown() }).passthrough();

function projectionFromResponse(response: CompanyRuntimeResponse): CompanyRuntimeProjection {
  if (!response.ok) {
    return { state: "unavailable", tasks: [], reason: "invalid_runtime_snapshot" };
  }
  const payload = payloadSchema.safeParse(response.payload);
  return payload.success
    ? projectCompanyRuntimeSnapshot(payload.data.snapshot)
    : { state: "unavailable", tasks: [], reason: "invalid_runtime_snapshot" };
}

export function createTaskRepository(dependencies: TaskRepositoryDependencies): TaskRepository {
  let loadGeneration = 0;

  const readRuntime = async (): Promise<CompanyRuntimeProjection> => {
    const response = dependencies.runtimeClient.getContext()
      ? await dependencies.runtimeClient.read()
      : await dependencies.runtimeClient.bootstrap();
    return projectionFromResponse(response);
  };

  return {
    async load() {
      const generation = ++loadGeneration;
      const [legacy, runtime] = await Promise.all([
        dependencies.loadLegacyTasks(),
        readRuntime(),
      ]);
      if (generation !== loadGeneration) throw new StaleTaskLoadError("stale task load discarded");
      return {
        tasks: mergeWorkboardTaskViews(legacy.map(projectLegacyTask), runtime.tasks),
        runtime,
      };
    },
    subscribe(listener) {
      return dependencies.runtimeClient.subscribe((response) => listener(projectionFromResponse(response)));
    },
    async mutateLegacy(input) {
      if (input.viewKey !== workboardTaskViewKey(input.origin, input.sourceId)) {
        return { ok: false, reason: "runtime_unavailable" };
      }
      if (input.origin === "legacy") {
        const legacyTasks = await dependencies.loadLegacyTasks();
        if (legacyTasks.some((task) => task.id === input.sourceId)) {
          return { ok: true, value: await input.mutate() };
        }
      }
      const runtime = await readRuntime();
      if (runtime.state === "ready" && runtime.tasks.some((task) => task.sourceId === input.sourceId)) {
        return { ok: false, reason: "runtime_owned" };
      }
      return { ok: false, reason: "runtime_unavailable" };
    },
  };
}

async function loadLegacyTasks(): Promise<readonly LegacyTaskRecord[]> {
  const { data, error } = await supabase
    .from("tasks")
    .select("*")
    .order("created_at", { ascending: false });
  if (error) throw new LegacyTaskLoadError(error.message);
  return data ?? [];
}

export const taskRepository = createTaskRepository({ loadLegacyTasks, runtimeClient: companyRuntimeClient });
