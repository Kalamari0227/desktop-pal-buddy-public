import { describe, expect, it, vi } from "vitest";
import { createInitialCompanyState } from "./company-runtime";
import {
	createCompanyRuntimeClient,
	type CompanyRuntimeBridge,
} from "./companyRuntimeClient";

const epoch = "f7091d6f-e310-46f5-ae2f-a761f136f36a";
const checkingConnection = { state: "checking", reasonCode: "checking" } as const;

function status(actorSessionRevision = 0) {
	return {
		epoch,
    actorId: actorSessionRevision === 0 ? "sales-demo" : "production-demo",
    role: actorSessionRevision === 0 ? "sales" : "production",
    actorSessionRevision,
    stopped: false,
  };
}

function requestId(request: unknown): string {
	if (request === null || typeof request !== "object" || !("requestId" in request) || typeof request.requestId !== "string") {
		throw new TypeError("requestId is required");
	}
	return request.requestId;
}

function snapshot(actorSessionRevision = 0) {
	return {
		formatVersion: 1,
		revision: 0,
		currentEpoch: epoch,
		stopped: false,
		current: createInitialCompanyState({
			epoch,
			strategyVersionId: "f6846f3d-1aa0-487a-88a1-c383ba9076ea",
			createdAt: "2026-09-19T00:00:00.000Z",
			strategyContentHash: "a".repeat(64),
		}),
		records: {},
		projection: {
			actorId: actorSessionRevision === 0 ? "sales-demo" : "production-demo",
			role: actorSessionRevision === 0 ? "sales" : "production",
		},
	};
}

function success(request: unknown, nextStatus = status(), payload: unknown = {}) {
	return {
		schemaVersion: 1,
		requestId: requestId(request),
    epoch: nextStatus.epoch,
    actorSessionRevision: nextStatus.actorSessionRevision,
    ok: true,
    payload,
  };
}

	describe("company runtime renderer client", () => {
  it("decodes bounded readiness and sends only an empty explicit refresh payload", async () => {
    // Given: the bridge bootstraps checking and completes a refresh as ready.
    const refreshAiConnection = vi.fn(async (request: unknown) => success(request, status(), {
      aiConnection: { state: "ready", reasonCode: "local_profile_ready" },
    }));
    const bridge = {
      bootstrap: vi.fn(async (request: unknown) => success(request, status(), {
        status: status(), snapshot: snapshot(), aiConnection: { state: "checking", reasonCode: "checking" },
      })),
      read: vi.fn(), submit: vi.fn(), approve: vi.fn(), execute: vi.fn(), role: vi.fn(), stop: vi.fn(), resume: vi.fn(), reset: vi.fn(), cancel: vi.fn(), reconcile: vi.fn(), experience: vi.fn(),
      reviewReadiness: vi.fn(), refreshAiConnection,
      onUpdate: vi.fn(() => vi.fn()),
    } satisfies CompanyRuntimeBridge & { refreshAiConnection(request: unknown): Promise<unknown> };
    const client = createCompanyRuntimeClient(bridge);

    // When: the renderer bootstraps and explicitly refreshes readiness.
    const boot = await client.bootstrap();
    const refreshMethod = Reflect.get(client, "refreshAiConnection");
    expect(typeof refreshMethod).toBe("function");
    if (typeof refreshMethod !== "function") throw new TypeError("refreshAiConnection is required");
    const refreshed = await Reflect.apply(refreshMethod, client, []);

    // Then: the strict bounded states survive decoding and the request adds no fields.
    expect(boot).toMatchObject({ ok: true, payload: { aiConnection: { state: "checking", reasonCode: "checking" } } });
    expect(refreshed).toMatchObject({ ok: true, payload: { aiConnection: { state: "ready", reasonCode: "local_profile_ready" } } });
    expect(refreshAiConnection).toHaveBeenCalledWith(expect.objectContaining({ payload: {} }));
    expect(Object.keys((refreshAiConnection.mock.calls[0]?.[0] as { payload: object }).payload)).toEqual([]);
  });

  it("rejects invalid readiness states and unknown readiness fields", async () => {
    // Given: two bridges return untrusted readiness extensions.
    const invalidStateBridge: CompanyRuntimeBridge = {
      bootstrap: vi.fn(async (request) => success(request, status(), {
        status: status(), snapshot: snapshot(), aiConnection: { state: "connected", reasonCode: "actual_ai_succeeded" },
      })),
      read: vi.fn(), submit: vi.fn(), approve: vi.fn(), execute: vi.fn(), role: vi.fn(), stop: vi.fn(), resume: vi.fn(), reset: vi.fn(), cancel: vi.fn(), reconcile: vi.fn(), experience: vi.fn(), reviewReadiness: vi.fn(), onUpdate: vi.fn(() => vi.fn()),
    };
    const unknownFieldBridge: CompanyRuntimeBridge = {
      ...invalidStateBridge,
      bootstrap: vi.fn(async (request) => success(request, status(), {
        status: status(), snapshot: snapshot(),
        aiConnection: { state: "ready", reasonCode: "local_profile_ready", stderr: "token=secret" },
      })),
    };

    // When: each response crosses the renderer boundary.
    const invalidState = await createCompanyRuntimeClient(invalidStateBridge).bootstrap();
    const unknownField = await createCompanyRuntimeClient(unknownFieldBridge).bootstrap();

    // Then: neither response is accepted as runtime data.
    expect(invalidState).toMatchObject({ ok: false, error: { message: "invalid_runtime_response" } });
    expect(unknownField).toMatchObject({ ok: false, error: { message: "invalid_runtime_response" } });
  });

  it("keeps runtime status strict while accepting the existing bootstrap and read payloads", async () => {
    // Given: the existing bridge returns an exact status and then one with an unknown field.
    const bridge: CompanyRuntimeBridge = {
      bootstrap: vi.fn(async (request) => success(request, status(), { status: status(), snapshot: snapshot(), aiConnection: checkingConnection })),
      read: vi.fn(async (request) => success(request, status(), {
        status: { ...status(), rawDiagnostic: "must-not-cross" },
        snapshot: snapshot(),
      })),
      submit: vi.fn(), approve: vi.fn(), execute: vi.fn(), role: vi.fn(), stop: vi.fn(), resume: vi.fn(), reset: vi.fn(), cancel: vi.fn(), reconcile: vi.fn(), experience: vi.fn(),
      reviewReadiness: vi.fn(),
      onUpdate: vi.fn(() => vi.fn()),
    };
    const client = createCompanyRuntimeClient(bridge);

    // When: the client bootstraps and parses a later read.
    const boot = await client.bootstrap();
    const read = await client.read();

    // Then: the baseline bootstrap is accepted and the extended status is rejected.
    expect(boot).toMatchObject({ ok: true, payload: { status: status() } });
    expect(read).toMatchObject({ ok: false, error: { code: "unavailable", message: "invalid_runtime_response" } });
  });

  it("returns an explicit unavailable bootstrap in a browser without inventing context", async () => {
    const client = createCompanyRuntimeClient(undefined);
    await expect(client.bootstrap()).resolves.toMatchObject({
      schemaVersion: 1,
      epoch: null,
      actorSessionRevision: null,
      ok: false,
      error: { code: "unavailable" },
		});

    expect(client.getContext()).toBeNull();
  });

  it("sends only explicit strategy decision inputs through the named bridge", async () => {
		// Given: a bootstrapped management client and one bounded evidence reference.
		const reviewStrategy = vi.fn(async (request) => success(request, status(), {
			review: { decision: "create_new_version" }, version: { version: 2 },
		}));
		const bridge: CompanyRuntimeBridge = {
			bootstrap: vi.fn(async (request) => success(request, status(), { status: status(), snapshot: snapshot(), aiConnection: checkingConnection })),
			read: vi.fn(), submit: vi.fn(), approve: vi.fn(), execute: vi.fn(), role: vi.fn(), stop: vi.fn(), resume: vi.fn(), reset: vi.fn(), cancel: vi.fn(), reconcile: vi.fn(), experience: vi.fn(),
			reviewReadiness: vi.fn(), reviewStrategy,
			onUpdate: vi.fn(() => vi.fn()),
		};
		const client = createCompanyRuntimeClient(bridge);
		await client.bootstrap();
		const payload = {
			decision: "create_new_version" as const,
			baseStrategyRef: { strategy_id: "STRATEGY-DEMO-PRODUCTION", strategy_version_id: "f6846f3d-1aa0-487a-88a1-c383ba9076ea" },
			expectedBaseVersion: 1,
			evidenceRefs: [{ kind: "assessment" as const, id: "34bcbad7-bce8-4aa2-bc54-257763d394f2", version: 1 }],
			uncertainties: ["검사 완료 시점 미확인"],
			proposedChanges: {
				objective: "준비 상태 확인",
				review_question: "검사와 포장이 완료되었는가?",
				execution_criteria: ["검사와 포장 확인"],
				constraints: ["확인 전 납기 확약 금지"],
			},
		};

		// When: the renderer makes the explicit decision.
		const result = await client.reviewStrategy?.(payload);

		// Then: the renderer sends no generated identity, actor, time, hash, policy, or evidence body.
		expect(result).toMatchObject({ ok: true, payload: { version: { version: 2 } } });
		expect(reviewStrategy).toHaveBeenCalledWith(expect.objectContaining({ payload }));
		expect(JSON.stringify(reviewStrategy.mock.calls[0]?.[0])).not.toMatch(/contentHash|created_by|created_at|policy|rawBody/);
	});

	it("sends only the fixed readiness target and reuse choice through the named bridge", async () => {
		// Given: a bootstrapped renderer client with the named readiness bridge.
		const reviewReadiness = vi.fn(async (request) => success(request, status(), { assessment: { finding: "needs_review" } }));
		const bridge: CompanyRuntimeBridge = {
			bootstrap: vi.fn(async (request) => success(request, status(), { status: status(), snapshot: snapshot(), aiConnection: checkingConnection })),
			read: vi.fn(), submit: vi.fn(), approve: vi.fn(), execute: vi.fn(), role: vi.fn(), stop: vi.fn(), resume: vi.fn(), reset: vi.fn(), cancel: vi.fn(), reconcile: vi.fn(), experience: vi.fn(),
			reviewReadiness,
			onUpdate: vi.fn(() => vi.fn()),
		};
		const client = createCompanyRuntimeClient(bridge);
		await client.bootstrap();

		// When: the renderer asks to apply the latest eligible learning.
			const result = await client.reviewReadiness!({ useLatestLearning: true });

		// Then: IDs and authority-bearing fields are fixed by the client contract.
		expect(result).toMatchObject({ ok: true, payload: { assessment: { finding: "needs_review" } } });
		expect(reviewReadiness).toHaveBeenCalledWith(expect.objectContaining({
			payload: {
				orderId: "SO-DEMO-1002",
				targetPlanId: "PP-DEMO-1002",
				useLatestLearning: true,
			},
		}));
	});

	it("uses only the fixed bridge methods and discards a reply made stale by a role change", async () => {
		let releaseRead: (() => void) | undefined;
		const bridge: CompanyRuntimeBridge = {
			bootstrap: vi.fn(async (request) => success(request, status(), { status: status(), snapshot: snapshot(), aiConnection: checkingConnection })),
			read: vi.fn((request) => new Promise((resolve) => { releaseRead = () => resolve(success(request, status(), { snapshot: snapshot() })); })),
      submit: vi.fn(), approve: vi.fn(), execute: vi.fn(), stop: vi.fn(), resume: vi.fn(), reset: vi.fn(), cancel: vi.fn(), reconcile: vi.fn(),
		role: vi.fn(async (request) => success(request, status(1), status(1))),
      experience: vi.fn(async (request) => success(request, status(), { id: "experience-draft-1" })),
      reviewReadiness: vi.fn(),
      onUpdate: vi.fn(() => vi.fn()),
    };
    const client = createCompanyRuntimeClient(bridge);
    expect((await client.bootstrap()).ok).toBe(true);
		await expect(client.saveExperienceDraft?.({ workboardTaskId: epoch, draft: { correction: "verify" } })).resolves.toMatchObject({ ok: true });
		expect(bridge.experience).toHaveBeenCalledWith(expect.objectContaining({ payload: { workboardTaskId: epoch, draft: { correction: "verify" } } }));
		const pending = client.read({});
		expect((await client.role({ actorId: "production-demo" })).ok).toBe(true);
		releaseRead?.();
    await expect(pending).resolves.toMatchObject({ ok: false, error: { code: "stale_context" } });
    expect(client.getContext()).toEqual({ epoch: status().epoch, actorSessionRevision: 1 });
    expect(Object.keys(bridge)).not.toContain("invoke");
  });

  it("sends only the explicit strategy adoption request through the named bridge", async () => {
    // Given: a bootstrapped client with the dedicated adoption bridge.
    const adoptStrategy = vi.fn(async (request: unknown) => success(request, status(), { idempotent: false }));
    const bridge: CompanyRuntimeBridge = {
      bootstrap: vi.fn(async (request) => success(request, status(), { status: status(), snapshot: snapshot(), aiConnection: checkingConnection })),
      read: vi.fn(), submit: vi.fn(), approve: vi.fn(), execute: vi.fn(), role: vi.fn(), stop: vi.fn(), resume: vi.fn(), reset: vi.fn(), cancel: vi.fn(), reconcile: vi.fn(), experience: vi.fn(),
      reviewReadiness: vi.fn(), adoptStrategy, onUpdate: vi.fn(() => vi.fn()),
    };
    const client = createCompanyRuntimeClient(bridge);
    await client.bootstrap();
    const payload = {
      requestId: "2e585ecc-bc84-4bdb-a488-08d28cb55fa1",
      reviewId: "0e7235c4-2f6a-4a96-b1f8-21d12b5b0cb4",
      expectedActiveRef: {
        strategy_id: "STRATEGY-DEMO-PRODUCTION",
        strategy_version_id: "f6846f3d-1aa0-487a-88a1-c383ba9076ea",
      },
    };

    // When: the renderer adopts the reviewed strategy.
    await client.adoptStrategy?.(payload);

    // Then: actor, epoch, time, target, and policy are absent from the payload.
    expect(adoptStrategy).toHaveBeenCalledWith(expect.objectContaining({ payload }));
    expect(JSON.stringify(adoptStrategy.mock.calls[0]?.[0])).not.toMatch(/actorId|adoptedAt|toRef|policy/);
  });

  it("sends only a workboard task identity for result explanation and validates the reply", async () => {
    // Given: a bootstrapped client and a strict explanation bridge.
    const explainResult = vi.fn(async (request: unknown) => success(request, status(), {
      runtimeMode: "stub",
      actualAI: false,
      explanation: {
        schemaVersion: 1,
        kind: "explanation",
        summary: "검증된 결과 설명",
        verifiedFactIds: ["verified-readback:1"],
        citedEvidenceIds: ["readback:1"],
        uncertainties: ["사업 결과 미확인"],
        authorityClaims: [],
      },
    }));
    const bridge: CompanyRuntimeBridge = {
      bootstrap: vi.fn(async (request) => success(request, status(), { status: status(), snapshot: snapshot(), aiConnection: checkingConnection })),
      read: vi.fn(), submit: vi.fn(), approve: vi.fn(), execute: vi.fn(), role: vi.fn(), stop: vi.fn(), resume: vi.fn(), reset: vi.fn(), cancel: vi.fn(), reconcile: vi.fn(), experience: vi.fn(),
      reviewReadiness: vi.fn(), explainResult, onUpdate: vi.fn(() => vi.fn()),
    };
    const client = createCompanyRuntimeClient(bridge);
    await client.bootstrap();

    // When: the selected task asks for its verified result explanation.
    const result = await client.explainResult?.({ workboardTaskId: epoch });

    // Then: no facts, citations, actor, or authority are renderer-controlled.
    expect(result).toMatchObject({ ok: true, payload: { actualAI: false, explanation: { citedEvidenceIds: ["readback:1"] } } });
    expect(explainResult).toHaveBeenCalledWith(expect.objectContaining({ payload: { workboardTaskId: epoch } }));
    expect(JSON.stringify(explainResult.mock.calls[0]?.[0])).not.toMatch(/facts|citations|actorId|authority|businessOutcome/);
  });

	it("installs one update listener, ignores stale updates, and removes it on unsubscribe", async () => {
		let listener: ((value: unknown) => void) | undefined;
		const cleanup = vi.fn();
		const bridge: CompanyRuntimeBridge = {
			bootstrap: vi.fn(async (request) => success(request, status(), { status: status(), snapshot: snapshot(), aiConnection: checkingConnection })),
      read: vi.fn(), submit: vi.fn(), approve: vi.fn(), execute: vi.fn(), role: vi.fn(), stop: vi.fn(), resume: vi.fn(), reset: vi.fn(), cancel: vi.fn(), reconcile: vi.fn(), experience: vi.fn(), reviewReadiness: vi.fn(),
      onUpdate: vi.fn((callback) => { listener = callback; return cleanup; }),
    };
    const client = createCompanyRuntimeClient(bridge);
		await client.bootstrap();
		const callback = vi.fn();
		const unsubscribe = client.subscribe(callback);
		listener?.({ ...success({ requestId: crypto.randomUUID() }, status(), { snapshot: snapshot() }), epoch: crypto.randomUUID() });
		expect(callback).not.toHaveBeenCalled();
		listener?.(success({ requestId: crypto.randomUUID() }, status(), { snapshot: snapshot() }));
		expect(callback).toHaveBeenCalledTimes(1);
    unsubscribe();
		expect(cleanup).toHaveBeenCalledTimes(1);
	});

	it("keeps an in-flight read current when a same-context publish arrives", async () => {
		let listener: ((value: unknown) => void) | undefined;
		let releaseRead: (() => void) | undefined;
		const bridge: CompanyRuntimeBridge = {
			bootstrap: vi.fn(async (request) => success(request, status(), { status: status(), snapshot: snapshot(), aiConnection: checkingConnection })),
			read: vi.fn((request) => new Promise((resolve) => { releaseRead = () => resolve(success(request, status(), { snapshot: snapshot() })); })),
			submit: vi.fn(), approve: vi.fn(), execute: vi.fn(), role: vi.fn(), stop: vi.fn(), resume: vi.fn(), reset: vi.fn(), cancel: vi.fn(), reconcile: vi.fn(), experience: vi.fn(), reviewReadiness: vi.fn(),
			onUpdate: vi.fn((callback) => { listener = callback; return vi.fn(); }),
		};
		const client = createCompanyRuntimeClient(bridge);
		await client.bootstrap();
		client.subscribe(vi.fn());
		const pending = client.read({});
		listener?.(success({ requestId: crypto.randomUUID() }, status(), { status: status(), snapshot: snapshot() }));
		releaseRead?.();

		await expect(pending).resolves.toMatchObject({ ok: true });
	});

	it("accepts a role reply when its update publication arrives first", async () => {
		let listener: ((value: unknown) => void) | undefined;
		const bridge: CompanyRuntimeBridge = {
			bootstrap: vi.fn(async (request) => success(request, status(), { status: status(), snapshot: snapshot(), aiConnection: checkingConnection })),
			read: vi.fn(), submit: vi.fn(), approve: vi.fn(), execute: vi.fn(), stop: vi.fn(), resume: vi.fn(), reset: vi.fn(), cancel: vi.fn(), reconcile: vi.fn(), experience: vi.fn(), reviewReadiness: vi.fn(),
			role: vi.fn(async (request) => {
				const nextStatus = status(1);
				listener?.(success({ requestId: crypto.randomUUID() }, nextStatus, { status: nextStatus, snapshot: snapshot(1) }));
				return success(request, nextStatus, nextStatus);
			}),
			onUpdate: vi.fn((callback) => { listener = callback; return vi.fn(); }),
		};
		const client = createCompanyRuntimeClient(bridge);
		await client.bootstrap();
		client.subscribe(vi.fn());

		await expect(client.role({ actorId: "production-demo" })).resolves.toMatchObject({ ok: true });
		expect(client.getContext()).toEqual({ epoch, actorSessionRevision: 1 });
	});
});
