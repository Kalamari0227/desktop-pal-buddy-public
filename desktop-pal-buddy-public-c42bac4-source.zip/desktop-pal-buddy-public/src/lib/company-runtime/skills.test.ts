import { describe, expect, it } from "vitest";
import { createInitialCompanyState } from "./fixtures";

const seed = {
  epoch: "85c540f3-5e30-4f65-9e30-4f65e2c782a2",
  strategyVersionId: "266cae99-24da-4595-95ed-c2c782a20417",
  createdAt: "2026-09-18T00:00:00.000Z",
  strategyContentHash: "a".repeat(64),
} as const;

function invocation(overrides: Record<string, unknown> = {}) {
  return {
    skillRef: { id: "assess-order-priority", version: 1 },
    connectorId: "company-runtime",
    capabilities: ["virtual-erp-read"],
    policyVersion: "company-policy-v1",
    inputSchemaVersion: 1,
    outputSchemaVersion: 1,
    state: createInitialCompanyState(seed),
    input: {
      orderId: "SO-DEMO-1001",
      planId: "PP-DEMO-1001",
      proposedPriority: 1,
    },
    ...overrides,
  };
}

describe("registered company-runtime skill dispatch", () => {
  it("publishes the dispatcher and assessments from the runtime library entry point", async () => {
    // Break caught: a built runtime library omits the approved skill API even though internal module tests pass.
    const runtime = await import("./index");

    expect(runtime.dispatchRegisteredSkill).toBeTypeOf("function");
    expect(runtime.assessOrderPriority).toBeTypeOf("function");
    expect(runtime.reviewProductionReadiness).toBeTypeOf("function");
  });

  it("runs the canonical priority assessment only after capability, connector, policy, version, and reviewed registration checks", async () => {
    // Break caught: bypassing registration would let an unreviewed or incorrectly scoped caller assess ERP state.
    const { dispatchRegisteredSkill } = await import("./skills");

    const result = dispatchRegisteredSkill(invocation());

    expect(result).toMatchObject({
      ok: true,
      status: "proposed",
      skillRef: { id: "assess-order-priority", version: 1 },
      result: {
        beforeOrder: ["PP-DEMO-1002", "PP-DEMO-1003", "PP-DEMO-1001"],
        proposedOrder: ["PP-DEMO-1001", "PP-DEMO-1002", "PP-DEMO-1003"],
        displacedPlanIds: ["PP-DEMO-1002", "PP-DEMO-1003"],
        delivery: { status: "unknown" },
        mutationCount: 0,
      },
    });
  });

  it.each([
    ["missing capability", invocation({ capabilities: [] }), "missing_capability"],
    ["unregistered connector", invocation({ connectorId: "model-added-connector" }), "unregistered_connector"],
    ["unregistered skill", invocation({ skillRef: { id: "model-added-skill", version: 1 } }), "unregistered_skill"],
  ])("blocks %s without mutating the supplied ledger", async (_name, supplied, expectedReason) => {
    // Break caught: a caller could use a model-proposed skill or connector to bypass the fixed registry.
    const { dispatchRegisteredSkill } = await import("./skills");
    const before = JSON.stringify(supplied.state);

    const result = dispatchRegisteredSkill(supplied);

    expect(result).toMatchObject({ ok: false, status: "blocked", reason: expectedReason, mutationCount: 0 });
    expect(JSON.stringify(supplied.state)).toBe(before);
  });

  it("rejects a nested state field so untrusted skill input cannot replace the validated ledger", async () => {
    // Break caught: object spreading could let model input override the outer validated state after registry checks.
    const { dispatchRegisteredSkill } = await import("./skills");
    const supplied = invocation();
    const forgedState = createInitialCompanyState(seed);
    forgedState.inventory[0].availableKg = 999_999;
    const before = JSON.stringify(supplied.state);

    const result = dispatchRegisteredSkill({
      ...supplied,
      input: {
        orderId: "SO-DEMO-1001",
        planId: "PP-DEMO-1001",
        proposedPriority: 1,
        state: forgedState,
      },
    });

    expect(result).toMatchObject({ ok: false, status: "blocked", reason: "invalid_input", mutationCount: 0 });
    expect(JSON.stringify(supplied.state)).toBe(before);
  });
});
