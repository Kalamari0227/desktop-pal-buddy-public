import { z } from "zod";
import { strategyRefSchema } from "../agentic/schemas";
import type { RuntimeStrategyVersion, StrategyReview } from "./contracts";
import {
  actorIdSchema,
  companyStateSchema,
  runtimeStrategyVersionSchema,
  strategyReviewSchema,
} from "./schemas";
import { canonicalSerialize } from "./transitions";

const boundedText = z.string().trim().min(1).max(500);
const digest = z.string().regex(/^[a-f0-9]{64}$/);
const evidenceSnapshotSchema = z.object({
  kind: z.enum(["task", "assessment", "readback", "learning"]),
  id: boundedText,
  version: z.number().int().positive(),
  contentHash: digest,
  visibilityScope: z.enum(["official", "management_shared"]),
}).strict();
const proposedChangesSchema = z.object({
  objective: boundedText,
  review_question: boundedText,
  execution_criteria: z.array(boundedText).min(1).max(12),
  constraints: z.array(boundedText).min(1).max(12),
}).strict();
const strategyReviewDecisionInputSchema = z.object({
  requestId: z.string().uuid(),
  state: companyStateSchema,
  existingReviews: z.array(strategyReviewSchema),
  decision: z.enum(["maintain", "create_new_version"]),
  baseStrategyRef: strategyRefSchema,
  expectedBaseVersion: z.number().int().positive(),
  evidenceSnapshot: z.array(evidenceSnapshotSchema).min(1).max(12),
  uncertainties: z.array(boundedText).min(1).max(12),
  proposedChanges: proposedChangesSchema,
  reviewerActorId: actorIdSchema,
  reviewedAt: z.string().datetime(),
  nextStrategyVersionId: z.string().uuid().nullable(),
}).strict();
const strategyReviewReplayInputSchema = z.object({
  requestId: z.string().uuid(),
  existingReviews: z.array(strategyReviewSchema),
  strategyVersions: z.array(runtimeStrategyVersionSchema),
  decision: z.enum(["maintain", "create_new_version"]),
  baseStrategyRef: strategyRefSchema,
  expectedBaseVersion: z.number().int().positive(),
  evidenceRefs: z.array(z.object({
    kind: z.enum(["task", "assessment", "readback", "learning"]),
    id: boundedText,
    version: z.number().int().positive(),
  }).strict()).min(1).max(12),
  uncertainties: z.array(boundedText).min(1).max(12),
  proposedChanges: proposedChangesSchema,
  reviewerActorId: actorIdSchema,
}).strict();

type FailureCode =
  | "invalid_input"
  | "management_role_required"
  | "stale_base"
  | "duplicate_request";

export type StrategyReviewDecisionResult =
  | {
    readonly ok: true;
    readonly review: StrategyReview;
    readonly version: RuntimeStrategyVersion | null;
    readonly idempotent: boolean;
  }
  | { readonly ok: false; readonly code: FailureCode };

export type StrategyReviewReplayResult = StrategyReviewDecisionResult
  | { readonly ok: false; readonly code: "not_found" };

function sameReviewRequest(
  review: StrategyReview,
  input: z.infer<typeof strategyReviewDecisionInputSchema>,
): boolean {
  return canonicalSerialize({
    baseStrategyRef: review.baseStrategyRef,
    evidenceSnapshot: review.evidenceSnapshot,
    uncertainties: review.uncertainties,
    proposedChanges: review.proposedChanges,
    reviewerActorId: review.reviewerActorId,
    decision: review.decision,
  }) === canonicalSerialize({
    baseStrategyRef: input.baseStrategyRef,
    evidenceSnapshot: input.evidenceSnapshot,
    uncertainties: input.uncertainties,
    proposedChanges: input.proposedChanges,
    reviewerActorId: input.reviewerActorId,
    decision: input.decision,
  });
}

export function replayStrategyReview(rawInput: unknown): StrategyReviewReplayResult {
  const parsed = strategyReviewReplayInputSchema.safeParse(rawInput);
  if (!parsed.success) return { ok: false, code: "invalid_input" };
  const input = parsed.data;
  if (input.reviewerActorId !== "management-demo") return { ok: false, code: "management_role_required" };
  const prior = input.existingReviews.find((review) => review.id === input.requestId);
  if (!prior) return { ok: false, code: "not_found" };
  const base = input.strategyVersions.find((candidate) =>
    candidate.strategy_id === input.baseStrategyRef.strategy_id
    && candidate.strategy_version_id === input.baseStrategyRef.strategy_version_id);
  const same = base?.version === input.expectedBaseVersion && canonicalSerialize({
    baseStrategyRef: prior.baseStrategyRef,
    evidenceRefs: prior.evidenceSnapshot.map(({ kind, id, version }) => ({ kind, id, version })),
    uncertainties: prior.uncertainties,
    proposedChanges: prior.proposedChanges,
    reviewerActorId: prior.reviewerActorId,
    decision: prior.decision,
  }) === canonicalSerialize({
    baseStrategyRef: input.baseStrategyRef,
    evidenceRefs: input.evidenceRefs,
    uncertainties: input.uncertainties,
    proposedChanges: input.proposedChanges,
    reviewerActorId: input.reviewerActorId,
    decision: input.decision,
  });
  if (!same) return { ok: false, code: "duplicate_request" };
  const version = prior.resultingStrategyRef === null
    ? null
    : input.strategyVersions.find((candidate) =>
      candidate.strategy_id === prior.resultingStrategyRef?.strategy_id
      && candidate.strategy_version_id === prior.resultingStrategyRef.strategy_version_id) ?? null;
  if (prior.resultingStrategyRef !== null && version === null) return { ok: false, code: "duplicate_request" };
  return { ok: true, review: prior, version, idempotent: true };
}

export function decideStrategyReview(
  rawInput: unknown,
  hash: (value: string) => string,
): StrategyReviewDecisionResult {
  const parsed = strategyReviewDecisionInputSchema.safeParse(rawInput);
  if (!parsed.success || typeof hash !== "function") return { ok: false, code: "invalid_input" };
  const input = parsed.data;
  if (input.reviewerActorId !== "management-demo") return { ok: false, code: "management_role_required" };

  const prior = input.existingReviews.find((review) => review.id === input.requestId);
  if (prior) {
    if (!sameReviewRequest(prior, input)) return { ok: false, code: "duplicate_request" };
    const version = prior.resultingStrategyRef === null
      ? null
      : input.state.strategyVersions.find((candidate) =>
        candidate.strategy_id === prior.resultingStrategyRef?.strategy_id
        && candidate.strategy_version_id === prior.resultingStrategyRef.strategy_version_id) ?? null;
    if (prior.resultingStrategyRef !== null && version === null) return { ok: false, code: "duplicate_request" };
    return { ok: true, review: prior, version, idempotent: true };
  }

  const base = input.state.strategyVersions.find((candidate) =>
    candidate.strategy_id === input.baseStrategyRef.strategy_id
    && candidate.strategy_version_id === input.baseStrategyRef.strategy_version_id);
  const active = input.state.activeStrategyRef;
  if (!base
    || active.strategy_id !== input.baseStrategyRef.strategy_id
    || active.strategy_version_id !== input.baseStrategyRef.strategy_version_id
    || base.version !== input.expectedBaseVersion) {
    return { ok: false, code: "stale_base" };
  }
  if ((input.decision === "maintain") !== (input.nextStrategyVersionId === null)) {
    return { ok: false, code: "invalid_input" };
  }

  let version: RuntimeStrategyVersion | null = null;
  if (input.decision === "create_new_version") {
    const versionId = input.nextStrategyVersionId;
    if (versionId === null) return { ok: false, code: "invalid_input" };
    if (input.state.strategyVersions.some((candidate) => candidate.strategy_version_id === versionId)) {
      return { ok: false, code: "invalid_input" };
    }
    const nextVersion = Math.max(
      ...input.state.strategyVersions
        .filter((candidate) => candidate.strategy_id === base.strategy_id)
        .map((candidate) => candidate.version),
    ) + 1;
    const content = {
      strategy_version_id: versionId,
      strategy_id: base.strategy_id,
      version: nextVersion,
      objective: input.proposedChanges.objective,
      review_question: input.proposedChanges.review_question,
      parent_version_id: base.strategy_version_id,
      execution_criteria: input.proposedChanges.execution_criteria,
      constraints: input.proposedChanges.constraints,
      created_by: input.reviewerActorId,
      created_at: input.reviewedAt,
      origin: "management" as const,
    };
    const parsedVersion = runtimeStrategyVersionSchema.safeParse({
      ...content,
      content_hash: hash(canonicalSerialize(content)),
    });
    if (!parsedVersion.success) return { ok: false, code: "invalid_input" };
    version = parsedVersion.data;
  }

  const review = strategyReviewSchema.parse({
    id: input.requestId,
    epoch: input.state.currentEpoch,
    baseStrategyRef: input.baseStrategyRef,
    evidenceSnapshot: input.evidenceSnapshot,
    uncertainties: input.uncertainties,
    proposedChanges: input.proposedChanges,
    reviewerActorId: input.reviewerActorId,
    reviewedAt: input.reviewedAt,
    decision: input.decision,
    resultingStrategyRef: version === null ? null : {
      strategy_id: version.strategy_id,
      strategy_version_id: version.strategy_version_id,
    },
  });
  return { ok: true, review, version, idempotent: false };
}
