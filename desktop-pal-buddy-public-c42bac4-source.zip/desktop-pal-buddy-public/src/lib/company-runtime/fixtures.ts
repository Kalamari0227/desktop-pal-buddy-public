import type { CompanyState, SkillDescriptor } from "./contracts";
import { companyStateSchema } from "./schemas";

export interface TrustedSeedInputs {
  epoch: string;
  strategyVersionId: string;
  createdAt: string;
  strategyContentHash: string;
  stopped?: boolean;
  bootstrap?: boolean;
}

export const REGISTERED_SKILLS: readonly SkillDescriptor[] = [
  {
    id: "assess-order-priority",
    version: 1,
    inputSchemaVersion: 1,
    outputSchemaVersion: 1,
    requiredCapabilities: ["virtual-erp-read"],
    allowedConnectorIds: ["company-runtime"],
    policyVersion: "company-policy-v1",
    reviewState: "approved",
  },
  {
    id: "change-production-priority",
    version: 1,
    inputSchemaVersion: 1,
    outputSchemaVersion: 1,
    requiredCapabilities: ["virtual-erp-read", "virtual-erp-production-priority-write"],
    allowedConnectorIds: ["company-runtime"],
    policyVersion: "company-policy-v1",
    reviewState: "approved",
  },
  {
    id: "review-production-readiness",
    version: 1,
    inputSchemaVersion: 1,
    outputSchemaVersion: 1,
    requiredCapabilities: ["virtual-erp-read"],
    allowedConnectorIds: ["company-runtime"],
    policyVersion: "company-policy-v1",
    reviewState: "approved",
  },
];

export function createInitialCompanyState(trusted: TrustedSeedInputs): CompanyState {
  return companyStateSchema.parse({
    formatVersion: 1,
    revision: 0,
    currentEpoch: trusted.epoch,
    stopped: trusted.stopped ?? false,
    bootstrap: trusted.bootstrap ?? true,
    customers: [{ id: "CUSTOMER-DEMO-1001", version: 1, name: "Demo Automotive" }],
    salesOpportunities: [{
      id: "OPP-DEMO-1001",
      version: 1,
      customerId: "CUSTOMER-DEMO-1001",
      materialId: "MAT-GA-DEMO",
      requestedKg: 20_000,
      status: "qualified",
    }],
    quotes: [{
      id: "QUOTE-DEMO-1001",
      version: 1,
      opportunityId: "OPP-DEMO-1001",
      quantityKg: 20_000,
      status: "approved",
    }],
    salesOrders: [
      { id: "SO-DEMO-1001", version: 1, customerId: "CUSTOMER-DEMO-1001", materialId: "MAT-GA-DEMO", quantityKg: 20_000, status: "in_production" },
      { id: "SO-DEMO-1002", version: 1, customerId: "CUSTOMER-DEMO-1001", materialId: "MAT-GA-DEMO", quantityKg: 10_000, status: "in_production" },
      { id: "SO-DEMO-1003", version: 1, customerId: "CUSTOMER-DEMO-1001", materialId: "MAT-GA-DEMO", quantityKg: 8_000, status: "in_production" },
    ],
    inventory: [{ id: "INV-DEMO-GA-ULSAN", version: 1, materialId: "MAT-GA-DEMO", availableKg: 25_000, warehouseId: "WH-ULSAN" }],
    productionPlans: [
      { id: "PP-DEMO-1001", orderId: "SO-DEMO-1001", version: 1, productionGroupId: "PG-DEMO-GA", priority: 5, status: "queued", qualityHold: false, materialId: "MAT-GA-DEMO", requiredKg: 20_000 },
      { id: "PP-DEMO-1002", orderId: "SO-DEMO-1002", version: 1, productionGroupId: "PG-DEMO-GA", priority: 2, status: "queued", qualityHold: false, materialId: "MAT-GA-DEMO", requiredKg: 10_000 },
      { id: "PP-DEMO-1003", orderId: "SO-DEMO-1003", version: 1, productionGroupId: "PG-DEMO-GA", priority: 3, status: "queued", qualityHold: false, materialId: "MAT-GA-DEMO", requiredKg: 8_000 },
    ],
    inspections: [
      { id: "INSPECTION-DEMO-1001", orderId: "SO-DEMO-1001", version: 1, status: "pending" },
      { id: "INSPECTION-DEMO-1002", orderId: "SO-DEMO-1002", version: 1, status: "pending" },
      { id: "INSPECTION-DEMO-1003", orderId: "SO-DEMO-1003", version: 1, status: "passed" },
    ],
    shipments: [
      { id: "SHIPMENT-DEMO-1001", orderId: "SO-DEMO-1001", version: 1, status: "not_ready", packagingStatus: "unchecked" },
      { id: "SHIPMENT-DEMO-1002", orderId: "SO-DEMO-1002", version: 1, status: "not_ready", packagingStatus: "unchecked" },
      { id: "SHIPMENT-DEMO-1003", orderId: "SO-DEMO-1003", version: 1, status: "not_ready", packagingStatus: "ready" },
    ],
    skills: REGISTERED_SKILLS.map((skill) => ({ ...skill, requiredCapabilities: [...skill.requiredCapabilities], allowedConnectorIds: [...skill.allowedConnectorIds] })),
    strategyVersions: [{
      strategy_version_id: trusted.strategyVersionId,
      strategy_id: "STRATEGY-DEMO-PRODUCTION",
      version: 1,
      objective: "우선순위 변경 전 영향 주문을 확인",
      review_question: "우선순위 변경이 다른 주문과 검사·출하 준비에 미치는 영향은 무엇인가?",
      parent_version_id: null,
      execution_criteria: ["대상 주문·재고·생산계획 버전을 확인"],
      constraints: ["검사·출하 준비 미확인 상태에서 납기를 확약하지 않음"],
      created_by: "management-demo",
      created_at: trusted.createdAt,
      origin: "seed",
      content_hash: trusted.strategyContentHash,
    }],
    activeStrategyRef: {
      strategy_id: "STRATEGY-DEMO-PRODUCTION",
      strategy_version_id: trusted.strategyVersionId,
    },
    bootstrapReadSet: [
      { kind: "production_plan", id: "PP-DEMO-1001", version: 1 },
      { kind: "sales_order", id: "SO-DEMO-1001", version: 1 },
      { kind: "inventory", id: "INV-DEMO-GA-ULSAN", version: 1 },
    ],
  });
}

export function productionPlanOrder(state: Pick<CompanyState, "productionPlans">): string[] {
  return [...state.productionPlans]
    .sort((left, right) => left.priority - right.priority || left.id.localeCompare(right.id))
    .map((plan) => plan.id);
}
