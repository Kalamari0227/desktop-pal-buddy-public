import { describe, expect, it } from "vitest";
import { createInitialCompanyState } from "./fixtures";

const seed = {
  epoch: "85c540f3-5e30-4f65-9e30-4f65e2c782a2",
  strategyVersionId: "266cae99-24da-4595-95ed-c2c782a20417",
  createdAt: "2026-09-18T00:00:00.000Z",
  strategyContentHash: "a".repeat(64),
} as const;

const trusted = {
  intentId: "a711eef6-4a2b-4a20-bb6e-552ecbab7258",
  workboardTaskId: "719c1670-0035-437a-8f80-245edb22e99a",
  packetTaskId: "2e03a8e9-c48d-470b-8470-e925965891d2",
  epoch: seed.epoch,
  requesterActorId: "sales-demo",
  createdAt: "2026-09-18T01:00:00.000Z",
} as const;

function testDigest(value: string): string {
  let accumulator = 0x811c9dc5;
  for (const character of value) {
    accumulator ^= character.charCodeAt(0);
    accumulator = Math.imul(accumulator, 0x01000193);
  }
  return (accumulator >>> 0).toString(16).padStart(8, "0").repeat(8);
}

function proposalInput(overrides: Record<string, unknown> = {}) {
  const state = createInitialCompanyState(seed);
  return {
    mode: "shadow",
    state,
    orderId: "SO-DEMO-1001",
    targetPlanId: "PP-DEMO-1001",
    toPriority: 1,
    strategyRef: state.activeStrategyRef,
    skillRef: { id: "change-production-priority", version: 1 },
    policyVersion: "company-policy-v1",
    trusted,
    ...overrides,
  };
}

describe("immutable action proposals and shadow policy", () => {
  it("creates a canonical intent and a deterministic 5 to 1 shadow without changing ERP state", async () => {
    // Break caught: proposal generation could trust caller impact data, omit source versions, or mutate the virtual ERP during Shadow.
    const { createActionProposal } = await import("./policy");
    const supplied = proposalInput();
    const before = JSON.stringify(supplied.state);

    const result = createActionProposal(supplied, testDigest);
    const repeated = createActionProposal(proposalInput(), testDigest);

    expect(result).toMatchObject({
      status: "proposed",
      intent: {
        id: trusted.intentId,
        revision: 1,
        targetPlanId: "PP-DEMO-1001",
        fromPriority: 5,
        toPriority: 1,
        strategyRef: supplied.state.activeStrategyRef,
        skillRef: { id: "change-production-priority", version: 1 },
        policyVersion: "company-policy-v1",
        requesterActorId: "sales-demo",
        proposalDigest: expect.stringMatching(/^[a-f0-9]{64}$/),
      },
      shadow: {
        diff: { priority: { before: 5, after: 1 }, version: { before: 1, after: 1 } },
        beforeOrder: ["PP-DEMO-1002", "PP-DEMO-1003", "PP-DEMO-1001"],
        afterOrder: ["PP-DEMO-1001", "PP-DEMO-1002", "PP-DEMO-1003"],
        affectedPlanIds: ["PP-DEMO-1002", "PP-DEMO-1003"],
        mutationCount: 0,
      },
      mutationCount: 0,
    });
    expect(result.status === "proposed" && result.intent.readSet).toEqual([
      { kind: "inspection", id: "INSPECTION-DEMO-1001", version: 1 },
      { kind: "inventory", id: "INV-DEMO-GA-ULSAN", version: 1 },
      { kind: "production_plan", id: "PP-DEMO-1001", version: 1 },
      { kind: "production_plan", id: "PP-DEMO-1002", version: 1 },
      { kind: "production_plan", id: "PP-DEMO-1003", version: 1 },
      { kind: "sales_order", id: "SO-DEMO-1001", version: 1 },
      { kind: "shipment", id: "SHIPMENT-DEMO-1001", version: 1 },
    ]);
    expect(JSON.stringify(supplied.state)).toBe(before);
    expect(result.status === "proposed" && Object.isFrozen(result.intent)).toBe(true);
    expect(result.status === "proposed" && Object.isFrozen(result.intent.readSet)).toBe(true);
    expect(repeated.status === "proposed" && result.status === "proposed"
      ? repeated.intent.proposalDigest
      : undefined).toBe(result.status === "proposed" ? result.intent.proposalDigest : undefined);
  });

  it("uses one canonical serializer for proposal and read-set digest inputs", async () => {
    // Break caught: main could hash key insertion order or a differently normalized read set and bind approval to different bytes.
    const {
      canonicalizeActionIntentDigestInput,
      canonicalizeReadSet,
      canonicalizeReadSetDigestInput,
    } = await import("./transitions");
    const left = [
      { kind: "sales_order", id: "SO-DEMO-1001", version: 1 },
      { version: 1, id: "PP-DEMO-1001", kind: "production_plan" },
    ];
    const right = [...left].reverse();

    expect(canonicalizeReadSet(left)).toEqual([
      { kind: "production_plan", id: "PP-DEMO-1001", version: 1 },
      { kind: "sales_order", id: "SO-DEMO-1001", version: 1 },
    ]);
    expect(canonicalizeReadSetDigestInput(left)).toBe(canonicalizeReadSetDigestInput(right));
    expect(canonicalizeReadSetDigestInput(left)).toBe('[{"id":"PP-DEMO-1001","kind":"production_plan","version":1},{"id":"SO-DEMO-1001","kind":"sales_order","version":1}]');

    const result = createProposalForCanonicalTest(await import("./policy"));
    if (result.status !== "proposed") throw new Error(`unexpected status: ${result.status}`);
    const reordered = {
      ...result.intent,
      strategyRef: {
        strategy_version_id: result.intent.strategyRef.strategy_version_id,
        strategy_id: result.intent.strategyRef.strategy_id,
      },
      readSet: [...result.intent.readSet].reverse(),
      evidenceRefs: [...result.intent.evidenceRefs].reverse(),
    };
    expect(canonicalizeActionIntentDigestInput(result.intent)).toBe(canonicalizeActionIntentDigestInput(reordered));
  });

  it("increments revision and changes the digest when the requested priority changes", async () => {
    // Break caught: editing a proposal could retain an earlier approval-bound revision or digest.
    const { createActionProposal, reviseActionProposal } = await import("./policy");
    const first = createActionProposal(proposalInput(), testDigest);
    if (first.status !== "proposed") throw new Error(`unexpected status: ${first.status}`);

    const revised = reviseActionProposal({
      state: createInitialCompanyState(seed),
      previousIntent: first.intent,
      toPriority: 2,
      createdAt: "2026-09-18T01:05:00.000Z",
    }, testDigest);

    expect(revised).toMatchObject({
      status: "proposed",
      intent: { id: first.intent.id, revision: 2, fromPriority: 5, toPriority: 2 },
      shadow: { diff: { priority: { before: 5, after: 2 } } },
    });
    expect(revised.status === "proposed" && revised.intent.proposalDigest).not.toBe(first.intent.proposalDigest);
  });

  it("revises and previews an existing v1 task after active strategy advances to stored v2", async () => {
    // Given: an immutable v1 intent exists before management activates stored v2.
    const { createActionProposal, previewPriorityShadow, reviseActionProposal } = await import("./policy");
    const v1State = createInitialCompanyState(seed);
    const first = createActionProposal(proposalInput(), testDigest);
    if (first.status !== "proposed") throw new Error(`unexpected status: ${first.status}`);
    const v2Id = "98d84b35-3bdf-4642-b251-f96df1626515";
    const stateWithActiveV2 = {
      ...v1State,
      strategyVersions: [...v1State.strategyVersions, {
        ...v1State.strategyVersions[0],
        strategy_version_id: v2Id,
        version: 2,
        parent_version_id: v1State.activeStrategyRef.strategy_version_id,
        origin: "management" as const,
        content_hash: "b".repeat(64),
      }],
      activeStrategyRef: { strategy_id: v1State.activeStrategyRef.strategy_id, strategy_version_id: v2Id },
    };

    // When: the pinned task is previewed and revised without replacing its strategy ref.
    const preview = previewPriorityShadow({ state: stateWithActiveV2, intent: first.intent, mode: "shadow" });
    const revised = reviseActionProposal({
      state: stateWithActiveV2,
      previousIntent: first.intent,
      toPriority: 2,
      createdAt: "2026-09-18T01:05:00.000Z",
    }, testDigest);

    // Then: both lifecycle decisions retain the exact stored v1 ref.
    expect(preview.status).toBe("proposed");
    expect(revised.status).toBe("proposed");
    expect(revised.status === "proposed" ? revised.intent.strategyRef : null).toEqual(v1State.activeStrategyRef);
  });

  it("rejects a revised proposal when the prior immutable digest was tampered", async () => {
    // Break caught: revision could legitimize a caller-edited prior intent by issuing it a fresh digest.
    const { createActionProposal, reviseActionProposal } = await import("./policy");
    const first = createActionProposal(proposalInput(), testDigest);
    if (first.status !== "proposed") throw new Error(`unexpected status: ${first.status}`);

    expect(reviseActionProposal({
      state: createInitialCompanyState(seed),
      previousIntent: { ...first.intent, proposalDigest: "f".repeat(64) },
      toPriority: 2,
      createdAt: "2026-09-18T01:05:00.000Z",
    }, testDigest)).toEqual({ status: "blocked", reason: "invalid_digest", mutationCount: 0 });
  });

  it("returns already_satisfied rather than creating a no-op proposal", async () => {
    // Break caught: an equal priority could be presented as an approvable mutation.
    const { createActionProposal } = await import("./policy");

    expect(createActionProposal(proposalInput({ toPriority: 5 }), testDigest)).toEqual({
      status: "already_satisfied",
      reason: "already_satisfied",
      mutationCount: 0,
    });
  });

  it.each([
    ["read-only change", { mode: "read_only" }, "read_only_change_not_allowed"],
    ["unknown mode", { mode: "automatic" }, "invalid_input"],
    ["fake AI approval", { approved: true }, "invalid_input"],
    ["unknown priority", { toPriority: 99 }, "invalid_input"],
    ["unknown target", { targetPlanId: "PP-IGNORE-POLICY" }, "missing_production_plan"],
    ["stale epoch", { trusted: { ...trusted, epoch: "c62ef26d-7ddf-4c11-bf84-2aec79c6e4a6" } }, "stale_context"],
    ["stale strategy", { strategyRef: { strategy_id: "STRATEGY-DEMO-PRODUCTION", strategy_version_id: "c62ef26d-7ddf-4c11-bf84-2aec79c6e4a6" } }, "invalid_strategy"],
    ["unregistered skill version", { skillRef: { id: "change-production-priority", version: 2 } }, "invalid_skill"],
  ])("blocks %s and preserves the ledger", async (_name, overrides, reason) => {
    // Break caught: malformed, stale, or model-injected policy input could become an action proposal.
    const { createActionProposal } = await import("./policy");
    const supplied = proposalInput(overrides);
    const before = JSON.stringify(supplied.state);

    expect(createActionProposal(supplied, testDigest)).toEqual({ status: "blocked", reason, mutationCount: 0 });
    expect(JSON.stringify(supplied.state)).toBe(before);
  });

  it("never turns apply mode or an approval-shaped extra into apply authority", async () => {
    // Break caught: a placeholder boolean or mode switch could bypass Task 8's exact human approval lifecycle.
    const { createActionProposal, previewPriorityShadow } = await import("./policy");
    const apply = createActionProposal(proposalInput({ mode: "apply" }), testDigest);
    const proposed = createActionProposal(proposalInput(), testDigest);
    if (proposed.status !== "proposed") throw new Error(`unexpected status: ${proposed.status}`);

    expect(apply).toEqual({ status: "blocked", reason: "approval_required", mutationCount: 0 });
    expect(previewPriorityShadow({
      state: createInitialCompanyState(seed),
      intent: proposed.intent,
      mode: "shadow",
      approved: true,
    })).toEqual({ status: "blocked", reason: "invalid_input", mutationCount: 0 });
  });
});

function createProposalForCanonicalTest(policy: typeof import("./policy")) {
  return policy.createActionProposal(proposalInput(), testDigest);
}
