import type { StrategyRef, StrategyVersion, TaskPacket } from "../agentic/types";

export const RUNTIME_SCHEMA_VERSION = 1 as const;
export const ACTOR_IDS = ["sales-demo", "production-demo", "management-demo"] as const;
export const ACTOR_ROLES = ["sales", "production", "management"] as const;
export const OBJECT_KINDS = [
  "customer",
  "sales_opportunity",
  "quote",
  "sales_order",
  "inventory",
  "production_plan",
  "inspection",
  "shipment",
] as const;
export const EXECUTION_MODES = ["read_only", "shadow", "apply"] as const;
export const RUNTIME_ERROR_CODES = [
  "unavailable",
  "invalid_input",
  "unauthorized_role",
  "stale_context",
  "approval_required",
  "stopped",
  "persistence_failed",
  "verification_required",
  "ai_failed",
  "conflict",
  "adapter_unproven",
] as const;

export type ActorId = (typeof ACTOR_IDS)[number];
export type ActorRole = (typeof ACTOR_ROLES)[number];
export type ObjectKind = (typeof OBJECT_KINDS)[number];
export type ExecutionMode = (typeof EXECUTION_MODES)[number];
export type RuntimeErrorCode = (typeof RUNTIME_ERROR_CODES)[number];

export interface VersionedObject {
  id: string;
  version: number;
}

export interface Customer extends VersionedObject {
  name: string;
}

export interface SalesOpportunity extends VersionedObject {
  customerId: string;
  materialId: string;
  requestedKg: number;
  status: "qualified" | "closed";
}

export interface Quote extends VersionedObject {
  opportunityId: string;
  quantityKg: number;
  status: "draft" | "approved";
}

export interface SalesOrder extends VersionedObject {
  customerId: string;
  materialId: string;
  quantityKg: number;
  status: "confirmed" | "in_production" | "completed";
}

export interface InventoryItem extends VersionedObject {
  materialId: string;
  availableKg: number;
  warehouseId: string;
}

export interface ProductionPlan extends VersionedObject {
  orderId: string;
  productionGroupId: string;
  priority: number;
  status: "queued" | "running" | "completed";
  qualityHold: boolean;
  materialId: string;
  requiredKg: number;
}

export interface Inspection extends VersionedObject {
  orderId: string;
  status: "pending" | "passed" | "failed";
}

export interface Shipment extends VersionedObject {
  orderId: string;
  status: "not_ready" | "ready" | "shipped";
  packagingStatus: "unchecked" | "ready";
}

export interface ObjectVersionRef {
  kind: ObjectKind;
  id: string;
  version: number;
}

export interface SkillRef {
  id: string;
  version: number;
}

export interface SkillDescriptor extends SkillRef {
  inputSchemaVersion: number;
  outputSchemaVersion: number;
  requiredCapabilities: string[];
  allowedConnectorIds: string[];
  policyVersion: string;
  reviewState: "approved";
}

export interface RuntimeStrategyVersion extends StrategyVersion {
  parent_version_id: string | null;
  execution_criteria: string[];
  constraints: string[];
  created_by: ActorId;
  created_at: string;
  origin: "seed" | "management";
  content_hash: string;
}

export interface ActionIntent {
  readonly id: string;
  readonly revision: number;
  readonly workboardTaskId: string;
  readonly packetTaskId: string;
  readonly epoch: string;
  readonly targetPlanId: string;
  readonly fromPriority: number;
  readonly toPriority: number;
  readonly readSet: readonly ObjectVersionRef[];
  readonly strategyRef: StrategyRef;
  readonly skillRef: SkillRef;
  readonly policyVersion: string;
  readonly evidenceRefs: readonly string[];
  readonly proposalDigest: string;
  readonly requesterActorId: ActorId;
  readonly createdAt: string;
}

export interface Approval {
  id: string;
  intentId: string;
  intentRevision: number;
  proposalDigest: string;
  epoch: string;
  readSetDigest: string;
  policyVersion: string;
  skillRef: SkillRef;
  strategyRef: StrategyRef;
  requesterActorId: ActorId;
  approverActorId: ActorId;
  decision: "approved" | "rejected" | "revoked";
  decidedAt: string;
  expiresAt: string;
  consumedByExecutionId: string | null;
}

export interface Execution {
  id: string;
  intentId: string;
  approvalId: string | null;
  idempotencyKey: string;
  epoch: string;
  mode: ExecutionMode;
  state: "prepared" | "applied_pending_readback" | "verified" | "failed_before_apply" | "verification_required";
  before: { priority: number; version: number };
  expectedAfter: { priority: number; version: number };
  attempt: number;
  startedAt: string;
}

export interface ReadbackEvidence {
  executionId: string;
  targetPlanId: string;
  epoch: string;
  expectedPriority: number;
  expectedVersion: number;
  observedPriority: number;
  observedVersion: number;
  readAt: string;
  matches: boolean;
}

export interface AssessmentEvidence {
  id: string;
  epoch: string;
  packetTaskId: string;
  readSet: ObjectVersionRef[];
  baselineReadSet: ObjectVersionRef[];
  additionalReadSet: ObjectVersionRef[];
  requiredChecks: Array<"inspection" | "packaging">;
  usedAssetRef: { assetId: string; version: number } | null;
  reuse: {
    status: "baseline" | "selected" | "no_candidate" | "needs_review";
    code: string | null;
    lineageStatus: string | null;
    lineageRefs: Array<{ assetId: string; version: number }>;
    candidateIds: string[];
  };
  finding: "ready" | "needs_review";
  reasons: string[];
  mutationCount: 0;
  observedAt: string;
}

export interface BusinessOutcome {
  packetTaskId: string;
  status: "unobserved" | "observed_simulated";
  recordedByActorId: ActorId | null;
  evidenceRefs: string[];
  observedAt: string | null;
}

export interface RuntimeTaskRecord {
  workboardTaskId: string;
  packetTaskId: string;
  epoch: string;
  packet: TaskPacket;
  status: "pending" | "in_progress" | "done" | "verification_required";
  currentProposal: { intentId: string; revision: number; proposalDigest: string } | null;
  currentApprovalId: string | null;
  executionId: string | null;
  businessOutcome: BusinessOutcome;
}

export interface LearningAsset extends VersionedObject {
  authorActorId: ActorId;
  sourceTaskId: string;
  sourceEvidenceRefs: string[];
  correctionRef: string | null;
  content: string;
  applicability: string[];
  requiredChecks: string[];
  allowedAudiences: ActorRole[];
  reviewState: "private" | "shared" | "withdrawn";
  consent: { version: number; decidedAt: string; audiences: ActorRole[] };
  provenance: string;
}

export interface StrategyReviewEvidenceSnapshot {
  kind: string;
  id: string;
  version: number;
  contentHash: string;
  visibilityScope: string;
}

export interface StrategyReview {
  id: string;
  epoch: string;
  baseStrategyRef: StrategyRef;
  evidenceSnapshot: StrategyReviewEvidenceSnapshot[];
  uncertainties: string[];
  proposedChanges: {
    objective: string;
    review_question: string;
    execution_criteria: string[];
    constraints: string[];
  };
  reviewerActorId: ActorId;
  reviewedAt: string;
  decision: "maintain" | "create_new_version";
  resultingStrategyRef: StrategyRef | null;
}

export interface StrategyAdoption {
  readonly id: string;
  readonly epoch: string;
  readonly reviewId: string;
  readonly fromRef: StrategyRef;
  readonly toRef: StrategyRef;
  readonly actorId: ActorId;
  readonly adoptedAt: string;
}

export interface CompanyState {
  formatVersion: 1;
  revision: number;
  currentEpoch: string;
  stopped: boolean;
  bootstrap: boolean;
  customers: Customer[];
  salesOpportunities: SalesOpportunity[];
  quotes: Quote[];
  salesOrders: SalesOrder[];
  inventory: InventoryItem[];
  productionPlans: ProductionPlan[];
  inspections: Inspection[];
  shipments: Shipment[];
  skills: SkillDescriptor[];
  strategyVersions: RuntimeStrategyVersion[];
  activeStrategyRef: StrategyRef;
  bootstrapReadSet: ObjectVersionRef[];
}

export interface RuntimeRequestEnvelope<TPayload = unknown> {
  schemaVersion: 1;
  requestId: string;
  epoch: string;
  actorSessionRevision: number;
  payload: TPayload;
}

export type RuntimeResponseEnvelope<TPayload = unknown> =
  | { schemaVersion: 1; requestId: string; epoch: string; actorSessionRevision: number; ok: true; payload: TPayload }
  | { schemaVersion: 1; requestId: string; epoch: string; actorSessionRevision: number; ok: false; error: { code: RuntimeErrorCode; message: string } };

export type RuntimeTaskPacket = TaskPacket;
