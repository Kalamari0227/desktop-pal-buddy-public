import { describe, expect, it } from "vitest";
import type { ExperienceDraft } from "./experience";
import { createLearningAssetStore } from "./learning";

const draft: ExperienceDraft = {
  id: "experience-draft-1",
  version: 1,
  authorActorId: "sales-demo",
  workItem: {
    workboardTaskId: "9e650d6d-9e9f-4a09-b041-e345d16620a8",
    packetTaskId: "27862353-b4b6-43d3-bec2-2e4afe57dc06",
  },
  sourceEvidenceIds: ["evidence:production_plan:PP-DEMO-1001:v2"],
  asset: { id: "PP-DEMO-1001", version: 2 },
  correction: "검사와 출하 준비를 먼저 확인합니다.",
  applicability: ["queued production plan"],
  counterexample: "검사 불합격",
  outcome: { state: "unobserved" },
  visibility: "private",
  reviewRequest: "requested",
  createdAt: "2026-09-19T01:00:00.000Z",
};

function createStore() {
  let sequence = 0;
  return createLearningAssetStore({
    drafts: [draft],
    now: () => "2026-09-19T02:00:00.000Z",
    nextId: () => {
      sequence += 1;
      return `learning-${sequence}`;
    },
  });
}

function preview(store: ReturnType<typeof createStore>, overrides: Record<string, unknown> = {}) {
  return store.preview({
    actorId: "sales-demo",
    draftId: draft.id,
    exactPublishableSentence: "검사와 출하 준비를 먼저 확인한 뒤 납기를 검토합니다.",
    applicability: ["queued production plan"],
    targetDepartments: ["production"],
    includeManagementStrategyReview: true,
    ...overrides,
  });
}

describe("learning asset consent store", () => {
  it("previews the exact sentence, source chain, applicability, departments, and management review scope", () => {
    const result = preview(createStore());

    expect(result).toMatchObject({
      ok: true,
      preview: {
        authorActorId: "sales-demo",
        sourceDraft: { id: draft.id, version: 1 },
        exactPublishableSentence: "검사와 출하 준비를 먼저 확인한 뒤 납기를 검토합니다.",
        sourceEvidenceIds: draft.sourceEvidenceIds,
        applicability: ["queued production plan"],
        targetDepartments: ["production"],
        includeManagementStrategyReview: true,
      },
    });
  });

  it("publishes only after the author explicitly consents to the exact preview", () => {
    const store = createStore();
    const result = preview(store);
    if (!result.ok) throw new Error(result.code);

    expect(store.publish({ actorId: "production-demo", preview: result.preview, consentGranted: true }))
      .toEqual({ ok: false, code: "author_required" });
    expect(store.publish({ actorId: "sales-demo", preview: result.preview, consentGranted: false }))
      .toEqual({ ok: false, code: "consent_required" });

    const published = store.publish({ actorId: "sales-demo", preview: result.preview, consentGranted: true });
    expect(published).toMatchObject({
      ok: true,
      asset: {
        id: "learning-1",
        version: 1,
        authorActorId: "sales-demo",
        sourceDraft: { id: draft.id, version: 1 },
        consent: { decidedAt: "2026-09-19T02:00:00.000Z" },
      },
    });
  });

  it("filters active bodies by department and management-review consent without leaking private drafts", () => {
    const store = createStore();
    const result = preview(store);
    if (!result.ok) throw new Error(result.code);
    store.publish({ actorId: "sales-demo", preview: result.preview, consentGranted: true });

    expect(store.readForRole("production-demo")).toEqual([
      expect.objectContaining({ exactPublishableSentence: result.preview.exactPublishableSentence }),
    ]);
    expect(store.readForRole("sales-demo")).toEqual([]);
    expect(store.search("sales-demo", "검사")).toEqual([]);
    expect(store.recommend("management-demo")).toEqual([]);
    expect(store.aiContext("production-demo")).toEqual([
      expect.objectContaining({ exactPublishableSentence: result.preview.exactPublishableSentence }),
    ]);
    expect(store.managementStrategyReview("management-demo")).toEqual([
      expect.objectContaining({ exactPublishableSentence: result.preview.exactPublishableSentence }),
    ]);
    expect(JSON.stringify(store.projectForActor("production-demo"))).not.toContain(draft.counterexample);
  });

  it("does not expose a persisted private asset through any role projection", () => {
    const publishedStore = createStore();
    const result = preview(publishedStore);
    if (!result.ok) throw new Error(result.code);
    const published = publishedStore.publish({ actorId: "sales-demo", preview: result.preview, consentGranted: true });
    if (!published.ok) throw new Error(published.code);
    const store = createLearningAssetStore({
      drafts: [draft],
      assets: [{ ...published.asset, sharingState: "private" }],
      now: () => "2026-09-19T02:00:00.000Z",
    });
    const privateBody = published.asset.exactPublishableSentence;

    expect(store.readForRole("production-demo")).toEqual([]);
    expect(store.search("production-demo", "검사")).toEqual([]);
    expect(store.recommend("production-demo")).toEqual([]);
    expect(store.aiContext("production-demo")).toEqual([]);
    expect(store.managementStrategyReview("management-demo")).toEqual([]);
    expect(JSON.stringify(store.projectForActor("production-demo"))).not.toContain(privateBody);
    expect(JSON.stringify(store.projectForActor("management-demo"))).not.toContain(privateBody);
  });

  it("creates an immutable new version and requires a fresh preview and consent", () => {
    const store = createStore();
    const firstPreview = preview(store);
    if (!firstPreview.ok) throw new Error(firstPreview.code);
    const first = store.publish({ actorId: "sales-demo", preview: firstPreview.preview, consentGranted: true });
    if (!first.ok) throw new Error(first.code);
    const before = structuredClone(store.snapshot().assets[0]);

    expect(store.publish({
      actorId: "sales-demo",
      preview: { ...firstPreview.preview, assetId: first.asset.id },
      consentGranted: true,
    })).toEqual({ ok: false, code: "preview_required" });

    const secondPreview = preview(store, {
      assetId: first.asset.id,
      exactPublishableSentence: "검사 완료와 출하 준비를 모두 확인한 뒤 납기를 검토합니다.",
    });
    if (!secondPreview.ok) throw new Error(secondPreview.code);
    const stalePreview = preview(store, {
      assetId: first.asset.id,
      exactPublishableSentence: "동시에 작성된 오래된 수정입니다.",
    });
    if (!stalePreview.ok) throw new Error(stalePreview.code);
    const withoutConsent = store.publish({ actorId: "sales-demo", preview: secondPreview.preview, consentGranted: false });
    expect(withoutConsent).toEqual({ ok: false, code: "consent_required" });
    const second = store.publish({ actorId: "sales-demo", preview: secondPreview.preview, consentGranted: true });

    expect(second).toMatchObject({ ok: true, asset: { id: first.asset.id, version: 2 } });
    expect(store.publish({ actorId: "sales-demo", preview: stalePreview.preview, consentGranted: true }))
      .toEqual({ ok: false, code: "version_conflict" });
    expect(store.snapshot().assets[0]).toEqual(before);
    expect(store.readForRole("production-demo")).toEqual([
      expect.objectContaining({ id: first.asset.id, version: 2 }),
    ]);
  });

  it("withdraws only for the author and excludes the version everywhere while preserving body-free provenance", () => {
    const store = createStore();
    const result = preview(store);
    if (!result.ok) throw new Error(result.code);
    const published = store.publish({ actorId: "sales-demo", preview: result.preview, consentGranted: true });
    if (!published.ok) throw new Error(published.code);
    store.addPendingSuggestion({ id: "suggestion-1", assetId: published.asset.id, assetVersion: 1 });

    expect(store.withdraw({ actorId: "production-demo", assetId: published.asset.id, version: 1 }))
      .toEqual({ ok: false, code: "author_required" });
    expect(store.withdraw({ actorId: "sales-demo", assetId: published.asset.id, version: 1 }))
      .toMatchObject({ ok: true, withdrawal: { assetId: published.asset.id, version: 1 } });

    expect(store.readForRole("production-demo")).toEqual([]);
    expect(store.search("production-demo", "검사")).toEqual([]);
    expect(store.recommend("production-demo")).toEqual([]);
    expect(store.aiContext("production-demo")).toEqual([]);
    expect(store.managementStrategyReview("management-demo")).toEqual([]);
    expect(store.snapshot().suggestions).toEqual([
      { id: "suggestion-1", assetId: published.asset.id, assetVersion: 1, state: "stale" },
    ]);
    const provenance = store.provenanceForAuthor("sales-demo");
    expect(provenance).toEqual([expect.objectContaining({ id: published.asset.id, version: 1, withdrawn: true })]);
    expect(JSON.stringify(provenance)).not.toContain(result.preview.exactPublishableSentence);
  });
});
