import { describe, expect, it } from "vitest";
import { createProductionPriorityChangePacket } from "./packet";
import {
  mergeWorkboardTaskViews,
  projectCompanyRuntimeSnapshot,
  projectLegacyTask,
} from "./projection";

const sharedId = "9e650d6d-9e9f-4a09-b041-e345d16620a8";
const packetId = "27862353-b4b6-43d3-bec2-2e4afe57dc06";
const epoch = "f7091d6f-e310-46f5-ae2f-a761f136f36a";
const strategyVersionId = "f6846f3d-1aa0-487a-88a1-c383ba9076ea";
const activeStrategyVersionId = "194d29ef-806c-4e11-8ca8-485d75812fed";
const intentId = "4cda2ea4-8f68-410b-ac7d-d627a3db3680";
const approvalId = "f5ef65ee-0a15-4756-b10f-c8ba90b7174c";
const executionId = "5d36a948-e977-4bf4-93d8-08c33459c42b";
const projectionNow = "2026-09-26T03:00:00.000Z";
const noProposal: { intentId: string; revision: number; proposalDigest: string } | null = null;
const noApproval: string | null = null;
const noExecution: string | null = null;
const consumedExecution: string | null = executionId;

function runtimeSnapshot() {
  return {
    currentEpoch: epoch,
    records: {
      tasks: [{
        workboardTaskId: sharedId,
        packetTaskId: packetId,
        epoch,
        packet: createProductionPriorityChangePacket({
          packetTaskId: packetId,
          createdAt: "2026-09-19T00:00:00.000Z",
          requesterActorId: "sales-demo",
          strategyRef: {
            strategy_id: "STRATEGY-DEMO-PRODUCTION",
            strategy_version_id: strategyVersionId,
          },
        }),
        status: "pending",
        currentProposal: noProposal,
        currentApprovalId: noApproval,
        executionId: noExecution,
        businessOutcome: {
          packetTaskId: packetId,
          status: "unobserved",
          recordedByActorId: null,
          evidenceRefs: [],
          observedAt: null,
        },
      }],
    },
  };
}

function storedFactsSnapshot(overrides: Record<string, unknown> = {}) {
  return {
    ...runtimeSnapshot(),
    current: {
      activeStrategyRef: { strategy_id: "STRATEGY-DEMO-PRODUCTION", strategy_version_id: activeStrategyVersionId },
      strategyVersions: [
        {
          strategy_id: "STRATEGY-DEMO-PRODUCTION",
          strategy_version_id: strategyVersionId,
          version: 1,
          objective: "v1 objective",
          review_question: "v1 question",
        },
        {
          strategy_id: "STRATEGY-DEMO-PRODUCTION",
          strategy_version_id: activeStrategyVersionId,
          version: 2,
          objective: "v2 objective",
          review_question: "v2 question",
        },
      ],
    },
    records: {
      tasks: [{
        ...runtimeSnapshot().records.tasks[0],
        currentProposal: { intentId, revision: 1, proposalDigest: "a".repeat(64) },
        currentApprovalId: approvalId,
        executionId,
      }],
      actionIntents: [{
        id: intentId,
        revision: 1,
        workboardTaskId: sharedId,
        packetTaskId: packetId,
        epoch,
        targetPlanId: "PP-DEMO-1001",
        fromPriority: 5,
        toPriority: 1,
        readSet: [{ kind: "production_plan", id: "PP-DEMO-1001", version: 1 }],
        strategyRef: { strategy_id: "STRATEGY-DEMO-PRODUCTION", strategy_version_id: strategyVersionId },
        skillRef: { id: "change-production-priority", version: 1 },
        policyVersion: "company-policy-v1",
        evidenceRefs: [],
        proposalDigest: "a".repeat(64),
        requesterActorId: "sales-demo",
        createdAt: "2026-09-26T02:00:00.000Z",
      }],
      approvals: [{
        id: approvalId,
        intentId,
        intentRevision: 1,
        proposalDigest: "a".repeat(64),
        epoch,
        readSetDigest: "b".repeat(64),
        policyVersion: "company-policy-v1",
        skillRef: { id: "change-production-priority", version: 1 },
        strategyRef: { strategy_id: "STRATEGY-DEMO-PRODUCTION", strategy_version_id: strategyVersionId },
        requesterActorId: "sales-demo",
        approverActorId: "production-demo",
        decision: "approved",
        decidedAt: "2026-09-26T02:05:00.000Z",
        expiresAt: "2026-09-26T02:20:00.000Z",
        consumedByExecutionId: consumedExecution,
      }],
      executions: [{
        id: executionId,
        intentId,
        approvalId,
        idempotencyKey: `${epoch}:${intentId}:${"a".repeat(64)}`,
        epoch,
        mode: "apply",
        state: "verified",
        before: { priority: 5, version: 1 },
        expectedAfter: { priority: 1, version: 2 },
        attempt: 1,
        startedAt: "2026-09-26T02:06:00.000Z",
      }],
      readbackEvidence: [{
        executionId,
        targetPlanId: "PP-DEMO-1001",
        epoch,
        expectedPriority: 1,
        expectedVersion: 2,
        observedPriority: 1,
        observedVersion: 2,
        readAt: "2026-09-26T02:06:02.000Z",
        matches: true,
      }],
      ...((overrides.records as Record<string, unknown> | undefined) ?? {}),
    },
  };
}

function projectedCard(projection: ReturnType<typeof projectCompanyRuntimeSnapshot>): unknown {
  const task = projection.state === "ready" ? projection.tasks[0] : undefined;
  return task && "card" in task ? task.card : undefined;
}

function cardField(card: unknown, key: string): unknown {
  return typeof card === "object" && card !== null && key in card ? Reflect.get(card, key) : undefined;
}

describe("company runtime Workboard projection", () => {
  it("keeps identical source UUIDs distinct across origins and preserves the pinned packet strategy", () => {
    // Given
    const legacy = projectLegacyTask({
      id: sharedId,
      title: "Legacy task",
      description: null,
      source: "gateway",
      source_id: packetId,
      severity: "medium",
      customer: null,
      category: "delivery",
      status: "pending",
      created_at: "2026-09-18T00:00:00.000Z",
    });

    // When
    const runtime = projectCompanyRuntimeSnapshot(runtimeSnapshot());
    const merged = mergeWorkboardTaskViews([legacy], runtime.tasks);

    // Then
    expect(merged.map((task) => task.viewKey)).toEqual([
      `legacy:${sharedId}`,
      `company_runtime:${sharedId}`,
    ]);
    expect(new Set(merged.map((task) => task.viewKey)).size).toBe(2);
    expect(runtime.tasks[0]).toMatchObject({
      origin: "company_runtime",
      sourceId: sharedId,
      packetTaskId: packetId,
      strategyRef: {
        strategy_id: "STRATEGY-DEMO-PRODUCTION",
        strategy_version_id: strategyVersionId,
      },
    });
  });

  it("fails closed when the runtime snapshot cannot prove authoritative task ownership", () => {
    // Given
    const malformed = { currentEpoch: epoch, records: { tasks: [{ workboardTaskId: sharedId }] } };

    // When
    const projection = projectCompanyRuntimeSnapshot(malformed);

    // Then
    expect(projection).toEqual({ state: "unavailable", tasks: [], reason: "invalid_runtime_snapshot" });
  });

  it("rejects a task record from a stale epoch instead of projecting it as current", () => {
    // Given
    const stale = runtimeSnapshot();
    stale.records.tasks[0].epoch = "77bc5acd-bcde-4e91-92d5-08c76be97d3d";

    // When
    const projection = projectCompanyRuntimeSnapshot(stale);

    // Then
    expect(projection).toEqual({ state: "unavailable", tasks: [], reason: "invalid_runtime_snapshot" });
  });

  it("projects the stored task strategy and consumed verified execution even when v2 is active", () => {
    // Given: the task packet is pinned to v1 while the current catalog points at v2.
    const snapshot = storedFactsSnapshot();

    // When: the persisted runtime facts are projected into a company-work card.
    const projection = projectCompanyRuntimeSnapshot(snapshot, { now: projectionNow });

    // Then: the card uses exact stored tuples and does not report approval pending.
    expect(projection.state).toBe("ready");
    const card = projectedCard(projection);
    expect(card).toMatchObject({
      pinnedStrategy: { strategy_version_id: strategyVersionId, version: 1, objective: "v1 objective" },
      approval: { state: "consumed", approvalId },
      execution: { state: "verified", executionId },
      readback: { state: "verified", executionId, observedVersion: 2 },
      businessOutcome: { state: "unknown" },
    });
    expect(cardField(cardField(card, "approval"), "state")).not.toBe("pending");
  });

  it.each([
    ["missing strategy ref", (snapshot: ReturnType<typeof storedFactsSnapshot>) => {
      snapshot.records.tasks[0].packet.strategy_ref = undefined;
    }],
    ["invalid strategy ref", (snapshot: ReturnType<typeof storedFactsSnapshot>) => {
      snapshot.records.tasks[0].packet.strategy_ref = { strategy_id: "STRATEGY-DEMO-PRODUCTION", strategy_version_id: "not-stored" };
    }],
    ["cross-task approval", (snapshot: ReturnType<typeof storedFactsSnapshot>) => {
      snapshot.records.actionIntents[0].workboardTaskId = "d9dc4250-556d-4ce3-b274-e95bc4357591";
    }],
    ["expired approval", (snapshot: ReturnType<typeof storedFactsSnapshot>) => {
      snapshot.records.approvals[0].expiresAt = "2026-09-26T02:20:00.000Z";
      snapshot.records.approvals[0].consumedByExecutionId = noApproval;
    }],
    ["unverified readback", (snapshot: ReturnType<typeof storedFactsSnapshot>) => {
      snapshot.records.readbackEvidence[0].matches = false;
    }],
  ] as const)("fails closed for %s", (_label, mutate) => {
    // Given: one persisted reference or verification fact is unsafe.
    const snapshot = storedFactsSnapshot();
    mutate(snapshot);

    // When: the same runtime facts are projected.
    const projection = projectCompanyRuntimeSnapshot(snapshot, { now: projectionNow });

    // Then: the card requests review and never fills from a legacy catalog.
    const card = projectedCard(projection);
    expect(cardField(card, "reviewRequired")).toBe(true);
    if (_label === "missing strategy ref" || _label === "invalid strategy ref") {
      expect(cardField(cardField(card, "pinnedStrategy"), "status")).toBe("review_required");
    }
    if (_label === "cross-task approval") expect(cardField(cardField(card, "approval"), "state")).toBe("review_required");
    if (_label === "expired approval") {
      expect(cardField(cardField(card, "pinnedStrategy"), "status")).toBe("pinned");
      expect(cardField(cardField(card, "approval"), "state")).toBe("expired");
    }
    if (_label === "unverified readback") {
      expect(cardField(cardField(card, "pinnedStrategy"), "status")).toBe("pinned");
      expect(cardField(cardField(card, "readback"), "state")).toBe("verification_required");
    }
  });

  it("does not require approval for a read-only readiness packet", () => {
    // Given: a read-only packet with no proposal or approval facts.
    const snapshot = storedFactsSnapshot();
    snapshot.records.tasks[0].packet = {
      ...snapshot.records.tasks[0].packet,
      task_type: "production_readiness_review",
      required_approval: false,
      strategy_ref: { strategy_id: "STRATEGY-DEMO-PRODUCTION", strategy_version_id: strategyVersionId },
    };
    const readOnlySnapshot = {
      ...snapshot,
      records: {
        ...snapshot.records,
        tasks: [{ ...snapshot.records.tasks[0], currentProposal: noProposal, currentApprovalId: noApproval, executionId: noExecution }],
        actionIntents: [],
        approvals: [],
        executions: [],
        readbackEvidence: [],
      },
    };

    // When
    const projection = projectCompanyRuntimeSnapshot(readOnlySnapshot, { now: projectionNow });

    // Then
    const card = projectedCard(projection);
    expect(cardField(card, "approval")).toEqual({ state: "not_required" });
  });
});
