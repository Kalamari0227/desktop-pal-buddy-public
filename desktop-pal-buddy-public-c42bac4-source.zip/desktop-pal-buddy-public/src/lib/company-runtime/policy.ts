import { z } from "zod";
import { assessOrderPriority, type PriorityAssessment } from "./assessment";
import type { ActionIntent, CompanyState, ObjectVersionRef } from "./contracts";
import { REGISTERED_SKILLS } from "./fixtures";
import { actionIntentSchema, companyStateSchema, executionModeSchema, skillRefSchema } from "./schemas";
import {
  canonicalizeActionIntentDigestInput,
  canonicalizeReadSet,
  finalizeActionIntent,
  type ActionIntentDigestInput,
  type CanonicalDigest,
} from "./transitions";

export interface PriorityShadow {
  diff: {
    priority: { before: number; after: number };
    version: { before: number; after: number };
  };
  beforeOrder: string[];
  afterOrder: string[];
  affectedPlanIds: string[];
  mutationCount: 0;
}

export type ActionPolicyDecision =
  | { status: "proposed"; intent: ActionIntent; shadow: PriorityShadow; mutationCount: 0 }
  | { status: "already_satisfied"; reason: "already_satisfied"; mutationCount: 0 }
  | { status: "blocked"; reason: string; mutationCount: 0 };

const text = z.string().trim().min(1);
const uuid = z.string().uuid();
const timestamp = z.string().datetime();
const strategyRefSchema = z.object({ strategy_id: text, strategy_version_id: uuid }).strict();
const trustedProposalSchema = z.object({
  intentId: uuid,
  workboardTaskId: uuid,
  packetTaskId: uuid,
  epoch: uuid,
  requesterActorId: z.literal("sales-demo"),
  createdAt: timestamp,
}).strict();
const proposalInputSchema = z.object({
  mode: executionModeSchema,
  state: z.unknown(),
  orderId: text,
  targetPlanId: text,
  toPriority: z.number().int().min(1).max(9),
  strategyRef: strategyRefSchema,
  skillRef: skillRefSchema,
  policyVersion: text,
  trusted: trustedProposalSchema,
}).strict();
const revisionInputSchema = z.object({
  state: z.unknown(),
  previousIntent: z.unknown(),
  toPriority: z.number().int().min(1).max(9),
  createdAt: timestamp,
}).strict();
const shadowInputSchema = z.object({
  state: z.unknown(),
  intent: z.unknown(),
  mode: executionModeSchema,
}).strict();

function blocked(reason: string): ActionPolicyDecision {
  return { status: "blocked", reason, mutationCount: 0 };
}

function sameRef(
  left: { id: string; version: number },
  right: { id: string; version: number },
): boolean {
  return left.id === right.id && left.version === right.version;
}

function validatePolicyBindings(
  state: CompanyState,
  strategyRef: { strategy_id: string; strategy_version_id: string },
  skillRef: { id: string; version: number },
  policyVersion: string,
  requireActiveStrategy: boolean,
): string | undefined {
  const storedStrategy = state.strategyVersions.some((item) =>
    item.strategy_id === strategyRef.strategy_id && item.strategy_version_id === strategyRef.strategy_version_id);
  const activeStrategy = state.activeStrategyRef.strategy_id === strategyRef.strategy_id
    && state.activeStrategyRef.strategy_version_id === strategyRef.strategy_version_id;
  if (!storedStrategy || (requireActiveStrategy && !activeStrategy)) {
    return "invalid_strategy";
  }
  const registered = REGISTERED_SKILLS.find((item) => sameRef(item, skillRef));
  const stored = state.skills.find((item) => sameRef(item, skillRef));
  if (!registered || !stored || skillRef.id !== "change-production-priority") return "invalid_skill";
  if (registered.policyVersion !== policyVersion || stored.policyVersion !== policyVersion) return "invalid_policy";
  if (JSON.stringify(stored) !== JSON.stringify(registered)) return "invalid_skill";
  return undefined;
}

function assessmentReadSet(assessment: PriorityAssessment): ObjectVersionRef[] {
  return canonicalizeReadSet(assessment.sources.map(({ kind, id, version }) => ({ kind, id, version })));
}

function shadowFromAssessment(
  state: CompanyState,
  targetPlanId: string,
  toPriority: number,
  assessment: PriorityAssessment,
): PriorityShadow | undefined {
  const target = state.productionPlans.find((item) => item.id === targetPlanId);
  if (!target || assessment.status !== "proposed" || !assessment.beforeOrder || !assessment.proposedOrder || !assessment.displacedPlanIds) return undefined;
  return {
    diff: {
      priority: { before: target.priority, after: toPriority },
      version: { before: target.version, after: target.version },
    },
    beforeOrder: [...assessment.beforeOrder],
    afterOrder: [...assessment.proposedOrder],
    affectedPlanIds: [...assessment.displacedPlanIds],
    mutationCount: 0,
  };
}

interface BoundProposalInput {
  state: CompanyState;
  orderId: string;
  targetPlanId: string;
  toPriority: number;
  strategyRef: { strategy_id: string; strategy_version_id: string };
  skillRef: { id: string; version: number };
  policyVersion: string;
  trusted: {
    intentId: string;
    workboardTaskId: string;
    packetTaskId: string;
    epoch: string;
    requesterActorId: "sales-demo";
    createdAt: string;
  };
  revision: number;
  requireActiveStrategy: boolean;
}

function createBoundProposal(input: BoundProposalInput, digestCanonical: CanonicalDigest): ActionPolicyDecision {
  const bindingFailure = validatePolicyBindings(
    input.state,
    input.strategyRef,
    input.skillRef,
    input.policyVersion,
    input.requireActiveStrategy,
  );
  if (bindingFailure) return blocked(bindingFailure);
  const assessment = assessOrderPriority({
    state: input.state,
    orderId: input.orderId,
    planId: input.targetPlanId,
    proposedPriority: input.toPriority,
  });
  if (assessment.status === "blocked") return blocked(assessment.reason ?? "assessment_blocked");
  if (assessment.status === "already_satisfied") {
    return { status: "already_satisfied", reason: "already_satisfied", mutationCount: 0 };
  }
  const target = input.state.productionPlans.find((item) => item.id === input.targetPlanId);
  const shadow = shadowFromAssessment(input.state, input.targetPlanId, input.toPriority, assessment);
  if (!target || !shadow) return blocked("invalid_assessment");
  const digestInput: ActionIntentDigestInput = {
    id: input.trusted.intentId,
    revision: input.revision,
    workboardTaskId: input.trusted.workboardTaskId,
    packetTaskId: input.trusted.packetTaskId,
    epoch: input.trusted.epoch,
    targetPlanId: input.targetPlanId,
    fromPriority: target.priority,
    toPriority: input.toPriority,
    readSet: assessmentReadSet(assessment),
    strategyRef: input.strategyRef,
    skillRef: input.skillRef,
    policyVersion: input.policyVersion,
    evidenceRefs: assessment.sources.map((source) => source.evidenceId).sort(),
    requesterActorId: input.trusted.requesterActorId,
    createdAt: input.trusted.createdAt,
  };
  try {
    return { status: "proposed", intent: finalizeActionIntent(digestInput, digestCanonical), shadow, mutationCount: 0 };
  } catch {
    return blocked("invalid_digest");
  }
}

export function createActionProposal(input: unknown, digestCanonical: CanonicalDigest): ActionPolicyDecision {
  const parsed = proposalInputSchema.safeParse(input);
  if (!parsed.success || typeof digestCanonical !== "function") return blocked("invalid_input");
  const parsedState = companyStateSchema.safeParse(parsed.data.state);
  if (!parsedState.success) return blocked("invalid_state");
  if (parsed.data.trusted.epoch !== parsedState.data.currentEpoch) return blocked("stale_context");

  const assessment = assessOrderPriority({
    state: parsedState.data,
    orderId: parsed.data.orderId,
    planId: parsed.data.targetPlanId,
    proposedPriority: parsed.data.toPriority,
  });
  if (assessment.status === "already_satisfied") {
    return { status: "already_satisfied", reason: "already_satisfied", mutationCount: 0 };
  }
  if (assessment.status === "blocked") return blocked(assessment.reason ?? "assessment_blocked");
  if (parsed.data.mode === "read_only") return blocked("read_only_change_not_allowed");
  if (parsed.data.mode === "apply") return blocked("approval_required");

  return createBoundProposal({
    ...parsed.data,
    state: parsedState.data,
    revision: 1,
    requireActiveStrategy: true,
  }, digestCanonical);
}

export function reviseActionProposal(input: unknown, digestCanonical: CanonicalDigest): ActionPolicyDecision {
  const parsed = revisionInputSchema.safeParse(input);
  if (!parsed.success || typeof digestCanonical !== "function") return blocked("invalid_input");
  const parsedState = companyStateSchema.safeParse(parsed.data.state);
  const previous = actionIntentSchema.safeParse(parsed.data.previousIntent);
  if (!parsedState.success) return blocked("invalid_state");
  if (!previous.success) return blocked("invalid_intent");
  if (previous.data.epoch !== parsedState.data.currentEpoch) return blocked("stale_context");
  if (previous.data.requesterActorId !== "sales-demo") return blocked("invalid_requester");
  try {
    if (digestCanonical(canonicalizeActionIntentDigestInput(previous.data)) !== previous.data.proposalDigest) {
      return blocked("invalid_digest");
    }
  } catch {
    return blocked("invalid_digest");
  }
  const target = parsedState.data.productionPlans.find((item) => item.id === previous.data.targetPlanId);
  if (!target) return blocked("missing_production_plan");
  return createBoundProposal({
    state: parsedState.data,
    orderId: target.orderId,
    targetPlanId: previous.data.targetPlanId,
    toPriority: parsed.data.toPriority,
    strategyRef: previous.data.strategyRef,
    skillRef: previous.data.skillRef,
    policyVersion: previous.data.policyVersion,
    trusted: {
      intentId: previous.data.id,
      workboardTaskId: previous.data.workboardTaskId,
      packetTaskId: previous.data.packetTaskId,
      epoch: previous.data.epoch,
      requesterActorId: previous.data.requesterActorId as "sales-demo",
      createdAt: parsed.data.createdAt,
    },
    revision: previous.data.revision + 1,
    requireActiveStrategy: false,
  }, digestCanonical);
}

export function previewPriorityShadow(input: unknown): ActionPolicyDecision {
  const parsed = shadowInputSchema.safeParse(input);
  if (!parsed.success) return blocked("invalid_input");
  const parsedState = companyStateSchema.safeParse(parsed.data.state);
  const intent = actionIntentSchema.safeParse(parsed.data.intent);
  if (!parsedState.success) return blocked("invalid_state");
  if (!intent.success) return blocked("invalid_intent");
  if (intent.data.epoch !== parsedState.data.currentEpoch) return blocked("stale_context");
  if (parsed.data.mode === "read_only") return blocked("read_only_change_not_allowed");
  if (parsed.data.mode === "apply") return blocked("approval_required");
  const bindingFailure = validatePolicyBindings(
    parsedState.data,
    intent.data.strategyRef,
    intent.data.skillRef,
    intent.data.policyVersion,
    false,
  );
  if (bindingFailure) return blocked(bindingFailure);
  const target = parsedState.data.productionPlans.find((item) => item.id === intent.data.targetPlanId);
  if (!target) return blocked("missing_production_plan");
  if (target.priority !== intent.data.fromPriority) return blocked("stale_state");
  const assessment = assessOrderPriority({
    state: parsedState.data,
    orderId: target.orderId,
    planId: target.id,
    proposedPriority: intent.data.toPriority,
  });
  if (assessment.status === "already_satisfied") return { status: "already_satisfied", reason: "already_satisfied", mutationCount: 0 };
  if (assessment.status === "blocked") return blocked(assessment.reason ?? "assessment_blocked");
  const readSet = assessmentReadSet(assessment);
  if (JSON.stringify(readSet) !== JSON.stringify(intent.data.readSet)) return blocked("stale_state");
  const evidenceRefs = assessment.sources.map((source) => source.evidenceId).sort();
  if (JSON.stringify(evidenceRefs) !== JSON.stringify([...intent.data.evidenceRefs].sort())) return blocked("invalid_evidence");
  const shadow = shadowFromAssessment(parsedState.data, target.id, intent.data.toPriority, assessment);
  if (!shadow) return blocked("invalid_assessment");
  return { status: "proposed", intent: intent.data, shadow, mutationCount: 0 };
}
