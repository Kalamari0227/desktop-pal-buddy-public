import { z } from "zod";
import { actorIdSchema } from "./schemas";

const text = z.string().trim().min(1);
const uuid = z.string().uuid();
const version = z.number().int().positive();

export type ExperienceWorkItem = {
  readonly workboardTaskId: string;
  readonly packetTaskId: string;
};

export type ExperienceAsset = {
  readonly id: string;
  readonly version: number;
};

export type ExperienceSource = {
  readonly evidenceId: string;
  readonly kind: "work_fact" | "readback";
  readonly workItem: ExperienceWorkItem;
  readonly asset: ExperienceAsset;
};

export type ExperienceOutcome =
  | { readonly state: "unobserved" }
  | { readonly state: "observed"; readonly observedAt: string };

export type ExperienceDraft = {
  readonly id: string;
  readonly version: 1;
  readonly authorActorId: "sales-demo" | "production-demo" | "management-demo";
  readonly workItem: ExperienceWorkItem;
  readonly sourceEvidenceIds: readonly string[];
  readonly asset: ExperienceAsset;
  readonly correction: string;
  readonly applicability: readonly string[];
  readonly counterexample: string;
  readonly outcome: ExperienceOutcome;
  readonly visibility: "private";
  readonly reviewRequest: "none" | "requested";
  readonly createdAt: string;
};

export type ExperienceDraftSaveResult =
  | { readonly ok: true; readonly draft: ExperienceDraft; readonly persistedCount: number }
  | {
    readonly ok: false;
    readonly code: "invalid_input" | "missing_source" | "invalid_asset" | "observed_outcome_requires_readback" | "observed_outcome_requires_matching_readback";
    readonly persistedCount: number;
  };

const workItemSchema = z.object({ workboardTaskId: uuid, packetTaskId: uuid }).strict();
const assetSchema = z.object({ id: text, version }).strict();
const sourceSchema = z.object({
  evidenceId: text,
  kind: z.enum(["work_fact", "readback"]),
  workItem: workItemSchema,
  asset: assetSchema,
}).strict();
const outcomeSchema = z.discriminatedUnion("state", [
  z.object({ state: z.literal("unobserved") }).strict(),
  z.object({ state: z.literal("observed"), observedAt: z.string().datetime() }).strict(),
]);
const saveInputSchema = z.object({
  authorActorId: actorIdSchema,
  workItem: workItemSchema,
  sourceEvidenceIds: z.array(text).min(1),
  asset: assetSchema,
  correction: text,
  applicability: z.array(text).min(1),
  counterexample: text,
  outcome: outcomeSchema,
  saveDecision: z.enum(["private", "shared_review"]),
}).strict();
export const experienceDraftSchema = z.object({
  id: text,
  version: z.literal(1),
  authorActorId: actorIdSchema,
  workItem: workItemSchema,
  sourceEvidenceIds: z.array(text).min(1),
  asset: assetSchema,
  correction: text,
  applicability: z.array(text).min(1),
  counterexample: text,
  outcome: outcomeSchema,
  visibility: z.literal("private"),
  reviewRequest: z.enum(["none", "requested"]),
  createdAt: z.string().datetime(),
}).strict();

function sameWorkItem(left: ExperienceWorkItem, right: ExperienceWorkItem): boolean {
  return left.workboardTaskId === right.workboardTaskId && left.packetTaskId === right.packetTaskId;
}

function sameAsset(left: ExperienceAsset, right: ExperienceAsset): boolean {
  return left.id === right.id && left.version === right.version;
}

function validSources(sources: readonly ExperienceSource[]): readonly ExperienceSource[] {
  const parsed = sources.map((source) => sourceSchema.safeParse(source));
  return parsed.every((result) => result.success)
    ? sources
    : [];
}

export interface ExperienceDraftStore {
  save(input: unknown): ExperienceDraftSaveResult;
  discard(input: unknown): { readonly ok: true; readonly status: "discarded"; readonly persistedCount: number };
  listForActor(actorId: "sales-demo" | "production-demo" | "management-demo"): readonly ExperienceDraft[];
  searchForTeam(actorId: "sales-demo" | "production-demo" | "management-demo"): readonly ExperienceDraft[];
  snapshot(): readonly ExperienceDraft[];
}

export interface CreateExperienceDraftStoreOptions {
  readonly sources: readonly ExperienceSource[];
  readonly initialDrafts?: readonly ExperienceDraft[];
  readonly now?: () => string;
  readonly nextId?: () => string;
}

export function createExperienceDraftStore(options: CreateExperienceDraftStoreOptions): ExperienceDraftStore {
  const sourceById = new Map(validSources(options.sources).map((source) => [source.evidenceId, source]));
  const drafts: ExperienceDraft[] = [];
  for (const candidate of options.initialDrafts ?? []) {
    const parsed = experienceDraftSchema.safeParse(candidate);
    if (!parsed.success) continue;
    const selectedSources = parsed.data.sourceEvidenceIds.map((evidenceId) => sourceById.get(evidenceId));
    if (selectedSources.some((source) => source === undefined)) continue;
    const resolvedSources = selectedSources.filter((source): source is ExperienceSource => source !== undefined);
    if (!resolvedSources.every((source) => sameWorkItem(source.workItem, parsed.data.workItem))) continue;
    if (!resolvedSources.some((source) => sameAsset(source.asset, parsed.data.asset))) continue;
    if (parsed.data.outcome.state === "observed" && !resolvedSources.some((source) => source.kind === "readback" && sameAsset(source.asset, parsed.data.asset))) continue;
    const outcome: ExperienceOutcome = parsed.data.outcome.state === "unobserved"
      ? { state: "unobserved" }
      : { state: "observed", observedAt: parsed.data.outcome.observedAt };
    drafts.push({
      id: parsed.data.id,
      version: 1,
      authorActorId: parsed.data.authorActorId,
      workItem: { ...parsed.data.workItem },
      sourceEvidenceIds: [...parsed.data.sourceEvidenceIds],
      asset: { ...parsed.data.asset },
      correction: parsed.data.correction,
      applicability: [...parsed.data.applicability],
      counterexample: parsed.data.counterexample,
      outcome,
      visibility: "private",
      reviewRequest: parsed.data.reviewRequest,
      createdAt: parsed.data.createdAt,
    });
  }
  let nextSequence = 1;
  const now = options.now ?? (() => "2026-09-19T00:00:00.000Z");
  const nextId = options.nextId ?? (() => {
    const id = `experience-draft-${nextSequence}`;
    nextSequence += 1;
    return id;
  });

  return {
    save(input) {
      const parsed = saveInputSchema.safeParse(input);
      if (!parsed.success) return { ok: false, code: "invalid_input", persistedCount: drafts.length };
      const request = parsed.data;
      const selectedSources = request.sourceEvidenceIds.map((evidenceId) => sourceById.get(evidenceId));
      if (selectedSources.some((source) => source === undefined)
        || selectedSources.some((source) => source !== undefined && !sameWorkItem(source.workItem, request.workItem))) {
        return { ok: false, code: "missing_source", persistedCount: drafts.length };
      }
      const resolvedSources = selectedSources.filter((source): source is ExperienceSource => source !== undefined);
      if (!resolvedSources.some((source) => sameAsset(source.asset, request.asset))) {
        return { ok: false, code: "invalid_asset", persistedCount: drafts.length };
      }
      if (request.outcome.state === "observed" && !resolvedSources.some((source) => source.kind === "readback")) {
        return { ok: false, code: "observed_outcome_requires_readback", persistedCount: drafts.length };
      }
      if (request.outcome.state === "observed" && !resolvedSources.some((source) => source.kind === "readback" && sameAsset(source.asset, request.asset))) {
        return { ok: false, code: "observed_outcome_requires_matching_readback", persistedCount: drafts.length };
      }
      const outcome: ExperienceOutcome = request.outcome.state === "unobserved"
        ? { state: "unobserved" }
        : { state: "observed", observedAt: request.outcome.observedAt };
      const draft: ExperienceDraft = {
        id: nextId(),
        version: 1,
        authorActorId: request.authorActorId,
        workItem: { ...request.workItem },
        sourceEvidenceIds: [...request.sourceEvidenceIds],
        asset: { ...request.asset },
        correction: request.correction,
        applicability: [...request.applicability],
        counterexample: request.counterexample,
        outcome,
        visibility: "private",
        reviewRequest: request.saveDecision === "shared_review" ? "requested" : "none",
        createdAt: now(),
      };
      drafts.push(draft);
      return { ok: true, draft, persistedCount: drafts.length };
    },
    discard() {
      return { ok: true, status: "discarded", persistedCount: drafts.length };
    },
    listForActor(actorId) {
      return drafts.filter((draft) => draft.authorActorId === actorId);
    },
    searchForTeam() {
      return [];
    },
    snapshot() {
      return [...drafts];
    },
  };
}
