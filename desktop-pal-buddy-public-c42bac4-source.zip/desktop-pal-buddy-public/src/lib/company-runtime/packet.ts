import { taskPacketSchema } from "../agentic/schemas";
import { z } from "zod";
import type { ActorId } from "./contracts";
import type { StrategyRef, TaskPacket } from "../agentic/types";

export interface TrustedPacketInputs {
  packetTaskId: string;
  createdAt: string;
  requesterActorId: ActorId;
  strategyRef: StrategyRef;
}

const reportFormat = {
  include_summary: true,
  include_evidence: true,
  include_blockers: true,
  include_next_action: true,
  max_detail_level: "standard" as const,
};

const trustedPacketInputsSchema = z.object({
  packetTaskId: z.string().uuid(),
  createdAt: z.string().datetime(),
  requesterActorId: z.enum(["sales-demo", "production-demo", "management-demo"]),
  strategyRef: z.object({
    strategy_id: z.string().trim().min(1),
    strategy_version_id: z.string().uuid(),
  }).strict(),
}).strict();

export function createProductionPriorityChangePacket(trusted: TrustedPacketInputs): TaskPacket {
  trusted = trustedPacketInputsSchema.parse(trusted);
  return taskPacketSchema.parse({
    task_id: trusted.packetTaskId,
    created_at: trusted.createdAt,
    created_by: trusted.requesterActorId,
    request_summary: "가상 ERP 생산계획 PP-DEMO-1001의 우선순위를 검토하고 승인 후 5에서 1로 변경",
    raw_user_request: "긴급 주문 SO-DEMO-1001의 생산 우선순위를 올려줘",
    desired_outcome: "정확한 범위의 생산 승인 후 priority 변경을 재조회 근거로 확인",
    task_type: "production_priority_change",
    context_refs: [
      { type: "sales_order", label: "대상 주문", value: "SO-DEMO-1001" },
      { type: "material_item", label: "대상 생산계획", value: "PP-DEMO-1001" },
    ],
    strategy_ref: trusted.strategyRef,
    risk_level: "high",
    required_approval: true,
    approval_reason: "가상 ERP ProductionPlan.priority 변경은 exact-scope 생산 승인이 필요합니다.",
    forbidden_actions: ["do not mutate virtual ERP before exact-scope production approval", "do not modify real ERP systems"],
    execution_plan: [
      { step_id: "read", summary: "주문·재고·생산계획의 현재 버전을 읽습니다." },
      { step_id: "approve", summary: "고정된 intent와 digest에 생산 승인을 연결합니다." },
      { step_id: "apply-readback", summary: "priority만 변경하고 저장 파일을 다시 열어 확인합니다.", expected_evidence: "production_state" },
    ],
    verification_requirements: [{ type: "production_state", required: true, command_or_source: "company runtime ERP readback" }],
    report_format: reportFormat,
    status: "waiting_for_approval",
    evidence: [],
    blockers: [],
    next_action: "production-demo가 exact-scope 제안을 검토합니다.",
  });
}

export function createProductionReadinessReviewPacket(trusted: TrustedPacketInputs): TaskPacket {
  trusted = trustedPacketInputsSchema.parse(trusted);
  return taskPacketSchema.parse({
    task_id: trusted.packetTaskId,
    created_at: trusted.createdAt,
    created_by: trusted.requesterActorId,
    request_summary: "생산 완료 안내 전 검사·포장 준비 상태를 읽기 전용으로 검토",
    raw_user_request: "고객에게 완료 안내를 준비해도 되는지 확인해줘",
    desired_outcome: "조회 근거와 미확인 조건을 분리한 생산 준비 판단",
    task_type: "production_readiness_review",
    context_refs: [{ type: "sales_order", label: "검토 주문", value: "SO-DEMO-1002" }],
    strategy_ref: trusted.strategyRef,
    risk_level: "medium",
    required_approval: false,
    forbidden_actions: ["do not mutate virtual ERP state", "do not send external messages"],
    execution_plan: [{ step_id: "review", summary: "허용된 readSet만 조회하고 준비 상태를 평가합니다.", expected_evidence: "risk_assessment" }],
    verification_requirements: [{ type: "risk_assessment", required: true }],
    report_format: reportFormat,
    status: "queued",
    evidence: [],
    blockers: [],
    next_action: "검사 pending과 포장 미확인을 업무상 needs_review로 표시합니다.",
  });
}
