import { z } from "zod";
import type { StrategyRef, TaskPacket } from "../agentic";
import { actionIntentSchema, approvalSchema, executionSchema, readbackEvidenceSchema, runtimeTaskRecordSchema } from "./schemas";
import type { ActionIntent, Approval, Execution, ReadbackEvidence } from "./contracts";

export const WORKBOARD_TASK_ORIGINS = ["legacy", "company_runtime"] as const;
export type WorkboardTaskOrigin = (typeof WORKBOARD_TASK_ORIGINS)[number];

export interface LegacyTaskRecord {
  readonly id: string; readonly title: string; readonly description: string | null; readonly source: string | null; readonly source_id: string | null;
  readonly severity: string | null; readonly customer: string | null; readonly category: string | null; readonly status: string; readonly created_at: string;
  readonly demo_intake_required?: unknown;
  readonly demo_intake_packet?: unknown;
}

interface WorkboardTaskViewBase extends LegacyTaskRecord { readonly origin: WorkboardTaskOrigin; readonly sourceId: string; readonly viewKey: string; }

export interface LegacyWorkboardTaskView extends WorkboardTaskViewBase {
  readonly origin: "legacy";
}

export type PinnedStrategyProjection = { readonly status: "pinned"; readonly ref: StrategyRef; readonly strategy_id: string; readonly strategy_version_id: string; readonly version: number; readonly objective: string; readonly reviewQuestion: string }
  | { readonly status: "review_required"; readonly reason: "missing_ref" | "invalid_ref" };

export type ApprovalProjection = { readonly state: "not_required" } | { readonly state: "pending" }
  | { readonly state: "approved" | "expired" | "rejected" | "revoked"; readonly approvalId: string; readonly expiresAt: string }
  | { readonly state: "consumed"; readonly approvalId: string; readonly executionId: string; readonly expiresAt: string }
  | { readonly state: "review_required"; readonly reason: "missing_ref" | "invalid_ref" | "proposal_missing" };

export type ExecutionProjection = { readonly state: "none" }
  | { readonly state: Execution["state"]; readonly executionId: string; readonly expectedPriority: number; readonly expectedVersion: number }
  | { readonly state: "verification_required"; readonly executionId: string; readonly reason: "missing_readback" | "mismatched_readback" }
  | { readonly state: "review_required"; readonly executionId: string; readonly reason: "missing_ref" | "invalid_ref" };

export type ReadbackProjection = { readonly state: "none" }
  | { readonly state: "verified"; readonly executionId: string; readonly observedPriority: number; readonly observedVersion: number; readonly readAt: string }
  | { readonly state: "verification_required"; readonly executionId: string; readonly reason: "missing" | "mismatch" };

export type BusinessOutcomeProjection = { readonly state: "unknown" } | { readonly state: "observed_simulated"; readonly evidenceRefs: readonly string[]; readonly observedAt: string | null };

export interface CompanyRuntimeTaskCardProjection { readonly pinnedStrategy: PinnedStrategyProjection; readonly approval: ApprovalProjection; readonly execution: ExecutionProjection; readonly readback: ReadbackProjection; readonly businessOutcome: BusinessOutcomeProjection; readonly reviewRequired: boolean; }

export interface CompanyRuntimeTaskView extends WorkboardTaskViewBase { readonly origin: "company_runtime"; readonly packetTaskId: string; readonly epoch: string; readonly packet: TaskPacket; readonly strategyRef: StrategyRef | undefined; readonly card?: CompanyRuntimeTaskCardProjection; }

export type WorkboardTaskView = LegacyWorkboardTaskView | CompanyRuntimeTaskView;

export type CompanyRuntimeProjection =
  | { readonly state: "ready"; readonly epoch: string; readonly tasks: readonly CompanyRuntimeTaskView[] }
  | { readonly state: "unavailable"; readonly tasks: readonly []; readonly reason: "invalid_runtime_snapshot" };

const strategyVersionSchema = z.object({
  strategy_id: z.string().trim().min(1),
  strategy_version_id: z.string().trim().min(1),
  version: z.number().int().positive(),
  objective: z.string().trim().min(1),
  review_question: z.string().trim().min(1),
}).passthrough();

const runtimeSnapshotSchema = z.object({
  currentEpoch: z.string().uuid(),
  current: z.object({ strategyVersions: z.array(z.unknown()).default([]) }).passthrough().optional(),
  records: z.object({
    tasks: z.array(runtimeTaskRecordSchema),
    actionIntents: z.array(z.unknown()).default([]),
    approvals: z.array(z.unknown()).default([]),
    executions: z.array(z.unknown()).default([]),
    readbackEvidence: z.array(z.unknown()).default([]),
  }).passthrough(),
}).passthrough().superRefine((snapshot, context) => {
  if (snapshot.records.tasks.some((task) => task.epoch !== snapshot.currentEpoch)) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "runtime task belongs to a stale epoch" });
  }
});

type RuntimeSnapshot = z.infer<typeof runtimeSnapshotSchema>;
type RuntimeRecords = RuntimeSnapshot["records"];

function sameRef(left: StrategyRef, right: StrategyRef): boolean {
  return left.strategy_id === right.strategy_id && left.strategy_version_id === right.strategy_version_id;
}

function findIntent(records: RuntimeRecords, task: z.infer<typeof runtimeTaskRecordSchema>): ActionIntent | null {
  if (!task.currentProposal) return null;
  for (const value of records.actionIntents) {
    const parsed = actionIntentSchema.safeParse(value);
    if (parsed.success
      && parsed.data.id === task.currentProposal.intentId
      && parsed.data.revision === task.currentProposal.revision
      && parsed.data.proposalDigest === task.currentProposal.proposalDigest
      && parsed.data.workboardTaskId === task.workboardTaskId
      && parsed.data.packetTaskId === task.packetTaskId
      && parsed.data.epoch === task.epoch) return parsed.data;
  }
  return null;
}

function findApproval(records: RuntimeRecords, task: z.infer<typeof runtimeTaskRecordSchema>): Approval | null {
  if (!task.currentApprovalId) return null;
  for (const value of records.approvals) {
    const parsed = approvalSchema.safeParse(value);
    if (parsed.success && parsed.data.id === task.currentApprovalId) return parsed.data;
  }
  return null;
}

function findExecution(records: RuntimeRecords, task: z.infer<typeof runtimeTaskRecordSchema>): Execution | null {
  if (!task.executionId) return null;
  for (const value of records.executions) {
    const parsed = executionSchema.safeParse(value);
    if (parsed.success && parsed.data.id === task.executionId) return parsed.data;
  }
  return null;
}

function findReadback(records: RuntimeRecords, execution: Execution, intent: ActionIntent): ReadbackEvidence | null {
  for (const value of records.readbackEvidence) {
    const parsed = readbackEvidenceSchema.safeParse(value);
    if (parsed.success
      && parsed.data.executionId === execution.id
      && parsed.data.targetPlanId === intent.targetPlanId
      && parsed.data.epoch === execution.epoch
      && parsed.data.expectedPriority === execution.expectedAfter.priority
      && parsed.data.expectedVersion === execution.expectedAfter.version) return parsed.data;
  }
  return null;
}

function projectStrategy(task: z.infer<typeof runtimeTaskRecordSchema>, current: RuntimeSnapshot["current"]): PinnedStrategyProjection {
  const ref = task.packet.strategy_ref;
  if (!ref) return { status: "review_required", reason: "missing_ref" };
  const versions = current?.strategyVersions ?? [];
  for (const value of versions) {
    const parsed = strategyVersionSchema.safeParse(value);
    if (parsed.success && sameRef(parsed.data, ref)) {
      return {
        status: "pinned",
        ref,
        strategy_id: parsed.data.strategy_id,
        strategy_version_id: parsed.data.strategy_version_id,
        version: parsed.data.version,
        objective: parsed.data.objective,
        reviewQuestion: parsed.data.review_question,
      };
    }
  }
  return { status: "review_required", reason: "invalid_ref" };
}

function projectApproval(
  task: z.infer<typeof runtimeTaskRecordSchema>,
  intent: ActionIntent | null,
  approval: Approval | null,
  execution: Execution | null,
  nowMs: number,
): ApprovalProjection {
  if (!task.packet.required_approval) return task.currentApprovalId ? { state: "review_required", reason: "invalid_ref" } : { state: "not_required" };
  if (!task.currentProposal || !intent) return { state: "review_required", reason: "proposal_missing" };
  if (!task.currentApprovalId) return { state: "pending" };
  if (!approval
    || approval.intentId !== intent.id
    || approval.intentRevision !== intent.revision
    || approval.proposalDigest !== intent.proposalDigest
    || approval.epoch !== intent.epoch
    || !sameRef(approval.strategyRef, intent.strategyRef)) return { state: "review_required", reason: "invalid_ref" };
  if (approval.decision === "rejected" || approval.decision === "revoked") return { state: approval.decision, approvalId: approval.id, expiresAt: approval.expiresAt };
  if (approval.consumedByExecutionId) {
    return execution?.id === approval.consumedByExecutionId
      ? { state: "consumed", approvalId: approval.id, executionId: execution.id, expiresAt: approval.expiresAt }
      : { state: "review_required", reason: "invalid_ref" };
  }
  if (Date.parse(approval.expiresAt) <= nowMs) return { state: "expired", approvalId: approval.id, expiresAt: approval.expiresAt };
  return { state: "approved", approvalId: approval.id, expiresAt: approval.expiresAt };
}

function executionMatches(task: z.infer<typeof runtimeTaskRecordSchema>, intent: ActionIntent | null, approval: Approval | null, execution: Execution | null): execution is Execution {
  return Boolean(execution
    && intent
    && execution.intentId === intent.id
    && execution.epoch === task.epoch
    && execution.approvalId === (approval?.id ?? null));
}

function projectExecution(task: z.infer<typeof runtimeTaskRecordSchema>, intent: ActionIntent | null, approval: Approval | null, execution: Execution | null, readback: ReadbackEvidence | null): ExecutionProjection {
  if (!task.executionId) return { state: "none" };
  if (!executionMatches(task, intent, approval, execution)) return { state: "review_required", executionId: task.executionId, reason: "invalid_ref" };
  if (execution.state === "verified" && !readback?.matches) {
    return { state: "verification_required", executionId: execution.id, reason: readback ? "mismatched_readback" : "missing_readback" };
  }
  return { state: execution.state, executionId: execution.id, expectedPriority: execution.expectedAfter.priority, expectedVersion: execution.expectedAfter.version };
}

function projectReadback(task: z.infer<typeof runtimeTaskRecordSchema>, execution: Execution | null, readback: ReadbackEvidence | null): ReadbackProjection {
  if (!task.executionId || !execution) return { state: "none" };
  if (readback?.matches) return { state: "verified", executionId: execution.id, observedPriority: readback.observedPriority, observedVersion: readback.observedVersion, readAt: readback.readAt };
  if (["applied_pending_readback", "verified", "verification_required"].includes(execution.state)) {
    return { state: "verification_required", executionId: execution.id, reason: readback ? "mismatch" : "missing" };
  }
  return { state: "none" };
}

function projectCard(task: z.infer<typeof runtimeTaskRecordSchema>, snapshot: RuntimeSnapshot, nowMs: number): CompanyRuntimeTaskCardProjection {
  const intent = findIntent(snapshot.records, task);
  const approval = findApproval(snapshot.records, task);
  const execution = findExecution(snapshot.records, task);
  const validExecution = executionMatches(task, intent, approval, execution) ? execution : null;
  const readback = intent && validExecution ? findReadback(snapshot.records, validExecution, intent) : null;
  const pinnedStrategy = projectStrategy(task, snapshot.current);
  const approvalProjection = projectApproval(task, intent, approval, validExecution, nowMs);
  const executionProjection = projectExecution(task, intent, approval, execution, readback);
  const readbackProjection = projectReadback(task, validExecution, readback);
  const businessOutcome: BusinessOutcomeProjection = task.businessOutcome.status === "observed_simulated"
    ? { state: "observed_simulated", evidenceRefs: task.businessOutcome.evidenceRefs, observedAt: task.businessOutcome.observedAt }
    : { state: "unknown" };
  const reviewRequired = pinnedStrategy.status === "review_required"
    || ["pending", "rejected", "revoked", "expired", "review_required"].includes(approvalProjection.state)
    || executionProjection.state === "review_required"
    || executionProjection.state === "verification_required"
    || readbackProjection.state === "verification_required";
  return { pinnedStrategy, approval: approvalProjection, execution: executionProjection, readback: readbackProjection, businessOutcome, reviewRequired };
}

export function workboardTaskViewKey(origin: WorkboardTaskOrigin, sourceId: string): string {
  return `${origin}:${sourceId}`;
}

export function projectLegacyTask(task: LegacyTaskRecord): LegacyWorkboardTaskView {
  return {
    ...task,
    origin: "legacy",
    sourceId: task.id,
    viewKey: workboardTaskViewKey("legacy", task.id),
  };
}

export function projectCompanyRuntimeSnapshot(value: unknown, options: { readonly now?: string } = {}): CompanyRuntimeProjection {
  const parsed = runtimeSnapshotSchema.safeParse(value);
  if (!parsed.success) return { state: "unavailable", tasks: [], reason: "invalid_runtime_snapshot" };
  const nowMs = Date.parse(options.now ?? new Date().toISOString());
  return {
    state: "ready",
    epoch: parsed.data.currentEpoch,
    tasks: parsed.data.records.tasks.map((record) => ({
      origin: "company_runtime",
      sourceId: record.workboardTaskId,
      viewKey: workboardTaskViewKey("company_runtime", record.workboardTaskId),
      id: record.workboardTaskId,
      title: record.packet.request_summary,
      description: record.packet.desired_outcome,
      source: "company_runtime",
      source_id: record.packetTaskId,
      severity: record.packet.risk_level,
      customer: null,
      category: "production",
      status: record.status,
      created_at: record.packet.created_at,
      packetTaskId: record.packetTaskId,
      epoch: record.epoch,
      packet: record.packet,
      strategyRef: record.packet.strategy_ref,
      card: projectCard(record, parsed.data, Number.isFinite(nowMs) ? nowMs : Date.now()),
    })),
  };
}

export function mergeWorkboardTaskViews(
  legacy: readonly LegacyWorkboardTaskView[],
  runtime: readonly CompanyRuntimeTaskView[],
): WorkboardTaskView[] {
  return [...legacy, ...runtime];
}
