import { describe, expect, it } from "vitest";
import { selectLearningReuse } from "./reuse";

const EPOCH = "018f4ef1-7bbb-7bbb-7bbb-7bbbbbbbbbbb";
const WORKBOARD_TASK_ID = "9e650d6d-9e9f-4a09-b041-e345d16620a8";
const PACKET_TASK_ID = "27862353-b4b6-43d3-bec2-2e4afe57dc06";

function asset(overrides: Record<string, unknown> = {}) {
  return {
    id: "learning-readiness",
    version: 1,
    authorActorId: "sales-demo",
    sourceDraft: { id: "experience-draft-1", version: 1 },
    sourceWorkItem: { workboardTaskId: WORKBOARD_TASK_ID, packetTaskId: PACKET_TASK_ID },
    sourceAsset: { id: "PP-DEMO-1001", version: 2 },
    sourceEvidenceIds: ["evidence:production_plan:PP-DEMO-1001:v2"],
    exactPublishableSentence: "검사와 포장 준비를 먼저 확인합니다.",
    applicability: ["queued production plan"],
    targetDepartments: ["production"],
    includeManagementStrategyReview: false,
    consent: { previewId: "learning-preview-1", decidedAt: "2026-09-19T02:00:00.000Z" },
    createdAt: "2026-09-19T02:00:00.000Z",
    reuseEpoch: EPOCH,
    reuseApplicability: {
      workType: "production_readiness",
      department: "production",
      materialGroup: "MAT-GA-DEMO",
      requiredChecks: ["inspection"],
    },
    sourceLearningRefs: [],
    sharingState: "shared",
    ...overrides,
  };
}

function withdrawal(assetId: string, version: number) {
  return {
    id: `withdrawal-${assetId}-${version}`,
    assetId,
    version,
    authorActorId: "sales-demo",
    withdrawnAt: "2026-09-19T03:00:00.000Z",
  };
}

function select(assets: readonly unknown[], overrides: Record<string, unknown> = {}) {
  return selectLearningReuse({
    assets,
    withdrawals: [],
    target: {
      epoch: EPOCH,
      workType: "production_readiness",
      department: "production",
      materialGroup: "MAT-GA-DEMO",
    },
    currentRequiredChecks: [],
    ...overrides,
  });
}

describe("bounded cross-department learning reuse", () => {
  it("selects an exact shared match and returns only the read expansion with redacted AI context", () => {
    const result = select([asset()]);

    expect(result).toMatchObject({
      kind: "selected",
      candidate: { assetId: "learning-readiness", version: 1 },
      matchedContext: {
        workType: "production_readiness",
        department: "production",
        materialGroup: "MAT-GA-DEMO",
      },
      requiredChecksToAdd: ["inspection"],
      lineage: { status: "verified", refs: [] },
      aiContext: {
        exactPublishableSentence: "검사와 포장 준비를 먼저 확인합니다.",
        requiredChecks: ["inspection"],
      },
    });
    expect(result).not.toHaveProperty("execute");
    expect(result).not.toHaveProperty("approval");
    expect(result).not.toHaveProperty("policy");
  });

  it("uses the latest active version and never falls back to a superseded version", () => {
    const latest = asset({ version: 2, exactPublishableSentence: "검사와 포장을 확인합니다." });
    expect(select([asset(), latest])).toMatchObject({ kind: "selected", candidate: { version: 2 } });

    const privateLatest = asset({ version: 2, sharingState: "private" });
    expect(select([asset(), privateLatest])).toEqual({
      kind: "no_candidate",
      code: "no_matching_candidate",
      lineage: { status: "not_checked", refs: [] },
      aiContext: null,
    });
  });

  it("rejects private, non-audience, withdrawn, and epoch-mismatched candidates without AI context", () => {
    expect(select([asset({ sharingState: "private" })])).toMatchObject({ kind: "no_candidate", aiContext: null });
    expect(select([asset({ targetDepartments: ["sales"] })])).toMatchObject({ kind: "no_candidate", aiContext: null });
    expect(select([asset()], { withdrawals: [withdrawal("learning-readiness", 1)] })).toMatchObject({ kind: "no_candidate", aiContext: null });
    expect(select([asset({ reuseEpoch: "018f4ef1-7bbb-7bbb-7bbb-7bbbbbbbbbbc" })])).toMatchObject({ kind: "no_candidate", aiContext: null });
  });

  it("rejects a recursively withdrawn source without exposing its body", () => {
    const source = asset({ id: "learning-source", exactPublishableSentence: "숨겨진 출처 본문" });
    const candidate = asset({ sourceLearningRefs: [{ assetId: "learning-source", version: 1 }] });

    const result = select([candidate, source], { withdrawals: [withdrawal("learning-source", 1)] });

    expect(result).toEqual({
      kind: "no_candidate",
      code: "source_withdrawn",
      lineage: { status: "source_withdrawn", refs: [{ assetId: "learning-source", version: 1 }] },
      aiContext: null,
    });
    expect(JSON.stringify(result)).not.toContain("숨겨진 출처 본문");
  });

  it("rejects a recursively private source and a cyclic provenance chain", () => {
    const privateSource = asset({ id: "learning-source", sharingState: "private" });
    const candidateWithPrivateSource = asset({ sourceLearningRefs: [{ assetId: "learning-source", version: 1 }] });
    expect(select([candidateWithPrivateSource, privateSource])).toMatchObject({
      kind: "no_candidate",
      code: "source_inaccessible",
      lineage: { status: "source_inaccessible" },
      aiContext: null,
    });

    const left = asset({ id: "learning-left", sourceLearningRefs: [{ assetId: "learning-right", version: 1 }] });
    const right = asset({ id: "learning-right", sourceLearningRefs: [{ assetId: "learning-left", version: 1 }] });
    expect(select([left, right])).toMatchObject({
      kind: "no_candidate",
      code: "source_cycle",
      lineage: { status: "source_cycle" },
      aiContext: null,
    });
  });

  it("fails closed when a referenced learning source is missing", () => {
    const candidate = asset({ sourceLearningRefs: [{ assetId: "learning-missing", version: 1 }] });

    expect(select([candidate])).toEqual({
      kind: "no_candidate",
      code: "source_missing",
      lineage: { status: "source_missing", refs: [{ assetId: "learning-missing", version: 1 }] },
      aiContext: null,
    });
  });

  it("returns needs_review when equally matching assets require conflicting reads", () => {
    const inspection = asset({ id: "learning-inspection" });
    const packaging = asset({
      id: "learning-packaging",
      reuseApplicability: {
        workType: "production_readiness",
        department: "production",
        materialGroup: "MAT-GA-DEMO",
        requiredChecks: ["packaging"],
      },
    });

    expect(select([inspection, packaging])).toEqual({
      kind: "needs_review",
      code: "conflicting_required_checks",
      candidateIds: ["learning-inspection", "learning-packaging"],
      aiContext: null,
    });
  });

  it("only adds missing required checks and never removes an existing check", () => {
    const candidate = asset({
      reuseApplicability: {
        workType: "production_readiness",
        department: "production",
        materialGroup: "MAT-GA-DEMO",
        requiredChecks: ["inspection", "packaging"],
      },
    });

    expect(select([candidate], { currentRequiredChecks: ["inspection"] })).toMatchObject({
      kind: "selected",
      requiredChecksToAdd: ["packaging"],
    });
  });

  it("fails closed with a typed result for an unknown applicability rule", () => {
    const unknownRule = asset({
      reuseApplicability: {
        workType: "production_readiness",
        department: "production",
        materialGroup: "MAT-GA-DEMO",
        requiredChecks: ["sql:drop-table"],
      },
    });

    expect(select([unknownRule])).toEqual({ kind: "rejected", code: "unknown_rule", aiContext: null });
  });
});
