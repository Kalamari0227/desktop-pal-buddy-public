import { z } from "zod";
import type { ActorId, ActorRole } from "./contracts";
import type { ExperienceDraft } from "./experience";
import { experienceDraftSchema } from "./experience";
import {
  actorIdSchema,
  actorRoleSchema,
  learningReuseApplicabilitySchema,
  learningSourceReferenceSchema,
} from "./schemas";

const text = z.string().trim().min(1);
const positiveInteger = z.number().int().positive();
const timestamp = z.string().datetime();

export const learningPreviewSchema = z.object({
  previewId: text,
  assetId: text.nullable(),
  baseVersion: positiveInteger.nullable(),
  authorActorId: actorIdSchema,
  sourceDraft: z.object({ id: text, version: z.literal(1) }).strict(),
  sourceWorkItem: z.object({ workboardTaskId: z.string().uuid(), packetTaskId: z.string().uuid() }).strict(),
  sourceAsset: z.object({ id: text, version: positiveInteger }).strict(),
  sourceEvidenceIds: z.array(text).min(1),
  exactPublishableSentence: text,
  applicability: z.array(text).min(1),
  targetDepartments: z.array(actorRoleSchema).min(1),
  includeManagementStrategyReview: z.boolean(),
  reuseEpoch: z.string().uuid().nullable().optional().default(null),
  reuseApplicability: learningReuseApplicabilitySchema.nullable().optional().default(null),
  sourceLearningRefs: z.array(learningSourceReferenceSchema).optional().default([]),
}).strict();

export const learningAssetVersionSchema = learningPreviewSchema.omit({ previewId: true, assetId: true, baseVersion: true }).extend({
  id: text,
  version: positiveInteger,
  consent: z.object({ previewId: text, decidedAt: timestamp }).strict(),
  createdAt: timestamp,
  sharingState: z.enum(["private", "shared"]).optional().default("shared"),
}).strict();

export const learningWithdrawalSchema = z.object({
  id: text,
  assetId: text,
  version: positiveInteger,
  authorActorId: actorIdSchema,
  withdrawnAt: timestamp,
}).strict();

export const learningSuggestionSchema = z.object({
  id: text,
  assetId: text,
  assetVersion: positiveInteger,
  state: z.enum(["pending", "stale"]),
}).strict();

export const learningProvenanceSchema = z.object({
  id: text,
  version: positiveInteger,
  authorActorId: actorIdSchema,
  sourceDraft: z.object({ id: text, version: z.literal(1) }).strict(),
  sourceEvidenceIds: z.array(text),
  consent: z.object({ previewId: text, decidedAt: timestamp }).strict(),
  withdrawn: z.boolean(),
}).strict();

export type LearningPreview = z.infer<typeof learningPreviewSchema>;
export type LearningAssetVersion = z.infer<typeof learningAssetVersionSchema>;
export type LearningWithdrawal = z.infer<typeof learningWithdrawalSchema>;
export type LearningSuggestion = z.infer<typeof learningSuggestionSchema>;
export type LearningProvenance = z.infer<typeof learningProvenanceSchema>;

type LearningFailureCode = "invalid_input" | "draft_not_found" | "author_required" | "preview_required" | "consent_required" | "asset_not_found" | "version_conflict" | "already_withdrawn";

export type LearningFailure = { readonly ok: false; readonly code: LearningFailureCode };
export type LearningPreviewResult = { readonly ok: true; readonly preview: LearningPreview } | LearningFailure;
export type LearningPublishResult = { readonly ok: true; readonly asset: LearningAssetVersion } | LearningFailure;
export type LearningWithdrawResult = { readonly ok: true; readonly withdrawal: LearningWithdrawal } | LearningFailure;

const ACTOR_ROLE: Readonly<Record<ActorId, ActorRole>> = {
  "sales-demo": "sales",
  "production-demo": "production",
  "management-demo": "management",
};

function clone<T>(value: T): T { return structuredClone(value); }

function samePreview(left: LearningPreview, right: LearningPreview): boolean { return JSON.stringify(left) === JSON.stringify(right); }

function uniqueRoles(roles: readonly ActorRole[]): ActorRole[] { return [...new Set(roles)]; }

export interface CreateLearningAssetStoreOptions {
  readonly drafts: readonly ExperienceDraft[];
  readonly assets?: readonly LearningAssetVersion[];
  readonly withdrawals?: readonly LearningWithdrawal[];
  readonly suggestions?: readonly LearningSuggestion[];
  readonly previews?: readonly LearningPreview[];
  readonly now?: () => string;
  readonly nextId?: () => string;
  readonly nextPreviewId?: () => string;
}

export function createLearningAssetStore(options: CreateLearningAssetStoreOptions) {
  const drafts = new Map<string, ExperienceDraft>();
  for (const candidate of options.drafts) {
    const parsed = experienceDraftSchema.safeParse(candidate);
    if (parsed.success) drafts.set(parsed.data.id, clone(parsed.data));
  }
  const assets = options.assets?.flatMap((candidate) => {
    const parsed = learningAssetVersionSchema.safeParse(candidate);
    return parsed.success ? [clone(parsed.data)] : [];
  }) ?? [];
  const withdrawals = options.withdrawals?.flatMap((candidate) => {
    const parsed = learningWithdrawalSchema.safeParse(candidate);
    return parsed.success ? [clone(parsed.data)] : [];
  }) ?? [];
  const suggestions = options.suggestions?.flatMap((candidate) => {
    const parsed = learningSuggestionSchema.safeParse(candidate);
    return parsed.success ? [clone(parsed.data)] : [];
  }) ?? [];
  const previews = new Map<string, LearningPreview>();
  for (const candidate of options.previews ?? []) {
    const parsed = learningPreviewSchema.safeParse(candidate);
    if (parsed.success) previews.set(parsed.data.previewId, clone(parsed.data));
  }
  const now = options.now ?? (() => new Date().toISOString());
  let sequence = 0;
  let previewSequence = 0;
  const nextId = options.nextId ?? (() => {
    sequence += 1;
    return `learning-${sequence}`;
  });
  const nextPreviewId = options.nextPreviewId ?? (() => {
    previewSequence += 1;
    return `learning-preview-${previewSequence}`;
  });

  const isWithdrawn = (asset: LearningAssetVersion) => withdrawals.some((item) =>
    item.assetId === asset.id && item.version === asset.version);
  const latestActive = () => assets.filter((asset) => !isWithdrawn(asset) && !assets.some((candidate) =>
    candidate.id === asset.id && candidate.version > asset.version && !isWithdrawn(candidate)));
  const activeShared = () => latestActive().filter((asset) => asset.sharingState === "shared");
  const visible = (actorId: ActorId) => activeShared().filter((asset) =>
    asset.targetDepartments.includes(ACTOR_ROLE[actorId]));

  return {
    preview(input: unknown): LearningPreviewResult {
      const parsed = z.object({
        actorId: actorIdSchema,
        draftId: text,
        assetId: text.optional(),
        exactPublishableSentence: text,
        applicability: z.array(text).min(1),
        targetDepartments: z.array(actorRoleSchema).min(1),
        includeManagementStrategyReview: z.boolean(),
        reuseEpoch: z.string().uuid().nullable().optional(),
        reuseApplicability: learningReuseApplicabilitySchema.nullable().optional(),
        sourceLearningRefs: z.array(learningSourceReferenceSchema).optional(),
      }).strict().safeParse(input);
      if (!parsed.success) return { ok: false, code: "invalid_input" };
      const draft = drafts.get(parsed.data.draftId);
      if (!draft) return { ok: false, code: "draft_not_found" };
      if (draft.authorActorId !== parsed.data.actorId) return { ok: false, code: "author_required" };
      const existingVersions = parsed.data.assetId ? assets.filter((asset) => asset.id === parsed.data.assetId) : [];
      if (parsed.data.assetId && !existingVersions.some((asset) => asset.authorActorId === parsed.data.actorId)) {
        return { ok: false, code: "asset_not_found" };
      }
      const preview: LearningPreview = {
        previewId: nextPreviewId(),
        assetId: parsed.data.assetId ?? null,
        baseVersion: existingVersions.length === 0 ? null : Math.max(...existingVersions.map((asset) => asset.version)),
        authorActorId: draft.authorActorId,
        sourceDraft: { id: draft.id, version: draft.version },
        sourceWorkItem: clone(draft.workItem),
        sourceAsset: clone(draft.asset),
        sourceEvidenceIds: [...draft.sourceEvidenceIds],
        exactPublishableSentence: parsed.data.exactPublishableSentence,
        applicability: [...parsed.data.applicability],
        targetDepartments: uniqueRoles(parsed.data.targetDepartments),
        includeManagementStrategyReview: parsed.data.includeManagementStrategyReview,
        reuseEpoch: parsed.data.reuseEpoch ?? null,
        reuseApplicability: parsed.data.reuseApplicability ?? null,
        sourceLearningRefs: parsed.data.sourceLearningRefs ?? [],
      };
      previews.set(preview.previewId, clone(preview));
      return { ok: true, preview: clone(preview) };
    },
    publish(input: unknown): LearningPublishResult {
      const parsed = z.object({ actorId: actorIdSchema, preview: learningPreviewSchema, consentGranted: z.boolean() }).strict().safeParse(input);
      if (!parsed.success) return { ok: false, code: "invalid_input" };
      if (!parsed.data.consentGranted) return { ok: false, code: "consent_required" };
      if (parsed.data.actorId !== parsed.data.preview.authorActorId) return { ok: false, code: "author_required" };
      const storedPreview = previews.get(parsed.data.preview.previewId);
      if (!storedPreview || !samePreview(storedPreview, parsed.data.preview)) return { ok: false, code: "preview_required" };
      const existing = parsed.data.preview.assetId
        ? assets.filter((asset) => asset.id === parsed.data.preview.assetId)
        : [];
      if (existing.some((asset) => asset.authorActorId !== parsed.data.actorId)) return { ok: false, code: "author_required" };
      if (existing.length > 0 && parsed.data.preview.baseVersion !== Math.max(...existing.map((asset) => asset.version))) {
        return { ok: false, code: "version_conflict" };
      }
      const version = existing.length === 0 ? 1 : Math.max(...existing.map((asset) => asset.version)) + 1;
      const asset = learningAssetVersionSchema.parse({
        id: parsed.data.preview.assetId ?? nextId(),
        version,
        authorActorId: parsed.data.preview.authorActorId,
        sourceDraft: parsed.data.preview.sourceDraft,
        sourceWorkItem: parsed.data.preview.sourceWorkItem,
        sourceAsset: parsed.data.preview.sourceAsset,
        sourceEvidenceIds: parsed.data.preview.sourceEvidenceIds,
        exactPublishableSentence: parsed.data.preview.exactPublishableSentence,
        applicability: parsed.data.preview.applicability,
        targetDepartments: parsed.data.preview.targetDepartments,
        includeManagementStrategyReview: parsed.data.preview.includeManagementStrategyReview,
        reuseEpoch: parsed.data.preview.reuseEpoch,
        reuseApplicability: parsed.data.preview.reuseApplicability,
        sourceLearningRefs: parsed.data.preview.sourceLearningRefs,
        sharingState: "shared",
        consent: { previewId: parsed.data.preview.previewId, decidedAt: now() },
        createdAt: now(),
      });
      assets.push(asset);
      previews.delete(parsed.data.preview.previewId);
      return { ok: true, asset: clone(asset) };
    },
    withdraw(input: unknown): LearningWithdrawResult {
      const parsed = z.object({ actorId: actorIdSchema, assetId: text, version: positiveInteger }).strict().safeParse(input);
      if (!parsed.success) return { ok: false, code: "invalid_input" };
      const asset = assets.find((candidate) => candidate.id === parsed.data.assetId && candidate.version === parsed.data.version);
      if (!asset) return { ok: false, code: "asset_not_found" };
      if (asset.authorActorId !== parsed.data.actorId) return { ok: false, code: "author_required" };
      if (isWithdrawn(asset)) return { ok: false, code: "already_withdrawn" };
      const withdrawal = learningWithdrawalSchema.parse({ id: nextId(), assetId: asset.id, version: asset.version, authorActorId: asset.authorActorId, withdrawnAt: now() });
      withdrawals.push(withdrawal);
      for (let index = 0; index < suggestions.length; index += 1) {
        const suggestion = suggestions[index];
        if (suggestion?.assetId === asset.id && suggestion.assetVersion === asset.version && suggestion.state === "pending") {
          suggestions[index] = { ...suggestion, state: "stale" };
        }
      }
      return { ok: true, withdrawal: clone(withdrawal) };
    },
    addPendingSuggestion(input: unknown): LearningSuggestion | null {
      const parsed = learningSuggestionSchema.safeParse({ ...(typeof input === "object" && input !== null ? input : {}), state: "pending" });
      if (!parsed.success || !assets.some((asset) => asset.id === parsed.data.assetId && asset.version === parsed.data.assetVersion)) return null;
      suggestions.push(parsed.data);
      return clone(parsed.data);
    },
    readForRole(actorId: ActorId) { return clone(visible(actorId)); },
    search(actorId: ActorId, query: string) {
      const normalized = query.trim().toLocaleLowerCase();
      return clone(visible(actorId).filter((asset) => normalized.length > 0 && [asset.exactPublishableSentence, ...asset.applicability]
        .some((value) => value.toLocaleLowerCase().includes(normalized))));
    },
    recommend(actorId: ActorId) { return clone(visible(actorId)); },
    aiContext(actorId: ActorId) { return clone(visible(actorId)); },
    managementStrategyReview(actorId: ActorId) {
      return actorId === "management-demo" ? clone(activeShared().filter((asset) => asset.includeManagementStrategyReview)) : [];
    },
    provenanceForAuthor(actorId: ActorId) {
      return assets.filter((asset) => asset.authorActorId === actorId).map((asset) => ({
        id: asset.id,
        version: asset.version,
        authorActorId: asset.authorActorId,
        sourceDraft: clone(asset.sourceDraft),
        sourceEvidenceIds: [...asset.sourceEvidenceIds],
        consent: clone(asset.consent),
        withdrawn: isWithdrawn(asset),
      }));
    },
    projectForActor(actorId: ActorId) {
      return {
        active: clone(visible(actorId)),
        managementStrategyReview: this.managementStrategyReview(actorId),
        provenance: this.provenanceForAuthor(actorId),
        suggestions: clone(suggestions.filter((suggestion) => assets.some((asset) =>
          asset.id === suggestion.assetId && asset.authorActorId === actorId))),
      };
    },
    snapshot() {
      return { assets: clone(assets), withdrawals: clone(withdrawals), suggestions: clone(suggestions) };
    },
  };
}

export type LearningAssetStore = ReturnType<typeof createLearningAssetStore>;
