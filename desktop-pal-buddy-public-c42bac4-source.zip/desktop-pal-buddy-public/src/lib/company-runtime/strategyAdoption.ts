import { z } from "zod";
import type { RuntimeStrategyVersion, StrategyAdoption } from "./contracts";
import {
  actorIdSchema,
  companyStateSchema,
  strategyAdoptionSchema,
  strategyAdoptionsSchema,
  runtimeStrategyRefSchema,
  strategyReviewSchema,
} from "./schemas";
import { canonicalSerialize, type CanonicalDigest } from "./transitions";

const inputSchema = z.object({
  state: companyStateSchema,
  existingReviews: z.array(strategyReviewSchema),
  existingAdoptions: strategyAdoptionsSchema,
  requestId: z.string().uuid(),
  reviewId: z.string().uuid(),
  expectedActiveRef: runtimeStrategyRefSchema,
  trusted: z.object({
    actorId: actorIdSchema,
    epoch: z.string().uuid(),
    adoptedAt: z.string().datetime(),
  }).strict(),
}).strict();

type FailureCode =
  | "invalid_input"
  | "management_role_required"
  | "stale_context"
  | "conflict"
  | "review_not_found"
  | "invalid_review_target"
  | "stale_base";

export type StrategyAdoptionDecision =
  | {
    readonly ok: true;
    readonly adoption: StrategyAdoption;
    readonly targetVersion: RuntimeStrategyVersion;
    readonly activeStrategyRef: { readonly strategy_id: string; readonly strategy_version_id: string };
    readonly idempotent: boolean;
  }
  | { readonly ok: false; readonly code: FailureCode };

function sameStrategy(
  left: { readonly strategy_id: string; readonly strategy_version_id: string },
  right: { readonly strategy_id: string; readonly strategy_version_id: string },
): boolean {
  return left.strategy_id === right.strategy_id && left.strategy_version_id === right.strategy_version_id;
}

function hasExactReviewedContent(
  version: RuntimeStrategyVersion,
  review: z.infer<typeof strategyReviewSchema>,
  digestCanonical: CanonicalDigest,
): boolean {
  const content = {
    strategy_version_id: version.strategy_version_id,
    strategy_id: version.strategy_id,
    version: version.version,
    objective: version.objective,
    review_question: version.review_question,
    parent_version_id: version.parent_version_id,
    execution_criteria: version.execution_criteria,
    constraints: version.constraints,
    created_by: version.created_by,
    created_at: version.created_at,
    origin: version.origin,
  };
  try {
    return version.objective === review.proposedChanges.objective
      && version.review_question === review.proposedChanges.review_question
      && canonicalSerialize(version.execution_criteria) === canonicalSerialize(review.proposedChanges.execution_criteria)
      && canonicalSerialize(version.constraints) === canonicalSerialize(review.proposedChanges.constraints)
      && version.created_by === review.reviewerActorId
      && version.created_at === review.reviewedAt
      && version.origin === "management"
      && version.content_hash === digestCanonical(canonicalSerialize(content));
  } catch {
    return false;
  }
}

export function decideStrategyAdoption(
  rawInput: unknown,
  digestCanonical: CanonicalDigest,
): StrategyAdoptionDecision {
  const parsed = inputSchema.safeParse(rawInput);
  if (!parsed.success || typeof digestCanonical !== "function") return { ok: false, code: "invalid_input" };
  const input = parsed.data;
  if (input.trusted.actorId !== "management-demo") return { ok: false, code: "management_role_required" };
  if (input.trusted.epoch !== input.state.currentEpoch) return { ok: false, code: "stale_context" };

  const prior = input.existingAdoptions.find((adoption) => adoption.id === input.requestId);
  if (prior) {
    if (prior.epoch !== input.trusted.epoch
      || prior.reviewId !== input.reviewId
      || !sameStrategy(prior.fromRef, input.expectedActiveRef)) {
      return { ok: false, code: "conflict" };
    }
    const targetVersion = input.state.strategyVersions.find((version) => sameStrategy(version, prior.toRef));
    if (!targetVersion) return { ok: false, code: "invalid_review_target" };
    return {
      ok: true,
      adoption: prior,
      targetVersion,
      activeStrategyRef: input.state.activeStrategyRef,
      idempotent: true,
    };
  }

  if (!sameStrategy(input.state.activeStrategyRef, input.expectedActiveRef)) {
    return { ok: false, code: "stale_base" };
  }
  const review = input.existingReviews.find((candidate) => candidate.id === input.reviewId);
  if (!review) return { ok: false, code: "review_not_found" };
  if (review.epoch !== input.trusted.epoch) return { ok: false, code: "stale_context" };
  const resultingStrategyRef = review.resultingStrategyRef;
  if (review.reviewerActorId !== "management-demo"
    || review.decision !== "create_new_version"
    || resultingStrategyRef === null
    || !sameStrategy(review.baseStrategyRef, input.expectedActiveRef)) {
    return { ok: false, code: "invalid_review_target" };
  }
  const targetVersion = input.state.strategyVersions.find((version) =>
    resultingStrategyRef !== null && sameStrategy(version, resultingStrategyRef));
  if (!targetVersion
    || targetVersion.parent_version_id !== review.baseStrategyRef.strategy_version_id
    || targetVersion.strategy_id !== review.baseStrategyRef.strategy_id
    || !hasExactReviewedContent(targetVersion, review, digestCanonical)
    || resultingStrategyRef === null
    || input.existingAdoptions.some((adoption) => sameStrategy(adoption.toRef, resultingStrategyRef))) {
    return { ok: false, code: "invalid_review_target" };
  }

  const adoption = strategyAdoptionSchema.parse({
    id: input.requestId,
    epoch: input.trusted.epoch,
    reviewId: review.id,
    fromRef: input.expectedActiveRef,
    toRef: resultingStrategyRef,
    actorId: input.trusted.actorId,
    adoptedAt: input.trusted.adoptedAt,
  });
  return {
    ok: true,
    adoption,
    targetVersion,
    activeStrategyRef: adoption.toRef,
    idempotent: false,
  };
}
