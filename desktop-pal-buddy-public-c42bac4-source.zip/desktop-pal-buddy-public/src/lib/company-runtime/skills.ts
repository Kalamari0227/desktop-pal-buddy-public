import { z } from "zod";
import {
  assessOrderPriority,
  reviewProductionReadiness,
  type PriorityAssessment,
  type ProductionReadinessAssessment,
} from "./assessment";
import type { CompanyState, SkillDescriptor, SkillRef } from "./contracts";
import { REGISTERED_SKILLS } from "./fixtures";
import { companyStateSchema } from "./schemas";

export type RegisteredSkillResult = PriorityAssessment | ProductionReadinessAssessment;

export type SkillDispatchResult =
  | { ok: true; status: "proposed" | "already_satisfied" | "needs_review"; skillRef: SkillRef; result: RegisteredSkillResult; mutationCount: 0 }
  | { ok: false; status: "blocked"; skillRef?: SkillRef; reason: string; mutationCount: 0 };

const text = z.string().trim().min(1);
const skillRefSchema = z.object({ id: text, version: z.number().int().positive() }).strict();
const invocationSchema = z.object({
  skillRef: skillRefSchema,
  connectorId: text,
  capabilities: z.array(text),
  policyVersion: text,
  inputSchemaVersion: z.number().int().positive(),
  outputSchemaVersion: z.number().int().positive(),
  state: z.unknown(),
  input: z.unknown(),
}).strict();
const prioritySkillInputSchema = z.object({
  orderId: text,
  planId: text,
  proposedPriority: z.number().int().min(1).max(9),
  aiCandidate: z.unknown().optional(),
}).strict();
const readinessSkillInputSchema = z.object({
  orderId: text,
  planId: text,
}).strict();

function sameList(left: readonly string[], right: readonly string[]): boolean {
  return left.length === right.length && left.every((item, index) => item === right[index]);
}

function sameDescriptor(left: SkillDescriptor, right: SkillDescriptor): boolean {
  return left.id === right.id
    && left.version === right.version
    && left.inputSchemaVersion === right.inputSchemaVersion
    && left.outputSchemaVersion === right.outputSchemaVersion
    && left.policyVersion === right.policyVersion
    && left.reviewState === right.reviewState
    && sameList(left.requiredCapabilities, right.requiredCapabilities)
    && sameList(left.allowedConnectorIds, right.allowedConnectorIds);
}

function registeredStateDescriptor(state: CompanyState, canonical: SkillDescriptor): boolean {
  const stored = state.skills.find((skill) => skill.id === canonical.id && skill.version === canonical.version);
  return stored !== undefined && sameDescriptor(stored, canonical);
}

function blocked(reason: string, skillRef?: SkillRef): SkillDispatchResult {
  return { ok: false, status: "blocked", skillRef, reason, mutationCount: 0 };
}

/**
 * Dispatches only the three code-defined virtual-business skills. It never registers a model
 * suggestion, calls a provider, mutates the ledger, or turns an assessment into approval.
 */
export function dispatchRegisteredSkill(invocation: unknown): SkillDispatchResult {
  const parsed = invocationSchema.safeParse(invocation);
  if (!parsed.success) return blocked("invalid_invocation");
  const request = parsed.data;
  const canonical = REGISTERED_SKILLS.find((skill) => skill.id === request.skillRef.id && skill.version === request.skillRef.version);
  if (!canonical) return blocked("unregistered_skill", request.skillRef);
  if (canonical.reviewState !== "approved") return blocked("unreviewed_skill", request.skillRef);
  if (request.inputSchemaVersion !== canonical.inputSchemaVersion || request.outputSchemaVersion !== canonical.outputSchemaVersion) {
    return blocked("schema_version_mismatch", request.skillRef);
  }
  if (request.policyVersion !== canonical.policyVersion) return blocked("policy_version_mismatch", request.skillRef);
  if (!canonical.allowedConnectorIds.includes(request.connectorId)) return blocked("unregistered_connector", request.skillRef);
  if (!canonical.requiredCapabilities.every((capability) => request.capabilities.includes(capability))) {
    return blocked("missing_capability", request.skillRef);
  }
  const parsedState = companyStateSchema.safeParse(request.state);
  if (!parsedState.success) return blocked("invalid_state", request.skillRef);
  if (!registeredStateDescriptor(parsedState.data, canonical)) return blocked("unregistered_skill_state", request.skillRef);

  const result = canonical.id === "review-production-readiness"
    ? (() => {
      const input = readinessSkillInputSchema.safeParse(request.input);
      return input.success ? reviewProductionReadiness({ state: parsedState.data, ...input.data }) : undefined;
    })()
    : (() => {
      const input = prioritySkillInputSchema.safeParse(request.input);
      return input.success ? assessOrderPriority({ state: parsedState.data, ...input.data }) : undefined;
    })();
  if (!result) return blocked("invalid_input", request.skillRef);
  if (result.status === "blocked") return blocked(result.reason ?? "assessment_blocked", request.skillRef);
  return { ok: true, status: result.status, skillRef: request.skillRef, result, mutationCount: 0 };
}
