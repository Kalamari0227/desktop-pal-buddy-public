import type { ActionIntent, ObjectVersionRef } from "./contracts";
import {
  actionIntentDigestInputSchema,
  actionIntentSchema,
  objectVersionRefSchema,
} from "./schemas";

export type ActionIntentDigestInput = Omit<ActionIntent, "proposalDigest">;
export type CanonicalDigest = (canonicalInput: string) => string;

const digestPattern = /^[a-f0-9]{64}$/;

function compareObjectVersion(left: ObjectVersionRef, right: ObjectVersionRef): number {
  return (left.kind < right.kind ? -1 : left.kind > right.kind ? 1 : 0)
    || (left.id < right.id ? -1 : left.id > right.id ? 1 : 0)
    || left.version - right.version;
}

/** Normalizes the exact version tuples used by proposal and approval digest boundaries. */
export function canonicalizeReadSet(input: unknown): ObjectVersionRef[] {
  if (!Array.isArray(input)) throw new Error("invalid_read_set");
  const normalized = input.map((item) => objectVersionRefSchema.parse(item)).sort(compareObjectVersion);
  const keys = normalized.map((item) => `${item.kind}\u0000${item.id}\u0000${item.version}`);
  if (new Set(keys).size !== keys.length) throw new Error("duplicate_read_set_entry");
  return normalized;
}

function canonicalValue(value: unknown): string {
  if (value === null || typeof value === "string" || typeof value === "boolean") {
    return JSON.stringify(value);
  }
  if (typeof value === "number") {
    if (!Number.isFinite(value)) throw new Error("non_finite_canonical_number");
    return JSON.stringify(value);
  }
  if (Array.isArray(value)) return `[${value.map(canonicalValue).join(",")}]`;
  if (typeof value === "object") {
    const prototype = Object.getPrototypeOf(value);
    if (prototype !== Object.prototype && prototype !== null) throw new Error("unsupported_canonical_object");
    const record = value as Record<string, unknown>;
    const keys = Object.keys(record).sort();
    return `{${keys.map((key) => `${JSON.stringify(key)}:${canonicalValue(record[key])}`).join(",")}}`;
  }
  throw new Error("unsupported_canonical_value");
}

/** The single UTF-8 JSON representation Electron main must feed to SHA-256. */
export function canonicalSerialize(value: unknown): string {
  return canonicalValue(value);
}

export function canonicalizeReadSetDigestInput(readSet: unknown): string {
  return canonicalSerialize(canonicalizeReadSet(readSet));
}

export function canonicalizeActionIntentDigestInput(input: unknown): string {
  if (typeof input !== "object" || input === null || Array.isArray(input)) throw new Error("invalid_intent_digest_input");
  const { proposalDigest: _proposalDigest, ...candidate } = input as Record<string, unknown>;
  const normalized = {
    ...candidate,
    readSet: canonicalizeReadSet(candidate.readSet),
    evidenceRefs: Array.isArray(candidate.evidenceRefs)
      ? [...candidate.evidenceRefs].sort()
      : candidate.evidenceRefs,
  };
  const parsed = actionIntentDigestInputSchema.parse(normalized);
  return canonicalSerialize(parsed);
}

/**
 * Finalizes an intent with a digest computed by trusted Electron main. Renderer data must never
 * supply this callback or its result as authority; this pure bundle only normalizes and validates.
 */
export function finalizeActionIntent(
  input: ActionIntentDigestInput,
  digestCanonical: CanonicalDigest,
): ActionIntent {
  const canonicalInput = canonicalizeActionIntentDigestInput(input);
  const proposalDigest = digestCanonical(canonicalInput);
  if (!digestPattern.test(proposalDigest)) throw new Error("invalid_proposal_digest");
  const intent = actionIntentSchema.parse({ ...input, proposalDigest });
  intent.readSet.forEach(Object.freeze);
  Object.freeze(intent.readSet);
  Object.freeze(intent.strategyRef);
  Object.freeze(intent.skillRef);
  Object.freeze(intent.evidenceRefs);
  return Object.freeze(intent);
}
