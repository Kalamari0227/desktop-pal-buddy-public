import { z } from "zod";
import type {
  CompanyState,
  Inspection,
  InventoryItem,
  ObjectKind,
  ProductionPlan,
  SalesOrder,
  Shipment,
} from "./contracts";
import { companyStateSchema, learningReuseRequiredCheckSchema } from "./schemas";

export interface AssessmentSource {
  kind: ObjectKind;
  id: string;
  version: number;
  evidenceId: string;
}

export interface DepartmentContribution {
  facts: string[];
  unknowns: string[];
}

export interface PriorityAssessment {
  status: "proposed" | "already_satisfied" | "blocked";
  reason?: string;
  sources: AssessmentSource[];
  requiredKg?: number;
  availableKg?: number;
  beforeOrder?: string[];
  proposedOrder?: string[];
  displacedPlanIds?: string[];
  delivery?: { status: "unknown"; reasons: string[] };
  departments?: { sales: DepartmentContribution; production: DepartmentContribution };
  mutationCount: 0;
}

export interface ProductionReadinessAssessment {
  status: "needs_review" | "blocked";
  reason?: string;
  sources: AssessmentSource[];
  baselineSources: AssessmentSource[];
  additionalSources: AssessmentSource[];
  requiredChecks: Array<z.infer<typeof learningReuseRequiredCheckSchema>>;
  requiredKg?: number;
  availableKg?: number;
  departments?: { sales: DepartmentContribution; production: DepartmentContribution };
  mutationCount: 0;
}

const idSchema = z.string().trim().min(1);
const prioritySchema = z.number().int().min(1).max(9);
const citationSchema = z.object({
  kind: z.enum(["customer", "sales_opportunity", "quote", "sales_order", "inventory", "production_plan", "inspection", "shipment"]),
  id: idSchema,
  version: z.number().int().positive(),
  evidenceId: idSchema,
}).strict();
const aiCandidateSchema = z.object({
  orderId: idSchema,
  planId: idSchema,
  proposedPriority: prioritySchema,
  citations: z.array(citationSchema).min(1),
}).strict();
const priorityAssessmentInputSchema = z.object({
  state: z.unknown(),
  orderId: idSchema,
  planId: idSchema,
  proposedPriority: prioritySchema,
  aiCandidate: aiCandidateSchema.optional(),
}).strict();
const readinessInputSchema = z.object({
  state: z.unknown(),
  orderId: idSchema,
  planId: idSchema,
  requiredChecks: z.array(learningReuseRequiredCheckSchema).max(2).default([]),
}).strict().superRefine((value, context) => {
  if (new Set(value.requiredChecks).size !== value.requiredChecks.length) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "required checks must be unique" });
  }
});

function evidenceId(kind: ObjectKind, id: string, version: number): string {
  return `evidence:${kind}:${id}:v${version}`;
}

function source(kind: ObjectKind, item: { id: string; version: number }): AssessmentSource {
  return { kind, id: item.id, version: item.version, evidenceId: evidenceId(kind, item.id, item.version) };
}

function sortSources(sources: AssessmentSource[]): AssessmentSource[] {
  return [...sources].sort((left, right) =>
    left.kind.localeCompare(right.kind)
    || left.id.localeCompare(right.id)
    || left.version - right.version);
}

function blockedPriority(reason: string, sources: AssessmentSource[] = []): PriorityAssessment {
  return { status: "blocked", reason, sources: sortSources(sources), mutationCount: 0 };
}

function blockedReadiness(
  reason: string,
  baselineSources: AssessmentSource[] = [],
  additionalSources: AssessmentSource[] = [],
  requiredChecks: Array<z.infer<typeof learningReuseRequiredCheckSchema>> = [],
): ProductionReadinessAssessment {
  return {
    status: "blocked",
    reason,
    sources: sortSources([...baselineSources, ...additionalSources]),
    baselineSources: sortSources(baselineSources),
    additionalSources: sortSources(additionalSources),
    requiredChecks: [...requiredChecks],
    mutationCount: 0,
  };
}

function priorityOrder(plans: readonly ProductionPlan[], targetPlanId?: string, proposedPriority?: number): string[] {
  return plans
    .map((plan) => plan.id === targetPlanId && proposedPriority !== undefined ? { ...plan, priority: proposedPriority } : plan)
    .sort((left, right) => left.priority - right.priority || left.id.localeCompare(right.id))
    .map((plan) => plan.id);
}

function planSources(plans: readonly ProductionPlan[]): AssessmentSource[] {
  return plans.map((plan) => source("production_plan", plan));
}

function candidateCitationsAreGrounded(
  candidate: z.infer<typeof aiCandidateSchema> | undefined,
  expected: readonly AssessmentSource[],
): boolean {
  if (!candidate) return true;
  const expectedKeys = new Set(expected.map((item) => `${item.kind}\u0000${item.id}\u0000${item.version}\u0000${item.evidenceId}`));
  const candidateKeys = candidate.citations.map((item) => `${item.kind}\u0000${item.id}\u0000${item.version}\u0000${item.evidenceId}`);
  return candidateKeys.length === expectedKeys.size
    && new Set(candidateKeys).size === candidateKeys.length
    && candidateKeys.every((key) => expectedKeys.has(key));
}

function targetRecords(state: CompanyState, orderId: string, planId: string): {
  order?: SalesOrder;
  plan?: ProductionPlan;
  inspection?: Inspection;
  shipment?: Shipment;
  inventory: InventoryItem[];
} {
  const order = state.salesOrders.find((item) => item.id === orderId);
  const plan = state.productionPlans.find((item) => item.id === planId);
  return {
    order,
    plan,
    inspection: state.inspections.find((item) => item.orderId === orderId),
    shipment: state.shipments.find((item) => item.orderId === orderId),
    inventory: plan ? state.inventory.filter((item) => item.materialId === plan.materialId) : [],
  };
}

function explainDepartments(order: SalesOrder, plan: ProductionPlan, availableKg: number): { sales: DepartmentContribution; production: DepartmentContribution } {
  return {
    sales: {
      facts: [`${order.id} requires ${order.quantityKg}kg of ${order.materialId}.`],
      unknowns: ["No promised delivery date is present in the virtual ledger."],
    },
    production: {
      facts: [`${plan.id} is ${plan.status} at priority ${plan.priority}; ${availableKg}kg is available for ${plan.materialId}.`],
      unknowns: ["The virtual ledger has no production capacity or line-time record."],
    },
  };
}

/**
 * Performs a deterministic, read-only assessment for the fixed priority-change scenario.
 * It deliberately records uncertainty rather than making a delivery promise.
 */
export function assessOrderPriority(input: unknown): PriorityAssessment {
  const parsedInput = priorityAssessmentInputSchema.safeParse(input);
  if (!parsedInput.success) return blockedPriority("invalid_input");
  const parsedState = companyStateSchema.safeParse(parsedInput.data.state);
  if (!parsedState.success) return blockedPriority("invalid_state");

  const { orderId, planId, proposedPriority, aiCandidate } = parsedInput.data;
  const state = parsedState.data;
  const records = targetRecords(state, orderId, planId);
  if (!records.order) return blockedPriority("missing_sales_order");
  if (!records.plan) return blockedPriority("missing_production_plan", [source("sales_order", records.order)]);
  if (records.plan.orderId !== records.order.id || records.plan.materialId !== records.order.materialId || records.plan.requiredKg !== records.order.quantityKg) {
    return blockedPriority("invalid_plan_order_link", [source("sales_order", records.order), source("production_plan", records.plan)]);
  }
  if (!records.inspection) return blockedPriority("missing_inspection", [source("sales_order", records.order), source("production_plan", records.plan)]);
  if (!records.shipment) return blockedPriority("missing_shipment", [source("sales_order", records.order), source("production_plan", records.plan), source("inspection", records.inspection)]);
  if (records.inventory.length === 0) return blockedPriority("missing_inventory", [source("sales_order", records.order), source("production_plan", records.plan)]);

  const groupPlans = state.productionPlans.filter((item) => item.productionGroupId === records.plan!.productionGroupId);
  const sources = sortSources([
    source("sales_order", records.order),
    ...records.inventory.map((item) => source("inventory", item)),
    ...planSources(groupPlans),
    source("inspection", records.inspection),
    source("shipment", records.shipment),
  ]);
  if (aiCandidate && (aiCandidate.orderId !== orderId || aiCandidate.planId !== planId || aiCandidate.proposedPriority !== proposedPriority)) {
    return blockedPriority("invalid_ai_candidate", sources);
  }
  if (!candidateCitationsAreGrounded(aiCandidate, sources)) return blockedPriority("invalid_ai_citations", sources);
  if (records.plan.priority === proposedPriority) {
    return { status: "already_satisfied", reason: "already_satisfied", sources, mutationCount: 0 };
  }
  const availableKg = records.inventory.reduce((total, item) => total + item.availableKg, 0);
  if (availableKg < records.plan.requiredKg) return blockedPriority("insufficient_inventory", sources);
  if (records.plan.qualityHold) return blockedPriority("quality_hold", sources);
  if (records.plan.status !== "queued") return blockedPriority("plan_not_queued", sources);

  const beforeOrder = priorityOrder(groupPlans);
  const proposedOrder = priorityOrder(groupPlans, records.plan.id, proposedPriority);
  const displacedPlanIds = groupPlans
    .filter((plan) => plan.id !== records.plan!.id && proposedOrder.indexOf(plan.id) > beforeOrder.indexOf(plan.id))
    .sort((left, right) => proposedOrder.indexOf(left.id) - proposedOrder.indexOf(right.id))
    .map((plan) => plan.id);
  const departments = explainDepartments(records.order, records.plan, availableKg);
  return {
    status: "proposed",
    sources,
    requiredKg: records.plan.requiredKg,
    availableKg,
    beforeOrder,
    proposedOrder,
    displacedPlanIds,
    delivery: {
      status: "unknown",
      reasons: ["Inspection and shipment records were read, but neither establishes a promised delivery date."],
    },
    departments,
    mutationCount: 0,
  };
}

/**
 * Baseline read-only readiness assessment. Inspection and shipment are intentionally not
 * read here; later consented sharing can explicitly expand this read set.
 */
export function reviewProductionReadiness(input: unknown): ProductionReadinessAssessment {
  const parsedInput = readinessInputSchema.safeParse(input);
  if (!parsedInput.success) return blockedReadiness("invalid_input");
  const parsedState = companyStateSchema.safeParse(parsedInput.data.state);
  if (!parsedState.success) return blockedReadiness("invalid_state");

  const { orderId, planId, requiredChecks } = parsedInput.data;
  const state = parsedState.data;
  const order = state.salesOrders.find((item) => item.id === orderId);
  if (!order) return blockedReadiness("missing_sales_order");
  const plan = state.productionPlans.find((item) => item.id === planId);
  if (!plan) return blockedReadiness("missing_production_plan", [source("sales_order", order)], [], requiredChecks);
  if (plan.orderId !== order.id || plan.materialId !== order.materialId || plan.requiredKg !== order.quantityKg) {
    return blockedReadiness("invalid_plan_order_link", [source("sales_order", order), source("production_plan", plan)], [], requiredChecks);
  }
  const inventory = state.inventory.filter((item) => item.materialId === plan.materialId);
  if (inventory.length === 0) return blockedReadiness("missing_inventory", [source("sales_order", order), source("production_plan", plan)], [], requiredChecks);

  const baselineSources = sortSources([
    source("sales_order", order),
    source("production_plan", plan),
    ...inventory.map((item) => source("inventory", item)),
  ]);
  const additionalSources: AssessmentSource[] = [];
  const reasons: string[] = [];
  if (requiredChecks.includes("inspection")) {
    const inspection = state.inspections.find((item) => item.orderId === orderId);
    if (!inspection) return blockedReadiness("missing_inspection", baselineSources, additionalSources, requiredChecks);
    additionalSources.push(source("inspection", inspection));
    if (inspection.status !== "passed") reasons.push(`inspection_${inspection.status}`);
  }
  if (requiredChecks.includes("packaging")) {
    const shipment = state.shipments.find((item) => item.orderId === orderId);
    if (!shipment) return blockedReadiness("missing_shipment", baselineSources, additionalSources, requiredChecks);
    additionalSources.push(source("shipment", shipment));
    if (shipment.status !== "ready" || shipment.packagingStatus !== "ready") reasons.push("packaging_not_ready");
  }
  const sources = sortSources([...baselineSources, ...additionalSources]);
  const availableKg = inventory.reduce((total, item) => total + item.availableKg, 0);
  const departments = explainDepartments(order, plan, availableKg);
  return {
    status: "needs_review",
    reason: availableKg < plan.requiredKg
      ? "insufficient_inventory"
      : requiredChecks.length === 0
        ? "inspection_and_shipment_not_read"
        : reasons.length > 0
          ? reasons.join("_and_")
          : "delivery_date_unobserved",
    sources,
    baselineSources,
    additionalSources: sortSources(additionalSources),
    requiredChecks: [...requiredChecks],
    requiredKg: plan.requiredKg,
    availableKg,
    departments,
    mutationCount: 0,
  };
}
