import { describe, expect, it } from "vitest";
import { createInitialCompanyState } from "./fixtures";
import { canonicalSerialize } from "./transitions";
import { decideStrategyReview, replayStrategyReview } from "./strategyReview";

const epoch = "f7091d6f-e310-46f5-ae2f-a761f136f36a";
const baseVersionId = "f6846f3d-1aa0-487a-88a1-c383ba9076ea";
const reviewId = "04d83596-3b4b-4b02-963f-2f0b41110312";
const nextVersionId = "194d29ef-806c-4e11-8ca8-485d75812fed";
const reviewedAt = "2026-09-19T05:00:00.000Z";
const digest = (value: string) => value.length.toString(16).padStart(64, "0");

function baseInput(decision: "maintain" | "create_new_version") {
  const state = createInitialCompanyState({
    epoch,
    strategyVersionId: baseVersionId,
    createdAt: "2026-09-19T00:00:00.000Z",
    strategyContentHash: "a".repeat(64),
  });
  return {
    requestId: reviewId,
    state,
    existingReviews: [],
    decision,
    baseStrategyRef: state.activeStrategyRef,
    expectedBaseVersion: 1,
    evidenceSnapshot: [{
      kind: "assessment",
      id: "8a3e281c-731e-457e-a456-e77c50f4be51",
      version: 1,
      contentHash: "b".repeat(64),
      visibilityScope: "official",
    }],
    uncertainties: ["검사 완료 시점은 아직 확인되지 않았습니다."],
    proposedChanges: {
      objective: "준비 상태를 확인한 뒤 납기를 판단",
      review_question: "검사와 포장 상태가 확인되었는가?",
      execution_criteria: ["검사와 포장 상태를 함께 확인"],
      constraints: ["미확인 상태에서 납기를 확약하지 않음"],
    },
    reviewerActorId: "management-demo" as const,
    reviewedAt,
    nextStrategyVersionId: decision === "create_new_version" ? nextVersionId : null,
  };
}

describe("strategy review decision", () => {
  it("records a maintain decision without creating a strategy version", () => {
    // Given: management reviews one bounded official evidence snapshot against active v1.
    const input = baseInput("maintain");

    // When: management explicitly maintains the strategy.
    const result = decideStrategyReview(input, digest);

    // Then: the review is immutable and no version is produced.
    expect(result).toEqual({
      ok: true,
      review: expect.objectContaining({
        id: reviewId,
        decision: "maintain",
        resultingStrategyRef: null,
      }),
      version: null,
      idempotent: false,
    });
  });

  it("creates exactly v2 with parent v1 and a canonical content hash", () => {
    // Given: an explicit create decision based on active v1.
    const input = baseInput("create_new_version");

    // When: the strategy review is decided.
    const result = decideStrategyReview(input, digest);

    // Then: one management version is linked to v1 and hashes its immutable content.
    expect(result.ok).toBe(true);
    if (!result.ok || result.version === null) throw new Error("strategy version missing");
    const { content_hash: contentHash, ...content } = result.version;
    expect(result.version).toMatchObject({
      strategy_version_id: nextVersionId,
      strategy_id: "STRATEGY-DEMO-PRODUCTION",
      version: 2,
      parent_version_id: baseVersionId,
      created_by: "management-demo",
      created_at: reviewedAt,
      origin: "management",
    });
    expect(contentHash).toBe(digest(canonicalSerialize(content)));
    expect(result.review.resultingStrategyRef).toEqual({
      strategy_id: "STRATEGY-DEMO-PRODUCTION",
      strategy_version_id: nextVersionId,
    });
  });

  it("allocates distinct increasing numbers to independent reviews from the same v1 base", () => {
    // Break caught: two reviews based on v1 could both produce the ambiguous numeric version 2.
    const first = decideStrategyReview(baseInput("create_new_version"), digest);
    if (!first.ok || first.version === null) throw new Error("first strategy version missing");
    const secondInput = baseInput("create_new_version");
    const second = decideStrategyReview({
      ...secondInput,
      requestId: "64c462af-612d-4eb1-8910-52f3eabb935d",
      nextStrategyVersionId: "fe99db5c-75a0-4698-93a2-8a3fde1148c8",
      state: {
        ...secondInput.state,
        strategyVersions: [...secondInput.state.strategyVersions, first.version],
      },
      existingReviews: [first.review],
      proposedChanges: { ...secondInput.proposedChanges, objective: "두 번째 독립 검토 목표" },
    }, digest);

    expect(second.ok).toBe(true);
    if (!second.ok || second.version === null) throw new Error("second strategy version missing");
    expect([first.version.version, second.version.version]).toEqual([2, 3]);
    expect(second.version.parent_version_id).toBe(baseVersionId);
  });

  it("rejects a new strategy version UUID that is already stored", () => {
    // Given: a new review command reuses the immutable UUID of stored v1.
    const input = baseInput("create_new_version");

    // When: management attempts to create the reviewed version.
    const result = decideStrategyReview({ ...input, nextStrategyVersionId: baseVersionId }, digest);

    // Then: no review or ambiguous version is returned.
    expect(result).toEqual({ ok: false, code: "invalid_input" });
  });

  it("returns the original result for the same request and rejects a changed duplicate", () => {
    // Given: one persisted v2 review.
    const first = decideStrategyReview(baseInput("create_new_version"), digest);
    if (!first.ok || first.version === null) throw new Error("fixture review missing");
    const retryInput = {
      ...baseInput("create_new_version"),
      state: {
        ...baseInput("create_new_version").state,
        strategyVersions: [...baseInput("create_new_version").state.strategyVersions, first.version],
        activeStrategyRef: first.review.resultingStrategyRef ?? baseInput("create_new_version").state.activeStrategyRef,
      },
      existingReviews: [first.review],
      nextStrategyVersionId: crypto.randomUUID(),
    };

    // When: the exact request is retried, then reused with changed content.
    const retry = decideStrategyReview(retryInput, digest);
    const changed = decideStrategyReview({
      ...retryInput,
      uncertainties: ["다른 불확실성"],
    }, digest);

    // Then: retry returns v2, while request-id reuse fails closed.
    expect(retry).toEqual({ ok: true, review: first.review, version: first.version, idempotent: true });
    expect(changed).toEqual({ ok: false, code: "duplicate_request" });
  });

  it("replays a persisted request from bounded references without resolving live evidence again", () => {
    // Given: a persisted review whose source evidence can no longer be read from the live projection.
    const first = decideStrategyReview(baseInput("create_new_version"), digest);
    if (!first.ok || first.version === null) throw new Error("fixture review missing");
    const replayInput = {
      requestId: reviewId,
      existingReviews: [first.review],
      strategyVersions: [...baseInput("create_new_version").state.strategyVersions, first.version],
      decision: first.review.decision,
      baseStrategyRef: first.review.baseStrategyRef,
      expectedBaseVersion: 1,
      evidenceRefs: first.review.evidenceSnapshot.map(({ kind, id, version }) => ({ kind, id, version })),
      uncertainties: first.review.uncertainties,
      proposedChanges: first.review.proposedChanges,
      reviewerActorId: first.review.reviewerActorId,
    };

    // When: the exact command is replayed and the same request id is reused with changed content.
    const replayed = replayStrategyReview(replayInput);
    const changed = replayStrategyReview({
      ...replayInput,
      proposedChanges: { ...replayInput.proposedChanges, objective: "변경된 목표" },
    });

    // Then: the stored result is returned without live evidence, while mismatched reuse fails closed.
    expect(replayed).toEqual({ ok: true, review: first.review, version: first.version, idempotent: true });
    expect(changed).toEqual({ ok: false, code: "duplicate_request" });
  });

  it.each([
    ["non-management reviewer", { reviewerActorId: "sales-demo" }, "management_role_required"],
    ["stale base version", { expectedBaseVersion: 0 }, "invalid_input"],
    ["cross-strategy base", { baseStrategyRef: { strategy_id: "OTHER", strategy_version_id: baseVersionId } }, "stale_base"],
    ["fabricated evidence hash", { evidenceSnapshot: [{ kind: "assessment", id: "x", version: 1, contentHash: "forged", visibilityScope: "official" }] }, "invalid_input"],
    ["empty criteria", { proposedChanges: { ...baseInput("create_new_version").proposedChanges, execution_criteria: [] } }, "invalid_input"],
  ])("rejects %s", (_name, patch, code) => {
    // Given: a malformed or unauthorized create request.
    const input = { ...baseInput("create_new_version"), ...patch };

    // When: the decision is evaluated.
    const result = decideStrategyReview(input, digest);

    // Then: no review or version is returned.
    expect(result).toEqual({ ok: false, code });
  });
});
