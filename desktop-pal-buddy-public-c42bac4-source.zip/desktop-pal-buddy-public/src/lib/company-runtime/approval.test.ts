import { describe, expect, it } from "vitest";
import type { ActionIntent, Approval, CompanyState, Execution } from "./contracts";
import { createInitialCompanyState } from "./fixtures";
import { createActionProposal, reviseActionProposal } from "./policy";
import { canonicalizeReadSetDigestInput } from "./transitions";

const seed = {
  epoch: "85c540f3-5e30-4f65-9e30-4f65e2c782a2",
  strategyVersionId: "266cae99-24da-4595-95ed-c2c782a20417",
  createdAt: "2026-09-18T00:00:00.000Z",
  strategyContentHash: "a".repeat(64),
} as const;

const approvalId = "1b66c3ce-2174-45b2-8617-8d7243663790";
const executionId = "a33f7475-4a30-4923-a6b3-303e0dd92945";
const decidedAt = "2026-09-18T02:00:00.000Z";

function testDigest(value: string): string {
  let accumulator = 0x811c9dc5;
  for (const character of value) {
    accumulator ^= character.charCodeAt(0);
    accumulator = Math.imul(accumulator, 0x01000193);
  }
  return (accumulator >>> 0).toString(16).padStart(8, "0").repeat(8);
}

function state(): CompanyState {
  return createInitialCompanyState(seed);
}

function intent(currentState = state()): ActionIntent {
  const result = createActionProposal({
    mode: "shadow",
    state: currentState,
    orderId: "SO-DEMO-1001",
    targetPlanId: "PP-DEMO-1001",
    toPriority: 1,
    strategyRef: currentState.activeStrategyRef,
    skillRef: { id: "change-production-priority", version: 1 },
    policyVersion: "company-policy-v1",
    trusted: {
      intentId: "a711eef6-4a2b-4a20-bb6e-552ecbab7258",
      workboardTaskId: "719c1670-0035-437a-8f80-245edb22e99a",
      packetTaskId: "2e03a8e9-c48d-470b-8470-e925965891d2",
      epoch: currentState.currentEpoch,
      requesterActorId: "sales-demo",
      createdAt: "2026-09-18T01:00:00.000Z",
    },
  }, testDigest);
  if (result.status !== "proposed") throw new Error(`unexpected proposal status: ${result.status}`);
  return result.intent;
}

function approved(currentState = state(), currentIntent = intent(currentState)): Approval {
  return {
    id: approvalId,
    intentId: currentIntent.id,
    intentRevision: currentIntent.revision,
    proposalDigest: currentIntent.proposalDigest,
    epoch: currentIntent.epoch,
    readSetDigest: testDigest(canonicalizeReadSetDigestInput(currentIntent.readSet)),
    policyVersion: currentIntent.policyVersion,
    skillRef: currentIntent.skillRef,
    strategyRef: currentIntent.strategyRef,
    requesterActorId: currentIntent.requesterActorId,
    approverActorId: "production-demo",
    decision: "approved",
    decidedAt,
    expiresAt: "2026-09-18T02:15:00.000Z",
    consumedByExecutionId: null,
  };
}

function persistedExecution(currentIntent: ActionIntent, approval: Approval): Execution {
  return {
    id: executionId,
    intentId: currentIntent.id,
    approvalId: approval.id,
    idempotencyKey: `${currentIntent.epoch}:${currentIntent.id}:${currentIntent.proposalDigest}`,
    epoch: currentIntent.epoch,
    mode: "apply",
    state: "applied_pending_readback",
    before: { priority: 5, version: 1 },
    expectedAfter: { priority: 1, version: 2 },
    attempt: 1,
    startedAt: "2026-09-18T02:01:00.000Z",
  };
}

describe("exact-scope human approvals", () => {
  it("PIN accepts an exact v1 intent and approval while v1 is active", async () => {
    // Break caught: the established exact v1 approval path could stop authorizing apply.
    const { evaluateApprovalAuthorization } = await import("./approval");
    const currentState = state();
    const currentIntent = intent(currentState);

    expect(evaluateApprovalAuthorization({
      state: currentState,
      intent: currentIntent,
      approval: approved(currentState, currentIntent),
      persistedExecution: null,
      trusted: { actorId: "production-demo", now: "2026-09-18T02:01:00.000Z" },
    }, testDigest)).toEqual({ status: "apply_authorized", approvalId, intentId: currentIntent.id });
  });

  it("keeps an existing v1 intent authorized after active strategy advances to v2", async () => {
    // Break caught: changing only the active strategy could invalidate a task already pinned to stored v1.
    const { evaluateApprovalAuthorization } = await import("./approval");
    const v1State = state();
    const v1Intent = intent(v1State);
    const v1Approval = approved(v1State, v1Intent);
    const v2Id = "98d84b35-3bdf-4642-b251-f96df1626515";
    const stateWithActiveV2: CompanyState = {
      ...v1State,
      strategyVersions: [...v1State.strategyVersions, {
        ...v1State.strategyVersions[0],
        strategy_version_id: v2Id,
        version: 2,
        parent_version_id: v1State.activeStrategyRef.strategy_version_id,
        origin: "management",
        content_hash: "b".repeat(64),
      }],
      activeStrategyRef: {
        strategy_id: v1State.activeStrategyRef.strategy_id,
        strategy_version_id: v2Id,
      },
    };

    expect(evaluateApprovalAuthorization({
      state: stateWithActiveV2,
      intent: v1Intent,
      approval: v1Approval,
      persistedExecution: null,
      trusted: { actorId: "production-demo", now: "2026-09-18T02:01:00.000Z" },
    }, testDigest)).toEqual({ status: "apply_authorized", approvalId, intentId: v1Intent.id });
  });

  it.each([
    ["expired approval", (s: CompanyState, i: ActionIntent, a: Approval) => ({ state: s, intent: i, approval: a, now: "2026-09-18T02:15:00.001Z" }), "approval_expired"],
    ["revoked approval", (s: CompanyState, i: ActionIntent, a: Approval) => ({ state: s, intent: i, approval: { ...a, decision: "revoked" as const }, now: "2026-09-18T02:01:00.000Z" }), "approval_revoked"],
    ["stale readSet", (s: CompanyState, i: ActionIntent, a: Approval) => ({
      state: { ...s, inventory: s.inventory.map((item) => item.id === "INV-DEMO-GA-ULSAN" ? { ...item, version: 2 } : item) },
      intent: i,
      approval: a,
      now: "2026-09-18T02:01:00.000Z",
    }), "stale_state"],
  ])("PIN rejects %s without changing its established reason", async (_name, arrange, reason) => {
    // Break caught: expiry, revocation, or source-version guards could be weakened while changing strategy binding.
    const { evaluateApprovalAuthorization } = await import("./approval");
    const currentState = state();
    const currentIntent = intent(currentState);
    const fixture = arrange(currentState, currentIntent, approved(currentState, currentIntent));

    expect(evaluateApprovalAuthorization({
      state: fixture.state,
      intent: fixture.intent,
      approval: fixture.approval,
      persistedExecution: null,
      trusted: { actorId: "production-demo", now: fixture.now },
    }, testDigest)).toEqual({ status: "blocked", reason });
  });

  it("rejects sales decisions and records a production approval bound to the exact proposal", async () => {
    // Break caught: renderer role/approved fields or a sales actor could mint runtime execution authority.
    const { decideApproval } = await import("./approval");
    const currentState = state();
    const currentIntent = intent(currentState);

    expect(decideApproval({
      state: currentState,
      intent: currentIntent,
      decision: "approved",
      trusted: { approvalId, actorId: "sales-demo", now: decidedAt },
    }, testDigest)).toEqual({ status: "blocked", reason: "unauthorized_role" });

    const result = decideApproval({
      state: currentState,
      intent: currentIntent,
      decision: "approved",
      trusted: { approvalId, actorId: "production-demo", now: decidedAt },
    }, testDigest);

    expect(result).toEqual({
      status: "recorded",
      approval: approved(currentState, currentIntent),
    });
    expect(result.status === "recorded" && result.approval.requesterActorId).toBe("sales-demo");
  });

  it("rejects malformed authority fields and allows production to reject without creating approval authority", async () => {
    // Break caught: payload-supplied role or approved boolean could override the trusted main actor/decision.
    const { decideApproval, evaluateApprovalAuthorization } = await import("./approval");
    const currentState = state();
    const currentIntent = intent(currentState);

    expect(decideApproval({
      state: currentState,
      intent: currentIntent,
      decision: "approved",
      approved: true,
      role: "production",
      trusted: { approvalId, actorId: "sales-demo", now: decidedAt },
    }, testDigest)).toEqual({ status: "blocked", reason: "invalid_input" });

    const rejected = decideApproval({
      state: currentState,
      intent: currentIntent,
      decision: "rejected",
      trusted: { approvalId, actorId: "production-demo", now: decidedAt },
    }, testDigest);
    expect(rejected.status).toBe("recorded");
    if (rejected.status !== "recorded") throw new Error("expected rejection record");
    expect(evaluateApprovalAuthorization({
      state: currentState,
      intent: currentIntent,
      approval: rejected.approval,
      persistedExecution: null,
      trusted: { actorId: "production-demo", now: "2026-09-18T02:01:00.000Z" },
    }, testDigest)).toEqual({ status: "blocked", reason: "approval_rejected" });
  });

  it.each([
    ["old epoch", (s: CompanyState, i: ActionIntent, a: Approval) => ({ state: { ...s, currentEpoch: "c62ef26d-7ddf-4c11-bf84-2aec79c6e4a6" }, intent: i, approval: a }), "stale_context"],
    ["changed target", (s: CompanyState, i: ActionIntent, a: Approval) => ({ state: s, intent: { ...i, targetPlanId: "PP-DEMO-1002" }, approval: a }), "approval_scope_mismatch"],
    ["changed priority", (s: CompanyState, i: ActionIntent, a: Approval) => ({ state: s, intent: { ...i, toPriority: 2 }, approval: a }), "approval_scope_mismatch"],
    ["changed read set", (s: CompanyState, i: ActionIntent, a: Approval) => ({ state: s, intent: { ...i, readSet: i.readSet.slice(1) }, approval: a }), "approval_scope_mismatch"],
    ["changed strategy", (s: CompanyState, i: ActionIntent, a: Approval) => ({ state: s, intent: { ...i, strategyRef: { ...i.strategyRef, strategy_id: "OTHER" } }, approval: a }), "approval_scope_mismatch"],
    ["changed skill version", (s: CompanyState, i: ActionIntent, a: Approval) => ({ state: s, intent: { ...i, skillRef: { ...i.skillRef, version: 2 } }, approval: a }), "approval_scope_mismatch"],
    ["changed policy", (s: CompanyState, i: ActionIntent, a: Approval) => ({ state: s, intent: { ...i, policyVersion: "company-policy-v2" }, approval: a }), "approval_scope_mismatch"],
  ])("requires reapproval for %s", async (_name, alter, reason) => {
    // Break caught: an approval could drift to a proposal, state epoch, source version, strategy, skill, or policy it never covered.
    const { evaluateApprovalAuthorization } = await import("./approval");
    const currentState = state();
    const currentIntent = intent(currentState);
    const approval = approved(currentState, currentIntent);
    const changed = alter(currentState, currentIntent, approval);

    expect(evaluateApprovalAuthorization({
      ...changed,
      persistedExecution: null,
      trusted: { actorId: "production-demo", now: "2026-09-18T02:01:00.000Z" },
    }, testDigest)).toEqual({ status: "blocked", reason });
  });

  it("revalidates every authoritative read-set version before authorizing apply", async () => {
    // Break caught: a non-target ERP object could change after approval without invalidating it.
    const { evaluateApprovalAuthorization } = await import("./approval");
    const currentState = state();
    const currentIntent = intent(currentState);
    const approval = approved(currentState, currentIntent);
    const changedState = structuredClone(currentState);
    const source = changedState.inventory.find((item) => item.id === "INV-DEMO-GA-ULSAN");
    if (!source) throw new Error("missing fixture inventory");
    source.version += 1;

    expect(evaluateApprovalAuthorization({
      state: changedState,
      intent: currentIntent,
      approval,
      persistedExecution: null,
      trusted: { actorId: "production-demo", now: "2026-09-18T02:01:00.000Z" },
    }, testDigest)).toEqual({ status: "blocked", reason: "stale_state" });
  });

  it("binds approval lookup to intent revision and authorizes a freshly approved revision two", async () => {
    // Break caught: id-only approval lookup could let revision one authorize a revised proposal sharing the same intent ID.
    const { decideApproval, evaluateApprovalAuthorization } = await import("./approval");
    const currentState = state();
    const first = intent(currentState);
    const revised = reviseActionProposal({
      state: currentState,
      previousIntent: first,
      toPriority: 2,
      createdAt: "2026-09-18T01:05:00.000Z",
    }, testDigest);
    if (revised.status !== "proposed") throw new Error(`unexpected revision status: ${revised.status}`);

    expect(evaluateApprovalAuthorization({
      state: currentState,
      intent: revised.intent,
      approval: approved(currentState, first),
      persistedExecution: null,
      trusted: { actorId: "production-demo", now: "2026-09-18T02:01:00.000Z" },
    }, testDigest)).toEqual({ status: "blocked", reason: "approval_scope_mismatch" });

    const decision = decideApproval({
      state: currentState,
      intent: revised.intent,
      decision: "approved",
      trusted: { approvalId, actorId: "production-demo", now: decidedAt },
    }, testDigest);
    if (decision.status !== "recorded") throw new Error(`unexpected approval status: ${decision.status}`);
    expect(decision.approval).toMatchObject({ intentId: first.id, intentRevision: 2 });
    expect(evaluateApprovalAuthorization({
      state: currentState,
      intent: revised.intent,
      approval: decision.approval,
      persistedExecution: null,
      trusted: { actorId: "production-demo", now: "2026-09-18T02:01:00.000Z" },
    }, testDigest)).toEqual({ status: "apply_authorized", approvalId, intentId: first.id });
  });

  it.each([
    ["expired", "2026-09-18T02:15:00.001Z", "approval_expired"],
    ["clock rollback", "2026-09-18T01:59:59.999Z", "clock_rollback"],
  ])("fails closed when the approval clock is %s", async (_name, now, reason) => {
    // Break caught: an expired approval or a rolled-back clock could reopen apply authority.
    const { evaluateApprovalAuthorization } = await import("./approval");
    const currentState = state();
    const currentIntent = intent(currentState);

    expect(evaluateApprovalAuthorization({
      state: currentState,
      intent: currentIntent,
      approval: approved(currentState, currentIntent),
      persistedExecution: null,
      trusted: { actorId: "production-demo", now },
    }, testDigest)).toEqual({ status: "blocked", reason });
  });

  it("caps an extended persisted expiry at fifteen minutes after the decision", async () => {
    // Break caught: changing only persisted expiresAt could extend one approval into blanket future authority.
    const { evaluateApprovalAuthorization } = await import("./approval");
    const currentState = state();
    const currentIntent = intent(currentState);

    expect(evaluateApprovalAuthorization({
      state: currentState,
      intent: currentIntent,
      approval: { ...approved(currentState, currentIntent), expiresAt: "2026-09-18T12:00:00.000Z" },
      persistedExecution: null,
      trusted: { actorId: "production-demo", now: "2026-09-18T02:30:00.000Z" },
    }, testDigest)).toEqual({ status: "blocked", reason: "approval_expired" });
  });

  it("preserves a valid approval across role switches but never grants sales execution", async () => {
    // Break caught: switching roles could revoke the record or let the sales session execute it.
    const { evaluateApprovalAuthorization } = await import("./approval");
    const currentState = state();
    const currentIntent = intent(currentState);
    const approval = approved(currentState, currentIntent);
    const base = { state: currentState, intent: currentIntent, approval, persistedExecution: null };

    expect(evaluateApprovalAuthorization({
      ...base,
      trusted: { actorId: "sales-demo", now: "2026-09-18T02:01:00.000Z" },
    }, testDigest)).toEqual({ status: "blocked", reason: "unauthorized_role" });
    expect(evaluateApprovalAuthorization({
      ...base,
      trusted: { actorId: "production-demo", now: "2026-09-18T02:02:00.000Z" },
    }, testDigest)).toEqual({ status: "apply_authorized", approvalId, intentId: currentIntent.id });
  });

  it("rejects a stored approval whose approver was not production", async () => {
    // Break caught: a structurally valid stored row with a sales approver could be mistaken for human production authority.
    const { evaluateApprovalAuthorization } = await import("./approval");
    const currentState = state();
    const currentIntent = intent(currentState);

    expect(evaluateApprovalAuthorization({
      state: currentState,
      intent: currentIntent,
      approval: { ...approved(currentState, currentIntent), approverActorId: "sales-demo" },
      persistedExecution: null,
      trusted: { actorId: "production-demo", now: "2026-09-18T02:01:00.000Z" },
    }, testDigest)).toEqual({ status: "blocked", reason: "approval_scope_mismatch" });
  });

  it("lets production revoke an approval and blocks it afterward", async () => {
    // Break caught: revocation could be ignored or accepted from a non-production actor.
    const { evaluateApprovalAuthorization, revokeApproval } = await import("./approval");
    const currentState = state();
    const currentIntent = intent(currentState);
    const approval = approved(currentState, currentIntent);

    expect(revokeApproval({
      approval,
      trusted: { actorId: "sales-demo", now: "2026-09-18T02:03:00.000Z" },
    })).toEqual({ status: "blocked", reason: "unauthorized_role" });
    const revoked = revokeApproval({
      approval,
      trusted: { actorId: "production-demo", now: "2026-09-18T03:00:00.000Z" },
    });
    expect(revoked.status).toBe("recorded");
    if (revoked.status !== "recorded") throw new Error("expected revoked record");
    expect(revoked.approval).toMatchObject({ decision: "revoked", approverActorId: "production-demo" });
    expect(evaluateApprovalAuthorization({
      state: currentState,
      intent: currentIntent,
      approval: revoked.approval,
      persistedExecution: null,
      trusted: { actorId: "production-demo", now: "2026-09-18T03:01:00.000Z" },
    }, testDigest)).toEqual({ status: "blocked", reason: "approval_revoked" });
  });

  it("returns readback-only for the persisted consumed execution, including after expiry", async () => {
    // Break caught: recovery could either lose readback or expose a second apply authorization.
    const { evaluateApprovalAuthorization } = await import("./approval");
    const currentState = state();
    const currentIntent = intent(currentState);
    const baseApproval = approved(currentState, currentIntent);
    const approval = { ...baseApproval, consumedByExecutionId: executionId };
    const execution = persistedExecution(currentIntent, approval);

    expect(evaluateApprovalAuthorization({
      state: currentState,
      intent: currentIntent,
      approval,
      persistedExecution: execution,
      trusted: { actorId: "production-demo", now: "2026-09-18T03:00:00.000Z" },
    }, testDigest)).toEqual({
      status: "readback_only",
      approvalId,
      intentId: currentIntent.id,
      executionId,
    });
  });

  it.each([
    ["idempotency digest", (execution: Execution) => ({ ...execution, idempotencyKey: "wrong-key" })],
    ["before priority", (execution: Execution) => ({ ...execution, before: { ...execution.before, priority: 4 } })],
    ["before version", (execution: Execution) => ({ ...execution, before: { ...execution.before, version: 2 } })],
    ["expected priority", (execution: Execution) => ({ ...execution, expectedAfter: { ...execution.expectedAfter, priority: 2 } })],
    ["expected version", (execution: Execution) => ({ ...execution, expectedAfter: { ...execution.expectedAfter, version: 3 } })],
  ])("rejects persisted readback with mismatched %s", async (_name, alter) => {
    // Break caught: an unrelated or differently scoped persisted execution could unlock readback for this approval.
    const { evaluateApprovalAuthorization } = await import("./approval");
    const currentState = state();
    const currentIntent = intent(currentState);
    const approval = { ...approved(currentState, currentIntent), consumedByExecutionId: executionId };

    expect(evaluateApprovalAuthorization({
      state: currentState,
      intent: currentIntent,
      approval,
      persistedExecution: alter(persistedExecution(currentIntent, approval)),
      trusted: { actorId: "production-demo", now: "2026-09-18T03:00:00.000Z" },
    }, testDigest)).toEqual({ status: "blocked", reason: "approval_consumed" });
  });

  it("never reuses a consumed approval for a new or caller-claimed execution", async () => {
    // Break caught: a caller-provided execution ID could masquerade as persisted consumption and authorize a second apply.
    const { evaluateApprovalAuthorization } = await import("./approval");
    const currentState = state();
    const currentIntent = intent(currentState);
    const approval = { ...approved(currentState, currentIntent), consumedByExecutionId: executionId };
    const unrelated = { ...persistedExecution(currentIntent, approval), id: "7a8cb6d5-c620-4baa-b37b-09ec14e16788" };

    for (const persistedExecution of [null, unrelated, executionId]) {
      expect(evaluateApprovalAuthorization({
        state: currentState,
        intent: currentIntent,
        approval,
        persistedExecution,
        trusted: { actorId: "production-demo", now: "2026-09-18T02:02:00.000Z" },
      }, testDigest)).toEqual({ status: "blocked", reason: persistedExecution === executionId ? "invalid_input" : "approval_consumed" });
    }
  });
});
