import { describe, expect, it } from "vitest";
import { createInitialCompanyState } from "./fixtures";

const seed = {
  epoch: "85c540f3-5e30-4f65-9e30-4f65e2c782a2",
  strategyVersionId: "266cae99-24da-4595-95ed-c2c782a20417",
  createdAt: "2026-09-18T00:00:00.000Z",
  strategyContentHash: "a".repeat(64),
} as const;

function input(overrides: Record<string, unknown> = {}) {
  return {
    state: createInitialCompanyState(seed),
    orderId: "SO-DEMO-1001",
    planId: "PP-DEMO-1001",
    proposedPriority: 1,
    ...overrides,
  };
}

describe("grounded order-priority assessment", () => {
  it("records versioned source evidence, both departments' facts, and an unknown delivery outcome without changing the ledger", async () => {
    // Break caught: a priority proposal could omit its ERP sources, promise delivery, or mutate state during read-only assessment.
    const { assessOrderPriority } = await import("./assessment");
    const supplied = input();
    const before = JSON.stringify(supplied.state);

    const result = assessOrderPriority(supplied);

    expect(result).toMatchObject({
      status: "proposed",
      requiredKg: 20_000,
      availableKg: 25_000,
      beforeOrder: ["PP-DEMO-1002", "PP-DEMO-1003", "PP-DEMO-1001"],
      proposedOrder: ["PP-DEMO-1001", "PP-DEMO-1002", "PP-DEMO-1003"],
      displacedPlanIds: ["PP-DEMO-1002", "PP-DEMO-1003"],
      delivery: { status: "unknown" },
      departments: {
        sales: { facts: expect.any(Array), unknowns: expect.any(Array) },
        production: { facts: expect.any(Array), unknowns: expect.any(Array) },
      },
      mutationCount: 0,
    });
    expect(result.sources).toEqual(expect.arrayContaining([
      expect.objectContaining({ kind: "sales_order", id: "SO-DEMO-1001", version: 1, evidenceId: expect.any(String) }),
      expect.objectContaining({ kind: "inventory", id: "INV-DEMO-GA-ULSAN", version: 1, evidenceId: expect.any(String) }),
      expect.objectContaining({ kind: "production_plan", id: "PP-DEMO-1001", version: 1, evidenceId: expect.any(String) }),
      expect.objectContaining({ kind: "inspection", id: "INSPECTION-DEMO-1001", version: 1, evidenceId: expect.any(String) }),
      expect.objectContaining({ kind: "shipment", id: "SHIPMENT-DEMO-1001", version: 1, evidenceId: expect.any(String) }),
    ]));
    expect(JSON.stringify(supplied.state)).toBe(before);
  });

  it.each([
    ["insufficient inventory", (value: ReturnType<typeof input>) => { value.state.inventory[0].availableKg = 19_999; }, "insufficient_inventory"],
    ["quality hold", (value: ReturnType<typeof input>) => { value.state.productionPlans[0].qualityHold = true; }, "quality_hold"],
    ["running plan", (value: ReturnType<typeof input>) => { value.state.productionPlans[0].status = "running"; }, "plan_not_queued"],
    ["missing plan", (value: ReturnType<typeof input>) => { value.planId = "PP-MISSING"; }, "missing_production_plan"],
  ])("blocks %s and preserves state", async (_name, alter, expectedReason) => {
    // Break caught: an invalid or unsafe production target could produce a priority proposal.
    const { assessOrderPriority } = await import("./assessment");
    const supplied = input();
    alter(supplied);
    const before = JSON.stringify(supplied.state);

    const result = assessOrderPriority(supplied);

    expect(result).toMatchObject({ status: "blocked", reason: expectedReason, mutationCount: 0 });
    expect(JSON.stringify(supplied.state)).toBe(before);
  });

  it("blocks a forged AI citation and reports an equal priority as already satisfied", async () => {
    // Break caught: a model could cite an old source version or make a no-op proposal look actionable.
    const { assessOrderPriority } = await import("./assessment");
    const forged = assessOrderPriority(input({
      aiCandidate: {
        orderId: "SO-DEMO-1001",
        planId: "PP-DEMO-1001",
        proposedPriority: 1,
        citations: [{ kind: "sales_order", id: "SO-DEMO-1001", version: 99, evidenceId: "evidence:sales_order:SO-DEMO-1001:v99" }],
      },
    }));
    const satisfied = assessOrderPriority(input({ proposedPriority: 5 }));

    expect(forged).toMatchObject({ status: "blocked", reason: "invalid_ai_citations", mutationCount: 0 });
    expect(satisfied).toMatchObject({ status: "already_satisfied", reason: "already_satisfied", mutationCount: 0 });
  });

  it("blocks a model candidate that names a different plan before considering its citations", async () => {
    // Break caught: a model could redirect an otherwise cited assessment to a different production plan.
    const { assessOrderPriority } = await import("./assessment");
    const result = assessOrderPriority(input({
      aiCandidate: {
        orderId: "SO-DEMO-1001",
        planId: "PP-DEMO-1002",
        proposedPriority: 1,
        citations: [{ kind: "sales_order", id: "SO-DEMO-1001", version: 1, evidenceId: "evidence:sales_order:SO-DEMO-1001:v1" }],
      },
    }));

    expect(result).toMatchObject({ status: "blocked", reason: "invalid_ai_candidate", mutationCount: 0 });
  });

  it("keeps displaced plan IDs in proposed priority order when ledger collection order changes", async () => {
    // Break caught: reading a differently ordered persisted array could make a deterministic impact list unstable.
    const { assessOrderPriority } = await import("./assessment");
    const supplied = input();
    supplied.state.productionPlans.reverse();

    const result = assessOrderPriority(supplied);

    expect(result).toMatchObject({
      proposedOrder: ["PP-DEMO-1001", "PP-DEMO-1002", "PP-DEMO-1003"],
      displacedPlanIds: ["PP-DEMO-1002", "PP-DEMO-1003"],
    });
  });
});

describe("baseline production-readiness assessment", () => {
  it("reads only order, inventory, and production sources and leaves inspection and shipment as explicit unknowns", async () => {
    // Break caught: readiness could silently use shared inspection/shipment data before that read expansion is approved.
    const { reviewProductionReadiness } = await import("./assessment");
    const supplied = input();
    const before = JSON.stringify(supplied.state);

    const result = reviewProductionReadiness({ state: supplied.state, orderId: supplied.orderId, planId: supplied.planId });

    expect(result).toMatchObject({ status: "needs_review", reason: "inspection_and_shipment_not_read", mutationCount: 0 });
    expect(result.sources.map((item) => item.kind)).toEqual(["inventory", "production_plan", "sales_order"]);
    expect(result.departments?.sales.unknowns).toContain("No promised delivery date is present in the virtual ledger.");
    expect(JSON.stringify(supplied.state)).toBe(before);
  });

  it("adds only the requested inspection and packaging sources while pending records remain needs review", async () => {
    // Given: the same untouched SO-DEMO-1002 ledger state and an approved bounded reuse check set.
    const { reviewProductionReadiness } = await import("./assessment");
    const supplied = input();
    const before = JSON.stringify(supplied.state);

    // When: readiness is reviewed with the two checks selected by the reuse contract.
    const result = reviewProductionReadiness({
      state: supplied.state,
      orderId: "SO-DEMO-1002",
      planId: "PP-DEMO-1002",
      requiredChecks: ["inspection", "packaging"],
    });

    // Then: the baseline read set is retained, only inspection/shipment are added, and no readiness is invented.
    expect(result).toMatchObject({
      status: "needs_review",
      reason: "inspection_pending_and_packaging_not_ready",
      requiredChecks: ["inspection", "packaging"],
      mutationCount: 0,
    });
    expect(result.baselineSources.map((item) => `${item.kind}:${item.id}`)).toEqual([
      "inventory:INV-DEMO-GA-ULSAN",
      "production_plan:PP-DEMO-1002",
      "sales_order:SO-DEMO-1002",
    ]);
    expect(result.additionalSources.map((item) => `${item.kind}:${item.id}`)).toEqual([
      "inspection:INSPECTION-DEMO-1002",
      "shipment:SHIPMENT-DEMO-1002",
    ]);
    expect(result.sources.map((item) => `${item.kind}:${item.id}`)).toEqual([
      "inspection:INSPECTION-DEMO-1002",
      "inventory:INV-DEMO-GA-ULSAN",
      "production_plan:PP-DEMO-1002",
      "sales_order:SO-DEMO-1002",
      "shipment:SHIPMENT-DEMO-1002",
    ]);
    expect(JSON.stringify(supplied.state)).toBe(before);
  });
});
