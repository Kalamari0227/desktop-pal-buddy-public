import { describe, expect, it } from "vitest";
import {
  createExperienceDraftStore,
  type ExperienceSource,
  type ExperienceWorkItem,
} from "./experience";

const workItem: ExperienceWorkItem = {
  workboardTaskId: "9e650d6d-9e9f-4a09-b041-e345d16620a8",
  packetTaskId: "27862353-b4b6-43d3-bec2-2e4afe57dc06",
};

const sources: readonly ExperienceSource[] = [
  {
    evidenceId: "evidence:production_plan:PP-DEMO-1001:v2",
    kind: "work_fact",
    workItem,
    asset: { id: "PP-DEMO-1001", version: 2 },
  },
  {
    evidenceId: "readback:f07c5de4-85a8-4ba4-acd2-b7e85cdfe7bb",
    kind: "readback",
    workItem,
    asset: { id: "PP-DEMO-1001", version: 2 },
  },
];

function createStore() {
  return createExperienceDraftStore({
    sources,
    now: () => "2026-09-19T01:00:00.000Z",
    nextId: () => "experience-draft-1",
  });
}

function privateDraft(overrides: Record<string, unknown> = {}) {
  return {
    authorActorId: "sales-demo",
    workItem,
    sourceEvidenceIds: sources.map((source) => source.evidenceId),
    asset: { id: "PP-DEMO-1001", version: 2 },
    correction: "검사와 출하 준비를 재확인한 뒤 납기 약속을 검토해야 합니다.",
    applicability: ["queued production plan", "delivery promise review"],
    counterexample: "검사 불합격 또는 출하 미준비면 이 판단을 적용하지 않습니다.",
    outcome: { state: "unobserved" },
    saveDecision: "private",
    ...overrides,
  };
}

describe("experience draft store", () => {
  it("saves an explicit private correction with stable author, source, and asset version fields", () => {
    const store = createStore();

    const result = store.save(privateDraft());

    expect(result).toMatchObject({
      ok: true,
      draft: {
        id: "experience-draft-1",
        version: 1,
        authorActorId: "sales-demo",
        workItem,
        asset: { id: "PP-DEMO-1001", version: 2 },
        sourceEvidenceIds: sources.map((source) => source.evidenceId),
        visibility: "private",
        reviewRequest: "none",
        outcome: { state: "unobserved" },
      },
    });
    expect(store.listForActor("sales-demo")).toHaveLength(1);
    expect(store.searchForTeam("management-demo")).toEqual([]);
  });

  it("keeps a requested shared review private until a later publication flow exists", () => {
    const store = createStore();

    const result = store.save(privateDraft({ saveDecision: "shared_review" }));

    expect(result).toMatchObject({ ok: true, draft: { visibility: "private", reviewRequest: "requested" } });
    expect(store.searchForTeam("production-demo")).toEqual([]);
    expect(store.searchForTeam("management-demo")).toEqual([]);
  });

  it("does not persist a discarded or unsaved correction", () => {
    const store = createStore();

    const discarded = store.discard({ authorActorId: "sales-demo", workItem });

    expect(discarded).toEqual({ ok: true, status: "discarded", persistedCount: 0 });
    expect(store.listForActor("sales-demo")).toEqual([]);
    expect(store.snapshot()).toEqual([]);
  });

  it("filters private drafts to their author when another actor reads the store", () => {
    const store = createStore();
    store.save(privateDraft());

    expect(store.listForActor("sales-demo")).toHaveLength(1);
    expect(store.listForActor("production-demo")).toEqual([]);
    expect(store.listForActor("management-demo")).toEqual([]);
  });

  it("keeps a saved private draft available to its author after deterministic store reconstruction", () => {
    const store = createStore();
    store.save(privateDraft());

    const reopened = createExperienceDraftStore({
      sources,
      initialDrafts: store.snapshot(),
      now: () => "2026-09-19T01:00:00.000Z",
      nextId: () => "experience-draft-2",
    });

    expect(reopened.listForActor("sales-demo")).toHaveLength(1);
    expect(reopened.listForActor("production-demo")).toEqual([]);
    expect(reopened.searchForTeam("management-demo")).toEqual([]);
  });

  it("rejects a correction that names source evidence outside the linked work item", () => {
    const store = createStore();

    const result = store.save(privateDraft({ sourceEvidenceIds: ["evidence:production_plan:PP-DEMO-1001:v99"] }));

    expect(result).toEqual({ ok: false, code: "missing_source", persistedCount: 0 });
    expect(store.snapshot()).toEqual([]);
  });

  it("preserves unobserved outcomes and requires readback evidence for observed outcomes", () => {
    const store = createStore();

    const unobserved = store.save(privateDraft());
    const invalidObserved = store.save(privateDraft({
      outcome: { state: "observed", observedAt: "2026-09-19T01:01:00.000Z" },
      sourceEvidenceIds: [sources[0]?.evidenceId],
    }));
    const observed = store.save(privateDraft({
      outcome: { state: "observed", observedAt: "2026-09-19T01:01:00.000Z" },
    }));

    expect(unobserved).toMatchObject({ ok: true, draft: { outcome: { state: "unobserved" } } });
    expect(invalidObserved).toEqual({ ok: false, code: "observed_outcome_requires_readback", persistedCount: 1 });
    expect(observed).toMatchObject({ ok: true, draft: { outcome: { state: "observed", observedAt: "2026-09-19T01:01:00.000Z" } } });
  });

  it("rejects an observed outcome when its selected readback names a different asset version", () => {
    const store = createExperienceDraftStore({
      sources: [
        sources[0]!,
        { ...sources[1]!, asset: { id: "PP-DEMO-1001", version: 1 } },
      ],
      now: () => "2026-09-19T01:00:00.000Z",
      nextId: () => "experience-draft-mismatched-readback",
    });

    const result = store.save(privateDraft({
      outcome: { state: "observed", observedAt: "2026-09-19T01:01:00.000Z" },
    }));

    expect(result).toEqual({ ok: false, code: "observed_outcome_requires_matching_readback", persistedCount: 0 });
    expect(store.snapshot()).toEqual([]);
  });
});
