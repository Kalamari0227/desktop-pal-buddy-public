import { describe, expect, it } from "vitest";
import type { CompanyState, StrategyAdoption } from "./contracts";
import { createInitialCompanyState } from "./fixtures";
import { strategyAdoptionRecordsSchema } from "./schemas";
import { decideStrategyReview } from "./strategyReview";
import { decideStrategyAdoption } from "./strategyAdoption";

const epoch = "f7091d6f-e310-46f5-ae2f-a761f136f36a";
const v1Id = "f6846f3d-1aa0-487a-88a1-c383ba9076ea";
const reviewId = "04d83596-3b4b-4b02-963f-2f0b41110312";
const v2Id = "194d29ef-806c-4e11-8ca8-485d75812fed";
const adoptionId = "5267086e-75e8-4ee3-9811-eb13b1bcf0ad";
const adoptedAt = "2026-09-19T06:00:00.000Z";
const hash = (value: string) => value.length.toString(16).padStart(64, "0");

function reviewedState() {
  const state = createInitialCompanyState({
    epoch,
    strategyVersionId: v1Id,
    createdAt: "2026-09-19T00:00:00.000Z",
    strategyContentHash: "a".repeat(64),
  });
  const result = decideStrategyReview({
    requestId: reviewId,
    state,
    existingReviews: [],
    decision: "create_new_version",
    baseStrategyRef: state.activeStrategyRef,
    expectedBaseVersion: 1,
    evidenceSnapshot: [{
      kind: "assessment",
      id: "8a3e281c-731e-457e-a456-e77c50f4be51",
      version: 1,
      contentHash: "b".repeat(64),
      visibilityScope: "official",
    }],
    uncertainties: ["검사 완료 시점은 아직 확인되지 않았습니다."],
    proposedChanges: {
      objective: "준비 상태를 확인한 뒤 납기를 판단",
      review_question: "검사와 포장 상태가 확인되었는가?",
      execution_criteria: ["검사와 포장 상태를 함께 확인"],
      constraints: ["미확인 상태에서 납기를 확약하지 않음"],
    },
    reviewerActorId: "management-demo",
    reviewedAt: "2026-09-19T05:00:00.000Z",
    nextStrategyVersionId: v2Id,
  }, hash);
  if (!result.ok || result.version === null) throw new Error("review fixture missing");
  return {
    state: { ...state, strategyVersions: [...state.strategyVersions, result.version] },
    review: result.review,
    version: result.version,
  };
}

function adoptionInput(overrides: Record<string, unknown> = {}) {
  const fixture = reviewedState();
  return {
    state: fixture.state,
    existingReviews: [fixture.review],
    existingAdoptions: [] as StrategyAdoption[],
    requestId: adoptionId,
    reviewId,
    expectedActiveRef: fixture.state.activeStrategyRef,
    trusted: { actorId: "management-demo", epoch, adoptedAt },
    ...overrides,
  };
}

describe("explicit strategy adoption", () => {
  it("returns a pure management decision from active v1 to the exact reviewed v2", () => {
    // Given: a stored create-new-version review while v1 remains active.
    const input = adoptionInput();
    const before = structuredClone(input.state);

    // When: management explicitly adopts the review target.
    const result = decideStrategyAdoption(input, hash);

    // Then: a v1-to-v2 adoption is returned without mutating state.
    expect(result).toMatchObject({
      ok: true,
      idempotent: false,
      adoption: {
        id: adoptionId,
        epoch,
        reviewId,
        fromRef: input.state.activeStrategyRef,
        toRef: { strategy_id: "STRATEGY-DEMO-PRODUCTION", strategy_version_id: v2Id },
        actorId: "management-demo",
        adoptedAt,
      },
      targetVersion: { strategy_version_id: v2Id, version: 2 },
      activeStrategyRef: { strategy_id: "STRATEGY-DEMO-PRODUCTION", strategy_version_id: v2Id },
    });
    expect(input.state).toEqual(before);
  });

  it("replays the same request idempotently and rejects changed payload reuse", () => {
    // Given: the adoption record and v2 active state were persisted once.
    const input = adoptionInput();
    const first = decideStrategyAdoption(input, hash);
    if (!first.ok) throw new Error(`unexpected adoption failure: ${first.code}`);
    const persistedState: CompanyState = { ...input.state, activeStrategyRef: first.activeStrategyRef };
    const replayInput = { ...input, state: persistedState, existingAdoptions: [first.adoption] };

    // When: the same request and a changed duplicate are evaluated.
    const replayed = decideStrategyAdoption(replayInput, hash);
    const changed = decideStrategyAdoption({
      ...replayInput,
      expectedActiveRef: { strategy_id: "OTHER", strategy_version_id: v1Id },
    }, hash);

    // Then: only the byte-equivalent request replays without another transition.
    expect(replayed).toMatchObject({ ok: true, idempotent: true, adoption: first.adoption });
    expect(changed).toEqual({ ok: false, code: "conflict" });
  });

  it("does not roll active v3 back when an earlier v2 adoption is replayed", () => {
    // Given: v2 was adopted and a later valid version is now active.
    const input = adoptionInput();
    const first = decideStrategyAdoption(input, hash);
    if (!first.ok) throw new Error(`unexpected adoption failure: ${first.code}`);
    const v3Id = "1131f721-46bd-46dc-977a-b17905e06061";
    const stateAtV3: CompanyState = {
      ...input.state,
      strategyVersions: [...input.state.strategyVersions, {
        ...first.targetVersion,
        strategy_version_id: v3Id,
        version: 3,
        parent_version_id: v2Id,
        content_hash: "c".repeat(64),
      }],
      activeStrategyRef: { strategy_id: first.targetVersion.strategy_id, strategy_version_id: v3Id },
    };

    // When: the original request is replayed after v3 activation.
    const replayed = decideStrategyAdoption({ ...input, state: stateAtV3, existingAdoptions: [first.adoption] }, hash);

    // Then: replay reports current v3 and cannot direct a rollback to v2.
    expect(replayed).toMatchObject({ ok: true, idempotent: true, activeStrategyRef: stateAtV3.activeStrategyRef });
  });

  it.each([
    ["forged role", { trusted: { actorId: "sales-demo", epoch, adoptedAt } }, "management_role_required"],
    ["stale epoch", { trusted: { actorId: "management-demo", epoch: "c62ef26d-7ddf-4c11-bf84-2aec79c6e4a6", adoptedAt } }, "stale_context"],
    ["stale active base", { expectedActiveRef: { strategy_id: "STRATEGY-DEMO-PRODUCTION", strategy_version_id: v2Id } }, "stale_base"],
    ["missing review", { existingReviews: [] }, "review_not_found"],
  ])("blocks %s", (_name, patch, code) => {
    // Given: one trust or stored-lineage precondition is invalid.
    const input = adoptionInput(patch);

    // When: adoption is evaluated.
    const result = decideStrategyAdoption(input, hash);

    // Then: no adoption record or target is returned.
    expect(result).toEqual({ ok: false, code });
  });

  it("rejects a stored reviewed target when its immutable content hash changed", () => {
    // Given: the target UUID exists but its stored reviewed content was altered.
    const input = adoptionInput();
    const tampered: CompanyState = {
      ...input.state,
      strategyVersions: input.state.strategyVersions.map((version) =>
        version.strategy_version_id === v2Id ? { ...version, objective: "변조된 목표" } : version),
    };

    // When: management tries to adopt the altered target.
    const result = decideStrategyAdoption({ ...input, state: tampered }, hash);

    // Then: exact review-to-version verification fails closed.
    expect(result).toEqual({ ok: false, code: "invalid_review_target" });
  });

  it("reads old records with an empty adoption history without mutating the source", () => {
    // Given: a format-v1 records object created before strategy adoption existed.
    const oldRecords = { strategyReviews: [] };

    // When: the additive records extension is parsed.
    const parsed = strategyAdoptionRecordsSchema.parse(oldRecords);

    // Then: consumers receive an empty history while the source remains unchanged.
    expect(parsed.strategyAdoptions).toEqual([]);
    expect(oldRecords).toEqual({ strategyReviews: [] });
  });
});
