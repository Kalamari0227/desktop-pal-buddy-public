import { z } from "zod";
import { strategyRefSchema, strategyVersionSchema, taskPacketSchema } from "../agentic/schemas";
import type { StrategyVersion } from "../agentic/types";
import {
  ACTOR_IDS,
  ACTOR_ROLES,
  EXECUTION_MODES,
  OBJECT_KINDS,
  RUNTIME_ERROR_CODES,
  type CompanyState,
  type RuntimeStrategyVersion,
} from "./contracts";

const text = z.string().trim().min(1);
const uuid = z.string().uuid();
const version = z.number().int().positive();
const kg = z.number().int().nonnegative();
const positiveKg = z.number().int().positive();
const digest = z.string().regex(/^[a-f0-9]{64}$/);
const timestamp = z.string().datetime();
const idVersion = { id: text, version };

export const LEARNING_REUSE_WORK_TYPES = ["production_readiness"] as const;
export const LEARNING_REUSE_DEPARTMENTS = ["production"] as const;
export const LEARNING_REUSE_MATERIAL_GROUPS = ["MAT-GA-DEMO"] as const;
export const LEARNING_REUSE_REQUIRED_CHECKS = ["inspection", "packaging"] as const;

export const actorIdSchema = z.enum(ACTOR_IDS);
export const actorRoleSchema = z.enum(ACTOR_ROLES);
export const objectKindSchema = z.enum(OBJECT_KINDS);
export const executionModeSchema = z.enum(EXECUTION_MODES);
export const runtimeErrorCodeSchema = z.enum(RUNTIME_ERROR_CODES);
export const learningReuseWorkTypeSchema = z.enum(LEARNING_REUSE_WORK_TYPES);
export const learningReuseDepartmentSchema = z.enum(LEARNING_REUSE_DEPARTMENTS);
export const learningReuseMaterialGroupSchema = z.enum(LEARNING_REUSE_MATERIAL_GROUPS);
export const learningReuseRequiredCheckSchema = z.enum(LEARNING_REUSE_REQUIRED_CHECKS);
export const learningReuseApplicabilitySchema = z.object({
  workType: learningReuseWorkTypeSchema,
  department: learningReuseDepartmentSchema,
  materialGroup: learningReuseMaterialGroupSchema,
  requiredChecks: z.array(learningReuseRequiredCheckSchema).min(1).max(LEARNING_REUSE_REQUIRED_CHECKS.length),
}).strict().superRefine((value, context) => {
  if (new Set(value.requiredChecks).size !== value.requiredChecks.length) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "required checks must be unique" });
  }
});
export const learningSourceReferenceSchema = z.object({
  assetId: text,
  version,
}).strict();

export const customerSchema = z.object({ ...idVersion, name: text }).strict();
export const salesOpportunitySchema = z.object({
  ...idVersion,
  customerId: text,
  materialId: text,
  requestedKg: positiveKg,
  status: z.enum(["qualified", "closed"]),
}).strict();
export const quoteSchema = z.object({
  ...idVersion,
  opportunityId: text,
  quantityKg: positiveKg,
  status: z.enum(["draft", "approved"]),
}).strict();
export const salesOrderSchema = z.object({
  ...idVersion,
  customerId: text,
  materialId: text,
  quantityKg: positiveKg,
  status: z.enum(["confirmed", "in_production", "completed"]),
}).strict();
export const inventoryItemSchema = z.object({
  ...idVersion,
  materialId: text,
  availableKg: kg,
  warehouseId: text,
}).strict();
export const productionPlanSchema = z.object({
  ...idVersion,
  orderId: text,
  productionGroupId: text,
  priority: z.number().int().min(1).max(9),
  status: z.enum(["queued", "running", "completed"]),
  qualityHold: z.boolean(),
  materialId: text,
  requiredKg: positiveKg,
}).strict();
export const inspectionSchema = z.object({
  ...idVersion,
  orderId: text,
  status: z.enum(["pending", "passed", "failed"]),
}).strict();
export const shipmentSchema = z.object({
  ...idVersion,
  orderId: text,
  status: z.enum(["not_ready", "ready", "shipped"]),
  packagingStatus: z.enum(["unchecked", "ready"]),
}).strict();

export const objectVersionRefSchema = z.object({ kind: objectKindSchema, id: text, version }).strict();
export const skillRefSchema = z.object({ id: text, version }).strict();
export const skillDescriptorSchema = skillRefSchema.extend({
  inputSchemaVersion: version,
  outputSchemaVersion: version,
  requiredCapabilities: z.array(text).min(1),
  allowedConnectorIds: z.array(text).min(1),
  policyVersion: text,
  reviewState: z.literal("approved"),
}).strict();

export const runtimeStrategyVersionSchema = strategyVersionSchema.extend({
  parent_version_id: uuid.nullable(),
  execution_criteria: z.array(text),
  constraints: z.array(text),
  created_by: actorIdSchema,
  created_at: timestamp,
  origin: z.enum(["seed", "management"]),
  content_hash: digest,
}).strict();
export const runtimeStrategyRefSchema = strategyRefSchema.extend({ strategy_version_id: uuid }).strict();

export function toLegacyStrategyVersion(runtimeVersion: RuntimeStrategyVersion): StrategyVersion {
  return strategyVersionSchema.parse({
    strategy_version_id: runtimeVersion.strategy_version_id,
    strategy_id: runtimeVersion.strategy_id,
    version: runtimeVersion.version,
    objective: runtimeVersion.objective,
    review_question: runtimeVersion.review_question,
  });
}

const actionIntentDigestShape = {
  id: uuid,
  revision: version,
  workboardTaskId: uuid,
  packetTaskId: uuid,
  epoch: uuid,
  targetPlanId: text,
  fromPriority: z.number().int().min(1).max(9),
  toPriority: z.number().int().min(1).max(9),
  readSet: z.array(objectVersionRefSchema),
  strategyRef: strategyRefSchema,
  skillRef: skillRefSchema,
  policyVersion: text,
  evidenceRefs: z.array(text),
  requesterActorId: actorIdSchema,
  createdAt: timestamp,
};

function validateCanonicalIntentReadSet(
  intent: { readSet: Array<{ kind: string; id: string; version: number }> },
  context: z.RefinementCtx,
): void {
  const keys = intent.readSet.map((item) => `${item.kind}\u0000${item.id}\u0000${String(item.version).padStart(12, "0")}`);
  const sorted = [...keys].sort();
  if (keys.some((key, index) => key !== sorted[index])) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "readSet must be sorted by kind, id, and version" });
  }
  if (new Set(keys).size !== keys.length) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "readSet must not contain duplicate object versions" });
  }
}

export const actionIntentDigestInputSchema = z.object(actionIntentDigestShape)
  .strict()
  .superRefine(validateCanonicalIntentReadSet);

export const actionIntentSchema = z.object({
  ...actionIntentDigestShape,
  proposalDigest: digest,
}).strict().superRefine(validateCanonicalIntentReadSet);

export const approvalSchema = z.object({
  id: uuid,
  intentId: uuid,
  intentRevision: version,
  proposalDigest: digest,
  epoch: uuid,
  readSetDigest: digest,
  policyVersion: text,
  skillRef: skillRefSchema,
  strategyRef: strategyRefSchema,
  requesterActorId: actorIdSchema,
  approverActorId: actorIdSchema,
  decision: z.enum(["approved", "rejected", "revoked"]),
  decidedAt: timestamp,
  expiresAt: timestamp,
  consumedByExecutionId: uuid.nullable(),
}).strict();

const priorityVersionSchema = z.object({ priority: z.number().int().min(1).max(9), version }).strict();
export const executionSchema = z.object({
  id: uuid,
  intentId: uuid,
  approvalId: uuid.nullable(),
  idempotencyKey: text,
  epoch: uuid,
  mode: executionModeSchema,
  state: z.enum(["prepared", "applied_pending_readback", "verified", "failed_before_apply", "verification_required"]),
  before: priorityVersionSchema,
  expectedAfter: priorityVersionSchema,
  attempt: version,
  startedAt: timestamp,
}).strict();

export const readbackEvidenceSchema = z.object({
  executionId: uuid,
  targetPlanId: text,
  epoch: uuid,
  expectedPriority: z.number().int().min(1).max(9),
  expectedVersion: version,
  observedPriority: z.number().int().min(1).max(9),
  observedVersion: version,
  readAt: timestamp,
  matches: z.boolean(),
}).strict();

export const assessmentEvidenceSchema = z.object({
  id: uuid,
  epoch: uuid,
  packetTaskId: uuid,
  readSet: z.array(objectVersionRefSchema),
  baselineReadSet: z.array(objectVersionRefSchema).default([]),
  additionalReadSet: z.array(objectVersionRefSchema).default([]),
  requiredChecks: z.array(learningReuseRequiredCheckSchema).default([]),
  usedAssetRef: learningSourceReferenceSchema.nullable().default(null),
  reuse: z.object({
    status: z.enum(["baseline", "selected", "no_candidate", "needs_review"]),
    code: text.nullable(),
    lineageStatus: z.enum(["verified", "not_checked", "source_missing", "source_withdrawn", "source_inaccessible", "source_superseded", "source_cycle"]).nullable(),
    lineageRefs: z.array(learningSourceReferenceSchema),
    candidateIds: z.array(text),
  }).strict().default({ status: "baseline", code: null, lineageStatus: null, lineageRefs: [], candidateIds: [] }),
  finding: z.enum(["ready", "needs_review"]),
  reasons: z.array(text),
  mutationCount: z.literal(0),
  observedAt: timestamp,
}).strict();

export const businessOutcomeSchema = z.object({
  packetTaskId: uuid,
  status: z.enum(["unobserved", "observed_simulated"]),
  recordedByActorId: actorIdSchema.nullable(),
  evidenceRefs: z.array(text),
  observedAt: timestamp.nullable(),
}).strict();

export const runtimeTaskRecordSchema = z.object({
  workboardTaskId: uuid,
  packetTaskId: uuid,
  epoch: uuid,
  packet: taskPacketSchema,
  status: z.enum(["pending", "in_progress", "done", "verification_required"]),
  currentProposal: z.object({
    intentId: uuid,
    revision: version,
    proposalDigest: digest,
  }).strict().nullable(),
  currentApprovalId: uuid.nullable(),
  executionId: uuid.nullable(),
  businessOutcome: businessOutcomeSchema,
}).strict().superRefine((record, context) => {
  if (record.packet.task_id !== record.packetTaskId) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "task record packet identity mismatch" });
  }
  if (record.businessOutcome.packetTaskId !== record.packetTaskId) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "task record business outcome identity mismatch" });
  }
});

export const learningAssetSchema = z.object({
  ...idVersion,
  authorActorId: actorIdSchema,
  sourceTaskId: uuid,
  sourceEvidenceRefs: z.array(text),
  correctionRef: text.nullable(),
  content: text,
  applicability: z.array(text),
  requiredChecks: z.array(text),
  allowedAudiences: z.array(actorRoleSchema),
  reviewState: z.enum(["private", "shared", "withdrawn"]),
  consent: z.object({ version, decidedAt: timestamp, audiences: z.array(actorRoleSchema) }).strict(),
  provenance: text,
}).strict();

export const strategyReviewSchema = z.object({
  id: uuid,
  epoch: uuid,
  baseStrategyRef: strategyRefSchema,
  evidenceSnapshot: z.array(z.object({
    kind: text,
    id: text,
    version,
    contentHash: digest,
    visibilityScope: text,
  }).strict()),
  uncertainties: z.array(text),
  proposedChanges: z.object({
    objective: text,
    review_question: text,
    execution_criteria: z.array(text),
    constraints: z.array(text),
  }).strict(),
  reviewerActorId: actorIdSchema,
  reviewedAt: timestamp,
  decision: z.enum(["maintain", "create_new_version"]),
  resultingStrategyRef: strategyRefSchema.nullable(),
}).strict();

export const strategyAdoptionSchema = z.object({
  id: uuid,
  epoch: uuid,
  reviewId: uuid,
  fromRef: runtimeStrategyRefSchema,
  toRef: runtimeStrategyRefSchema,
  actorId: actorIdSchema,
  adoptedAt: timestamp,
}).strict();

export const strategyAdoptionsSchema = z.array(strategyAdoptionSchema).default([]);
export const strategyAdoptionRecordsSchema = z.object({
  strategyAdoptions: strategyAdoptionsSchema,
}).passthrough();

const stateShape = {
  formatVersion: z.literal(1),
  revision: z.number().int().nonnegative(),
  currentEpoch: uuid,
  stopped: z.boolean(),
  bootstrap: z.boolean(),
  customers: z.array(customerSchema),
  salesOpportunities: z.array(salesOpportunitySchema),
  quotes: z.array(quoteSchema),
  salesOrders: z.array(salesOrderSchema),
  inventory: z.array(inventoryItemSchema),
  productionPlans: z.array(productionPlanSchema),
  inspections: z.array(inspectionSchema),
  shipments: z.array(shipmentSchema),
  skills: z.array(skillDescriptorSchema),
  strategyVersions: z.array(runtimeStrategyVersionSchema),
  activeStrategyRef: strategyRefSchema,
  bootstrapReadSet: z.array(objectVersionRefSchema),
};

function duplicateIds(items: readonly { id: string }[]): string[] {
  const seen = new Set<string>();
  const duplicates = new Set<string>();
  for (const item of items) {
    if (seen.has(item.id)) duplicates.add(item.id);
    seen.add(item.id);
  }
  return [...duplicates];
}

export const companyStateSchema: z.ZodType<CompanyState> = z.object(stateShape).strict().superRefine((state, context) => {
  const collections = [
    state.customers,
    state.salesOpportunities,
    state.quotes,
    state.salesOrders,
    state.inventory,
    state.productionPlans,
    state.inspections,
    state.shipments,
    state.skills,
  ];
  for (const collection of collections) {
    for (const duplicate of duplicateIds(collection)) {
      context.addIssue({ code: z.ZodIssueCode.custom, message: `duplicate id: ${duplicate}` });
    }
  }
  for (const duplicate of duplicateIds(state.strategyVersions.map((item) => ({ id: item.strategy_version_id })))) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: `duplicate strategy version id: ${duplicate}` });
  }
  const orderIds = new Set(state.salesOrders.map((item) => item.id));
  const customerIds = new Set(state.customers.map((item) => item.id));
  const opportunityIds = new Set(state.salesOpportunities.map((item) => item.id));
  for (const opportunity of state.salesOpportunities) {
    if (!customerIds.has(opportunity.customerId)) context.addIssue({ code: z.ZodIssueCode.custom, message: `unknown customer: ${opportunity.customerId}` });
  }
  for (const quote of state.quotes) {
    if (!opportunityIds.has(quote.opportunityId)) context.addIssue({ code: z.ZodIssueCode.custom, message: `unknown opportunity: ${quote.opportunityId}` });
  }
  for (const order of state.salesOrders) {
    if (!customerIds.has(order.customerId)) context.addIssue({ code: z.ZodIssueCode.custom, message: `unknown customer: ${order.customerId}` });
  }
  for (const linked of [...state.productionPlans, ...state.inspections, ...state.shipments]) {
    if (!orderIds.has(linked.orderId)) context.addIssue({ code: z.ZodIssueCode.custom, message: `unknown order: ${linked.orderId}` });
  }
  const active = state.strategyVersions.find((candidate) =>
    candidate.strategy_id === state.activeStrategyRef.strategy_id
    && candidate.strategy_version_id === state.activeStrategyRef.strategy_version_id);
  if (!active) context.addIssue({ code: z.ZodIssueCode.custom, message: "active strategy reference is not stored" });
});

const envelopeBase = {
  schemaVersion: z.literal(1),
  requestId: uuid,
  epoch: uuid,
  actorSessionRevision: z.number().int().nonnegative(),
};
export const runtimeRequestEnvelopeSchema = z.object({ ...envelopeBase, payload: z.unknown() }).strict();
export const runtimeSuccessEnvelopeSchema = z.object({ ...envelopeBase, ok: z.literal(true), payload: z.unknown() }).strict();
export const runtimeErrorEnvelopeSchema = z.object({
  ...envelopeBase,
  ok: z.literal(false),
  error: z.object({ code: runtimeErrorCodeSchema, message: text }).strict(),
}).strict();
export const runtimeEnvelopeSchema = z.union([runtimeRequestEnvelopeSchema, runtimeSuccessEnvelopeSchema, runtimeErrorEnvelopeSchema]);

export type RuntimeContextValidation =
  | { valid: true; envelope: z.infer<typeof runtimeRequestEnvelopeSchema> }
  | { valid: false; code: "invalid_input" | "stale_context"; issues: string[] };

export function validateRuntimeRequestContext(
  input: unknown,
  current: { epoch: string; actorSessionRevision: number },
): RuntimeContextValidation {
  const parsed = runtimeRequestEnvelopeSchema.safeParse(input);
  if (!parsed.success) {
    return { valid: false, code: "invalid_input", issues: parsed.error.issues.map((issue) => issue.message) };
  }
  const issues: string[] = [];
  if (parsed.data.epoch !== current.epoch) issues.push("request epoch is stale");
  if (parsed.data.actorSessionRevision !== current.actorSessionRevision) issues.push("actor session revision is stale");
  return issues.length > 0
    ? { valid: false, code: "stale_context", issues }
    : { valid: true, envelope: parsed.data };
}
