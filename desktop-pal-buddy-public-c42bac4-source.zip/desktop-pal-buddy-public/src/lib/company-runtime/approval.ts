import { z } from "zod";
import type { ActionIntent, Approval, CompanyState, Execution, ObjectKind } from "./contracts";
import { REGISTERED_SKILLS } from "./fixtures";
import {
  actionIntentSchema,
  actorIdSchema,
  approvalSchema,
  companyStateSchema,
  executionSchema,
} from "./schemas";
import {
  canonicalizeActionIntentDigestInput,
  canonicalizeReadSetDigestInput,
  type CanonicalDigest,
} from "./transitions";

const APPROVAL_WINDOW_MS = 15 * 60 * 1_000;
const uuid = z.string().uuid();
const timestamp = z.string().datetime();

const trustedDecisionSchema = z.object({
  approvalId: uuid,
  actorId: actorIdSchema,
  now: timestamp,
}).strict();

const decideApprovalInputSchema = z.object({
  state: z.unknown(),
  intent: z.unknown(),
  decision: z.enum(["approved", "rejected"]),
  trusted: trustedDecisionSchema,
}).strict();

const trustedActorClockSchema = z.object({
  actorId: actorIdSchema,
  now: timestamp,
}).strict();

const revokeApprovalInputSchema = z.object({
  approval: z.unknown(),
  trusted: trustedActorClockSchema,
}).strict();

const authorizationInputSchema = z.object({
  state: z.unknown(),
  intent: z.unknown(),
  approval: z.unknown(),
  persistedExecution: z.unknown().nullable(),
  trusted: trustedActorClockSchema,
}).strict();

export type ApprovalRecordDecision =
  | { status: "recorded"; approval: Approval }
  | { status: "blocked"; reason: string };

export type ApprovalAuthorization =
  | { status: "apply_authorized"; approvalId: string; intentId: string }
  | { status: "readback_only"; approvalId: string; intentId: string; executionId: string }
  | { status: "blocked"; reason: string };

function blocked(reason: string): { status: "blocked"; reason: string } {
  return { status: "blocked", reason };
}

function isProductionActor(actorId: string): boolean {
  return actorId === "production-demo";
}

function sameSkill(left: { id: string; version: number }, right: { id: string; version: number }): boolean {
  return left.id === right.id && left.version === right.version;
}

function sameStrategy(
  left: { strategy_id: string; strategy_version_id: string },
  right: { strategy_id: string; strategy_version_id: string },
): boolean {
  return left.strategy_id === right.strategy_id && left.strategy_version_id === right.strategy_version_id;
}

function objectVersion(state: CompanyState, kind: ObjectKind, id: string): number | undefined {
  switch (kind) {
    case "customer": return state.customers.find((item) => item.id === id)?.version;
    case "sales_opportunity": return state.salesOpportunities.find((item) => item.id === id)?.version;
    case "quote": return state.quotes.find((item) => item.id === id)?.version;
    case "sales_order": return state.salesOrders.find((item) => item.id === id)?.version;
    case "inventory": return state.inventory.find((item) => item.id === id)?.version;
    case "production_plan": return state.productionPlans.find((item) => item.id === id)?.version;
    case "inspection": return state.inspections.find((item) => item.id === id)?.version;
    case "shipment": return state.shipments.find((item) => item.id === id)?.version;
  }
}

function validateProposalDigest(intent: ActionIntent, digestCanonical: CanonicalDigest): boolean {
  try {
    return digestCanonical(canonicalizeActionIntentDigestInput(intent)) === intent.proposalDigest;
  } catch {
    return false;
  }
}

function validateCurrentBindings(state: CompanyState, intent: ActionIntent): string | undefined {
  if (intent.epoch !== state.currentEpoch) return "stale_context";
  if (!state.strategyVersions.some((item) => sameStrategy(item, intent.strategyRef))) {
    return "invalid_strategy";
  }
  const registered = REGISTERED_SKILLS.find((item) => sameSkill(item, intent.skillRef));
  const stored = state.skills.find((item) => sameSkill(item, intent.skillRef));
  if (!registered || !stored || intent.skillRef.id !== "change-production-priority") return "invalid_skill";
  if (registered.policyVersion !== intent.policyVersion || stored.policyVersion !== intent.policyVersion) return "invalid_policy";
  if (JSON.stringify(registered) !== JSON.stringify(stored)) return "invalid_skill";
  const target = state.productionPlans.find((item) => item.id === intent.targetPlanId);
  if (!target || target.priority !== intent.fromPriority) return "stale_state";
  if (intent.readSet.some((reference) => objectVersion(state, reference.kind, reference.id) !== reference.version)) {
    return "stale_state";
  }
  return undefined;
}

function exactApprovalBinding(
  approval: Approval,
  intent: ActionIntent,
  digestCanonical: CanonicalDigest,
): boolean {
  let readSetDigest: string;
  try {
    readSetDigest = digestCanonical(canonicalizeReadSetDigestInput(intent.readSet));
  } catch {
    return false;
  }
  return approval.intentId === intent.id
    && approval.intentRevision === intent.revision
    && approval.proposalDigest === intent.proposalDigest
    && approval.epoch === intent.epoch
    && approval.readSetDigest === readSetDigest
    && approval.policyVersion === intent.policyVersion
    && sameSkill(approval.skillRef, intent.skillRef)
    && sameStrategy(approval.strategyRef, intent.strategyRef)
    && approval.requesterActorId === intent.requesterActorId
    && approval.approverActorId === "production-demo";
}

function isCommittedReadbackExecution(execution: Execution, approval: Approval, intent: ActionIntent): boolean {
  const targetVersion = intent.readSet.find(
    (reference) => reference.kind === "production_plan" && reference.id === intent.targetPlanId,
  )?.version;
  return execution.id === approval.consumedByExecutionId
    && execution.approvalId === approval.id
    && execution.intentId === intent.id
    && execution.epoch === intent.epoch
    && execution.idempotencyKey === `${intent.epoch}:${intent.id}:${intent.proposalDigest}`
    && execution.mode === "apply"
    && targetVersion !== undefined
    && execution.before.priority === intent.fromPriority
    && execution.before.version === targetVersion
    && execution.expectedAfter.priority === intent.toPriority
    && execution.expectedAfter.version === targetVersion + 1
    && ["applied_pending_readback", "verified", "verification_required"].includes(execution.state);
}

/**
 * Creates an exact-scope decision using only identity, time, ID, and hashing supplied by Electron main.
 * Renderer payloads must not be spread into `trusted` or supply actor roles/approval booleans.
 */
export function decideApproval(input: unknown, digestCanonical: CanonicalDigest): ApprovalRecordDecision {
  const parsed = decideApprovalInputSchema.safeParse(input);
  if (!parsed.success || typeof digestCanonical !== "function") return blocked("invalid_input");
  if (!isProductionActor(parsed.data.trusted.actorId)) return blocked("unauthorized_role");
  const state = companyStateSchema.safeParse(parsed.data.state);
  const intent = actionIntentSchema.safeParse(parsed.data.intent);
  if (!state.success || !intent.success) return blocked("invalid_input");
  if (intent.data.requesterActorId !== "sales-demo") return blocked("invalid_requester");
  if (!validateProposalDigest(intent.data, digestCanonical)) return blocked("invalid_digest");
  const bindingFailure = validateCurrentBindings(state.data, intent.data);
  if (bindingFailure) return blocked(bindingFailure);

  const decidedAtMs = Date.parse(parsed.data.trusted.now);
  const approval = approvalSchema.parse({
    id: parsed.data.trusted.approvalId,
    intentId: intent.data.id,
    intentRevision: intent.data.revision,
    proposalDigest: intent.data.proposalDigest,
    epoch: intent.data.epoch,
    readSetDigest: digestCanonical(canonicalizeReadSetDigestInput(intent.data.readSet)),
    policyVersion: intent.data.policyVersion,
    skillRef: intent.data.skillRef,
    strategyRef: intent.data.strategyRef,
    requesterActorId: intent.data.requesterActorId,
    approverActorId: parsed.data.trusted.actorId,
    decision: parsed.data.decision,
    decidedAt: parsed.data.trusted.now,
    expiresAt: new Date(decidedAtMs + APPROVAL_WINDOW_MS).toISOString(),
    consumedByExecutionId: null,
  });
  return { status: "recorded", approval };
}

/** Records revocation as a replacement immutable snapshot; persistence/event history remains main-owned. */
export function revokeApproval(input: unknown): ApprovalRecordDecision {
  const parsed = revokeApprovalInputSchema.safeParse(input);
  if (!parsed.success) return blocked("invalid_input");
  if (!isProductionActor(parsed.data.trusted.actorId)) return blocked("unauthorized_role");
  const approval = approvalSchema.safeParse(parsed.data.approval);
  if (!approval.success) return blocked("invalid_input");
  if (approval.data.decision !== "approved") return blocked("approval_not_approved");
  if (Date.parse(parsed.data.trusted.now) < Date.parse(approval.data.decidedAt)) return blocked("clock_rollback");
  return {
    status: "recorded",
    approval: approvalSchema.parse({
      ...approval.data,
      decision: "revoked",
      approverActorId: parsed.data.trusted.actorId,
      decidedAt: parsed.data.trusted.now,
    }),
  };
}

/**
 * Distinguishes one-time apply authority from recovery readback. A consumed approval can never
 * return `apply_authorized`; only a matching persisted post-apply execution can return readback.
 */
export function evaluateApprovalAuthorization(input: unknown, digestCanonical: CanonicalDigest): ApprovalAuthorization {
  const parsed = authorizationInputSchema.safeParse(input);
  if (!parsed.success || typeof digestCanonical !== "function") return blocked("invalid_input");
  if (!isProductionActor(parsed.data.trusted.actorId)) return blocked("unauthorized_role");
  const state = companyStateSchema.safeParse(parsed.data.state);
  const intent = actionIntentSchema.safeParse(parsed.data.intent);
  const approval = approvalSchema.safeParse(parsed.data.approval);
  if (!state.success || !intent.success || !approval.success) return blocked("invalid_input");
  if (intent.data.epoch !== state.data.currentEpoch || approval.data.epoch !== state.data.currentEpoch) {
    return blocked("stale_context");
  }
  if (!validateProposalDigest(intent.data, digestCanonical)
    || !exactApprovalBinding(approval.data, intent.data, digestCanonical)) {
    return blocked("approval_scope_mismatch");
  }
  if (approval.data.decision === "rejected") return blocked("approval_rejected");
  if (approval.data.decision === "revoked") return blocked("approval_revoked");

  if (approval.data.consumedByExecutionId !== null) {
    const execution = executionSchema.safeParse(parsed.data.persistedExecution);
    if (!execution.success) {
      return blocked(parsed.data.persistedExecution === null ? "approval_consumed" : "invalid_input");
    }
    if (!isCommittedReadbackExecution(execution.data, approval.data, intent.data)) {
      return blocked("approval_consumed");
    }
    return {
      status: "readback_only",
      approvalId: approval.data.id,
      intentId: intent.data.id,
      executionId: execution.data.id,
    };
  }

  if (parsed.data.persistedExecution !== null) return blocked("invalid_input");
  const nowMs = Date.parse(parsed.data.trusted.now);
  const decidedAtMs = Date.parse(approval.data.decidedAt);
  if (nowMs < decidedAtMs) return blocked("clock_rollback");
  const effectiveExpiresAtMs = Math.min(
    Date.parse(approval.data.expiresAt),
    decidedAtMs + APPROVAL_WINDOW_MS,
  );
  if (nowMs > effectiveExpiresAtMs) return blocked("approval_expired");
  const bindingFailure = validateCurrentBindings(state.data, intent.data);
  if (bindingFailure) return blocked(bindingFailure);
  return { status: "apply_authorized", approvalId: approval.data.id, intentId: intent.data.id };
}
