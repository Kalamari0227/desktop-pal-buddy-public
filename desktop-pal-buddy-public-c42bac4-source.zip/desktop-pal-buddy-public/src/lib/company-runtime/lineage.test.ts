import { describe, expect, it } from "vitest";
import { deriveCompanyLineage } from "./lineage";

const epoch = "f7091d6f-e310-46f5-ae2f-a761f136f36a";
const strategyVersionId = "f6846f3d-1aa0-487a-88a1-c383ba9076ea";
const taskId = "9e650d6d-9e9f-4a09-b041-e345d16620a8";
const packetTaskId = "27862353-b4b6-43d3-bec2-2e4afe57dc06";
const intentId = "4cda2ea4-8f68-410b-ac7d-d627a3db3680";
const approvalId = "f5ef65ee-0a15-4756-b10f-c8ba90b7174c";
const executionId = "5d36a948-e977-4bf4-93d8-08c33459c42b";
const assessmentId = "8a3e281c-731e-457e-a456-e77c50f4be51";
const reviewId = "04d83596-3b4b-4b02-963f-2f0b41110312";

function snapshot() {
  return {
    currentEpoch: epoch,
    current: {
      activeStrategyRef: { strategy_id: "STRATEGY-DEMO-PRODUCTION", strategy_version_id: strategyVersionId },
      strategyVersions: [{
        strategy_id: "STRATEGY-DEMO-PRODUCTION",
        strategy_version_id: strategyVersionId,
        version: 1,
        objective: "준비 상태를 확인한 뒤 납기를 판단",
        review_question: "검사와 포장 상태가 확인되었는가?",
        content_hash: "a".repeat(64),
      }],
    },
    records: {
      tasks: [{
        workboardTaskId: taskId,
        packetTaskId,
        epoch,
        status: "done",
        packet: {
          strategy_ref: { strategy_id: "STRATEGY-DEMO-PRODUCTION", strategy_version_id: strategyVersionId },
          request_summary: "가상 ERP 우선순위 변경",
        },
        currentProposal: { intentId, revision: 1, proposalDigest: "b".repeat(64) },
        currentApprovalId: approvalId,
        executionId,
        businessOutcome: { status: "unobserved" },
      }],
      actionIntents: [{ id: intentId, revision: 1, workboardTaskId: taskId, packetTaskId, epoch }],
      approvals: [{ id: approvalId, intentId, intentRevision: 1, decision: "approved", epoch }],
      executions: [{ id: executionId, intentId, approvalId, state: "verified", epoch }],
      readbackEvidence: [{ executionId, targetPlanId: "PP-DEMO-1001", observedVersion: 2, matches: true, epoch }],
      assessmentEvidence: [{
        id: assessmentId,
        packetTaskId,
        epoch,
        finding: "needs_review",
        readSet: [{ kind: "sales_order", id: "SO-DEMO-1001", version: 1 }],
        usedAssetRef: { assetId: "learning-1", version: 1 },
        reuse: { lineageRefs: [{ assetId: "learning-1", version: 1 }] },
      }],
      experienceDrafts: [{
        id: "experience-1",
        version: 1,
        workItem: { workboardTaskId: taskId, packetTaskId },
        outcome: { state: "unobserved" },
      }],
      learningAssets: [{
        id: "learning-1",
        version: 1,
        sourceDraft: { id: "experience-1", version: 1 },
        sourceWorkItem: { workboardTaskId: taskId, packetTaskId },
        sourceLearningRefs: [],
        sharingState: "shared",
      }],
      learningManagementStrategyReview: [{
        id: "learning-1",
        version: 1,
        sourceDraft: { id: "experience-1", version: 1 },
        sourceWorkItem: { workboardTaskId: taskId, packetTaskId },
        sourceLearningRefs: [],
        sharingState: "shared",
      }],
      learningProvenance: [{ id: "learning-1", version: 1, sourceDraft: { id: "experience-1", version: 1 }, withdrawn: false }],
      strategyReviews: [{
        id: reviewId,
        epoch,
        baseStrategyRef: { strategy_id: "STRATEGY-DEMO-PRODUCTION", strategy_version_id: strategyVersionId },
        evidenceSnapshot: [{ kind: "assessment", id: assessmentId, version: 1 }],
        decision: "create_new_version",
        resultingStrategyRef: { strategy_id: "STRATEGY-DEMO-PRODUCTION", strategy_version_id: "194d29ef-806c-4e11-8ca8-485d75812fed" },
      }],
    },
    history: [],
  };
}

describe("deriveCompanyLineage", () => {
  it("derives an exact persisted chain without replacing referenced IDs", () => {
    // Given: one strategy task with persisted decision, execution, learning, reuse, and review records.
    const input = snapshot();

    // When: the lineage is derived from the renderer snapshot.
    const result = deriveCompanyLineage(input);

    // Then: every link retains its exact persisted identity and status.
    expect(result?.strategy).toMatchObject({ id: "STRATEGY-DEMO-PRODUCTION", versionId: strategyVersionId, version: 1, contentHash: "a".repeat(64) });
    expect(result?.tasks[0]).toMatchObject({ id: taskId, packetTaskId, status: "available" });
    expect(result?.tasks[0]?.relations.map(({ kind, id, version, status }) => ({ kind, id, version, status }))).toEqual([
      { kind: "packet_strategy", id: strategyVersionId, version: 1, status: "available" },
      { kind: "assessment", id: assessmentId, version: 1, status: "available" },
      { kind: "proposal", id: intentId, version: 1, status: "available" },
      { kind: "approval", id: approvalId, version: 1, status: "available" },
      { kind: "execution", id: executionId, version: 1, status: "available" },
      { kind: "readback", id: executionId, version: 2, status: "available" },
      { kind: "outcome", id: packetTaskId, version: 1, status: "unobserved" },
      { kind: "experience", id: "experience-1", version: 1, status: "unobserved" },
      { kind: "learning", id: "learning-1", version: 1, status: "available" },
      { kind: "reuse", id: "learning-1", version: 1, status: "available" },
    ]);
    expect(result?.reviews[0]).toMatchObject({ id: reviewId, version: 1, status: "available" });
    expect(result?.reviews[0]?.evidence[0]).toMatchObject({ kind: "assessment", id: assessmentId, version: 1, status: "available" });
    expect(result?.reviews[0]?.resultingStrategy).toMatchObject({ id: "194d29ef-806c-4e11-8ca8-485d75812fed", status: "missing" });
    expect(result?.tasks[0]?.relations.find((item) => item.kind === "packet_strategy")?.fields).toEqual([
      { label: "objective", value: "준비 상태를 확인한 뒤 납기를 판단" },
      { label: "review_question", value: "검사와 포장 상태가 확인되었는가?" },
      { label: "content_hash", value: "a".repeat(64) },
    ]);
    expect(result?.tasks[0]?.relations.find((item) => item.kind === "proposal")?.fields).toEqual([
      { label: "workboardTaskId", value: taskId },
      { label: "packetTaskId", value: packetTaskId },
      { label: "epoch", value: epoch },
    ]);
    expect(result?.tasks[0]?.relations.find((item) => item.kind === "approval")?.fields).toContainEqual({ label: "intentId", value: intentId });
    expect(result?.tasks[0]?.relations.find((item) => item.kind === "execution")?.fields).toContainEqual({ label: "state", value: "verified" });
    expect(result?.tasks[0]?.relations.find((item) => item.kind === "readback")?.fields).toContainEqual({ label: "targetPlanId", value: "PP-DEMO-1001" });
    expect(result?.tasks[0]?.relations.find((item) => item.kind === "assessment")?.fields).toContainEqual({ label: "finding", value: "needs_review" });
    expect(result?.tasks[0]?.relations.find((item) => item.kind === "reuse")?.fields).toContainEqual({ label: "sharingState", value: "shared" });
    expect(result?.reviews[0]?.evidence[0]?.fields).toContainEqual({ label: "finding", value: "needs_review" });
  });

  it("labels missing, withdrawn, and archived refs without substituting a newer or current record", () => {
    // Given: exact refs point to a missing proposal, withdrawn learning v1, and an old-epoch assessment.
    const base = snapshot();
    const input = {
      ...base,
      history: [{
        epoch: "1403c94a-75ca-4182-836a-b0ae0ebfde42",
        records: { assessmentEvidence: [{ id: "old-assessment", packetTaskId, epoch: "1403c94a-75ca-4182-836a-b0ae0ebfde42" }] },
      }],
    };
    input.records.tasks[0].currentProposal = { intentId: "da1b4929-a2ef-45a4-a1cd-acde937da2c5", revision: 4, proposalDigest: "c".repeat(64) };
    input.records.learningAssets = [];
    input.records.learningManagementStrategyReview = [];
    input.records.learningProvenance = [{ id: "learning-1", version: 1, sourceDraft: { id: "experience-1", version: 1 }, withdrawn: true }];
    input.records.strategyReviews[0].evidenceSnapshot = [
      { kind: "assessment", id: "old-assessment", version: 1 },
      { kind: "learning", id: "learning-1", version: 1 },
    ];

    // When: the unavailable relations are resolved.
    const result = deriveCompanyLineage(input);
    const relations = result?.tasks[0]?.relations ?? [];

    // Then: the exact refs show bounded reasons and no fallback identity appears.
    expect(relations.find((item) => item.kind === "proposal")).toMatchObject({ id: "da1b4929-a2ef-45a4-a1cd-acde937da2c5", version: 4, status: "missing", reason: "referenced proposal is not stored" });
    expect(relations.find((item) => item.kind === "learning")).toMatchObject({ id: "learning-1", version: 1, status: "withdrawn" });
    expect(result?.reviews[0]?.evidence).toEqual([
      expect.objectContaining({ kind: "assessment", id: "old-assessment", version: 1, status: "archived" }),
      expect.objectContaining({ kind: "learning", id: "learning-1", version: 1, status: "withdrawn" }),
    ]);
    expect(relations.some((item) => item.kind === "proposal" && item.id === intentId)).toBe(false);
    expect(relations.find((item) => item.kind === "proposal")?.fields).toEqual([]);
    expect(result?.reviews[0]?.evidence.every((item) => item.fields.length === 0)).toBe(true);
  });

  it("keeps a projected learning asset's exact source-draft ref when the private draft is unavailable", () => {
    // Given: management can see a shared asset but its employee-private source draft is absent from the projection.
    const input = snapshot();
    input.records.experienceDrafts = [];

    // When: lineage is derived from that bounded projection.
    const result = deriveCompanyLineage(input);

    // Then: the source draft remains navigable as missing and is not replaced by another experience record.
    expect(result?.tasks[0]?.relations).toContainEqual({
      kind: "experience",
      id: "experience-1",
      version: 1,
      status: "missing",
      reason: "referenced experience draft is not stored in this projection",
      fields: [],
    });
  });

  it("marks an approval unavailable when its persisted tuple does not match the selected task proposal", () => {
    const input = snapshot();
    const unrelatedApprovalId = "deed7ab5-041d-426a-9cae-e42bd0130846";
    input.records.approvals = [
      { id: approvalId, intentId: "cbef4721-9556-4524-8789-a87577fb70de", intentRevision: 1, decision: "approved", epoch },
      { id: unrelatedApprovalId, intentId, intentRevision: 1, decision: "approved", epoch },
    ];

    const result = deriveCompanyLineage(input);
    const approval = result?.tasks[0]?.relations.find((item) => item.kind === "approval");

    expect(approval).toEqual({
      kind: "approval",
      id: approvalId,
      version: 1,
      status: "missing",
      reason: "referenced approval does not match the selected task proposal",
      fields: [],
    });
    expect(result?.tasks[0]?.relations.some((item) => item.id === unrelatedApprovalId)).toBe(false);
  });

  it("does not use an intent from another task or epoch as the selected task proposal", () => {
    const input = snapshot();
    input.records.actionIntents = [{
      id: intentId,
      revision: 1,
      workboardTaskId: "97325cb0-6efe-4d9e-93b2-7114f8b789fb",
      packetTaskId,
      epoch: "9073dd35-5107-46ad-ab41-0af660b8a102",
    }];

    const result = deriveCompanyLineage(input);
    const relations = result?.tasks[0]?.relations ?? [];

    expect(relations.find((item) => item.kind === "proposal")).toMatchObject({ id: intentId, status: "missing" });
    expect(relations.find((item) => item.kind === "approval")).toMatchObject({ id: approvalId, status: "missing" });
    expect(relations.find((item) => item.kind === "execution")).toMatchObject({ id: executionId, status: "missing" });
  });

  it("marks an execution unavailable when its persisted intent or approval does not match the selected tuple", () => {
    const input = snapshot();
    const unrelatedExecutionId = "60a25558-56c8-4a71-81ea-b2076d449d19";
    input.records.executions = [
      { id: executionId, intentId, approvalId: "db08d52f-cd7d-40df-8197-97744a028fca", state: "verified", epoch },
      { id: unrelatedExecutionId, intentId, approvalId, state: "verified", epoch },
    ];

    const result = deriveCompanyLineage(input);
    const execution = result?.tasks[0]?.relations.find((item) => item.kind === "execution");

    expect(execution).toEqual({
      kind: "execution",
      id: executionId,
      version: 1,
      status: "missing",
      reason: "referenced execution does not match the selected proposal and approval",
      fields: [],
    });
    expect(result?.tasks[0]?.relations.some((item) => item.id === unrelatedExecutionId)).toBe(false);
  });

  it("returns null for malformed snapshots instead of inventing a lineage", () => {
    expect(deriveCompanyLineage({ currentEpoch: "not-an-epoch" })).toBeNull();
  });
});
