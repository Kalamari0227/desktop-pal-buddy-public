import { z } from "zod";

export const LINEAGE_STATUSES = ["available", "missing", "withdrawn", "archived", "unobserved"] as const;
export type LineageStatus = (typeof LINEAGE_STATUSES)[number];

export interface LineageField {
  readonly label: string;
  readonly value: string;
}

export interface LineageRelation {
  readonly kind: "packet_strategy" | "task" | "assessment" | "proposal" | "approval" | "execution" | "readback" | "outcome" | "experience" | "learning" | "reuse" | "resulting_strategy";
  readonly id: string;
  readonly version: number;
  readonly status: LineageStatus;
  readonly reason: string | null;
  readonly fields: readonly LineageField[];
}

export interface LineageTask {
  readonly id: string;
  readonly packetTaskId: string;
  readonly epoch: string;
  readonly title: string;
  readonly status: LineageStatus;
  readonly relations: readonly LineageRelation[];
  readonly readSet: readonly { readonly kind: string; readonly id: string; readonly version: number }[];
}

export interface CompanyLineage {
  readonly strategy: {
    readonly id: string;
    readonly versionId: string;
    readonly version: number;
    readonly objective: string;
    readonly reviewQuestion: string;
    readonly contentHash: string;
  };
  readonly tasks: readonly LineageTask[];
  readonly reviews: readonly {
    readonly id: string;
    readonly version: 1;
    readonly status: LineageStatus;
    readonly decision: string;
    readonly evidence: readonly LineageRelation[];
    readonly resultingStrategy: LineageRelation | null;
  }[];
}

const text = z.string().trim().min(1);
const version = z.number().int().positive();
const refSchema = z.object({ id: text, version }).passthrough();
const strategyRefSchema = z.object({ strategy_id: text, strategy_version_id: text }).strict();
const strategyVersionSchema = z.object({
  strategy_id: text,
  strategy_version_id: text,
  version,
  objective: text,
  review_question: text,
  content_hash: text,
}).passthrough();
const taskSchema = z.object({
  workboardTaskId: text,
  packetTaskId: text,
  epoch: text,
  status: text,
  packet: z.object({ strategy_ref: strategyRefSchema.optional(), request_summary: text }).passthrough(),
  currentProposal: z.object({ intentId: text, revision: version }).passthrough().nullable(),
  currentApprovalId: text.nullable(),
  executionId: text.nullable(),
  businessOutcome: z.object({ status: z.enum(["unobserved", "observed_simulated"]) }).passthrough(),
}).passthrough();
const recordsSchema = z.object({
  tasks: z.array(taskSchema).default([]),
  actionIntents: z.array(z.object({ id: text, revision: version, workboardTaskId: text, packetTaskId: text, epoch: text }).passthrough()).default([]),
  approvals: z.array(z.object({ id: text, intentId: text, intentRevision: version, epoch: text }).passthrough()).default([]),
  executions: z.array(z.object({ id: text, intentId: text, approvalId: text.nullable(), epoch: text, state: text }).passthrough()).default([]),
  readbackEvidence: z.array(z.object({ executionId: text, observedVersion: version, epoch: text }).passthrough()).default([]),
  assessmentEvidence: z.array(z.object({
    id: text,
    packetTaskId: text,
    epoch: text,
    readSet: z.array(z.object({ kind: text, id: text, version }).strict()).default([]),
    usedAssetRef: z.object({ assetId: text, version }).strict().nullable().optional(),
  }).passthrough()).default([]),
  experienceDrafts: z.array(z.object({
    id: text,
    version,
    workItem: z.object({ workboardTaskId: text, packetTaskId: text }).strict(),
    outcome: z.object({ state: z.enum(["unobserved", "observed"]) }).passthrough(),
  }).passthrough()).default([]),
  learningAssets: z.array(z.object({
    id: text,
    version,
    sourceDraft: refSchema,
    sourceWorkItem: z.object({ workboardTaskId: text, packetTaskId: text }).strict(),
    sourceLearningRefs: z.array(z.object({ assetId: text, version }).strict()).default([]),
    sharingState: z.enum(["private", "shared"]).optional(),
  }).passthrough()).default([]),
  learningManagementStrategyReview: z.array(z.object({
    id: text,
    version,
    sourceDraft: refSchema,
    sourceWorkItem: z.object({ workboardTaskId: text, packetTaskId: text }).strict(),
    sourceLearningRefs: z.array(z.object({ assetId: text, version }).strict()).default([]),
    sharingState: z.enum(["private", "shared"]).optional(),
  }).passthrough()).default([]),
  learningProvenance: z.array(z.object({ id: text, version, withdrawn: z.boolean() }).passthrough()).default([]),
  strategyReviews: z.array(z.object({
    id: text,
    epoch: text,
    baseStrategyRef: strategyRefSchema,
    evidenceSnapshot: z.array(z.object({ kind: text, id: text, version }).passthrough()),
    decision: text,
    resultingStrategyRef: strategyRefSchema.nullable(),
  }).passthrough()).default([]),
}).passthrough();
const snapshotSchema = z.object({
  currentEpoch: text,
  current: z.object({ activeStrategyRef: strategyRefSchema, strategyVersions: z.array(strategyVersionSchema) }).passthrough(),
  records: recordsSchema,
  history: z.array(z.object({ epoch: text, records: recordsSchema.partial().passthrough() }).passthrough()).default([]),
}).passthrough();

function relation(kind: LineageRelation["kind"], id: string, itemVersion: number, status: LineageStatus, reason: string | null = null, fields: readonly LineageField[] = []): LineageRelation {
  return { kind, id, version: itemVersion, status, reason, fields: status === "available" ? fields : [] };
}

function fields(...items: ReadonlyArray<readonly [string, unknown]>): LineageField[] {
  return items.flatMap(([label, value]) => {
    if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") return [{ label, value: String(value) }];
    return [];
  });
}

function evidenceKind(value: string): "task" | "assessment" | "readback" | "learning" | null {
  if (value === "task" || value === "assessment" || value === "readback" || value === "learning") return value;
  return null;
}

export function deriveCompanyLineage(value: unknown): CompanyLineage | null {
  const parsed = snapshotSchema.safeParse(value);
  if (!parsed.success) return null;
  const { currentEpoch, current, records, history } = parsed.data;
  const activeRef = current.activeStrategyRef;
  const strategy = current.strategyVersions.find((item) => item.strategy_id === activeRef.strategy_id && item.strategy_version_id === activeRef.strategy_version_id);
  if (!strategy) return null;
  const visibleAssets = [...records.learningAssets, ...records.learningManagementStrategyReview]
    .filter((item, index, items) => items.findIndex((candidate) => candidate.id === item.id && candidate.version === item.version) === index);
  const archivedEvidence = new Set(history.flatMap((entry) => [
    ...(entry.records.assessmentEvidence ?? []).map((item) => `assessment:${item.id}:1`),
    ...(entry.records.readbackEvidence ?? []).map((item) => `readback:${item.executionId}:${item.observedVersion}`),
    ...(entry.records.tasks ?? []).map((item) => `task:${item.workboardTaskId}:1`),
  ]));
  const learningStatus = (id: string, itemVersion: number): LineageStatus => {
    if (records.learningProvenance.some((item) => item.id === id && item.version === itemVersion && item.withdrawn)) return "withdrawn";
    return visibleAssets.some((item) => item.id === id && item.version === itemVersion) ? "available" : "missing";
  };
  const strategyFields = (item: z.infer<typeof strategyVersionSchema>) => fields(
    ["objective", item.objective],
    ["review_question", item.review_question],
    ["content_hash", item.content_hash],
  );
  const assessmentFields = (item: (typeof records.assessmentEvidence)[number]) => fields(
    ["packetTaskId", item.packetTaskId],
    ["epoch", item.epoch],
    ["finding", item.finding],
    ["usedAssetRef", item.usedAssetRef ? `${item.usedAssetRef.assetId} v${item.usedAssetRef.version}` : null],
  );
  const learningFields = (item: (typeof visibleAssets)[number]) => fields(
    ["sourceDraft", `${item.sourceDraft.id} v${item.sourceDraft.version}`],
    ["sourceWorkItem", `${item.sourceWorkItem.workboardTaskId}/${item.sourceWorkItem.packetTaskId}`],
    ["sharingState", item.sharingState],
  );
  const evidenceFields = (kind: "task" | "assessment" | "readback" | "learning", id: string, itemVersion: number): LineageField[] => {
    if (kind === "assessment") {
      const item = records.assessmentEvidence.find((candidate) => candidate.id === id && itemVersion === 1);
      return item ? assessmentFields(item) : [];
    }
    if (kind === "readback") {
      const item = records.readbackEvidence.find((candidate) => candidate.executionId === id && candidate.observedVersion === itemVersion);
      return item ? fields(["executionId", item.executionId], ["epoch", item.epoch], ["targetPlanId", item.targetPlanId], ["matches", item.matches]) : [];
    }
    if (kind === "learning") {
      const item = visibleAssets.find((candidate) => candidate.id === id && candidate.version === itemVersion);
      return item ? learningFields(item) : [];
    }
    const item = records.tasks.find((candidate) => candidate.workboardTaskId === id && itemVersion === 1);
    return item ? fields(["packetTaskId", item.packetTaskId], ["epoch", item.epoch], ["status", item.status], ["request_summary", item.packet.request_summary]) : [];
  };
  const evidenceStatus = (kind: string, id: string, itemVersion: number): LineageStatus => {
    if (kind === "learning") return learningStatus(id, itemVersion);
    const found = kind === "assessment"
      ? records.assessmentEvidence.some((item) => item.id === id && itemVersion === 1)
      : kind === "readback"
        ? records.readbackEvidence.some((item) => item.executionId === id && item.observedVersion === itemVersion)
        : kind === "task" && records.tasks.some((item) => item.workboardTaskId === id && itemVersion === 1);
    if (found) return "available";
    return archivedEvidence.has(`${kind}:${id}:${itemVersion}`) ? "archived" : "missing";
  };
  const tasks = records.tasks
    .filter((task) => task.packet.strategy_ref?.strategy_id === strategy.strategy_id)
    .map<LineageTask>((task) => {
      const relations: LineageRelation[] = [];
      const packetVersion = current.strategyVersions.find((item) => item.strategy_version_id === task.packet.strategy_ref?.strategy_version_id);
      if (task.packet.strategy_ref) relations.push(relation("packet_strategy", task.packet.strategy_ref.strategy_version_id, packetVersion?.version ?? 1, packetVersion ? "available" : "missing", packetVersion ? null : "referenced strategy version is not stored", packetVersion ? strategyFields(packetVersion) : []));
      const assessments = records.assessmentEvidence.filter((item) => item.packetTaskId === task.packetTaskId && item.epoch === task.epoch);
      for (const assessment of assessments) relations.push(relation("assessment", assessment.id, 1, "available", null, assessmentFields(assessment)));
      const selectedIntent = task.currentProposal
        ? records.actionIntents.find((item) => item.id === task.currentProposal?.intentId
          && item.revision === task.currentProposal.revision
          && item.workboardTaskId === task.workboardTaskId
          && item.packetTaskId === task.packetTaskId
          && item.epoch === task.epoch)
        : undefined;
      if (task.currentProposal) {
        relations.push(relation("proposal", task.currentProposal.intentId, task.currentProposal.revision, selectedIntent ? "available" : "missing", selectedIntent ? null : "referenced proposal is not stored", selectedIntent ? fields(["workboardTaskId", selectedIntent.workboardTaskId], ["packetTaskId", selectedIntent.packetTaskId], ["epoch", selectedIntent.epoch]) : []));
      }
      const approvalById = task.currentApprovalId
        ? records.approvals.find((item) => item.id === task.currentApprovalId)
        : undefined;
      const selectedApproval = task.currentApprovalId && selectedIntent
        ? records.approvals.find((item) => item.id === task.currentApprovalId
          && item.intentId === selectedIntent.id
          && item.intentRevision === selectedIntent.revision
          && item.epoch === task.epoch)
        : undefined;
      if (task.currentApprovalId) {
        const reason = selectedApproval
          ? null
          : approvalById
            ? "referenced approval does not match the selected task proposal"
            : "referenced approval is not stored";
        relations.push(relation("approval", task.currentApprovalId, 1, selectedApproval ? "available" : "missing", reason, selectedApproval ? fields(["intentId", selectedApproval.intentId], ["intentRevision", selectedApproval.intentRevision], ["epoch", selectedApproval.epoch], ["decision", selectedApproval.decision]) : []));
      }
      if (task.executionId) {
        const executionById = records.executions.find((item) => item.id === task.executionId);
        const selectedExecution = selectedIntent && selectedApproval
          ? records.executions.find((item) => item.id === task.executionId
            && item.intentId === selectedIntent.id
            && item.approvalId === selectedApproval.id
            && item.epoch === task.epoch)
          : undefined;
        const executionReason = selectedExecution
          ? null
          : executionById
            ? "referenced execution does not match the selected proposal and approval"
            : "referenced execution is not stored";
        relations.push(relation("execution", task.executionId, 1, selectedExecution ? "available" : "missing", executionReason, selectedExecution ? fields(["intentId", selectedExecution.intentId], ["approvalId", selectedExecution.approvalId], ["epoch", selectedExecution.epoch], ["state", selectedExecution.state]) : []));
        const readback = records.readbackEvidence.find((item) => item.executionId === task.executionId && item.epoch === task.epoch);
        if (selectedExecution?.state === "verified" || readback) relations.push(relation("readback", task.executionId, readback?.observedVersion ?? 1, readback ? "available" : "missing", readback ? null : "verified execution readback is not stored", readback ? fields(["executionId", readback.executionId], ["epoch", readback.epoch], ["targetPlanId", readback.targetPlanId], ["matches", readback.matches]) : []));
      }
      relations.push(relation("outcome", task.packetTaskId, 1, task.businessOutcome.status === "unobserved" ? "unobserved" : "available", task.businessOutcome.status === "unobserved" ? "business outcome has not been observed" : null, fields(["packetTaskId", task.packetTaskId], ["status", task.businessOutcome.status])));
      const drafts = records.experienceDrafts.filter((item) => item.workItem.workboardTaskId === task.workboardTaskId && item.workItem.packetTaskId === task.packetTaskId);
      for (const draft of drafts) relations.push(relation("experience", draft.id, draft.version, draft.outcome.state === "unobserved" ? "unobserved" : "available", draft.outcome.state === "unobserved" ? "experience outcome has not been observed" : null, fields(["workboardTaskId", draft.workItem.workboardTaskId], ["packetTaskId", draft.workItem.packetTaskId], ["outcome", draft.outcome.state])));
      const assets = visibleAssets.filter((item) => item.sourceWorkItem.workboardTaskId === task.workboardTaskId && item.sourceWorkItem.packetTaskId === task.packetTaskId);
      for (const asset of assets) {
        if (!drafts.some((draft) => draft.id === asset.sourceDraft.id && draft.version === asset.sourceDraft.version)) {
          relations.push(relation("experience", asset.sourceDraft.id, asset.sourceDraft.version, "missing", "referenced experience draft is not stored in this projection"));
        }
      }
      const referencedAsset = assessments.flatMap((item) => item.usedAssetRef ? [item.usedAssetRef] : [])[0];
      const assetRefs = assets.length > 0 ? assets.map((item) => ({ assetId: item.id, version: item.version })) : referencedAsset ? [referencedAsset] : [];
      for (const assetRef of assetRefs) {
        const status = learningStatus(assetRef.assetId, assetRef.version);
        const asset = visibleAssets.find((item) => item.id === assetRef.assetId && item.version === assetRef.version);
        relations.push(relation("learning", assetRef.assetId, assetRef.version, status, status === "withdrawn" ? "learning asset was withdrawn" : null, asset ? learningFields(asset) : []));
      }
      for (const assessment of assessments) if (assessment.usedAssetRef) {
        const status = learningStatus(assessment.usedAssetRef.assetId, assessment.usedAssetRef.version);
        const asset = visibleAssets.find((item) => item.id === assessment.usedAssetRef?.assetId && item.version === assessment.usedAssetRef.version);
        relations.push(relation("reuse", assessment.usedAssetRef.assetId, assessment.usedAssetRef.version, status, null, asset ? learningFields(asset) : []));
      }
      return { id: task.workboardTaskId, packetTaskId: task.packetTaskId, epoch: task.epoch, title: task.packet.request_summary, status: task.epoch === currentEpoch ? "available" : "archived", relations, readSet: assessments.flatMap((item) => item.readSet) };
    });
  return {
    strategy: { id: strategy.strategy_id, versionId: strategy.strategy_version_id, version: strategy.version, objective: strategy.objective, reviewQuestion: strategy.review_question, contentHash: strategy.content_hash },
    tasks,
    reviews: records.strategyReviews.filter((review) => review.baseStrategyRef.strategy_id === strategy.strategy_id).map((review) => ({
      id: review.id,
      version: 1,
      status: review.epoch === currentEpoch ? "available" : "archived",
      decision: review.decision,
      evidence: review.evidenceSnapshot.flatMap((item) => {
        const kind = evidenceKind(item.kind);
        if (!kind) return [];
        const status = evidenceStatus(kind, item.id, item.version);
        const reason = status === "archived"
          ? "referenced evidence belongs to an archived epoch"
          : status === "withdrawn"
            ? "referenced learning was withdrawn"
            : status === "missing"
              ? "referenced evidence is not stored"
              : null;
        return [relation(kind, item.id, item.version, status, reason, evidenceFields(kind, item.id, item.version))];
      }),
      resultingStrategy: review.resultingStrategyRef === null ? null : (() => {
        const result = current.strategyVersions.find((item) => item.strategy_id === review.resultingStrategyRef?.strategy_id && item.strategy_version_id === review.resultingStrategyRef.strategy_version_id);
        return relation("resulting_strategy", review.resultingStrategyRef.strategy_version_id, result?.version ?? 1, result ? "available" : "missing", result ? null : "resulting strategy version is not stored", result ? strategyFields(result) : []);
      })(),
    })),
  };
}
