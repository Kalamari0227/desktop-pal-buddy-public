import { describe, expect, it } from "vitest";
import { createTaskCompletionPreview, createTaskEvidenceItem, suggestEvidenceTypesForTask } from "../agentic/taskEvidenceCapture";
import { taskPacketSchema } from "../agentic/schemas";
import { createProductionPriorityChangePacket, createProductionReadinessReviewPacket } from "./packet";

const trusted = {
  packetTaskId: "fe230488-bc6c-4f4c-a89d-e8cc64b218c0",
  createdAt: "2026-09-18T00:10:00.000Z",
  requesterActorId: "sales-demo",
  strategyRef: {
    strategy_id: "STRATEGY-DEMO-PRODUCTION",
    strategy_version_id: "266cae99-24da-4595-95ed-c2c782a20417",
  },
} as const;

describe("company runtime task packets", () => {
  it("round-trips priority-change packets through the existing TaskPacket schema", () => {
    const packet = createProductionPriorityChangePacket(trusted);
    const parsed = taskPacketSchema.parse(JSON.parse(JSON.stringify(packet)));

    expect(parsed.task_type).toBe("production_priority_change");
    expect(parsed.required_approval).toBe(true);
    expect(parsed.verification_requirements).toEqual([
      { type: "production_state", required: true, command_or_source: "company runtime ERP readback" },
    ]);
    expect(suggestEvidenceTypesForTask(parsed)).toEqual(["production_state"]);
  });

  it("keeps priority-change completion denied without valid production-state evidence", () => {
    const packet = createProductionPriorityChangePacket(trusted);
    const unrelatedEvidence = createTaskEvidenceItem({
      packet,
      evidence_type: "manual_observation",
      source_system: "user",
      summary: "A person said the change looked complete.",
      created_at: "2026-09-18T00:11:00.000Z",
    }).evidence;
    const preview = createTaskCompletionPreview({
      packet,
      evidence: [unrelatedEvidence],
      result_summary: "Priority was changed.",
    });

    expect(preview.can_complete).toBe(false);
    expect(preview.missing_verification_types).toEqual(["production_state"]);
    expect(preview.validation.issues).toContain("completed task requires passing evidence for every required verification");
  });

  it("accepts one runtime production-state item in both evidence mapping paths", () => {
    const packet = createProductionPriorityChangePacket(trusted);
    const productionEvidence = createTaskEvidenceItem({
      packet,
      evidence_type: "production_state",
      source_system: "erp",
      source_ref: "company-runtime/85c540f3-5e30-4a42-97f0-3f46577cf339/execution/75250df8-6d98-4618-8419-de18316fe790",
      summary: "PP-DEMO-1001 expected and observed priority/version match.",
      created_at: "2026-09-18T00:12:00.000Z",
    }).evidence;
    const preview = createTaskCompletionPreview({
      packet,
      evidence: [productionEvidence],
      trusted_production_state_contexts: [{
        evidence_id: productionEvidence.evidence_id,
        packet_task_id: packet.task_id,
        epoch: "85c540f3-5e30-4a42-97f0-3f46577cf339",
        execution_id: "75250df8-6d98-4618-8419-de18316fe790",
        read_set_digest: "b".repeat(64),
        expected_priority: 1,
        expected_version: 2,
        observed_priority: 1,
        observed_version: 2,
        matches: true,
      }],
    });

    expect(suggestEvidenceTypesForTask(packet)).toEqual(["production_state"]);
    expect(createTaskEvidenceItem({
      packet,
      evidence_type: "production_state",
      source_system: "erp",
      source_ref: productionEvidence.source.ref,
      summary: productionEvidence.summary,
      created_at: productionEvidence.created_at,
    }).validation.valid).toBe(false);
    expect(preview.missing_verification_types).toEqual([]);
    expect(preview.validation.valid).toBe(true);
    expect(preview.can_complete).toBe(true);
  });

  it("rejects renderer-minted production-state evidence in capture and completion", () => {
    const packet = createProductionPriorityChangePacket(trusted);
    const captured = createTaskEvidenceItem({
      packet,
      evidence_type: "production_state",
      source_system: "user",
      source_ref: "renderer-says-done",
      summary: "Untrusted completion claim.",
      created_at: "2026-09-18T00:12:00.000Z",
    });
    const preview = createTaskCompletionPreview({ packet, evidence: [captured.evidence] });

    expect(captured.validation.valid).toBe(false);
    expect(captured.validation.issues).toContain("production_state evidence requires the ERP source system");
    expect(preview.validation.valid).toBe(false);
    expect(preview.can_complete).toBe(false);
  });

  it("rejects an ERP-labelled forged production state with a valid-looking runtime ref", () => {
    const packet = createProductionPriorityChangePacket(trusted);
    const forged = createTaskEvidenceItem({
      packet,
      evidence_type: "production_state",
      source_system: "erp",
      source_ref: "company-runtime/85c540f3-5e30-4a42-97f0-3f46577cf339/execution/75250df8-6d98-4618-8419-de18316fe790",
      summary: "Renderer claims the persisted readback matched.",
      created_at: "2026-09-18T00:12:00.000Z",
    });
    const preview = createTaskCompletionPreview({ packet, evidence: [forged.evidence] });

    expect(forged.validation.valid).toBe(false);
    expect(forged.validation.issues).toContain("production_state evidence requires trusted runtime readback context");
    expect(preview.validation.issues).toContain("production_state evidence requires trusted runtime readback context");
    expect(preview.can_complete).toBe(false);
  });

  it("rejects malformed UUID segments before considering runtime context", () => {
    const packet = createProductionPriorityChangePacket(trusted);
    const malformed = createTaskEvidenceItem({
      packet,
      evidence_type: "production_state",
      source_system: "erp",
      source_ref: "company-runtime/------------------------------------/execution/renderer-forged",
      summary: "Malformed runtime reference.",
      created_at: "2026-09-18T00:12:00.000Z",
    });

    expect(malformed.validation.valid).toBe(false);
    expect(malformed.validation.issues).toContain("production_state evidence requires UUID epoch and execution refs");
  });

  it("creates readiness review packets as read-only assessment work", () => {
    const packet = createProductionReadinessReviewPacket({
      ...trusted,
      packetTaskId: "6f8460af-c88c-45d3-bee2-aa5a69bcd167",
      requesterActorId: "production-demo",
    });

    expect(taskPacketSchema.parse(packet)).toMatchObject({
      task_type: "production_readiness_review",
      required_approval: false,
      verification_requirements: [{ type: "risk_assessment", required: true }],
    });
    expect(packet.forbidden_actions).toContain("do not mutate virtual ERP state");
  });
});
