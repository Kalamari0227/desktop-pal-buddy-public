import { z } from "zod";
import {
  LEARNING_REUSE_DEPARTMENTS,
  LEARNING_REUSE_MATERIAL_GROUPS,
  LEARNING_REUSE_REQUIRED_CHECKS,
  LEARNING_REUSE_WORK_TYPES,
  learningReuseApplicabilitySchema,
  learningReuseRequiredCheckSchema,
} from "./schemas";
import {
  learningAssetVersionSchema,
  learningWithdrawalSchema,
  type LearningAssetVersion,
  type LearningWithdrawal,
} from "./learning";

const epochSchema = z.string().uuid();
const reuseTargetSchema = z.object({
  epoch: epochSchema,
  workType: z.enum(LEARNING_REUSE_WORK_TYPES),
  department: z.enum(LEARNING_REUSE_DEPARTMENTS),
  materialGroup: z.enum(LEARNING_REUSE_MATERIAL_GROUPS),
}).strict();
const reuseSelectionInputSchema = z.object({
  assets: z.array(learningAssetVersionSchema),
  withdrawals: z.array(learningWithdrawalSchema),
  target: reuseTargetSchema,
  currentRequiredChecks: z.array(learningReuseRequiredCheckSchema),
}).strict();

type ReuseTarget = z.infer<typeof reuseTargetSchema>;
type RequiredCheck = z.infer<typeof learningReuseRequiredCheckSchema>;
type SourceReference = { readonly assetId: string; readonly version: number };
type LineageStatus = "verified" | "not_checked" | "source_missing" | "source_withdrawn" | "source_inaccessible" | "source_superseded" | "source_cycle";
type Lineage = { readonly status: LineageStatus; readonly refs: readonly SourceReference[] };
type LineageInspectionInput = {
  readonly assets: readonly LearningAssetVersion[];
  readonly latest: ReadonlyMap<string, LearningAssetVersion>;
  readonly withdrawals: readonly LearningWithdrawal[];
  readonly target: ReuseTarget;
};
type RedactedAiContext = {
  readonly assetId: string;
  readonly version: number;
  readonly exactPublishableSentence: string;
  readonly requiredChecks: readonly RequiredCheck[];
};

export type LearningReuseResult =
  | {
    readonly kind: "selected";
    readonly candidate: { readonly assetId: string; readonly version: number };
    readonly matchedContext: ReuseTarget;
    readonly requiredChecksToAdd: readonly RequiredCheck[];
    readonly lineage: Lineage;
    readonly aiContext: RedactedAiContext;
  }
  | {
    readonly kind: "no_candidate";
    readonly code: Exclude<LineageStatus, "verified"> | "no_matching_candidate";
    readonly lineage: Lineage;
    readonly aiContext: null;
  }
  | {
    readonly kind: "needs_review";
    readonly code: "conflicting_required_checks" | "ambiguous_candidates";
    readonly candidateIds: readonly string[];
    readonly aiContext: null;
  }
  | { readonly kind: "rejected"; readonly code: "invalid_input" | "unknown_rule"; readonly aiContext: null };

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function hasUnknownValue(value: unknown, allowed: readonly string[]): boolean {
  return typeof value === "string" && !allowed.some((candidate) => candidate === value);
}

function hasUnknownApplicability(value: unknown): boolean {
  if (!isRecord(value)) return false;
  const allowedKeys = ["workType", "department", "materialGroup", "requiredChecks"];
  if (Object.keys(value).some((key) => !allowedKeys.includes(key))) return true;
  if (hasUnknownValue(value.workType, LEARNING_REUSE_WORK_TYPES)) return true;
  if (hasUnknownValue(value.department, LEARNING_REUSE_DEPARTMENTS)) return true;
  if (hasUnknownValue(value.materialGroup, LEARNING_REUSE_MATERIAL_GROUPS)) return true;
  return Array.isArray(value.requiredChecks)
    && value.requiredChecks.some((check) => hasUnknownValue(check, LEARNING_REUSE_REQUIRED_CHECKS));
}

function hasUnknownTarget(value: unknown): boolean {
  if (!isRecord(value)) return false;
  const allowedKeys = ["epoch", "workType", "department", "materialGroup"];
  if (Object.keys(value).some((key) => !allowedKeys.includes(key))) return true;
  return hasUnknownValue(value.workType, LEARNING_REUSE_WORK_TYPES)
    || hasUnknownValue(value.department, LEARNING_REUSE_DEPARTMENTS)
    || hasUnknownValue(value.materialGroup, LEARNING_REUSE_MATERIAL_GROUPS);
}

function hasUnknownRule(input: unknown): boolean {
  if (!isRecord(input)) return false;
  if (hasUnknownTarget(input.target)) return true;
  if (Array.isArray(input.currentRequiredChecks)
    && input.currentRequiredChecks.some((check) => hasUnknownValue(check, LEARNING_REUSE_REQUIRED_CHECKS))) return true;
  return Array.isArray(input.assets) && input.assets.some((asset) =>
    isRecord(asset) && hasUnknownApplicability(asset.reuseApplicability));
}

function isWithdrawn(asset: LearningAssetVersion, withdrawals: readonly LearningWithdrawal[]): boolean {
  return withdrawals.some((withdrawal) => withdrawal.assetId === asset.id && withdrawal.version === asset.version);
}

function latestByAssetId(assets: readonly LearningAssetVersion[]): ReadonlyMap<string, LearningAssetVersion> {
  const latest = new Map<string, LearningAssetVersion>();
  for (const asset of assets) {
    const current = latest.get(asset.id);
    if (current === undefined || asset.version > current.version) latest.set(asset.id, asset);
  }
  return latest;
}

function contextMatches(asset: LearningAssetVersion, target: ReuseTarget): boolean {
  const applicability = asset.reuseApplicability;
  return asset.reuseEpoch === target.epoch
    && applicability !== null
    && applicability.workType === target.workType
    && applicability.department === target.department
    && applicability.materialGroup === target.materialGroup;
}

function hasAudience(asset: LearningAssetVersion, target: ReuseTarget): boolean {
  return asset.sharingState === "shared" && asset.targetDepartments.includes(target.department);
}

function sourceKey(reference: SourceReference): string {
  return `${reference.assetId}:${reference.version}`;
}

function assetKey(asset: LearningAssetVersion): string {
  return `${asset.id}:${asset.version}`;
}

function inspectLineage(
  candidate: LearningAssetVersion,
  input: LineageInspectionInput,
): Lineage {
  const byReference = new Map(input.assets.map((asset) => [assetKey(asset), asset]));
  const refs: SourceReference[] = [];
  const visit = (asset: LearningAssetVersion, ancestors: ReadonlySet<string>): LineageStatus => {
    for (const reference of asset.sourceLearningRefs) {
      refs.push({ assetId: reference.assetId, version: reference.version });
      const key = sourceKey(reference);
      if (ancestors.has(key)) return "source_cycle";
      const source = byReference.get(key);
      if (source === undefined) return "source_missing";
      if (input.latest.get(source.id)?.version !== source.version) return "source_superseded";
      if (isWithdrawn(source, input.withdrawals)) return "source_withdrawn";
      if (!hasAudience(source, input.target) || source.reuseEpoch !== input.target.epoch) return "source_inaccessible";
      const nextAncestors = new Set(ancestors);
      nextAncestors.add(key);
      const status = visit(source, nextAncestors);
      if (status !== "verified") return status;
    }
    return "verified";
  };
  return { status: visit(candidate, new Set([assetKey(candidate)])), refs };
}

function sameChecks(left: readonly RequiredCheck[], right: readonly RequiredCheck[]): boolean {
  return left.length === right.length && left.every((check) => right.includes(check));
}

function redactedAiContext(asset: LearningAssetVersion): RedactedAiContext {
  const applicability = learningReuseApplicabilitySchema.parse(asset.reuseApplicability);
  return {
    assetId: asset.id,
    version: asset.version,
    exactPublishableSentence: asset.exactPublishableSentence,
    requiredChecks: [...applicability.requiredChecks],
  };
}

export function selectLearningReuse(input: unknown): LearningReuseResult {
  if (hasUnknownRule(input)) return { kind: "rejected", code: "unknown_rule", aiContext: null };
  const parsed = reuseSelectionInputSchema.safeParse(input);
  if (!parsed.success) return { kind: "rejected", code: "invalid_input", aiContext: null };
  const latest = latestByAssetId(parsed.data.assets);
  const matched = [...latest.values()]
    .filter((asset) => !isWithdrawn(asset, parsed.data.withdrawals))
    .filter((asset) => hasAudience(asset, parsed.data.target))
    .filter((asset) => contextMatches(asset, parsed.data.target))
    .sort((left, right) => left.id.localeCompare(right.id));
  if (matched.length === 0) {
    return { kind: "no_candidate", code: "no_matching_candidate", lineage: { status: "not_checked", refs: [] }, aiContext: null };
  }
  const lineageInput: LineageInspectionInput = {
    assets: parsed.data.assets,
    latest,
    withdrawals: parsed.data.withdrawals,
    target: parsed.data.target,
  };
  const inspected = matched.map((asset) => ({ asset, lineage: inspectLineage(asset, lineageInput) }));
  const verified = inspected.filter((entry) => entry.lineage.status === "verified");
  if (verified.length === 0) {
    const first = inspected[0];
    if (first === undefined) return { kind: "no_candidate", code: "no_matching_candidate", lineage: { status: "not_checked", refs: [] }, aiContext: null };
    if (first.lineage.status === "verified") {
      return { kind: "no_candidate", code: "no_matching_candidate", lineage: { status: "not_checked", refs: [] }, aiContext: null };
    }
    return { kind: "no_candidate", code: first.lineage.status, lineage: first.lineage, aiContext: null };
  }
  if (verified.length > 1) {
    const first = verified[0];
    if (first === undefined) return { kind: "no_candidate", code: "no_matching_candidate", lineage: { status: "not_checked", refs: [] }, aiContext: null };
    const sameRequiredChecks = verified.every((entry) => {
      const applicability = entry.asset.reuseApplicability;
      return applicability !== null && sameChecks(applicability.requiredChecks, first.asset.reuseApplicability?.requiredChecks ?? []);
    });
    return {
      kind: "needs_review",
      code: sameRequiredChecks ? "ambiguous_candidates" : "conflicting_required_checks",
      candidateIds: verified.map((entry) => entry.asset.id),
      aiContext: null,
    };
  }
  const selected = verified[0];
  if (selected === undefined || selected.asset.reuseApplicability === null) {
    return { kind: "no_candidate", code: "no_matching_candidate", lineage: { status: "not_checked", refs: [] }, aiContext: null };
  }
  const requiredChecksToAdd = selected.asset.reuseApplicability.requiredChecks.filter((check) => !parsed.data.currentRequiredChecks.includes(check));
  return {
    kind: "selected",
    candidate: { assetId: selected.asset.id, version: selected.asset.version },
    matchedContext: parsed.data.target,
    requiredChecksToAdd,
    lineage: selected.lineage,
    aiContext: redactedAiContext(selected.asset),
  };
}
