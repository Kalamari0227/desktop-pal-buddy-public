import { describe, expect, it } from "vitest";
import {
  assessmentEvidenceSchema,
  companyStateSchema,
  runtimeEnvelopeSchema,
  runtimeStrategyVersionSchema,
  toLegacyStrategyVersion,
  validateRuntimeRequestContext,
} from "./schemas";
import { createInitialCompanyState } from "./fixtures";

const trustedSeed = {
  epoch: "85c540f3-5e30-4a42-97f0-3f46577cf339",
  strategyVersionId: "266cae99-24da-4595-95ed-c2c782a20417",
  createdAt: "2026-09-18T00:00:00.000Z",
  strategyContentHash: "a".repeat(64),
} as const;

function seed() {
  return createInitialCompanyState(trustedSeed);
}

describe("company runtime schemas", () => {
  it("round-trips the deterministic seed with integer kg quantities and three ordered plans", () => {
    const parsed = companyStateSchema.parse(seed());

    expect(parsed.productionPlans.map(({ id, priority }) => [id, priority])).toEqual([
      ["PP-DEMO-1001", 5],
      ["PP-DEMO-1002", 2],
      ["PP-DEMO-1003", 3],
    ]);
    expect(parsed.salesOrders[0].quantityKg).toBe(20_000);
    expect(parsed.inventory[0].availableKg).toBe(25_000);
    expect(parsed.stopped).toBe(false);
    expect(parsed.bootstrap).toBe(true);
  });

  it("rejects unknown envelope fields", () => {
    expect(runtimeEnvelopeSchema.safeParse({
      schemaVersion: 1,
      requestId: "72e19c22-3c35-4610-a9b4-ef31b64d6c70",
      epoch: trustedSeed.epoch,
      actorSessionRevision: 1,
      ok: false,
      error: { code: "invalid_input", message: "bad request" },
      rendererCanChooseActor: true,
    }).success).toBe(false);
  });

  it("classifies old epoch and actor session requests as stale context", () => {
    const result = validateRuntimeRequestContext({
      schemaVersion: 1,
      requestId: "72e19c22-3c35-4610-a9b4-ef31b64d6c70",
      epoch: "ffbc51b0-22e2-4a26-ae5b-d04b39579026",
      actorSessionRevision: 2,
      payload: { request: "review" },
    }, { epoch: trustedSeed.epoch, actorSessionRevision: 3 });

    expect(result).toEqual({
      valid: false,
      code: "stale_context",
      issues: ["request epoch is stale", "actor session revision is stale"],
    });
  });

  it("rejects unknown read-set object kinds", () => {
    const value = seed();
    value.bootstrapReadSet[0] = { kind: "deal", id: "SO-DEMO-1001", version: 1 } as never;
    expect(companyStateSchema.safeParse(value).success).toBe(false);
  });

  it("rejects negative and fractional kilogram values", () => {
    const negative = seed();
    negative.inventory[0].availableKg = -1;
    expect(companyStateSchema.safeParse(negative).success).toBe(false);

    const fractional = seed();
    fractional.salesOrders[0].quantityKg = 20_000.5;
    expect(companyStateSchema.safeParse(fractional).success).toBe(false);
  });

  it("rejects a strategy reference that is not an immutable stored version", () => {
    const value = seed();
    value.activeStrategyRef.strategy_version_id = "92c9d919-afb1-4486-8687-f90a58774e00";
    expect(companyStateSchema.safeParse(value).success).toBe(false);
  });

  it("rejects duplicate object IDs inside an entity collection", () => {
    const value = seed();
    value.productionPlans[1].id = "PP-DEMO-1001";
    expect(companyStateSchema.safeParse(value).success).toBe(false);
  });

  it("keeps the runtime strategy strict and projects exactly the legacy five fields", () => {
    const runtimeVersion = runtimeStrategyVersionSchema.parse(seed().strategyVersions[0]);
    expect(runtimeStrategyVersionSchema.safeParse({ ...runtimeVersion, rendererDigest: "fake" }).success).toBe(false);
    expect(toLegacyStrategyVersion(runtimeVersion)).toEqual({
      strategy_version_id: trustedSeed.strategyVersionId,
      strategy_id: "STRATEGY-DEMO-PRODUCTION",
      version: 1,
      objective: "우선순위 변경 전 영향 주문을 확인",
      review_question: "우선순위 변경이 다른 주문과 검사·출하 준비에 미치는 영향은 무엇인가?",
    });
  });

  it("persists a version-pinned reuse assessment without accepting an executable authority field", () => {
    // Given: main-owned readiness evidence for a selected shared learning version.
    const evidence = {
      id: "72e19c22-3c35-4610-a9b4-ef31b64d6c70",
      epoch: trustedSeed.epoch,
      packetTaskId: "d547e1ee-b5e2-45dc-a6ab-0ff24087476d",
      readSet: [
        { kind: "inspection", id: "INSPECTION-DEMO-1002", version: 1 },
        { kind: "inventory", id: "INV-DEMO-GA-ULSAN", version: 1 },
        { kind: "production_plan", id: "PP-DEMO-1002", version: 1 },
        { kind: "sales_order", id: "SO-DEMO-1002", version: 1 },
        { kind: "shipment", id: "SHIPMENT-DEMO-1002", version: 1 },
      ],
      baselineReadSet: [
        { kind: "inventory", id: "INV-DEMO-GA-ULSAN", version: 1 },
        { kind: "production_plan", id: "PP-DEMO-1002", version: 1 },
        { kind: "sales_order", id: "SO-DEMO-1002", version: 1 },
      ],
      additionalReadSet: [
        { kind: "inspection", id: "INSPECTION-DEMO-1002", version: 1 },
        { kind: "shipment", id: "SHIPMENT-DEMO-1002", version: 1 },
      ],
      requiredChecks: ["inspection", "packaging"],
      usedAssetRef: { assetId: "learning-ready", version: 2 },
      reuse: { status: "selected", code: null, lineageStatus: "verified", lineageRefs: [], candidateIds: [] },
      finding: "needs_review",
      reasons: ["inspection_pending_and_packaging_not_ready"],
      mutationCount: 0,
      observedAt: "2026-09-19T00:00:00.000Z",
    };

    // When / Then: the evidence parses exactly and an injected execute capability is rejected.
    expect(assessmentEvidenceSchema.parse(evidence)).toEqual(evidence);
    expect(assessmentEvidenceSchema.safeParse({ ...evidence, execute: true }).success).toBe(false);
  });
});
