import { describe, expect, it } from "vitest";
import { createDataQueryProvider } from "./dataQueryProvider";

describe("data query providers", () => {
  it("selects the demo provider in demo runtime mode", () => {
    expect(createDataQueryProvider("demo").mode).toBe("demo");
  });

  it("returns deterministic demo results for high-priority questions", async () => {
    const result = await createDataQueryProvider("demo").query("긴급 상태인 작업을 모두 보여줘");

    expect(result.sql).toContain("severity IN");
    expect(result.data).toHaveLength(2);
    expect(result.insight).toContain("하드코딩 데모");
  });
});
