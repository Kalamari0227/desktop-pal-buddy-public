import { describe, expect, it } from "vitest";
import { resolveAppRuntimeMode, runtimeConnectionLabel, runtimeConnectionState } from "./runtimeMode";

describe("resolveAppRuntimeMode", () => {
  it("defaults to demo mode for safe local/demo previews", () => {
    expect(resolveAppRuntimeMode({})).toBe("demo");
  });

  it("uses explicit app modes when configured", () => {
    expect(resolveAppRuntimeMode({ VITE_APP_MODE: "staging" })).toBe("staging");
    expect(resolveAppRuntimeMode({ VITE_APP_MODE: "production" })).toBe("production");
  });

  it("keeps backwards compatibility with VITE_DEMO_MODE=false", () => {
    expect(resolveAppRuntimeMode({ VITE_DEMO_MODE: "false" })).toBe("production");
  });

  it("returns a short reader-facing connection label", () => {
    expect(runtimeConnectionLabel("demo")).toBe("Demo");
    expect(runtimeConnectionLabel("staging")).toBe("Staging");
    expect(runtimeConnectionLabel("production")).toBe("Live");
  });

  it("describes runtime connection states for demo and real modes", () => {
    expect(
      runtimeConnectionState({
        mode: "demo",
        isConfigured: false,
        isAuthenticated: false,
      })
    ).toMatchObject({ label: "Demo", detail: "로컬 데모 데이터", tone: "neutral" });

    expect(
      runtimeConnectionState({
        mode: "staging",
        isConfigured: false,
        isAuthenticated: false,
      })
    ).toMatchObject({ detail: "Supabase 설정 필요", tone: "danger" });

    expect(
      runtimeConnectionState({
        mode: "production",
        isConfigured: true,
        isAuthenticated: false,
      })
    ).toMatchObject({ label: "Live", detail: "로그인 필요", tone: "warning" });

    expect(
      runtimeConnectionState({
        mode: "production",
        isConfigured: true,
        isAuthenticated: true,
        email: "user@example.com",
      })
    ).toMatchObject({ label: "Live", detail: "user@example.com", tone: "success" });
  });
});
