import { useCallback, useEffect, useReducer } from "react";
import type { ShellMode, ViewMode, WorkspaceLaunchState } from "@/types/shell";

interface OpenWorkspaceOptions {
  initialMode?: string;
  initialContext?: Record<string, string>;
  initialPrompt?: string;
}

interface ShellControllerState {
  viewMode: ViewMode;
  shellMode: ShellMode;
  workspaceLaunch: WorkspaceLaunchState;
}

type ShellControllerAction =
  | { type: "runtime-changed"; isElectronShell: boolean }
  | { type: "view-mode-set"; viewMode: ViewMode }
  | { type: "shell-mode-set"; shellMode: ShellMode }
  | { type: "chat-opened"; initialPrompt?: string }
  | { type: "workspace-opened"; isElectronShell: boolean; options: OpenWorkspaceOptions }
  | { type: "workspace-launch-cleared" }
  | { type: "ambient-returned"; clearPrompt: boolean };

export function getInitialShellControllerState(isElectronShell: boolean): ShellControllerState {
  return {
    viewMode: "ambient",
    shellMode: isElectronShell ? "dock" : "browser",
    workspaceLaunch: {
      initialContext: {},
      initialPromptId: 0,
    },
  };
}

function bumpWorkspacePrompt(
  workspaceLaunch: WorkspaceLaunchState,
  next: Partial<WorkspaceLaunchState>,
): WorkspaceLaunchState {
  return {
    ...workspaceLaunch,
    ...next,
    initialPromptId: workspaceLaunch.initialPromptId + 1,
  };
}

export function shellControllerReducer(
  state: ShellControllerState,
  action: ShellControllerAction,
): ShellControllerState {
  switch (action.type) {
    case "runtime-changed":
      return {
        ...state,
        shellMode: action.isElectronShell ? "dock" : "browser",
      };
    case "view-mode-set":
      return { ...state, viewMode: action.viewMode };
    case "shell-mode-set":
      return { ...state, shellMode: action.shellMode };
    case "chat-opened":
      return {
        ...state,
        viewMode: "chat",
        workspaceLaunch: bumpWorkspacePrompt(state.workspaceLaunch, {
          initialPrompt: action.initialPrompt,
        }),
      };
    case "workspace-opened": {
      const nextState = {
        ...state,
        workspaceLaunch: bumpWorkspacePrompt(state.workspaceLaunch, {
          initialMode: action.options.initialMode,
          initialContext: action.options.initialContext || {},
          initialPrompt: action.options.initialPrompt,
        }),
      };

      if (action.isElectronShell) return nextState;
      return {
        ...nextState,
        viewMode: "workspace",
        shellMode: "browser",
      };
    }
    case "workspace-launch-cleared":
      return {
        ...state,
        workspaceLaunch: {
          ...state.workspaceLaunch,
          initialMode: undefined,
          initialContext: {},
          initialPrompt: undefined,
        },
      };
    case "ambient-returned":
      return shellControllerReducer(
        { ...state, viewMode: "ambient" },
        action.clearPrompt
          ? { type: "workspace-launch-cleared" }
          : { type: "view-mode-set", viewMode: "ambient" },
      );
  }
}

export function useShellController(isElectronShell: boolean) {
  const [state, dispatch] = useReducer(
    shellControllerReducer,
    isElectronShell,
    getInitialShellControllerState,
  );

  useEffect(() => {
    dispatch({ type: "runtime-changed", isElectronShell });
  }, [isElectronShell]);

  const setViewMode = useCallback((viewMode: ViewMode) => {
    dispatch({ type: "view-mode-set", viewMode });
  }, []);

  const setShellMode = useCallback((shellMode: ShellMode) => {
    dispatch({ type: "shell-mode-set", shellMode });
  }, []);

  const openChatWithPrompt = useCallback((initialPrompt?: string) => {
    dispatch({ type: "chat-opened", initialPrompt });
  }, []);

  const openWorkspace = useCallback((options: OpenWorkspaceOptions) => {
    dispatch({ type: "workspace-opened", isElectronShell, options });
  }, [isElectronShell]);

  const clearWorkspaceLaunch = useCallback(() => {
    dispatch({ type: "workspace-launch-cleared" });
  }, []);

  const returnToAmbient = useCallback((clearPrompt = false) => {
    dispatch({ type: "ambient-returned", clearPrompt });
  }, []);

  return {
    viewMode: state.viewMode,
    setViewMode,
    shellMode: state.shellMode,
    setShellMode,
    workspaceLaunch: state.workspaceLaunch,
    openChatWithPrompt,
    openWorkspace,
    clearWorkspaceLaunch,
    returnToAmbient,
  };
}
