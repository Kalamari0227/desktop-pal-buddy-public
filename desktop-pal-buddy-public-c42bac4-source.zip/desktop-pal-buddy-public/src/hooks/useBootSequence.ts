import { useEffect, useReducer } from "react";

export type BootPhase = "init" | "emerge" | "connect" | "expand" | "reveal" | "fadeout";

export interface BootSequenceState {
  bootComplete: boolean;
  bootPhase: BootPhase;
  dockEntering: boolean;
  dockVisibleAfterBoot: boolean;
}

type BootSequenceAction =
  | { type: "electron-ready" }
  | { type: "browser-started" }
  | { type: "phase-changed"; phase: BootPhase }
  | { type: "completed" }
  | { type: "dock-entry-settled" };

export function getInitialBootSequenceState(isElectronShell: boolean): BootSequenceState {
  return {
    bootComplete: isElectronShell,
    bootPhase: isElectronShell ? "fadeout" : "init",
    dockEntering: !isElectronShell,
    dockVisibleAfterBoot: isElectronShell,
  };
}

export function bootSequenceReducer(
  state: BootSequenceState,
  action: BootSequenceAction,
): BootSequenceState {
  switch (action.type) {
    case "electron-ready":
      return getInitialBootSequenceState(true);
    case "browser-started":
      return getInitialBootSequenceState(false);
    case "phase-changed":
      return { ...state, bootPhase: action.phase };
    case "completed":
      return {
        ...state,
        bootComplete: true,
        dockEntering: true,
        dockVisibleAfterBoot: true,
      };
    case "dock-entry-settled":
      return { ...state, dockEntering: false };
  }
}

export function useBootSequence(isElectronShell: boolean) {
  const [state, dispatch] = useReducer(
    bootSequenceReducer,
    isElectronShell,
    getInitialBootSequenceState,
  );

  useEffect(() => {
    if (isElectronShell) {
      dispatch({ type: "electron-ready" });
      return;
    }

    dispatch({ type: "browser-started" });
    const timers = [
      window.setTimeout(() => dispatch({ type: "phase-changed", phase: "emerge" }), 2000),
      window.setTimeout(() => dispatch({ type: "phase-changed", phase: "connect" }), 4000),
      window.setTimeout(() => dispatch({ type: "phase-changed", phase: "expand" }), 6000),
      window.setTimeout(() => dispatch({ type: "phase-changed", phase: "reveal" }), 8000),
      window.setTimeout(() => dispatch({ type: "phase-changed", phase: "fadeout" }), 9000),
      window.setTimeout(() => dispatch({ type: "completed" }), 10000),
      window.setTimeout(() => dispatch({ type: "dock-entry-settled" }), 10100),
    ];

    return () => timers.forEach((timer) => window.clearTimeout(timer));
  }, [isElectronShell]);

  return state;
}
