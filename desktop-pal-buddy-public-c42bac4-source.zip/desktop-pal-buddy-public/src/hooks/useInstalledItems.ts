import { useCallback, useMemo } from "react";
import { useMutation, useQuery, useQueryClient, type QueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Database, Json } from "@/integrations/supabase/types";
import { toast } from "sonner";

export type InstalledItemType = "agent" | "skill" | "mcp" | "workflow" | "plugin";

type InstalledItemRow = Database["public"]["Tables"]["installed_items"]["Row"];
type InstalledItemInsert = Database["public"]["Tables"]["installed_items"]["Insert"];
type InstalledItemUpdate = Database["public"]["Tables"]["installed_items"]["Update"];

export interface InstalledItem {
  id: string;
  item_id: string;
  item_type: InstalledItemType;
  item_name: string;
  item_icon: string;
  item_description: string | null;
  is_active: boolean;
  installed_at: string;
  config: Json | null;
}

export interface InstallItemInput {
  item_id: string;
  item_type: InstalledItemType;
  item_name: string;
  item_icon?: string;
  item_description?: string;
}

export const installedItemsQueryKey = ["installed-items"] as const;

const installedItemTypes = new Set<InstalledItemType>([
  "agent",
  "skill",
  "mcp",
  "workflow",
  "plugin",
]);

function toInstalledItemType(value: string): InstalledItemType {
  return installedItemTypes.has(value as InstalledItemType)
    ? (value as InstalledItemType)
    : "plugin";
}

function fallbackIconForType(type: InstalledItemType) {
  switch (type) {
    case "agent":
      return "Bot";
    case "skill":
      return "Zap";
    case "mcp":
      return "Server";
    case "workflow":
      return "GitBranch";
    case "plugin":
      return "Puzzle";
  }
}

export function mapInstalledItemRow(row: InstalledItemRow): InstalledItem {
  const itemType = toInstalledItemType(row.item_type);
  return {
    id: row.id,
    item_id: row.item_id,
    item_type: itemType,
    item_name: row.item_name,
    item_icon: row.item_icon || fallbackIconForType(itemType),
    item_description: row.item_description,
    is_active: row.is_active,
    installed_at: row.installed_at,
    config: row.config,
  };
}

export async function fetchInstalledItems() {
  const { data, error } = await supabase
    .from("installed_items")
    .select("*")
    .order("installed_at", { ascending: false });

  if (error) throw error;
  return (data || []).map(mapInstalledItemRow);
}

async function upsertInstalledItem(item: InstallItemInput) {
  const payload: InstalledItemInsert = {
    item_id: item.item_id,
    item_type: item.item_type,
    item_name: item.item_name,
    item_icon: item.item_icon || fallbackIconForType(item.item_type),
    item_description: item.item_description || null,
    is_active: true,
  };

  const { error } = await supabase
    .from("installed_items")
    .upsert(payload, { onConflict: "owner_id,item_id,item_type" });

  if (error) throw error;
  return item;
}

async function deleteInstalledItem(id: string) {
  const { error } = await supabase.from("installed_items").delete().eq("id", id);
  if (error) throw error;
}

async function updateInstalledItemActive(id: string, active: boolean) {
  const payload: InstalledItemUpdate = { is_active: active };
  const { error } = await supabase.from("installed_items").update(payload).eq("id", id);
  if (error) throw error;
}

function updateInstalledItemsCache(
  queryClient: QueryClient,
  updater: (items: InstalledItem[]) => InstalledItem[],
) {
  queryClient.setQueryData<InstalledItem[]>(installedItemsQueryKey, (current = []) => updater(current));
}

export function useInstalledItems() {
  const queryClient = useQueryClient();
  const query = useQuery({
    queryKey: installedItemsQueryKey,
    queryFn: fetchInstalledItems,
  });

  const installMutation = useMutation({
    mutationFn: upsertInstalledItem,
    onSuccess: async (item) => {
      toast.success(`${item.item_name} 설치 완료`);
      await queryClient.invalidateQueries({ queryKey: installedItemsQueryKey });
    },
    onError: () => {
      toast.error("설치에 실패했습니다");
    },
  });

  const uninstallMutation = useMutation({
    mutationFn: deleteInstalledItem,
    onSuccess: (_data, id) => {
      updateInstalledItemsCache(queryClient, (items) => items.filter((item) => item.id !== id));
      toast.success("제거되었습니다");
    },
    onError: () => {
      toast.error("제거에 실패했습니다");
    },
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: installedItemsQueryKey });
    },
  });

  const toggleActiveMutation = useMutation({
    mutationFn: ({ id, active }: { id: string; active: boolean }) => updateInstalledItemActive(id, active),
    onSuccess: (_data, { id, active }) => {
      updateInstalledItemsCache(queryClient, (items) => (
        items.map((item) => (item.id === id ? { ...item, is_active: active } : item))
      ));
    },
    onError: () => {
      toast.error("상태 변경에 실패했습니다");
    },
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: installedItemsQueryKey });
    },
  });

  const items = useMemo(() => query.data || [], [query.data]);

  const install = useCallback(async (item: InstallItemInput) => {
    try {
      await installMutation.mutateAsync(item);
      return true;
    } catch {
      return false;
    }
  }, [installMutation]);

  const uninstall = useCallback(async (id: string) => {
    await uninstallMutation.mutateAsync(id);
  }, [uninstallMutation]);

  const toggleActive = useCallback(async (id: string, active: boolean) => {
    await toggleActiveMutation.mutateAsync({ id, active });
  }, [toggleActiveMutation]);

  const isInstalled = useCallback((itemId: string, itemType: string) => {
    return items.some((item) => item.item_id === itemId && item.item_type === itemType);
  }, [items]);

  const getByType = useCallback((type: InstalledItemType) => {
    return items.filter((item) => item.item_type === type);
  }, [items]);

  const activeAgents = useMemo(() => (
    items.filter((item) => item.item_type === "agent" && item.is_active)
  ), [items]);

  return {
    items,
    loading: query.isLoading,
    install,
    uninstall,
    toggleActive,
    isInstalled,
    getByType,
    activeAgents,
    refetch: query.refetch,
  };
}
