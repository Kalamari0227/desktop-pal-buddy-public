import { useCallback, useEffect, useReducer, useRef } from "react";
import type { Agent, AgentId, DockState } from "@/types/dock";
import { DEFAULT_AGENTS } from "@/types/dock";

interface DockSimulationState {
  dockState: DockState;
  agents: Agent[];
}

type DockSimulationAction =
  | { type: "dock-state-changed"; dockState: DockState }
  | { type: "simulation-started" }
  | { type: "agents-dispatched"; targetIds: AgentId[] }
  | { type: "activated-agents-focused" }
  | { type: "focused-agents-completed" }
  | { type: "reset-dock" }
  | { type: "risk-alerted" };

export function selectAgentTargets(actionId: string): AgentId[] {
  if (actionId === "risk") return ["risk"];
  if (actionId === "search" || actionId === "docs") return ["docs"];
  return ["market", "docs"];
}

export function getInitialDockSimulationState(initialDockState: DockState): DockSimulationState {
  return {
    dockState: initialDockState,
    agents: DEFAULT_AGENTS,
  };
}

export function dockSimulationReducer(
  state: DockSimulationState,
  action: DockSimulationAction,
): DockSimulationState {
  switch (action.type) {
    case "dock-state-changed":
      return { ...state, dockState: action.dockState };
    case "simulation-started":
      return {
        dockState: "thinking",
        agents: state.agents.map((agent) => ({ ...agent, state: "inactive" })),
      };
    case "agents-dispatched":
      return {
        dockState: "dispatching",
        agents: state.agents.map((agent) => ({
          ...agent,
          state: action.targetIds.includes(agent.id) ? "activated" : "inactive",
        })),
      };
    case "activated-agents-focused":
      return {
        dockState: "working",
        agents: state.agents.map((agent) => (
          agent.state === "activated" ? { ...agent, state: "focused" } : agent
        )),
      };
    case "focused-agents-completed":
      return {
        dockState: "completed",
        agents: state.agents.map((agent) => (
          agent.state === "focused" ? { ...agent, state: "completed" } : { ...agent, state: "available" }
        )),
      };
    case "reset-dock":
      return {
        dockState: "idle",
        agents: state.agents.map((agent) => ({ ...agent, state: "available" })),
      };
    case "risk-alerted":
      return {
        dockState: "alert",
        agents: state.agents.map((agent) => (
          agent.id === "risk" ? { ...agent, state: "activated" } : agent
        )),
      };
  }
}

export function useDockSimulation(initialDockState: DockState) {
  const [state, dispatch] = useReducer(
    dockSimulationReducer,
    initialDockState,
    getInitialDockSimulationState,
  );
  const timersRef = useRef<ReturnType<typeof window.setTimeout>[]>([]);

  const clearTimers = useCallback(() => {
    timersRef.current.forEach((timer) => window.clearTimeout(timer));
    timersRef.current = [];
  }, []);

  const schedule = useCallback((callback: () => void, delayMs: number) => {
    const timer = window.setTimeout(callback, delayMs);
    timersRef.current.push(timer);
  }, []);

  const setDockState = useCallback((dockState: DockState) => {
    dispatch({ type: "dock-state-changed", dockState });
  }, []);

  const resetDock = useCallback(() => {
    clearTimers();
    dispatch({ type: "reset-dock" });
  }, [clearTimers]);

  const flagRiskAlert = useCallback(() => {
    dispatch({ type: "risk-alerted" });
  }, []);

  const simulate = useCallback((actionId: string) => {
    clearTimers();
    dispatch({ type: "simulation-started" });

    schedule(() => {
      dispatch({ type: "agents-dispatched", targetIds: selectAgentTargets(actionId) });
      schedule(() => {
        dispatch({ type: "activated-agents-focused" });
        schedule(() => {
          dispatch({ type: "focused-agents-completed" });
          schedule(() => dispatch({ type: "reset-dock" }), 5000);
        }, 3000);
      }, 2000);
    }, 1500);
  }, [clearTimers, schedule]);

  useEffect(() => clearTimers, [clearTimers]);

  return {
    dockState: state.dockState,
    agents: state.agents,
    setDockState,
    resetDock,
    flagRiskAlert,
    simulate,
  };
}
