import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { act, renderHook, waitFor } from "@testing-library/react";
import { createElement, type ReactNode } from "react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import type { Database } from "@/integrations/supabase/types";
import { mapInstalledItemRow, useInstalledItems } from "./useInstalledItems";

type InstalledItemRow = Database["public"]["Tables"]["installed_items"]["Row"];

const mockDb = vi.hoisted(() => ({
  rows: [] as InstalledItemRow[],
  upsertCalls: [] as Array<{ payload: unknown; options: unknown }>,
  deleteCalls: [] as Array<{ column: string; value: string }>,
  updateCalls: [] as Array<{ payload: unknown; column: string; value: string }>,
}));

vi.mock("sonner", () => ({
  toast: {
    success: vi.fn(),
    error: vi.fn(),
    info: vi.fn(),
  },
}));

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    from: (table: string) => {
      if (table !== "installed_items") {
        throw new Error(`Unexpected table ${table}`);
      }

      return {
        select: () => ({
          order: async () => ({ data: mockDb.rows, error: null }),
        }),
        upsert: async (payload: InstalledItemRow, options: unknown) => {
          mockDb.upsertCalls.push({ payload, options });
          const existingIndex = mockDb.rows.findIndex((row) => (
            row.item_id === payload.item_id && row.item_type === payload.item_type
          ));
          const nextRow: InstalledItemRow = {
            config: null,
            id: `installed-${payload.item_id}`,
            installed_at: "2026-07-02T00:00:00.000Z",
            is_active: payload.is_active ?? true,
            item_description: payload.item_description ?? null,
            item_icon: payload.item_icon ?? null,
            item_id: payload.item_id,
            item_name: payload.item_name,
            item_type: payload.item_type,
            owner_id: null,
          };
          if (existingIndex >= 0) mockDb.rows[existingIndex] = nextRow;
          else mockDb.rows.unshift(nextRow);
          return { error: null };
        },
        delete: () => ({
          eq: async (column: string, value: string) => {
            mockDb.deleteCalls.push({ column, value });
            mockDb.rows = mockDb.rows.filter((row) => row.id !== value);
            return { error: null };
          },
        }),
        update: (payload: Partial<InstalledItemRow>) => ({
          eq: async (column: string, value: string) => {
            mockDb.updateCalls.push({ payload, column, value });
            mockDb.rows = mockDb.rows.map((row) => (
              row.id === value ? { ...row, ...payload } : row
            ));
            return { error: null };
          },
        }),
      };
    },
  },
}));

function createWrapper() {
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: { retry: false },
      mutations: { retry: false },
    },
  });

  return function Wrapper({ children }: { children: ReactNode }) {
    return createElement(QueryClientProvider, { client: queryClient }, children);
  };
}

const baseRow: InstalledItemRow = {
  config: null,
  id: "installed-agent",
  installed_at: "2026-07-01T00:00:00.000Z",
  is_active: true,
  item_description: "시장 브리핑",
  item_icon: null,
  item_id: "agent-market",
  item_name: "시장 에이전트",
  item_type: "agent",
  owner_id: "user-1",
};

describe("useInstalledItems", () => {
  beforeEach(() => {
    mockDb.rows = [baseRow];
    mockDb.upsertCalls = [];
    mockDb.deleteCalls = [];
    mockDb.updateCalls = [];
  });

  it("normalizes database rows for the UI", () => {
    expect(mapInstalledItemRow(baseRow)).toMatchObject({
      id: "installed-agent",
      item_type: "agent",
      item_icon: "Bot",
      item_name: "시장 에이전트",
      config: null,
    });
  });

  it("loads installed items and exposes derived helpers", async () => {
    const { result } = renderHook(() => useInstalledItems(), { wrapper: createWrapper() });

    await waitFor(() => expect(result.current.loading).toBe(false));

    expect(result.current.items).toHaveLength(1);
    expect(result.current.isInstalled("agent-market", "agent")).toBe(true);
    expect(result.current.getByType("agent")).toHaveLength(1);
    expect(result.current.activeAgents).toHaveLength(1);
  });

  it("installs, toggles, and removes items through React Query mutations", async () => {
    const { result } = renderHook(() => useInstalledItems(), { wrapper: createWrapper() });
    await waitFor(() => expect(result.current.loading).toBe(false));

    await act(async () => {
      await result.current.install({
        item_id: "skill-1",
        item_type: "skill",
        item_name: "요약 스킬",
      });
    });

    expect(mockDb.upsertCalls[0]).toMatchObject({
      payload: {
        item_id: "skill-1",
        item_type: "skill",
        item_icon: "Zap",
        is_active: true,
      },
      options: { onConflict: "owner_id,item_id,item_type" },
    });
    await waitFor(() => expect(result.current.isInstalled("skill-1", "skill")).toBe(true));

    await act(async () => {
      await result.current.toggleActive("installed-skill-1", false);
    });

    expect(mockDb.updateCalls[0]).toMatchObject({
      payload: { is_active: false },
      column: "id",
      value: "installed-skill-1",
    });
    await waitFor(() => (
      expect(result.current.items.find((item) => item.id === "installed-skill-1")?.is_active).toBe(false)
    ));

    await act(async () => {
      await result.current.uninstall("installed-skill-1");
    });

    expect(mockDb.deleteCalls[0]).toEqual({ column: "id", value: "installed-skill-1" });
    await waitFor(() => expect(result.current.isInstalled("skill-1", "skill")).toBe(false));
  });
});
