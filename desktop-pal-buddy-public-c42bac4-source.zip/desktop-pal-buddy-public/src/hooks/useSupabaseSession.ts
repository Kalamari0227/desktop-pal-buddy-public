import { useCallback, useEffect, useMemo, useState } from "react";
import type { Session } from "@supabase/supabase-js";
import { supabase, isSupabaseConfigured } from "@/integrations/supabase/client";
import {
  resolveAppRuntimeMode,
  runtimeConnectionState,
  type RuntimeConnectionState,
} from "@/lib/runtimeMode";

type AuthStatus = "checking" | "ready";

export function useSupabaseSession(): {
  mode: ReturnType<typeof resolveAppRuntimeMode>;
  isConfigured: boolean;
  isAuthenticated: boolean;
  session: Session | null;
  email: string | null;
  status: AuthStatus;
  connection: RuntimeConnectionState;
  signIn: (email: string, password: string) => Promise<void>;
  signOut: () => Promise<void>;
} {
  const mode = resolveAppRuntimeMode();
  const [session, setSession] = useState<Session | null>(null);
  const [status, setStatus] = useState<AuthStatus>("checking");
  const isConfigured = isSupabaseConfigured();

  useEffect(() => {
    let mounted = true;

    void supabase.auth.getSession().then(({ data }) => {
      if (!mounted) return;
      setSession(data.session);
      setStatus("ready");
    });

    const { data } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      setSession(nextSession);
      setStatus("ready");
    });

    return () => {
      mounted = false;
      data.subscription.unsubscribe();
    };
  }, []);

  const signIn = useCallback(async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
  }, []);

  const signOut = useCallback(async () => {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
  }, []);

  const email = session?.user.email ?? null;
  const isAuthenticated = Boolean(session);
  const connection = useMemo(
    () => runtimeConnectionState({ mode, isConfigured, isAuthenticated, email }),
    [email, isAuthenticated, isConfigured, mode]
  );

  return {
    mode,
    isConfigured,
    isAuthenticated,
    session,
    email,
    status,
    connection,
    signIn,
    signOut,
  };
}
