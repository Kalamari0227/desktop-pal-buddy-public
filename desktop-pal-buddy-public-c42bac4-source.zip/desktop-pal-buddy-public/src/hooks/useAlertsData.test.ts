import { describe, expect, it } from "vitest";
import { buildDockAlerts, mapTasksToAlerts } from "./useAlertsData";

const baseTask = {
  id: "task-1",
  title: "현대자동차 납기 리스크",
  description: null,
  severity: "critical",
  customer: "현대자동차",
  category: "delivery",
  source: "risk",
  status: "pending",
  created_at: "2026-07-01T00:00:00.000Z",
};

describe("alerts data mapping", () => {
  it("maps risky tasks into alert items", () => {
    const alerts = mapTasksToAlerts([
      baseTask,
      { ...baseTask, id: "task-2", severity: "low" },
    ]);

    expect(alerts).toEqual([
      {
        id: "task-1",
        title: "현대자동차 납기 리스크",
        description: null,
        severity: "critical",
        customer: "현대자동차",
        category: "delivery",
        source: "risk",
        status: "pending",
        createdAt: "2026-07-01T00:00:00.000Z",
      },
    ]);
  });

  it("builds dock alerts from active high-priority alerts only", () => {
    const alerts = mapTasksToAlerts([
      baseTask,
      { ...baseTask, id: "task-2", severity: "medium" },
      { ...baseTask, id: "task-3", status: "done" },
      { ...baseTask, id: "task-4", title: "기아 가격 리스크", customer: "기아", severity: "high" },
    ]);

    expect(buildDockAlerts(alerts, new Set(["task-1"]))).toEqual([
      {
        id: "task-4",
        type: "risk",
        title: "기아 가격 리스크",
        customer: "기아",
        severity: "high",
        agentId: "risk",
      },
    ]);
    expect(buildDockAlerts(alerts, new Set())).toEqual([
      {
        id: "task-1",
        type: "risk",
        title: "현대자동차 납기 리스크",
        customer: "현대자동차",
        severity: "high",
        agentId: "risk",
      },
      {
        id: "task-4",
        type: "risk",
        title: "기아 가격 리스크",
        customer: "기아",
        severity: "high",
        agentId: "risk",
      },
    ]);
  });
});
