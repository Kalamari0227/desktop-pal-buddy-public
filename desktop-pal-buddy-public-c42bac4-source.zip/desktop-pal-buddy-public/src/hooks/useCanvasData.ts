import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useCanvasStore, type CanvasNodeUI, type CanvasEdgeUI } from "@/stores/canvasStore";
import type { Database } from "@/integrations/supabase/types";

type CanvasNodeRecord = Database["public"]["Tables"]["canvas_nodes"]["Row"];

/**
 * Hook to fetch canvas_nodes and canvas_edges from DB
 * and populate the canvasStore graph state.
 */
export function useCanvasData(enabled: boolean) {
  const setNodes = useCanvasStore((s) => s.setNodes);
  const setEdges = useCanvasStore((s) => s.setEdges);
  const setSyncState = useCanvasStore((s) => s.setSyncState);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    if (!enabled || loaded) return;

    setSyncState({ loading: true, error: null });

    Promise.all([
      supabase
        .from("canvas_nodes")
        .select("*")
        .eq("status", "active")
        .order("importance_score", { ascending: false }),
      supabase
        .from("canvas_edges")
        .select("*"),
    ]).then(([nodesRes, edgesRes]) => {
      if (nodesRes.error) {
        setSyncState({ loading: false, error: nodesRes.error.message });
        return;
      }

      const dbNodes = nodesRes.data || [];
      const dbEdges = edgesRes.data || [];

      // Assign positions using a simple layout algorithm
      // Customer nodes anchor, others cluster around them
      const nodePositions = layoutNodes(dbNodes);

      const uiNodes: CanvasNodeUI[] = dbNodes.map((n, i) => ({
        id: n.id,
        type: n.type,
        title: n.title,
        x: nodePositions[i].x,
        y: nodePositions[i].y,
        z: nodePositions[i].z,
        importance_score: Number(n.importance_score) || 0.5,
        status: n.status,
      }));

      const uiEdges: CanvasEdgeUI[] = dbEdges.map((e) => ({
        id: e.id,
        source_id: e.source_id,
        target_id: e.target_id,
        type: e.type,
        status: e.status,
        confidence_score: Number(e.confidence_score) || 0.5,
      }));

      setNodes(uiNodes);
      setEdges(uiEdges);
      setSyncState({ loading: false, lastRefreshedAt: new Date() });
      setLoaded(true);
    });
  }, [enabled, loaded, setNodes, setEdges, setSyncState]);

  return loaded;
}

/**
 * Simple radial layout: customers as anchors, related nodes clustered nearby
 */
function layoutNodes(nodes: CanvasNodeRecord[]): { x: number; y: number; z: number }[] {
  const positions: { x: number; y: number; z: number }[] = Array.from({ length: nodes.length }, () => ({
    x: 0,
    y: 0,
    z: 0,
  }));
  const customerEntries = nodes
    .map((node, index) => ({ node, index }))
    .filter(({ node }) => node.type === "customer");
  const customerAnchors = new Map<string, { x: number; y: number }>();
  const unassignedEntries: Array<{ node: CanvasNodeRecord; index: number }> = [];

  customerEntries.forEach(({ node, index }, customerIndex) => {
    const angle = (customerIndex / Math.max(customerEntries.length, 1)) * Math.PI * 2 - Math.PI / 2;
    const radius = 3.4 + hashUnit(`${node.id}:customer-radius`) * 0.45;
    const { x, y } = polarToCartesian(angle, radius);
    customerAnchors.set(node.customer_id || node.id, { x, y });
    positions[index] = {
      x,
      y,
      z: hashCentered(`${node.id}:customer-z`, 0.28),
    };
  });

  nodes.forEach((node, index) => {
    if (node.type === "customer") return;

    const anchor = node.customer_id ? customerAnchors.get(node.customer_id) : undefined;
    if (!anchor) {
      unassignedEntries.push({ node, index });
      return;
    }

    const angle = hashUnit(`${node.id}:anchor-angle`) * Math.PI * 2;
    const radius = 0.8 + hashUnit(`${node.id}:anchor-radius`) * 1.15;
    const { x, y } = polarToCartesian(angle, radius);
    positions[index] = {
      x: anchor.x + x,
      y: anchor.y + y,
      z: hashCentered(`${node.id}:anchor-z`, 0.18),
    };
  });

  unassignedEntries.forEach(({ node, index }, unassignedIndex) => {
    const baseAngle = (unassignedIndex / Math.max(unassignedEntries.length, 1)) * Math.PI * 2;
    const angle = baseAngle + hashCentered(`${node.id}:free-angle`, 0.22);
    const radius = 2.25 + hashUnit(`${node.id}:free-radius`) * 1.15;
    const { x, y } = polarToCartesian(angle, radius);
    positions[index] = {
      x,
      y,
      z: hashCentered(`${node.id}:free-z`, 0.22),
    };
  });

  return positions;
}

function polarToCartesian(angle: number, radius: number) {
  return {
    x: Math.cos(angle) * radius,
    y: Math.sin(angle) * radius,
  };
}

function hashUnit(input: string) {
  let hash = 2166136261;
  for (let i = 0; i < input.length; i++) {
    hash ^= input.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return ((hash >>> 0) % 10000) / 10000;
}

function hashCentered(input: string, amplitude: number) {
  return (hashUnit(input) - 0.5) * amplitude * 2;
}
