import { useEffect } from "react";
import type { DockState } from "@/types/dock";
import type { ShellMode, ViewMode } from "@/types/shell";
import { toast } from "sonner";

interface ElectronShellSyncParams {
  isElectronShell: boolean;
  shellMode: ShellMode;
  viewMode: ViewMode;
  dockState: DockState;
  isDockWidget: boolean;
  isDockChatShell: boolean;
  setShellMode: (mode: ShellMode) => void;
  setViewMode: (mode: ViewMode) => void;
  clearWorkspaceLaunch: () => void;
}

export function useElectronShellSync({
  isElectronShell,
  shellMode,
  viewMode,
  dockState,
  isDockWidget,
  isDockChatShell,
  setShellMode,
  setViewMode,
  clearWorkspaceLaunch,
}: ElectronShellSyncParams) {
  useEffect(() => {
    if (!isElectronShell) return;

    let isMounted = true;

    window.desktop?.getShellMode().then((mode) => {
      if (!isMounted) return;
      setShellMode(mode);
      setViewMode(mode === "workspace" ? "workspace" : "ambient");
    });

    const unsubscribe = window.desktop?.onShellModeChange((mode) => {
      setShellMode(mode);
      if (mode === "workspace") {
        setViewMode("workspace");
        return;
      }

      setViewMode("ambient");
      clearWorkspaceLaunch();
    });

    return () => {
      isMounted = false;
      unsubscribe?.();
    };
  }, [clearWorkspaceLaunch, isElectronShell, setShellMode, setViewMode]);

  useEffect(() => {
    if (!isElectronShell) return;

    return window.desktop?.onUpdateDownloaded?.(() => {
      toast.success("업데이트 다운로드 완료. 앱을 다시 열면 적용됩니다.");
    });
  }, [isElectronShell]);

  useEffect(() => {
    if (!isElectronShell || viewMode === "workspace") return;
    window.desktop?.syncDockState(dockState);
  }, [dockState, viewMode, isElectronShell]);

  useEffect(() => {
    if (!isElectronShell || shellMode !== "dock") return;
    window.desktop?.syncDockSurface(viewMode === "chat" ? "chat" : "ambient");
  }, [isElectronShell, shellMode, viewMode]);

  useEffect(() => {
    if (!isElectronShell) return;

    const html = document.documentElement;
    const body = document.body;
    const previousHtmlBackground = html.style.backgroundColor;
    const previousBodyBackground = body.style.backgroundColor;

    if (isDockWidget || isDockChatShell) {
      html.style.backgroundColor = "transparent";
      body.style.backgroundColor = "transparent";
    } else {
      html.style.backgroundColor = "";
      body.style.backgroundColor = "";
    }

    return () => {
      html.style.backgroundColor = previousHtmlBackground;
      body.style.backgroundColor = previousBodyBackground;
    };
  }, [isDockChatShell, isDockWidget, isElectronShell]);
}
