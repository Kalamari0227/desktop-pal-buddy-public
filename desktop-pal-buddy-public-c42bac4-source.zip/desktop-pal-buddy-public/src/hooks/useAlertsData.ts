import { useMemo } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { DockAlert } from "@/types/dock";

export type AlertItem = {
  id: string;
  title: string;
  description: string | null;
  severity: string;
  customer: string | null;
  category: string | null;
  source: string | null;
  status: string | null;
  createdAt: string;
};

type TaskAlertRow = {
  id: string;
  title: string;
  description: string | null;
  severity: string | null;
  customer: string | null;
  category: string | null;
  source: string | null;
  status: string | null;
  created_at: string;
};

type DismissalRow = {
  task_id: string;
};

export type AlertsData = {
  alerts: AlertItem[];
  dismissedIds: Set<string>;
};

export const alertsQueryKey = ["alerts-data"];

const alertSeverities = new Set(["critical", "high", "medium"]);
const emptyAlerts: AlertItem[] = [];
const emptyDismissedIds = new Set<string>();

export function mapTasksToAlerts(tasks: TaskAlertRow[]): AlertItem[] {
  return tasks
    .filter((task) => task.severity && alertSeverities.has(task.severity))
    .map((task) => ({
      id: task.id,
      title: task.title,
      description: task.description,
      severity: task.severity ?? "medium",
      customer: task.customer,
      category: task.category,
      source: task.source,
      status: task.status,
      createdAt: task.created_at,
    }));
}

export function buildDockAlerts(alerts: AlertItem[], dismissedIds: Set<string>): DockAlert[] {
  return alerts
    .filter((alert) => alert.status !== "done")
    .filter((alert) => alert.severity === "critical" || alert.severity === "high")
    .filter((alert) => !dismissedIds.has(alert.id))
    .slice(0, 5)
    .map((alert) => ({
      id: alert.id,
      type: "risk" as const,
      title: alert.title,
      customer: alert.customer || undefined,
      severity: "high" as const,
      agentId: "risk" as const,
    }));
}

async function fetchAlertsData(): Promise<AlertsData> {
  const [tasksRes, dismissRes] = await Promise.all([
    supabase
      .from("tasks")
      .select("id, title, description, severity, customer, category, source, status, created_at")
      .order("created_at", { ascending: false }),
    supabase.from("alert_dismissals").select("task_id"),
  ]);

  if (tasksRes.error) throw tasksRes.error;
  if (dismissRes.error) throw dismissRes.error;

  return {
    alerts: mapTasksToAlerts((tasksRes.data as TaskAlertRow[]) || []),
    dismissedIds: new Set(((dismissRes.data as DismissalRow[]) || []).map((row) => row.task_id)),
  };
}

async function setAlertDismissal({ id, dismissed }: { id: string; dismissed: boolean }) {
  if (dismissed) {
    const { error } = await supabase
      .from("alert_dismissals")
      .upsert({ task_id: id }, { onConflict: "owner_id,task_id" });
    if (error) throw error;
    return;
  }

  const { error } = await supabase.from("alert_dismissals").delete().eq("task_id", id);
  if (error) throw error;
}

export function useAlertsData() {
  const queryClient = useQueryClient();
  const query = useQuery({
    queryKey: alertsQueryKey,
    queryFn: fetchAlertsData,
    staleTime: 30_000,
  });

  const mutation = useMutation({
    mutationFn: setAlertDismissal,
    onMutate: async ({ id, dismissed }) => {
      await queryClient.cancelQueries({ queryKey: alertsQueryKey });
      const previous = queryClient.getQueryData<AlertsData>(alertsQueryKey);
      queryClient.setQueryData<AlertsData>(alertsQueryKey, (current) => {
        if (!current) return current;
        const nextDismissed = new Set(current.dismissedIds);
        if (dismissed) nextDismissed.add(id);
        else nextDismissed.delete(id);
        return { ...current, dismissedIds: nextDismissed };
      });
      return { previous };
    },
    onError: (_error, _variables, context) => {
      if (context?.previous) queryClient.setQueryData(alertsQueryKey, context.previous);
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: alertsQueryKey });
    },
  });

  const alerts = query.data ? query.data.alerts : emptyAlerts;
  const dismissedIds = query.data ? query.data.dismissedIds : emptyDismissedIds;
  const activeDockAlerts = useMemo(() => buildDockAlerts(alerts, dismissedIds), [alerts, dismissedIds]);
  const allDockAlerts = useMemo(() => buildDockAlerts(alerts, new Set()), [alerts]);

  return {
    alerts,
    dismissedIds,
    activeDockAlerts,
    allDockAlerts,
    isLoading: query.isLoading,
    error: query.error,
    dismissAlert: (id: string) => mutation.mutateAsync({ id, dismissed: true }),
    restoreAlert: (id: string) => mutation.mutateAsync({ id, dismissed: false }),
    isUpdatingDismissal: mutation.isPending,
  };
}
