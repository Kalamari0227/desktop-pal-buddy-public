import { useEffect, useState } from "react";
import {
  companyRuntimeClient,
  type AiConnection,
  type CompanyRuntimeClient,
  type CompanyRuntimeResponse,
} from "@/lib/companyRuntimeClient";

type RuntimeState = "loading" | "ready" | "unavailable" | "error";

export function useCompanyRuntime(client: CompanyRuntimeClient = companyRuntimeClient) {
  const [state, setState] = useState<RuntimeState>("loading");
  const [snapshot, setSnapshot] = useState<unknown>(null);
  const [status, setStatus] = useState<unknown>(null);
  const [error, setError] = useState<unknown>(null);
  const [aiConnection, setAiConnection] = useState<AiConnection>({ state: "checking", reasonCode: "checking" });

  useEffect(() => {
    let active = true;
    let updateReceived = false;
    const apply = (response: CompanyRuntimeResponse) => {
      if (!active) return;
      if (!response.ok) {
        setState(response.error.code === "unavailable" ? "unavailable" : "error");
        setError(response.error);
        return;
      }
      const payload = response.payload as { snapshot?: unknown; status?: unknown; aiConnection?: AiConnection };
      if (payload.snapshot !== undefined) setSnapshot(payload.snapshot);
      if (payload.status !== undefined) setStatus(payload.status);
      if (payload.aiConnection !== undefined) setAiConnection(payload.aiConnection);
      setError(null);
      setState("ready");
    };
    const unsubscribe = client.subscribe((response) => {
      updateReceived = true;
      apply(response);
    });
    void client.bootstrap().then((response) => {
      if (!updateReceived) apply(response);
    });
    return () => {
      active = false;
      unsubscribe();
    };
  }, [client]);

  return {
    state,
    snapshot,
    status,
    error,
    aiConnection,
    refreshAiConnection: client.refreshAiConnection,
    client,
  };
}
