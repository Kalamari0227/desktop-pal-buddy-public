import { act, renderHook } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import {
  dockSimulationReducer,
  getInitialDockSimulationState,
  selectAgentTargets,
  useDockSimulation,
} from "./useDockSimulation";

describe("dock simulation", () => {
  afterEach(() => {
    vi.useRealTimers();
  });

  it("selects the expected agent targets for quick actions", () => {
    expect(selectAgentTargets("risk")).toEqual(["risk"]);
    expect(selectAgentTargets("search")).toEqual(["docs"]);
    expect(selectAgentTargets("briefing")).toEqual(["market", "docs"]);
  });

  it("keeps the alert state transition in the reducer", () => {
    const state = dockSimulationReducer(getInitialDockSimulationState("idle"), {
      type: "risk-alerted",
    });

    expect(state.dockState).toBe("alert");
    expect(state.agents.find((agent) => agent.id === "risk")?.state).toBe("activated");
  });

  it("advances through thinking, dispatching, working, completed, and idle", () => {
    vi.useFakeTimers();
    const { result } = renderHook(() => useDockSimulation("expanded"));

    act(() => result.current.simulate("risk"));
    expect(result.current.dockState).toBe("thinking");

    act(() => vi.advanceTimersByTime(1500));
    expect(result.current.dockState).toBe("dispatching");
    expect(result.current.agents.find((agent) => agent.id === "risk")?.state).toBe("activated");

    act(() => vi.advanceTimersByTime(2000));
    expect(result.current.dockState).toBe("working");

    act(() => vi.advanceTimersByTime(3000));
    expect(result.current.dockState).toBe("completed");

    act(() => vi.advanceTimersByTime(5000));
    expect(result.current.dockState).toBe("idle");
  });
});
