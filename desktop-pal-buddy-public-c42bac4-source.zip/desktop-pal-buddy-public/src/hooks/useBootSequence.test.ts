import { act, renderHook } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import {
  bootSequenceReducer,
  getInitialBootSequenceState,
  useBootSequence,
} from "./useBootSequence";

describe("boot sequence", () => {
  afterEach(() => {
    vi.useRealTimers();
  });

  it("starts immediately in the ready state inside Electron", () => {
    expect(getInitialBootSequenceState(true)).toEqual({
      bootComplete: true,
      bootPhase: "fadeout",
      dockEntering: false,
      dockVisibleAfterBoot: true,
    });
  });

  it("advances browser boot phases on the same schedule as the overlay", () => {
    vi.useFakeTimers();
    const { result } = renderHook(() => useBootSequence(false));

    expect(result.current).toMatchObject({
      bootComplete: false,
      bootPhase: "init",
      dockEntering: true,
      dockVisibleAfterBoot: false,
    });

    act(() => vi.advanceTimersByTime(2000));
    expect(result.current.bootPhase).toBe("emerge");

    act(() => vi.advanceTimersByTime(7000));
    expect(result.current.bootPhase).toBe("fadeout");
    expect(result.current.bootComplete).toBe(false);

    act(() => vi.advanceTimersByTime(1000));
    expect(result.current).toMatchObject({
      bootComplete: true,
      dockEntering: true,
      dockVisibleAfterBoot: true,
    });

    act(() => vi.advanceTimersByTime(100));
    expect(result.current.dockEntering).toBe(false);
  });

  it("keeps reducer transitions explicit", () => {
    const started = bootSequenceReducer(getInitialBootSequenceState(false), {
      type: "phase-changed",
      phase: "connect",
    });

    expect(started.bootPhase).toBe("connect");
    expect(bootSequenceReducer(started, { type: "completed" }).bootComplete).toBe(true);
  });
});
