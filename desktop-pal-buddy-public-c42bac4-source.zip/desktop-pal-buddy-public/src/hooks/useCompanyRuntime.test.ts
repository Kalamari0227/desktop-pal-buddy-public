import { act, renderHook, waitFor } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import type {
  CompanyRuntimeClient,
  CompanyRuntimeResponse,
} from "../lib/companyRuntimeClient";
import { useCompanyRuntime } from "./useCompanyRuntime";

const epoch = "f7091d6f-e310-46f5-ae2f-a761f136f36a";

function success(revision: number): CompanyRuntimeResponse {
  return {
    schemaVersion: 1,
    requestId: crypto.randomUUID(),
    epoch,
    actorSessionRevision: 0,
    ok: true,
    payload: { status: { role: "sales" }, snapshot: { revision } },
  };
}

function unavailable(): CompanyRuntimeResponse {
  return {
    schemaVersion: 1,
    requestId: crypto.randomUUID(),
    epoch: null,
    actorSessionRevision: null,
    ok: false,
    error: { code: "unavailable", message: "desktop_runtime_unavailable" },
  };
}

function readinessSuccess(
  revision: number,
  aiConnection: { readonly state: "checking" | "ready"; readonly reasonCode: "checking" | "local_profile_ready" },
): CompanyRuntimeResponse {
  return {
    schemaVersion: 1,
    requestId: crypto.randomUUID(),
    epoch,
    actorSessionRevision: 0,
    ok: true,
    payload: { status: { role: "sales" }, snapshot: { revision }, aiConnection },
  };
}

function clientWith(
  bootstrap: () => Promise<CompanyRuntimeResponse>,
  subscribe: (callback: (response: CompanyRuntimeResponse) => void) => () => void,
): CompanyRuntimeClient {
  const unavailableCall = vi.fn(async () => unavailable());
  return {
    bootstrap,
    subscribe,
    read: unavailableCall,
    submit: unavailableCall,
    approve: unavailableCall,
    execute: unavailableCall,
    role: unavailableCall,
    stop: unavailableCall,
    resume: unavailableCall,
    reset: unavailableCall,
    cancel: unavailableCall,
    reconcile: unavailableCall,
    refreshAiConnection: unavailableCall,
    getContext: () => null,
  };
}

describe("useCompanyRuntime", () => {
  it("keeps a completion update when a delayed checking bootstrap resolves later", async () => {
    // Given: readiness completion is published before an older bootstrap reply resolves.
    let resolveBootstrap: ((value: CompanyRuntimeResponse) => void) | undefined;
    let update: ((value: CompanyRuntimeResponse) => void) | undefined;
    const bootstrap = vi.fn(() => new Promise<CompanyRuntimeResponse>((resolve) => { resolveBootstrap = resolve; }));
    const client = clientWith(bootstrap, (callback) => {
      update = callback;
      return vi.fn();
    });
    const { result } = renderHook(() => useCompanyRuntime(client));

    // When: ready arrives first and the delayed bootstrap reports checking.
    act(() => update?.(readinessSuccess(2, { state: "ready", reasonCode: "local_profile_ready" })));
    await act(async () => resolveBootstrap?.(readinessSuccess(1, { state: "checking", reasonCode: "checking" })));

    // Then: the hook does not regress readiness to checking.
    await waitFor(() => expect(Reflect.get(result.current, "aiConnection")).toEqual({ state: "ready", reasonCode: "local_profile_ready" }));
  });

  it("bootstraps once, applies current updates, and cleans the subscription on unmount", async () => {
    let update: ((value: CompanyRuntimeResponse) => void) | undefined;
    const unsubscribe = vi.fn();
    const bootstrap = vi.fn(async () => success(1));
    const subscribe = vi.fn((callback: (response: CompanyRuntimeResponse) => void) => {
      update = callback;
      return unsubscribe;
    });
    const client = clientWith(bootstrap, subscribe);
    const { result, unmount } = renderHook(() => useCompanyRuntime(client));
    await waitFor(() => expect(result.current.state).toBe("ready"));
    expect(result.current.snapshot).toEqual({ revision: 1 });
    act(() => update?.(success(2)));
    expect(result.current.snapshot).toEqual({ revision: 2 });
    unmount();
    expect(unsubscribe).toHaveBeenCalledTimes(1);
  });

  it("reports browser unavailable and ignores bootstrap completion after unmount", async () => {
    let resolve: ((value: CompanyRuntimeResponse) => void) | undefined;
    const bootstrap = vi.fn(() => new Promise<CompanyRuntimeResponse>((done) => { resolve = done; }));
    const subscribe = vi.fn(() => vi.fn());
    const client = clientWith(bootstrap, subscribe);
    const { result, unmount } = renderHook(() => useCompanyRuntime(client));
    expect(result.current.state).toBe("loading");
    unmount();
    await act(async () => resolve?.(unavailable()));
    expect(subscribe).toHaveBeenCalledTimes(1);
  });
});
