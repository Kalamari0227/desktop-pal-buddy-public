import { act, renderHook } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { useShellController } from "./useShellController";

describe("shell controller", () => {
  it("opens and clears browser workspace launch state", () => {
    const { result } = renderHook(() => useShellController(false));

    act(() => {
      result.current.openWorkspace({
        initialMode: "risk",
        initialContext: { customer: "현대자동차" },
        initialPrompt: "리스크를 정리해줘",
      });
    });

    expect(result.current.viewMode).toBe("workspace");
    expect(result.current.shellMode).toBe("browser");
    expect(result.current.workspaceLaunch).toMatchObject({
      initialMode: "risk",
      initialContext: { customer: "현대자동차" },
      initialPrompt: "리스크를 정리해줘",
      initialPromptId: 1,
    });

    act(() => result.current.returnToAmbient(true));
    expect(result.current.viewMode).toBe("ambient");
    expect(result.current.workspaceLaunch.initialPrompt).toBeUndefined();
  });

  it("does not force Electron workspace view before the shell reports it", () => {
    const { result } = renderHook(() => useShellController(true));

    act(() => {
      result.current.openWorkspace({ initialMode: "meeting" });
    });

    expect(result.current.shellMode).toBe("dock");
    expect(result.current.viewMode).toBe("ambient");
    expect(result.current.workspaceLaunch.initialMode).toBe("meeting");
  });
});
