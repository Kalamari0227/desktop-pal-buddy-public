import { evidenceItemToAgentEvidenceInsert, type AgentEvidenceRow } from "@/lib/agentic/evidencePersistence";
import { createWorkerEvent, workerEventToAgentEventInsert, type AgentEventRow } from "@/lib/agentic/eventPersistence";
import { gatewayPacketToWorkboardTaskInsert } from "@/lib/agentic/gatewayWorkboardIntake";
import { withDemoTaskPacket, type DemoPacketMetadata } from "@/lib/agentic/demoTaskPackets";
import { workerResultToAgentResultInsert, type AgentResultRow } from "@/lib/agentic/resultPersistence";
import { createStrategyGatewayDraft } from "@/lib/agentic/strategy";
import { validateWorkboardStatusGate } from "@/lib/agentic/taskCompletionGate";
import { createTaskEvidenceItem } from "@/lib/agentic/taskEvidenceCapture";
import type { TaskWorkboardRouteInput } from "@/lib/agentic/taskWorkboardRouting";
import type { EvidenceItem, StrategyRef, TaskPacket, WorkerResult } from "@/lib/agentic/types";
import { demoStrategyVersions } from "./demoStrategyCatalog";

export { demoStrategies, demoStrategyVersions } from "./demoStrategyCatalog";

export type DemoStrategyTaskRow = TaskWorkboardRouteInput & DemoPacketMetadata & {
  id: string;
  title: string;
  description: string | null;
  source: string;
  source_id: string;
  severity: string;
  customer: string;
  category: string;
  status: string;
  created_at: string;
  updated_at: string;
  owner_id: null;
};

export interface DemoStrategyRows {
  tasks: DemoStrategyTaskRow[];
  evidence: AgentEvidenceRow[];
  events: AgentEventRow[];
  results: AgentResultRow[];
}

const refV1: StrategyRef = {
  strategy_id: "delivery-risk-early-warning",
  strategy_version_id: "delivery-risk-early-warning-v1",
};

const refV2: StrategyRef = {
  strategy_id: "delivery-risk-early-warning",
  strategy_version_id: "delivery-risk-early-warning-v2",
};

function createTaskRow(input: {
  packet: TaskPacket;
  id: string;
  customer: string;
  status: "pending" | "done";
  created_at: string;
}): DemoStrategyTaskRow {
  const insert = gatewayPacketToWorkboardTaskInsert({
    packet: input.packet,
    workboard_task_id: input.id,
    created_at: input.created_at,
  });

  return withDemoTaskPacket({
    id: insert.id!,
    title: insert.title,
    description: insert.description ?? null,
    source: insert.source!,
    source_id: insert.source_id!,
    severity: insert.severity!,
    customer: input.customer,
    category: insert.category!,
    status: input.status,
    created_at: insert.created_at!,
    updated_at: insert.updated_at!,
    owner_id: null,
  }, input.packet);
}

function evidenceRow(workboardTaskId: string, evidence: EvidenceItem, index: number): AgentEvidenceRow {
  const insert = evidenceItemToAgentEvidenceInsert({ workboard_task_id: workboardTaskId, evidence });
  return {
    id: `demo-strategy-evidence-row-${index}`,
    owner_id: null,
    task_id: insert.task_id,
    packet_task_id: insert.packet_task_id,
    evidence_id: insert.evidence_id,
    evidence_type: insert.evidence_type,
    summary: insert.summary,
    source_system: insert.source_system,
    source_url: insert.source_url ?? null,
    source_path: insert.source_path ?? null,
    source_command: insert.source_command ?? null,
    source_ref: insert.source_ref ?? null,
    status: insert.status,
    raw_excerpt: insert.raw_excerpt ?? null,
    artifact_path: insert.artifact_path ?? null,
    created_at: insert.created_at ?? evidence.created_at,
  };
}

function eventRow(workboardTaskId: string, packetTaskId: string, index: number, eventType: "accepted" | "completed", createdAt: string): AgentEventRow {
  const event = createWorkerEvent({
    packet_task_id: packetTaskId,
    event_type: eventType,
    message: eventType === "accepted" ? "가상 전략 작업을 접수했습니다." : "가상 증거 검증을 마쳤습니다.",
    created_at: createdAt,
    sequence: index,
  });
  const insert = workerEventToAgentEventInsert({ workboard_task_id: workboardTaskId, event });
  return {
    id: `demo-strategy-event-row-${index}`,
    owner_id: null,
    task_id: insert.task_id,
    packet_task_id: insert.packet_task_id,
    event_id: insert.event_id,
    event_type: insert.event_type,
    message: insert.message,
    evidence_ref_id: insert.evidence_ref_id ?? null,
    severity: insert.severity ?? null,
    requires_user_action: insert.requires_user_action ?? false,
    created_at: insert.created_at ?? createdAt,
  };
}

function resultRow(workboardTaskId: string, packetTaskId: string, result: WorkerResult): AgentResultRow {
  const createdAt = "2026-09-17T09:30:00.000Z";
  const insert = workerResultToAgentResultInsert({
    workboard_task_id: workboardTaskId,
    packet_task_id: packetTaskId,
    result,
    blockers: [],
    next_action: "현재 납기 일정을 유지하며 다음 가상 신호를 확인합니다.",
    created_at: createdAt,
  });
  return {
    id: "demo-strategy-result-row-v1",
    owner_id: null,
    task_id: insert.task_id,
    packet_task_id: insert.packet_task_id,
    outcome: insert.outcome,
    summary: insert.summary,
    details: insert.details ?? null,
    changed_paths: insert.changed_paths ?? [],
    checked_refs: insert.checked_refs ?? [],
    risks: insert.risks ?? [],
    blockers: insert.blockers ?? [],
    next_action: insert.next_action ?? null,
    retention_decision: insert.retention_decision ?? null,
    created_at: insert.created_at ?? createdAt,
  };
}

export function createDemoStrategyRows(): DemoStrategyRows {
  const v1Draft = createStrategyGatewayDraft({
    raw_user_request: "가상한빛모빌리티 주문의 납기 지연 위험을 확인해줘",
    context_refs: [
      { type: "customer_account", label: "가상 고객", value: "가상한빛모빌리티" },
      { type: "sales_order", label: "가상 주문", value: "VSO-1001" },
      { type: "due_date", label: "가상 납기", value: "2026-09-25" },
    ],
    created_at: "2026-09-17T09:00:00.000Z",
    created_by: "demo-strategy-fixture",
  }, refV1, demoStrategyVersions);
  const v2Draft = createStrategyGatewayDraft({
    raw_user_request: "가상새봄부품 주문의 납기 지연 위험을 확인해줘",
    context_refs: [
      { type: "customer_account", label: "가상 고객", value: "가상새봄부품" },
      { type: "sales_order", label: "가상 주문", value: "VSO-2001" },
      { type: "due_date", label: "가상 납기", value: "2026-09-29" },
    ],
    created_at: "2026-09-18T08:00:00.000Z",
    created_by: "demo-strategy-fixture",
  }, refV2, demoStrategyVersions);

  if (!v1Draft.packet || !v2Draft.packet) {
    throw new Error("demo strategy packets must be valid");
  }

  const v1Task = createTaskRow({
    packet: v1Draft.packet,
    id: "demo-strategy-task-v1-completed",
    customer: "가상한빛모빌리티",
    status: "done",
    created_at: "2026-09-17T09:00:00.000Z",
  });
  const v2Task = createTaskRow({
    packet: v2Draft.packet,
    id: "demo-strategy-task-v2-pending",
    customer: "가상새봄부품",
    status: "pending",
    created_at: "2026-09-18T08:00:00.000Z",
  });

  const evidence = [
    createTaskEvidenceItem({
      packet: v1Draft.packet,
      evidence_type: "order_status",
      source_system: "erp",
      source_ref: "VSO-1001-fictional",
      summary: "가상 주문 VSO-1001은 출하 준비 상태입니다.",
      created_at: "2026-09-17T09:10:00.000Z",
      sequence: 1,
    }).evidence,
    createTaskEvidenceItem({
      packet: v1Draft.packet,
      evidence_type: "delivery_schedule",
      source_system: "spreadsheet",
      source_ref: "fictional-delivery-plan-v1",
      summary: "가상 출하 계획은 고객 납기 전에 도착하는 일정입니다.",
      created_at: "2026-09-17T09:15:00.000Z",
      sequence: 2,
    }).evidence,
    createTaskEvidenceItem({
      packet: v1Draft.packet,
      evidence_type: "risk_assessment",
      source_system: "gateway",
      source_ref: "fictional-risk-review-v1",
      summary: "가상 주문의 현재 납기 지연 위험은 낮음으로 평가했습니다.",
      created_at: "2026-09-17T09:20:00.000Z",
      sequence: 3,
    }).evidence,
  ];
  const result: WorkerResult = {
    outcome: "passed",
    summary: "가상 주문의 필수 납기 증거를 확인했으며 현재 지연 위험은 낮습니다.",
    details: "이 결과는 데모 fixture이며 실제 고객 또는 운영 데이터가 아닙니다.",
    risks: ["현재 페이지 세션을 새로고침하면 데모 상태가 초기화됩니다."],
  };

  const gate = validateWorkboardStatusGate({
    packet: v1Draft.packet,
    current_status: "in_progress",
    target_status: "done",
    evidence,
    result_summary: result.summary,
    result_details: result.details,
    outcome: result.outcome,
  });
  if (!gate.allowed) {
    throw new Error(`completed demo fixture failed the completion gate: ${gate.issues.join("; ")}`);
  }

  return {
    tasks: [v1Task, v2Task],
    evidence: evidence.map((item, index) => evidenceRow(v1Task.id, item, index + 1)),
    events: [
      eventRow(v1Task.id, v1Draft.packet.task_id, 1, "accepted", "2026-09-17T09:01:00.000Z"),
      eventRow(v1Task.id, v1Draft.packet.task_id, 2, "completed", "2026-09-17T09:30:00.000Z"),
      eventRow(v2Task.id, v2Draft.packet.task_id, 3, "accepted", "2026-09-18T08:01:00.000Z"),
    ],
    results: [resultRow(v1Task.id, v1Draft.packet.task_id, result)],
  };
}
