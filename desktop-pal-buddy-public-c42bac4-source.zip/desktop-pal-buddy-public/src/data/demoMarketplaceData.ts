// Public demo marketplace data captured from the original Supabase public-read tables.
// Keep this static for safe external demos: no Supabase/API calls are made in demo mode.

export const originalDemoMarketplaceData = {
  "marketplace_agents": [
    {
      "id": "62be653a-ed9b-4b63-b03d-fb67520d8a86",
      "name": "문서 작성 도우미",
      "description": "보고서, 제안서, 이메일 등 비즈니스 문서를 전문적으로 작성하는 에이전트입니다.",
      "category": "writing",
      "icon": "FileEdit",
      "prompt_template": "당신은 비즈니스 문서 작성 전문가입니다. 명확하고 전문적인 문서를 작성하세요.",
      "creator_name": "WriteFlow",
      "installs": 5201,
      "rating": 4.9,
      "tags": [
        "문서",
        "보고서",
        "작문",
        "이메일"
      ],
      "is_featured": true,
      "created_at": "2026-03-08T17:05:19.831794+00:00",
      "updated_at": "2026-03-08T17:05:19.831794+00:00"
    },
    {
      "id": "9099e373-8856-49d6-982d-0babf0ca83b5",
      "name": "고객 응대 전문가",
      "description": "고객 문의에 친절하고 정확하게 응답하는 CS 전문 에이전트입니다. 불만 처리, FAQ 안내, 에스컬레이션 판단을 수행합니다.",
      "category": "customer-service",
      "icon": "Headphones",
      "prompt_template": "당신은 고객 응대 전문가입니다. 항상 공감하며 친절하게 응답하세요.",
      "creator_name": "ServiceAI",
      "installs": 4502,
      "rating": 4.8,
      "tags": [
        "고객지원",
        "CS",
        "응대"
      ],
      "is_featured": true,
      "created_at": "2026-03-08T17:05:19.831794+00:00",
      "updated_at": "2026-03-08T17:05:19.831794+00:00"
    },
    {
      "id": "d6c9e53a-f5d0-41c5-ba6d-6372c81ffe85",
      "name": "데이터 분석가",
      "description": "데이터를 분석하고 인사이트를 도출하는 전문 에이전트입니다. SQL 쿼리 작성, 차트 추천, 트렌드 분석을 지원합니다.",
      "category": "analytics",
      "icon": "BarChart3",
      "prompt_template": "당신은 데이터 분석 전문가입니다. 데이터 기반으로 명확한 인사이트를 제공하세요.",
      "creator_name": "DataMind",
      "installs": 3801,
      "rating": 4.7,
      "tags": [
        "데이터",
        "분석",
        "SQL",
        "인사이트"
      ],
      "is_featured": true,
      "created_at": "2026-03-08T17:05:19.831794+00:00",
      "updated_at": "2026-03-08T17:05:19.831794+00:00"
    },
    {
      "id": "6de74982-c138-4479-b459-2481464c7474",
      "name": "마케팅 카피라이터",
      "description": "광고 카피, SNS 콘텐츠, 랜딩 페이지 문구를 창의적으로 작성하는 에이전트입니다.",
      "category": "marketing",
      "icon": "Megaphone",
      "prompt_template": "당신은 마케팅 카피라이터입니다. 타겟 고객에 맞는 매력적인 카피를 작성하세요.",
      "creator_name": "CopyGenius",
      "installs": 3400,
      "rating": 4.7,
      "tags": [
        "마케팅",
        "카피",
        "SNS",
        "광고"
      ],
      "is_featured": true,
      "created_at": "2026-03-08T17:05:19.831794+00:00",
      "updated_at": "2026-03-08T17:05:19.831794+00:00"
    },
    {
      "id": "10a46247-67bd-4f6e-a53b-d7a6dfd1b56d",
      "name": "코드 리뷰어",
      "description": "코드를 분석하여 버그, 성능 이슈, 보안 취약점을 찾고 개선안을 제안하는 에이전트입니다.",
      "category": "development",
      "icon": "Code",
      "prompt_template": "당신은 시니어 코드 리뷰어입니다. 코드의 품질, 보안, 성능을 종합적으로 평가하세요.",
      "creator_name": "CodeGuard",
      "installs": 2900,
      "rating": 4.6,
      "tags": [
        "코드리뷰",
        "개발",
        "보안",
        "품질"
      ],
      "is_featured": true,
      "created_at": "2026-03-08T17:05:19.831794+00:00",
      "updated_at": "2026-03-08T17:05:19.831794+00:00"
    },
    {
      "id": "6e5e3e50-f99c-42e3-8ba8-cbb29820af1d",
      "name": "번역 전문가",
      "description": "한/영/일/중 비즈니스 문서를 자연스럽게 번역하는 다국어 전문 에이전트입니다.",
      "category": "translation",
      "icon": "Languages",
      "prompt_template": "당신은 전문 번역가입니다. 문맥과 뉘앙스를 살려 자연스러운 번역을 제공하세요.",
      "creator_name": "TransPro",
      "installs": 2600,
      "rating": 4.5,
      "tags": [
        "번역",
        "다국어",
        "로컬라이제이션"
      ],
      "is_featured": false,
      "created_at": "2026-03-08T17:05:19.831794+00:00",
      "updated_at": "2026-03-08T17:05:19.831794+00:00"
    },
    {
      "id": "77fc1c40-8f24-4878-8b79-bfb5a591f8e8",
      "name": "회의 요약 비서",
      "description": "회의 내용을 자동으로 요약하고 액션 아이템을 추출하는 에이전트입니다.",
      "category": "productivity",
      "icon": "ClipboardList",
      "prompt_template": "당신은 회의 요약 전문가입니다. 핵심 논의 사항과 액션 아이템을 구조화하여 정리하세요.",
      "creator_name": "MeetBot",
      "installs": 2101,
      "rating": 4.4,
      "tags": [
        "회의",
        "요약",
        "액션아이템",
        "미팅"
      ],
      "is_featured": false,
      "created_at": "2026-03-08T17:05:19.831794+00:00",
      "updated_at": "2026-03-08T17:05:19.831794+00:00"
    },
    {
      "id": "07c3ffed-2e25-462d-a85a-88c9e1d49f47",
      "name": "UX 리서처",
      "description": "사용자 피드백을 분석하고 UX 개선점을 도출하는 에이전트입니다.",
      "category": "design",
      "icon": "MousePointerClick",
      "prompt_template": "당신은 UX 리서처입니다. 사용자 관점에서 경험을 분석하고 개선안을 제시하세요.",
      "creator_name": "UXBot",
      "installs": 1600,
      "rating": 4.4,
      "tags": [
        "UX",
        "리서치",
        "사용자경험",
        "피드백"
      ],
      "is_featured": false,
      "created_at": "2026-03-08T17:05:19.831794+00:00",
      "updated_at": "2026-03-08T17:05:19.831794+00:00"
    },
    {
      "id": "d9fad27a-9999-430e-a191-ce6fcec6bfde",
      "name": "법률 자문 어시스턴트",
      "description": "계약서 검토, 법률 용어 해석, 컴플라이언스 체크를 지원하는 에이전트입니다.",
      "category": "legal",
      "icon": "Scale",
      "prompt_template": "당신은 법률 자문 어시스턴트입니다. 법적 관점에서 정확한 조언을 제공하세요.",
      "creator_name": "LegalAI",
      "installs": 1200,
      "rating": 4.3,
      "tags": [
        "법률",
        "계약서",
        "컴플라이언스"
      ],
      "is_featured": false,
      "created_at": "2026-03-08T17:05:19.831794+00:00",
      "updated_at": "2026-03-08T17:05:19.831794+00:00"
    },
    {
      "id": "5c16f916-c368-4215-931f-72c29573fa90",
      "name": "리스크 분석가",
      "description": "비즈니스 리스크를 분석하고 대응 방안을 제시하는 전문 에이전트입니다.",
      "category": "risk",
      "icon": "ShieldAlert",
      "prompt_template": "당신은 리스크 분석 전문가입니다. 잠재적 위험 요소를 식별하고 대응책을 제안하세요.",
      "creator_name": "RiskEye",
      "installs": 890,
      "rating": 4.2,
      "tags": [
        "리스크",
        "위험분석",
        "대응방안"
      ],
      "is_featured": false,
      "created_at": "2026-03-08T17:05:19.831794+00:00",
      "updated_at": "2026-03-08T17:05:19.831794+00:00"
    },
    {
      "id": "7b055ee9-10ef-4b75-8b5e-695539000a1f",
      "name": "주간 보고서 생성기",
      "description": "주간 실적과 이슈를 자동으로 보고서 형태로 작성하는 에이전트",
      "category": "productivity",
      "icon": "BarChart3",
      "prompt_template": "이번 주 주간 보고서를 작성해줘. 실적 현황, 주요 이슈, 다음 주 계획을 포함해서.",
      "creator_name": "강다희",
      "installs": 45,
      "rating": 4.9,
      "tags": [
        "보고서",
        "주간",
        "실적"
      ],
      "is_featured": true,
      "created_at": "2026-03-08T15:45:04.861162+00:00",
      "updated_at": "2026-03-08T15:45:04.861162+00:00"
    },
    {
      "id": "76924165-4dd8-40cc-9fc8-b1086ca378fc",
      "name": "고객 미팅 브리핑 생성기",
      "description": "고객사 방문/회의 전 핵심 이슈, 최근 거래 현황, 주의사항을 자동으로 정리해주는 에이전트",
      "category": "sales",
      "icon": "Briefcase",
      "prompt_template": "다음 고객사에 대한 미팅 브리핑을 작성해줘: {{customer}}. 최근 거래 현황, 주요 이슈, 주의사항을 포함해서.",
      "creator_name": "김철수",
      "installs": 42,
      "rating": 4.8,
      "tags": [
        "미팅",
        "브리핑",
        "고객관리"
      ],
      "is_featured": true,
      "created_at": "2026-03-08T15:45:04.861162+00:00",
      "updated_at": "2026-03-08T15:45:04.861162+00:00"
    },
    {
      "id": "2c2c21fb-4846-432f-be0a-1f9bbf228a85",
      "name": "납기 리스크 스캐너",
      "description": "전체 고객사의 납기 현황을 스캔하고 지연 위험이 있는 건을 자동 탐지하는 에이전트",
      "category": "risk",
      "icon": "ShieldAlert",
      "prompt_template": "현재 납기 현황을 전체 스캔하고, 지연 위험이 있는 건을 우선순위별로 정리해줘.",
      "creator_name": "박영희",
      "installs": 38,
      "rating": 4.6,
      "tags": [
        "납기",
        "리스크",
        "자동탐지"
      ],
      "is_featured": true,
      "created_at": "2026-03-08T15:45:04.861162+00:00",
      "updated_at": "2026-03-08T15:45:04.861162+00:00"
    },
    {
      "id": "cc16ae1c-bb68-44e5-8314-3faec9c94b2c",
      "name": "시장 동향 요약기",
      "description": "철강/자동차 업계 최신 뉴스와 시장 동향을 요약 정리하는 에이전트",
      "category": "market",
      "icon": "TrendingUp",
      "prompt_template": "오늘의 철강/자동차 업계 주요 뉴스와 시장 동향을 요약해줘. 당사에 미치는 영향도 분석해줘.",
      "creator_name": "정수현",
      "installs": 35,
      "rating": 4.7,
      "tags": [
        "시장",
        "동향",
        "뉴스"
      ],
      "is_featured": true,
      "created_at": "2026-03-08T15:45:04.861162+00:00",
      "updated_at": "2026-03-08T15:45:04.861162+00:00"
    },
    {
      "id": "bd506b31-e816-4b91-97d2-114873119d94",
      "name": "회의록 자동 정리기",
      "description": "회의 내용을 구조화하고 액션 아이템을 자동 추출하는 에이전트",
      "category": "productivity",
      "icon": "FileText",
      "prompt_template": "다음 회의 내용을 정리해줘: {{meeting_notes}}. 핵심 결정사항, 액션 아이템, 담당자를 구분해서.",
      "creator_name": "한지민",
      "installs": 31,
      "rating": 4.4,
      "tags": [
        "회의록",
        "정리",
        "액션아이템"
      ],
      "is_featured": false,
      "created_at": "2026-03-08T15:45:04.861162+00:00",
      "updated_at": "2026-03-08T15:45:04.861162+00:00"
    },
    {
      "id": "fc2d8b2c-15fd-4c23-bfad-2ab0c482be84",
      "name": "가격 협상 시뮬레이터",
      "description": "원가 구조와 시장 가격을 기반으로 가격 협상 시나리오를 생성하는 에이전트",
      "category": "sales",
      "icon": "Calculator",
      "prompt_template": "{{customer}}와의 {{product}} 가격 협상을 위한 시나리오를 3가지 만들어줘. 원가, 마진율, 시장가를 고려해서.",
      "creator_name": "이지은",
      "installs": 28,
      "rating": 4.3,
      "tags": [
        "가격",
        "협상",
        "시뮬레이션"
      ],
      "is_featured": true,
      "created_at": "2026-03-08T15:45:04.861162+00:00",
      "updated_at": "2026-03-08T15:45:04.861162+00:00"
    },
    {
      "id": "4197ed39-3cdf-4f9d-af76-b49f452102f5",
      "name": "품질 클레임 분석기",
      "description": "고객 클레임 데이터를 분석하고 원인 분류 및 대응 방안을 제안하는 에이전트",
      "category": "quality",
      "icon": "Bug",
      "prompt_template": "다음 품질 클레임을 분석해줘: {{claim_detail}}. 원인 분류, 재발 방지 대책, 고객 대응 방안을 포함해서.",
      "creator_name": "최민수",
      "installs": 22,
      "rating": 4.5,
      "tags": [
        "품질",
        "클레임",
        "분석"
      ],
      "is_featured": false,
      "created_at": "2026-03-08T15:45:04.861162+00:00",
      "updated_at": "2026-03-08T15:45:04.861162+00:00"
    },
    {
      "id": "72a9e05a-9194-43fa-958a-6a307eff1a81",
      "name": "경쟁사 비교 분석기",
      "description": "경쟁사 제품/가격/서비스를 비교 분석하는 에이전트",
      "category": "market",
      "icon": "GitCompare",
      "prompt_template": "{{competitor}} 대비 당사의 {{product}} 경쟁력을 분석해줘. 가격, 품질, 납기, 서비스 관점에서.",
      "creator_name": "송민호",
      "installs": 18,
      "rating": 4.1,
      "tags": [
        "경쟁사",
        "비교",
        "분석"
      ],
      "is_featured": false,
      "created_at": "2026-03-08T15:45:04.861162+00:00",
      "updated_at": "2026-03-08T15:45:04.861162+00:00"
    }
  ],
  "marketplace_workflows": [
    {
      "id": "3dc3c2d4-ff5a-47fa-ac12-762ba4ebbf91",
      "name": "고객 온보딩 자동화",
      "description": "신규 고객 등록 시 환영 이메일 발송, CRM 업데이트, Slack 알림을 자동으로 처리합니다.",
      "category": "automation",
      "trigger_type": "webhook",
      "steps": [
        {
          "name": "고객 등록 이벤트",
          "type": "trigger",
          "config": {}
        },
        {
          "name": "환영 이메일 발송",
          "type": "action",
          "config": {}
        },
        {
          "name": "CRM 레코드 생성",
          "type": "action",
          "config": {}
        },
        {
          "name": "Slack 알림",
          "type": "action",
          "config": {}
        }
      ],
      "creator_name": "AutoFlow",
      "installs": 3201,
      "rating": 4.8,
      "tags": [
        "온보딩",
        "이메일",
        "CRM"
      ],
      "is_featured": true,
      "created_at": "2026-03-08T17:03:29.687048+00:00",
      "updated_at": "2026-03-08T17:03:29.687048+00:00"
    },
    {
      "id": "d5d8ce9a-67a0-47f0-be18-08afad4746b8",
      "name": "일일 리포트 생성",
      "description": "매일 오전 9시에 주요 KPI를 수집하고 요약 리포트를 생성하여 팀에 공유합니다.",
      "category": "reporting",
      "trigger_type": "schedule",
      "steps": [
        {
          "name": "매일 09:00 스케줄",
          "type": "trigger",
          "config": {}
        },
        {
          "name": "KPI 데이터 수집",
          "type": "action",
          "config": {}
        },
        {
          "name": "리포트 생성",
          "type": "action",
          "config": {}
        },
        {
          "name": "이메일 발송",
          "type": "action",
          "config": {}
        }
      ],
      "creator_name": "ReportBot",
      "installs": 2800,
      "rating": 4.7,
      "tags": [
        "리포트",
        "KPI",
        "자동화"
      ],
      "is_featured": true,
      "created_at": "2026-03-08T17:03:29.687048+00:00",
      "updated_at": "2026-03-08T17:03:29.687048+00:00"
    },
    {
      "id": "1cc23848-c667-493f-aaa4-bc445678f4c9",
      "name": "리드 스코어링",
      "description": "새 리드 유입 시 AI 기반으로 점수를 매기고 영업팀에 우선순위별로 배분합니다.",
      "category": "ai",
      "trigger_type": "webhook",
      "steps": [
        {
          "name": "새 리드 등록",
          "type": "trigger",
          "config": {}
        },
        {
          "name": "AI 스코어링",
          "type": "action",
          "config": {}
        },
        {
          "name": "점수 70+ 여부",
          "type": "condition",
          "config": {}
        },
        {
          "name": "영업팀 배분",
          "type": "action",
          "config": {}
        }
      ],
      "creator_name": "SalesAI",
      "installs": 2400,
      "rating": 4.7,
      "tags": [
        "리드",
        "영업",
        "AI스코어링"
      ],
      "is_featured": true,
      "created_at": "2026-03-08T17:03:29.687048+00:00",
      "updated_at": "2026-03-08T17:03:29.687048+00:00"
    },
    {
      "id": "eec82c2d-10c5-481c-ac20-dd6672dba08c",
      "name": "감정 분석 알림",
      "description": "고객 피드백이 부정적일 경우 즉시 담당 팀에 알림을 보냅니다.",
      "category": "ai",
      "trigger_type": "webhook",
      "steps": [
        {
          "name": "새 피드백 수신",
          "type": "trigger",
          "config": {}
        },
        {
          "name": "감정 분석 실행",
          "type": "action",
          "config": {}
        },
        {
          "name": "부정적 판단?",
          "type": "condition",
          "config": {}
        },
        {
          "name": "긴급 알림 전송",
          "type": "action",
          "config": {}
        }
      ],
      "creator_name": "AI Flow",
      "installs": 2100,
      "rating": 4.6,
      "tags": [
        "감정분석",
        "AI",
        "고객피드백"
      ],
      "is_featured": true,
      "created_at": "2026-03-08T17:03:29.687048+00:00",
      "updated_at": "2026-03-08T17:03:29.687048+00:00"
    },
    {
      "id": "4845d9c1-8336-4ee6-a166-6eb287cf454b",
      "name": "이슈 에스컬레이션",
      "description": "고객 이슈가 24시간 이상 미해결 시 자동으로 상위 담당자에게 에스컬레이션합니다.",
      "category": "automation",
      "trigger_type": "schedule",
      "steps": [
        {
          "name": "24시간 미해결 이슈 감지",
          "type": "trigger",
          "config": {}
        },
        {
          "name": "우선순위 확인",
          "type": "condition",
          "config": {}
        },
        {
          "name": "담당자 재배정",
          "type": "action",
          "config": {}
        },
        {
          "name": "알림 전송",
          "type": "action",
          "config": {}
        }
      ],
      "creator_name": "SupportFlow",
      "installs": 1900,
      "rating": 4.5,
      "tags": [
        "이슈",
        "에스컬레이션",
        "고객지원"
      ],
      "is_featured": true,
      "created_at": "2026-03-08T17:03:29.687048+00:00",
      "updated_at": "2026-03-08T17:03:29.687048+00:00"
    },
    {
      "id": "162cb507-9af3-4430-ab86-144524ee8fdc",
      "name": "Slack → 작업 변환",
      "description": "Slack 메시지에서 특정 이모지 반응 시 자동으로 작업을 생성합니다.",
      "category": "integration",
      "trigger_type": "webhook",
      "steps": [
        {
          "name": "Slack 이모지 반응",
          "type": "trigger",
          "config": {}
        },
        {
          "name": "메시지 내용 추출",
          "type": "action",
          "config": {}
        },
        {
          "name": "작업 생성",
          "type": "action",
          "config": {}
        },
        {
          "name": "확인 메시지 전송",
          "type": "action",
          "config": {}
        }
      ],
      "creator_name": "SlackOps",
      "installs": 1500,
      "rating": 4.3,
      "tags": [
        "Slack",
        "작업",
        "통합"
      ],
      "is_featured": false,
      "created_at": "2026-03-08T17:03:29.687048+00:00",
      "updated_at": "2026-03-08T17:03:29.687048+00:00"
    },
    {
      "id": "b5d0c198-4f97-452a-bed6-1b6ff7eabb67",
      "name": "PR 리뷰 자동 배정",
      "description": "GitHub PR 생성 시 코드 변경 영역에 따라 적절한 리뷰어를 자동 배정합니다.",
      "category": "development",
      "trigger_type": "webhook",
      "steps": [
        {
          "name": "GitHub PR 생성",
          "type": "trigger",
          "config": {}
        },
        {
          "name": "변경 파일 분석",
          "type": "action",
          "config": {}
        },
        {
          "name": "리뷰어 매칭",
          "type": "action",
          "config": {}
        },
        {
          "name": "리뷰어 배정",
          "type": "action",
          "config": {}
        }
      ],
      "creator_name": "DevOps Kit",
      "installs": 1200,
      "rating": 4.2,
      "tags": [
        "GitHub",
        "PR",
        "코드리뷰"
      ],
      "is_featured": false,
      "created_at": "2026-03-08T17:03:29.687048+00:00",
      "updated_at": "2026-03-08T17:03:29.687048+00:00"
    },
    {
      "id": "f92e625f-941a-494b-8320-4319fae4131e",
      "name": "데이터 백업 파이프라인",
      "description": "매주 일요일 자정에 주요 데이터를 백업하고 무결성을 검증합니다.",
      "category": "data",
      "trigger_type": "schedule",
      "steps": [
        {
          "name": "매주 일요일 00:00",
          "type": "trigger",
          "config": {}
        },
        {
          "name": "데이터 덤프 생성",
          "type": "action",
          "config": {}
        },
        {
          "name": "무결성 검증",
          "type": "action",
          "config": {}
        },
        {
          "name": "백업 완료 리포트",
          "type": "output",
          "config": {}
        }
      ],
      "creator_name": "DataGuard",
      "installs": 980,
      "rating": 4.4,
      "tags": [
        "백업",
        "데이터",
        "보안"
      ],
      "is_featured": false,
      "created_at": "2026-03-08T17:03:29.687048+00:00",
      "updated_at": "2026-03-08T17:03:29.687048+00:00"
    },
    {
      "id": "6b0c98ff-bad6-4b44-a177-19abaf3b9a6d",
      "name": "주간 성과 대시보드",
      "description": "매주 월요일 팀 성과 지표를 집계하여 대시보드를 업데이트하고 요약을 공유합니다.",
      "category": "reporting",
      "trigger_type": "schedule",
      "steps": [
        {
          "name": "매주 월요일 08:00",
          "type": "trigger",
          "config": {}
        },
        {
          "name": "성과 데이터 집계",
          "type": "action",
          "config": {}
        },
        {
          "name": "대시보드 업데이트",
          "type": "action",
          "config": {}
        },
        {
          "name": "주간 요약 공유",
          "type": "output",
          "config": {}
        }
      ],
      "creator_name": "MetricsBot",
      "installs": 870,
      "rating": 4.1,
      "tags": [
        "성과",
        "대시보드",
        "주간리포트"
      ],
      "is_featured": false,
      "created_at": "2026-03-08T17:03:29.687048+00:00",
      "updated_at": "2026-03-08T17:03:29.687048+00:00"
    },
    {
      "id": "74c89952-dae0-461f-809f-4673de68cc9f",
      "name": "인보이스 처리 자동화",
      "description": "이메일로 수신된 인보이스를 자동 파싱하고 회계 시스템에 등록합니다.",
      "category": "automation",
      "trigger_type": "webhook",
      "steps": [
        {
          "name": "인보이스 이메일 수신",
          "type": "trigger",
          "config": {}
        },
        {
          "name": "PDF 파싱",
          "type": "action",
          "config": {}
        },
        {
          "name": "데이터 검증",
          "type": "action",
          "config": {}
        },
        {
          "name": "회계 시스템 등록",
          "type": "action",
          "config": {}
        }
      ],
      "creator_name": "FinanceBot",
      "installs": 650,
      "rating": 4,
      "tags": [
        "인보이스",
        "회계",
        "자동화"
      ],
      "is_featured": false,
      "created_at": "2026-03-08T17:03:29.687048+00:00",
      "updated_at": "2026-03-08T17:03:29.687048+00:00"
    },
    {
      "id": "aa61bab2-d046-4047-8e4c-02b548e4dfe0",
      "name": "주간 실적 자동 집계",
      "description": "매주 금요일 자동으로 주간 실적을 집계하고 보고서를 생성하는 자동화",
      "category": "reporting",
      "trigger_type": "schedule",
      "steps": [
        {
          "type": "trigger",
          "label": "매주 금요일 17:00"
        },
        {
          "type": "action",
          "label": "실적 데이터 집계"
        },
        {
          "type": "action",
          "label": "AI 보고서 생성"
        },
        {
          "type": "output",
          "label": "PDF 생성 및 공유"
        }
      ],
      "creator_name": "강다희",
      "installs": 62,
      "rating": 4.9,
      "tags": [
        "실적",
        "주간",
        "보고서"
      ],
      "is_featured": true,
      "created_at": "2026-03-08T15:53:27.637549+00:00",
      "updated_at": "2026-03-08T15:53:27.637549+00:00"
    },
    {
      "id": "b6ba2448-fa86-4b25-9155-3a5dd05659ba",
      "name": "고객 방문 후 자동 보고서",
      "description": "고객 방문 완료 후 회의 메모를 기반으로 보고서 초안을 자동 생성하고 팀에 공유하는 자동화",
      "category": "reporting",
      "trigger_type": "event",
      "steps": [
        {
          "type": "trigger",
          "label": "방문 완료 이벤트"
        },
        {
          "type": "action",
          "label": "회의 메모 수집"
        },
        {
          "type": "action",
          "label": "AI 보고서 생성"
        },
        {
          "type": "action",
          "label": "팀 채널 공유"
        }
      ],
      "creator_name": "김철수",
      "installs": 56,
      "rating": 4.8,
      "tags": [
        "보고서",
        "자동화",
        "방문"
      ],
      "is_featured": true,
      "created_at": "2026-03-08T15:53:27.637549+00:00",
      "updated_at": "2026-03-08T15:53:27.637549+00:00"
    },
    {
      "id": "9e1b8932-4a18-431d-a09a-9721588e10d1",
      "name": "일일 시장 브리핑 자동 생성",
      "description": "매일 아침 시장 동향과 뉴스를 수집하여 맞춤 브리핑을 자동 생성하는 자동화",
      "category": "market",
      "trigger_type": "schedule",
      "steps": [
        {
          "type": "trigger",
          "label": "매일 07:00 스케줄"
        },
        {
          "type": "action",
          "label": "뉴스/시장 데이터 수집"
        },
        {
          "type": "action",
          "label": "AI 브리핑 생성"
        },
        {
          "type": "output",
          "label": "팀 채널 전송"
        }
      ],
      "creator_name": "한지민",
      "installs": 52,
      "rating": 4.7,
      "tags": [
        "브리핑",
        "시장",
        "자동화"
      ],
      "is_featured": false,
      "created_at": "2026-03-08T15:53:27.637549+00:00",
      "updated_at": "2026-03-08T15:53:27.637549+00:00"
    },
    {
      "id": "43e8e491-9f39-4c77-b315-f8acc96be277",
      "name": "납기 지연 알림 자동화",
      "description": "납기 D-3일부터 자동으로 관련자에게 알림을 보내고 대응 상태를 추적하는 자동화",
      "category": "alert",
      "trigger_type": "schedule",
      "steps": [
        {
          "type": "trigger",
          "label": "매일 09:00 스케줄"
        },
        {
          "type": "condition",
          "label": "납기 D-3 이내 필터"
        },
        {
          "type": "action",
          "label": "담당자 알림 발송"
        },
        {
          "type": "action",
          "label": "대응 상태 업데이트"
        }
      ],
      "creator_name": "박영희",
      "installs": 48,
      "rating": 4.7,
      "tags": [
        "납기",
        "알림",
        "자동화"
      ],
      "is_featured": true,
      "created_at": "2026-03-08T15:53:27.637549+00:00",
      "updated_at": "2026-03-08T15:53:27.637549+00:00"
    },
    {
      "id": "4cd70a21-271b-4c7a-a9b6-d435c338ff06",
      "name": "신규 고객 온보딩 체크리스트",
      "description": "신규 고객 등록 시 자동으로 온보딩 작업을 생성하고 진행 상황을 추적하는 자동화",
      "category": "sales",
      "trigger_type": "event",
      "steps": [
        {
          "type": "trigger",
          "label": "신규 고객 등록"
        },
        {
          "type": "action",
          "label": "온보딩 작업 생성"
        },
        {
          "type": "action",
          "label": "담당자 자동 배정"
        },
        {
          "type": "condition",
          "label": "완료 여부 체크"
        },
        {
          "type": "output",
          "label": "온보딩 완료 보고"
        }
      ],
      "creator_name": "이지은",
      "installs": 41,
      "rating": 4.6,
      "tags": [
        "온보딩",
        "고객",
        "체크리스트"
      ],
      "is_featured": true,
      "created_at": "2026-03-08T15:53:27.637549+00:00",
      "updated_at": "2026-03-08T15:53:27.637549+00:00"
    },
    {
      "id": "686ad152-d412-4f7a-b868-2eb3a8cb8bf5",
      "name": "견적 승인 자동 라우팅",
      "description": "견적서 제출 시 금액에 따라 자동으로 승인 라인을 결정하고 알림을 보내는 자동화",
      "category": "sales",
      "trigger_type": "event",
      "steps": [
        {
          "type": "trigger",
          "label": "견적서 제출"
        },
        {
          "type": "condition",
          "label": "금액별 승인 라인 분기"
        },
        {
          "type": "action",
          "label": "승인자 알림"
        },
        {
          "type": "condition",
          "label": "승인/반려 체크"
        },
        {
          "type": "output",
          "label": "결과 통보"
        }
      ],
      "creator_name": "송민호",
      "installs": 37,
      "rating": 4.4,
      "tags": [
        "견적",
        "승인",
        "라우팅"
      ],
      "is_featured": false,
      "created_at": "2026-03-08T15:53:27.637549+00:00",
      "updated_at": "2026-03-08T15:53:27.637549+00:00"
    },
    {
      "id": "80ba4a7b-f6a9-47ad-b8a5-c9c2ce734655",
      "name": "클레임 접수 → 분석 → 대응",
      "description": "품질 클레임 접수 시 자동으로 원인을 분류하고 대응 초안을 생성하는 엔드투엔드 자동화",
      "category": "quality",
      "trigger_type": "event",
      "steps": [
        {
          "type": "trigger",
          "label": "클레임 접수 이벤트"
        },
        {
          "type": "action",
          "label": "AI 원인 분류"
        },
        {
          "type": "condition",
          "label": "심각도 판단"
        },
        {
          "type": "action",
          "label": "대응 초안 생성"
        },
        {
          "type": "output",
          "label": "담당자 할당"
        }
      ],
      "creator_name": "최민수",
      "installs": 33,
      "rating": 4.5,
      "tags": [
        "클레임",
        "품질",
        "대응"
      ],
      "is_featured": true,
      "created_at": "2026-03-08T15:53:27.637549+00:00",
      "updated_at": "2026-03-08T15:53:27.637549+00:00"
    },
    {
      "id": "ca78b4b0-024b-44aa-b4f9-a077c74e2224",
      "name": "경쟁사 가격 변동 모니터링",
      "description": "경쟁사 가격 변동을 감지하면 자동으로 영향 분석을 수행하고 알림을 보내는 자동화",
      "category": "market",
      "trigger_type": "event",
      "steps": [
        {
          "type": "trigger",
          "label": "가격 변동 감지"
        },
        {
          "type": "action",
          "label": "영향 범위 분석"
        },
        {
          "type": "condition",
          "label": "영향도 임계값 체크"
        },
        {
          "type": "action",
          "label": "관련 영업팀 알림"
        },
        {
          "type": "output",
          "label": "대응 전략 제안"
        }
      ],
      "creator_name": "정수현",
      "installs": 29,
      "rating": 4.3,
      "tags": [
        "경쟁사",
        "가격",
        "모니터링"
      ],
      "is_featured": false,
      "created_at": "2026-03-08T15:53:27.637549+00:00",
      "updated_at": "2026-03-08T15:53:27.637549+00:00"
    }
  ],
  "marketplace_skills": [
    {
      "id": "8511e555-f1b7-4e8e-b5d9-e1f89bd2810a",
      "name": "번역",
      "description": "다국어 텍스트를 실시간으로 번역합니다. 한/영/일/중 등 주요 언어를 지원합니다.",
      "category": "ai",
      "icon": "Languages",
      "skill_type": "transform",
      "input_schema": {},
      "output_schema": {},
      "implementation": null,
      "creator_name": "TranslateAI",
      "installs": 4201,
      "rating": 4.7,
      "tags": [
        "번역",
        "다국어",
        "NLP"
      ],
      "is_featured": true,
      "is_composable": true,
      "created_at": "2026-03-08T16:50:16.503074+00:00",
      "updated_at": "2026-03-08T16:50:16.503074+00:00"
    },
    {
      "id": "3aa639e3-bcf5-489b-bafc-87d99a5d4720",
      "name": "텍스트 요약",
      "description": "긴 문서나 텍스트를 핵심 내용 중심으로 자동 요약합니다.",
      "category": "ai",
      "icon": "FileText",
      "skill_type": "analysis",
      "input_schema": {},
      "output_schema": {},
      "implementation": null,
      "creator_name": "AI Summary",
      "installs": 3100,
      "rating": 4.9,
      "tags": [
        "요약",
        "NLP",
        "텍스트"
      ],
      "is_featured": true,
      "is_composable": true,
      "created_at": "2026-03-08T16:50:16.503074+00:00",
      "updated_at": "2026-03-08T16:50:16.503074+00:00"
    },
    {
      "id": "5b273016-f340-418f-9311-64c907e615f4",
      "name": "감정 분석",
      "description": "텍스트의 감정을 긍정/부정/중립으로 분류하고 신뢰도 점수를 반환합니다.",
      "category": "ai",
      "icon": "Heart",
      "skill_type": "analysis",
      "input_schema": {},
      "output_schema": {},
      "implementation": null,
      "creator_name": "NLP Korea",
      "installs": 2340,
      "rating": 4.8,
      "tags": [
        "NLP",
        "감정분석",
        "텍스트"
      ],
      "is_featured": true,
      "is_composable": true,
      "created_at": "2026-03-08T16:50:16.503074+00:00",
      "updated_at": "2026-03-08T16:50:16.503074+00:00"
    },
    {
      "id": "7cae97a4-ddc2-4bd6-af0e-529d0be611b2",
      "name": "키워드 추출",
      "description": "텍스트에서 TF-IDF 기반 핵심 키워드를 자동 추출합니다.",
      "category": "ai",
      "icon": "Key",
      "skill_type": "extraction",
      "input_schema": {},
      "output_schema": {},
      "implementation": null,
      "creator_name": "NLP Korea",
      "installs": 1870,
      "rating": 4.6,
      "tags": [
        "키워드",
        "NLP",
        "추출"
      ],
      "is_featured": true,
      "is_composable": true,
      "created_at": "2026-03-08T16:50:16.503074+00:00",
      "updated_at": "2026-03-08T16:50:16.503074+00:00"
    },
    {
      "id": "d103b99c-46de-4c5f-b24c-240729c3d54d",
      "name": "개인정보 마스킹",
      "description": "텍스트에서 전화번호, 이메일, 주민번호 등 개인정보를 자동 탐지하고 마스킹합니다.",
      "category": "security",
      "icon": "EyeOff",
      "skill_type": "transform",
      "input_schema": {},
      "output_schema": {},
      "implementation": null,
      "creator_name": "SecureData",
      "installs": 1560,
      "rating": 4.8,
      "tags": [
        "개인정보",
        "마스킹",
        "보안"
      ],
      "is_featured": true,
      "is_composable": true,
      "created_at": "2026-03-08T16:50:16.503074+00:00",
      "updated_at": "2026-03-08T16:50:16.503074+00:00"
    },
    {
      "id": "2fca22bd-69f5-427f-bfe7-d5ec9b2973a0",
      "name": "데이터 정규화",
      "description": "입력 데이터를 표준 형식으로 정규화합니다. Min-Max, Z-Score 등 다양한 정규화 방식을 지원합니다.",
      "category": "data",
      "icon": "BarChart3",
      "skill_type": "transform",
      "input_schema": {},
      "output_schema": {},
      "implementation": null,
      "creator_name": "DataLab",
      "installs": 1250,
      "rating": 4.7,
      "tags": [
        "정규화",
        "데이터처리",
        "전처리"
      ],
      "is_featured": true,
      "is_composable": true,
      "created_at": "2026-03-08T16:50:16.503074+00:00",
      "updated_at": "2026-03-08T16:50:16.503074+00:00"
    },
    {
      "id": "b0f64ccf-5295-417f-99e2-6c7bc57f9f6b",
      "name": "중복 제거",
      "description": "데이터셋에서 유사/중복 레코드를 탐지하고 병합합니다.",
      "category": "data",
      "icon": "Copy",
      "skill_type": "transform",
      "input_schema": {},
      "output_schema": {},
      "implementation": null,
      "creator_name": "DataLab",
      "installs": 980,
      "rating": 4.4,
      "tags": [
        "중복제거",
        "데이터정제",
        "클렌징"
      ],
      "is_featured": false,
      "is_composable": true,
      "created_at": "2026-03-08T16:50:16.503074+00:00",
      "updated_at": "2026-03-08T16:50:16.503074+00:00"
    },
    {
      "id": "91fd6294-5d78-4a8a-a7e8-3dc833259b37",
      "name": "CSV 변환",
      "description": "다양한 형식의 데이터를 CSV로 변환하거나 CSV를 JSON/XML 등으로 변환합니다.",
      "category": "data",
      "icon": "FileSpreadsheet",
      "skill_type": "transform",
      "input_schema": {},
      "output_schema": {},
      "implementation": null,
      "creator_name": "FileUtils",
      "installs": 890,
      "rating": 4.3,
      "tags": [
        "CSV",
        "변환",
        "파일"
      ],
      "is_featured": false,
      "is_composable": true,
      "created_at": "2026-03-08T16:50:16.503074+00:00",
      "updated_at": "2026-03-08T16:50:16.503074+00:00"
    },
    {
      "id": "0e06f205-592e-4788-b51f-1eab8dc1af7a",
      "name": "날짜/시간 파서",
      "description": "다양한 형식의 날짜/시간 문자열을 ISO 8601 표준으로 변환합니다.",
      "category": "data",
      "icon": "Clock",
      "skill_type": "transform",
      "input_schema": {},
      "output_schema": {},
      "implementation": null,
      "creator_name": "TimeUtils",
      "installs": 730,
      "rating": 4.3,
      "tags": [
        "날짜",
        "시간",
        "파싱"
      ],
      "is_featured": false,
      "is_composable": true,
      "created_at": "2026-03-08T16:50:16.503074+00:00",
      "updated_at": "2026-03-08T16:50:16.503074+00:00"
    },
    {
      "id": "fbb5a45a-ffe7-4694-993a-a3b4ef5cb056",
      "name": "이메일 파서",
      "description": "이메일 본문에서 핵심 정보(발신자, 날짜, 주요 내용)를 추출합니다.",
      "category": "integration",
      "icon": "Mail",
      "skill_type": "extraction",
      "input_schema": {},
      "output_schema": {},
      "implementation": null,
      "creator_name": "MailBot",
      "installs": 670,
      "rating": 4.1,
      "tags": [
        "이메일",
        "파싱",
        "추출"
      ],
      "is_featured": false,
      "is_composable": true,
      "created_at": "2026-03-08T16:50:16.503074+00:00",
      "updated_at": "2026-03-08T16:50:16.503074+00:00"
    },
    {
      "id": "cec8093c-9069-4a2d-b11e-d41ae9477a04",
      "name": "주소 정제",
      "description": "비정형 주소 데이터를 표준 형식으로 정제하고 우편번호를 매핑합니다.",
      "category": "data",
      "icon": "MapPin",
      "skill_type": "transform",
      "input_schema": {},
      "output_schema": {},
      "implementation": null,
      "creator_name": "GeoKR",
      "installs": 520,
      "rating": 4,
      "tags": [
        "주소",
        "정제",
        "지오코딩"
      ],
      "is_featured": false,
      "is_composable": true,
      "created_at": "2026-03-08T16:50:16.503074+00:00",
      "updated_at": "2026-03-08T16:50:16.503074+00:00"
    },
    {
      "id": "52d13a39-decd-487d-a45e-b6b1c42de69d",
      "name": "JSON 스키마 검증",
      "description": "JSON 데이터가 정의된 스키마에 맞는지 검증하고 오류를 리포트합니다.",
      "category": "data",
      "icon": "ShieldCheck",
      "skill_type": "validation",
      "input_schema": {},
      "output_schema": {},
      "implementation": null,
      "creator_name": "SchemaTools",
      "installs": 410,
      "rating": 4.2,
      "tags": [
        "JSON",
        "검증",
        "스키마"
      ],
      "is_featured": false,
      "is_composable": true,
      "created_at": "2026-03-08T16:50:16.503074+00:00",
      "updated_at": "2026-03-08T16:50:16.503074+00:00"
    }
  ],
  "marketplace_plugins": [],
  "marketplace_mcps": [
    {
      "id": "3bad8fc7-b9eb-4da7-bcbb-c849d9d6f38b",
      "name": "GitHub",
      "description": "GitHub 레포지토리, 이슈, PR, 코드 검색 등을 지원하는 MCP 서버입니다.",
      "category": "development",
      "icon": "Github",
      "server_url": "https://mcp.github.com/v1",
      "auth_type": "oauth",
      "tools_count": 20,
      "tools_schema": [
        {
          "name": "search_repos",
          "description": "레포지토리 검색"
        },
        {
          "name": "list_issues",
          "description": "이슈 목록"
        },
        {
          "name": "create_pr",
          "description": "PR 생성"
        },
        {
          "name": "read_file",
          "description": "파일 읽기"
        }
      ],
      "creator_name": "GitHub Inc",
      "installs": 6101,
      "rating": 4.9,
      "tags": [
        "깃허브",
        "코드",
        "레포지토리",
        "PR"
      ],
      "is_featured": true,
      "is_verified": true,
      "created_at": "2026-03-08T16:55:04.407164+00:00",
      "updated_at": "2026-03-08T16:55:04.407164+00:00"
    },
    {
      "id": "7647dc53-af91-49e2-a528-83079c92b513",
      "name": "Notion",
      "description": "Notion 워크스페이스의 페이지, 데이터베이스, 블록을 읽고 쓸 수 있는 MCP 서버입니다.",
      "category": "productivity",
      "icon": "BookOpen",
      "server_url": "https://mcp.notion.so/v1",
      "auth_type": "oauth",
      "tools_count": 12,
      "tools_schema": [
        {
          "name": "search_pages",
          "description": "페이지 검색"
        },
        {
          "name": "read_page",
          "description": "페이지 내용 읽기"
        },
        {
          "name": "create_page",
          "description": "새 페이지 생성"
        },
        {
          "name": "query_database",
          "description": "데이터베이스 쿼리"
        }
      ],
      "creator_name": "Notion Labs",
      "installs": 5200,
      "rating": 4.8,
      "tags": [
        "노션",
        "문서",
        "위키",
        "데이터베이스"
      ],
      "is_featured": true,
      "is_verified": true,
      "created_at": "2026-03-08T16:55:04.407164+00:00",
      "updated_at": "2026-03-08T16:55:04.407164+00:00"
    },
    {
      "id": "8eb29882-e76f-4ae0-8598-73db6a0ad01e",
      "name": "Slack",
      "description": "Slack 채널 메시지 읽기/쓰기, 사용자 조회, 파일 공유 등을 지원하는 MCP 서버입니다.",
      "category": "communication",
      "icon": "MessageSquare",
      "server_url": "https://mcp.slack.com/v1",
      "auth_type": "oauth",
      "tools_count": 15,
      "tools_schema": [
        {
          "name": "send_message",
          "description": "메시지 전송"
        },
        {
          "name": "list_channels",
          "description": "채널 목록 조회"
        },
        {
          "name": "search_messages",
          "description": "메시지 검색"
        },
        {
          "name": "upload_file",
          "description": "파일 업로드"
        }
      ],
      "creator_name": "Slack Technologies",
      "installs": 4800,
      "rating": 4.7,
      "tags": [
        "슬랙",
        "메시징",
        "협업",
        "채팅"
      ],
      "is_featured": true,
      "is_verified": true,
      "created_at": "2026-03-08T16:55:04.407164+00:00",
      "updated_at": "2026-03-08T16:55:04.407164+00:00"
    },
    {
      "id": "e536f557-4881-4de6-a40c-cfaf991548d6",
      "name": "Linear",
      "description": "Linear 이슈, 프로젝트, 사이클을 관리할 수 있는 MCP 서버입니다.",
      "category": "development",
      "icon": "LayoutList",
      "server_url": "https://mcp.linear.app/v1",
      "auth_type": "api_key",
      "tools_count": 10,
      "tools_schema": [
        {
          "name": "create_issue",
          "description": "이슈 생성"
        },
        {
          "name": "list_issues",
          "description": "이슈 목록 조회"
        },
        {
          "name": "update_issue",
          "description": "이슈 업데이트"
        },
        {
          "name": "list_projects",
          "description": "프로젝트 목록"
        }
      ],
      "creator_name": "Linear Inc",
      "installs": 3600,
      "rating": 4.6,
      "tags": [
        "리니어",
        "이슈트래커",
        "프로젝트관리"
      ],
      "is_featured": true,
      "is_verified": true,
      "created_at": "2026-03-08T16:55:04.407164+00:00",
      "updated_at": "2026-03-08T16:55:04.407164+00:00"
    },
    {
      "id": "9ecec6e8-7df7-4ebe-b359-6b8421c079a4",
      "name": "Figma",
      "description": "Figma 파일, 컴포넌트, 디자인 토큰을 읽을 수 있는 MCP 서버입니다.",
      "category": "design",
      "icon": "Paintbrush",
      "server_url": "https://mcp.figma.com/v1",
      "auth_type": "api_key",
      "tools_count": 7,
      "tools_schema": [
        {
          "name": "get_file",
          "description": "파일 정보 조회"
        },
        {
          "name": "list_components",
          "description": "컴포넌트 목록"
        },
        {
          "name": "export_image",
          "description": "이미지 내보내기"
        },
        {
          "name": "get_styles",
          "description": "스타일 조회"
        }
      ],
      "creator_name": "Figma Inc",
      "installs": 3200,
      "rating": 4.6,
      "tags": [
        "피그마",
        "디자인",
        "UI",
        "컴포넌트"
      ],
      "is_featured": true,
      "is_verified": true,
      "created_at": "2026-03-08T16:55:04.407164+00:00",
      "updated_at": "2026-03-08T16:55:04.407164+00:00"
    },
    {
      "id": "8011be59-30d0-4590-8e86-a5a61ffdf782",
      "name": "Google Drive",
      "description": "Google Drive 파일 검색, 읽기, 생성 및 공유를 지원하는 MCP 서버입니다.",
      "category": "productivity",
      "icon": "HardDrive",
      "server_url": "https://mcp.googleapis.com/drive/v1",
      "auth_type": "oauth",
      "tools_count": 8,
      "tools_schema": [
        {
          "name": "search_files",
          "description": "파일 검색"
        },
        {
          "name": "read_file",
          "description": "파일 읽기"
        },
        {
          "name": "create_file",
          "description": "파일 생성"
        },
        {
          "name": "share_file",
          "description": "파일 공유"
        }
      ],
      "creator_name": "Google",
      "installs": 2900,
      "rating": 4.5,
      "tags": [
        "구글드라이브",
        "파일",
        "클라우드",
        "문서"
      ],
      "is_featured": false,
      "is_verified": true,
      "created_at": "2026-03-08T16:55:04.407164+00:00",
      "updated_at": "2026-03-08T16:55:04.407164+00:00"
    },
    {
      "id": "f9c922be-fafc-466a-ba1c-b20b0bd04570",
      "name": "Jira",
      "description": "Jira 프로젝트, 이슈, 스프린트를 관리할 수 있는 MCP 서버입니다.",
      "category": "development",
      "icon": "Bug",
      "server_url": "https://mcp.atlassian.com/jira/v1",
      "auth_type": "oauth",
      "tools_count": 14,
      "tools_schema": [
        {
          "name": "create_issue",
          "description": "이슈 생성"
        },
        {
          "name": "search_issues",
          "description": "이슈 검색(JQL)"
        },
        {
          "name": "list_sprints",
          "description": "스프린트 조회"
        },
        {
          "name": "transition_issue",
          "description": "이슈 상태 변경"
        }
      ],
      "creator_name": "Atlassian",
      "installs": 2100,
      "rating": 4.3,
      "tags": [
        "지라",
        "이슈트래커",
        "애자일",
        "스프린트"
      ],
      "is_featured": false,
      "is_verified": true,
      "created_at": "2026-03-08T16:55:04.407164+00:00",
      "updated_at": "2026-03-08T16:55:04.407164+00:00"
    },
    {
      "id": "3421ac11-bce4-46b5-a1f1-d46d07c8d158",
      "name": "PostgreSQL",
      "description": "직접 PostgreSQL 데이터베이스에 연결하여 쿼리를 실행하는 MCP 서버입니다.",
      "category": "data",
      "icon": "Database",
      "server_url": null,
      "auth_type": "connection_string",
      "tools_count": 5,
      "tools_schema": [
        {
          "name": "execute_query",
          "description": "SQL 쿼리 실행"
        },
        {
          "name": "list_tables",
          "description": "테이블 목록"
        },
        {
          "name": "describe_table",
          "description": "테이블 스키마 조회"
        }
      ],
      "creator_name": "Community",
      "installs": 1800,
      "rating": 4.4,
      "tags": [
        "데이터베이스",
        "SQL",
        "PostgreSQL",
        "쿼리"
      ],
      "is_featured": false,
      "is_verified": true,
      "created_at": "2026-03-08T16:55:04.407164+00:00",
      "updated_at": "2026-03-08T16:55:04.407164+00:00"
    },
    {
      "id": "67ad714b-ea71-4aa0-83f5-b30246337d5a",
      "name": "Confluence",
      "description": "Confluence 페이지와 스페이스를 검색하고 관리하는 MCP 서버입니다.",
      "category": "productivity",
      "icon": "FileText",
      "server_url": "https://mcp.atlassian.com/confluence/v1",
      "auth_type": "oauth",
      "tools_count": 9,
      "tools_schema": [
        {
          "name": "search_pages",
          "description": "페이지 검색"
        },
        {
          "name": "read_page",
          "description": "페이지 읽기"
        },
        {
          "name": "create_page",
          "description": "페이지 생성"
        }
      ],
      "creator_name": "Atlassian",
      "installs": 1500,
      "rating": 4.2,
      "tags": [
        "컨플루언스",
        "위키",
        "문서",
        "협업"
      ],
      "is_featured": false,
      "is_verified": true,
      "created_at": "2026-03-08T16:55:04.407164+00:00",
      "updated_at": "2026-03-08T16:55:04.407164+00:00"
    },
    {
      "id": "897be3ea-9749-4b14-878b-601f5c7ed316",
      "name": "Sentry",
      "description": "에러 모니터링 및 이슈 트래킹을 지원하는 MCP 서버입니다.",
      "category": "monitoring",
      "icon": "AlertTriangle",
      "server_url": "https://mcp.sentry.io/v1",
      "auth_type": "api_key",
      "tools_count": 6,
      "tools_schema": [
        {
          "name": "list_issues",
          "description": "이슈 목록"
        },
        {
          "name": "get_issue_details",
          "description": "이슈 상세"
        },
        {
          "name": "resolve_issue",
          "description": "이슈 해결"
        }
      ],
      "creator_name": "Sentry.io",
      "installs": 980,
      "rating": 4.1,
      "tags": [
        "센트리",
        "에러",
        "모니터링",
        "디버깅"
      ],
      "is_featured": false,
      "is_verified": false,
      "created_at": "2026-03-08T16:55:04.407164+00:00",
      "updated_at": "2026-03-08T16:55:04.407164+00:00"
    }
  ],
  "installed_items": [
    {
      "id": "55b1f517-44f9-4375-94bd-036e90eeee6b",
      "item_id": "9099e373-8856-49d6-982d-0babf0ca83b5",
      "item_type": "agent",
      "item_name": "고객 응대 전문가",
      "item_icon": "Headphones",
      "item_description": "고객 문의에 친절하고 정확하게 응답하는 CS 전문 에이전트입니다. 불만 처리, FAQ 안내, 에스컬레이션 판단을 수행합니다.",
      "is_active": true,
      "installed_at": "2026-03-17T05:29:35.880562+00:00",
      "config": {}
    },
    {
      "id": "22dc331f-218f-4d85-9d3d-161922380d53",
      "item_id": "62be653a-ed9b-4b63-b03d-fb67520d8a86",
      "item_type": "agent",
      "item_name": "문서 작성 도우미",
      "item_icon": "FileEdit",
      "item_description": "보고서, 제안서, 이메일 등 비즈니스 문서를 전문적으로 작성하는 에이전트입니다.",
      "is_active": true,
      "installed_at": "2026-03-17T05:29:24.660887+00:00",
      "config": {}
    },
    {
      "id": "97c5b9bb-b69a-42db-b731-5417ef9b3b14",
      "item_id": "77fc1c40-8f24-4878-8b79-bfb5a591f8e8",
      "item_type": "agent",
      "item_name": "회의 요약 비서",
      "item_icon": "ClipboardList",
      "item_description": "회의 내용을 자동으로 요약하고 액션 아이템을 추출하는 에이전트입니다.",
      "is_active": true,
      "installed_at": "2026-03-14T10:46:19.226776+00:00",
      "config": {}
    },
    {
      "id": "d7b09b7a-146b-43d0-b87a-89b34901a3d1",
      "item_id": "d6c9e53a-f5d0-41c5-ba6d-6372c81ffe85",
      "item_type": "agent",
      "item_name": "데이터 분석가",
      "item_icon": "BarChart3",
      "item_description": "데이터를 분석하고 인사이트를 도출하는 전문 에이전트입니다. SQL 쿼리 작성, 차트 추천, 트렌드 분석을 지원합니다.",
      "is_active": true,
      "installed_at": "2026-03-10T14:14:22.180592+00:00",
      "config": {}
    }
  ]
} as const;
