import type { Strategy, StrategyVersion } from "@/lib/agentic/types";

export const demoStrategies: readonly Strategy[] = Object.freeze([
  Object.freeze({
    strategy_id: "delivery-risk-early-warning",
    title: "납기 위험 조기 확인",
  }),
]);

export const demoStrategyVersions: readonly StrategyVersion[] = Object.freeze([
  Object.freeze({
    strategy_version_id: "delivery-risk-early-warning-v1",
    strategy_id: "delivery-risk-early-warning",
    version: 1,
    objective: "주문 상태와 납기 일정을 함께 확인해 납기 위험을 조기에 발견한다.",
    review_question: "주문·납기 증거가 위험 판단을 충분히 뒷받침하는가?",
  }),
  Object.freeze({
    strategy_version_id: "delivery-risk-early-warning-v2",
    strategy_id: "delivery-risk-early-warning",
    version: 2,
    objective: "주문·납기 신호와 공급 여유를 함께 확인해 조기 경보의 정확도를 높인다.",
    review_question: "공급 여유 신호를 추가한 판단이 더 빠르고 명확한 대응을 만드는가?",
  }),
]);
