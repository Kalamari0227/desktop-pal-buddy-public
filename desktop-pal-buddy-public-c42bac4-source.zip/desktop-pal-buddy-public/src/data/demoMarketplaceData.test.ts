import { describe, expect, it } from "vitest";
import { originalDemoMarketplaceData } from "./demoMarketplaceData";

describe("original public demo marketplace data", () => {
  it("keeps the old marketplace and installed-item presets available in demo mode", () => {
    expect(originalDemoMarketplaceData.marketplace_agents.length).toBeGreaterThanOrEqual(18);
    expect(originalDemoMarketplaceData.marketplace_workflows.length).toBeGreaterThanOrEqual(18);
    expect(originalDemoMarketplaceData.marketplace_skills.length).toBeGreaterThanOrEqual(12);
    expect(originalDemoMarketplaceData.marketplace_mcps.length).toBeGreaterThanOrEqual(10);
    expect(originalDemoMarketplaceData.installed_items.map((item) => item.item_name)).toEqual([
      "고객 응대 전문가",
      "문서 작성 도우미",
      "회의 요약 비서",
      "데이터 분석가",
    ]);
    expect(originalDemoMarketplaceData.marketplace_agents.some((agent) => agent.name === "문서 작성 도우미")).toBe(true);
    expect(originalDemoMarketplaceData.marketplace_mcps.some((mcp) => mcp.name === "GitHub")).toBe(true);
  });
});
