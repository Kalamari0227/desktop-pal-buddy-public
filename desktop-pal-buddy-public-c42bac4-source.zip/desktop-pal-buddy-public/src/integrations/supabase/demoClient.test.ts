import { describe, expect, it } from "vitest";
import { createDemoSupabaseClient } from "./demoClient";

async function rows(client: ReturnType<typeof createDemoSupabaseClient>, table: string) {
  const result = await client.from(table).select("*");
  return result.data;
}

describe("demo Supabase client session storage", () => {
  it("keeps strategy fixtures behind an explicit opt-in", async () => {
    const normal = await rows(createDemoSupabaseClient(), "tasks");
    const strategy = await rows(createDemoSupabaseClient({ includeStrategyFixtures: true }), "tasks");

    expect(normal.some((row) => row.demo_intake_required === true)).toBe(false);
    expect(strategy.filter((row) => row.demo_intake_required === true)).toHaveLength(2);
  });

  it("gives each client its own session rows", async () => {
    const first = createDemoSupabaseClient();
    const second = createDemoSupabaseClient();
    await first.from("tasks").insert({ id: "session-only", title: "세션 작업", status: "pending" });

    expect((await rows(first, "tasks")).some((row) => row.id === "session-only")).toBe(true);
    expect((await rows(second, "tasks")).some((row) => row.id === "session-only")).toBe(false);
  });

  it("applies the task created-at default without replacing a supplied updated-at", async () => {
    const client = createDemoSupabaseClient();
    const updatedAt = "2026-09-18T11:30:00.000Z";

    const result = await client
      .from("tasks")
      .insert({ title: "후속 작업", status: "pending", updated_at: updatedAt })
      .select("*")
      .single();

    expect(result.data?.updated_at).toBe(updatedAt);
    expect(Number.isNaN(Date.parse(String(result.data?.created_at)))).toBe(false);
  });

  it("clones inserted and selected packet metadata", async () => {
    const client = createDemoSupabaseClient();
    const payload = {
      id: "cloned-task",
      title: "복제 작업",
      status: "pending",
      demo_intake_packet: { task_id: "packet-1", nested: { value: "original" } },
    };
    await client.from("tasks").insert(payload);
    payload.demo_intake_packet.nested.value = "mutated-after-write";

    const firstRead = await client.from("tasks").select("*").eq("id", "cloned-task").single();
    (firstRead.data!.demo_intake_packet as { nested: { value: string } }).nested.value = "mutated-after-read";
    const secondRead = await client.from("tasks").select("*").eq("id", "cloned-task").single();

    expect((secondRead.data!.demo_intake_packet as { nested: { value: string } }).nested.value).toBe("original");
  });

  it("persists filtered updates only when the query is awaited", async () => {
    const client = createDemoSupabaseClient();
    const query = client.from("tasks").update({ status: "done" }).eq("id", "demo-task-kia-price");

    expect((await client.from("tasks").select("*").eq("id", "demo-task-kia-price").single()).data?.status).toBe("pending");
    await query;
    expect((await client.from("tasks").select("*").eq("id", "demo-task-kia-price").single()).data?.status).toBe("done");
    expect((await client.from("tasks").select("*").eq("id", "demo-task-toyota-export").single()).data?.status).toBe("pending");
  });

  it("persists filtered deletes only when the query is awaited", async () => {
    const client = createDemoSupabaseClient();
    const query = client.from("tasks").delete().eq("id", "demo-task-kia-price");

    expect((await rows(client, "tasks")).some((row) => row.id === "demo-task-kia-price")).toBe(true);
    await query;
    expect((await rows(client, "tasks")).some((row) => row.id === "demo-task-kia-price")).toBe(false);
    expect((await rows(client, "tasks")).some((row) => row.id === "demo-task-toyota-export")).toBe(true);
  });

  it("upserts task-related rows by id and reads back the replacement", async () => {
    const client = createDemoSupabaseClient();
    await client.from("agent_events").upsert({
      id: "event-row",
      task_id: "task-1",
      packet_task_id: "packet-1",
      event_id: "event-1",
      event_type: "accepted",
      message: "처음",
    });
    await client.from("agent_events").upsert({
      id: "event-row",
      task_id: "task-1",
      packet_task_id: "packet-1",
      event_id: "event-1",
      event_type: "progress",
      message: "갱신",
    });

    const stored = await client.from("agent_events").select("*").eq("id", "event-row");
    expect(stored.data).toHaveLength(1);
    expect(stored.data[0].message).toBe("갱신");
  });

  it("keeps non-task demo tables on their existing read-only fixture behavior", async () => {
    const client = createDemoSupabaseClient();
    await client.from("marketplace_agents").insert({ id: "not-session-persisted", name: "임시 항목" });

    expect((await rows(client, "marketplace_agents")).some((row) => row.id === "not-session-persisted")).toBe(false);
  });
});
