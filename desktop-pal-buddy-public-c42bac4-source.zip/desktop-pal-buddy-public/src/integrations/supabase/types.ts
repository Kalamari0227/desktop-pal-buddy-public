export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.4"
  }
  public: {
    Tables: {
      agent_approvals: {
        Row: {
          action_type: string | null
          approval_reason: string
          approved_scope: string
          created_at: string
          decision: string
          id: string
          owner_id: string | null
          packet_task_id: string
          task_id: string
        }
        Insert: {
          action_type?: string | null
          approval_reason: string
          approved_scope: string
          created_at?: string
          decision: string
          id?: string
          owner_id?: string | null
          packet_task_id: string
          task_id: string
        }
        Update: {
          action_type?: string | null
          approval_reason?: string
          approved_scope?: string
          created_at?: string
          decision?: string
          id?: string
          owner_id?: string | null
          packet_task_id?: string
          task_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "agent_approvals_task_id_fkey"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "tasks"
            referencedColumns: ["id"]
          },
        ]
      }
      agent_evidence: {
        Row: {
          artifact_path: string | null
          created_at: string
          evidence_id: string
          evidence_type: string
          id: string
          owner_id: string | null
          packet_task_id: string
          raw_excerpt: string | null
          source_command: string | null
          source_path: string | null
          source_ref: string | null
          source_system: string
          source_url: string | null
          status: string
          summary: string
          task_id: string
        }
        Insert: {
          artifact_path?: string | null
          created_at?: string
          evidence_id: string
          evidence_type: string
          id?: string
          owner_id?: string | null
          packet_task_id: string
          raw_excerpt?: string | null
          source_command?: string | null
          source_path?: string | null
          source_ref?: string | null
          source_system: string
          source_url?: string | null
          status: string
          summary: string
          task_id: string
        }
        Update: {
          artifact_path?: string | null
          created_at?: string
          evidence_id?: string
          evidence_type?: string
          id?: string
          owner_id?: string | null
          packet_task_id?: string
          raw_excerpt?: string | null
          source_command?: string | null
          source_path?: string | null
          source_ref?: string | null
          source_system?: string
          source_url?: string | null
          status?: string
          summary?: string
          task_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "agent_evidence_task_id_fkey"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "tasks"
            referencedColumns: ["id"]
          },
        ]
      }
      agent_events: {
        Row: {
          created_at: string
          event_id: string
          event_type: string
          evidence_ref_id: string | null
          id: string
          message: string
          owner_id: string | null
          packet_task_id: string
          requires_user_action: boolean
          severity: string | null
          task_id: string
        }
        Insert: {
          created_at?: string
          event_id: string
          event_type: string
          evidence_ref_id?: string | null
          id?: string
          message: string
          owner_id?: string | null
          packet_task_id: string
          requires_user_action?: boolean
          severity?: string | null
          task_id: string
        }
        Update: {
          created_at?: string
          event_id?: string
          event_type?: string
          evidence_ref_id?: string | null
          id?: string
          message?: string
          owner_id?: string | null
          packet_task_id?: string
          requires_user_action?: boolean
          severity?: string | null
          task_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "agent_events_task_id_fkey"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "tasks"
            referencedColumns: ["id"]
          },
        ]
      }
      agent_results: {
        Row: {
          blockers: Json
          changed_paths: Json
          checked_refs: Json
          created_at: string
          details: string | null
          id: string
          next_action: string | null
          outcome: string
          owner_id: string | null
          packet_task_id: string
          retention_decision: Json | null
          risks: Json
          summary: string
          task_id: string
        }
        Insert: {
          blockers?: Json
          changed_paths?: Json
          checked_refs?: Json
          created_at?: string
          details?: string | null
          id?: string
          next_action?: string | null
          outcome: string
          owner_id?: string | null
          packet_task_id: string
          retention_decision?: Json | null
          risks?: Json
          summary: string
          task_id: string
        }
        Update: {
          blockers?: Json
          changed_paths?: Json
          checked_refs?: Json
          created_at?: string
          details?: string | null
          id?: string
          next_action?: string | null
          outcome?: string
          owner_id?: string | null
          packet_task_id?: string
          retention_decision?: Json | null
          risks?: Json
          summary?: string
          task_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "agent_results_task_id_fkey"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "tasks"
            referencedColumns: ["id"]
          },
        ]
      }
      alert_dismissals: {
        Row: {
          dismissed_at: string
          id: string
          owner_id: string | null
          task_id: string
        }
        Insert: {
          dismissed_at?: string
          id?: string
          owner_id?: string | null
          task_id: string
        }
        Update: {
          dismissed_at?: string
          id?: string
          owner_id?: string | null
          task_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "alert_dismissals_task_id_fkey"
            columns: ["task_id"]
            isOneToOne: false
            referencedRelation: "tasks"
            referencedColumns: ["id"]
          },
        ]
      }
      data_query_audit_logs: {
        Row: {
          created_at: string
          error_message: string | null
          generated_sql: string | null
          id: string
          latency_ms: number | null
          question: string
          row_count: number
          status: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          error_message?: string | null
          generated_sql?: string | null
          id?: string
          latency_ms?: number | null
          question: string
          row_count?: number
          status: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          error_message?: string | null
          generated_sql?: string | null
          id?: string
          latency_ms?: number | null
          question?: string
          row_count?: number
          status?: string
          user_id?: string | null
        }
        Relationships: []
      }
      canvas_edges: {
        Row: {
          confidence_score: number | null
          created_at: string
          created_by: string
          explanation: string | null
          id: string
          metadata: Json | null
          owner_id: string | null
          source_id: string
          status: Database["public"]["Enums"]["canvas_edge_status"]
          target_id: string
          type: Database["public"]["Enums"]["canvas_edge_type"]
          weight: number | null
        }
        Insert: {
          confidence_score?: number | null
          created_at?: string
          created_by?: string
          explanation?: string | null
          id?: string
          metadata?: Json | null
          owner_id?: string | null
          source_id: string
          status?: Database["public"]["Enums"]["canvas_edge_status"]
          target_id: string
          type?: Database["public"]["Enums"]["canvas_edge_type"]
          weight?: number | null
        }
        Update: {
          confidence_score?: number | null
          created_at?: string
          created_by?: string
          explanation?: string | null
          id?: string
          metadata?: Json | null
          owner_id?: string | null
          source_id?: string
          status?: Database["public"]["Enums"]["canvas_edge_status"]
          target_id?: string
          type?: Database["public"]["Enums"]["canvas_edge_type"]
          weight?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "canvas_edges_source_id_fkey"
            columns: ["source_id"]
            isOneToOne: false
            referencedRelation: "canvas_nodes"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "canvas_edges_target_id_fkey"
            columns: ["target_id"]
            isOneToOne: false
            referencedRelation: "canvas_nodes"
            referencedColumns: ["id"]
          },
        ]
      }
      canvas_evidences: {
        Row: {
          created_at: string
          description: string | null
          edge_id: string | null
          id: string
          label: string
          metadata: Json | null
          owner_id: string | null
          score: number | null
          source_refs: string[] | null
          type: Database["public"]["Enums"]["canvas_evidence_type"]
        }
        Insert: {
          created_at?: string
          description?: string | null
          edge_id?: string | null
          id?: string
          label: string
          metadata?: Json | null
          owner_id?: string | null
          score?: number | null
          source_refs?: string[] | null
          type?: Database["public"]["Enums"]["canvas_evidence_type"]
        }
        Update: {
          created_at?: string
          description?: string | null
          edge_id?: string | null
          id?: string
          label?: string
          metadata?: Json | null
          owner_id?: string | null
          score?: number | null
          source_refs?: string[] | null
          type?: Database["public"]["Enums"]["canvas_evidence_type"]
        }
        Relationships: [
          {
            foreignKeyName: "canvas_evidences_edge_id_fkey"
            columns: ["edge_id"]
            isOneToOne: false
            referencedRelation: "canvas_edges"
            referencedColumns: ["id"]
          },
        ]
      }
      canvas_graph_snapshots: {
        Row: {
          created_at: string
          created_by: string | null
          edge_ids: string[] | null
          filters: Json | null
          id: string
          layout: Json | null
          name: string
          node_ids: string[] | null
          owner_id: string | null
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          edge_ids?: string[] | null
          filters?: Json | null
          id?: string
          layout?: Json | null
          name: string
          node_ids?: string[] | null
          owner_id?: string | null
        }
        Update: {
          created_at?: string
          created_by?: string | null
          edge_ids?: string[] | null
          filters?: Json | null
          id?: string
          layout?: Json | null
          name?: string
          node_ids?: string[] | null
          owner_id?: string | null
        }
        Relationships: []
      }
      canvas_nodes: {
        Row: {
          confidence_score: number | null
          content: string | null
          created_at: string
          customer_id: string | null
          id: string
          importance_score: number | null
          metadata: Json | null
          owner_id: string | null
          project_id: string | null
          status: Database["public"]["Enums"]["canvas_node_status"]
          summary: string | null
          tags: string[] | null
          title: string
          type: Database["public"]["Enums"]["canvas_node_type"]
          updated_at: string
        }
        Insert: {
          confidence_score?: number | null
          content?: string | null
          created_at?: string
          customer_id?: string | null
          id?: string
          importance_score?: number | null
          metadata?: Json | null
          owner_id?: string | null
          project_id?: string | null
          status?: Database["public"]["Enums"]["canvas_node_status"]
          summary?: string | null
          tags?: string[] | null
          title: string
          type?: Database["public"]["Enums"]["canvas_node_type"]
          updated_at?: string
        }
        Update: {
          confidence_score?: number | null
          content?: string | null
          created_at?: string
          customer_id?: string | null
          id?: string
          importance_score?: number | null
          metadata?: Json | null
          owner_id?: string | null
          project_id?: string | null
          status?: Database["public"]["Enums"]["canvas_node_status"]
          summary?: string | null
          tags?: string[] | null
          title?: string
          type?: Database["public"]["Enums"]["canvas_node_type"]
          updated_at?: string
        }
        Relationships: []
      }
      canvas_review_decisions: {
        Row: {
          decision: Database["public"]["Enums"]["canvas_review_decision"]
          id: string
          owner_id: string | null
          reason: string | null
          reviewed_at: string
          reviewed_by: string | null
          target_id: string
          target_type: string
        }
        Insert: {
          decision?: Database["public"]["Enums"]["canvas_review_decision"]
          id?: string
          owner_id?: string | null
          reason?: string | null
          reviewed_at?: string
          reviewed_by?: string | null
          target_id: string
          target_type?: string
        }
        Update: {
          decision?: Database["public"]["Enums"]["canvas_review_decision"]
          id?: string
          owner_id?: string | null
          reason?: string | null
          reviewed_at?: string
          reviewed_by?: string | null
          target_id?: string
          target_type?: string
        }
        Relationships: []
      }
      debate_history: {
        Row: {
          con_agent_id: string
          created_at: string
          debate_rounds: number
          id: string
          judge_agent_id: string | null
          messages: Json
          owner_id: string | null
          pro_agent_id: string
          summary: string | null
          topic: string
          verdict: string | null
          verdict_reason: string | null
        }
        Insert: {
          con_agent_id: string
          created_at?: string
          debate_rounds?: number
          id?: string
          judge_agent_id?: string | null
          messages?: Json
          owner_id?: string | null
          pro_agent_id: string
          summary?: string | null
          topic: string
          verdict?: string | null
          verdict_reason?: string | null
        }
        Update: {
          con_agent_id?: string
          created_at?: string
          debate_rounds?: number
          id?: string
          judge_agent_id?: string | null
          messages?: Json
          owner_id?: string | null
          pro_agent_id?: string
          summary?: string | null
          topic?: string
          verdict?: string | null
          verdict_reason?: string | null
        }
        Relationships: []
      }
      installed_items: {
        Row: {
          config: Json | null
          id: string
          installed_at: string
          is_active: boolean
          item_description: string | null
          item_icon: string | null
          item_id: string
          item_name: string
          item_type: string
          owner_id: string | null
        }
        Insert: {
          config?: Json | null
          id?: string
          installed_at?: string
          is_active?: boolean
          item_description?: string | null
          item_icon?: string | null
          item_id: string
          item_name: string
          item_type: string
          owner_id?: string | null
        }
        Update: {
          config?: Json | null
          id?: string
          installed_at?: string
          is_active?: boolean
          item_description?: string | null
          item_icon?: string | null
          item_id?: string
          item_name?: string
          item_type?: string
          owner_id?: string | null
        }
        Relationships: []
      }
      marketplace_agents: {
        Row: {
          category: string
          created_at: string
          creator_name: string | null
          description: string | null
          icon: string | null
          id: string
          installs: number | null
          is_featured: boolean | null
          name: string
          prompt_template: string | null
          rating: number | null
          tags: string[] | null
          updated_at: string
        }
        Insert: {
          category?: string
          created_at?: string
          creator_name?: string | null
          description?: string | null
          icon?: string | null
          id?: string
          installs?: number | null
          is_featured?: boolean | null
          name: string
          prompt_template?: string | null
          rating?: number | null
          tags?: string[] | null
          updated_at?: string
        }
        Update: {
          category?: string
          created_at?: string
          creator_name?: string | null
          description?: string | null
          icon?: string | null
          id?: string
          installs?: number | null
          is_featured?: boolean | null
          name?: string
          prompt_template?: string | null
          rating?: number | null
          tags?: string[] | null
          updated_at?: string
        }
        Relationships: []
      }
      marketplace_mcp_reviews: {
        Row: {
          comment: string | null
          created_at: string
          id: string
          mcp_id: string
          owner_id: string | null
          rating: number
          reviewer_name: string
        }
        Insert: {
          comment?: string | null
          created_at?: string
          id?: string
          mcp_id: string
          owner_id?: string | null
          rating: number
          reviewer_name?: string
        }
        Update: {
          comment?: string | null
          created_at?: string
          id?: string
          mcp_id?: string
          owner_id?: string | null
          rating?: number
          reviewer_name?: string
        }
        Relationships: [
          {
            foreignKeyName: "marketplace_mcp_reviews_mcp_id_fkey"
            columns: ["mcp_id"]
            isOneToOne: false
            referencedRelation: "marketplace_mcps"
            referencedColumns: ["id"]
          },
        ]
      }
      marketplace_mcps: {
        Row: {
          auth_type: string | null
          category: string
          created_at: string
          creator_name: string | null
          description: string | null
          icon: string | null
          id: string
          installs: number | null
          is_featured: boolean | null
          is_verified: boolean | null
          name: string
          rating: number | null
          server_url: string | null
          tags: string[] | null
          tools_count: number | null
          tools_schema: Json | null
          updated_at: string
        }
        Insert: {
          auth_type?: string | null
          category?: string
          created_at?: string
          creator_name?: string | null
          description?: string | null
          icon?: string | null
          id?: string
          installs?: number | null
          is_featured?: boolean | null
          is_verified?: boolean | null
          name: string
          rating?: number | null
          server_url?: string | null
          tags?: string[] | null
          tools_count?: number | null
          tools_schema?: Json | null
          updated_at?: string
        }
        Update: {
          auth_type?: string | null
          category?: string
          created_at?: string
          creator_name?: string | null
          description?: string | null
          icon?: string | null
          id?: string
          installs?: number | null
          is_featured?: boolean | null
          is_verified?: boolean | null
          name?: string
          rating?: number | null
          server_url?: string | null
          tags?: string[] | null
          tools_count?: number | null
          tools_schema?: Json | null
          updated_at?: string
        }
        Relationships: []
      }
      marketplace_plugins: {
        Row: {
          created_at: string
          creator_name: string | null
          description: string | null
          id: string
          installs: number | null
          is_featured: boolean | null
          name: string
          rating: number | null
          skill_config: Json | null
          skill_ids: string[]
          tags: string[] | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          creator_name?: string | null
          description?: string | null
          id?: string
          installs?: number | null
          is_featured?: boolean | null
          name: string
          rating?: number | null
          skill_config?: Json | null
          skill_ids?: string[]
          tags?: string[] | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          creator_name?: string | null
          description?: string | null
          id?: string
          installs?: number | null
          is_featured?: boolean | null
          name?: string
          rating?: number | null
          skill_config?: Json | null
          skill_ids?: string[]
          tags?: string[] | null
          updated_at?: string
        }
        Relationships: []
      }
      marketplace_reviews: {
        Row: {
          agent_id: string
          comment: string | null
          created_at: string
          id: string
          owner_id: string | null
          rating: number
          reviewer_name: string
        }
        Insert: {
          agent_id: string
          comment?: string | null
          created_at?: string
          id?: string
          owner_id?: string | null
          rating: number
          reviewer_name?: string
        }
        Update: {
          agent_id?: string
          comment?: string | null
          created_at?: string
          id?: string
          owner_id?: string | null
          rating?: number
          reviewer_name?: string
        }
        Relationships: [
          {
            foreignKeyName: "marketplace_reviews_agent_id_fkey"
            columns: ["agent_id"]
            isOneToOne: false
            referencedRelation: "marketplace_agents"
            referencedColumns: ["id"]
          },
        ]
      }
      marketplace_skill_reviews: {
        Row: {
          comment: string | null
          created_at: string
          id: string
          owner_id: string | null
          rating: number
          reviewer_name: string
          skill_id: string
        }
        Insert: {
          comment?: string | null
          created_at?: string
          id?: string
          owner_id?: string | null
          rating: number
          reviewer_name?: string
          skill_id: string
        }
        Update: {
          comment?: string | null
          created_at?: string
          id?: string
          owner_id?: string | null
          rating?: number
          reviewer_name?: string
          skill_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "marketplace_skill_reviews_skill_id_fkey"
            columns: ["skill_id"]
            isOneToOne: false
            referencedRelation: "marketplace_skills"
            referencedColumns: ["id"]
          },
        ]
      }
      marketplace_skills: {
        Row: {
          category: string
          created_at: string
          creator_name: string | null
          description: string | null
          icon: string | null
          id: string
          implementation: string | null
          input_schema: Json | null
          installs: number | null
          is_composable: boolean | null
          is_featured: boolean | null
          name: string
          output_schema: Json | null
          rating: number | null
          skill_type: string
          tags: string[] | null
          updated_at: string
        }
        Insert: {
          category?: string
          created_at?: string
          creator_name?: string | null
          description?: string | null
          icon?: string | null
          id?: string
          implementation?: string | null
          input_schema?: Json | null
          installs?: number | null
          is_composable?: boolean | null
          is_featured?: boolean | null
          name: string
          output_schema?: Json | null
          rating?: number | null
          skill_type?: string
          tags?: string[] | null
          updated_at?: string
        }
        Update: {
          category?: string
          created_at?: string
          creator_name?: string | null
          description?: string | null
          icon?: string | null
          id?: string
          implementation?: string | null
          input_schema?: Json | null
          installs?: number | null
          is_composable?: boolean | null
          is_featured?: boolean | null
          name?: string
          output_schema?: Json | null
          rating?: number | null
          skill_type?: string
          tags?: string[] | null
          updated_at?: string
        }
        Relationships: []
      }
      marketplace_workflow_reviews: {
        Row: {
          comment: string | null
          created_at: string
          id: string
          owner_id: string | null
          rating: number
          reviewer_name: string
          workflow_id: string
        }
        Insert: {
          comment?: string | null
          created_at?: string
          id?: string
          owner_id?: string | null
          rating: number
          reviewer_name?: string
          workflow_id: string
        }
        Update: {
          comment?: string | null
          created_at?: string
          id?: string
          owner_id?: string | null
          rating?: number
          reviewer_name?: string
          workflow_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "marketplace_workflow_reviews_workflow_id_fkey"
            columns: ["workflow_id"]
            isOneToOne: false
            referencedRelation: "marketplace_workflows"
            referencedColumns: ["id"]
          },
        ]
      }
      marketplace_workflows: {
        Row: {
          category: string
          created_at: string
          creator_name: string | null
          description: string | null
          id: string
          installs: number | null
          is_featured: boolean | null
          name: string
          rating: number | null
          steps: Json | null
          tags: string[] | null
          trigger_type: string | null
          updated_at: string
        }
        Insert: {
          category?: string
          created_at?: string
          creator_name?: string | null
          description?: string | null
          id?: string
          installs?: number | null
          is_featured?: boolean | null
          name: string
          rating?: number | null
          steps?: Json | null
          tags?: string[] | null
          trigger_type?: string | null
          updated_at?: string
        }
        Update: {
          category?: string
          created_at?: string
          creator_name?: string | null
          description?: string | null
          id?: string
          installs?: number | null
          is_featured?: boolean | null
          name?: string
          rating?: number | null
          steps?: Json | null
          tags?: string[] | null
          trigger_type?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      tasks: {
        Row: {
          category: string | null
          created_at: string
          customer: string | null
          description: string | null
          id: string
          owner_id: string | null
          severity: string | null
          source: string | null
          source_id: string | null
          status: string
          title: string
          updated_at: string
        }
        Insert: {
          category?: string | null
          created_at?: string
          customer?: string | null
          description?: string | null
          id?: string
          owner_id?: string | null
          severity?: string | null
          source?: string | null
          source_id?: string | null
          status?: string
          title: string
          updated_at?: string
        }
        Update: {
          category?: string | null
          created_at?: string
          customer?: string | null
          description?: string | null
          id?: string
          owner_id?: string | null
          severity?: string | null
          source?: string | null
          source_id?: string | null
          status?: string
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      execute_readonly_query: { Args: { query_text: string; max_rows?: number }; Returns: Json }
    }
    Enums: {
      canvas_edge_status:
        | "suggested"
        | "confirmed"
        | "rejected"
        | "hidden"
        | "archived"
      canvas_edge_type:
        | "related"
        | "same_customer"
        | "same_project"
        | "follow_up"
        | "cause_effect"
        | "evidence"
        | "conflict"
        | "derived_from"
        | "mentioned_in"
      canvas_evidence_type:
        | "shared_entity"
        | "shared_keyword"
        | "embedding_similarity"
        | "same_document"
        | "temporal_proximity"
        | "user_confirmed"
        | "ai_reasoning"
      canvas_node_status: "active" | "archived" | "deleted" | "needs_review"
      canvas_node_type:
        | "memo"
        | "meeting"
        | "customer"
        | "document"
        | "action"
        | "product"
        | "issue"
        | "risk"
        | "ai_insight"
        | "project"
        | "report"
      canvas_review_decision: "approved" | "rejected" | "edited" | "deferred"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      canvas_edge_status: [
        "suggested",
        "confirmed",
        "rejected",
        "hidden",
        "archived",
      ],
      canvas_edge_type: [
        "related",
        "same_customer",
        "same_project",
        "follow_up",
        "cause_effect",
        "evidence",
        "conflict",
        "derived_from",
        "mentioned_in",
      ],
      canvas_evidence_type: [
        "shared_entity",
        "shared_keyword",
        "embedding_similarity",
        "same_document",
        "temporal_proximity",
        "user_confirmed",
        "ai_reasoning",
      ],
      canvas_node_status: ["active", "archived", "deleted", "needs_review"],
      canvas_node_type: [
        "memo",
        "meeting",
        "customer",
        "document",
        "action",
        "product",
        "issue",
        "risk",
        "ai_insight",
        "project",
        "report",
      ],
      canvas_review_decision: ["approved", "rejected", "edited", "deferred"],
    },
  },
} as const
