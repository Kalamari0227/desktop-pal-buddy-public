import { afterEach, describe, expect, it, vi } from "vitest";

const createDemoSupabaseClient = vi.fn(() => ({ from: vi.fn() }));
const createClient = vi.fn(() => ({ from: vi.fn() }));

vi.mock("./demoClient", () => ({ createDemoSupabaseClient }));
vi.mock("@supabase/supabase-js", () => ({ createClient }));

async function loadClient(env: Record<string, string | undefined>) {
  vi.resetModules();
  vi.stubEnv("VITE_APP_MODE", env.VITE_APP_MODE);
  vi.stubEnv("VITE_SUPABASE_URL", env.VITE_SUPABASE_URL);
  vi.stubEnv("VITE_SUPABASE_PUBLISHABLE_KEY", env.VITE_SUPABASE_PUBLISHABLE_KEY);
  await import("./client");
}

describe("Supabase client strategy fixtures", () => {
  afterEach(() => {
    vi.unstubAllEnvs();
    vi.clearAllMocks();
  });

  it("opts into strategy fixtures only for explicit demo mode", async () => {
    await loadClient({ VITE_APP_MODE: "demo" });
    expect(createDemoSupabaseClient).toHaveBeenCalledWith({ includeStrategyFixtures: true });
  });

  it.each(["staging", "production"])("does not load strategy fixtures for %s missing-config fallback", async (mode) => {
    await loadClient({ VITE_APP_MODE: mode });
    expect(createDemoSupabaseClient).toHaveBeenCalledWith({ includeStrategyFixtures: false });
  });
});
