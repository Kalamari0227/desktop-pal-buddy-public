import { originalDemoMarketplaceData } from "@/data/demoMarketplaceData";
import { createDemoStrategyRows } from "@/data/demoStrategyData";

const now = new Date();
const daysAgo = (days: number) => new Date(now.getTime() - days * 86400000).toISOString();

const demoTasks = [
  {
    id: "demo-task-hyundai-quality",
    title: "GA 강판 품질 재검 및 출하 일정 조정",
    description: "현대자동차 2분기 물량 대응을 위한 품질 재검과 대체 출하 일정 협의가 필요합니다.",
    source: "risk",
    source_id: "hyundai-quality",
    severity: "critical",
    customer: "현대자동차",
    category: "quality",
    status: "in_progress",
    created_at: daysAgo(0),
    updated_at: daysAgo(0),
  },
  {
    id: "demo-task-kia-price",
    title: "신규 모델 강판 사양 및 가격 재협상",
    description: "기아 신규 모델 적용 사양과 원자재가 변동분 반영 기준을 정리해야 합니다.",
    source: "manual",
    source_id: "kia-price",
    severity: "high",
    customer: "기아",
    category: "price",
    status: "pending",
    created_at: daysAgo(1),
    updated_at: daysAgo(1),
  },
  {
    id: "demo-task-toyota-export",
    title: "수출 강판 JIS 규격 확인 및 재발 방지 브리핑",
    description: "Toyota 수출 강판 규격 확인 자료와 품질 재발 방지 액션을 준비합니다.",
    source: "audit",
    source_id: "toyota-quality",
    severity: "medium",
    customer: "Toyota",
    category: "quality",
    status: "pending",
    created_at: daysAgo(2),
    updated_at: daysAgo(2),
  },
  {
    id: "demo-task-gm-delivery",
    title: "DP강 공급 확대 및 원가 절감 협의",
    description: "GM Korea 공급 확대 요청에 대한 월별 물량과 원가 절감안을 정리했습니다.",
    source: "manual",
    source_id: "gm-delivery",
    severity: "medium",
    customer: "GM Korea",
    category: "delivery",
    status: "done",
    created_at: daysAgo(3),
    updated_at: daysAgo(1),
  },
];

const demoCanvasNodes = [
  { id: "hyundai", type: "customer", title: "현대자동차", customer_id: "hyundai", importance_score: 0.95, status: "active" },
  { id: "kia", type: "customer", title: "기아", customer_id: "kia", importance_score: 0.86, status: "active" },
  { id: "quality-risk", type: "risk", title: "GA 강판 품질 재검", customer_id: "hyundai", importance_score: 0.9, status: "active" },
  { id: "price-action", type: "action", title: "가격 재협상 초안", customer_id: "kia", importance_score: 0.74, status: "active" },
];

const demoCanvasEdges = [
  { id: "edge-1", source_id: "hyundai", target_id: "quality-risk", type: "related", status: "approved", confidence_score: 0.92 },
  { id: "edge-2", source_id: "kia", target_id: "price-action", type: "follow_up", status: "approved", confidence_score: 0.81 },
];

export type DemoRow = Record<string, unknown>;
type DemoRowsResult = { data: DemoRow[]; error: null };
type DemoSingleResult = { data: DemoRow | null; error: null };

const clone = <T>(value: T): T => structuredClone(value);

const toRows = (payload?: unknown): DemoRow[] => {
  if (Array.isArray(payload)) return payload.filter((row): row is DemoRow => Boolean(row) && typeof row === "object" && !Array.isArray(row));
  return payload && typeof payload === "object" && !Array.isArray(payload) ? [payload as DemoRow] : [];
};

function createInitialTableData(includeStrategyFixtures: boolean): Record<string, DemoRow[]> {
  const strategyRows = includeStrategyFixtures ? createDemoStrategyRows() : null;
  return clone({
    agent_approvals: [],
    agent_evidence: strategyRows?.evidence ?? [],
    agent_events: strategyRows?.events ?? [],
    agent_results: strategyRows?.results ?? [],
    tasks: [...demoTasks, ...(strategyRows?.tasks ?? [])] as unknown as DemoRow[],
    alert_dismissals: [],
    installed_items: [...originalDemoMarketplaceData.installed_items],
    canvas_nodes: demoCanvasNodes,
    canvas_edges: demoCanvasEdges,
    canvas_evidences: [],
    canvas_review_decisions: [],
    canvas_graph_snapshots: [],
    marketplace_agents: [...originalDemoMarketplaceData.marketplace_agents],
    marketplace_reviews: [],
    marketplace_workflows: [...originalDemoMarketplaceData.marketplace_workflows],
    marketplace_workflow_reviews: [],
    marketplace_skills: [...originalDemoMarketplaceData.marketplace_skills],
    marketplace_skill_reviews: [],
    marketplace_plugins: [...originalDemoMarketplaceData.marketplace_plugins],
    marketplace_mcps: [...originalDemoMarketplaceData.marketplace_mcps],
    marketplace_mcp_reviews: [],
    debate_history: [],
  } satisfies Record<string, DemoRow[]>);
}

export interface DemoQuery {
  select(columns?: string): DemoQuery;
  insert(payload?: unknown): DemoQuery;
  update(payload?: unknown): DemoQuery;
  upsert(payload?: unknown): DemoQuery;
  delete(): DemoQuery;
  eq(column: string, value: unknown): DemoQuery;
  neq(column: string, value: unknown): DemoQuery;
  in(column: string, values: unknown[]): DemoQuery;
  is(column: string, value: unknown): DemoQuery;
  gte(column: string, value: unknown): DemoQuery;
  lte(column: string, value: unknown): DemoQuery;
  gt(column: string, value: unknown): DemoQuery;
  lt(column: string, value: unknown): DemoQuery;
  ilike(column: string, value: string): DemoQuery;
  like(column: string, value: string): DemoQuery;
  or(value?: string): DemoQuery;
  contains(column?: string, value?: unknown): DemoQuery;
  range(from: number, to: number): DemoQuery;
  order(column: string, options?: { ascending?: boolean }): DemoQuery;
  limit(count: number): DemoQuery;
  single(): Promise<DemoSingleResult>;
  then: Promise<DemoRowsResult>["then"];
  catch: Promise<DemoRowsResult>["catch"];
  finally: Promise<DemoRowsResult>["finally"];
}

type Filter = (row: DemoRow) => boolean;
type Mutation = "select" | "insert" | "update" | "upsert" | "delete";
const PERSISTED_TASK_TABLES = new Set([
  "tasks",
  "agent_approvals",
  "agent_evidence",
  "agent_events",
  "agent_results",
]);

function createDemoQuery(
  tableData: Record<string, DemoRow[]>,
  table: string,
  nextId: () => number,
): DemoQuery {
  let mutation: Mutation = "select";
  let payloadRows: DemoRow[] = [];
  const filters: Filter[] = [];
  const orders: Array<{ column: string; ascending: boolean }> = [];
  let range: { from: number; to: number } | undefined;
  let limit: number | undefined;
  let execution: Promise<DemoRowsResult> | undefined;

  const sourceRows = () => tableData[table] ?? (tableData[table] = []);
  const matches = (row: DemoRow) => filters.every((filter) => filter(row));
  const prepareRows = (rows: DemoRow[]) => rows.map((row) => ({
    ...clone(row),
    id: row.id ?? `demo-${table}-${nextId()}`,
  }));
  const prepareInsertedRows = (rows: DemoRow[]) => prepareRows(rows).map((row) => {
    if (table !== "tasks") {
      return row;
    }

    const insertedAt = new Date().toISOString();
    return {
      created_at: insertedAt,
      updated_at: insertedAt,
      ...row,
    };
  });
  const applyView = (input: DemoRow[]) => {
    let rows = input.filter(matches);
    for (const order of orders) {
      rows = [...rows].sort((a, b) => {
        const comparison = String(a[order.column] ?? "").localeCompare(String(b[order.column] ?? ""));
        return order.ascending ? comparison : -comparison;
      });
    }
    if (range) {
      rows = rows.slice(range.from, range.to + 1);
    }
    if (limit !== undefined) {
      rows = rows.slice(0, limit);
    }
    return rows;
  };
  const execute = (): Promise<DemoRowsResult> => {
    if (execution) return execution;

    execution = Promise.resolve().then(() => {
      if (mutation !== "select" && !PERSISTED_TASK_TABLES.has(table)) {
        return { data: clone(payloadRows), error: null };
      }

      const stored = sourceRows();
      let affected: DemoRow[];

      if (mutation === "insert") {
        affected = prepareInsertedRows(payloadRows);
        stored.push(...affected);
      } else if (mutation === "upsert") {
        affected = prepareRows(payloadRows).map((row) => {
          const index = stored.findIndex((candidate) => candidate.id === row.id);
          if (index >= 0) {
            stored[index] = row;
          } else {
            stored.push(row);
          }
          return row;
        });
      } else if (mutation === "update") {
        affected = [];
        stored.forEach((row, index) => {
          if (matches(row)) {
            stored[index] = { ...row, ...clone(payloadRows[0] ?? {}) };
            affected.push(stored[index]);
          }
        });
      } else if (mutation === "delete") {
        affected = stored.filter(matches);
        tableData[table] = stored.filter((row) => !matches(row));
      } else {
        affected = applyView(stored);
      }

      return { data: clone(affected), error: null };
    });
    return execution;
  };
  const resolveSingle = (): Promise<DemoSingleResult> => execute().then((result) => ({
    data: result.data[0] ?? null,
    error: null,
  }));
  const query: Record<string, unknown> = {
    select: () => query,
    insert: (payload?: unknown) => { mutation = "insert"; payloadRows = toRows(payload); return query; },
    update: (payload?: unknown) => { mutation = "update"; payloadRows = toRows(payload); return query; },
    upsert: (payload?: unknown) => { mutation = "upsert"; payloadRows = toRows(payload); return query; },
    delete: () => { mutation = "delete"; return query; },
    eq: (column: string, value: unknown) => { filters.push((row) => row[column] === value); return query; },
    neq: (column: string, value: unknown) => { filters.push((row) => row[column] !== value); return query; },
    "in": (column: string, values: unknown[]) => { filters.push((row) => values.includes(row[column])); return query; },
    is: (column: string, value: unknown) => { filters.push((row) => row[column] === value); return query; },
    gte: (column: string, value: unknown) => { filters.push((row) => String(row[column] ?? "") >= String(value)); return query; },
    lte: (column: string, value: unknown) => { filters.push((row) => String(row[column] ?? "") <= String(value)); return query; },
    gt: (column: string, value: unknown) => { filters.push((row) => String(row[column] ?? "") > String(value)); return query; },
    lt: (column: string, value: unknown) => { filters.push((row) => String(row[column] ?? "") < String(value)); return query; },
    ilike: (column: string, value: string) => { const needle = value.replace(/%/g, "").toLowerCase(); filters.push((row) => String(row[column] ?? "").toLowerCase().includes(needle)); return query; },
    like: (column: string, value: string) => { const needle = value.replace(/%/g, ""); filters.push((row) => String(row[column] ?? "").includes(needle)); return query; },
    or: () => query,
    contains: () => query,
    range: (from: number, to: number) => { range = { from, to }; return query; },
    order: (column: string, options?: { ascending?: boolean }) => { orders.push({ column, ascending: options?.ascending !== false }); return query; },
    limit: (count: number) => { limit = count; return query; },
    single: resolveSingle,
    then: (...args: Parameters<Promise<DemoRowsResult>["then"]>) => execute().then(...args),
    catch: (...args: Parameters<Promise<DemoRowsResult>["catch"]>) => execute().catch(...args),
    finally: (...args: Parameters<Promise<DemoRowsResult>["finally"]>) => execute().finally(...args),
  };
  return query as unknown as DemoQuery;
}

export function createDemoSupabaseClient(options?: { includeStrategyFixtures?: boolean }) {
  const tableData = createInitialTableData(options?.includeStrategyFixtures === true);
  let rowSequence = 0;

  return {
    from: (table: string) => createDemoQuery(tableData, table, () => {
      rowSequence += 1;
      return rowSequence;
    }),
    rpc: async () => ({ data: [], error: null }),
    functions: {
      invoke: async () => ({ data: { response: "Demo mode: backend functions are disabled." }, error: null }),
    },
    auth: {
      getSession: async () => ({ data: { session: null }, error: null }),
      onAuthStateChange: () => ({ data: { subscription: { unsubscribe: () => undefined } } }),
      signInWithPassword: async () => ({
        data: { user: null, session: null },
        error: { message: "Demo mode does not use Supabase Auth." },
      }),
      signOut: async () => ({ error: null }),
    },
  };
}
