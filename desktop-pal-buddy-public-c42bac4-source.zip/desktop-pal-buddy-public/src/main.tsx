import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";

// Ensure dark background persists during boot (prevents white flash)
const lockBootBackground = () => {
  document.documentElement.style.backgroundColor = "#0B0F1A";
  document.body.style.backgroundColor = "#0B0F1A";
  const root = document.getElementById("root");
  if (root) root.style.backgroundColor = "#0B0F1A";
};
lockBootBackground();

// Defer light theme application until boot completes to prevent white flash.
const isThemeMode = (value: string | null): value is NonNullable<Window["__deferredTheme"]> =>
  value === "dark" || value === "light" || value === "system";
const storedTheme = localStorage.getItem("steel-theme");
window.__deferredTheme = isThemeMode(storedTheme) ? storedTheme : "light";
window.__applyDeferredTheme = () => {
  lockBootBackground();
  const theme = window.__deferredTheme || "light";
  if (theme === "system") {
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    document.documentElement.classList.toggle("light", !prefersDark);
  } else {
    document.documentElement.classList.toggle("light", theme === "light");
  }
  lockBootBackground();
  requestAnimationFrame(lockBootBackground);
};

createRoot(document.getElementById("root")!).render(<App />);
