import { useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Calendar,
  PenLine,
  Search,
  ShieldAlert,
  LayoutDashboard,
  ArrowRight,
} from "lucide-react";
import { CoreOrb } from "./CoreOrb";
import { AgentOrb } from "./AgentOrb";
import type { DockState, Agent, DockAlert } from "@/types/dock";
import { STATE_LABELS, QUICK_ACTIONS } from "@/types/dock";
import { cn } from "@/lib/utils";

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  Calendar, PenLine, Search, ShieldAlert, LayoutDashboard,
};

interface AmbientDockProps {
  state: DockState;
  agents: Agent[];
  alerts: DockAlert[];
  onStateChange: (state: DockState) => void;
  onQuickAction: (actionId: string) => void;
  onAgentClick: (agentId: string) => void;
  onOpenWorkspace: (initialMode?: string) => void;
  onDismissAlert?: (alertId: string) => void;
  isUserTyping?: boolean;
  layoutMode?: "desktop" | "widget";
  enterAnimation?: boolean;
}

const fadeUp = {
  initial: { opacity: 0, y: 8 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: 8 },
  transition: { duration: 0.2 },
};

export function AmbientDock({
  state, agents, alerts,
  onStateChange, onQuickAction, onAgentClick, onOpenWorkspace, onDismissAlert, isUserTyping,
  layoutMode = "desktop", enterAnimation = false,
}: AmbientDockProps) {
  const collapseTimeoutRef = useRef<number | null>(null);
  const isExpanded = state === "expanded" || state === "hovered";
  const isActive = ["thinking", "dispatching", "working", "needs_review", "alert", "completed"].includes(state);
  const showAgents = isExpanded || isActive;
  const showQuickActions = isExpanded;
  const activeAlert = alerts[0];
  const isWidget = layoutMode === "widget";

  useEffect(() => {
    return () => {
      if (collapseTimeoutRef.current) {
        window.clearTimeout(collapseTimeoutRef.current);
      }
    };
  }, []);

  const clearCollapseTimeout = () => {
    if (collapseTimeoutRef.current) {
      window.clearTimeout(collapseTimeoutRef.current);
      collapseTimeoutRef.current = null;
    }
  };

  const handleMouseEnter = () => {
    clearCollapseTimeout();
    if (state === "idle") onStateChange("hovered");
  };

  const handleMouseLeave = () => {
    clearCollapseTimeout();
    if (isActive) return;

    collapseTimeoutRef.current = window.setTimeout(() => {
      if (state === "hovered" || state === "expanded") {
        onStateChange("idle");
      }
      collapseTimeoutRef.current = null;
    }, 140);
  };
  const handleCoreClick = () => {
    if (state === "idle" || state === "hovered") onStateChange("expanded");
    else if (state === "expanded" || state === "completed" || state === "needs_review") onOpenWorkspace();
  };

  return (
    <div
      className={cn(
        "z-50 flex flex-col items-end gap-2 transition-all duration-700 ease-out",
        isWidget
          ? "pointer-events-none absolute inset-0 justify-end p-4"
          : "fixed bottom-5 right-5",
        enterAnimation ? "opacity-0 translate-y-8" : "opacity-100 translate-y-0",
      )}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      {/* Expanded content panel — appears above the pill */}
      <AnimatePresence>
        {(showQuickActions || state === "alert" || state === "completed" || state === "working" || state === "dispatching") && (
          <motion.div
            {...fadeUp}
            className="pointer-events-auto w-[320px] rounded-2xl overflow-hidden shrink-0"
            style={{
              background: "hsl(var(--card))",
              border: "1px solid hsl(var(--border))",
              boxShadow: "var(--shadow-3)",
            }}
          >
            {/* Alert card */}
            {state === "alert" && activeAlert && (
              <div className="p-4">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
                    style={{ background: "hsla(var(--status-alert) / 0.12)" }}>
                    <ShieldAlert className="w-4 h-4" style={{ color: "hsl(var(--status-alert))" }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-[12px] font-semibold text-foreground">{activeAlert.title}</p>
                    {activeAlert.customer && (
                      <p className="text-[11px] text-muted-foreground mt-0.5">{activeAlert.customer}</p>
                    )}
                  </div>
                  <span className="text-[9px] px-2 py-0.5 rounded-full font-semibold flex-shrink-0"
                    style={{
                      background: "hsla(var(--status-alert) / 0.12)",
                      color: "hsl(var(--status-alert))",
                    }}>
                    {activeAlert.severity === "high" ? "긴급" : "주의"}
                  </span>
                </div>
                <div className="flex gap-2 mt-3 ml-11">
                  <button
                    onClick={() => onOpenWorkspace("risk")}
                    className="text-[11px] px-3 py-1.5 rounded-lg font-semibold transition-colors"
                    style={{ background: "hsl(var(--status-alert))", color: "white" }}
                  >
                    확인하기
                  </button>
                  <button
                    onClick={() => {
                      if (activeAlert && onDismissAlert) onDismissAlert(activeAlert.id);
                      onStateChange("idle");
                    }}
                    className="text-[11px] px-3 py-1.5 rounded-lg font-medium text-muted-foreground hover:bg-secondary transition-colors"
                  >
                    나중에
                  </button>
                </div>
              </div>
            )}

            {/* Working status */}
            {(state === "working" || state === "dispatching") && (
              <div className="px-4 py-3 flex items-center gap-3">
                <motion.div
                  className="w-2 h-2 rounded-full"
                  style={{ background: "hsl(var(--primary))" }}
                  animate={{ opacity: [1, 0.3, 1] }}
                  transition={{ duration: 1, repeat: Infinity }}
                />
                <p className="text-[11px] text-muted-foreground">
                  {state === "dispatching" ? "에이전트 배정 중..." : "작업 수행 중..."}
                </p>
              </div>
            )}

            {/* Completed */}
            {state === "completed" && (
              <div className="p-4 flex items-center justify-between">
                <p className="text-[12px] font-medium text-foreground">결과가 준비되었습니다</p>
                <button
                  onClick={() => onOpenWorkspace()}
                  className="text-[11px] px-3 py-1.5 rounded-lg font-semibold flex items-center gap-1 transition-colors"
                  style={{ background: "hsl(var(--primary))", color: "hsl(var(--primary-foreground))" }}
                >
                  열기 <ArrowRight className="w-3 h-3" />
                </button>
              </div>
            )}

            {/* Quick actions */}
            {showQuickActions && (
              <div className="p-2">
                {QUICK_ACTIONS.slice(0, 4).map((action) => {
                  const Icon = iconMap[action.icon];
                  return (
                    <button
                      key={action.id}
                      onClick={() => onQuickAction(action.id)}
                      className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-[12px] text-foreground hover:bg-secondary/60 transition-colors text-left group"
                    >
                      {Icon && (
                        <div className="w-7 h-7 rounded-lg flex items-center justify-center bg-secondary/80 group-hover:bg-secondary transition-colors">
                          <Icon className="w-3.5 h-3.5 text-muted-foreground" />
                        </div>
                      )}
                      <span className="font-medium">{action.label}</span>
                    </button>
                  );
                })}

                <div className="mx-2 my-1.5 h-px bg-border/50" />

                <button
                  onClick={() => onOpenWorkspace()}
                  className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-[12px] hover:bg-secondary/60 transition-colors text-left group"
                >
                  <div className="w-7 h-7 rounded-lg flex items-center justify-center bg-primary/10 group-hover:bg-primary/15 transition-colors">
                    <LayoutDashboard className="w-3.5 h-3.5 text-primary" />
                  </div>
                  <span className="font-semibold text-primary">워크스페이스 열기</span>
                </button>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Bottom pill — always visible */}
      <div
        className="pointer-events-auto flex shrink-0 items-center gap-4 rounded-full p-2.5 px-5"
        style={{
          background: "hsl(var(--card))",
          border: "1px solid hsl(var(--border))",
          boxShadow: "var(--shadow-2)",
        }}
      >
        {/* Agent orbs */}
        <AnimatePresence>
          {showAgents && agents.map((agent, i) => (
            <motion.div
              key={agent.id}
              initial={{ opacity: 0, width: 0 }}
              animate={{ opacity: 1, width: "auto" }}
              exit={{ opacity: 0, width: 0 }}
              transition={{ duration: 0.2, delay: i * 0.03 }}
            >
              <AgentOrb
                agent={agent}
                size={isExpanded ? "md" : "sm"}
                onClick={() => onAgentClick(agent.id)}
              />
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Status label chip */}
        <AnimatePresence>
          {isActive && (
            <motion.span
              initial={{ opacity: 0, width: 0 }}
              animate={{ opacity: 1, width: "auto" }}
              exit={{ opacity: 0, width: 0 }}
              className="text-[10px] font-medium text-muted-foreground px-2 whitespace-nowrap"
            >
              {STATE_LABELS[state]}
            </motion.span>
          )}
        </AnimatePresence>

        {/* Core orb */}
        <CoreOrb state={state} onClick={handleCoreClick} isUserTyping={isUserTyping} />
      </div>
    </div>
  );
}
