import { useRef, useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import type { DockState } from "@/types/dock";

interface CoreOrbProps {
  state: DockState;
  onClick?: () => void;
  isUserTyping?: boolean;
}

function getVideoSrc(state: DockState, isUserTyping?: boolean): string {
  if (isUserTyping) return "./animations/listening.mp4";
  switch (state) {
    case "thinking":
    case "dispatching":
    case "working":
      return "./animations/thinking.mp4";
    case "listening":
      return "./animations/listening.mp4";
    default:
      return "./animations/idle.mp4";
  }
}

export function CoreOrb({ state, onClick, isUserTyping }: CoreOrbProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [currentSrc, setCurrentSrc] = useState(() => getVideoSrc(state, isUserTyping));
  const [isVideoReady, setIsVideoReady] = useState(false);
  const isAlert = state === "alert";
  const isActive = ["thinking", "dispatching", "working", "listening"].includes(state) || isUserTyping;

  useEffect(() => {
    const newSrc = getVideoSrc(state, isUserTyping);
    if (newSrc !== currentSrc) {
      setIsVideoReady(false);
      setCurrentSrc(newSrc);
    }
  }, [state, isUserTyping, currentSrc]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;
    video.load();
    video.play().catch(() => {});
  }, [currentSrc]);

  return (
    <button
      onClick={onClick}
      className="relative w-24 h-24 rounded-full flex items-center justify-center cursor-pointer group transition-transform duration-200 hover:scale-105 active:scale-95 overflow-hidden"
      style={{
        backgroundColor: "#05070c",
        boxShadow: isAlert
          ? "0 4px 20px hsla(var(--status-alert) / 0.4)"
          : isActive
          ? "0 4px 20px hsla(var(--primary) / 0.4)"
          : "0 2px 12px hsla(var(--primary) / 0.25)",
      }}
    >
      <video
        ref={videoRef}
        src={currentSrc}
        autoPlay
        loop
        muted
        playsInline
        onLoadedData={() => setIsVideoReady(true)}
        className="absolute inset-0 w-full h-full object-cover rounded-full transition-opacity duration-300"
        style={{ opacity: isVideoReady ? 1 : 0 }}
      />

      {/* Alert overlay tint */}
      {isAlert && (
        <div
          className="absolute inset-0 rounded-full"
          style={{ background: "hsla(var(--status-alert) / 0.3)" }}
        />
      )}

      {/* Pulse ring for active states */}
      <AnimatePresence>
        {isActive && (
          <motion.div
            initial={{ opacity: 0, scale: 1 }}
            animate={{ opacity: [0.3, 0], scale: [1, 1.6] }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.5, repeat: Infinity, ease: "easeOut" }}
            className="absolute inset-0 rounded-full"
            style={{ background: "hsl(var(--primary))" }}
          />
        )}
      </AnimatePresence>
    </button>
  );
}
