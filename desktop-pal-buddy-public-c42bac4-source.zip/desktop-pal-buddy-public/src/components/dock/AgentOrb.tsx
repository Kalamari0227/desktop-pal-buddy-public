import { motion } from "framer-motion";
import { BarChart3, Shield, FileText, TrendingUp, CalendarCheck } from "lucide-react";
import type { Agent } from "@/types/dock";

interface AgentOrbProps {
  agent: Agent;
  size?: "sm" | "md";
  onClick?: () => void;
}

const agentConfig: Record<string, { colorVar: string; Icon: React.ComponentType<{ className?: string; style?: React.CSSProperties }> }> = {
  market: { colorVar: "--agent-market", Icon: BarChart3 },
  risk: { colorVar: "--agent-risk", Icon: Shield },
  docs: { colorVar: "--agent-docs", Icon: FileText },
  sales: { colorVar: "--agent-sales", Icon: TrendingUp },
  planner: { colorVar: "--agent-planner", Icon: CalendarCheck },
};

export function AgentOrb({ agent, size = "sm", onClick }: AgentOrbProps) {
  const config = agentConfig[agent.id] ?? agentConfig.market;
  const { colorVar, Icon } = config;
  const dim = size === "sm" ? 44 : 52;
  const isActive = ["activated", "focused", "completed"].includes(agent.state);
  const isInactive = ["hidden", "inactive"].includes(agent.state);

  return (
    <button
      onClick={onClick}
      className="relative flex flex-col items-center gap-1.5 cursor-pointer transition-all duration-200 hover:scale-105 active:scale-95"
      style={{ opacity: isInactive ? 0.35 : 1 }}
    >
      <div
        className="rounded-full flex items-center justify-center transition-all duration-300"
        style={{
          width: dim,
          height: dim,
          background: isActive
            ? `hsla(var(${colorVar}) / 0.15)`
            : "hsla(var(--foreground) / 0.06)",
          border: isActive
            ? `1.5px solid hsla(var(${colorVar}) / 0.3)`
            : "1.5px solid hsla(var(--foreground) / 0.08)",
        }}
      >
        <Icon
          className="transition-colors duration-300"
          style={{
            width: size === "sm" ? 20 : 22,
            height: size === "sm" ? 20 : 22,
            color: isActive ? `hsl(var(${colorVar}))` : "hsl(var(--muted-foreground))",
          }}
        />
      </div>

      {/* Active indicator dot */}
      {isActive && (
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="absolute -bottom-0.5 w-1.5 h-1.5 rounded-full"
          style={{ background: `hsl(var(${colorVar}))` }}
        />
      )}

      {/* Badge */}
      {(agent.state === "needs_review" || agent.state === "alert_linked" || (agent.badge && agent.badge > 0)) && (
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          className="absolute -top-0.5 -right-0.5 w-4.5 h-4.5 rounded-full flex items-center justify-center text-[9px] font-bold"
          style={{
            background: agent.state === "alert_linked" ? "hsl(var(--status-alert))" : "hsl(var(--status-review))",
            color: "white",
          }}
        >
          {agent.badge || "!"}
        </motion.div>
      )}

      {size === "md" && (
        <span className="text-[10px] text-muted-foreground font-medium leading-none">
          {agent.nameKo}
        </span>
      )}
    </button>
  );
}
