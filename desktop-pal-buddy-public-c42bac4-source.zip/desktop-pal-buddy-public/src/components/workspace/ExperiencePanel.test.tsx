import { act, fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import {
  createExperienceDraftStore,
  type ExperienceSource,
  type ExperienceWorkItem,
} from "@/lib/company-runtime/experience";
import {
  createLearningAssetStore,
  type LearningPreviewResult,
  type LearningPublishResult,
  type LearningWithdrawResult,
} from "@/lib/company-runtime/learning";
import { ExperiencePanel } from "./ExperiencePanel";

const workItem: ExperienceWorkItem = {
  workboardTaskId: "9e650d6d-9e9f-4a09-b041-e345d16620a8",
  packetTaskId: "27862353-b4b6-43d3-bec2-2e4afe57dc06",
};

const sources: readonly ExperienceSource[] = [
  {
    evidenceId: "evidence:production_plan:PP-DEMO-1001:v2",
    kind: "work_fact",
    workItem,
    asset: { id: "PP-DEMO-1001", version: 2 },
  },
  {
    evidenceId: "readback:f07c5de4-85a8-4ba4-acd2-b7e85cdfe7bb",
    kind: "readback",
    workItem,
    asset: { id: "PP-DEMO-1001", version: 2 },
  },
];

function renderPanel() {
  const store = createExperienceDraftStore({
    sources,
    now: () => "2026-09-19T01:00:00.000Z",
    nextId: () => "experience-panel-1",
  });
  render(<ExperiencePanel actorId="sales-demo" workItem={workItem} sources={sources} store={store} />);
  return store;
}

function fillPrivateDraft() {
  fireEvent.change(screen.getByLabelText("판단 보완"), { target: { value: "검사·출하 준비를 먼저 확인합니다." } });
  fireEvent.change(screen.getByLabelText("적용 조건"), { target: { value: "queued plan" } });
  fireEvent.change(screen.getByLabelText("반례"), { target: { value: "검사 불합격" } });
}

function sharedDraft(id: string, correction = "검사와 출하 준비를 먼저 확인합니다.") {
  const drafts = createExperienceDraftStore({ sources, nextId: () => id });
  const saved = drafts.save({
    authorActorId: "sales-demo",
    workItem,
    sourceEvidenceIds: sources.map((source) => source.evidenceId),
    asset: { id: "PP-DEMO-1001", version: 2 },
    correction,
    applicability: ["queued production plan"],
    counterexample: "검사 불합격",
    outcome: { state: "unobserved" },
    saveDecision: "shared_review",
  });
  if (!saved.ok) throw new Error(saved.code);
  return saved.draft;
}

function previewInput(draft: ReturnType<typeof sharedDraft>) {
  return {
    actorId: "sales-demo" as const,
    draftId: draft.id,
    exactPublishableSentence: draft.correction,
    applicability: draft.applicability,
    targetDepartments: ["production"] as const,
    includeManagementStrategyReview: true,
  };
}

function deferred<T>() {
  let resolve: (value: T) => void = () => undefined;
  const promise = new Promise<T>((complete) => { resolve = complete; });
  return { promise, resolve };
}

describe("ExperiencePanel", () => {
  it("does not create a draft before the employee explicitly invokes 경험 작성", () => {
    const store = renderPanel();

    expect(screen.getByRole("button", { name: "경험 작성" })).toBeInTheDocument();
    expect(screen.queryByLabelText("판단 보완")).not.toBeInTheDocument();
    expect(store.snapshot()).toEqual([]);
  });

  it("defaults to private and only persists selected source-backed input after 나만 보관", () => {
    const store = renderPanel();
    fireEvent.click(screen.getByRole("button", { name: "경험 작성" }));
    fillPrivateDraft();

    expect(screen.getByText(/기본 선택: 나만 보관/)).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "나만 보관" }));

    expect(screen.getByText("개인 초안을 보관했습니다.")).toBeInTheDocument();
    expect(store.listForActor("sales-demo")).toHaveLength(1);
    expect(store.searchForTeam("management-demo")).toEqual([]);
  });

  it("discards form input without storing it when 저장하지 않음 is selected", () => {
    const store = renderPanel();
    fireEvent.click(screen.getByRole("button", { name: "경험 작성" }));
    fillPrivateDraft();
    fireEvent.click(screen.getByRole("button", { name: "저장하지 않음" }));

    expect(screen.getByText("입력을 저장하지 않았습니다.")).toBeInTheDocument();
    expect(screen.queryByLabelText("판단 보완")).not.toBeInTheDocument();
    expect(store.snapshot()).toEqual([]);
  });

  it("labels employee correction separately from work facts and preserves an unobserved outcome", () => {
    renderPanel();
    fireEvent.click(screen.getByRole("button", { name: "경험 작성" }));

    expect(screen.getByLabelText("업무 증거")).toHaveTextContent("업무 사실");
    expect(screen.getByLabelText("업무 증거")).toHaveTextContent("재조회 증거");
    expect(screen.getByText("직원 판단 보완")).toBeInTheDocument();
    expect(screen.getByRole("radio", { name: "결과 미관찰" })).toBeChecked();
  });

  it("uses the selected readback asset version when saving an observed outcome", async () => {
    const sourcesAfterReadback: readonly ExperienceSource[] = [
      { ...sources[0]!, asset: { id: "PP-DEMO-1001", version: 1 } },
      { ...sources[1]!, asset: { id: "PP-DEMO-1001", version: 2 } },
    ];
    const store = createExperienceDraftStore({
      sources: sourcesAfterReadback,
      now: () => "2026-09-19T01:00:00.000Z",
      nextId: () => "experience-panel-observed",
    });
    render(<ExperiencePanel actorId="sales-demo" workItem={workItem} sources={sourcesAfterReadback} store={store} />);

    fireEvent.click(screen.getByRole("button", { name: "경험 작성" }));
    fillPrivateDraft();
    fireEvent.click(screen.getByRole("radio", { name: "재조회 증거로 관찰" }));
    fireEvent.click(screen.getByRole("button", { name: "나만 보관" }));

    expect(await screen.findByText("개인 초안을 보관했습니다.")).toBeInTheDocument();
    expect(store.snapshot()).toEqual([expect.objectContaining({ asset: { id: "PP-DEMO-1001", version: 2 } })]);
  });

  it("shows the exact scoped consent preview before an author can publish", async () => {
    const drafts = createExperienceDraftStore({ sources, now: () => "2026-09-19T01:00:00.000Z" });
    const saved = drafts.save({
      authorActorId: "sales-demo",
      workItem,
      sourceEvidenceIds: sources.map((source) => source.evidenceId),
      asset: { id: "PP-DEMO-1001", version: 2 },
      correction: "검사와 출하 준비를 먼저 확인합니다.",
      applicability: ["queued production plan"],
      counterexample: "검사 불합격",
      outcome: { state: "unobserved" },
      saveDecision: "shared_review",
    });
    if (!saved.ok) throw new Error(saved.code);
    const learningStore = createLearningAssetStore({
      drafts: [saved.draft],
      now: () => "2026-09-19T02:00:00.000Z",
      nextId: () => "learning-ui-1",
      nextPreviewId: () => "learning-preview-ui-1",
    });
    render(<ExperiencePanel
      actorId="sales-demo"
      workItem={workItem}
      sources={sources}
      persistedDrafts={[saved.draft]}
      learningStore={learningStore}
    />);

    expect(screen.queryByRole("button", { name: "동의하고 게시" })).not.toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "공유 미리보기" }));

    const preview = await screen.findByLabelText("학습 게시 미리보기");
    expect(preview).toHaveTextContent("검사와 출하 준비를 먼저 확인합니다.");
    expect(preview).toHaveTextContent(sources[0]!.evidenceId);
    expect(preview).toHaveTextContent("queued production plan");
    expect(preview).toHaveTextContent("생산");
    expect(preview).toHaveTextContent("경영 전략 검토 포함");

    fireEvent.click(screen.getByRole("button", { name: "동의하고 게시" }));
    expect(await screen.findByText("동의한 범위로 게시했습니다.")).toBeInTheDocument();
    expect(learningStore.snapshot().assets).toEqual([
      expect.objectContaining({ version: 1, targetDepartments: ["production"], includeManagementStrategyReview: true }),
    ]);
  });

  it("clears an unpublished consent preview across a role switch", async () => {
    const drafts = createExperienceDraftStore({ sources, now: () => "2026-09-19T01:00:00.000Z" });
    const saved = drafts.save({
      authorActorId: "sales-demo",
      workItem,
      sourceEvidenceIds: sources.map((source) => source.evidenceId),
      asset: { id: "PP-DEMO-1001", version: 2 },
      correction: "검사와 출하 준비를 먼저 확인합니다.",
      applicability: ["queued production plan"],
      counterexample: "검사 불합격",
      outcome: { state: "unobserved" },
      saveDecision: "shared_review",
    });
    if (!saved.ok) throw new Error(saved.code);
    const learningStore = createLearningAssetStore({
      drafts: [saved.draft],
      nextId: () => "learning-ui-role-switch",
      nextPreviewId: () => "learning-preview-ui-role-switch",
    });
    const view = render(<ExperiencePanel
      actorId="sales-demo"
      workItem={workItem}
      sources={sources}
      persistedDrafts={[saved.draft]}
      learningStore={learningStore}
    />);

    fireEvent.click(screen.getByRole("button", { name: "경험 작성" }));
    fireEvent.change(screen.getByLabelText("판단 보완"), { target: { value: "다른 역할에 보이면 안 되는 개인 입력" } });
    fireEvent.change(screen.getByLabelText("적용 조건"), { target: { value: "temporary applicability" } });
    fireEvent.change(screen.getByLabelText("반례"), { target: { value: "temporary counterexample" } });
    fireEvent.click(screen.getByRole("radio", { name: "재조회 증거로 관찰" }));
    fireEvent.click(screen.getByLabelText("영업"));
    fireEvent.click(screen.getByLabelText("경영 전략 검토 포함"));
    fireEvent.click(screen.getByRole("button", { name: "공유 미리보기" }));
    expect(await screen.findByRole("button", { name: "동의하고 게시" })).toBeInTheDocument();

    view.rerender(<ExperiencePanel
      actorId="production-demo"
      workItem={workItem}
      sources={sources}
      persistedDrafts={[saved.draft]}
      learningStore={learningStore}
    />);
    expect(screen.queryByLabelText("학습 게시 미리보기")).not.toBeInTheDocument();

    view.rerender(<ExperiencePanel
      actorId="sales-demo"
      workItem={workItem}
      sources={sources}
      persistedDrafts={[saved.draft]}
      learningStore={learningStore}
    />);
    expect(screen.queryByLabelText("학습 게시 미리보기")).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "동의하고 게시" })).not.toBeInTheDocument();
    expect(screen.queryByText("다른 역할에 보이면 안 되는 개인 입력")).not.toBeInTheDocument();
    expect(screen.getByLabelText("영업")).not.toBeChecked();
    expect(screen.getByLabelText("생산")).toBeChecked();
    expect(screen.getByLabelText("경영 전략 검토 포함")).toBeChecked();

    fireEvent.click(screen.getByRole("button", { name: "경험 작성" }));
    expect(screen.getByLabelText("판단 보완")).toHaveValue("");
    expect(screen.getByLabelText("적용 조건")).toHaveValue("");
    expect(screen.getByLabelText("반례")).toHaveValue("");
    expect(screen.getByRole("radio", { name: "결과 미관찰" })).toBeChecked();
    expect(screen.getAllByRole("checkbox", { name: /업무 사실|재조회 증거/ })).toHaveLength(2);
    for (const evidenceCheckbox of screen.getAllByRole("checkbox", { name: /업무 사실|재조회 증거/ })) {
      expect(evidenceCheckbox).toBeChecked();
    }
  });

  it("ignores a preview response that finishes after switching roles", async () => {
    const drafts = createExperienceDraftStore({ sources });
    const saved = drafts.save({
      authorActorId: "sales-demo",
      workItem,
      sourceEvidenceIds: sources.map((source) => source.evidenceId),
      asset: { id: "PP-DEMO-1001", version: 2 },
      correction: "늦게 도착한 미리보기",
      applicability: ["queued production plan"],
      counterexample: "검사 불합격",
      outcome: { state: "unobserved" },
      saveDecision: "shared_review",
    });
    if (!saved.ok) throw new Error(saved.code);
    const store = createLearningAssetStore({ drafts: [saved.draft] });
    const delayedResult = store.preview({
      actorId: "sales-demo",
      draftId: saved.draft.id,
      exactPublishableSentence: saved.draft.correction,
      applicability: saved.draft.applicability,
      targetDepartments: ["production"],
      includeManagementStrategyReview: true,
    });
    let resolvePreview: ((result: LearningPreviewResult) => void) | undefined;
    const previewLearning = () => new Promise<LearningPreviewResult>((resolve) => { resolvePreview = resolve; });
    const panel = (actorId: "sales-demo" | "production-demo") => <ExperiencePanel
      actorId={actorId}
      workItem={workItem}
      sources={sources}
      persistedDrafts={[saved.draft]}
      previewLearning={previewLearning}
    />;
    const view = render(panel("sales-demo"));

    fireEvent.click(screen.getByRole("button", { name: "공유 미리보기" }));
    view.rerender(panel("production-demo"));
    view.rerender(panel("sales-demo"));
    await act(async () => { resolvePreview?.(delayedResult); });

    expect(screen.queryByLabelText("학습 게시 미리보기")).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "동의하고 게시" })).not.toBeInTheDocument();
  });

  it("ignores a preview response after its department scope changes", async () => {
    const draft = sharedDraft("experience-scope-transition");
    const store = createLearningAssetStore({ drafts: [draft] });
    const pending = deferred<LearningPreviewResult>();
    render(<ExperiencePanel actorId="sales-demo" workItem={workItem} sources={sources}
      persistedDrafts={[draft]} previewLearning={() => pending.promise} />);

    fireEvent.click(screen.getByRole("button", { name: "공유 미리보기" }));
    fireEvent.click(screen.getByLabelText("영업"));
    await act(async () => { pending.resolve(store.preview(previewInput(draft))); });

    expect(screen.queryByLabelText("학습 게시 미리보기")).not.toBeInTheDocument();
  });

  it("ignores a preview response after the source draft changes", async () => {
    const firstDraft = sharedDraft("experience-draft-first", "첫 번째 초안");
    const nextDraft = sharedDraft("experience-draft-next", "두 번째 초안");
    const store = createLearningAssetStore({ drafts: [firstDraft, nextDraft] });
    const pending = deferred<LearningPreviewResult>();
    const panel = (drafts: readonly (typeof firstDraft)[]) => <ExperiencePanel actorId="sales-demo"
      workItem={workItem} sources={sources} persistedDrafts={drafts} previewLearning={() => pending.promise} />;
    const view = render(panel([firstDraft]));

    fireEvent.click(screen.getByRole("button", { name: "공유 미리보기" }));
    view.rerender(panel([firstDraft, nextDraft]));
    await act(async () => { pending.resolve(store.preview(previewInput(firstDraft))); });

    expect(screen.queryByLabelText("학습 게시 미리보기")).not.toBeInTheDocument();
    expect(screen.queryByText("첫 번째 초안")).not.toBeInTheDocument();
  });

  it("ignores a publish completion after a role round trip", async () => {
    const draft = sharedDraft("experience-publish-round-trip");
    const store = createLearningAssetStore({ drafts: [draft] });
    const resultPreview = store.preview(previewInput(draft));
    if (!resultPreview.ok) throw new Error(resultPreview.code);
    const publishResult = store.publish({ actorId: "sales-demo", preview: resultPreview.preview, consentGranted: true });
    const pending = deferred<LearningPublishResult>();
    const panel = (actorId: "sales-demo" | "production-demo") => <ExperiencePanel actorId={actorId}
      workItem={workItem} sources={sources} persistedDrafts={[draft]} learningStore={store}
      publishLearning={() => pending.promise} />;
    const view = render(panel("sales-demo"));
    fireEvent.click(screen.getByRole("button", { name: "공유 미리보기" }));
    fireEvent.click(await screen.findByRole("button", { name: "동의하고 게시" }));

    view.rerender(panel("production-demo"));
    view.rerender(panel("sales-demo"));
    await act(async () => { pending.resolve(publishResult); });

    expect(screen.queryByText("동의한 범위로 게시했습니다.")).not.toBeInTheDocument();
    expect(screen.queryByLabelText("학습 게시 미리보기")).not.toBeInTheDocument();
  });

  it("ignores a withdrawal completion after a role round trip", async () => {
    const draft = sharedDraft("experience-withdraw-round-trip");
    const store = createLearningAssetStore({ drafts: [draft] });
    const resultPreview = store.preview(previewInput(draft));
    if (!resultPreview.ok) throw new Error(resultPreview.code);
    const published = store.publish({ actorId: "sales-demo", preview: resultPreview.preview, consentGranted: true });
    if (!published.ok) throw new Error(published.code);
    const provenance = store.provenanceForAuthor("sales-demo");
    const withdrawal = store.withdraw({ actorId: "sales-demo", assetId: published.asset.id, version: published.asset.version });
    const pending = deferred<LearningWithdrawResult>();
    const panel = (actorId: "sales-demo" | "production-demo") => <ExperiencePanel actorId={actorId}
      workItem={workItem} sources={sources} persistedDrafts={[draft]} learningStore={store}
      learningProvenance={provenance} withdrawLearning={() => pending.promise} />;
    const view = render(panel("sales-demo"));

    fireEvent.click(screen.getByRole("button", { name: "공유 철회" }));
    view.rerender(panel("production-demo"));
    view.rerender(panel("sales-demo"));
    await act(async () => { pending.resolve(withdrawal); });

    expect(screen.queryByText("공유를 철회했습니다.")).not.toBeInTheDocument();
  });
});
