import { CheckCircle2, CircleAlert, Database, Loader2 } from "lucide-react";
import { useSupabaseSession } from "@/hooks/useSupabaseSession";

const toneClass = {
  neutral: "bg-secondary/50 text-muted-foreground",
  warning: "bg-amber-500/10 text-amber-600 dark:text-amber-300",
  success: "bg-status-completed/10 text-status-completed",
  danger: "bg-destructive/10 text-destructive",
};

export function RuntimeConnectionStatus() {
  const { connection, status } = useSupabaseSession();
  const Icon =
    status === "checking"
      ? Loader2
      : connection.tone === "success"
        ? CheckCircle2
        : connection.tone === "danger" || connection.tone === "warning"
          ? CircleAlert
          : Database;

  return (
    <div
      className={`flex min-w-0 items-center gap-1.5 rounded-lg px-2.5 py-1 text-[10px] ${toneClass[connection.tone]}`}
      aria-label={`연결 상태: ${connection.label}, ${connection.detail}`}
    >
      <Icon className={`h-3 w-3 flex-shrink-0 ${status === "checking" ? "animate-spin" : ""}`} />
      <span className="font-medium">{connection.label}</span>
      <span className="hidden max-w-[150px] truncate text-current/70 sm:inline">{connection.detail}</span>
    </div>
  );
}
