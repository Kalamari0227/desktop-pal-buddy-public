import { useEffect, useMemo, useRef, useState } from "react";
import { Database, History, Loader2, RefreshCcw, ShieldAlert, Square, Users } from "lucide-react";
import { z } from "zod";
import {
  companyRuntimeClient,
  type CompanyRuntimeClient,
  type CompanyRuntimeResponse,
} from "@/lib/companyRuntimeClient";
import { useCompanyRuntime } from "@/hooks/useCompanyRuntime";
import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

const statusSchema = z.object({
  epoch: z.string().uuid(),
  actorId: z.enum(["sales-demo", "production-demo", "management-demo"]),
  role: z.enum(["sales", "production", "management"]),
  actorSessionRevision: z.number().int().nonnegative(),
  stopped: z.boolean(),
}).strict();

const snapshotSchema = z.object({
  currentEpoch: z.string().uuid(),
  stopped: z.boolean(),
  history: z.array(z.object({ epoch: z.string().uuid() }).passthrough()).default([]),
}).passthrough();

const runtimeIssueSchema = z.object({ code: z.string(), message: z.string() }).strict();

const roles = [
  { actorId: "sales-demo", role: "sales", label: "영업 역할" },
  { actorId: "production-demo", role: "production", label: "생산 역할" },
  { actorId: "management-demo", role: "management", label: "경영 역할" },
] as const;

type Operation = "role" | "stop" | "resume" | "reset" | "read";

interface CompanyRuntimeControlsProps {
  client?: CompanyRuntimeClient;
}

function failureCopy(issue: { readonly code: string; readonly message: string }): { readonly title: string; readonly detail: string } {
  switch (issue.code) {
    case "persistence_failed":
    case "verification_required":
      return { title: "저장소 오류로 런타임 상태를 변경하지 못했습니다", detail: issue.message };
    case "unavailable":
      return { title: "로컬 런타임을 사용할 수 없습니다", detail: issue.message };
    case "unauthorized_role":
      return { title: "현재 가상 역할에는 이 동작 권한이 없습니다", detail: issue.message };
    case "stale_context":
      return { title: "역할 또는 epoch가 변경되어 이전 응답을 버렸습니다", detail: issue.message };
    default:
      return { title: "런타임 동작을 완료하지 못했습니다", detail: issue.message };
  }
}

function roleLabel(role: "sales" | "production" | "management"): string {
  switch (role) {
    case "sales":
      return "영업 역할";
    case "production":
      return "생산 역할";
    case "management":
      return "경영 역할";
  }
}

export function CompanyRuntimeControls({ client = companyRuntimeClient }: CompanyRuntimeControlsProps) {
  const { state, snapshot, status, error, aiConnection, refreshAiConnection, client: runtimeClient } = useCompanyRuntime(client);
  const [busy, setBusy] = useState<Operation | null>(null);
  const [refreshingConnection, setRefreshingConnection] = useState(false);
  const [notice, setNotice] = useState<{ readonly title: string; readonly detail: string } | null>(null);
  const [resetOpen, setResetOpen] = useState(false);
  const [confirmation, setConfirmation] = useState("");
  const operationGeneration = useRef(0);
  const parsedStatus = useMemo(() => statusSchema.safeParse(status), [status]);
  const parsedSnapshot = useMemo(() => snapshotSchema.safeParse(snapshot), [snapshot]);
  const parsedIssue = useMemo(() => runtimeIssueSchema.safeParse(error), [error]);
  const activeStatus = parsedStatus.success ? parsedStatus.data : null;
  const activeSnapshot = parsedSnapshot.success ? parsedSnapshot.data : null;
  const contextKey = activeStatus
    ? `${activeStatus.epoch}:${activeStatus.actorSessionRevision}:${activeStatus.role}:${activeStatus.stopped}`
    : "unavailable";

  useEffect(() => {
    operationGeneration.current += 1;
    setBusy(null);
  }, [contextKey]);

  const run = async (operation: Operation, request: () => Promise<CompanyRuntimeResponse>) => {
    if (busy || state !== "ready") return;
    const generation = operationGeneration.current + 1;
    operationGeneration.current = generation;
    setBusy(operation);
    setNotice(null);
    const result = await request();
    if (operationGeneration.current !== generation) return;
    setBusy(null);
    if (!result.ok) {
      setNotice(failureCopy(result.error));
      return;
    }
    if (operation === "stop") {
      const readResult = await runtimeClient.read();
      if (operationGeneration.current !== generation) return;
      if (!readResult.ok) setNotice(failureCopy(readResult.error));
    }
  };

  const isReady = state === "ready" && activeStatus !== null && activeSnapshot !== null;
  const canResume = activeStatus?.role === "production" && activeStatus.stopped;
  const canReset = (activeStatus?.role === "production" || activeStatus?.role === "management") && activeStatus.stopped;
  const issue = parsedIssue.success ? failureCopy(parsedIssue.data) : null;
  const connectionCopy = aiConnection.state === "checking"
    ? "AI 연결 확인 중 · 아직 AI를 실행하지 않았습니다"
    : aiConnection.state === "ready"
      ? "AI 연결 준비됨 · 실제 AI 해석 전"
      : "AI 연결을 확인할 수 없음 · AI 해석을 시작하지 않습니다";

  const refreshConnection = async () => {
    if (!refreshAiConnection || refreshingConnection) return;
    setRefreshingConnection(true);
    await refreshAiConnection();
    setRefreshingConnection(false);
  };

  return (
    <section aria-labelledby="company-runtime-heading" className="border-b border-border/50 bg-secondary/10 px-4 py-3 sm:px-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <Database className="h-4 w-4 text-blue-300" aria-hidden="true" />
            <h2 id="company-runtime-heading" className="text-[12px] font-semibold text-foreground">가상 ERP 런타임</h2>
          </div>
          <p className="mt-1 text-[10px] text-muted-foreground">로컬 시뮬레이션 역할이며 실제 기업 인증이나 외부 ERP 연결이 아닙니다.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2 text-[10px]">
          <span className="rounded-md border border-blue-500/20 bg-blue-500/10 px-2 py-1 text-blue-700 dark:text-blue-300">가상 ERP 패널 · 로컬 런타임 상태 제어 전용</span>
          <span className="rounded-md border border-border/50 bg-background px-2 py-1 text-muted-foreground">
            로컬 런타임 연결: {state === "ready" ? "연결됨" : state === "loading" ? "확인 중" : "사용할 수 없음"}
          </span>
          <span className="rounded-md border border-border/50 bg-background px-2 py-1 text-muted-foreground">{connectionCopy}</span>
          <Button type="button" size="sm" variant="outline" className="h-7 px-2 text-[10px] focus-visible:ring-2 focus-visible:ring-blue-400 focus-visible:ring-offset-2" disabled={!refreshAiConnection || refreshingConnection} onClick={() => void refreshConnection()}>
            {refreshingConnection ? "AI 연결 확인 중" : "AI 연결 다시 확인"}
          </Button>
        </div>
      </div>

      {isReady && activeStatus && activeSnapshot ? (
        <div className="mt-3 grid gap-3 xl:grid-cols-[minmax(0,1fr)_auto]">
          <div className="grid gap-3 md:grid-cols-3">
            <section className="rounded-lg border border-border/50 bg-background/70 p-3" aria-label="가상 역할">
              <div className="flex items-center gap-2 text-[10px] font-medium text-muted-foreground"><Users className="h-3.5 w-3.5" aria-hidden="true" />가상 역할</div>
              <p className="mt-2 text-[12px] font-semibold text-foreground">{roleLabel(activeStatus.role)}</p>
              <div className="mt-2 flex flex-wrap gap-1.5">
                {roles.map((candidate) => (
                  <Button
                    key={candidate.actorId}
                    type="button"
                    size="sm"
                    variant={candidate.role === activeStatus.role ? "secondary" : "outline"}
                    aria-pressed={candidate.role === activeStatus.role}
                    disabled={busy !== null}
                    onClick={() => void run("role", () => runtimeClient.role({ actorId: candidate.actorId }))}
                    className="h-7 px-2 text-[10px]"
                  >
                    {candidate.label}로 전환
                  </Button>
                ))}
              </div>
            </section>

            <section className="rounded-lg border border-border/50 bg-background/70 p-3" aria-label="현재 런타임 상태">
              <p className="text-[10px] font-medium text-muted-foreground">현재 epoch</p>
              <p className="mt-2 break-all font-mono text-[10px] text-foreground">{activeSnapshot.currentEpoch}</p>
              <p className="mt-2 text-[11px] font-semibold text-foreground">{activeStatus.stopped ? "중지됨" : "동작 중"}</p>
              <p className="mt-1 text-[10px] text-muted-foreground">중단 사유: {activeStatus.stopped ? "main 런타임이 중지 상태를 보고했습니다. 쓰기는 main에서 차단됩니다." : "없음"}</p>
            </section>

            <section className="rounded-lg border border-border/50 bg-background/70 p-3" aria-label="읽기 전용 epoch 이력">
              <div className="flex items-center gap-2 text-[10px] font-medium text-muted-foreground"><History className="h-3.5 w-3.5" aria-hidden="true" />읽기 전용 이력</div>
              <p className="mt-2 text-[11px] text-foreground">보존된 epoch {activeSnapshot.history.length}개</p>
              {activeSnapshot.history.length > 0 ? (
                <ul className="mt-1 space-y-1 font-mono text-[10px] text-muted-foreground">
                  {activeSnapshot.history.map((entry) => <li key={entry.epoch}>{entry.epoch}</li>)}
                </ul>
              ) : <p className="mt-1 text-[10px] text-muted-foreground">보존된 이전 epoch가 없습니다.</p>}
            </section>
          </div>

          <div className="flex flex-wrap items-center gap-2 xl:max-w-72 xl:justify-end">
            <Button type="button" size="sm" variant="outline" disabled={busy !== null} onClick={() => void run("read", () => runtimeClient.read())}>
              {busy === "read" ? <Loader2 className="animate-spin" aria-hidden="true" /> : <Database aria-hidden="true" />}최신 상태 읽기
            </Button>
            <Button type="button" size="sm" variant="outline" disabled={busy !== null || activeStatus.stopped} onClick={() => void run("stop", () => runtimeClient.stop())}>
              {busy === "stop" ? <Loader2 className="animate-spin" aria-hidden="true" /> : <Square aria-hidden="true" />}런타임 중지
            </Button>
            <Button type="button" size="sm" disabled={busy !== null || !canResume} onClick={() => void run("resume", () => runtimeClient.resume())}>
              {busy === "resume" ? <Loader2 className="animate-spin" aria-hidden="true" /> : <RefreshCcw aria-hidden="true" />}명시적으로 재개
            </Button>
            <Button type="button" size="sm" variant="destructive" disabled={busy !== null || !canReset} onClick={() => setResetOpen(true)}>
              새 epoch로 초기화
            </Button>
          </div>
        </div>
      ) : (
        <RuntimeBlocked issue={issue} />
      )}

      {activeStatus?.stopped && <p className="mt-3 text-[10px] text-muted-foreground">중지된 동안에도 최신 상태 읽기는 사용할 수 있습니다. 자동 재개, 자동 재시도, seed 복구는 수행하지 않습니다.</p>}
      {notice && <RuntimeBlocked issue={notice} />}

      <AlertDialog open={resetOpen} onOpenChange={setResetOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>새 stopped seed epoch로 초기화</AlertDialogTitle>
            <AlertDialogDescription>
              현재 epoch의 기록은 읽기 전용 이력으로 보존합니다. 새 가상 ERP seed는 stopped 상태로 시작하며 자동 재개하지 않습니다. 계속하려면 RESET을 입력하세요.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <label className="grid gap-2 text-sm font-medium text-foreground">
            초기화 확인
            <input aria-label="초기화 확인" value={confirmation} onChange={(event) => setConfirmation(event.target.value)} className="h-10 rounded-md border border-input bg-background px-3 text-sm" />
          </label>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setConfirmation("")}>취소</AlertDialogCancel>
            <AlertDialogAction
              disabled={confirmation !== "RESET" || busy !== null}
              onClick={() => {
                setResetOpen(false);
                setConfirmation("");
                void run("reset", () => runtimeClient.reset({ confirmation: "RESET" }));
              }}
            >
              새 중지된 epoch 초기화
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </section>
  );
}

function RuntimeBlocked({ issue }: { issue: { readonly title: string; readonly detail: string } | null }) {
  return (
    <div role="status" className="mt-3 flex items-start gap-2 rounded-lg border border-amber-500/20 bg-amber-500/10 p-3">
      <ShieldAlert className="mt-0.5 h-4 w-4 flex-none text-amber-300" aria-hidden="true" />
      <div className="text-[11px]">
        <p className="font-semibold text-amber-800 dark:text-amber-200">{issue?.title ?? "런타임 snapshot을 확인할 수 없습니다"}</p>
        <p className="mt-1 text-muted-foreground">{issue?.detail ?? "손상되었거나 사용할 수 없는 상태를 복구하거나 변경하지 않았습니다."}</p>
      </div>
    </div>
  );
}
