import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { WorkspaceChat } from "./WorkspaceChat";

const streamChatMock = vi.hoisted(() => vi.fn());

vi.mock("@/hooks/useInstalledItems", () => ({
  useInstalledItems: () => ({ activeAgents: [] }),
}));

vi.mock("@/lib/streamChat", () => ({
  streamChat: streamChatMock,
}));

describe("WorkspaceChat company-work entry", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    streamChatMock.mockImplementation(async ({ onDone }: { onDone: () => void }) => onDone());
  });

  it("keeps ordinary chat streaming distinct from an explicit company-work draft transfer", async () => {
    const onStartCompanyWork = vi.fn();
    render(<WorkspaceChat onStartCompanyWork={onStartCompanyWork} />);

    const input = screen.getByPlaceholderText("무엇이든 물어보세요...");
    fireEvent.change(input, { target: { value: "SO-DEMO-1001 priority 1" } });
    fireEvent.click(screen.getByRole("button", { name: "회사 업무 시작" }));

    expect(streamChatMock).not.toHaveBeenCalled();
    expect(onStartCompanyWork).toHaveBeenCalledWith("SO-DEMO-1001 priority 1");

    fireEvent.keyDown(input, { key: "Enter" });
    await waitFor(() => expect(streamChatMock).toHaveBeenCalledTimes(1));

    fireEvent.click(screen.getByRole("button", { name: "회사 업무 시작" }));
    expect(onStartCompanyWork).toHaveBeenLastCalledWith("");
  });
});
