import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import {
  AlertTriangle,
  Bot,
  Lightbulb,
  FileText,
  ExternalLink,
} from "lucide-react";
import type { Agent, DockAlert } from "@/types/dock";
import { AgentOrb } from "@/components/dock/AgentOrb";
import { supabase } from "@/integrations/supabase/client";

interface ContextPanelProps {
  agents: Agent[];
  alerts: DockAlert[];
  onModeSelect?: (mode: string, context?: Record<string, string>) => void;
}

export function ContextPanel({ agents, alerts, onModeSelect }: ContextPanelProps) {
  const [recommendedActions, setRecommendedActions] = useState<
    { label: string; priority: string; mode: string; customer?: string }[]
  >([]);

  // Generate recommended actions from DB tasks
  useEffect(() => {
    supabase
      .from("tasks")
      .select("*")
      .neq("status", "done")
      .order("created_at", { ascending: false })
      .limit(10)
      .then(({ data }) => {
        if (!data || data.length === 0) return;
        const actions: { label: string; priority: string; mode: string; customer?: string }[] = [];

        // Find meeting-related tasks
        const meetingTask = data.find((t) => t.category === "delivery" && t.customer);
        if (meetingTask) {
          actions.push({
            label: `${meetingTask.customer} 방문 전 브리핑 생성`,
            priority: meetingTask.severity === "critical" ? "high" : "medium",
            mode: "meeting",
            customer: meetingTask.customer || undefined,
          });
        }

        // Find price-related tasks
        const priceTask = data.find((t) => t.category === "price" && t.customer);
        if (priceTask) {
          actions.push({
            label: `${priceTask.customer} 가격 회신 초안 작성`,
            priority: priceTask.severity === "critical" ? "high" : "medium",
            mode: "response",
            customer: priceTask.customer || undefined,
          });
        }

        // Find quality-related tasks
        const qualityTask = data.find((t) => t.category === "quality");
        if (qualityTask) {
          actions.push({
            label: "품질 이슈 현황 업데이트",
            priority: qualityTask.severity === "critical" || qualityTask.severity === "high" ? "high" : "low",
            mode: "risk",
          });
        }

        // Fallback if no specific tasks found
        if (actions.length === 0) {
          actions.push({ label: "리스크 현황 점검", priority: "medium", mode: "risk" });
        }

        setRecommendedActions(actions.slice(0, 3));
      });
  }, []);

  const handleActionClick = (action: { mode: string; customer?: string }) => {
    if (onModeSelect) {
      onModeSelect(action.mode, action.customer ? { customer: action.customer } : undefined);
    }
  };

  const handleAlertClick = (alert: DockAlert) => {
    if (onModeSelect) {
      onModeSelect("risk", alert.customer ? { customer: alert.customer } : undefined);
    }
  };

  return (
    <div className="hidden xl:flex w-72 h-full flex-col border-l border-border/50 bg-card/50 overflow-y-auto scrollbar-thin">
      <div className="p-4 space-y-5">
        {/* Active Alerts */}
        {alerts.length > 0 && (
          <section>
            <h3 className="text-[10px] font-medium text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <AlertTriangle className="w-3 h-3 text-status-alert" />
              경고
            </h3>
            <div className="space-y-2">
              {alerts.map((alert) => (
                <motion.div
                  key={alert.id}
                  whileHover={{ scale: 1.01 }}
                  onClick={() => handleAlertClick(alert)}
                  className="p-3 rounded-xl bg-status-alert/5 border border-status-alert/15 cursor-pointer"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="text-[12px] font-medium text-foreground">{alert.title}</p>
                      {alert.customer && (
                        <p className="text-[10px] text-muted-foreground mt-0.5">{alert.customer}</p>
                      )}
                    </div>
                    <span
                      className="text-[9px] px-1.5 py-0.5 rounded-full font-medium"
                      style={{
                        background:
                          alert.severity === "high"
                            ? "hsla(var(--status-alert) / 0.15)"
                            : "hsla(var(--status-review) / 0.15)",
                        color:
                          alert.severity === "high"
                            ? "hsl(var(--status-alert))"
                            : "hsl(var(--status-review))",
                      }}
                    >
                      {alert.severity === "high" ? "긴급" : "주의"}
                    </span>
                  </div>
                </motion.div>
              ))}
            </div>
          </section>
        )}

        {/* Agent Status */}
        <section>
          <h3 className="text-[10px] font-medium text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Bot className="w-3 h-3" />
            에이전트 상태
          </h3>
          <div className="flex gap-3 p-3 rounded-xl bg-secondary/30 border border-border/50">
            {agents.map((agent) => (
              <AgentOrb key={agent.id} agent={agent} size="md" />
            ))}
          </div>
        </section>

        {/* Recommended Actions */}
        <section>
          <h3 className="text-[10px] font-medium text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <Lightbulb className="w-3 h-3" />
            추천 액션
          </h3>
          <div className="space-y-1.5">
            {recommendedActions.map((action, i) => (
              <motion.button
                key={i}
                whileHover={{ x: 2 }}
                onClick={() => handleActionClick(action)}
                className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-left hover:bg-secondary/50 transition-colors"
              >
                <div
                  className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                  style={{
                    background:
                      action.priority === "high"
                        ? "hsl(var(--status-alert))"
                        : action.priority === "medium"
                        ? "hsl(var(--status-review))"
                        : "hsl(var(--status-idle))",
                  }}
                />
                <span className="text-[11px] text-secondary-foreground">{action.label}</span>
              </motion.button>
            ))}
          </div>
        </section>

        {/* Recent Sources — kept as static for now */}
        <section>
          <h3 className="text-[10px] font-medium text-muted-foreground uppercase tracking-wider mb-2 flex items-center gap-1.5">
            <FileText className="w-3 h-3" />
            최근 문서
          </h3>
          <div className="space-y-1">
            {[
              { title: "2026년 1분기 판매 실적 보고", date: "3월 5일" },
              { title: "H사 품질 회의록", date: "3월 4일" },
              { title: "K사 가격 협의 메일", date: "3월 3일" },
              { title: "T사 납기 조정 요청", date: "3월 2일" },
            ].map((source, i) => (
              <motion.button
                key={i}
                whileHover={{ x: 2 }}
                onClick={() => onModeSelect?.("search")}
                className="w-full flex items-center justify-between px-3 py-2 rounded-xl text-left hover:bg-secondary/50 transition-colors group"
              >
                <div>
                  <p className="text-[11px] text-secondary-foreground truncate max-w-[180px]">
                    {source.title}
                  </p>
                  <p className="text-[9px] text-muted-foreground mt-0.5">{source.date}</p>
                </div>
                <ExternalLink className="w-3 h-3 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
              </motion.button>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
