import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import type { ActorId, ActorRole } from "@/lib/company-runtime";
import type { ExperienceDraft } from "@/lib/company-runtime/experience";
import type {
  LearningAssetStore,
  LearningPreview,
  LearningPreviewResult,
  LearningProvenance,
  LearningPublishResult,
  LearningWithdrawResult,
} from "@/lib/company-runtime/learning";

interface ExperienceSharingPanelProps {
  readonly actorId: ActorId;
  readonly draft?: ExperienceDraft;
  readonly store?: LearningAssetStore;
  readonly preview?: (input: unknown) => Promise<LearningPreviewResult>;
  readonly publish?: (input: unknown) => Promise<LearningPublishResult>;
  readonly withdraw?: (input: unknown) => Promise<LearningWithdrawResult>;
  readonly provenance: readonly LearningProvenance[];
  readonly onNotice: (notice: string | null) => void;
}

const DEPARTMENTS: readonly ActorRole[] = ["sales", "production", "management"];
const label = (department: ActorRole) => department === "sales" ? "영업" : department === "production" ? "생산" : "경영";

export function ExperienceSharingPanel({
  actorId,
  draft,
  store,
  preview,
  publish,
  withdraw,
  provenance,
  onNotice,
}: ExperienceSharingPanelProps) {
  const generation = useRef(0);
  const [learningPreview, setLearningPreview] = useState<LearningPreview | null>(null);
  const [includeManagementReview, setIncludeManagementReview] = useState(true);
  const [targetDepartments, setTargetDepartments] = useState<readonly ActorRole[]>(["production"]);

  useEffect(() => {
    generation.current += 1;
    setLearningPreview(null);
    setIncludeManagementReview(true);
    setTargetDepartments(["production"]);
  }, [actorId, draft?.id]);

  const invalidatePreview = () => {
    generation.current += 1;
    setLearningPreview(null);
  };

  const previewShare = async () => {
    if (!draft || (!store && !preview)) return;
    const requestGeneration = ++generation.current;
    const input = {
      actorId,
      draftId: draft.id,
      exactPublishableSentence: draft.correction,
      applicability: draft.applicability,
      targetDepartments,
      includeManagementStrategyReview: includeManagementReview,
    };
    const result = preview ? await preview(input) : store?.preview(input);
    if (requestGeneration !== generation.current) return;
    if (!result?.ok) {
      onNotice(`미리보기를 만들지 못했습니다: ${result?.code ?? "unavailable"}`);
      return;
    }
    setLearningPreview(result.preview);
    onNotice(null);
  };

  const publishShare = async () => {
    if (!learningPreview || (!store && !publish)) return;
    const requestGeneration = ++generation.current;
    const input = { actorId, preview: learningPreview, consentGranted: true };
    const result = publish ? await publish(input) : store?.publish(input);
    if (requestGeneration !== generation.current) return;
    if (!result?.ok) {
      onNotice(`게시하지 못했습니다: ${result?.code ?? "unavailable"}`);
      return;
    }
    setLearningPreview(null);
    onNotice("동의한 범위로 게시했습니다.");
  };

  const withdrawShare = async (assetId: string, version: number) => {
    if (!withdraw) return;
    const requestGeneration = ++generation.current;
    const result = await withdraw({ actorId, assetId, version });
    if (requestGeneration !== generation.current) return;
    onNotice(result.ok ? "공유를 철회했습니다." : `철회하지 못했습니다: ${result.code}`);
  };

  return <>
    {draft && (store || preview) && (
      <div className="space-y-2 rounded-md border border-border/40 p-2">
        <p className="font-medium text-foreground">학습 공유 동의</p>
        <p className="text-muted-foreground">실행 승인과 별개이며, 미리 본 문장과 범위에만 동의합니다.</p>
        <fieldset className="flex flex-wrap gap-3">
          <legend className="sr-only">대상 부서</legend>
          {DEPARTMENTS.map((department) => (
            <label key={department}>
              <input
                type="checkbox"
                checked={targetDepartments.includes(department)}
                onChange={(event) => {
                  invalidatePreview();
                  setTargetDepartments((current) => event.target.checked
                    ? [...current, department]
                    : current.filter((value) => value !== department));
                }}
              /> {label(department)}
            </label>
          ))}
        </fieldset>
        <label className="flex items-center gap-2">
          <input
            type="checkbox"
            checked={includeManagementReview}
            onChange={(event) => { invalidatePreview(); setIncludeManagementReview(event.target.checked); }}
          /> 경영 전략 검토 포함
        </label>
        <Button type="button" size="sm" variant="outline" onClick={() => void previewShare()}>공유 미리보기</Button>
        {learningPreview && (
          <div aria-label="학습 게시 미리보기" className="space-y-1 rounded-md bg-muted/40 p-2">
            <p><span className="font-medium">게시 문장</span> · {learningPreview.exactPublishableSentence}</p>
            <p><span className="font-medium">출처</span> · {learningPreview.sourceEvidenceIds.join(", ")}</p>
            <p><span className="font-medium">적용 조건</span> · {learningPreview.applicability.join(", ")}</p>
            <p><span className="font-medium">대상 부서</span> · {learningPreview.targetDepartments.map(label).join(", ")}</p>
            <p>{learningPreview.includeManagementStrategyReview ? "경영 전략 검토 포함" : "경영 전략 검토 제외"}</p>
            <Button type="button" size="sm" onClick={() => void publishShare()}>동의하고 게시</Button>
          </div>
        )}
      </div>
    )}
    {provenance.some((item) => !item.withdrawn) && (
      <div className="space-y-2 rounded-md border border-border/40 p-2">
        <p className="font-medium text-foreground">게시한 학습</p>
        {provenance.filter((item) => !item.withdrawn).map((item) => (
          <div key={`${item.id}:${item.version}`} className="flex items-center justify-between gap-2">
            <span>{item.id} · v{item.version}</span>
            <Button type="button" size="sm" variant="outline" onClick={() => void withdrawShare(item.id, item.version)}>공유 철회</Button>
          </div>
        ))}
      </div>
    )}
  </>;
}
