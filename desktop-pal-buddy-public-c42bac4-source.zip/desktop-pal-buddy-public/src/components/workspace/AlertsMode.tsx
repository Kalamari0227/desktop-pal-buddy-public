import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { ArrowLeft, AlertTriangle, Bell, BellOff, Clock } from "lucide-react";
import { toast } from "sonner";
import { useAlertsData } from "@/hooks/useAlertsData";

interface AlertsModeProps {
  onBack: () => void;
  onDismissChange?: (dismissedIds: Set<string>) => void;
}

const severityConfig: Record<string, { label: string; color: string; bg: string }> = {
  critical: { label: "심각", color: "hsl(var(--status-alert))", bg: "hsl(var(--status-alert) / 0.1)" },
  high: { label: "높음", color: "hsl(var(--status-review))", bg: "hsl(var(--status-review) / 0.1)" },
  medium: { label: "보통", color: "hsl(var(--status-review))", bg: "hsl(var(--status-review) / 0.05)" },
  low: { label: "낮음", color: "hsl(var(--status-completed))", bg: "hsl(var(--status-completed) / 0.1)" },
};

const categoryLabels: Record<string, string> = { delivery: "납기", quality: "품질", price: "가격" };

export function AlertsMode({ onBack, onDismissChange }: AlertsModeProps) {
  const { alerts, dismissedIds: dismissed, isLoading, dismissAlert, restoreAlert, isUpdatingDismissal } = useAlertsData();
  const [filter, setFilter] = useState<"all" | "active" | "dismissed">("all");

  useEffect(() => {
    onDismissChange?.(dismissed);
  }, [dismissed, onDismissChange]);

  const filteredAlerts = alerts.filter((a) => {
    if (filter === "active") return !dismissed.has(a.id);
    if (filter === "dismissed") return dismissed.has(a.id);
    return true;
  });

  const activeCount = alerts.filter((a) => !dismissed.has(a.id)).length;

  const handleDismiss = async (id: string) => {
    const isDismissed = dismissed.has(id);
    try {
      if (isDismissed) await restoreAlert(id);
      else await dismissAlert(id);
    } catch {
      toast.error("알림 상태를 바꾸지 못했습니다");
    }
  };

  const timeSince = (dateStr: string) => {
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 60) return `${mins}분 전`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours}시간 전`;
    return `${Math.floor(hours / 24)}일 전`;
  };

  return (
    <div className="flex-1 h-full overflow-y-auto p-6 space-y-6 scrollbar-thin">
      <div className="flex items-center gap-3">
        <button onClick={onBack} className="p-1.5 rounded-lg hover:bg-secondary transition-colors">
          <ArrowLeft className="w-4 h-4 text-muted-foreground" />
        </button>
        <div>
          <h1 className="text-xl font-semibold tracking-tight">알림 센터</h1>
          <p className="text-[13px] text-muted-foreground mt-0.5">리스크 및 이슈 알림 관리</p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "활성 알림", value: `${activeCount}건`, color: activeCount > 0 ? "hsl(var(--status-alert))" : "hsl(var(--status-completed))" },
          { label: "심각 알림", value: `${alerts.filter(a => a.severity === "critical" && !dismissed.has(a.id)).length}건`, color: "hsl(var(--status-alert))" },
          { label: "처리 완료", value: `${dismissed.size}건`, color: "hsl(var(--status-completed))" },
        ].map((stat, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            className="p-4 rounded-2xl bg-secondary/20 border border-border/30"
          >
            <p className="text-[10px] text-muted-foreground">{stat.label}</p>
            <p className="text-lg font-semibold mt-1 font-mono" style={{ color: stat.color }}>{stat.value}</p>
          </motion.div>
        ))}
      </div>

      {/* Filter */}
      <div className="flex gap-2">
        {[
          { key: "all" as const, label: `전체 ${alerts.length}` },
          { key: "active" as const, label: `활성 ${activeCount}` },
          { key: "dismissed" as const, label: `처리됨 ${dismissed.size}` },
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => setFilter(tab.key)}
            className={`px-3 py-1.5 rounded-lg text-[11px] font-medium transition-colors ${
              filter === tab.key ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-secondary"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Alert list */}
      <div className="space-y-2">
        {isLoading ? (
          <div className="text-center py-12">
            <Bell className="w-8 h-8 text-muted-foreground/30 mx-auto mb-2" />
            <p className="text-[12px] text-muted-foreground">알림을 불러오는 중입니다</p>
          </div>
        ) : filteredAlerts.length === 0 ? (
          <div className="text-center py-12">
            <Bell className="w-8 h-8 text-muted-foreground/30 mx-auto mb-2" />
            <p className="text-[12px] text-muted-foreground">알림이 없습니다</p>
          </div>
        ) : (
          filteredAlerts.map((alert, i) => {
            const sev = severityConfig[alert.severity] || severityConfig.medium;
            const isDismissed = dismissed.has(alert.id);
            return (
              <motion.div
                key={alert.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.03 }}
                className={`p-4 rounded-xl border transition-colors ${
                  isDismissed
                    ? "bg-secondary/10 border-border/20 opacity-60"
                    : "bg-secondary/20 border-border/30 hover:border-border/60"
                }`}
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3">
                    <div className="mt-0.5">
                      <AlertTriangle className="w-4 h-4" style={{ color: sev.color }} />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-[9px] px-1.5 py-0.5 rounded font-medium" style={{ background: sev.bg, color: sev.color }}>
                          {sev.label}
                        </span>
                        {alert.category && (
                          <span className="text-[9px] px-1.5 py-0.5 rounded bg-muted/50 text-muted-foreground">
                            {categoryLabels[alert.category] || alert.category}
                          </span>
                        )}
                        {alert.customer && (
                          <span className="text-[9px] text-muted-foreground">{alert.customer}</span>
                        )}
                      </div>
                      <p className="text-[12px] font-medium text-foreground">{alert.title}</p>
                      {alert.description && (
                        <p className="text-[11px] text-muted-foreground mt-1 line-clamp-2">{alert.description}</p>
                      )}
                      <div className="flex items-center gap-2 mt-2">
                        <Clock className="w-3 h-3 text-muted-foreground" />
                        <span className="text-[9px] text-muted-foreground">{timeSince(alert.createdAt)}</span>
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => handleDismiss(alert.id)}
                    disabled={isUpdatingDismissal}
                    className="p-1.5 rounded-lg hover:bg-secondary transition-colors flex-shrink-0"
                    title={isDismissed ? "다시 활성화" : "처리 완료"}
                  >
                    {isDismissed ? (
                      <Bell className="w-3.5 h-3.5 text-muted-foreground" />
                    ) : (
                      <BellOff className="w-3.5 h-3.5 text-muted-foreground" />
                    )}
                  </button>
                </div>
              </motion.div>
            );
          })
        )}
      </div>
    </div>
  );
}
