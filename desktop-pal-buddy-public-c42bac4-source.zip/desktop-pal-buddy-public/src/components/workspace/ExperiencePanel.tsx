import { useEffect, useState } from "react";
import {
  createExperienceDraftStore,
  type ExperienceDraft,
  type ExperienceDraftSaveResult,
  type ExperienceDraftStore,
  type ExperienceSource,
  type ExperienceWorkItem,
} from "@/lib/company-runtime/experience";
import type { ActorId } from "@/lib/company-runtime";
import type { LearningAssetStore, LearningPreviewResult, LearningProvenance, LearningPublishResult, LearningWithdrawResult } from "@/lib/company-runtime/learning";
import { Button } from "@/components/ui/button";
import { ExperienceSharingPanel } from "./ExperienceSharingPanel";

interface ExperiencePanelProps {
  readonly actorId: ActorId;
  readonly workItem: ExperienceWorkItem;
  readonly sources: readonly ExperienceSource[];
  readonly store?: ExperienceDraftStore;
  readonly persistedDrafts?: readonly ExperienceDraft[];
  readonly saveDraft?: (input: unknown) => Promise<ExperienceDraftSaveResult>;
  readonly learningStore?: LearningAssetStore;
  readonly previewLearning?: (input: unknown) => Promise<LearningPreviewResult>;
  readonly publishLearning?: (input: unknown) => Promise<LearningPublishResult>;
  readonly withdrawLearning?: (input: unknown) => Promise<LearningWithdrawResult>;
  readonly learningProvenance?: readonly LearningProvenance[];
}

type DraftOutcome = "unobserved" | "observed";

function selectedAsset(
  sources: readonly ExperienceSource[],
  selectedSourceIds: readonly string[],
  outcome: DraftOutcome,
): { readonly id: string; readonly version: number } | null {
  const selectedSources = sources.filter((source) => selectedSourceIds.includes(source.evidenceId));
  const source = outcome === "observed"
    ? selectedSources.find((candidate) => candidate.kind === "readback")
    : selectedSources[0];
  return source ? source.asset : null;
}

export function ExperiencePanel({
  actorId,
  workItem,
  sources,
  store,
  persistedDrafts = [],
  saveDraft,
  learningStore,
  previewLearning,
  publishLearning,
  withdrawLearning,
  learningProvenance = [],
}: ExperiencePanelProps) {
  const [fallbackStore] = useState(() => createExperienceDraftStore({ sources }));
  const draftStore = store ?? fallbackStore;
  const [isWriting, setIsWriting] = useState(false);
  const [correction, setCorrection] = useState("");
  const [applicability, setApplicability] = useState("");
  const [counterexample, setCounterexample] = useState("");
  const [outcome, setOutcome] = useState<DraftOutcome>("unobserved");
  const [notice, setNotice] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [selectedSourceIds, setSelectedSourceIds] = useState<readonly string[]>([]);
  const authorDrafts = persistedDrafts.filter((draft) => draft.authorActorId === actorId);
  const shareDraft = authorDrafts[authorDrafts.length - 1];

  useEffect(() => {
    setIsWriting(false);
    setCorrection("");
    setApplicability("");
    setCounterexample("");
    setOutcome("unobserved");
    setNotice(null);
    setIsSaving(false);
    setSelectedSourceIds([]);
  }, [actorId]);

  const begin = () => {
    setIsWriting(true);
    setNotice(null);
    setSelectedSourceIds(sources.map((source) => source.evidenceId));
  };

  const discard = () => {
    draftStore.discard({ authorActorId: actorId, workItem });
    setIsWriting(false);
    setCorrection("");
    setApplicability("");
    setCounterexample("");
    setOutcome("unobserved");
    setSelectedSourceIds([]);
    setNotice("입력을 저장하지 않았습니다.");
  };

  const save = async (saveDecision: "private" | "shared_review") => {
    const asset = selectedAsset(sources, selectedSourceIds, outcome);
    if (!asset) {
      setNotice("저장할 업무 증거가 없습니다.");
      return;
    }
    const input = {
      authorActorId: actorId,
      workItem,
      sourceEvidenceIds: selectedSourceIds,
      asset,
      correction,
      applicability: applicability.split("\n").map((value) => value.trim()).filter(Boolean),
      counterexample,
      outcome: outcome === "unobserved"
        ? { state: "unobserved" }
        : { state: "observed", observedAt: "2026-09-19T00:00:00.000Z" },
      saveDecision,
    };
    setIsSaving(true);
    const result = saveDraft ? await saveDraft(input) : draftStore.save(input);
    setIsSaving(false);
    if (!result.ok) {
      setNotice(`저장하지 못했습니다: ${result.code}`);
      return;
    }
    setIsWriting(false);
    setCorrection("");
    setApplicability("");
    setCounterexample("");
    setOutcome("unobserved");
    setSelectedSourceIds([]);
    setNotice(saveDecision === "private" ? "개인 초안을 보관했습니다." : "공유 검토 요청을 개인 초안으로 보관했습니다.");
  };

  return (
    <section aria-labelledby="experience-heading" className="space-y-3 rounded-lg border border-border/40 bg-background/50 p-3 text-[11px]">
      <div>
        <h4 id="experience-heading" className="font-semibold">직원 경험 초안</h4>
        <p className="mt-1 text-muted-foreground">직원 판단 보완은 업무 사실·정책·전략·실행 권한과 분리됩니다. 개인 행동 기록을 수집하지 않습니다.</p>
        <p className="mt-1 text-muted-foreground">보관된 개인 초안 {store ? draftStore.listForActor(actorId).length : persistedDrafts.length}개</p>
      </div>
      {!isWriting ? (
        <Button type="button" size="sm" variant="outline" onClick={begin}>경험 작성</Button>
      ) : (
        <div className="space-y-3">
          <div aria-label="업무 증거" className="rounded-md border border-border/40 p-2 text-muted-foreground">
            <p className="font-medium text-foreground">업무 증거</p>
            {sources.length === 0 ? <p className="mt-1">연결된 증거가 없습니다.</p> : sources.map((source) => (
              <label key={source.evidenceId} className="mt-1 flex items-center gap-2">
                <input
                  type="checkbox"
                  checked={selectedSourceIds.includes(source.evidenceId)}
                  onChange={(event) => setSelectedSourceIds((current) => event.target.checked
                    ? [...current, source.evidenceId]
                    : current.filter((evidenceId) => evidenceId !== source.evidenceId))}
                />
                {source.kind === "work_fact" ? "업무 사실" : "재조회 증거"} · {source.evidenceId} · {source.asset.id}/v{source.asset.version}
              </label>
            ))}
          </div>
          <p className="font-medium text-foreground">직원 판단 보완</p>
          <label className="grid gap-1">판단 보완<textarea aria-label="판단 보완" value={correction} onChange={(event) => setCorrection(event.target.value)} className="min-h-16 rounded-md border border-input bg-background p-2" /></label>
          <label className="grid gap-1">적용 조건<textarea aria-label="적용 조건" value={applicability} onChange={(event) => setApplicability(event.target.value)} className="min-h-12 rounded-md border border-input bg-background p-2" /></label>
          <label className="grid gap-1">반례<textarea aria-label="반례" value={counterexample} onChange={(event) => setCounterexample(event.target.value)} className="min-h-12 rounded-md border border-input bg-background p-2" /></label>
          <fieldset className="space-y-1">
            <legend className="font-medium">결과 상태</legend>
            <label className="mr-3"><input type="radio" name="experience-outcome" checked={outcome === "unobserved"} onChange={() => setOutcome("unobserved")} /> 결과 미관찰</label>
            <label><input type="radio" name="experience-outcome" checked={outcome === "observed"} onChange={() => setOutcome("observed")} /> 재조회 증거로 관찰</label>
          </fieldset>
          <p className="text-muted-foreground">기본 선택: 나만 보관 · 공유 검토는 Task17 전까지 팀 검색에 공개되지 않습니다.</p>
          <div className="flex flex-wrap gap-2">
            <Button type="button" size="sm" disabled={isSaving} onClick={() => void save("private")}>{isSaving ? "보관 중" : "나만 보관"}</Button>
            <Button type="button" size="sm" variant="outline" disabled={isSaving} onClick={() => void save("shared_review")}>공유 검토</Button>
            <Button type="button" size="sm" variant="ghost" disabled={isSaving} onClick={discard}>저장하지 않음</Button>
          </div>
        </div>
      )}
      <ExperienceSharingPanel
        actorId={actorId}
        draft={shareDraft}
        store={learningStore}
        preview={previewLearning}
        publish={publishLearning}
        withdraw={withdrawLearning}
        provenance={learningProvenance}
        onNotice={setNotice}
      />
      {notice && <p role="status" className="text-muted-foreground">{notice}</p>}
    </section>
  );
}
