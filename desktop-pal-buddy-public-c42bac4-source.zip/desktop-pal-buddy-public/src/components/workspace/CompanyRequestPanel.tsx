import { useEffect, useMemo, useRef, useState } from "react";
import { Bot, Loader2, Square, Workflow } from "lucide-react";
import { z } from "zod";
import {
  assessOrderPriority,
  companyStateSchema,
  type PriorityAssessment,
} from "@/lib/company-runtime";
import {
  companyRuntimeClient,
  type CompanyRuntimeClient,
  type CompanyRuntimeResponse,
} from "@/lib/companyRuntimeClient";
import { useCompanyRuntime } from "@/hooks/useCompanyRuntime";

interface CompanyRequestPanelProps {
  client?: CompanyRuntimeClient;
  onOpenTasks?: (taskId?: string) => void;
  companyDraft?: { id: string; text: string };
  onCompanyDraftChange?: (draft: { id: string; text: string }) => void;
}

const statusSchema = z.object({
  epoch: z.string().uuid(),
  actorId: z.string(),
  role: z.string(),
  actorSessionRevision: z.number().int().nonnegative(),
  stopped: z.boolean(),
}).passthrough();

const snapshotSchema = z.object({
  current: companyStateSchema,
}).passthrough();

const interpretationSchema = z.object({
  intent: z.string(),
  targetIds: z.array(z.string()).default([]),
  requestedPriority: z.number().int().min(1).max(9).optional(),
  clarificationQuestions: z.array(z.string()).default([]),
}).passthrough();

const clarificationPayloadSchema = z.object({
  interpretation: interpretationSchema,
  clarificationRequired: z.literal(true),
  runtimeMode: z.string(),
  actualAI: z.boolean(),
}).passthrough();

const proposalPayloadSchema = z.object({
  interpretation: interpretationSchema,
  task: z.object({ workboardTaskId: z.string().uuid() }).passthrough(),
  proposal: z.object({
    intent: z.object({
      targetPlanId: z.string(),
      fromPriority: z.number().int(),
      toPriority: z.number().int(),
    }).passthrough(),
    shadow: z.object({
      diff: z.object({
        priority: z.object({ before: z.number().int(), after: z.number().int() }).strict(),
      }).passthrough(),
      mutationCount: z.literal(0),
    }).passthrough(),
  }).passthrough(),
  runtimeMode: z.string(),
  actualAI: z.boolean(),
}).passthrough();

const readinessPayloadSchema = z.object({
  task: z.object({ workboardTaskId: z.string().uuid(), status: z.string() }).passthrough(),
  assessment: z.object({
    finding: z.literal("needs_review"),
    requiredChecks: z.array(z.enum(["inspection", "packaging"])),
    usedAssetRef: z.object({ assetId: z.string(), version: z.number().int().positive() }).strict().nullable(),
    additionalReadSet: z.array(z.object({ kind: z.string(), id: z.string(), version: z.number().int().positive() }).strict()),
    reuse: z.object({ status: z.enum(["baseline", "selected", "no_candidate", "needs_review"]), code: z.string().nullable() }).passthrough(),
  }).passthrough(),
}).passthrough();

type ReadinessView = z.infer<typeof readinessPayloadSchema>;

type ViewState =
  | { kind: "idle" }
  | { kind: "submitting" }
  | { kind: "canceled" }
  | { kind: "clarification"; questions: string[]; runtimeMode: string; actualAI: boolean }
  | { kind: "failed"; title: string; detail: string }
  | {
      kind: "proposed";
      workboardTaskId: string;
      fromPriority: number;
      toPriority: number;
      runtimeMode: string;
      actualAI: boolean;
      assessment: ProposedAssessment;
    };

type ProposedAssessment = PriorityAssessment & { status: "proposed" };

function isProposedAssessment(value: PriorityAssessment): value is ProposedAssessment {
  return value.status === "proposed";
}

function failureCopy(error: { code: string; message: string }): { title: string; detail: string } {
  switch (error.code) {
    case "unavailable":
    case "adapter_unproven":
      return { title: "회사 런타임을 사용할 수 없습니다", detail: "연결 상태를 확인한 뒤 요청을 직접 다시 제출해 주세요." };
    case "stopped":
      return { title: "회사 런타임이 중지되었습니다", detail: "관리자가 런타임을 재개한 뒤 요청을 직접 다시 제출해 주세요." };
    case "stale_context":
      return { title: "작업 맥락이 변경되었습니다", detail: "최신 역할과 회사 자료를 확인한 뒤 요청을 직접 다시 제출해 주세요." };
    case "ai_failed":
      return { title: "AI 해석에 실패했습니다", detail: "입력 내용은 유지되었습니다. 연결을 확인하고 필요할 때 직접 다시 제출해 주세요." };
    case "invalid_input": {
      if (["missing_sales_order", "interpretation_target_missing", "unknown_order"].includes(error.message)) {
        return { title: "주문을 찾을 수 없습니다", detail: "main 회사 자료에서 주문을 확인한 뒤 정확한 주문 ID로 직접 다시 제출해 주세요." };
      }
      if (["quality_hold", "plan_not_queued", "insufficient_inventory"].includes(error.message)) {
        return { title: "요청이 정책 검토에서 차단되었습니다", detail: `회사 자료의 차단 사유를 먼저 해결해야 합니다. (${error.message})` };
      }
      return { title: "확인 가능한 정보가 부족합니다", detail: `실행 가능한 제안은 만들지 않았습니다. (${error.message})` };
    }
    default:
      return { title: "요청을 검토하지 못했습니다", detail: error.message };
  }
}

function isActualAI(runtimeMode: string, actualAI: boolean): boolean {
  return actualAI && !["stub", "unavailable", "adapter_unproven"].includes(runtimeMode);
}

function RuntimeLabel({ runtimeMode, actualAI }: { runtimeMode?: string; actualAI?: boolean }) {
  const verifiedActualAI = runtimeMode ? isActualAI(runtimeMode, actualAI === true) : false;
  const label = runtimeMode === "stub"
    ? "결정론적 Stub · 실제 AI 아님"
    : verifiedActualAI
      ? "호스트 검증 실제 AI"
      : "호스트 확인 전 · 실제 AI 아님";
  return (
    <div className="flex flex-wrap gap-2 text-[10px]">
      <span className="rounded-md border border-blue-500/20 bg-blue-500/10 px-2 py-1 text-blue-300">가상 ERP</span>
      <span className="rounded-md border border-border/40 bg-background px-2 py-1 text-muted-foreground">{label}</span>
    </div>
  );
}

export function CompanyRequestPanel({
  client = companyRuntimeClient,
  onOpenTasks,
  companyDraft,
  onCompanyDraftChange,
}: CompanyRequestPanelProps) {
  const { state: runtimeState, snapshot, status, aiConnection, client: runtimeClient } = useCompanyRuntime(client);
  const [requestText, setRequestText] = useState("");
  const [view, setView] = useState<ViewState>({ kind: "idle" });
  const [readinessView, setReadinessView] = useState<ReadinessView | null>(null);
  const [readinessPending, setReadinessPending] = useState(false);
  const requestGeneration = useRef(0);
  const appliedCompanyDraftIds = useRef(new Set<string>());
  const parsedSnapshot = useMemo(() => snapshotSchema.safeParse(snapshot), [snapshot]);
  const parsedStatus = useMemo(() => statusSchema.safeParse(status), [status]);
  const companyState = parsedSnapshot.success ? parsedSnapshot.data.current : null;
  const activeStrategy = companyState?.strategyVersions.find((candidate) =>
    candidate.strategy_id === companyState.activeStrategyRef.strategy_id
    && candidate.strategy_version_id === companyState.activeStrategyRef.strategy_version_id);

  const contextKey = parsedStatus.success
    ? `${parsedStatus.data.epoch}:${parsedStatus.data.actorSessionRevision}:${parsedStatus.data.role}`
    : "unavailable";

  useEffect(() => {
    requestGeneration.current += 1;
    setReadinessView(null);
    setReadinessPending(false);
    setView((current) => current.kind === "submitting" ? {
      kind: "failed",
      title: "작업 맥락이 변경되었습니다",
      detail: "최신 역할과 회사 자료를 확인한 뒤 요청을 직접 다시 제출해 주세요.",
    } : current);
  }, [contextKey]);

  useEffect(() => {
    if (!companyDraft || appliedCompanyDraftIds.current.has(companyDraft.id)) return;
    appliedCompanyDraftIds.current.add(companyDraft.id);
    setRequestText(companyDraft.text);
  }, [companyDraft]);

  const submit = async () => {
    const trimmed = requestText.trim();
    if (!trimmed || !companyState || parsedStatus.data?.stopped) return;
    const generation = requestGeneration.current + 1;
    requestGeneration.current = generation;
    setView({ kind: "submitting" });
    const response = await runtimeClient.submit({ requestText: trimmed });
    if (requestGeneration.current !== generation) return;
    applyResponse(response, companyState, setView);
  };

  const cancel = async () => {
    requestGeneration.current += 1;
    setView({ kind: "canceled" });
    await runtimeClient.cancel();
  };

  const reviewReadiness = async (useLatestLearning: boolean) => {
    if (!parsedStatus.success || parsedStatus.data.role !== "production" || parsedStatus.data.stopped) return;
    if (!runtimeClient.reviewReadiness) return;
    setReadinessPending(true);
    const response = await runtimeClient.reviewReadiness({ useLatestLearning });
    setReadinessPending(false);
    if (!response.ok) {
      setView({ kind: "failed", ...failureCopy(response.error) });
      return;
    }
    const parsed = readinessPayloadSchema.safeParse(response.payload);
    if (!parsed.success) {
      setView({ kind: "failed", title: "준비 상태를 읽지 못했습니다", detail: "호스트 응답이 읽기 전용 준비 검토 형식이 아닙니다." });
      return;
    }
    setReadinessView(parsed.data);
  };

  const runtimeMode = view.kind === "proposed" || view.kind === "clarification" ? view.runtimeMode : undefined;
  const actualAI = view.kind === "proposed" || view.kind === "clarification" ? view.actualAI : undefined;
  const connectionCopy = aiConnection.state === "ready"
    ? "AI 연결 준비됨 · 실제 AI 해석 전"
    : aiConnection.state === "checking"
      ? "AI 연결 확인 중 · 아직 AI를 실행하지 않았습니다"
      : "AI 연결을 확인할 수 없습니다 · 실제 AI 해석 전";
  const nextAction = parsedStatus.data?.stopped
    ? "다음 행동: 생산 역할에서 런타임을 재개한 뒤 직접 검토하세요."
    : aiConnection.state === "unavailable"
      ? "다음 행동: AI 연결을 다시 확인한 뒤 직접 검토하세요."
      : !requestText.trim()
        ? "다음 행동: 회사 요청을 입력한 뒤 직접 검토하세요."
        : "다음 행동: 회사 요청을 직접 검토하세요.";

  return (
    <section aria-labelledby="company-request-heading" className="rounded-xl border border-blue-500/20 bg-blue-500/5 p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <Bot className="h-4 w-4 text-blue-300" aria-hidden="true" />
            <h2 id="company-request-heading" className="text-sm font-semibold text-foreground">회사 요청</h2>
          </div>
          <p className="mt-1 text-[11px] text-muted-foreground">main 회사 자료에 근거해 후보와 Shadow 변경만 준비합니다.</p>
        </div>
        <RuntimeLabel runtimeMode={runtimeMode} actualAI={actualAI} />
      </div>

      <p className="mt-2 text-[10px] text-muted-foreground">{connectionCopy}</p>
      <p className="mt-1 text-[10px] font-medium text-foreground">{nextAction}</p>

      <div className="mt-4 grid gap-3">
        <label className="space-y-1 text-[10px] text-muted-foreground">
          회사 요청
          <textarea
            aria-label="회사 요청"
            value={requestText}
            onChange={(event) => {
              const text = event.target.value;
              setRequestText(text);
              if (companyDraft) onCompanyDraftChange?.({ ...companyDraft, text });
            }}
            placeholder="예: 주문 1001 생산 우선순위를 1로 올려줘"
            className="min-h-24 w-full resize-y rounded-lg border border-border/40 bg-background px-3 py-2 text-[12px] text-foreground outline-none focus:border-blue-500/50"
          />
        </label>
        <label className="space-y-1 text-[10px] text-muted-foreground">
          전략 버전
          <select
            aria-label="회사 전략 버전"
            value={activeStrategy?.strategy_version_id ?? ""}
            disabled
            className="h-9 w-full rounded-lg border border-border/40 bg-background px-2 text-[11px] text-foreground disabled:opacity-80"
          >
            {activeStrategy ? (
              <option value={activeStrategy.strategy_version_id}>
                {activeStrategy.strategy_id} · v{activeStrategy.version}
              </option>
            ) : <option value="">전략 확인 중</option>}
          </select>
          <span className="block leading-relaxed">main snapshot의 활성 버전에 고정됩니다.</span>
        </label>
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-2">
        {view.kind === "submitting" ? (
          <button type="button" onClick={() => void cancel()} className="inline-flex h-9 items-center gap-2 rounded-lg border border-border/50 bg-background px-3 text-[11px] font-medium text-foreground">
            <Square className="h-3.5 w-3.5" aria-hidden="true" /> 검토 취소
          </button>
        ) : (
          <button
            type="button"
            onClick={() => void submit()}
            disabled={!requestText.trim() || runtimeState !== "ready" || !companyState || parsedStatus.data?.stopped}
            className="inline-flex h-9 items-center gap-2 rounded-lg bg-blue-500 px-3 text-[11px] font-semibold text-white disabled:cursor-not-allowed disabled:opacity-50"
          >
            <Workflow className="h-3.5 w-3.5" aria-hidden="true" /> 회사 요청 검토
          </button>
        )}
        {runtimeState === "unavailable" && <p className="text-[11px] text-amber-300">회사 런타임을 사용할 수 없습니다</p>}
        {parsedStatus.data?.stopped && <p className="text-[11px] text-amber-300">회사 런타임이 중지되었습니다</p>}
      </div>

      {view.kind === "submitting" && (
        <div role="status" className="mt-3 flex items-center gap-2 rounded-lg border border-blue-500/20 bg-background/60 px-3 py-2 text-[11px] text-foreground">
          <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" /> 회사 자료와 요청을 확인하고 있습니다
        </div>
      )}
      {view.kind === "canceled" && <Notice title="검토가 취소되었습니다" detail="늦게 도착한 응답은 표시하거나 작업으로 만들지 않습니다." />}
      {view.kind === "failed" && <Notice title={view.title} detail={view.detail} />}
      {view.kind === "clarification" && (
        <Notice title="추가 정보가 필요합니다" detail={view.questions.join(" ")} />
      )}
      {view.kind === "proposed" && (
        <ProposalView view={view} onOpenTasks={onOpenTasks} />
      )}
      {parsedStatus.success && parsedStatus.data.role === "production" && (
        <section aria-label="생산 준비 상태 읽기" className="mt-4 space-y-3 rounded-lg border border-border/40 bg-background/50 p-3">
          <div>
            <h3 className="text-[12px] font-semibold text-foreground">SO-DEMO-1002 생산 준비 검토</h3>
            <p className="mt-1 text-[10px] leading-relaxed text-muted-foreground">가상 ERP를 읽기만 하며 승인·적용·출하 완료를 만들지 않습니다.</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              disabled={readinessPending || runtimeState !== "ready" || parsedStatus.data.stopped}
              onClick={() => void reviewReadiness(false)}
              className="inline-flex h-9 items-center rounded-lg border border-border/50 bg-background px-3 text-[11px] font-semibold text-foreground disabled:opacity-50"
            >
              기준선 준비 상태 읽기
            </button>
            <button
              type="button"
              disabled={readinessPending || runtimeState !== "ready" || parsedStatus.data.stopped}
              onClick={() => void reviewReadiness(true)}
              className="inline-flex h-9 items-center rounded-lg border border-blue-500/30 bg-blue-500/10 px-3 text-[11px] font-semibold text-blue-300 disabled:opacity-50"
            >
              승인 학습으로 다시 확인
            </button>
          </div>
          {readinessPending && <p role="status" className="text-[10px] text-muted-foreground">준비 상태 근거를 읽고 있습니다.</p>}
          {readinessView && (
            <div className="space-y-2 text-[10px] text-muted-foreground">
              <p className="font-medium text-amber-300">추가 확인 필요 · {readinessView.assessment.finding}</p>
              <p>{readinessView.assessment.usedAssetRef
                ? `${readinessView.assessment.usedAssetRef.assetId} · v${readinessView.assessment.usedAssetRef.version}`
                : "사용 학습 없음"}</p>
              <ul aria-label="추가 조회 근거" className="space-y-1">
                {readinessView.assessment.additionalReadSet.length > 0
                  ? readinessView.assessment.additionalReadSet.map((reference) => (
                    <li key={`${reference.kind}:${reference.id}:${reference.version}`}>
                      {reference.kind} · {reference.id} · v{reference.version}
                    </li>
                  ))
                  : <li>추가 조회 없음</li>}
              </ul>
              <p>사업 결과 미관찰</p>
              {onOpenTasks && (
                <button type="button" onClick={() => onOpenTasks(readinessView.task.workboardTaskId)} className="inline-flex h-8 items-center rounded-lg border border-border/50 bg-background px-3 font-semibold text-foreground">
                  Workboard에서 근거 보기
                </button>
              )}
            </div>
          )}
        </section>
      )}
    </section>
  );
}

function applyResponse(
  response: CompanyRuntimeResponse,
  companyState: z.infer<typeof companyStateSchema>,
  setView: (view: ViewState) => void,
) {
  if (!response.ok) {
    setView({ kind: "failed", ...failureCopy(response.error) });
    return;
  }
  const clarification = clarificationPayloadSchema.safeParse(response.payload);
  if (clarification.success) {
    setView({
      kind: "clarification",
      questions: clarification.data.interpretation.clarificationQuestions,
      runtimeMode: clarification.data.runtimeMode,
      actualAI: clarification.data.actualAI,
    });
    return;
  }
  const proposed = proposalPayloadSchema.safeParse(response.payload);
  if (!proposed.success) {
    setView({ kind: "failed", title: "확인 가능한 정보가 부족합니다", detail: "호스트 응답이 실행 가능한 제안 형식이 아닙니다." });
    return;
  }
  const orderId = proposed.data.interpretation.targetIds.find((id) => companyState.salesOrders.some((order) => order.id === id));
  const planId = proposed.data.proposal.intent.targetPlanId;
  const assessment = assessOrderPriority({
    state: companyState,
    orderId,
    planId,
    proposedPriority: proposed.data.proposal.intent.toPriority,
  });
  if (!isProposedAssessment(assessment)) {
    setView({ kind: "failed", title: "확인 가능한 정보가 부족합니다", detail: `실행 가능한 제안은 만들지 않았습니다. (${assessment.reason ?? assessment.status})` });
    return;
  }
  setView({
    kind: "proposed",
    workboardTaskId: proposed.data.task.workboardTaskId,
    fromPriority: proposed.data.proposal.shadow.diff.priority.before,
    toPriority: proposed.data.proposal.shadow.diff.priority.after,
    runtimeMode: proposed.data.runtimeMode,
    actualAI: proposed.data.actualAI,
    assessment,
  });
}

function Notice({ title, detail }: { title: string; detail: string }) {
  return (
    <div role="status" className="mt-3 rounded-lg border border-amber-500/20 bg-amber-500/10 px-3 py-2">
      <p className="text-[11px] font-semibold text-amber-200">{title}</p>
      <p className="mt-1 text-[10px] leading-relaxed text-muted-foreground">{detail}</p>
    </div>
  );
}

function ProposalView({
  view,
  onOpenTasks,
}: {
  view: Extract<ViewState, { kind: "proposed" }>;
  onOpenTasks?: (taskId?: string) => void;
}) {
  const { assessment } = view;
  return (
    <div className="mt-4 space-y-3">
      <section aria-labelledby="shadow-preview-heading" className="rounded-lg border border-emerald-500/20 bg-emerald-500/5 p-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 id="shadow-preview-heading" className="text-[12px] font-semibold text-foreground">Shadow 변경 미리보기</h3>
          <span className="rounded-md border border-emerald-500/20 bg-emerald-500/10 px-2 py-1 text-[10px] text-emerald-300">변경 건수 0</span>
        </div>
        <p className="mt-2 text-lg font-semibold text-foreground">priority {view.fromPriority} → {view.toPriority}</p>
        <p className="mt-1 text-[10px] text-muted-foreground">AI 해석은 후보입니다. ID, 수량, diff와 정책 판단은 호스트 회사 자료가 확정합니다.</p>
      </section>

      <div className="grid gap-3 md:grid-cols-2">
        <Contribution title="영업 판단" contribution={assessment.departments?.sales} />
        <Contribution title="생산 판단" contribution={assessment.departments?.production} />
      </div>

      <section aria-label="버전이 있는 근거" className="rounded-lg border border-border/40 bg-background/50 p-3">
        <h3 className="text-[11px] font-semibold text-foreground">버전이 있는 근거</h3>
        <ul className="mt-2 grid gap-1 text-[10px] text-muted-foreground sm:grid-cols-2">
          {assessment.sources.map((source) => (
            <li key={source.evidenceId}>{source.kind} · {source.id} · v{source.version}</li>
          ))}
        </ul>
      </section>

      {onOpenTasks && (
        <button type="button" onClick={() => onOpenTasks(view.workboardTaskId)} className="inline-flex h-9 items-center rounded-lg border border-border/50 bg-background px-3 text-[11px] font-semibold text-foreground">
          Workboard에서 계속
        </button>
      )}
    </div>
  );
}

function Contribution({
  title,
  contribution,
}: {
  title: string;
  contribution?: { facts: string[]; unknowns: string[] };
}) {
  return (
    <section className="rounded-lg border border-border/40 bg-background/50 p-3">
      <h3 className="text-[11px] font-semibold text-foreground">{title}</h3>
      <ul className="mt-2 space-y-1 text-[10px] leading-relaxed text-foreground">
        {contribution?.facts.map((fact) => <li key={fact}>{fact}</li>)}
      </ul>
      <p className="mt-2 text-[10px] font-medium text-amber-300">확인되지 않은 정보</p>
      <ul className="mt-1 space-y-1 text-[10px] leading-relaxed text-muted-foreground">
        {contribution?.unknowns.map((unknown) => <li key={unknown}>{unknown}</li>)}
      </ul>
    </section>
  );
}
