import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { WorkflowMarketplace } from "./WorkflowMarketplace";
import { SkillsMarketplace } from "./SkillsMarketplace";
import { McpMarketplace } from "./McpMarketplace";
import {
  Search,
  Plus,
  Star,
  Download,
  ArrowLeft,
  Sparkles,
  TrendingUp,
  X,
  Loader2,
  MessageSquare,
  Send,
  Bot,
  GitBranch,
  Zap,
  Server,
} from "lucide-react";
import { toast } from "sonner";
import { useInstalledItems } from "@/hooks/useInstalledItems";
import { createMarketplaceProvider, type MarketplaceReview } from "@/lib/marketplaceProvider";

const marketplaceProvider = createMarketplaceProvider();

interface MarketplaceAgent {
  id: string;
  name: string;
  description: string | null;
  category: string;
  icon: string;
  prompt_template: string | null;
  creator_name: string;
  installs: number;
  rating: number;
  tags: string[];
  is_featured: boolean;
  created_at: string;
}

const CATEGORIES = [
  { id: "all", label: "전체" },
  { id: "sales", label: "영업" },
  { id: "risk", label: "리스크" },
  { id: "quality", label: "품질" },
  { id: "market", label: "시장분석" },
  { id: "productivity", label: "생산성" },
];

interface MarketplaceModeProps {
  onBack: () => void;
}

export function MarketplaceMode({ onBack }: MarketplaceModeProps) {
  const [activeTab, setActiveTab] = useState<"agents" | "workflows" | "skills" | "mcps">("agents");
  const [agents, setAgents] = useState<MarketplaceAgent[]>([]);
  const { install: installItem, isInstalled } = useInstalledItems();
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedAgent, setSelectedAgent] = useState<MarketplaceAgent | null>(null);
  const [aiSearching, setAiSearching] = useState(false);
  const [aiRecommendation, setAiRecommendation] = useState("");

  useEffect(() => {
    fetchAgents();
  }, []);

  const fetchAgents = async () => {
    setLoading(true);
    try {
      setAgents(await marketplaceProvider.list<MarketplaceAgent>("agent"));
    } catch {
      toast.error("에이전트 목록을 불러오는데 실패했습니다");
    }
    setLoading(false);
  };

  const handleInstall = async (agent: MarketplaceAgent) => {
    if (isInstalled(agent.id, "agent")) {
      toast.info(`${agent.name}은(는) 이미 설치되어 있습니다`);
      return;
    }
    try {
      await marketplaceProvider.incrementInstalls("agent", agent.id, agent.installs);
      setAgents((prev) =>
        prev.map((a) => (a.id === agent.id ? { ...a, installs: a.installs + 1 } : a))
      );
      await installItem({
        item_id: agent.id,
        item_type: "agent",
        item_name: agent.name,
        item_icon: agent.icon,
        item_description: agent.description || undefined,
      });
    } catch {
      toast.error("에이전트 설치에 실패했습니다");
    }
  };

  const handleAiSearch = async () => {
    if (!searchQuery.trim()) return;
    setAiSearching(true);
    setAiRecommendation("");
    try {
      const recommendation = await marketplaceProvider.recommendAgents({
        query: searchQuery,
        agentNames: agents.map((a) => `${a.name}(${a.category})`),
      });
      setAiRecommendation(recommendation || "추천 결과를 가져올 수 없습니다.");
    } catch {
      setAiRecommendation("AI 추천을 불러오지 못했습니다.");
    }
    setAiSearching(false);
  };

  const filtered = agents.filter((a) => {
    const matchCategory = activeCategory === "all" || a.category === activeCategory;
    const matchSearch =
      !searchQuery ||
      a.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      a.tags.some((t) => t.includes(searchQuery.toLowerCase()));
    return matchCategory && matchSearch;
  });

  const featured = agents.filter((a) => a.is_featured);

  return (
    <div className="h-full flex flex-col overflow-hidden">
      {/* Header */}
      <div className="px-6 py-5 border-b border-border/50 flex-shrink-0">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <button onClick={onBack} className="p-1.5 rounded-lg hover:bg-secondary transition-colors">
              <ArrowLeft className="w-4 h-4 text-muted-foreground" />
            </button>
            <div>
              <h1 className="text-[15px] font-bold text-foreground">연결 센터</h1>
              <p className="text-[11px] text-muted-foreground mt-0.5">
                사내에서 만든 에이전트와 자동화를 검색하고 설치하세요
              </p>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 p-1 rounded-xl bg-secondary/40">
          {[
            { id: "agents" as const, icon: Bot, label: "에이전트" },
            { id: "workflows" as const, icon: GitBranch, label: "자동화" },
            { id: "skills" as const, icon: Zap, label: "스킬" },
            { id: "mcps" as const, icon: Server, label: "MCP" },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-[11px] font-medium transition-colors ${
                activeTab === tab.id
                  ? "bg-card text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <tab.icon className="w-3.5 h-3.5" />
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Tab Content */}
      {activeTab === "agents" ? (
        <>
          {/* Agent search/filter header */}
          <div className="px-6 pt-4 pb-2 flex-shrink-0 space-y-3">
            <div className="flex gap-2">
              <div className="flex-1 relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleAiSearch()}
                  placeholder="에이전트 검색... (Enter로 AI 추천)"
                  className="w-full pl-9 pr-4 py-2.5 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none transition-colors"
                />
              </div>
              <button
                onClick={handleAiSearch}
                disabled={aiSearching || !searchQuery.trim()}
                className="px-3 py-2 rounded-xl text-[12px] font-medium bg-accent/10 hover:bg-accent/20 text-accent-foreground border border-border/50 transition-colors flex items-center gap-1.5 disabled:opacity-50"
              >
                {aiSearching ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                AI 추천
              </button>
              <button
                onClick={() => setShowCreateModal(true)}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-[12px] font-semibold transition-colors"
                style={{ background: "hsl(var(--primary))", color: "hsl(var(--primary-foreground))" }}
              >
                <Plus className="w-3.5 h-3.5" />
                만들기
              </button>
            </div>

            <AnimatePresence>
              {aiRecommendation && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="p-3 rounded-xl bg-primary/5 border border-primary/10"
                >
                  <div className="flex items-start gap-2">
                    <Sparkles className="w-3.5 h-3.5 text-primary mt-0.5 flex-shrink-0" />
                    <p className="text-[11px] text-foreground leading-relaxed flex-1">{aiRecommendation}</p>
                    <button onClick={() => setAiRecommendation("")} className="p-0.5">
                      <X className="w-3 h-3 text-muted-foreground" />
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="flex gap-1.5 overflow-x-auto scrollbar-none">
              {CATEGORIES.map((cat) => (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`px-3 py-1.5 rounded-lg text-[11px] font-medium whitespace-nowrap transition-colors ${
                    activeCategory === cat.id
                      ? "bg-primary/15 text-primary"
                      : "text-muted-foreground hover:bg-secondary"
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Agent Content */}
          <div className="flex-1 overflow-y-auto px-6 py-4 space-y-6 scrollbar-thin">
            {loading ? (
              <div className="flex items-center justify-center py-20">
                <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
              </div>
            ) : (
              <>
                {activeCategory === "all" && featured.length > 0 && !searchQuery && (
                  <section>
                    <div className="flex items-center gap-2 mb-3">
                      <TrendingUp className="w-3.5 h-3.5 text-primary" />
                      <h2 className="text-[12px] font-semibold text-foreground">추천 에이전트</h2>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      {featured.slice(0, 4).map((agent) => (
                        <AgentCard key={agent.id} agent={agent} onInstall={handleInstall} onSelect={setSelectedAgent} featured installed={isInstalled(agent.id, "agent")} />
                      ))}
                    </div>
                  </section>
                )}
                <section>
                  <div className="flex items-center justify-between mb-3">
                    <h2 className="text-[12px] font-semibold text-foreground">
                      {activeCategory === "all" ? "모든 에이전트" : CATEGORIES.find((c) => c.id === activeCategory)?.label}
                      <span className="text-muted-foreground font-normal ml-1.5">({filtered.length})</span>
                    </h2>
                  </div>
                  {filtered.length === 0 ? (
                    <div className="text-center py-12">
                      <p className="text-[12px] text-muted-foreground">검색 결과가 없습니다</p>
                      <button onClick={() => setShowCreateModal(true)} className="mt-2 text-[11px] text-primary hover:underline">
                        직접 에이전트를 만들어보세요
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-2 gap-3">
                      {filtered.map((agent) => (
                        <AgentCard key={agent.id} agent={agent} onInstall={handleInstall} onSelect={setSelectedAgent} installed={isInstalled(agent.id, "agent")} />
                      ))}
                    </div>
                  )}
                </section>
              </>
            )}
          </div>

          <AnimatePresence>
            {showCreateModal && (
              <CreateAgentModal onClose={() => setShowCreateModal(false)} onCreated={() => { setShowCreateModal(false); fetchAgents(); }} />
            )}
          </AnimatePresence>
          <AnimatePresence>
            {selectedAgent && (
              <AgentDetailModal agent={selectedAgent} onClose={() => setSelectedAgent(null)} onInstall={handleInstall} />
            )}
          </AnimatePresence>
        </>
      ) : activeTab === "workflows" ? (
        <div className="flex-1 overflow-y-auto px-6 py-4 scrollbar-thin">
          <WorkflowMarketplace />
        </div>
      ) : activeTab === "skills" ? (
        <div className="flex-1 overflow-y-auto px-6 py-4 scrollbar-thin">
          <SkillsMarketplace />
        </div>
      ) : (
        <div className="flex-1 overflow-y-auto px-6 py-4 scrollbar-thin">
          <McpMarketplace />
        </div>
      )}
    </div>
  );
}

/* ─── Agent Card ─── */
function AgentCard({
  agent,
  onInstall,
  onSelect,
  featured,
  installed,
}: {
  agent: MarketplaceAgent;
  onInstall: (a: MarketplaceAgent) => void;
  onSelect: (a: MarketplaceAgent) => void;
  featured?: boolean;
  installed?: boolean;
}) {
  return (
    <motion.div
      whileHover={{ y: -2 }}
      onClick={() => onSelect(agent)}
      className={`rounded-2xl p-4 border cursor-pointer transition-colors group ${
        featured
          ? "border-primary/20 bg-primary/[0.03]"
          : "border-border/50 bg-card/50 hover:border-border"
      }`}
    >
      <div className="flex items-start justify-between mb-3">
        <div
          className="w-10 h-10 rounded-xl flex items-center justify-center text-[18px]"
          style={{ background: "hsl(var(--secondary))" }}
        >
          🤖
        </div>
        {featured && (
          <span className="text-[9px] px-2 py-0.5 rounded-full bg-primary/10 text-primary font-semibold">추천</span>
        )}
      </div>
      <h3 className="text-[13px] font-semibold text-foreground mb-1 line-clamp-1">{agent.name}</h3>
      <p className="text-[11px] text-muted-foreground line-clamp-2 mb-3">{agent.description}</p>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
          <span className="flex items-center gap-1">
            <Star className="w-3 h-3 text-amber-500" fill="currentColor" />
            {agent.rating}
          </span>
          <span className="flex items-center gap-1">
            <Download className="w-3 h-3" />
            {agent.installs}
          </span>
        </div>
        {installed ? (
          <span className="px-2.5 py-1 rounded-lg text-[10px] font-semibold bg-green-500/10 text-green-600">
            설치됨 ✓
          </span>
        ) : (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onInstall(agent);
            }}
            className="px-2.5 py-1 rounded-lg text-[10px] font-semibold bg-primary/10 text-primary hover:bg-primary/20 transition-colors"
          >
            설치
          </button>
        )}
      </div>
      <div className="flex gap-1 mt-2 flex-wrap">
        {agent.tags.slice(0, 3).map((tag) => (
          <span
            key={tag}
            className="text-[9px] px-1.5 py-0.5 rounded-md bg-secondary/60 text-muted-foreground"
          >
            #{tag}
          </span>
        ))}
      </div>
    </motion.div>
  );
}

/* ─── Detail Modal with Reviews ─── */
function AgentDetailModal({
  agent,
  onClose,
  onInstall,
}: {
  agent: MarketplaceAgent;
  onClose: () => void;
  onInstall: (a: MarketplaceAgent) => void;
}) {
  const [reviews, setReviews] = useState<MarketplaceReview[]>([]);
  const [loadingReviews, setLoadingReviews] = useState(true);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState("");
  const [reviewerName, setReviewerName] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [hoverRating, setHoverRating] = useState(0);
  const [currentRating, setCurrentRating] = useState(agent.rating);

  const fetchReviews = useCallback(async () => {
    setLoadingReviews(true);
    try {
      setReviews(await marketplaceProvider.listReviews("agent", agent.id));
    } catch {
      toast.error("리뷰를 불러오지 못했습니다");
    }
    setLoadingReviews(false);
  }, [agent.id]);

  useEffect(() => {
    fetchReviews();
  }, [fetchReviews]);

  const submitReview = async () => {
    if (!reviewComment.trim()) {
      toast.error("리뷰 내용을 입력해주세요");
      return;
    }
    setSubmitting(true);
    try {
      await marketplaceProvider.submitReview("agent", agent.id, {
        reviewer_name: reviewerName.trim() || "익명",
        rating: reviewRating,
        comment: reviewComment.trim(),
      });
      toast.success("리뷰가 등록되었습니다!");
      setShowReviewForm(false);
      setReviewComment("");
      setReviewRating(5);
      setReviewerName("");
      await fetchReviews();
      const rating = await marketplaceProvider.getRating("agent", agent.id);
      if (rating !== null) setCurrentRating(rating);
    } catch {
      toast.error("리뷰 등록에 실패했습니다");
    }
    setSubmitting(false);
  };

  const ratingDistribution = [5, 4, 3, 2, 1].map((r) => ({
    stars: r,
    count: reviews.filter((rv) => rv.rating === r).length,
  }));
  const maxCount = Math.max(...ratingDistribution.map((d) => d.count), 1);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[60] bg-black/40 flex items-center justify-center p-8"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-lg rounded-2xl bg-card border border-border p-6 space-y-4 max-h-[85vh] overflow-y-auto scrollbar-thin"
        style={{ boxShadow: "var(--shadow-3)" }}
      >
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div
              className="w-12 h-12 rounded-xl flex items-center justify-center text-[22px]"
              style={{ background: "hsl(var(--secondary))" }}
            >
              🤖
            </div>
            <div>
              <h2 className="text-[14px] font-bold text-foreground">{agent.name}</h2>
              <p className="text-[11px] text-muted-foreground">by {agent.creator_name}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg hover:bg-secondary transition-colors">
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>

        <p className="text-[12px] text-foreground/80 leading-relaxed">{agent.description}</p>

        <div className="flex items-center gap-4 text-[11px] text-muted-foreground">
          <span className="flex items-center gap-1">
            <Star className="w-3.5 h-3.5 text-amber-500" fill="currentColor" />
            {currentRating}
          </span>
          <span className="flex items-center gap-1">
            <Download className="w-3.5 h-3.5" />
            {agent.installs}회 설치
          </span>
          <span className="flex items-center gap-1">
            <MessageSquare className="w-3.5 h-3.5" />
            {reviews.length}개 리뷰
          </span>
        </div>

        {agent.prompt_template && (
          <div className="rounded-xl bg-secondary/30 p-3">
            <p className="text-[10px] font-semibold text-muted-foreground mb-1">프롬프트 템플릿</p>
            <p className="text-[11px] text-foreground/70 font-mono leading-relaxed">{agent.prompt_template}</p>
          </div>
        )}

        <div className="flex gap-1.5 flex-wrap">
          {agent.tags.map((tag) => (
            <span key={tag} className="text-[10px] px-2 py-0.5 rounded-md bg-secondary/60 text-muted-foreground">
              #{tag}
            </span>
          ))}
        </div>

        <button
          onClick={() => {
            onInstall(agent);
            onClose();
          }}
          className="w-full py-2.5 rounded-xl text-[12px] font-semibold transition-colors"
          style={{ background: "hsl(var(--primary))", color: "hsl(var(--primary-foreground))" }}
        >
          에이전트 설치하기
        </button>

        {/* ─── Rating Summary ─── */}
        <div className="border-t border-border/50 pt-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-[13px] font-semibold text-foreground">평점 및 리뷰</h3>
            <button
              onClick={() => setShowReviewForm(!showReviewForm)}
              className="text-[11px] font-medium text-primary hover:underline flex items-center gap-1"
            >
              <Send className="w-3 h-3" />
              리뷰 작성
            </button>
          </div>

          {/* Rating distribution */}
          {reviews.length > 0 && (
            <div className="flex gap-4 mb-4">
              <div className="text-center">
                <div className="text-[28px] font-bold text-foreground">{currentRating}</div>
                <div className="flex items-center gap-0.5 justify-center mt-0.5">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <Star
                      key={s}
                      className={`w-3 h-3 ${s <= Math.round(Number(currentRating)) ? "text-amber-500" : "text-muted-foreground/30"}`}
                      fill="currentColor"
                    />
                  ))}
                </div>
                <p className="text-[10px] text-muted-foreground mt-1">{reviews.length}개</p>
              </div>
              <div className="flex-1 space-y-1">
                {ratingDistribution.map((d) => (
                  <div key={d.stars} className="flex items-center gap-2">
                    <span className="text-[10px] text-muted-foreground w-3 text-right">{d.stars}</span>
                    <div className="flex-1 h-2 rounded-full bg-secondary/50 overflow-hidden">
                      <div
                        className="h-full rounded-full bg-amber-500/70 transition-all"
                        style={{ width: `${(d.count / maxCount) * 100}%` }}
                      />
                    </div>
                    <span className="text-[10px] text-muted-foreground w-4">{d.count}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Review Form */}
          <AnimatePresence>
            {showReviewForm && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="overflow-hidden mb-4"
              >
                <div className="rounded-xl border border-border/50 p-3 space-y-3 bg-secondary/20">
                  <div>
                    <label className="text-[10px] font-medium text-muted-foreground block mb-1.5">평점</label>
                    <div className="flex items-center gap-1">
                      {[1, 2, 3, 4, 5].map((s) => (
                        <button
                          key={s}
                          onMouseEnter={() => setHoverRating(s)}
                          onMouseLeave={() => setHoverRating(0)}
                          onClick={() => setReviewRating(s)}
                          className="p-0.5 transition-transform hover:scale-110"
                        >
                          <Star
                            className={`w-5 h-5 ${
                              s <= (hoverRating || reviewRating) ? "text-amber-500" : "text-muted-foreground/30"
                            }`}
                            fill="currentColor"
                          />
                        </button>
                      ))}
                      <span className="text-[11px] text-muted-foreground ml-2">{reviewRating}점</span>
                    </div>
                  </div>
                  <div>
                    <label className="text-[10px] font-medium text-muted-foreground block mb-1">이름</label>
                    <input
                      value={reviewerName}
                      onChange={(e) => setReviewerName(e.target.value)}
                      placeholder="익명"
                      className="w-full px-3 py-1.5 rounded-lg text-[11px] bg-background border border-border/50 focus:border-primary/30 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-medium text-muted-foreground block mb-1">리뷰 *</label>
                    <textarea
                      value={reviewComment}
                      onChange={(e) => setReviewComment(e.target.value)}
                      rows={2}
                      placeholder="이 에이전트에 대한 의견을 남겨주세요"
                      className="w-full px-3 py-1.5 rounded-lg text-[11px] bg-background border border-border/50 focus:border-primary/30 focus:outline-none resize-none"
                    />
                  </div>
                  <div className="flex gap-2 justify-end">
                    <button
                      onClick={() => setShowReviewForm(false)}
                      className="px-3 py-1.5 rounded-lg text-[11px] text-muted-foreground hover:bg-secondary transition-colors"
                    >
                      취소
                    </button>
                    <button
                      onClick={submitReview}
                      disabled={submitting || !reviewComment.trim()}
                      className="px-3 py-1.5 rounded-lg text-[11px] font-semibold transition-colors disabled:opacity-50"
                      style={{ background: "hsl(var(--primary))", color: "hsl(var(--primary-foreground))" }}
                    >
                      {submitting ? "등록 중..." : "리뷰 등록"}
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Review List */}
          {loadingReviews ? (
            <div className="flex justify-center py-4">
              <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
            </div>
          ) : reviews.length === 0 ? (
            <p className="text-[11px] text-muted-foreground text-center py-4">
              아직 리뷰가 없습니다. 첫 번째 리뷰를 남겨보세요!
            </p>
          ) : (
            <div className="space-y-3">
              {reviews.map((review) => (
                <div key={review.id} className="rounded-xl bg-secondary/20 p-3">
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] font-semibold text-foreground">{review.reviewer_name}</span>
                      <div className="flex items-center gap-0.5">
                        {[1, 2, 3, 4, 5].map((s) => (
                          <Star
                            key={s}
                            className={`w-2.5 h-2.5 ${s <= review.rating ? "text-amber-500" : "text-muted-foreground/30"}`}
                            fill="currentColor"
                          />
                        ))}
                      </div>
                    </div>
                    <span className="text-[9px] text-muted-foreground">
                      {new Date(review.created_at).toLocaleDateString("ko-KR")}
                    </span>
                  </div>
                  <p className="text-[11px] text-foreground/70 leading-relaxed">{review.comment}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}

/* ─── Create Modal ─── */
function CreateAgentModal({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("general");
  const [promptTemplate, setPromptTemplate] = useState("");
  const [creatorName, setCreatorName] = useState("");
  const [tags, setTags] = useState("");
  const [saving, setSaving] = useState(false);
  const [aiGenerating, setAiGenerating] = useState(false);

  const handleAiAssist = async () => {
    if (!name.trim()) {
      toast.error("에이전트 이름을 먼저 입력해주세요");
      return;
    }
    setAiGenerating(true);
    try {
      const parsed = await marketplaceProvider.assistAgent(name);
      if (parsed.description) setDescription(parsed.description);
      if (parsed.prompt_template) setPromptTemplate(parsed.prompt_template);
      if (parsed.tags) setTags(parsed.tags.join(", "));
      if (parsed.category) setCategory(parsed.category);
    } catch {
      toast.error("AI 보조를 불러오지 못했습니다");
    }
    setAiGenerating(false);
  };

  const handleSubmit = async () => {
    if (!name.trim()) {
      toast.error("이름을 입력해주세요");
      return;
    }
    setSaving(true);
    try {
      await marketplaceProvider.create("agent", {
        name,
        description: description || null,
        category,
        prompt_template: promptTemplate || null,
        creator_name: creatorName || "익명",
        tags: tags
          .split(",")
          .map((t) => t.trim())
          .filter(Boolean),
      });
      toast.success("에이전트가 연결 센터에 등록되었습니다!");
      onCreated();
    } catch {
      toast.error("에이전트 등록에 실패했습니다");
    }
    setSaving(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[60] bg-black/40 flex items-center justify-center p-8"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md rounded-2xl bg-card border border-border p-6 space-y-4 max-h-[80vh] overflow-y-auto scrollbar-thin"
        style={{ boxShadow: "var(--shadow-3)" }}
      >
        <div className="flex items-center justify-between">
          <h2 className="text-[14px] font-bold text-foreground">새 에이전트 만들기</h2>
          <button onClick={onClose} className="p-1 rounded-lg hover:bg-secondary transition-colors">
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>

        <div className="space-y-3">
          <div>
            <label className="text-[11px] font-medium text-muted-foreground block mb-1">이름 *</label>
            <div className="flex gap-2">
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="예: 재고 최적화 분석기"
                className="flex-1 px-3 py-2 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none"
              />
              <button
                onClick={handleAiAssist}
                disabled={aiGenerating || !name.trim()}
                className="px-2.5 py-2 rounded-xl text-[11px] font-medium bg-primary/10 text-primary hover:bg-primary/20 transition-colors flex items-center gap-1 disabled:opacity-50 whitespace-nowrap"
              >
                {aiGenerating ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
                AI 채우기
              </button>
            </div>
          </div>

          <div>
            <label className="text-[11px] font-medium text-muted-foreground block mb-1">설명</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={2}
              placeholder="에이전트가 무엇을 하는지 설명해주세요"
              className="w-full px-3 py-2 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none resize-none"
            />
          </div>

          <div>
            <label className="text-[11px] font-medium text-muted-foreground block mb-1">카테고리</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full px-3 py-2 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none"
            >
              <option value="general">일반</option>
              <option value="sales">영업</option>
              <option value="risk">리스크</option>
              <option value="quality">품질</option>
              <option value="market">시장분석</option>
              <option value="productivity">생산성</option>
            </select>
          </div>

          <div>
            <label className="text-[11px] font-medium text-muted-foreground block mb-1">프롬프트 템플릿</label>
            <textarea
              value={promptTemplate}
              onChange={(e) => setPromptTemplate(e.target.value)}
              rows={3}
              placeholder="{{변수}}를 사용하여 프롬프트 템플릿을 작성하세요"
              className="w-full px-3 py-2 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none resize-none font-mono"
            />
          </div>

          <div>
            <label className="text-[11px] font-medium text-muted-foreground block mb-1">태그 (쉼표 구분)</label>
            <input
              value={tags}
              onChange={(e) => setTags(e.target.value)}
              placeholder="예: 재고, 최적화, 분석"
              className="w-full px-3 py-2 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none"
            />
          </div>

          <div>
            <label className="text-[11px] font-medium text-muted-foreground block mb-1">만든 사람</label>
            <input
              value={creatorName}
              onChange={(e) => setCreatorName(e.target.value)}
              placeholder="이름 (비워두면 '익명')"
              className="w-full px-3 py-2 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none"
            />
          </div>
        </div>

        <button
          onClick={handleSubmit}
          disabled={saving || !name.trim()}
          className="w-full py-2.5 rounded-xl text-[12px] font-semibold transition-colors disabled:opacity-50"
          style={{ background: "hsl(var(--primary))", color: "hsl(var(--primary-foreground))" }}
        >
          {saving ? "등록 중..." : "연결 센터에 등록"}
        </button>
      </motion.div>
    </motion.div>
  );
}
