import { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowLeft, Play, Loader2, Users, BarChart3, Shield,
  FileSearch, MessageSquare, Sparkles, Pause, RotateCcw,
  CheckCircle2, Settings2, Scale, BookCheck, ShieldCheck, Zap,
  FileText, ListTodo, Check, Send, User, Hand, AtSign,
  Swords, ThumbsUp, ThumbsDown, Gavel, History, Eye, Trash2
} from "lucide-react";
import { streamChat, type Msg } from "@/lib/streamChat";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import ReactMarkdown from "react-markdown";
import type { Database, Json } from "@/integrations/supabase/types";
import type { TaskRecord } from "@/types/task";
import {
  parseAgentMeetingActionItems,
  persistAgentMeetingGatewayTasks,
} from "@/lib/agentic";

interface AgentMeetingModeProps {
  onBack: () => void;
}

type AgentCategory = "operational" | "audit";
type MeetingMode = "meeting" | "debate";
type TaskSaveState = "idle" | "partial" | "complete";

interface MeetingAgent {
  id: string;
  name: string;
  nameKo: string;
  icon: typeof BarChart3;
  color: string;
  role: string;
  systemPrompt: string;
  category: AgentCategory;
}

interface MeetingMessage {
  agentId: string;
  content: string;
  timestamp: Date;
  isStreaming?: boolean;
}

type DebateHistoryRecord = Database["public"]["Tables"]["debate_history"]["Row"];
type StoredDebateMessage = {
  agentId: string;
  content: string;
  timestamp: string;
  isStreaming?: boolean;
};

function getStoredDebateMessages(messages: Json): StoredDebateMessage[] {
  if (!Array.isArray(messages)) return [];

  return messages.filter((message): message is StoredDebateMessage => {
    if (!message || typeof message !== "object" || Array.isArray(message)) return false;
    const candidate = message as Record<string, unknown>;
    return (
      typeof candidate.agentId === "string" &&
      typeof candidate.content === "string" &&
      typeof candidate.timestamp === "string"
    );
  });
}

const meetingAgents: MeetingAgent[] = [
  // 실무 에이전트
  {
    id: "market", name: "Market Agent", nameKo: "시장 분석",
    icon: BarChart3, color: "hsl(var(--agent-market))",
    role: "시장 동향 및 경쟁사 분석 전문가",
    systemPrompt: "당신은 자동차 강판 시장 분석 전문가입니다. 시장 가격, 경쟁사 동향, 수요 전망 관점에서 의견을 제시하세요.",
    category: "operational",
  },
  {
    id: "risk", name: "Risk Agent", nameKo: "리스크 감지",
    icon: Shield, color: "hsl(var(--agent-risk))",
    role: "리스크 관리 및 위험 평가 전문가",
    systemPrompt: "당신은 리스크 관리 전문가입니다. 납기, 품질, 가격 리스크 관점에서 잠재적 위험과 대응방안을 제시하세요.",
    category: "operational",
  },
  {
    id: "docs", name: "Docs Agent", nameKo: "문서 탐색",
    icon: FileSearch, color: "hsl(var(--agent-docs))",
    role: "내부 문서 및 규정 검색 전문가",
    systemPrompt: "당신은 문서 검색/분석 전문가입니다. 관련 문서, 계약서, 회의록 기반으로 근거를 제시하세요.",
    category: "operational",
  },
  {
    id: "sales", name: "Sales Agent", nameKo: "판매 분석",
    icon: BarChart3, color: "hsl(var(--agent-sales))",
    role: "판매 실적 및 수익성 분석 전문가",
    systemPrompt: "당신은 판매 분석 전문가입니다. 매출, 수익성, 가격 전략 관점에서 데이터 기반 의견을 제시하세요.",
    category: "operational",
  },
  {
    id: "planner", name: "Planner Agent", nameKo: "업무 계획",
    icon: MessageSquare, color: "hsl(var(--agent-planner))",
    role: "업무 기획 및 일정 관리 전문가",
    systemPrompt: "당신은 업무 계획 전문가입니다. 실행 가능한 액션 플랜, 일정, 우선순위 관점에서 의견을 제시하세요.",
    category: "operational",
  },
  // 감사 에이전트
  {
    id: "legal", name: "Legal Audit Agent", nameKo: "법률 감사",
    icon: Scale, color: "hsl(var(--status-review))",
    role: "계약·법률 리스크 검토 전문가",
    systemPrompt: "당신은 법률 감사 전문가입니다. 공정거래법, 하도급법 등 관련 법규 저촉 여부와 계약 조건의 법적 리스크를 검토하고 의견을 제시하세요.",
    category: "audit",
  },
  {
    id: "compliance", name: "Compliance Agent", nameKo: "사규 준수",
    icon: BookCheck, color: "hsl(var(--status-review))",
    role: "내부 규정 준수 검토 전문가",
    systemPrompt: "당신은 사규 준수 감사 전문가입니다. 논의 내용이 사내 규정, 결재 기준, 권한 범위에 부합하는지 검토하고 위반 가능성이 있는 부분을 지적하세요.",
    category: "audit",
  },
  {
    id: "purpose", name: "Purpose Audit Agent", nameKo: "목적 적합성",
    icon: ShieldCheck, color: "hsl(var(--status-review))",
    role: "전략 목표 부합·ROI 타당성 검증 전문가",
    systemPrompt: "당신은 목적 적합성 감사 전문가입니다. 논의되는 안건이 조직 전략 목표에 부합하는지, 자원 배분과 ROI가 타당한지 검토하고 의견을 제시하세요.",
    category: "audit",
  },
];

const presetTopics = [
  { label: "Q2 가격 전략 수립", topic: "2분기 자동차 강판 가격 전략을 수립해야 합니다. 원자재 가격 상승, 경쟁사 동향, 고객별 수익성을 종합적으로 논의해주세요." },
  { label: "현대자동차 납기 리스크 대응", topic: "현대자동차 납기 지연 리스크가 감지되었습니다. 원인 분석, 영향 평가, 대응 방안을 논의해주세요." },
  { label: "신규 고객 진입 전략", topic: "전기차 부품 시장 신규 고객 확보 전략을 논의해주세요. 시장 규모, 경쟁 구도, 진입 전략을 종합적으로 분석해주세요." },
  { label: "주간 실적 리뷰", topic: "이번 주 판매 실적을 리뷰하고 다음 주 계획을 수립해주세요. 주요 이슈와 액션 아이템을 정리해주세요." },
];

export function AgentMeetingMode({ onBack }: AgentMeetingModeProps) {
  const [selectedAgents, setSelectedAgents] = useState<Set<string>>(new Set(["market", "risk", "planner"]));
  const [autoSelect, setAutoSelect] = useState(false);
  const [topic, setTopic] = useState("");
  const [messages, setMessages] = useState<MeetingMessage[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [currentSpeaker, setCurrentSpeaker] = useState<string | null>(null);
  const [round, setRound] = useState(0);
  const [showSetup, setShowSetup] = useState(true);
  const [tasks, setTasks] = useState<TaskRecord[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);
  const abortRef = useRef(false);
  const [savedAsReport, setSavedAsReport] = useState(false);
  const [taskSaveState, setTaskSaveState] = useState<TaskSaveState>("idle");
  const [savingReport, setSavingReport] = useState(false);
  const [savingTasks, setSavingTasks] = useState(false);
  const [userInput, setUserInput] = useState("");
  const [isPaused, setIsPaused] = useState(false);
  const [targetAgentId, setTargetAgentId] = useState<string | null>(null);
  const [isAskingAgent, setIsAskingAgent] = useState(false);
  const [meetingMode, setMeetingMode] = useState<MeetingMode>("meeting");
  const [proAgentId, setProAgentId] = useState<string>("market");
  const [conAgentId, setConAgentId] = useState<string>("risk");
  const [debateRounds, setDebateRounds] = useState(3);
  const [userVerdict, setUserVerdict] = useState<"pro" | "con" | "neutral" | null>(null);
  const [verdictReason, setVerdictReason] = useState("");
  const [showVerdictPanel, setShowVerdictPanel] = useState(false);
  const [judgeAgentId, setJudgeAgentId] = useState<string | null>(null);
  const userInterjectionRef = useRef<string | null>(null);
  const pauseResolveRef = useRef<(() => void) | null>(null);
  const conversationHistoryRef = useRef<{ agentId: string; content: string }[]>([]);
  const [debateHistoryList, setDebateHistoryList] = useState<DebateHistoryRecord[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [viewingDebate, setViewingDebate] = useState<DebateHistoryRecord | null>(null);
  const [savingDebate, setSavingDebate] = useState(false);

  useEffect(() => {
    supabase.from("tasks").select("*").order("created_at", { ascending: false }).limit(20)
      .then(({ data }) => setTasks(data || []));
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const toggleAgent = (id: string) => {
    setSelectedAgents(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const autoSelectAgents = useCallback(() => {
    const topicLower = topic.toLowerCase();
    const auto = new Set<string>();

    // 실무 에이전트 자동 선택
    if (topicLower.includes("가격") || topicLower.includes("시장") || topicLower.includes("경쟁")) auto.add("market");
    if (topicLower.includes("리스크") || topicLower.includes("납기") || topicLower.includes("품질") || topicLower.includes("위험")) auto.add("risk");
    if (topicLower.includes("문서") || topicLower.includes("계약") || topicLower.includes("규정")) auto.add("docs");
    if (topicLower.includes("실적") || topicLower.includes("매출") || topicLower.includes("수익") || topicLower.includes("판매")) auto.add("sales");
    if (topicLower.includes("계획") || topicLower.includes("일정") || topicLower.includes("전략") || topicLower.includes("액션")) auto.add("planner");

    // 감사 에이전트 자동 선택
    if (topicLower.includes("법률") || topicLower.includes("법규") || topicLower.includes("공정거래") || topicLower.includes("계약")) auto.add("legal");
    if (topicLower.includes("사규") || topicLower.includes("규정") || topicLower.includes("결재") || topicLower.includes("준수")) auto.add("compliance");
    if (topicLower.includes("목적") || topicLower.includes("전략") || topicLower.includes("roi") || topicLower.includes("타당성")) auto.add("purpose");

    // Always include at least 2 agents
    if (auto.size < 2) {
      auto.add("market");
      auto.add("planner");
    }

    setSelectedAgents(auto);
    toast.success(`${auto.size}명의 에이전트가 자동 선택되었습니다 (실무 ${[...auto].filter(id => meetingAgents.find(a => a.id === id)?.category === "operational").length}명, 감사 ${[...auto].filter(id => meetingAgents.find(a => a.id === id)?.category === "audit").length}명)`);
  }, [topic]);

  const waitForResume = () => new Promise<void>((resolve) => {
    pauseResolveRef.current = resolve;
  });

  const submitUserInterjection = useCallback(() => {
    if (!userInput.trim()) return;
    const text = userInput.trim();
    setUserInput("");

    // Add user message to UI
    setMessages(prev => [...prev, {
      agentId: "user",
      content: text,
      timestamp: new Date(),
      isStreaming: false,
    }]);
    conversationHistoryRef.current.push({ agentId: "user", content: text });

    // If paused, resume with user input
    if (isPaused && pauseResolveRef.current) {
      userInterjectionRef.current = text;
      setIsPaused(false);
      pauseResolveRef.current();
      pauseResolveRef.current = null;
    } else {
      // If running, just inject into history — agents will see it in context
      userInterjectionRef.current = text;
    }
    toast.success("의견이 회의에 반영됩니다");
  }, [userInput, isPaused]);

  const askSpecificAgent = useCallback(async () => {
    if (!userInput.trim() || !targetAgentId) return;
    const agent = meetingAgents.find(a => a.id === targetAgentId);
    if (!agent) return;

    const text = userInput.trim();
    setUserInput("");
    setIsAskingAgent(true);

    // Add user directed question to UI
    setMessages(prev => [...prev, {
      agentId: "user-directed",
      content: `**@${agent.nameKo}** ${text}`,
      timestamp: new Date(),
      isStreaming: false,
    }]);
    conversationHistoryRef.current.push({ agentId: "user", content: `[${agent.nameKo}에게 질문] ${text}` });

    const priorMessages = conversationHistoryRef.current.map(m => {
      if (m.agentId === "user") return `[사용자]: ${m.content}`;
      const a2 = meetingAgents.find(x => x.id === m.agentId);
      return `[${a2?.nameKo || m.agentId}]: ${m.content}`;
    }).join("\n\n");

    setCurrentSpeaker(agent.id);
    setMessages(prev => [...prev, {
      agentId: agent.id, content: "", timestamp: new Date(), isStreaming: true,
    }]);

    let accumulated = "";
    try {
      await new Promise<void>((resolve, reject) => {
        streamChat({
          messages: [{ role: "user", content: `회의 주제: ${topic}\n\n이전 논의:\n${priorMessages}\n\n사용자가 당신(${agent.nameKo}, ${agent.role})에게 직접 질문했습니다: "${text}"\n\n당신의 전문 분야 관점에서 이 질문에 구체적으로 답변하세요. 1-2문단으로 간결하게 답변하세요.` }],
          onDelta: (chunk) => {
            accumulated += chunk;
            setMessages(prev => {
              const updated = [...prev];
              updated[updated.length - 1] = { ...updated[updated.length - 1], content: accumulated };
              return updated;
            });
          },
          onDone: () => {
            setMessages(prev => {
              const updated = [...prev];
              updated[updated.length - 1] = { ...updated[updated.length - 1], isStreaming: false };
              return updated;
            });
            resolve();
          },
          onError: (err) => { toast.error(err); reject(new Error(err)); },
        });
      });
      conversationHistoryRef.current.push({ agentId: agent.id, content: accumulated });
    } catch { /* */ }

    setCurrentSpeaker(null);
    setIsAskingAgent(false);
    setTargetAgentId(null);
  }, [userInput, targetAgentId, topic]);

  const runAgentTurn = async (agent: MeetingAgent, roundNum: number, topicText: string, taskContext: string) => {
    if (abortRef.current) return;
    setCurrentSpeaker(agent.id);

    const priorMessages = conversationHistoryRef.current.map(m => {
      if (m.agentId === "user") return `[사용자 의견]: ${m.content}`;
      const a = meetingAgents.find(x => x.id === m.agentId);
      return `[${a?.nameKo || m.agentId}]: ${m.content}`;
    }).join("\n\n");

    const roundLabel = roundNum === 0 ? "첫 번째 라운드" : `${roundNum + 1}번째 라운드 (반론/보완)`;
    const userContext = userInterjectionRef.current
      ? `\n\n사용자가 다음 의견을 제시했습니다. 이를 반드시 고려하세요: "${userInterjectionRef.current}"`
      : "";

    const userPrompt = roundNum === 0
      ? `회의 주제: ${topicText}\n\n현재 데이터:\n${taskContext}\n\n당신은 ${agent.nameKo}(${agent.role})입니다. ${roundLabel}에서 이 주제에 대해 당신의 전문 분야 관점에서 핵심 의견을 2-3문단으로 제시하세요. 구체적인 데이터나 근거를 포함하세요.${userContext}`
      : `회의 주제: ${topicText}\n\n이전 논의:\n${priorMessages}\n\n당신은 ${agent.nameKo}(${agent.role})입니다. ${roundLabel}입니다. 다른 에이전트들의 의견을 참고하여 보완, 반론, 또는 추가 인사이트를 1-2문단으로 간결하게 제시하세요.${userContext}`;

    const chatMessages: Msg[] = [{ role: "user", content: userPrompt }];

    let accumulated = "";
    setMessages(prev => [...prev, {
      agentId: agent.id, content: "", timestamp: new Date(), isStreaming: true,
    }]);

    try {
      await new Promise<void>((resolve, reject) => {
        streamChat({
          messages: chatMessages,
          onDelta: (chunk) => {
            if (abortRef.current) return;
            accumulated += chunk;
            setMessages(prev => {
              const updated = [...prev];
              updated[updated.length - 1] = { ...updated[updated.length - 1], content: accumulated };
              return updated;
            });
          },
          onDone: () => {
            setMessages(prev => {
              const updated = [...prev];
              updated[updated.length - 1] = { ...updated[updated.length - 1], isStreaming: false };
              return updated;
            });
            resolve();
          },
          onError: (err) => { toast.error(err); reject(new Error(err)); },
        });
      });
      conversationHistoryRef.current.push({ agentId: agent.id, content: accumulated });
    } catch { /* break handled by caller */ }

    if (!abortRef.current) await new Promise(res => setTimeout(res, 500));
  };

  const startMeeting = useCallback(async () => {
    if (!topic.trim() || selectedAgents.size < 2) {
      toast.error("주제를 입력하고 2명 이상의 에이전트를 선택해주세요");
      return;
    }

    setShowSetup(false);
    setIsRunning(true);
    setMessages([]);
    setRound(0);
    abortRef.current = false;
    userInterjectionRef.current = null;
    conversationHistoryRef.current = [];

    const participants = meetingAgents.filter(a => selectedAgents.has(a.id));
    const taskContext = tasks.slice(0, 10).map(t => `- [${t.severity || "보통"}] ${t.title} (${t.customer || "미지정"}, ${t.status})`).join("\n");

    // Round 1
    setRound(1);
    for (const agent of participants) {
      if (abortRef.current) break;
      await runAgentTurn(agent, 0, topic, taskContext);
    }

    // Pause between rounds for optional user input
    if (!abortRef.current) {
      setIsPaused(true);
      setCurrentSpeaker(null);
      setMessages(prev => [...prev, {
        agentId: "pause",
        content: "라운드 1이 종료되었습니다. 의견을 추가하거나, '계속' 버튼을 눌러 다음 라운드를 진행하세요.",
        timestamp: new Date(),
        isStreaming: false,
      }]);
      await waitForResume();
    }

    // Round 2
    if (!abortRef.current) {
      setRound(2);
      for (const agent of participants) {
        if (abortRef.current) break;
        await runAgentTurn(agent, 1, topic, taskContext);
      }
      // Clear the interjection after it's been consumed
      userInterjectionRef.current = null;
    }

    // Generate summary
    if (!abortRef.current && conversationHistoryRef.current.length > 0) {
      setCurrentSpeaker("summary");
      const allDiscussion = conversationHistoryRef.current.map(m => {
        if (m.agentId === "user") return `[사용자 의견]: ${m.content}`;
        const a = meetingAgents.find(x => x.id === m.agentId);
        return `[${a?.nameKo}]: ${m.content}`;
      }).join("\n\n");

      setMessages(prev => [...prev, {
        agentId: "summary", content: "", timestamp: new Date(), isStreaming: true,
      }]);

      let summaryText = "";
      await streamChat({
        messages: [{ role: "user", content: `다음은 AI 에이전트들의 회의 내용입니다. 사용자 의견도 포함되어 있습니다. 핵심 합의사항, 논쟁점, 액션 아이템을 정리한 회의록 요약을 작성하세요.\n\n회의 주제: ${topic}\n\n논의 내용:\n${allDiscussion}` }],
        onDelta: (chunk) => {
          summaryText += chunk;
          setMessages(prev => {
            const updated = [...prev];
            updated[updated.length - 1] = { ...updated[updated.length - 1], content: summaryText };
            return updated;
          });
        },
        onDone: () => {
          setMessages(prev => {
            const updated = [...prev];
            updated[updated.length - 1] = { ...updated[updated.length - 1], isStreaming: false };
            return updated;
          });
        },
        onError: (err) => toast.error(err),
      });
    }

    setCurrentSpeaker(null);
    setIsRunning(false);
    setIsPaused(false);
    toast.success("에이전트 회의가 종료되었습니다");
  }, [topic, selectedAgents, tasks]);

  const startDebate = useCallback(async () => {
    if (!topic.trim()) {
      toast.error("토론 주제를 입력해주세요");
      return;
    }
    if (proAgentId === conAgentId) {
      toast.error("찬성과 반대 측에 서로 다른 에이전트를 선택해주세요");
      return;
    }

    const proAgent = meetingAgents.find(a => a.id === proAgentId)!;
    const conAgent = meetingAgents.find(a => a.id === conAgentId)!;

    setShowSetup(false);
    setIsRunning(true);
    setMessages([]);
    setRound(0);
    abortRef.current = false;
    userInterjectionRef.current = null;
    conversationHistoryRef.current = [];
    // Set selectedAgents for the status bar display
    setSelectedAgents(new Set([proAgentId, conAgentId, ...(judgeAgentId ? [judgeAgentId] : [])]));
    const judgeAgent = judgeAgentId ? meetingAgents.find(a => a.id === judgeAgentId) : null;

    const streamAgentMessage = async (agent: MeetingAgent, prompt: string, stance: "pro" | "con" | "judge") => {
      if (abortRef.current) return "";
      setCurrentSpeaker(agent.id);

      setMessages(prev => [...prev, {
        agentId: `${stance}-${agent.id}`,
        content: "",
        timestamp: new Date(),
        isStreaming: true,
      }]);

      let accumulated = "";
      try {
        await new Promise<void>((resolve, reject) => {
          streamChat({
            messages: [{ role: "user", content: prompt }],
            onDelta: (chunk) => {
              if (abortRef.current) return;
              accumulated += chunk;
              setMessages(prev => {
                const updated = [...prev];
                updated[updated.length - 1] = { ...updated[updated.length - 1], content: accumulated };
                return updated;
              });
            },
            onDone: () => {
              setMessages(prev => {
                const updated = [...prev];
                updated[updated.length - 1] = { ...updated[updated.length - 1], isStreaming: false };
                return updated;
              });
              resolve();
            },
            onError: (err) => { toast.error(err); reject(new Error(err)); },
          });
        });
        conversationHistoryRef.current.push({ agentId: agent.id, content: `[${stance === "pro" ? "찬성" : stance === "con" ? "반대" : "심판 평가"}] ${accumulated}` });
      } catch { /* */ }

      if (!abortRef.current) await new Promise(res => setTimeout(res, 500));
      return accumulated;
    };

    // Run debate rounds
    for (let r = 0; r < debateRounds && !abortRef.current; r++) {
      setRound(r + 1);

      const priorMessages = conversationHistoryRef.current.map(m => {
        const a = meetingAgents.find(x => x.id === m.agentId);
        return `[${a?.nameKo}]: ${m.content}`;
      }).join("\n\n");

      const userCtx = userInterjectionRef.current
        ? `\n\n사용자가 다음 의견을 제시했습니다. 반드시 고려하세요: "${userInterjectionRef.current}"`
        : "";

      const roundInfo = r === 0 ? "첫 번째 라운드 (입론)" : r === debateRounds - 1 ? "마지막 라운드 (최종 주장)" : `${r + 1}번째 라운드 (반박/보완)`;

      // Pro agent speaks
      const proPrompt = r === 0
        ? `토론 주제: "${topic}"\n\n당신은 ${proAgent.nameKo}(${proAgent.role})이며, 이 주제에 대해 **찬성** 입장입니다.\n${roundInfo}에서 찬성 근거를 2-3문단으로 강하게 주장하세요. 구체적 데이터와 논거를 제시하세요.${userCtx}`
        : `토론 주제: "${topic}"\n\n이전 토론:\n${priorMessages}\n\n당신은 ${proAgent.nameKo}(${proAgent.role})이며, **찬성** 입장입니다.\n${roundInfo}입니다. 반대 측 주장을 반박하고 찬성 근거를 보강하세요. 1-2문단으로 간결하게.${userCtx}`;

      await streamAgentMessage(proAgent, proPrompt, "pro");
      if (abortRef.current) break;

      // Con agent speaks
      const updatedPrior = conversationHistoryRef.current.map(m => {
        const a = meetingAgents.find(x => x.id === m.agentId);
        return `[${a?.nameKo}]: ${m.content}`;
      }).join("\n\n");

      const conPrompt = r === 0
        ? `토론 주제: "${topic}"\n\n이전 발언:\n${updatedPrior}\n\n당신은 ${conAgent.nameKo}(${conAgent.role})이며, 이 주제에 대해 **반대** 입장입니다.\n${roundInfo}에서 반대 근거를 2-3문단으로 강하게 주장하세요. 찬성 측 주장의 약점을 지적하고 구체적 반론을 제시하세요.${userCtx}`
        : `토론 주제: "${topic}"\n\n이전 토론:\n${updatedPrior}\n\n당신은 ${conAgent.nameKo}(${conAgent.role})이며, **반대** 입장입니다.\n${roundInfo}입니다. 찬성 측의 최신 주장을 반박하고 반대 근거를 보강하세요. 1-2문단으로 간결하게.${userCtx}`;

      await streamAgentMessage(conAgent, conPrompt, "con");

      // Judge mid-round evaluation
      if (judgeAgent && !abortRef.current) {
        const judgeHistory = conversationHistoryRef.current.map(m => {
          const a = meetingAgents.find(x => x.id === m.agentId);
          return `[${a?.nameKo || m.agentId}]: ${m.content}`;
        }).join("\n\n");

        const judgePrompt = `토론 주제: "${topic}"\n\n당신은 ${judgeAgent.nameKo}(${judgeAgent.role})이며, 이 토론의 **심판**입니다.\n\n지금까지의 토론 내용:\n${judgeHistory}\n\n라운드 ${r + 1} 종료 후 중간 평가를 해주세요:\n1. 이번 라운드에서 각 측의 논증 강도 평가 (5점 만점)\n2. 핵심 쟁점 정리\n3. 다음 라운드에서 보완이 필요한 부분\n\n간결하게 1-2문단으로 평가하세요.`;

        await streamAgentMessage(judgeAgent, judgePrompt, "judge");
      }

      // Pause between rounds for user input (except last)
      if (r < debateRounds - 1 && !abortRef.current) {
        setIsPaused(true);
        setCurrentSpeaker(null);
        setMessages(prev => [...prev, {
          agentId: "pause",
          content: `라운드 ${r + 1} 종료. 의견을 추가하거나 계속 진행하세요.`,
          timestamp: new Date(),
          isStreaming: false,
        }]);
        await waitForResume();
      }
    }

    // Generate verdict/summary
    if (!abortRef.current && conversationHistoryRef.current.length > 0) {
      setCurrentSpeaker("summary");
      const allDiscussion = conversationHistoryRef.current.map(m => {
        const a = meetingAgents.find(x => x.id === m.agentId);
        return `[${a?.nameKo}]: ${m.content}`;
      }).join("\n\n");

      setMessages(prev => [...prev, {
        agentId: "summary", content: "", timestamp: new Date(), isStreaming: true,
      }]);

      let summaryText = "";
      await streamChat({
        messages: [{ role: "user", content: `다음은 "${topic}" 주제에 대한 찬반 토론 내용입니다.\n\n찬성 측: ${proAgent.nameKo}\n반대 측: ${conAgent.nameKo}\n\n토론 내용:\n${allDiscussion}\n\n중립적 심판 입장에서 다음을 정리하세요:\n1. **찬성 측 핵심 논거** 요약\n2. **반대 측 핵심 논거** 요약\n3. **논쟁의 핵심 쟁점**\n4. **종합 판정**: 양측 주장의 강약점을 분석한 균형 잡힌 결론\n5. **권고 사항**: 의사결정을 위한 제안` }],
        onDelta: (chunk) => {
          summaryText += chunk;
          setMessages(prev => {
            const updated = [...prev];
            updated[updated.length - 1] = { ...updated[updated.length - 1], content: summaryText };
            return updated;
          });
        },
        onDone: () => {
          setMessages(prev => {
            const updated = [...prev];
            updated[updated.length - 1] = { ...updated[updated.length - 1], isStreaming: false };
            return updated;
          });
        },
        onError: (err) => toast.error(err),
      });
    }

    setCurrentSpeaker(null);
    setIsRunning(false);
    setIsPaused(false);
    setShowVerdictPanel(true);
    toast.success("찬반 토론이 종료되었습니다. 최종 판정을 내려주세요!");
  }, [topic, proAgentId, conAgentId, debateRounds, judgeAgentId]);

  const stopMeeting = () => {
    abortRef.current = true;
    setIsRunning(false);
    setCurrentSpeaker(null);
    setIsPaused(false);
    if (pauseResolveRef.current) {
      pauseResolveRef.current();
      pauseResolveRef.current = null;
    }
  };

  const resetMeeting = () => {
    setMessages([]);
    setShowSetup(true);
    setRound(0);
    setCurrentSpeaker(null);
    abortRef.current = false;
    setSavedAsReport(false);
    setTaskSaveState("idle");
    setIsPaused(false);
    setUserInput("");
    setUserVerdict(null);
    setVerdictReason("");
    setShowVerdictPanel(false);
    setJudgeAgentId(null);
    setViewingDebate(null);
    userInterjectionRef.current = null;
    conversationHistoryRef.current = [];
  };

  const loadDebateHistory = useCallback(async () => {
    setLoadingHistory(true);
    try {
      const { data, error } = await supabase
        .from("debate_history")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(20);
      if (error) throw error;
      setDebateHistoryList(data || []);
    } catch {
      toast.error("토론 이력을 불러올 수 없습니다");
    } finally {
      setLoadingHistory(false);
    }
  }, []);

  const saveDebateToDb = useCallback(async (verdict: string, reason: string) => {
    setSavingDebate(true);
    try {
      const summaryMsg = messages.find(m => m.agentId === "summary");
      const msgData: StoredDebateMessage[] = messages
        .filter(m => m.agentId !== "pause")
        .map(m => ({
          agentId: m.agentId,
          content: m.content,
          timestamp: m.timestamp.toISOString(),
        }));

      const { error } = await supabase.from("debate_history").insert([{
        topic,
        pro_agent_id: proAgentId,
        con_agent_id: conAgentId,
        judge_agent_id: judgeAgentId,
        debate_rounds: debateRounds,
        messages: msgData as Json,
        verdict,
        verdict_reason: reason || null,
        summary: summaryMsg?.content || null,
      }]);
      if (error) throw error;
      toast.success("토론 이력이 저장되었습니다");
    } catch {
      toast.error("토론 이력 저장에 실패했습니다");
    } finally {
      setSavingDebate(false);
    }
  }, [messages, topic, proAgentId, conAgentId, judgeAgentId, debateRounds]);

  const deleteDebate = useCallback(async (id: string) => {
    try {
      const { error } = await supabase.from("debate_history").delete().eq("id", id);
      if (error) throw error;
      setDebateHistoryList(prev => prev.filter(d => d.id !== id));
      if (viewingDebate?.id === id) setViewingDebate(null);
      toast.success("토론 이력이 삭제되었습니다");
    } catch {
      toast.error("삭제에 실패했습니다");
    }
  }, [viewingDebate]);

  const resumeMeeting = () => {
    if (pauseResolveRef.current) {
      setIsPaused(false);
      pauseResolveRef.current();
      pauseResolveRef.current = null;
    }
  };

  const saveAsReport = async () => {
    setSavingReport(true);
    try {
      const allContent = messages
        .filter(m => m.agentId !== "pause")
        .map(m => {
          if (m.agentId === "summary") return `## 회의록 요약\n${m.content}`;
          if (m.agentId === "user") return `### [사용자 개입]\n${m.content}`;
          const a = getAgent(m.agentId);
          const badge = a?.category === "audit" ? "[감사]" : "[실무]";
          return `### ${badge} ${a?.nameKo || m.agentId}\n${m.content}`;
        })
        .join("\n\n---\n\n");

      const reportContent = `# 에이전트 회의 보고서\n\n**주제:** ${topic}\n**일시:** ${new Date().toLocaleString("ko-KR")}\n**참석:** ${meetingAgents.filter(a => selectedAgents.has(a.id)).map(a => `${a.nameKo}(${a.category === "audit" ? "감사" : "실무"})`).join(", ")}\n\n---\n\n${allContent}`;

      // Download as markdown file
      const blob = new Blob([reportContent], { type: "text/markdown;charset=utf-8" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `회의보고서_${new Date().toISOString().slice(0, 10)}.md`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setSavedAsReport(true);
      toast.success("회의 보고서가 다운로드되었습니다");
    } catch {
      toast.error("보고서 저장에 실패했습니다");
    } finally {
      setSavingReport(false);
    }
  };

  const convertToTasks = async () => {
    setSavingTasks(true);
    try {
      const summaryMsg = messages.find(m => m.agentId === "summary");
      const content = summaryMsg?.content || messages.map(m => m.content).join("\n");

      // Use AI to extract action items
      let extracted = "";
      await new Promise<void>((resolve) => {
        streamChat({
          messages: [{ role: "user", content: `다음 회의 내용에서 구체적인 액션 아이템/작업을 추출하세요. 각 작업을 JSON 배열로 반환하세요. 형식: [{"title":"...", "description":"...", "severity":"high|medium|low", "category":"delivery|quality|price"}]\n작업만 JSON으로 반환하고 다른 텍스트는 쓰지 마세요.\n\n${content}` }],
          onDelta: (chunk) => { extracted += chunk; },
          onDone: () => resolve(),
          onError: (err) => { toast.error(err); resolve(); },
        });
      });

      const parseResult = parseAgentMeetingActionItems(extracted);
      if (!parseResult.ok) {
        toast.error(parseResult.reason === "empty_array"
          ? "추출된 작업이 없습니다"
          : "작업 추출 결과가 올바르지 않습니다");
        return;
      }

      const createdAt = new Date().toISOString();
      const result = await persistAgentMeetingGatewayTasks({
        action_items: parseResult.action_items,
        topic,
        created_at: createdAt,
      });

      if (result.status === "partial") {
        setTaskSaveState("partial");
        toast.warning("작업은 생성됐지만 이벤트 기록에 실패했습니다");
        return;
      }

      setTaskSaveState("complete");
      if (result.created_task_count === 0 && result.repaired_event_count > 0) {
        toast.success(`${result.repaired_event_count}개의 이벤트 기록이 복구되었습니다`);
      } else if (result.created_task_count === 0) {
        toast.info("이미 등록된 Gateway 작업입니다");
      } else {
        toast.success(`${result.created_task_count}개의 Gateway 작업이 생성되었습니다`);
      }
    } catch {
      toast.error("작업 변환에 실패했습니다");
    } finally {
      setSavingTasks(false);
    }
  };

  const getAgent = (id: string) => meetingAgents.find(a => a.id === id);

  return (
    <div className="flex-1 h-full overflow-hidden flex flex-col">
      {/* Header */}
      <div className="flex-shrink-0 p-6 pb-0 space-y-4">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="p-1.5 rounded-lg hover:bg-secondary transition-colors">
            <ArrowLeft className="w-4 h-4 text-muted-foreground" />
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-semibold tracking-tight flex items-center gap-2">
              <Users className="w-5 h-5 text-primary" />
              에이전트 회의
            </h1>
            <p className="text-[13px] text-muted-foreground mt-0.5">
              AI 에이전트들이 주제에 대해 다각도로 논의합니다
            </p>
          </div>
          {!showSetup && (
            <div className="flex items-center gap-2">
              {isRunning ? (
                <button onClick={stopMeeting} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-destructive/10 text-destructive text-[11px] font-medium hover:bg-destructive/20 transition-colors">
                  <Pause className="w-3.5 h-3.5" /> 중단
                </button>
              ) : (
                <button onClick={resetMeeting} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-secondary text-secondary-foreground text-[11px] font-medium hover:bg-secondary/80 transition-colors">
                  <RotateCcw className="w-3.5 h-3.5" /> 새 회의
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {viewingDebate ? (
        /* Viewing past debate */
        <div className="flex-1 overflow-y-auto p-6 space-y-4 scrollbar-thin">
          <div className="flex items-center gap-2 mb-2">
            <button onClick={() => setViewingDebate(null)} className="p-1.5 rounded-lg hover:bg-secondary transition-colors">
              <ArrowLeft className="w-4 h-4 text-muted-foreground" />
            </button>
            <h2 className="text-[14px] font-semibold text-foreground">토론 이력 상세</h2>
          </div>

          <div className="p-4 rounded-xl bg-primary/5 border border-primary/10 space-y-2">
            <p className="text-[12px] font-semibold text-foreground">{viewingDebate.topic}</p>
            <div className="flex items-center gap-4 text-[10px]">
              <span className="flex items-center gap-1">
                <ThumbsUp className="w-3 h-3 text-emerald-500" />
                <span className="text-emerald-600">찬성: {getAgent(viewingDebate.pro_agent_id)?.nameKo || viewingDebate.pro_agent_id}</span>
              </span>
              <span className="text-muted-foreground">vs</span>
              <span className="flex items-center gap-1">
                <ThumbsDown className="w-3 h-3 text-rose-500" />
                <span className="text-rose-600">반대: {getAgent(viewingDebate.con_agent_id)?.nameKo || viewingDebate.con_agent_id}</span>
              </span>
              {viewingDebate.judge_agent_id && (
                <>
                  <span className="text-muted-foreground">·</span>
                  <span className="flex items-center gap-1">
                    <Gavel className="w-3 h-3 text-amber-500" />
                    <span className="text-amber-600">심판: {getAgent(viewingDebate.judge_agent_id)?.nameKo || viewingDebate.judge_agent_id}</span>
                  </span>
                </>
              )}
            </div>
            <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
              <span>{new Date(viewingDebate.created_at).toLocaleString("ko-KR")}</span>
              <span>{viewingDebate.debate_rounds}라운드</span>
            </div>
            {viewingDebate.verdict && (
              <div className={`mt-2 p-3 rounded-lg border ${
                viewingDebate.verdict === "pro" ? "border-emerald-500/20 bg-emerald-500/5" :
                viewingDebate.verdict === "con" ? "border-rose-500/20 bg-rose-500/5" :
                "border-border/30 bg-secondary/10"
              }`}>
                <div className="flex items-center gap-2">
                  <Gavel className="w-3.5 h-3.5 text-primary" />
                  <span className="text-[11px] font-semibold">
                    판정: {viewingDebate.verdict === "pro" ? "찬성 승" : viewingDebate.verdict === "con" ? "반대 승" : "무승부"}
                  </span>
                </div>
                {viewingDebate.verdict_reason && (
                  <p className="text-[10px] text-muted-foreground mt-1">사유: {viewingDebate.verdict_reason}</p>
                )}
              </div>
            )}
          </div>

          {/* Messages */}
          {getStoredDebateMessages(viewingDebate.messages).map((msg, i) => {
            const isJudge = msg.agentId?.startsWith("judge-");
            const isDebateMsg = msg.agentId?.startsWith("pro-") || msg.agentId?.startsWith("con-");
            const stance = msg.agentId?.startsWith("pro-") ? "pro" : msg.agentId?.startsWith("con-") ? "con" : isJudge ? "judge" : null;
            const realId = (isDebateMsg || isJudge) ? msg.agentId.replace(/^(pro|con|judge)-/, "") : msg.agentId;
            const ag = getAgent(realId);
            const isSummary = msg.agentId === "summary";
            const isVerdict = msg.agentId === "verdict";
            const isUser = msg.agentId === "user" || msg.agentId === "user-directed";

            if (isVerdict) {
              return (
                <div key={i} className="rounded-2xl border-2 border-primary/30 bg-primary/5 p-4">
                  <div className="flex items-center gap-2 mb-1">
                    <Gavel className="w-3.5 h-3.5 text-primary" />
                    <span className="text-[11px] font-semibold text-primary">사용자 최종 판정</span>
                  </div>
                  <div className="prose prose-sm max-w-none text-[12px] text-secondary-foreground"><ReactMarkdown>{msg.content}</ReactMarkdown></div>
                </div>
              );
            }

            if (isUser) {
              return (
                <div key={i} className="rounded-2xl border border-blue-500/20 bg-blue-500/5 p-3 ml-8">
                  <div className="flex items-center gap-1.5 mb-1">
                    <User className="w-3 h-3 text-blue-500" />
                    <span className="text-[10px] font-semibold text-blue-500">사용자</span>
                  </div>
                  <div className="prose prose-sm max-w-none text-[12px] text-secondary-foreground"><ReactMarkdown>{msg.content}</ReactMarkdown></div>
                </div>
              );
            }

            return (
              <div key={i} className={`rounded-2xl border p-3 ${
                isSummary ? "bg-primary/5 border-primary/20" :
                stance === "judge" ? "border-amber-500/20 bg-amber-500/[0.03]" :
                stance === "pro" ? "border-emerald-500/20 bg-emerald-500/[0.03]" :
                stance === "con" ? "border-rose-500/20 bg-rose-500/[0.03]" :
                "bg-secondary/10 border-border/20"
              }`}>
                <div className="flex items-center gap-2 mb-1">
                  {isSummary ? (
                    <>
                      <Swords className="w-3.5 h-3.5 text-primary" />
                      <span className="text-[11px] font-semibold text-primary">토론 판정</span>
                    </>
                  ) : ag ? (
                    <>
                      <ag.icon className="w-3.5 h-3.5" style={{ color: ag.color }} />
                      <span className="text-[11px] font-semibold" style={{ color: ag.color }}>{ag.nameKo}</span>
                      {stance && (
                        <span className={`text-[8px] px-1.5 py-0.5 rounded-md font-medium ${
                          stance === "pro" ? "bg-emerald-500/10 text-emerald-600" :
                          stance === "judge" ? "bg-amber-500/10 text-amber-600" :
                          "bg-rose-500/10 text-rose-600"
                        }`}>
                          {stance === "pro" ? "찬성" : stance === "judge" ? "심판" : "반대"}
                        </span>
                      )}
                    </>
                  ) : null}
                </div>
                <div className="prose prose-sm max-w-none text-[12px] text-secondary-foreground"><ReactMarkdown>{msg.content}</ReactMarkdown></div>
              </div>
            );
          })}
        </div>
      ) : showSetup ? (
        /* Setup Panel */
        <div className="flex-1 overflow-y-auto p-6 space-y-5 scrollbar-thin">
          {/* History Button */}
          <button
            onClick={() => { setShowHistory(!showHistory); if (!showHistory) loadDebateHistory(); }}
            className="w-full flex items-center justify-between py-2.5 px-4 rounded-xl bg-secondary/20 border border-border/20 hover:bg-secondary/30 transition-colors"
          >
            <div className="flex items-center gap-2">
              <History className="w-4 h-4 text-muted-foreground" />
              <span className="text-[12px] font-medium text-foreground">토론 이력 조회</span>
            </div>
            <span className="text-[10px] text-muted-foreground">{showHistory ? "닫기" : "열기"}</span>
          </button>

          {/* History List */}
          <AnimatePresence>
            {showHistory && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="space-y-2 overflow-hidden"
              >
                {loadingHistory ? (
                  <div className="flex items-center justify-center py-6">
                    <Loader2 className="w-4 h-4 animate-spin text-muted-foreground" />
                  </div>
                ) : debateHistoryList.length === 0 ? (
                  <p className="text-[11px] text-muted-foreground text-center py-4">저장된 토론 이력이 없습니다</p>
                ) : (
                  debateHistoryList.map(debate => (
                    <div key={debate.id} className="p-3 rounded-xl bg-secondary/10 border border-border/20 space-y-1.5">
                      <div className="flex items-start justify-between">
                        <p className="text-[11px] font-medium text-foreground leading-snug flex-1">{debate.topic}</p>
                        <div className="flex items-center gap-1 flex-shrink-0 ml-2">
                          <button onClick={() => setViewingDebate(debate)} className="p-1 rounded-md hover:bg-secondary transition-colors">
                            <Eye className="w-3 h-3 text-muted-foreground" />
                          </button>
                          <button onClick={() => deleteDebate(debate.id)} className="p-1 rounded-md hover:bg-destructive/10 transition-colors">
                            <Trash2 className="w-3 h-3 text-destructive/60" />
                          </button>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 text-[9px] text-muted-foreground">
                        <span>{new Date(debate.created_at).toLocaleDateString("ko-KR")}</span>
                        <span>·</span>
                        <span>{getAgent(debate.pro_agent_id)?.nameKo || "?"} vs {getAgent(debate.con_agent_id)?.nameKo || "?"}</span>
                        {debate.verdict && (
                          <>
                            <span>·</span>
                            <span className={
                              debate.verdict === "pro" ? "text-emerald-500" :
                              debate.verdict === "con" ? "text-rose-500" :
                              "text-foreground"
                            }>
                              {debate.verdict === "pro" ? "찬성 승" : debate.verdict === "con" ? "반대 승" : "무승부"}
                            </span>
                          </>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </motion.div>
            )}
          </AnimatePresence>
          {/* Mode Toggle */}
          <div className="flex rounded-xl bg-secondary/30 border border-border/30 p-1 gap-1">
            <button
              onClick={() => setMeetingMode("meeting")}
              className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-[12px] font-semibold transition-all ${
                meetingMode === "meeting" ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Users className="w-3.5 h-3.5" /> 다자 회의
            </button>
            <button
              onClick={() => setMeetingMode("debate")}
              className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-[12px] font-semibold transition-all ${
                meetingMode === "debate" ? "bg-primary text-primary-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Swords className="w-3.5 h-3.5" /> 찬반 토론
            </button>
          </div>

          {/* Topic Input */}
          <div className="space-y-2">
            <label className="text-[12px] font-semibold text-foreground">
              {meetingMode === "debate" ? "토론 주제 (찬반이 나뉠 수 있는 주제)" : "회의 주제"}
            </label>
            <textarea
              value={topic}
              onChange={e => setTopic(e.target.value)}
              placeholder={meetingMode === "debate" ? "예: 원자재 가격 인상분을 고객에게 전가해야 하는가?" : "에이전트들이 논의할 주제를 입력하세요..."}
              rows={3}
              className="w-full p-3 rounded-xl bg-secondary/30 border border-border/30 text-[13px] text-foreground placeholder:text-muted-foreground resize-none outline-none focus:ring-1 focus:ring-primary/30"
            />
          </div>

          {/* Preset Topics */}
          <div className="space-y-2">
            <label className="text-[10px] font-medium text-muted-foreground uppercase tracking-wider">
              {meetingMode === "debate" ? "추천 토론 주제" : "추천 주제"}
            </label>
            <div className="flex flex-wrap gap-2">
              {meetingMode === "debate" ? (
                <>
                  {[
                    { label: "가격 인상 전가", topic: "원자재 가격 인상분을 고객에게 전가해야 하는가?" },
                    { label: "신규 설비 투자", topic: "현 시점에서 신규 생산 설비에 대한 대규모 투자를 진행해야 하는가?" },
                    { label: "독점 공급 계약", topic: "현대자동차와 독점 공급 계약을 체결해야 하는가?" },
                    { label: "해외 시장 진출", topic: "동남아 시장에 직접 진출해야 하는가, 현지 파트너십을 통해야 하는가?" },
                  ].map((p, i) => (
                    <button key={i} onClick={() => setTopic(p.topic)}
                      className="px-3 py-1.5 rounded-lg bg-primary/5 border border-primary/10 text-[11px] text-primary hover:bg-primary/10 transition-colors"
                    >{p.label}</button>
                  ))}
                </>
              ) : (
                presetTopics.map((p, i) => (
                  <button key={i} onClick={() => { setTopic(p.topic); if (autoSelect) autoSelectAgents(); }}
                    className="px-3 py-1.5 rounded-lg bg-primary/5 border border-primary/10 text-[11px] text-primary hover:bg-primary/10 transition-colors"
                  >{p.label}</button>
                ))
              )}
            </div>
          </div>

          {meetingMode === "debate" ? (
            /* Debate Setup */
            <div className="space-y-4">
              {/* Pro/Con Agent Selection */}
              <div className="grid grid-cols-2 gap-4">
                {/* Pro side */}
                <div className="space-y-2">
                  <div className="flex items-center gap-1.5">
                    <ThumbsUp className="w-3.5 h-3.5 text-emerald-500" />
                    <label className="text-[11px] font-semibold text-emerald-600">찬성 측</label>
                  </div>
                  <div className="space-y-1.5">
                    {meetingAgents.map(agent => (
                      <button
                        key={agent.id}
                        onClick={() => setProAgentId(agent.id)}
                        className={`w-full p-2.5 rounded-xl border text-left transition-all ${
                          proAgentId === agent.id
                            ? "border-emerald-500/30 bg-emerald-500/5"
                            : "border-border/20 bg-secondary/10 opacity-50 hover:opacity-75"
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 rounded-lg flex items-center justify-center" style={{ background: `${agent.color}20` }}>
                            <agent.icon className="w-3 h-3" style={{ color: agent.color }} />
                          </div>
                          <div>
                            <p className="text-[10px] font-medium text-foreground">{agent.nameKo}</p>
                            <p className="text-[8px] text-muted-foreground">{agent.category === "audit" ? "감사" : "실무"}</p>
                          </div>
                          {proAgentId === agent.id && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 ml-auto" />}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Con side */}
                <div className="space-y-2">
                  <div className="flex items-center gap-1.5">
                    <ThumbsDown className="w-3.5 h-3.5 text-rose-500" />
                    <label className="text-[11px] font-semibold text-rose-600">반대 측</label>
                  </div>
                  <div className="space-y-1.5">
                    {meetingAgents.map(agent => (
                      <button
                        key={agent.id}
                        onClick={() => setConAgentId(agent.id)}
                        className={`w-full p-2.5 rounded-xl border text-left transition-all ${
                          conAgentId === agent.id
                            ? "border-rose-500/30 bg-rose-500/5"
                            : "border-border/20 bg-secondary/10 opacity-50 hover:opacity-75"
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <div className="w-6 h-6 rounded-lg flex items-center justify-center" style={{ background: `${agent.color}20` }}>
                            <agent.icon className="w-3 h-3" style={{ color: agent.color }} />
                          </div>
                          <div>
                            <p className="text-[10px] font-medium text-foreground">{agent.nameKo}</p>
                            <p className="text-[8px] text-muted-foreground">{agent.category === "audit" ? "감사" : "실무"}</p>
                          </div>
                          {conAgentId === agent.id && <CheckCircle2 className="w-3.5 h-3.5 text-rose-500 ml-auto" />}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Judge Agent Selection */}
              <div className="space-y-2">
                <div className="flex items-center gap-1.5">
                  <Gavel className="w-3.5 h-3.5 text-amber-500" />
                  <label className="text-[11px] font-semibold text-amber-600">심판 에이전트 (선택)</label>
                </div>
                <div className="space-y-1.5">
                  <button
                    onClick={() => setJudgeAgentId(null)}
                    className={`w-full p-2.5 rounded-xl border text-left transition-all ${
                      !judgeAgentId
                        ? "border-amber-500/30 bg-amber-500/5"
                        : "border-border/20 bg-secondary/10 opacity-50 hover:opacity-75"
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-lg bg-secondary/30 flex items-center justify-center">
                        <Scale className="w-3 h-3 text-muted-foreground" />
                      </div>
                      <p className="text-[10px] font-medium text-muted-foreground">심판 없음</p>
                      {!judgeAgentId && <CheckCircle2 className="w-3.5 h-3.5 text-amber-500 ml-auto" />}
                    </div>
                  </button>
                  {meetingAgents.filter(a => a.id !== proAgentId && a.id !== conAgentId).map(agent => (
                    <button
                      key={agent.id}
                      onClick={() => setJudgeAgentId(agent.id)}
                      className={`w-full p-2.5 rounded-xl border text-left transition-all ${
                        judgeAgentId === agent.id
                          ? "border-amber-500/30 bg-amber-500/5"
                          : "border-border/20 bg-secondary/10 opacity-50 hover:opacity-75"
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <div className="w-6 h-6 rounded-lg flex items-center justify-center" style={{ background: `${agent.color}20` }}>
                          <agent.icon className="w-3 h-3" style={{ color: agent.color }} />
                        </div>
                        <div>
                          <p className="text-[10px] font-medium text-foreground">{agent.nameKo}</p>
                          <p className="text-[8px] text-muted-foreground">{agent.category === "audit" ? "감사" : "실무"}</p>
                        </div>
                        {judgeAgentId === agent.id && <CheckCircle2 className="w-3.5 h-3.5 text-amber-500 ml-auto" />}
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Debate rounds */}
              <div className="space-y-2">
                <label className="text-[12px] font-semibold text-foreground">토론 라운드 수</label>
                <div className="flex gap-2">
                  {[2, 3, 4, 5].map(n => (
                    <button
                      key={n}
                      onClick={() => setDebateRounds(n)}
                      className={`flex-1 py-2 rounded-xl text-[12px] font-medium border transition-all ${
                        debateRounds === n
                          ? "bg-primary/10 text-primary border-primary/30"
                          : "bg-secondary/20 text-muted-foreground border-border/20 hover:bg-secondary/40"
                      }`}
                    >{n}라운드</button>
                  ))}
                </div>
              </div>

              {proAgentId === conAgentId && (
                <p className="text-[10px] text-destructive">⚠ 찬성과 반대 측에 서로 다른 에이전트를 선택해주세요</p>
              )}
            </div>
          ) : (
            /* Meeting Agent Selection (existing) */
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-[12px] font-semibold text-foreground">참석 에이전트</label>
                <button
                  onClick={() => { setAutoSelect(!autoSelect); if (!autoSelect && topic) autoSelectAgents(); }}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-[10px] font-medium transition-colors ${
                    autoSelect ? "bg-primary/10 text-primary" : "bg-secondary/50 text-muted-foreground hover:bg-secondary"
                  }`}
                >
                  <Sparkles className="w-3 h-3" />
                  {autoSelect ? "자동 선택 ON" : "자동 선택"}
                </button>
              </div>

              {/* 실무 에이전트 */}
              <div>
                <div className="flex items-center gap-1.5 mb-2">
                  <Zap className="w-3 h-3 text-primary" />
                  <span className="text-[10px] font-semibold text-primary uppercase tracking-wider">실무 에이전트</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {meetingAgents.filter(a => a.category === "operational").map(agent => {
                    const isSelected = selectedAgents.has(agent.id);
                    return (
                      <motion.button key={agent.id} whileTap={{ scale: 0.98 }}
                        onClick={() => { if (!autoSelect) toggleAgent(agent.id); }}
                        className={`p-3 rounded-xl border text-left transition-all ${
                          isSelected ? "border-primary/30 bg-primary/5" : "border-border/30 bg-secondary/10 opacity-50"
                        } ${autoSelect ? "cursor-default" : "hover:border-border/60"}`}
                      >
                        <div className="flex items-center gap-2.5">
                          <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: `${agent.color}20` }}>
                            <agent.icon className="w-3.5 h-3.5" style={{ color: agent.color }} />
                          </div>
                          <div>
                            <p className="text-[11px] font-medium text-foreground">{agent.nameKo}</p>
                            <p className="text-[9px] text-muted-foreground">{agent.role}</p>
                          </div>
                          {isSelected && <CheckCircle2 className="w-4 h-4 text-primary ml-auto" />}
                        </div>
                      </motion.button>
                    );
                  })}
                </div>
              </div>

              {/* 감사 에이전트 */}
              <div>
                <div className="flex items-center gap-1.5 mb-2">
                  <Scale className="w-3 h-3 text-status-review" />
                  <span className="text-[10px] font-semibold text-status-review uppercase tracking-wider">감사 에이전트</span>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  {meetingAgents.filter(a => a.category === "audit").map(agent => {
                    const isSelected = selectedAgents.has(agent.id);
                    return (
                      <motion.button key={agent.id} whileTap={{ scale: 0.98 }}
                        onClick={() => { if (!autoSelect) toggleAgent(agent.id); }}
                        className={`p-3 rounded-xl border text-left transition-all ${
                          isSelected ? "bg-status-review/5" : "bg-secondary/10 opacity-50"
                        } ${autoSelect ? "cursor-default" : "hover:border-status-review/40"}`}
                        style={{ borderColor: isSelected ? "hsl(var(--status-review) / 0.3)" : undefined }}
                      >
                        <div className="flex items-center gap-2.5">
                          <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: `${agent.color}15` }}>
                            <agent.icon className="w-3.5 h-3.5" style={{ color: agent.color }} />
                          </div>
                          <div>
                            <p className="text-[11px] font-medium text-foreground">{agent.nameKo}</p>
                            <p className="text-[9px] text-muted-foreground">{agent.role}</p>
                          </div>
                          {isSelected && <CheckCircle2 className="w-4 h-4 text-status-review ml-auto" />}
                        </div>
                      </motion.button>
                    );
                  })}
                </div>
              </div>

              <p className="text-[10px] text-muted-foreground">
                {selectedAgents.size}명 선택됨 · 최소 2명 이상 선택해야 합니다
              </p>
            </div>
          )}

          {/* Start Button */}
          <motion.button
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.99 }}
            onClick={meetingMode === "debate" ? startDebate : startMeeting}
            disabled={meetingMode === "debate" ? (!topic.trim() || proAgentId === conAgentId) : (!topic.trim() || selectedAgents.size < 2)}
            className="w-full py-3 rounded-xl bg-primary text-primary-foreground text-[13px] font-semibold flex items-center justify-center gap-2 disabled:opacity-30 disabled:cursor-not-allowed transition-opacity"
          >
            {meetingMode === "debate" ? <Swords className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            {meetingMode === "debate" ? "토론 시작" : "회의 시작"}
          </motion.button>
        </div>
      ) : (
        /* Meeting View */
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Status bar */}
          <div className="flex-shrink-0 px-6 py-3 border-b border-border/30">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex -space-x-2">
                  {meetingAgents.filter(a => selectedAgents.has(a.id)).map(a => (
                    <div
                      key={a.id}
                      className={`w-7 h-7 rounded-full border-2 border-background flex items-center justify-center ${
                        currentSpeaker === a.id ? "ring-2 ring-primary ring-offset-1 ring-offset-background" : ""
                      }`}
                      style={{ background: `${a.color}30` }}
                    >
                      <a.icon className="w-3 h-3" style={{ color: a.color }} />
                    </div>
                  ))}
                </div>
                <div>
                  <p className="text-[11px] font-medium">
                    {isRunning && !isPaused ? (
                      <>
                        <span className="text-primary">라운드 {round}</span> 진행 중
                        {currentSpeaker && currentSpeaker !== "summary" && (
                          <> · <span style={{ color: getAgent(currentSpeaker)?.color }}>{getAgent(currentSpeaker)?.nameKo}</span> 발언 중</>
                        )}
                        {currentSpeaker === "summary" && (
                          <> · <span className="text-primary">회의록 작성 중</span></>
                        )}
                      </>
                    ) : isPaused ? (
                      <span className="text-amber-500">⏸ 일시정지 — 사용자 의견 대기 중</span>
                    ) : (
                      <span className="text-muted-foreground">회의 종료</span>
                    )}
                  </p>
                </div>
              </div>
              {isRunning && (
                <div className="flex items-center gap-1.5">
                  <Loader2 className="w-3.5 h-3.5 text-primary animate-spin" />
                  <span className="text-[10px] text-muted-foreground">{messages.length}개 발언</span>
                </div>
              )}
            </div>
          </div>

          {/* Messages */}
          <div ref={scrollRef} className="flex-1 overflow-y-auto px-6 py-4 space-y-4 scrollbar-thin">
            {/* Topic banner */}
            <div className="p-4 rounded-xl bg-primary/5 border border-primary/10">
              <div className="flex items-center gap-2 mb-1.5">
                {meetingMode === "debate" ? <Swords className="w-3.5 h-3.5 text-primary" /> : <Settings2 className="w-3.5 h-3.5 text-primary" />}
                <span className="text-[10px] font-semibold text-primary uppercase tracking-wider">
                  {meetingMode === "debate" ? "토론 주제" : "회의 주제"}
                </span>
              </div>
              <p className="text-[12px] text-foreground leading-relaxed">{topic}</p>
              {meetingMode === "debate" && (
                <div className="flex items-center gap-4 mt-2 pt-2 border-t border-primary/10">
                  <span className="flex items-center gap-1.5 text-[10px]">
                    <ThumbsUp className="w-3 h-3 text-emerald-500" />
                    <span className="font-medium text-emerald-600">찬성: {getAgent(proAgentId)?.nameKo}</span>
                  </span>
                  <span className="text-[10px] text-muted-foreground">vs</span>
                  <span className="flex items-center gap-1.5 text-[10px]">
                    <ThumbsDown className="w-3 h-3 text-rose-500" />
                    <span className="font-medium text-rose-600">반대: {getAgent(conAgentId)?.nameKo}</span>
                  </span>
                  {judgeAgentId && (
                    <>
                      <span className="text-[10px] text-muted-foreground">·</span>
                      <span className="flex items-center gap-1.5 text-[10px]">
                        <Gavel className="w-3 h-3 text-amber-500" />
                        <span className="font-medium text-amber-600">심판: {getAgent(judgeAgentId)?.nameKo}</span>
                      </span>
                    </>
                  )}
                </div>
              )}
            </div>

            <AnimatePresence>
              {messages.map((msg, i) => {
                const isJudgeMsg = msg.agentId.startsWith("judge-");
                const isDebateMsg = msg.agentId.startsWith("pro-") || msg.agentId.startsWith("con-");
                const debateStance = msg.agentId.startsWith("pro-") ? "pro" : msg.agentId.startsWith("con-") ? "con" : isJudgeMsg ? "judge" : null;
                const realAgentId = (isDebateMsg || isJudgeMsg) ? msg.agentId.replace(/^(pro|con|judge)-/, "") : msg.agentId;
                const agent = getAgent(realAgentId);
                const isSummary = msg.agentId === "summary";
                const isUser = msg.agentId === "user" || msg.agentId === "user-directed";
                const isPauseMsg = msg.agentId === "pause";

                if (msg.agentId === "verdict") {
                  return (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, y: 15, scale: 0.98 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      className="rounded-2xl border-2 border-primary/30 bg-primary/5 p-5"
                    >
                      <div className="flex items-center gap-2.5 mb-2">
                        <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center">
                          <Gavel className="w-3.5 h-3.5 text-primary" />
                        </div>
                        <p className="text-[11px] font-semibold text-primary">사용자 최종 판정</p>
                      </div>
                      <div className="prose prose-sm max-w-none text-[12px] leading-relaxed text-secondary-foreground">
                        <ReactMarkdown>{msg.content}</ReactMarkdown>
                      </div>
                    </motion.div>
                  );
                }

                if (isPauseMsg) {
                  return (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="flex items-center gap-3 py-3"
                    >
                      <div className="flex-1 h-px bg-border/40" />
                      <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-accent/50 border border-border/30">
                        <Hand className="w-3 h-3 text-muted-foreground" />
                        <span className="text-[10px] text-muted-foreground font-medium">라운드 종료 · 의견을 추가할 수 있습니다</span>
                      </div>
                      <div className="flex-1 h-px bg-border/40" />
                    </motion.div>
                  );
                }

                if (isUser) {
                  return (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, y: 15, scale: 0.98 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      transition={{ duration: 0.3 }}
                      className="rounded-2xl border border-blue-500/20 bg-blue-500/5 p-4 ml-8"
                    >
                      <div className="flex items-center gap-2.5 mb-2">
                        <div className="w-7 h-7 rounded-lg bg-blue-500/10 flex items-center justify-center">
                          <User className="w-3.5 h-3.5 text-blue-500" />
                        </div>
                        <div className="flex items-center gap-1.5">
                          <p className="text-[11px] font-semibold text-blue-500">사용자</p>
                          <span className={`text-[8px] px-1.5 py-0.5 rounded-md font-medium ${
                            msg.agentId === "user-directed" 
                              ? "bg-amber-500/10 text-amber-600" 
                              : "bg-blue-500/10 text-blue-500"
                          }`}>
                            {msg.agentId === "user-directed" ? "지목 질문" : "개입"}
                          </span>
                        </div>
                      </div>
                      <div className="prose prose-sm max-w-none text-[12px] leading-relaxed text-secondary-foreground">
                        <ReactMarkdown>{msg.content}</ReactMarkdown>
                      </div>
                    </motion.div>
                  );
                }

                return (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 15, scale: 0.98 }}
                    animate={{ opacity: 1, y: 0, scale: 1 }}
                    transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                    className={`rounded-2xl border ${
                      isSummary
                        ? "bg-primary/5 border-primary/20 p-5"
                        : debateStance === "judge"
                          ? "border-amber-500/20 bg-amber-500/[0.03] p-4"
                          : debateStance === "pro"
                            ? "border-emerald-500/20 bg-emerald-500/[0.03] p-4"
                            : debateStance === "con"
                              ? "border-rose-500/20 bg-rose-500/[0.03] p-4"
                              : agent?.category === "audit"
                                ? "border-status-review/20 p-4"
                                : "bg-secondary/10 border-border/20 p-4"
                    }`}
                    style={!isSummary && !debateStance && agent?.category === "audit" ? { background: "hsl(var(--status-review) / 0.03)" } : {}}
                  >
                    <div className="flex items-center gap-2.5 mb-2">
                      {isSummary ? (
                        <>
                          <div className="w-7 h-7 rounded-lg bg-primary/10 flex items-center justify-center">
                            {meetingMode === "debate" ? <Swords className="w-3.5 h-3.5 text-primary" /> : <Sparkles className="w-3.5 h-3.5 text-primary" />}
                          </div>
                          <div>
                            <p className="text-[11px] font-semibold text-primary">
                              {meetingMode === "debate" ? "토론 판정" : "회의록 요약"}
                            </p>
                            <p className="text-[9px] text-muted-foreground">
                              {meetingMode === "debate" ? "Debate Verdict" : "Meeting Summary"}
                            </p>
                          </div>
                        </>
                      ) : agent ? (
                        <>
                          <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: `${agent.color}20` }}>
                            <agent.icon className="w-3.5 h-3.5" style={{ color: agent.color }} />
                          </div>
                          <div className="flex items-center gap-1.5">
                            <p className="text-[11px] font-semibold" style={{ color: agent.color }}>{agent.nameKo}</p>
                            {debateStance ? (
                              <span className={`text-[8px] px-1.5 py-0.5 rounded-md font-medium flex items-center gap-0.5 ${
                                debateStance === "pro"
                                  ? "bg-emerald-500/10 text-emerald-600"
                                  : debateStance === "judge"
                                    ? "bg-amber-500/10 text-amber-600"
                                    : "bg-rose-500/10 text-rose-600"
                              }`}>
                                {debateStance === "pro" ? <ThumbsUp className="w-2.5 h-2.5" /> : debateStance === "judge" ? <Gavel className="w-2.5 h-2.5" /> : <ThumbsDown className="w-2.5 h-2.5" />}
                                {debateStance === "pro" ? "찬성" : debateStance === "judge" ? "심판 평가" : "반대"}
                              </span>
                            ) : (
                              <span className={`text-[8px] px-1.5 py-0.5 rounded-md font-medium ${
                                agent.category === "audit"
                                  ? "bg-status-review/10 text-status-review"
                                  : "bg-primary/10 text-primary"
                              }`}>
                                {agent.category === "audit" ? "감사" : "실무"}
                              </span>
                            )}
                          </div>
                          {!debateStance && <p className="text-[9px] text-muted-foreground">{agent.role}</p>}
                        </>
                      ) : null}
                      {msg.isStreaming && (
                        <Loader2 className="w-3 h-3 text-primary animate-spin ml-auto" />
                      )}
                    </div>
                    <div className="prose prose-sm max-w-none text-[12px] leading-relaxed text-secondary-foreground">
                      <ReactMarkdown>{msg.content || "..."}</ReactMarkdown>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>

          {/* User input bar during meeting */}
          {(isRunning || isPaused) && (
            <div className="flex-shrink-0 px-6 py-3 border-t border-border/30 space-y-2">
              {isPaused && (
                <div className="flex items-center justify-between">
                  <p className="text-[11px] text-muted-foreground">의견을 입력하거나, 바로 다음 라운드를 진행하세요</p>
                  <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={resumeMeeting}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary text-primary-foreground text-[11px] font-medium"
                  >
                    <Play className="w-3 h-3" /> 계속 진행
                  </motion.button>
                </div>
              )}

              {/* Agent mention chips */}
              <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none">
                <AtSign className="w-3 h-3 text-muted-foreground flex-shrink-0" />
                <span className="text-[9px] text-muted-foreground flex-shrink-0">지목:</span>
                {meetingAgents.filter(a => selectedAgents.has(a.id)).map(agent => (
                  <button
                    key={agent.id}
                    onClick={() => setTargetAgentId(targetAgentId === agent.id ? null : agent.id)}
                    disabled={isAskingAgent}
                    className={`flex items-center gap-1 px-2 py-1 rounded-lg text-[10px] font-medium transition-all flex-shrink-0 ${
                      targetAgentId === agent.id
                        ? agent.category === "audit"
                          ? "bg-status-review/15 text-status-review ring-1 ring-status-review/30"
                          : "bg-primary/15 text-primary ring-1 ring-primary/30"
                        : "bg-secondary/50 text-muted-foreground hover:bg-secondary"
                    }`}
                  >
                    <agent.icon className="w-2.5 h-2.5" />
                    {agent.nameKo}
                  </button>
                ))}
              </div>

              {/* Input row */}
              <div className="flex items-center gap-2">
                <div className="flex-1 relative">
                  {targetAgentId && (
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 flex items-center gap-1 text-[10px] font-semibold" style={{ color: getAgent(targetAgentId)?.color }}>
                      @{getAgent(targetAgentId)?.nameKo}
                    </span>
                  )}
                  <input
                    type="text"
                    value={userInput}
                    onChange={e => setUserInput(e.target.value)}
                    onKeyDown={e => {
                      if (e.key === "Enter" && !e.shiftKey) {
                        e.preventDefault();
                        if (targetAgentId) {
                          void askSpecificAgent();
                        } else {
                          submitUserInterjection();
                        }
                      }
                    }}
                    placeholder={targetAgentId ? `${getAgent(targetAgentId)?.nameKo}에게 질문...` : isPaused ? "에이전트들에게 전달할 의견을 입력하세요..." : "회의 중 의견 추가..."}
                    className="w-full py-2.5 rounded-xl bg-secondary/30 border border-border/30 text-[12px] text-foreground placeholder:text-muted-foreground outline-none focus:ring-1 focus:ring-primary/30 pr-10"
                    style={{ paddingLeft: targetAgentId ? `${(getAgent(targetAgentId)?.nameKo?.length || 3) * 10 + 28}px` : "16px" }}
                    disabled={isAskingAgent}
                  />
                  <button
                    onClick={() => {
                      if (targetAgentId) {
                        void askSpecificAgent();
                      } else {
                        submitUserInterjection();
                      }
                    }}
                    disabled={!userInput.trim() || isAskingAgent}
                    className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-lg text-primary hover:bg-primary/10 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                  >
                    {isAskingAgent ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Debate Verdict Panel */}
          {showVerdictPanel && meetingMode === "debate" && !isRunning && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex-shrink-0 px-6 py-4 border-t border-border/30 space-y-3"
            >
              {!userVerdict ? (
                <>
                  <div className="flex items-center gap-2">
                    <Gavel className="w-4 h-4 text-primary" />
                    <p className="text-[12px] font-semibold text-foreground">최종 판정을 내려주세요</p>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <motion.button
                      whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
                      onClick={() => setUserVerdict("pro")}
                      className="flex flex-col items-center gap-1.5 py-3 rounded-xl border border-emerald-500/20 bg-emerald-500/5 hover:bg-emerald-500/10 transition-all"
                    >
                      <ThumbsUp className="w-5 h-5 text-emerald-500" />
                      <span className="text-[11px] font-semibold text-emerald-600">찬성 승</span>
                      <span className="text-[9px] text-muted-foreground">{getAgent(proAgentId)?.nameKo}</span>
                    </motion.button>
                    <motion.button
                      whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
                      onClick={() => setUserVerdict("neutral")}
                      className="flex flex-col items-center gap-1.5 py-3 rounded-xl border border-border/30 bg-secondary/10 hover:bg-secondary/20 transition-all"
                    >
                      <Scale className="w-5 h-5 text-muted-foreground" />
                      <span className="text-[11px] font-semibold text-foreground">무승부</span>
                      <span className="text-[9px] text-muted-foreground">양측 동등</span>
                    </motion.button>
                    <motion.button
                      whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
                      onClick={() => setUserVerdict("con")}
                      className="flex flex-col items-center gap-1.5 py-3 rounded-xl border border-rose-500/20 bg-rose-500/5 hover:bg-rose-500/10 transition-all"
                    >
                      <ThumbsDown className="w-5 h-5 text-rose-500" />
                      <span className="text-[11px] font-semibold text-rose-600">반대 승</span>
                      <span className="text-[9px] text-muted-foreground">{getAgent(conAgentId)?.nameKo}</span>
                    </motion.button>
                  </div>
                </>
              ) : (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-3">
                  {/* Verdict result */}
                  <div className={`p-4 rounded-xl border ${
                    userVerdict === "pro" ? "border-emerald-500/20 bg-emerald-500/5" :
                    userVerdict === "con" ? "border-rose-500/20 bg-rose-500/5" :
                    "border-border/30 bg-secondary/10"
                  }`}>
                    <div className="flex items-center gap-2 mb-2">
                      <Gavel className="w-4 h-4 text-primary" />
                      <span className="text-[12px] font-semibold text-foreground">최종 판정 결과</span>
                    </div>
                    <div className="flex items-center gap-3">
                      {userVerdict === "pro" && (
                        <>
                          <ThumbsUp className="w-6 h-6 text-emerald-500" />
                          <div>
                            <p className="text-[13px] font-bold text-emerald-600">찬성 측 승리</p>
                            <p className="text-[10px] text-muted-foreground">{getAgent(proAgentId)?.nameKo}의 주장이 채택되었습니다</p>
                          </div>
                        </>
                      )}
                      {userVerdict === "con" && (
                        <>
                          <ThumbsDown className="w-6 h-6 text-rose-500" />
                          <div>
                            <p className="text-[13px] font-bold text-rose-600">반대 측 승리</p>
                            <p className="text-[10px] text-muted-foreground">{getAgent(conAgentId)?.nameKo}의 주장이 채택되었습니다</p>
                          </div>
                        </>
                      )}
                      {userVerdict === "neutral" && (
                        <>
                          <Scale className="w-6 h-6 text-muted-foreground" />
                          <div>
                            <p className="text-[13px] font-bold text-foreground">무승부</p>
                            <p className="text-[10px] text-muted-foreground">양측 주장이 동등하게 평가되었습니다</p>
                          </div>
                        </>
                      )}
                    </div>
                  </div>

                  {/* Verdict reason input */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-medium text-muted-foreground">판정 사유 (선택)</label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={verdictReason}
                        onChange={e => setVerdictReason(e.target.value)}
                        placeholder="판정 이유를 간단히 기록하세요..."
                        className="flex-1 px-3 py-2 rounded-xl bg-secondary/30 border border-border/30 text-[11px] text-foreground placeholder:text-muted-foreground outline-none focus:ring-1 focus:ring-primary/30"
                      />
                      <button
                        onClick={async () => {
                          setShowVerdictPanel(false);
                          const verdictLabel = userVerdict === "pro" ? `찬성 승 (${getAgent(proAgentId)?.nameKo})` : userVerdict === "con" ? `반대 승 (${getAgent(conAgentId)?.nameKo})` : "무승부";
                          setMessages(prev => [...prev, {
                            agentId: "verdict",
                            content: `## 🔨 최종 판정: ${verdictLabel}\n\n${verdictReason ? `**사유:** ${verdictReason}` : ""}`,
                            timestamp: new Date(),
                            isStreaming: false,
                          }]);
                          // Auto-save to DB
                          await saveDebateToDb(userVerdict!, verdictReason);
                          toast.success("최종 판정이 기록되었습니다");
                        }}
                        disabled={savingDebate}
                        className="px-4 py-2 rounded-xl bg-primary text-primary-foreground text-[11px] font-semibold hover:bg-primary/90 transition-colors"
                      >
                        {savingDebate ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : "확정"}
                      </button>
                    </div>
                  </div>

                  {/* Change verdict */}
                  <button
                    onClick={() => setUserVerdict(null)}
                    className="text-[10px] text-muted-foreground hover:text-foreground transition-colors"
                  >
                    ← 판정 변경
                  </button>
                </motion.div>
              )}
            </motion.div>
          )}

          {/* Action buttons after meeting ends */}
          {!isRunning && !isPaused && messages.length > 0 && !showVerdictPanel && (
            <div className="flex-shrink-0 px-6 py-4 border-t border-border/30">
              <div className="flex items-center gap-3">
                <motion.button
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={saveAsReport}
                  disabled={savedAsReport || savingReport}
                  className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-[12px] font-semibold transition-all ${
                    savedAsReport
                      ? "bg-green-500/10 text-green-600 border border-green-500/20"
                      : "bg-primary/10 text-primary border border-primary/20 hover:bg-primary/15"
                  }`}
                >
                  {savingReport ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : savedAsReport ? <Check className="w-3.5 h-3.5" /> : <FileText className="w-3.5 h-3.5" />}
                  {savedAsReport ? "보고서 저장됨" : "보고서로 저장"}
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={convertToTasks}
                  disabled={taskSaveState === "complete" || savingTasks}
                  className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-[12px] font-semibold transition-all ${
                    taskSaveState === "complete"
                      ? "bg-green-500/10 text-green-600 border border-green-500/20"
                      : "bg-accent text-accent-foreground border border-border/30 hover:bg-accent/80"
                  }`}
                >
                  {savingTasks ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : taskSaveState === "complete" ? (
                    <Check className="w-3.5 h-3.5" />
                  ) : taskSaveState === "partial" ? (
                    <RotateCcw className="w-3.5 h-3.5" />
                  ) : (
                    <ListTodo className="w-3.5 h-3.5" />
                  )}
                  {taskSaveState === "complete"
                    ? "작업 생성됨"
                    : taskSaveState === "partial"
                      ? "이벤트 기록 재시도"
                      : "작업으로 변환"}
                </motion.button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
