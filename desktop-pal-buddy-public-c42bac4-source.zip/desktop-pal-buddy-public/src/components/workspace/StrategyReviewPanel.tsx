import { useEffect, useMemo, useRef, useState } from "react";
import { BookOpenCheck, Loader2 } from "lucide-react";
import { z } from "zod";
import { companyStateSchema } from "@/lib/company-runtime";
import {
  companyRuntimeClient,
  type CompanyRuntimeClient,
  type StrategyAdoptionCommand,
  type StrategyReviewCommand,
} from "@/lib/companyRuntimeClient";
import { useCompanyRuntime } from "@/hooks/useCompanyRuntime";

interface StrategyReviewPanelProps {
  readonly client?: CompanyRuntimeClient;
}

const statusSchema = z.object({
  epoch: z.string().uuid(),
  role: z.enum(["sales", "production", "management"]),
  actorSessionRevision: z.number().int().nonnegative(),
  stopped: z.boolean(),
}).passthrough();

const strategyRefSchema = z.object({
  strategy_id: z.string().min(1),
  strategy_version_id: z.string().uuid(),
}).strict();

const reviewChangesSchema = z.object({
  objective: z.string().min(1),
  review_question: z.string().min(1),
  execution_criteria: z.array(z.string()),
  constraints: z.array(z.string()),
}).strict();

const strategyReviewSchema = z.object({
  id: z.string().uuid(),
  baseStrategyRef: strategyRefSchema,
  decision: z.enum(["maintain", "create_new_version"]),
  proposedChanges: reviewChangesSchema,
  resultingStrategyRef: strategyRefSchema.nullable(),
}).passthrough();

const strategyAdoptionSchema = z.object({
  id: z.string().uuid(),
  reviewId: z.string().uuid(),
  fromRef: strategyRefSchema,
  toRef: strategyRefSchema,
}).passthrough();

const snapshotSchema = z.object({
  current: companyStateSchema,
  records: z.object({
    tasks: z.array(z.object({
      workboardTaskId: z.string().uuid(),
      epoch: z.string().uuid(),
      packet: z.object({ request_summary: z.string(), desired_outcome: z.string(), forbidden_actions: z.array(z.string()) }).passthrough().optional(),
    }).passthrough()).default([]),
    assessmentEvidence: z.array(z.object({
      id: z.string().uuid(), epoch: z.string().uuid(),
      finding: z.enum(["ready", "needs_review"]).optional(),
      reasons: z.array(z.string()).default([]),
      requiredChecks: z.array(z.string()).default([]),
      readSet: z.array(z.object({ kind: z.string(), id: z.string(), version: z.number().int().positive() })).default([]),
      mutationCount: z.number().int().nonnegative().optional(),
    }).passthrough()).default([]),
    readbackEvidence: z.array(z.object({
      executionId: z.string().uuid(), epoch: z.string().uuid(), observedVersion: z.number().int().positive(),
      observedPriority: z.number().int().optional(), matches: z.boolean().optional(),
    }).passthrough()).default([]),
    learningManagementStrategyReview: z.array(z.object({
      id: z.string(), version: z.number().int().positive(), content: z.string().optional(),
      exactPublishableSentence: z.string().optional(), applicability: z.array(z.string()).default([]),
      requiredChecks: z.array(z.string()).default([]),
    }).passthrough()).default([]),
    strategyReviews: z.array(strategyReviewSchema).default([]),
    strategyAdoptions: z.array(strategyAdoptionSchema).default([]),
  }).passthrough(),
}).passthrough();

const resultSchema = z.object({
  review: z.object({
    id: z.string().uuid(),
    decision: z.enum(["maintain", "create_new_version"]),
    resultingStrategyRef: strategyRefSchema.nullable().optional(),
  }).passthrough(),
  version: z.object({
    strategy_version_id: z.string().uuid(),
    version: z.number().int().positive(),
  }).passthrough().nullable(),
}).passthrough();

const readPayloadSchema = z.object({ snapshot: snapshotSchema }).passthrough();

interface ReviewedDraft {
  readonly reviewId: string;
  readonly baseStrategyRef: StrategyAdoptionCommand["expectedActiveRef"];
  readonly targetStrategyRef: StrategyAdoptionCommand["expectedActiveRef"];
  readonly version: number;
  readonly objective: string;
  readonly constraints: readonly string[];
}

type EvidenceRef = StrategyReviewCommand["evidenceRefs"][number];
type EvidenceOption = { readonly reference: EvidenceRef; readonly substance: readonly string[] };

function lines(value: string): string[] {
  return value.split("\n").map((item) => item.trim()).filter((item) => item.length > 0);
}

function evidenceKey(reference: EvidenceRef): string {
  return `${reference.kind}:${reference.id}:${reference.version}`;
}

export function StrategyReviewPanel({ client = companyRuntimeClient }: StrategyReviewPanelProps) {
  const { state, snapshot, status, client: runtimeClient } = useCompanyRuntime(client);
  const parsedStatus = useMemo(() => statusSchema.safeParse(status), [status]);
  const parsedSnapshot = useMemo(() => snapshotSchema.safeParse(snapshot), [snapshot]);
  const activeStatus = parsedStatus.success ? parsedStatus.data : null;
  const company = parsedSnapshot.success ? parsedSnapshot.data.current : null;
  const active = company?.strategyVersions.find((candidate) =>
    candidate.strategy_id === company.activeStrategyRef.strategy_id
    && candidate.strategy_version_id === company.activeStrategyRef.strategy_version_id) ?? null;
  const evidence = useMemo<readonly EvidenceOption[]>(() => {
    if (!parsedSnapshot.success) return [];
    const records = parsedSnapshot.data.records;
    return [
      ...records.assessmentEvidence.map((item) => ({
        reference: { kind: "assessment" as const, id: item.id, version: 1 },
        substance: [
          ...(item.finding ? [`판단: ${item.finding}${item.reasons.length > 0 ? ` · ${item.reasons.join(" · ")}` : ""}`] : []),
          ...(item.readSet.length > 0 ? [`근거 범위: ${item.readSet.map((ref) => `${ref.kind}/${ref.id} · v${ref.version}`).join(", ")}`] : []),
          ...(item.reasons.length > 0 ? [`반례·불확실성: ${item.reasons.join(" · ")}`] : []),
          `한계: 읽기 전용 근거이며 ERP 변경 ${item.mutationCount ?? 0}건${item.requiredChecks.length > 0 ? ` · 추가 확인 ${item.requiredChecks.join(", ")}` : ""}`,
        ],
      })),
      ...records.readbackEvidence.map((item) => ({
        reference: { kind: "readback" as const, id: item.executionId, version: item.observedVersion },
        substance: [`재조회: priority ${item.observedPriority ?? "미상"} · ${item.matches === true ? "일치" : "확인 필요"}`],
      })),
      ...records.tasks.map((item) => ({
        reference: { kind: "task" as const, id: item.workboardTaskId, version: 1 },
        substance: item.packet ? [
          `업무: ${item.packet.request_summary}`,
          `목표: ${item.packet.desired_outcome}`,
          ...(item.packet.forbidden_actions.length > 0 ? [`한계: ${item.packet.forbidden_actions.join(" · ")}`] : []),
        ] : [],
      })),
      ...records.learningManagementStrategyReview.map((item) => ({
        reference: { kind: "learning" as const, id: item.id, version: item.version },
        substance: [
          ...(item.content || item.exactPublishableSentence ? [`학습 내용: ${item.content ?? item.exactPublishableSentence}`] : []),
          ...(item.applicability.length > 0 ? [`적용 조건: ${item.applicability.join(", ")}`] : []),
          ...(item.requiredChecks.length > 0 ? [`추가 확인: ${item.requiredChecks.join(", ")}`] : []),
        ],
      })),
    ];
  }, [parsedSnapshot]);
  const [selectedKeys, setSelectedKeys] = useState<readonly string[]>([]);
  const [objective, setObjective] = useState("");
  const [reviewQuestion, setReviewQuestion] = useState("");
  const [criteria, setCriteria] = useState("");
  const [constraints, setConstraints] = useState("");
  const [uncertainties, setUncertainties] = useState("검사 완료 시점과 실제 사업 성과는 아직 확인되지 않았습니다.");
  const [reviewPending, setReviewPending] = useState(false);
  const [adoptionPending, setAdoptionPending] = useState(false);
  const [createdDraft, setCreatedDraft] = useState<ReviewedDraft | null>(null);
  const [adoptionDialog, setAdoptionDialog] = useState<ReviewedDraft | null>(null);
  const [locallyAdoptedReviewId, setLocallyAdoptedReviewId] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const generation = useRef(0);
  const adoptionIntent = useRef<{ readonly key: string; readonly requestId: string } | null>(null);
  const adoptionTriggerRef = useRef<HTMLButtonElement>(null);
  const adoptionDialogRef = useRef<HTMLElement>(null);
  const adoptionPendingRef = useRef(false);
  const contextKey = activeStatus
    ? `${activeStatus.epoch}:${activeStatus.actorSessionRevision}:${activeStatus.role}:${activeStatus.stopped}`
    : "unavailable";

  useEffect(() => {
    generation.current += 1;
    setReviewPending(false);
    setAdoptionPending(false);
    setAdoptionDialog(null);
    setNotice(null);
  }, [contextKey]);

  useEffect(() => {
    if (!active) return;
    setObjective(active.objective);
    setReviewQuestion(active.review_question);
    setCriteria(active.execution_criteria.join("\n"));
    setConstraints(active.constraints.join("\n"));
  }, [active]);

  useEffect(() => {
    setSelectedKeys(evidence.map((item) => evidenceKey(item.reference)));
  }, [evidence]);

  useEffect(() => {
    adoptionPendingRef.current = adoptionPending;
  }, [adoptionPending]);

  useEffect(() => {
    if (!adoptionDialog) return;
    const dialog = adoptionDialogRef.current;
    const opener = adoptionTriggerRef.current;
    if (!dialog) return;
    const focusable = () => Array.from(dialog.querySelectorAll<HTMLElement>(
      'button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])',
    ));
    focusable()[0]?.focus();
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape" && !adoptionPendingRef.current) {
        event.preventDefault();
        setAdoptionDialog(null);
        return;
      }
      if (event.key !== "Tab") return;
      const controls = focusable();
      const first = controls[0];
      const last = controls[controls.length - 1];
      if (!first || !last) return;
      const current = document.activeElement;
      if (event.shiftKey && (current === first || !dialog.contains(current))) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && current === last) {
        event.preventDefault();
        first.focus();
      }
    };
    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      if (opener?.isConnected) opener.focus();
    };
  }, [adoptionDialog]);

  const storedDraft = useMemo<ReviewedDraft | null>(() => {
    if (!parsedSnapshot.success) return null;
    const records = parsedSnapshot.data.records;
    const review = [...records.strategyReviews].reverse().find((candidate) =>
      candidate.decision === "create_new_version"
      && candidate.resultingStrategyRef !== null
      && !records.strategyAdoptions.some((adoption) => adoption.reviewId === candidate.id));
    if (!review?.resultingStrategyRef) return null;
    const target = parsedSnapshot.data.current.strategyVersions.find((candidate) =>
      candidate.strategy_id === review.resultingStrategyRef?.strategy_id
      && candidate.strategy_version_id === review.resultingStrategyRef.strategy_version_id);
    if (!target) return null;
    return {
      reviewId: review.id,
      baseStrategyRef: review.baseStrategyRef,
      targetStrategyRef: review.resultingStrategyRef,
      version: target.version,
      objective: review.proposedChanges.objective,
      constraints: review.proposedChanges.constraints,
    };
  }, [parsedSnapshot]);
  const reviewedDraft = locallyAdoptedReviewId === (createdDraft ?? storedDraft)?.reviewId
    ? null
    : createdDraft ?? storedDraft;

  if (activeStatus?.role !== "management" || !company || !active) return null;

  const submit = async (decision: StrategyReviewCommand["decision"]) => {
    if (reviewPending || state !== "ready" || activeStatus.stopped || !runtimeClient.reviewStrategy) return;
    const selected = evidence.map((item) => item.reference).filter((item) => selectedKeys.includes(evidenceKey(item)));
    const proposedCriteria = lines(criteria);
    const proposedConstraints = lines(constraints);
    const proposedUncertainties = lines(uncertainties);
    if (selected.length === 0 || proposedCriteria.length === 0 || proposedConstraints.length === 0
      || proposedUncertainties.length === 0 || !objective.trim() || !reviewQuestion.trim()) {
      setNotice("증거, 불확실성, 기준과 제약을 모두 확인해 주세요.");
      return;
    }
    const started = generation.current + 1;
    generation.current = started;
    setReviewPending(true);
    setNotice(null);
    const response = await runtimeClient.reviewStrategy({
      decision,
      baseStrategyRef: company.activeStrategyRef,
      expectedBaseVersion: active.version,
      evidenceRefs: selected,
      uncertainties: proposedUncertainties,
      proposedChanges: {
        objective: objective.trim(),
        review_question: reviewQuestion.trim(),
        execution_criteria: proposedCriteria,
        constraints: proposedConstraints,
      },
    });
    if (generation.current !== started) return;
    setReviewPending(false);
    if (!response.ok) {
      setNotice(`전략 검토를 기록하지 못했습니다. (${response.error.message})`);
      return;
    }
    const parsed = resultSchema.safeParse(response.payload);
    if (!parsed.success) {
      setNotice("전략 검토 응답 형식을 확인할 수 없습니다.");
      return;
    }
    if (parsed.data.version) {
      const targetStrategyRef = parsed.data.review.resultingStrategyRef ?? {
        strategy_id: company.activeStrategyRef.strategy_id,
        strategy_version_id: parsed.data.version.strategy_version_id,
      };
      setCreatedDraft({
        reviewId: parsed.data.review.id,
        baseStrategyRef: company.activeStrategyRef,
        targetStrategyRef,
        version: parsed.data.version.version,
        objective: objective.trim(),
        constraints: proposedConstraints,
      });
      setNotice(`전략 v${parsed.data.version.version}를 만들었습니다.`);
      return;
    }
    setNotice("현재 전략을 유지하는 검토를 기록했습니다.");
  };

  const adoptionRequestId = (draft: ReviewedDraft): string => {
    const key = `${draft.reviewId}:${draft.baseStrategyRef.strategy_version_id}:${draft.targetStrategyRef.strategy_version_id}`;
    if (adoptionIntent.current?.key === key) return adoptionIntent.current.requestId;
    const requestId = crypto.randomUUID();
    adoptionIntent.current = { key, requestId };
    return requestId;
  };

  const readAdoption = async (draft: ReviewedDraft, requestId: string): Promise<boolean> => {
    const response = await runtimeClient.read();
    if (!response.ok) return false;
    const payload = readPayloadSchema.safeParse(response.payload);
    if (!payload.success) return false;
    const persisted = payload.data.snapshot;
    const activeMatches = persisted.current.activeStrategyRef.strategy_id === draft.targetStrategyRef.strategy_id
      && persisted.current.activeStrategyRef.strategy_version_id === draft.targetStrategyRef.strategy_version_id;
    const matching = persisted.records.strategyAdoptions.filter((adoption) =>
      adoption.id === requestId
      && adoption.reviewId === draft.reviewId
      && adoption.toRef.strategy_version_id === draft.targetStrategyRef.strategy_version_id);
    return activeMatches && matching.length === 1;
  };

  const confirmAdoption = async () => {
    const draft = adoptionDialog;
    if (!draft || adoptionPending || state !== "ready" || activeStatus.stopped || !runtimeClient.adoptStrategy) return;
    const currentRef = company.activeStrategyRef;
    if (currentRef.strategy_id !== draft.baseStrategyRef.strategy_id
      || currentRef.strategy_version_id !== draft.baseStrategyRef.strategy_version_id) {
      setAdoptionDialog(null);
      setNotice("활성 전략이 바뀌었습니다. 최신 상태에서 새 검토가 필요합니다.");
      return;
    }
    const started = generation.current + 1;
    generation.current = started;
    const requestId = adoptionRequestId(draft);
    setAdoptionPending(true);
    setNotice(null);
    const response = await runtimeClient.adoptStrategy({
      requestId,
      reviewId: draft.reviewId,
      expectedActiveRef: draft.baseStrategyRef,
    });
    if (generation.current !== started) return;
    if (response.ok) {
      setAdoptionPending(false);
      setAdoptionDialog(null);
      setLocallyAdoptedReviewId(draft.reviewId);
      setNotice(`새 업무는 전략 v${draft.version}를 사용합니다. 진행 중 업무는 기존 전략을 유지합니다.`);
      return;
    }
    const reconciled = await readAdoption(draft, requestId);
    if (generation.current !== started) return;
    setAdoptionPending(false);
    setAdoptionDialog(null);
    if (reconciled) {
      setLocallyAdoptedReviewId(draft.reviewId);
      setNotice(`저장 상태에서 전략 v${draft.version} 적용을 확인했습니다. 새 업무에만 적용됩니다.`);
      return;
    }
    setNotice(response.error.code === "stale_context"
      ? "활성 전략이 바뀌었습니다. 최신 상태에서 새 검토가 필요합니다."
      : `전략을 적용하지 못했습니다. (${response.error.message})`);
  };

  return (
    <section aria-label="경영 전략 검토" className="mt-4 rounded-xl border border-amber-500/20 bg-amber-500/5 p-4">
      <div className="flex items-start gap-2">
        <BookOpenCheck className="mt-0.5 h-4 w-4 text-amber-300" aria-hidden="true" />
        <div>
          <h2 className="text-sm font-semibold text-foreground">전략 검토</h2>
          <p className="mt-1 text-[11px] text-muted-foreground">{active.strategy_id} · v{active.version}</p>
          <p className="mt-0.5 text-[10px] font-medium text-amber-700 dark:text-amber-200">활성 전략 · v{active.version}</p>
        </div>
      </div>
      <div className="mt-4 grid gap-3">
        <fieldset className="rounded-lg border border-border/40 bg-background/60 p-3">
          <legend className="px-1 text-[11px] font-semibold text-foreground">검토 증거</legend>
          <div className="mt-1 space-y-2">
            {evidence.map(({ reference, substance }) => {
              const key = evidenceKey(reference);
              return (
                <div key={key} className="rounded-md border border-border/30 bg-background/70 p-2">
                  <label className="flex items-center gap-2 text-[10px] text-muted-foreground">
                    <input
                      type="checkbox"
                      checked={selectedKeys.includes(key)}
                      onChange={(event) => setSelectedKeys((current) => event.target.checked
                        ? [...current, key]
                        : current.filter((item) => item !== key))}
                    />
                    {reference.kind} · {reference.id} · v{reference.version}
                  </label>
                  {substance.map((line) => <p key={line} className="mt-1 text-[10px] leading-relaxed text-foreground/80">{line}</p>)}
                </div>
              );
            })}
            {evidence.length === 0 && <p className="text-[10px] text-amber-300">검토 가능한 공식 증거가 없습니다.</p>}
          </div>
        </fieldset>

        <label className="grid gap-1 text-[10px] text-muted-foreground">반례와 불확실성
          <textarea aria-label="반례와 불확실성" value={uncertainties} onChange={(event) => setUncertainties(event.target.value)} className="min-h-16 rounded-lg border border-border/40 bg-background px-3 py-2 text-[11px] text-foreground" />
        </label>
        <label className="grid gap-1 text-[10px] text-muted-foreground">제안 목표
          <input aria-label="제안 목표" value={objective} onChange={(event) => setObjective(event.target.value)} className="h-9 rounded-lg border border-border/40 bg-background px-3 text-[11px] text-foreground" />
        </label>
        <label className="grid gap-1 text-[10px] text-muted-foreground">검토 질문
          <textarea aria-label="검토 질문" value={reviewQuestion} onChange={(event) => setReviewQuestion(event.target.value)} className="min-h-14 rounded-lg border border-border/40 bg-background px-3 py-2 text-[11px] text-foreground" />
        </label>
        <label className="grid gap-1 text-[10px] text-muted-foreground">실행 기준
          <textarea aria-label="실행 기준" value={criteria} onChange={(event) => setCriteria(event.target.value)} className="min-h-16 rounded-lg border border-border/40 bg-background px-3 py-2 text-[11px] text-foreground" />
        </label>
        <label className="grid gap-1 text-[10px] text-muted-foreground">제약 조건
          <textarea aria-label="제약 조건" value={constraints} onChange={(event) => setConstraints(event.target.value)} className="min-h-16 rounded-lg border border-border/40 bg-background px-3 py-2 text-[11px] text-foreground" />
        </label>
      </div>

      {reviewedDraft && (
        <section aria-label="검토된 전략 버전" className="mt-4 rounded-lg border border-blue-500/20 bg-blue-500/5 p-3">
          <p className="text-[11px] font-semibold text-foreground">검토 버전 · v{reviewedDraft.version}</p>
          <p className="mt-1 text-[10px] leading-relaxed text-muted-foreground">{reviewedDraft.objective}</p>
          <button ref={adoptionTriggerRef} type="button" disabled={adoptionPending} onClick={() => setAdoptionDialog(reviewedDraft)} className="mt-3 h-9 rounded-lg border border-blue-500/30 bg-blue-500/10 px-3 text-[11px] font-semibold text-blue-700 disabled:opacity-50 dark:text-blue-100">새 업무에 적용</button>
        </section>
      )}

      <p className="mt-3 text-[10px] leading-relaxed text-muted-foreground">제한: 기존 업무와 승인에 고정된 v1은 바뀌지 않습니다. 새 버전은 이후 업무 선택에만 사용되며 정책은 자동 활성화하지 않습니다.</p>
      <p role="status" className="mt-3 min-h-4 text-[11px] text-foreground">{notice}</p>
      <div className="mt-3 flex flex-wrap gap-2">
        <button type="button" disabled={reviewPending || evidence.length === 0} onClick={() => void submit("maintain")} className="h-9 rounded-lg border border-border/50 bg-background px-3 text-[11px] font-semibold text-foreground disabled:opacity-50">현재 전략 유지</button>
        <button type="button" disabled={reviewPending || evidence.length === 0} onClick={() => void submit("create_new_version")} className="inline-flex h-9 items-center gap-2 rounded-lg bg-amber-500 px-3 text-[11px] font-semibold text-black disabled:opacity-50">
          {reviewPending && <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />}새 전략 버전 만들기
        </button>
      </div>

      {adoptionDialog && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-4">
          <section ref={adoptionDialogRef} role="dialog" aria-modal="true" aria-labelledby="strategy-adoption-title" className="w-full max-w-lg rounded-xl border border-border/60 bg-background p-5 shadow-2xl">
            <h3 id="strategy-adoption-title" className="text-sm font-semibold text-foreground">검토한 전략을 새 업무에 적용</h3>
            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <section aria-label="현재 전략" className="rounded-lg border border-border/40 bg-secondary/30 p-3">
                <p className="text-[10px] font-semibold text-muted-foreground">현재 목표 · v{active.version}</p>
                <p className="mt-1 text-[11px] leading-relaxed text-foreground">{active.objective}</p>
                <p className="mt-2 text-[10px] leading-relaxed text-muted-foreground">제약 · {active.constraints.join(" · ")}</p>
              </section>
              <section aria-label="새 전략" className="rounded-lg border border-blue-500/30 bg-blue-500/5 p-3">
                <p className="text-[10px] font-semibold text-blue-700 dark:text-blue-200">새 목표 · v{adoptionDialog.version}</p>
                <p className="mt-1 text-[11px] leading-relaxed text-foreground">{adoptionDialog.objective}</p>
                <p className="mt-2 text-[10px] leading-relaxed text-muted-foreground">제약 · {adoptionDialog.constraints.join(" · ")}</p>
              </section>
            </div>
            <p className="mt-4 text-[11px] font-semibold text-amber-700 dark:text-amber-200">이후 새 업무에 적용, 진행 중 업무 유지.</p>
            <div className="mt-5 flex justify-end gap-2">
              <button type="button" disabled={adoptionPending} onClick={() => setAdoptionDialog(null)} className="h-9 rounded-lg border border-border/50 px-3 text-[11px] font-semibold text-foreground disabled:opacity-50">취소</button>
              <button type="button" disabled={adoptionPending} onClick={() => void confirmAdoption()} className="inline-flex h-9 items-center gap-2 rounded-lg bg-blue-500 px-3 text-[11px] font-semibold text-white disabled:opacity-50">
                {adoptionPending && <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden="true" />}새 업무에 적용
              </button>
            </div>
          </section>
        </div>
      )}
    </section>
  );
}
