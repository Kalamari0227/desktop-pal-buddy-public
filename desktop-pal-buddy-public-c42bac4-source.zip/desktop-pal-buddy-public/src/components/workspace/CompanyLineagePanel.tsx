import { useMemo, useState } from "react";
import { ArrowLeft, GitBranch } from "lucide-react";
import { z } from "zod";
import type { Strategy, StrategyVersion } from "@/lib/agentic";
import { deriveCompanyLineage, type LineageRelation } from "@/lib/company-runtime/lineage";
import { companyRuntimeClient, type CompanyRuntimeClient } from "@/lib/companyRuntimeClient";
import { useCompanyRuntime } from "@/hooks/useCompanyRuntime";
import { StrategySummary } from "./StrategySummary";

interface CompanyLineagePanelProps {
  readonly originTaskId?: string;
  readonly onOpenTask?: (taskId: string) => void;
  readonly client?: CompanyRuntimeClient;
}

const statusLabels = {
  available: "available · 확인됨",
  missing: "missing · 기록 없음",
  withdrawn: "withdrawn · 철회됨",
  archived: "archived · 이전 epoch",
  unobserved: "unobserved · 미관찰",
} as const;

const statusTone = {
  available: "border-emerald-500/20 bg-emerald-500/10 text-emerald-300",
  missing: "border-red-500/20 bg-red-500/10 text-red-300",
  withdrawn: "border-amber-500/20 bg-amber-500/10 text-amber-300",
  archived: "border-border/50 bg-secondary/40 text-muted-foreground",
  unobserved: "border-blue-500/20 bg-blue-500/10 text-blue-200",
} as const;

const adoptionHistorySchema = z.object({
  current: z.object({
    strategyVersions: z.array(z.object({
      strategy_version_id: z.string().uuid(),
      version: z.number().int().positive(),
    }).passthrough()),
  }).passthrough(),
  records: z.object({
    strategyAdoptions: z.array(z.object({
      id: z.string().uuid(),
      reviewId: z.string().uuid(),
      fromRef: z.object({ strategy_version_id: z.string().uuid() }).passthrough(),
      toRef: z.object({ strategy_version_id: z.string().uuid() }).passthrough(),
      actorId: z.string().min(1),
      adoptedAt: z.string().datetime(),
    }).passthrough()).default([]),
  }).passthrough(),
}).passthrough();

export function CompanyLineagePanel({ originTaskId, onOpenTask, client = companyRuntimeClient }: CompanyLineagePanelProps) {
  const runtime = useCompanyRuntime(client);
  const lineage = useMemo(() => deriveCompanyLineage(runtime.snapshot), [runtime.snapshot]);
  const adoptions = useMemo(() => {
    const parsed = adoptionHistorySchema.safeParse(runtime.snapshot);
    if (!parsed.success) return [];
    const versions = parsed.data.current.strategyVersions;
    return parsed.data.records.strategyAdoptions.map((adoption) => ({
      ...adoption,
      fromVersion: versions.find((version) => version.strategy_version_id === adoption.fromRef.strategy_version_id)?.version ?? null,
      toVersion: versions.find((version) => version.strategy_version_id === adoption.toRef.strategy_version_id)?.version ?? null,
    }));
  }, [runtime.snapshot]);
  const [originTask] = useState<string | null>(originTaskId ?? null);
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(originTask);
  const [selectedRelation, setSelectedRelation] = useState<LineageRelation | null>(null);
  const selectedTask = lineage?.tasks.find((task) => task.id === selectedTaskId) ?? null;

  if (runtime.state === "loading") return <section aria-label="전략-경험 계보" className="rounded-xl border border-border/40 bg-background/50 p-4 text-[11px] text-muted-foreground">계보를 불러오는 중입니다.</section>;
  if (!lineage) return null;

  const strategy: Strategy = { strategy_id: lineage.strategy.id, title: "Brave New Company 운영 전략" };
  const version: StrategyVersion = {
    strategy_id: lineage.strategy.id,
    strategy_version_id: lineage.strategy.versionId,
    version: lineage.strategy.version,
    objective: lineage.strategy.objective,
    review_question: lineage.strategy.reviewQuestion,
  };
  const openTask = (taskId: string) => {
    setSelectedTaskId(taskId);
    setSelectedRelation(null);
    onOpenTask?.(taskId);
  };

  return (
    <section aria-label="전략-경험 계보" className="mt-4 rounded-xl border border-blue-500/20 bg-blue-500/5 p-4">
      <div className="flex items-start gap-2">
        <GitBranch className="mt-0.5 h-4 w-4 shrink-0 text-blue-300" aria-hidden="true" />
        <div className="min-w-0">
          <h2 className="text-sm font-semibold text-foreground">전략에서 경험까지</h2>
          <p className="mt-1 text-[10px] leading-relaxed text-muted-foreground">가상 데이터 · 읽기 전용 · 사업 결과는 미관찰 상태일 수 있습니다.</p>
        </div>
      </div>

      <div className="mt-3">
        <StrategySummary strategy={strategy} version={version} contentHash={lineage.strategy.contentHash} onOpenLineage={() => { setSelectedTaskId(null); setSelectedRelation(null); }} />
        <p className="mt-2 font-mono text-[10px] text-muted-foreground">{lineage.strategy.id} · v{lineage.strategy.version} · {lineage.strategy.versionId}</p>
      </div>

      {adoptions.length > 0 && (
        <section aria-label="전략 적용 이력" className="mt-3 rounded-lg border border-emerald-500/20 bg-emerald-500/5 p-3">
          <p className="text-[11px] font-semibold text-foreground">전략 적용 이력</p>
          <div className="mt-2 grid gap-2">
            {adoptions.map((adoption) => (
              <div key={adoption.id} className="rounded-md border border-border/30 bg-background/60 p-2">
                <p className="text-[11px] font-semibold text-emerald-700 dark:text-emerald-200">v{adoption.fromVersion ?? "?"} → v{adoption.toVersion ?? "?"}</p>
                <p className="mt-1 font-mono text-[9px] text-muted-foreground">{adoption.actorId} · {adoption.adoptedAt}</p>
                <p className="mt-1 font-mono text-[9px] text-muted-foreground">review {adoption.reviewId} · adoption {adoption.id}</p>
              </div>
            ))}
          </div>
        </section>
      )}

      {selectedRelation ? (
        <div className="mt-3 rounded-lg border border-border/40 bg-background/70 p-3">
          <button type="button" onClick={() => setSelectedRelation(null)} className="inline-flex items-center gap-1 text-[11px] font-semibold text-blue-200">
            <ArrowLeft className="h-3.5 w-3.5" aria-hidden="true" />계보로 돌아가기
          </button>
          <p className="mt-3 font-mono text-[11px] text-foreground">{selectedRelation.kind} · {selectedRelation.id} · v{selectedRelation.version}</p>
          <span className={`mt-2 inline-flex rounded-md border px-2 py-1 text-[10px] ${statusTone[selectedRelation.status]}`}>{statusLabels[selectedRelation.status]}</span>
          <p role="status" className="mt-2 text-[10px] leading-relaxed text-muted-foreground">{selectedRelation.reason ?? `정확한 저장 기록 ${selectedRelation.kind}/${selectedRelation.id} v${selectedRelation.version}와 연결되었습니다.`}</p>
          {selectedRelation.fields.length > 0 && (
            <section aria-label="저장 레코드 상세" className="mt-3 rounded-md border border-border/30 bg-background/60 p-2">
              <dl className="grid gap-2">
                {selectedRelation.fields.map((field) => (
                  <div key={field.label} className="grid gap-0.5">
                    <dt className="font-mono text-[9px] text-muted-foreground">{field.label}</dt>
                    <dd className="break-all font-mono text-[10px] text-foreground">{field.value}</dd>
                  </div>
                ))}
              </dl>
            </section>
          )}
        </div>
      ) : (
        <div className="mt-3 space-y-3">
          <div className="grid gap-2">
            {lineage.tasks.map((task) => (
              <button key={task.id} type="button" aria-label={`업무 ${task.id} 열기`} onClick={() => openTask(task.id)} className={`rounded-lg border p-3 text-left ${selectedTask?.id === task.id ? "border-blue-500/40 bg-blue-500/10" : "border-border/40 bg-background/60"}`}>
                <span className="block text-[11px] font-semibold text-foreground">{task.title}</span>
                <span className="mt-1 block font-mono text-[10px] text-muted-foreground">{task.id} · packet {task.packetTaskId}</span>
                <span className={`mt-2 inline-flex rounded-md border px-2 py-1 text-[10px] ${statusTone[task.status]}`}>{statusLabels[task.status]}</span>
              </button>
            ))}
          </div>

          {selectedTask && (
            <div className="rounded-lg border border-border/40 bg-background/60 p-3">
              <p className="text-[11px] font-semibold text-foreground">업무 근거와 경험</p>
              {selectedTask.readSet.length > 0 && <p className="mt-2 text-[10px] leading-relaxed text-muted-foreground">조회 범위 · {selectedTask.readSet.map((item) => `${item.kind}/${item.id} v${item.version}`).join(" · ")}</p>}
              <div className="mt-2 grid gap-2">
                {selectedTask.relations.map((item, index) => (
                  <button key={`${item.kind}:${item.id}:${item.version}:${index}`} type="button" aria-label={`${item.kind} ${item.id} v${item.version} ${item.status} 보기`} onClick={() => setSelectedRelation(item)} className="flex min-w-0 items-center justify-between gap-2 rounded-md border border-border/30 bg-background px-2.5 py-2 text-left">
                    <span className="min-w-0 truncate font-mono text-[10px] text-foreground">{item.kind} · {item.id} · v{item.version}</span>
                    <span className={`shrink-0 rounded-md border px-1.5 py-0.5 text-[9px] ${statusTone[item.status]}`}>{item.status}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {lineage.reviews.map((review) => (
            <section key={review.id} aria-label={`전략 검토 ${review.id}`} className="rounded-lg border border-amber-500/20 bg-amber-500/5 p-3">
              <p className="text-[11px] font-semibold text-foreground">전략 검토 · {review.decision}</p>
              <p className="mt-1 font-mono text-[10px] text-muted-foreground">{review.id} · v{review.version} · {review.status}</p>
              <div className="mt-2 grid gap-1">
                {review.evidence.map((item) => (
                  <button key={`${item.kind}:${item.id}:${item.version}`} type="button" aria-label={`${item.kind} ${item.id} v${item.version} ${item.status} 보기`} onClick={() => setSelectedRelation(item)} className="rounded-md border border-border/30 bg-background/60 px-2 py-1.5 text-left font-mono text-[10px] text-muted-foreground">
                    {item.kind} · {item.id} · v{item.version} · {item.status}
                  </button>
                ))}
                {review.resultingStrategy && (
                  <button type="button" aria-label={`resulting_strategy ${review.resultingStrategy.id} v${review.resultingStrategy.version} ${review.resultingStrategy.status} 보기`} onClick={() => setSelectedRelation(review.resultingStrategy)} className="rounded-md border border-border/30 bg-background/60 px-2 py-1.5 text-left font-mono text-[10px] text-muted-foreground">
                    result · {review.resultingStrategy.id} · v{review.resultingStrategy.version} · {review.resultingStrategy.status}
                  </button>
                )}
              </div>
            </section>
          ))}
        </div>
      )}

      {originTask && (
        <button type="button" onClick={() => openTask(originTask)} className="mt-3 inline-flex h-8 items-center gap-1 rounded-lg border border-border/50 bg-background px-3 text-[11px] font-semibold text-foreground">
          <ArrowLeft className="h-3.5 w-3.5" aria-hidden="true" />원래 업무로 돌아가기
        </button>
      )}
    </section>
  );
}
