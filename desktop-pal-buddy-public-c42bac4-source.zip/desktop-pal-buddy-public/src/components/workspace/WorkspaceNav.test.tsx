import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { WorkspaceNav } from "./WorkspaceNav";

describe("WorkspaceNav", () => {
  it("shows the business-facing menu structure", () => {
    render(<WorkspaceNav activeMode="gateway" onModeChange={vi.fn()} onClose={vi.fn()} />);

    ["홈", "요청", "작업", "고객", "리스크", "문서", "보고서", "자동화", "연결", "설정"].forEach((label) => {
      expect(screen.getByRole("button", { name: label })).toBeInTheDocument();
    });

    expect(screen.getByRole("button", { name: "요청" })).toHaveAttribute("aria-current", "page");
    expect(screen.queryByRole("button", { name: "Gateway" })).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Marketplace" })).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Workflows" })).not.toBeInTheDocument();
  }, 10000);

  it("routes grouped menu items to the existing workspace modes", () => {
    const onModeChange = vi.fn();
    render(<WorkspaceNav activeMode="home" onModeChange={onModeChange} onClose={vi.fn()} />);

    fireEvent.click(screen.getByRole("button", { name: "요청" }));
    fireEvent.click(screen.getByRole("button", { name: "자동화" }));
    fireEvent.click(screen.getByRole("button", { name: "연결" }));
    fireEvent.click(screen.getByRole("button", { name: /알림/ }));

    expect(onModeChange).toHaveBeenNthCalledWith(1, "gateway");
    expect(onModeChange).toHaveBeenNthCalledWith(2, "workflows");
    expect(onModeChange).toHaveBeenNthCalledWith(3, "marketplace");
    expect(onModeChange).toHaveBeenNthCalledWith(4, "alerts");
  });

  it("keeps grouped detail modes highlighted under their parent menu", () => {
    render(<WorkspaceNav activeMode="agent-meeting" onModeChange={vi.fn()} onClose={vi.fn()} />);

    expect(screen.getByRole("button", { name: "자동화" })).toHaveAttribute("aria-current", "page");
    expect(screen.getByRole("button", { name: "회의" })).toHaveAttribute("aria-current", "page");
  });
});
