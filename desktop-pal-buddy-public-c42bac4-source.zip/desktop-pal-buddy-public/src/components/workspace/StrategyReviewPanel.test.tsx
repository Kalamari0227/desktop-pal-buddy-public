import { fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { createInitialCompanyState } from "@/lib/company-runtime";
import type {
  CompanyRuntimeClient,
  CompanyRuntimeResponse,
  StrategyAdoptionCommand,
  StrategyReviewCommand,
} from "@/lib/companyRuntimeClient";
import { StrategyReviewPanel } from "./StrategyReviewPanel";

const epoch = "85c540f3-5e30-4a42-97f0-3f46577cf339";
const strategyVersionId = "266cae99-24da-4595-95ed-c2c782a20417";
const assessmentId = "719c1670-0035-437a-8f80-245edb22e99a";
const reviewId = "23df084c-8f17-41ba-a570-6b763ec7fae1";
const strategyV2Id = "6a21f048-4106-4c46-b7c1-4b8c7c50dad6";
const state = createInitialCompanyState({
  epoch,
  strategyVersionId,
  createdAt: "2026-09-18T00:00:00.000Z",
  strategyContentHash: "a".repeat(64),
});

function success(payload: unknown, revision = 2): CompanyRuntimeResponse {
  return {
    schemaVersion: 1,
    requestId: crypto.randomUUID(),
    epoch,
    actorSessionRevision: revision,
    ok: true,
    payload,
  };
}

function clientFor(
  role: "sales" | "production" | "management",
  reviewStrategy: (payload: StrategyReviewCommand) => Promise<CompanyRuntimeResponse>,
  options: {
    readonly snapshot?: unknown;
    readonly adoptStrategy?: (payload: StrategyAdoptionCommand) => Promise<CompanyRuntimeResponse>;
    readonly read?: () => Promise<CompanyRuntimeResponse>;
    readonly captureSubscriber?: (subscriber: (response: CompanyRuntimeResponse) => void) => void;
  } = {},
): CompanyRuntimeClient {
  const actorId = role === "management" ? "management-demo" : role === "production" ? "production-demo" : "sales-demo";
  const defaultSnapshot = {
    formatVersion: 1,
    revision: 2,
    currentEpoch: epoch,
    stopped: false,
    current: state,
    records: {
      tasks: [],
      assessmentEvidence: [{
        id: assessmentId,
        epoch,
        finding: "needs_review",
        reasons: ["검사 상태가 pending입니다."],
        requiredChecks: ["inspection", "packaging"],
        readSet: [{ kind: "production_plan", id: "PP-DEMO-1002", version: 1 }],
        mutationCount: 0,
        observedAt: "2026-09-19T01:00:00.000Z",
      }],
      readbackEvidence: [],
      learningManagementStrategyReview: [{
        id: "learning-ready",
        version: 1,
        content: "완료 안내 전 검사와 포장을 확인합니다.",
        applicability: ["queued production plan"],
        requiredChecks: ["inspection", "packaging"],
      }],
      strategyReviews: [],
      strategyAdoptions: [],
    },
    projection: { actorId, role },
  };
  return {
    bootstrap: vi.fn(async () => success({
      snapshot: options.snapshot ?? defaultSnapshot,
      status: { epoch, actorId, role, actorSessionRevision: 2, stopped: false },
    })),
    read: vi.fn(options.read ?? (async () => success({ snapshot: options.snapshot ?? defaultSnapshot }))),
    submit: vi.fn(),
    approve: vi.fn(),
    execute: vi.fn(),
    role: vi.fn(),
    stop: vi.fn(),
    resume: vi.fn(),
    reset: vi.fn(),
    cancel: vi.fn(),
    reconcile: vi.fn(),
    reviewReadiness: vi.fn(),
    reviewStrategy,
    adoptStrategy: options.adoptStrategy,
    subscribe: vi.fn((subscriber) => {
      options.captureSubscriber?.(subscriber);
      return () => undefined;
    }),
    getContext: vi.fn(() => ({ epoch, actorSessionRevision: 2 })),
  };
}

function reviewedSnapshot(activeStrategyVersionId = strategyVersionId, adoptions: readonly unknown[] = []) {
  const strategyV2 = {
    ...state.strategyVersions[0],
    strategy_version_id: strategyV2Id,
    version: 2,
    objective: "검사와 포장 확인 후 납기 판단",
    review_question: "검증된 준비 상태인가?",
    execution_criteria: ["검사와 포장 확인"],
    constraints: ["진행 중 업무 유지", "외부 ERP 변경 금지"],
    parent_version_id: strategyVersionId,
    created_at: "2026-09-19T02:00:00.000Z",
    origin: "management" as const,
  };
  const review = {
    id: reviewId,
    epoch,
    requestId: "6d78dd3c-dbb1-4c51-9d7f-4d3d29d68364",
    baseStrategyRef: state.activeStrategyRef,
    baseContentHash: state.strategyVersions[0].content_hash,
    expectedBaseVersion: 1,
    evidenceSnapshot: [{ kind: "assessment", id: assessmentId, version: 1 }],
    uncertainties: ["사업 성과 미확인"],
    proposedChanges: {
      objective: strategyV2.objective,
      review_question: strategyV2.review_question,
      execution_criteria: strategyV2.execution_criteria,
      constraints: strategyV2.constraints,
    },
    reviewerActorId: "management-demo",
    reviewedAt: "2026-09-19T02:00:00.000Z",
    decision: "create_new_version",
    resultingStrategyRef: { strategy_id: state.activeStrategyRef.strategy_id, strategy_version_id: strategyV2Id },
  };
  return {
    formatVersion: 1,
    revision: 3,
    currentEpoch: epoch,
    stopped: false,
    current: {
      ...state,
      activeStrategyRef: { ...state.activeStrategyRef, strategy_version_id: activeStrategyVersionId },
      strategyVersions: [...state.strategyVersions, strategyV2],
    },
    records: {
      tasks: [],
      assessmentEvidence: [],
      readbackEvidence: [],
      learningManagementStrategyReview: [],
      strategyReviews: [review],
      strategyAdoptions: adoptions,
    },
    projection: { actorId: "management-demo", role: "management" },
  };
}

describe("StrategyReviewPanel", () => {
  it.each(["sales", "production"] as const)("stays absent for the %s role", async (role) => {
    render(<StrategyReviewPanel client={clientFor(role, vi.fn())} />);

    await waitFor(() => expect(screen.queryByRole("heading", { name: "전략 검토" })).not.toBeInTheDocument());
  });

  it("shows evidence, uncertainty, counterexample, and limits before explicit v2 creation", async () => {
    // Given: management sees one official assessment and one management-approved shared learning asset.
    const reviewStrategy = vi.fn(async (_command: StrategyReviewCommand) => success({
      idempotent: false,
      review: { id: crypto.randomUUID(), decision: "create_new_version" },
      version: { strategy_version_id: crypto.randomUUID(), version: 2 },
    }));
    render(<StrategyReviewPanel client={clientFor("management", reviewStrategy)} />);

    const panel = await screen.findByLabelText("경영 전략 검토");
    expect(within(panel).getByText(`STRATEGY-DEMO-PRODUCTION · v1`)).toBeInTheDocument();
    expect(within(panel).getByText(`assessment · ${assessmentId} · v1`)).toBeInTheDocument();
    expect(within(panel).getByText("learning · learning-ready · v1")).toBeInTheDocument();
    expect(within(panel).getByText("판단: needs_review · 검사 상태가 pending입니다.")).toBeInTheDocument();
    expect(within(panel).getByText("근거 범위: production_plan/PP-DEMO-1002 · v1")).toBeInTheDocument();
    expect(within(panel).getByText("학습 내용: 완료 안내 전 검사와 포장을 확인합니다.")).toBeInTheDocument();
    expect(within(panel).getByText("적용 조건: queued production plan")).toBeInTheDocument();
    expect(within(panel).getByText("반례·불확실성: 검사 상태가 pending입니다.")).toBeInTheDocument();
    expect(within(panel).getByText("한계: 읽기 전용 근거이며 ERP 변경 0건 · 추가 확인 inspection, packaging")).toBeInTheDocument();
    expect(within(panel).getByText(/반례와 불확실성/)).toBeInTheDocument();
    expect(within(panel).getByText(/기존 업무와 승인에 고정된 v1은 바뀌지 않습니다/)).toBeInTheDocument();

    // When: management changes the proposed objective and explicitly creates a new version.
    fireEvent.change(within(panel).getByLabelText("제안 목표"), { target: { value: "검사와 포장 확인 후 납기 판단" } });
    fireEvent.click(within(panel).getByRole("button", { name: "새 전략 버전 만들기" }));

    // Then: only bounded references and proposed content are submitted, and v2 is reported without policy activation.
    expect(await within(panel).findByText("전략 v2를 만들었습니다.")).toBeInTheDocument();
    expect(reviewStrategy).toHaveBeenCalledWith(expect.objectContaining({
      decision: "create_new_version",
      baseStrategyRef: state.activeStrategyRef,
      expectedBaseVersion: 1,
      evidenceRefs: [
        { kind: "assessment", id: assessmentId, version: 1 },
        { kind: "learning", id: "learning-ready", version: 1 },
      ],
      proposedChanges: expect.objectContaining({ objective: "검사와 포장 확인 후 납기 판단" }),
    }));
    expect(JSON.stringify(reviewStrategy.mock.calls[0]?.[0])).not.toMatch(/contentHash|rawBody|policy/);
  });

  it("requires an explicit maintain action and records no new version", async () => {
    // Given: a complete review form with bounded evidence.
    const reviewStrategy = vi.fn(async (_command: StrategyReviewCommand) => success({
      idempotent: false,
      review: { id: crypto.randomUUID(), decision: "maintain", resultingStrategyRef: null },
      version: null,
    }));
    render(<StrategyReviewPanel client={clientFor("management", reviewStrategy)} />);
    const panel = await screen.findByLabelText("경영 전략 검토");

    // When: management explicitly keeps the current strategy.
    fireEvent.click(within(panel).getByRole("button", { name: "현재 전략 유지" }));

    // Then: the maintain command is submitted and no new-version wording is shown.
    expect(await within(panel).findByText("현재 전략을 유지하는 검토를 기록했습니다.")).toBeInTheDocument();
    expect(reviewStrategy).toHaveBeenCalledWith(expect.objectContaining({ decision: "maintain" }));
    expect(within(panel).queryByText("전략 v2를 만들었습니다.")).not.toBeInTheDocument();
  });

  it("keeps v1 active after review creation and exposes v2 as a separate reviewed draft", async () => {
    const reviewStrategy = vi.fn(async () => success({
      idempotent: false,
      review: reviewedSnapshot().records.strategyReviews[0],
      version: reviewedSnapshot().current.strategyVersions[1],
    }));
    render(<StrategyReviewPanel client={clientFor("management", reviewStrategy)} />);
    const panel = await screen.findByLabelText("경영 전략 검토");

    fireEvent.change(within(panel).getByLabelText("제안 목표"), { target: { value: "검사와 포장 확인 후 납기 판단" } });
    fireEvent.click(within(panel).getByRole("button", { name: "새 전략 버전 만들기" }));

    expect(await within(panel).findByText(/활성 전략.*v1/)).toBeInTheDocument();
    expect(within(panel).getByText(/검토 버전.*v2/)).toBeInTheDocument();
    expect(within(panel).getByRole("button", { name: "새 업무에 적용" })).toBeEnabled();
  });

  it("cancels adoption with zero active-ref or history change", async () => {
    const adoptStrategy = vi.fn();
    const read = vi.fn();
    render(<StrategyReviewPanel client={clientFor("management", vi.fn(), {
      snapshot: reviewedSnapshot(),
      adoptStrategy,
      read,
    })} />);
    const panel = await screen.findByLabelText("경영 전략 검토");

    fireEvent.click(within(panel).getByRole("button", { name: "새 업무에 적용" }));
    const dialog = screen.getByRole("dialog");
    expect(dialog).toHaveTextContent(state.strategyVersions[0].objective);
    expect(dialog).toHaveTextContent("검사와 포장 확인 후 납기 판단");
    expect(dialog).toHaveTextContent("이후 새 업무에 적용, 진행 중 업무 유지.");
    fireEvent.click(within(dialog).getByRole("button", { name: "취소" }));

    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
    expect(adoptStrategy).not.toHaveBeenCalled();
    expect(read).not.toHaveBeenCalled();
    expect(within(panel).getByText(/활성 전략.*v1/)).toBeInTheDocument();
  });

  it("keeps keyboard focus inside the adoption dialog and restores it after Escape", async () => {
    render(<StrategyReviewPanel client={clientFor("management", vi.fn(), { snapshot: reviewedSnapshot() })} />);
    const panel = await screen.findByLabelText("경영 전략 검토");
    const trigger = within(panel).getByRole("button", { name: "새 업무에 적용" });
    trigger.focus();
    fireEvent.click(trigger);
    const dialog = screen.getByRole("dialog");
    const cancel = within(dialog).getByRole("button", { name: "취소" });
    const confirm = within(dialog).getByRole("button", { name: "새 업무에 적용" });

    await waitFor(() => expect(cancel).toHaveFocus());
    fireEvent.keyDown(document, { key: "Tab", shiftKey: true });
    expect(confirm).toHaveFocus();
    fireEvent.keyDown(document, { key: "Tab" });
    expect(cancel).toHaveFocus();
    fireEvent.keyDown(document, { key: "Escape" });

    expect(screen.queryByRole("dialog")).not.toBeInTheDocument();
    await waitFor(() => expect(trigger).toHaveFocus());
  });

  it("confirms one adoption with one stable request id under repeated clicks", async () => {
    let finish: (response: CompanyRuntimeResponse) => void = () => undefined;
    const received: { command?: StrategyAdoptionCommand } = {};
    const adoptionPromise = new Promise<CompanyRuntimeResponse>((resolve) => { finish = resolve; });
    const adoptStrategy = vi.fn((command: StrategyAdoptionCommand) => {
      received.command = command;
      return adoptionPromise;
    });
    render(<StrategyReviewPanel client={clientFor("management", vi.fn(), {
      snapshot: reviewedSnapshot(),
      adoptStrategy,
    })} />);
    const panel = await screen.findByLabelText("경영 전략 검토");
    fireEvent.click(within(panel).getByRole("button", { name: "새 업무에 적용" }));
    const confirm = within(screen.getByRole("dialog")).getByRole("button", { name: "새 업무에 적용" });

    fireEvent.click(confirm);
    fireEvent.click(confirm);

    expect(adoptStrategy).toHaveBeenCalledTimes(1);
    expect(received.command).toEqual({
      requestId: expect.stringMatching(/^[0-9a-f-]{36}$/),
      reviewId,
      expectedActiveRef: state.activeStrategyRef,
    });
    finish(success({ idempotent: false, activeStrategyRef: { ...state.activeStrategyRef, strategy_version_id: strategyV2Id } }));
    expect(await within(panel).findByText(/새 업무는 전략 v2를 사용합니다/)).toBeInTheDocument();
  });

  it("reconciles an uncertain adoption response from persisted state without retrying", async () => {
    let issuedRequestId = "";
    const adoptStrategy = vi.fn(async (command: StrategyAdoptionCommand) => {
      issuedRequestId = command.requestId;
      return {
        schemaVersion: 1 as const,
        requestId: crypto.randomUUID(),
        epoch,
        actorSessionRevision: 2,
        ok: false as const,
        error: { code: "unavailable" as const, message: "response_lost" },
      };
    });
    const read = vi.fn(async () => success({ snapshot: reviewedSnapshot(strategyV2Id, [{
      id: issuedRequestId,
      epoch,
      reviewId,
      fromRef: state.activeStrategyRef,
      toRef: { ...state.activeStrategyRef, strategy_version_id: strategyV2Id },
      actorId: "management-demo",
      adoptedAt: "2026-09-19T03:00:00.000Z",
    }]) }));
    render(<StrategyReviewPanel client={clientFor("management", vi.fn(), { snapshot: reviewedSnapshot(), adoptStrategy, read })} />);
    const panel = await screen.findByLabelText("경영 전략 검토");
    fireEvent.click(within(panel).getByRole("button", { name: "새 업무에 적용" }));
    fireEvent.click(within(screen.getByRole("dialog")).getByRole("button", { name: "새 업무에 적용" }));

    expect(await within(panel).findByText(/저장 상태에서 전략 v2 적용을 확인했습니다/)).toBeInTheDocument();
    expect(adoptStrategy).toHaveBeenCalledTimes(1);
    expect(read).toHaveBeenCalledTimes(1);
  });

  it("requires a fresh review when active strategy changes while the dialog is open", async () => {
    const captured: { subscriber?: (response: CompanyRuntimeResponse) => void } = {};
    const adoptStrategy = vi.fn();
    render(<StrategyReviewPanel client={clientFor("management", vi.fn(), {
      snapshot: reviewedSnapshot(),
      adoptStrategy,
      captureSubscriber: (next) => { captured.subscriber = next; },
    })} />);
    const panel = await screen.findByLabelText("경영 전략 검토");
    fireEvent.click(within(panel).getByRole("button", { name: "새 업무에 적용" }));
    if (!captured.subscriber) throw new Error("subscriber was not captured");
    captured.subscriber(success({
      snapshot: reviewedSnapshot(strategyV2Id, []),
      status: { epoch, actorId: "management-demo", role: "management", actorSessionRevision: 2, stopped: false },
    }));
    await waitFor(() => expect(within(panel).getByText("활성 전략 · v2")).toBeInTheDocument());

    fireEvent.click(within(screen.getByRole("dialog")).getByRole("button", { name: "새 업무에 적용" }));

    expect(await within(panel).findByText(/활성 전략이 바뀌었습니다.*새 검토/)).toBeInTheDocument();
    expect(adoptStrategy).not.toHaveBeenCalled();
  });
});
