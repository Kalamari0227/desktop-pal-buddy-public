import { act, fireEvent, render, screen, waitFor } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import type { CompanyRuntimeClient, CompanyRuntimeResponse } from "@/lib/companyRuntimeClient";
import { CompanyRuntimeControls } from "./CompanyRuntimeControls";

const firstEpoch = "f7091d6f-e310-46f5-ae2f-a761f136f36a";
const nextEpoch = "85c540f3-5e30-4a42-97f0-3f46577cf339";

type RuntimeStatus = {
  readonly epoch: string;
  readonly actorId: "sales-demo" | "production-demo" | "management-demo";
  readonly role: "sales" | "production" | "management";
  readonly actorSessionRevision: number;
  readonly stopped: boolean;
};

function response(payload: unknown, status: RuntimeStatus): CompanyRuntimeResponse {
  return {
    schemaVersion: 1,
    requestId: crypto.randomUUID(),
    epoch: status.epoch,
    actorSessionRevision: status.actorSessionRevision,
    ok: true,
    payload,
  };
}

function failure(code: "persistence_failed" | "unavailable", message: string): CompanyRuntimeResponse {
  return {
    schemaVersion: 1,
    requestId: crypto.randomUUID(),
    epoch: firstEpoch,
    actorSessionRevision: 0,
    ok: false,
    error: { code, message },
  };
}

function snapshot(status: RuntimeStatus, history: readonly { readonly epoch: string }[] = []) {
  return {
    formatVersion: 1,
    revision: status.actorSessionRevision,
    currentEpoch: status.epoch,
    stopped: status.stopped,
    history,
    projection: { actorId: status.actorId, role: status.role },
  };
}

function setupClient(
  initial: RuntimeStatus,
  aiConnection: { readonly state: "checking" | "ready" | "unavailable"; readonly reasonCode: "checking" | "local_profile_ready" | "profile_unavailable" } = { state: "checking", reasonCode: "checking" },
) {
  let current = initial;
  let publish: ((value: CompanyRuntimeResponse) => void) | undefined;
  const subscriberCleanup = vi.fn();
  const emit = (history: readonly { readonly epoch: string }[] = []) => {
    publish?.(response({ status: current, snapshot: snapshot(current, history), aiConnection }, current));
  };
  const client: CompanyRuntimeClient = {
    bootstrap: vi.fn(async () => response({ status: current, snapshot: snapshot(current), aiConnection }, current)),
    read: vi.fn(async () => response({ status: current, snapshot: snapshot(current), aiConnection }, current)),
    submit: vi.fn(async () => failure("unavailable", "not_used")),
    approve: vi.fn(async () => failure("unavailable", "not_used")),
    execute: vi.fn(async () => failure("unavailable", "not_used")),
    role: vi.fn(async ({ actorId }) => {
      const role = actorId === "sales-demo" ? "sales" : actorId === "production-demo" ? "production" : "management";
      current = { epoch: current.epoch, actorId, role, actorSessionRevision: current.actorSessionRevision + 1, stopped: current.stopped };
      emit();
      return response({ status: current }, current);
    }),
    stop: vi.fn(async () => {
      current = { ...current, stopped: true };
      emit();
      return response({ status: current }, current);
    }),
    resume: vi.fn(async () => {
      current = { ...current, stopped: false };
      emit();
      return response({ status: current }, current);
    }),
    reset: vi.fn(async () => {
      const prior = current.epoch;
      current = { epoch: nextEpoch, actorId: current.actorId, role: current.role, actorSessionRevision: current.actorSessionRevision + 1, stopped: true };
      emit([{ epoch: prior }]);
      return response({ status: current }, current);
    }),
    cancel: vi.fn(async () => response({ cancelled: true }, current)),
    reconcile: vi.fn(async () => failure("unavailable", "not_used")),
    subscribe: vi.fn((callback) => {
      publish = callback;
      return subscriberCleanup;
    }),
    getContext: vi.fn(() => ({ epoch: current.epoch, actorSessionRevision: current.actorSessionRevision })),
  };
  const emitState = (next: RuntimeStatus, history: readonly { readonly epoch: string }[] = []) => {
    current = next;
    emit(history);
  };
  return { client, subscriberCleanup, emitState };
}

describe("CompanyRuntimeControls", () => {
  it("labels checking, ready, and unavailable as connection preflight without claiming AI inference", async () => {
    const runtime = setupClient({ epoch: firstEpoch, actorId: "sales-demo", role: "sales", actorSessionRevision: 0, stopped: false });
    runtime.client.refreshAiConnection = vi.fn(async () => response({ aiConnection: { state: "ready", reasonCode: "local_profile_ready" } }, {
      epoch: firstEpoch, actorId: "sales-demo", role: "sales", actorSessionRevision: 0, stopped: false,
    }));
    render(<CompanyRuntimeControls client={runtime.client} />);

    await screen.findByText(firstEpoch);
    expect(screen.getByText("AI 연결 확인 중 · 아직 AI를 실행하지 않았습니다")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "AI 연결 다시 확인" })).toBeEnabled();
  });

  it.each([
    [{ state: "ready", reasonCode: "local_profile_ready" } as const, "AI 연결 준비됨 · 실제 AI 해석 전"],
    [{ state: "unavailable", reasonCode: "profile_unavailable" } as const, "AI 연결을 확인할 수 없음 · AI 해석을 시작하지 않습니다"],
  ])("keeps %s as a bounded readiness state", async (aiConnection, label) => {
    const runtime = setupClient(
      { epoch: firstEpoch, actorId: "sales-demo", role: "sales", actorSessionRevision: 0, stopped: false },
      aiConnection,
    );
    render(<CompanyRuntimeControls client={runtime.client} />);

    expect(await screen.findByText(label)).toBeInTheDocument();
    expect(screen.queryByText(/AI 해석이 완료|실제 AI가 실행됨/)).not.toBeInTheDocument();
  });

  it("scopes the identity badge to this panel instead of making a global AI claim", async () => {
    const runtime = setupClient({ epoch: firstEpoch, actorId: "sales-demo", role: "sales", actorSessionRevision: 0, stopped: false });
    render(<CompanyRuntimeControls client={runtime.client} />);

    await screen.findByText(firstEpoch);
    expect(screen.getByText("가상 ERP 패널 · 로컬 런타임 상태 제어 전용")).toBeInTheDocument();
    expect(screen.queryByText(/결정론적 Stub|실제 AI 아님|provider calls 0/)).not.toBeInTheDocument();
  });

  it("stops, keeps an explicit read available, and only lets production explicitly resume", async () => {
    const runtime = setupClient({ epoch: firstEpoch, actorId: "sales-demo", role: "sales", actorSessionRevision: 0, stopped: false });
    render(<CompanyRuntimeControls client={runtime.client} />);

    await screen.findByText(firstEpoch);
    fireEvent.click(screen.getByRole("button", { name: "런타임 중지" }));
    await screen.findByText("중지됨");
    expect(runtime.client.stop).toHaveBeenCalledTimes(1);

    fireEvent.click(screen.getByRole("button", { name: "최신 상태 읽기" }));
    await waitFor(() => expect(runtime.client.read).toHaveBeenCalledTimes(1));
    expect(screen.getByRole("button", { name: "명시적으로 재개" })).toBeDisabled();

    fireEvent.click(screen.getByRole("button", { name: "생산 역할로 전환" }));
    await screen.findByText("생산 역할");
    fireEvent.click(screen.getByRole("button", { name: "명시적으로 재개" }));
    await screen.findByText("동작 중");
    expect(runtime.client.resume).toHaveBeenCalledTimes(1);
  });

  it("does not reset on cancelled confirmation and archives the prior epoch after exact confirmation", async () => {
    const runtime = setupClient({ epoch: firstEpoch, actorId: "production-demo", role: "production", actorSessionRevision: 0, stopped: true });
    render(<CompanyRuntimeControls client={runtime.client} />);

    await screen.findByText(firstEpoch);
    fireEvent.click(screen.getByRole("button", { name: "새 epoch로 초기화" }));
    expect(screen.getByRole("alertdialog")).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "취소" }));
    expect(runtime.client.reset).not.toHaveBeenCalled();

    fireEvent.click(screen.getByRole("button", { name: "새 epoch로 초기화" }));
    fireEvent.change(screen.getByRole("textbox", { name: "초기화 확인" }), { target: { value: "RESET" } });
    fireEvent.click(screen.getByRole("button", { name: "새 중지된 epoch 초기화" }));

    await screen.findByText(nextEpoch);
    expect(runtime.client.reset).toHaveBeenCalledWith({ confirmation: "RESET" });
    expect(screen.getByText("읽기 전용 이력")).toBeInTheDocument();
    expect(screen.getByText(firstEpoch)).toBeInTheDocument();
    expect(screen.queryByRole("textbox", { name: /작업|요청/ })).not.toBeInTheDocument();
  });

  it("blocks sales recovery controls and surfaces corrupt or failed persistence without claiming recovery", async () => {
    const runtime = setupClient({ epoch: firstEpoch, actorId: "sales-demo", role: "sales", actorSessionRevision: 0, stopped: false });
    runtime.client.stop = vi.fn(async () => failure("persistence_failed", "corrupt_snapshot"));
    render(<CompanyRuntimeControls client={runtime.client} />);

    await screen.findByText("동작 중");
    expect(screen.getByRole("button", { name: "명시적으로 재개" })).toBeDisabled();
    expect(screen.getByRole("button", { name: "새 epoch로 초기화" })).toBeDisabled();
    fireEvent.click(screen.getByRole("button", { name: "최신 상태 읽기" }));
    await waitFor(() => expect(runtime.client.read).toHaveBeenCalledTimes(1));
    fireEvent.click(screen.getByRole("button", { name: "런타임 중지" }));
    expect(await screen.findByText("저장소 오류로 런타임 상태를 변경하지 못했습니다")).toBeInTheDocument();
    expect(screen.getByText("corrupt_snapshot")).toBeInTheDocument();
  });

  it("cleans its shared runtime subscription on unmount", async () => {
    const runtime = setupClient({ epoch: firstEpoch, actorId: "sales-demo", role: "sales", actorSessionRevision: 0, stopped: false });
    const view = render(<CompanyRuntimeControls client={runtime.client} />);
    await screen.findByText(firstEpoch);
    view.unmount();
    expect(runtime.subscriberCleanup).toHaveBeenCalledTimes(1);
  });

  it("discards a late failed stop reply after the shared runtime context changes", async () => {
    const runtime = setupClient({ epoch: firstEpoch, actorId: "sales-demo", role: "sales", actorSessionRevision: 0, stopped: false });
    let release: ((value: CompanyRuntimeResponse) => void) | undefined;
    runtime.client.stop = vi.fn(() => new Promise<CompanyRuntimeResponse>((resolve) => { release = resolve; }));
    render(<CompanyRuntimeControls client={runtime.client} />);

    await screen.findByText("영업 역할");
    fireEvent.click(screen.getByRole("button", { name: "런타임 중지" }));
    expect(runtime.client.stop).toHaveBeenCalledTimes(1);
    act(() => runtime.emitState({ epoch: nextEpoch, actorId: "production-demo", role: "production", actorSessionRevision: 1, stopped: true }, [{ epoch: firstEpoch }]));
    await screen.findByText(nextEpoch);
    await act(async () => release?.(failure("persistence_failed", "late_stop_failure")));

    expect(screen.queryByText("저장소 오류로 런타임 상태를 변경하지 못했습니다")).not.toBeInTheDocument();
    expect(screen.getByText("생산 역할")).toBeInTheDocument();
  });
});
