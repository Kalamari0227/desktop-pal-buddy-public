import { render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { DataQueryWorkflow } from "./DataQueryWorkflow";

describe("DataQueryWorkflow", () => {
  it("renders the natural-language query controls and demo connection state", () => {
    render(<DataQueryWorkflow />);

    expect(screen.getByRole("heading", { name: "자연어 데이터 조회" })).toBeInTheDocument();
    expect(screen.getByPlaceholderText("예: 고객별 긴급 작업 현황을 보여줘")).toBeInTheDocument();
    expect(screen.getByText("Demo")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /긴급 상태인 작업을 모두 보여줘/ })).toBeInTheDocument();
  });
});
