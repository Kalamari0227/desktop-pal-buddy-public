import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, BarChart3, Shield, FileSearch, MessageSquare, Zap, Play, Power, Loader2, CheckCircle2, Clock, Scale, BookCheck, ShieldCheck } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { streamChat, type Msg } from "@/lib/streamChat";
import { toast } from "sonner";
import ReactMarkdown from "react-markdown";
import type { TaskRecord } from "@/types/task";

interface AgentsModeProps {
  onBack: () => void;
}

type AgentCategory = "operational" | "audit";

interface AgentConfig {
  id: string;
  name: string;
  nameKo: string;
  description: string;
  icon: typeof BarChart3;
  capabilities: string[];
  color: string;
  prompt: string;
  taskFilter: (task: TaskRecord) => boolean;
  category: AgentCategory;
}

const agentConfigs: AgentConfig[] = [
  // 실무 에이전트
  {
    id: "market",
    name: "Market Agent",
    nameKo: "시장 분석",
    description: "시장 동향, 경쟁사 분석, 가격 트렌드 모니터링",
    icon: BarChart3,
    capabilities: ["시장 가격 추적", "경쟁사 동향 분석", "수요 예측"],
    color: "hsl(var(--agent-market))",
    prompt: "현재 자동차 강판 시장 동향을 분석해주세요. 원자재 가격 변동, 경쟁사 움직임, 수요 전망을 포함해서 간결하게 브리핑해주세요.",
    taskFilter: (task) => task.category === "price" || task.source === "market",
    category: "operational",
  },
  {
    id: "risk",
    name: "Risk Agent",
    nameKo: "리스크 감지",
    description: "납기, 품질, 가격 리스크 실시간 모니터링 및 경고",
    icon: Shield,
    capabilities: ["납기 지연 감지", "품질 이슈 추적", "가격 변동 경고"],
    color: "hsl(var(--agent-risk))",
    prompt: "현재 등록된 리스크 항목들을 분석하고, 우선순위별 대응 방안을 제안해주세요. 납기, 품질, 가격 카테고리별로 정리해주세요.",
    taskFilter: (task) => task.source === "risk" || task.category === "delivery" || task.category === "quality",
    category: "operational",
  },
  {
    id: "docs",
    name: "Docs Agent",
    nameKo: "문서 탐색",
    description: "내부 문서, 회의록, 계약서 검색 및 요약",
    icon: FileSearch,
    capabilities: ["문서 검색", "회의록 요약", "계약 조건 분석"],
    color: "hsl(var(--agent-docs))",
    prompt: "최근 고객 관련 문서와 회의록을 기반으로 핵심 요약을 작성해주세요. 고객별 주요 이슈와 액션 아이템을 정리해주세요.",
    taskFilter: (task) => task.source === "docs" || task.source === "manual",
    category: "operational",
  },
  {
    id: "sales",
    name: "Sales Agent",
    nameKo: "판매 분석",
    description: "판매 실적, 수익성, KPI 분석 및 보고서 생성",
    icon: BarChart3,
    capabilities: ["실적 집계", "수익성 분석", "KPI 대시보드"],
    color: "hsl(var(--agent-sales))",
    prompt: "자동차 강판 판매 실적을 분석해주세요. 고객별 매출, 수익성 변화, 주요 KPI 달성률을 요약해주세요.",
    taskFilter: (task) => task.category === "price" || task.source === "sales",
    category: "operational",
  },
  {
    id: "planner",
    name: "Planner Agent",
    nameKo: "업무 계획",
    description: "일정 관리, 미팅 준비, 보고서 초안 작성",
    icon: MessageSquare,
    capabilities: ["미팅 브리핑", "보고서 초안", "일정 최적화"],
    color: "hsl(var(--agent-planner))",
    prompt: "이번 주 주요 업무 계획을 수립해주세요. 고객 미팅 준비사항, 보고서 작성 일정, 우선순위 작업을 정리해주세요.",
    taskFilter: (task) => task.source === "planner" || task.source === "manual",
    category: "operational",
  },
  // 감사 에이전트
  {
    id: "legal",
    name: "Legal Audit Agent",
    nameKo: "법률 감사",
    description: "계약 조건, 법적 리스크, 규제 준수 여부를 검토",
    icon: Scale,
    capabilities: ["계약서 법률 검토", "규제 준수 확인", "법적 리스크 평가"],
    color: "hsl(var(--status-review))",
    prompt: "현재 진행 중인 거래와 계약 조건을 법률적 관점에서 검토해주세요. 공정거래법, 하도급법 등 관련 법규 저촉 여부와 잠재적 법적 리스크를 분석해주세요.",
    taskFilter: (task) => task.source === "legal" || task.category === "contract",
    category: "audit",
  },
  {
    id: "compliance",
    name: "Compliance Agent",
    nameKo: "사규 준수",
    description: "내부 규정, 결재 기준, 권한 범위 준수 여부 확인",
    icon: BookCheck,
    capabilities: ["사규 위반 감지", "결재 기준 확인", "권한 범위 검증"],
    color: "hsl(var(--status-review))",
    prompt: "현재 작업과 의사결정이 사내 규정 및 결재 기준에 부합하는지 검토해주세요. 위반 가능성이 있는 항목과 시정 방안을 제시해주세요.",
    taskFilter: (task) => task.source === "compliance" || task.source === "manual",
    category: "audit",
  },
  {
    id: "purpose",
    name: "Purpose Audit Agent",
    nameKo: "목적 적합성",
    description: "전략 목표 부합 여부, 자원 배분 적정성, ROI 타당성 검증",
    icon: ShieldCheck,
    capabilities: ["전략 정합성 검토", "ROI 타당성 분석", "자원 배분 적정성"],
    color: "hsl(var(--status-review))",
    prompt: "현재 진행 중인 프로젝트와 작업이 조직의 전략 목표에 부합하는지 검토해주세요. 자원 배분의 적정성, ROI 타당성, 우선순위 적절성을 분석해주세요.",
    taskFilter: (task) => task.source === "audit" || task.source === "manual",
    category: "audit",
  },
];

export function AgentsMode({ onBack }: AgentsModeProps) {
  const [selectedAgent, setSelectedAgent] = useState<string | null>(null);
  const [agentStates, setAgentStates] = useState<Record<string, boolean>>(() => {
    const saved = localStorage.getItem("agentStates");
    return saved ? JSON.parse(saved) : { market: true, risk: true, docs: true, sales: false, planner: false };
  });
  const [tasks, setTasks] = useState<TaskRecord[]>([]);
  const [running, setRunning] = useState<string | null>(null);
  const [results, setResults] = useState<Record<string, string>>({});

  // Persist toggle state
  useEffect(() => {
    localStorage.setItem("agentStates", JSON.stringify(agentStates));
  }, [agentStates]);

  // Fetch tasks for activity logs
  useEffect(() => {
    supabase
      .from("tasks")
      .select("*")
      .order("created_at", { ascending: false })
      .limit(50)
      .then(({ data }) => setTasks(data || []));
  }, []);

  const toggleAgent = (id: string) => {
    setAgentStates((prev) => {
      const next = { ...prev, [id]: !prev[id] };
      toast.success(next[id] ? "에이전트가 활성화되었습니다" : "에이전트가 비활성화되었습니다");
      return next;
    });
  };

  const runAgent = useCallback(async (agent: AgentConfig) => {
    if (running) return;
    setRunning(agent.id);
    setResults((prev) => ({ ...prev, [agent.id]: "" }));

    // Build context from related tasks
    const relatedTasks = tasks.filter(agent.taskFilter).slice(0, 10);
    const taskContext = relatedTasks.length > 0
      ? `\n\n현재 관련 작업 데이터:\n${relatedTasks.map((t) => `- [${t.severity || "보통"}] ${t.title} (${t.customer || "미지정"}, ${t.status})`).join("\n")}`
      : "";

    const messages: Msg[] = [
      { role: "user", content: agent.prompt + taskContext },
    ];

    let accumulated = "";
    try {
      await streamChat({
        messages,
        onDelta: (chunk) => {
          accumulated += chunk;
          setResults((prev) => ({ ...prev, [agent.id]: accumulated }));
        },
        onDone: () => {
          setRunning(null);
          toast.success(`${agent.nameKo} 분석이 완료되었습니다`);
        },
        onError: (err) => {
          setRunning(null);
          toast.error(err);
        },
      });
    } catch {
      setRunning(null);
      toast.error("에이전트 실행에 실패했습니다");
    }
  }, [running, tasks]);

  const agent = agentConfigs.find((a) => a.id === selectedAgent);
  const activeCount = Object.values(agentStates).filter(Boolean).length;

  return (
    <div className="flex-1 h-full overflow-y-auto p-6 space-y-6 scrollbar-thin">
      <div className="flex items-center gap-3">
        <button onClick={onBack} className="p-1.5 rounded-lg hover:bg-secondary transition-colors">
          <ArrowLeft className="w-4 h-4 text-muted-foreground" />
        </button>
        <div>
          <h1 className="text-xl font-semibold tracking-tight">AI 에이전트</h1>
          <p className="text-[13px] text-muted-foreground mt-0.5">에이전트 상태 및 실행 관리</p>
        </div>
      </div>

      {/* Overview stats */}
      <div className="grid grid-cols-4 gap-3">
        {[
          { label: "활성 에이전트", value: `${activeCount}/${agentConfigs.length}`, color: "hsl(var(--status-completed))" },
          { label: "실무 에이전트", value: `${agentConfigs.filter(a => a.category === "operational").length}명`, color: "hsl(var(--primary))" },
          { label: "감사 에이전트", value: `${agentConfigs.filter(a => a.category === "audit").length}명`, color: "hsl(var(--status-review))" },
          { label: "관련 작업", value: `${tasks.length}건`, color: "hsl(var(--primary))" },
        ].map((stat, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            className="p-4 rounded-2xl bg-secondary/20 border border-border/30"
          >
            <p className="text-[10px] text-muted-foreground">{stat.label}</p>
            <p className="text-lg font-semibold mt-1 font-mono" style={{ color: stat.color }}>{stat.value}</p>
          </motion.div>
        ))}
      </div>

      {/* Agent grid or detail */}
      {!selectedAgent ? (
        <div className="space-y-5">
          {/* 실무 에이전트 */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="w-5 h-5 rounded-md bg-primary/10 flex items-center justify-center">
                <Zap className="w-3 h-3 text-primary" />
              </div>
              <h3 className="text-[12px] font-semibold text-foreground">실무 에이전트</h3>
              <span className="text-[9px] text-muted-foreground px-1.5 py-0.5 rounded-md bg-primary/5">Operational</span>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {agentConfigs.filter(a => a.category === "operational").map((a, i) => {
                const isActive = agentStates[a.id] ?? false;
                const relatedCount = tasks.filter(a.taskFilter).length;
                return (
                  <motion.div
                    key={a.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1 + i * 0.05 }}
                    className="p-5 rounded-2xl bg-secondary/20 border border-border/30 hover:border-border/60 transition-all"
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => setSelectedAgent(a.id)}>
                        <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: `${a.color}20` }}>
                          <a.icon className="w-4 h-4" style={{ color: a.color }} />
                        </div>
                        <div>
                          <p className="text-[12px] font-medium text-foreground">{a.nameKo}</p>
                          <p className="text-[10px] text-muted-foreground">{a.name}</p>
                        </div>
                      </div>
                      <button onClick={() => toggleAgent(a.id)} className="w-7 h-7 rounded-lg flex items-center justify-center transition-colors" style={{ background: isActive ? "hsl(var(--status-completed) / 0.1)" : "hsl(var(--muted) / 0.3)" }}>
                        <Power className="w-3.5 h-3.5" style={{ color: isActive ? "hsl(var(--status-completed))" : "hsl(var(--muted-foreground))" }} />
                      </button>
                    </div>
                    <p className="text-[11px] text-muted-foreground leading-relaxed mb-3">{a.description}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-[9px] text-muted-foreground">관련 작업 {relatedCount}건</span>
                      <button onClick={() => { if (!isActive) { toast.error("에이전트를 먼저 활성화해주세요"); return; } setSelectedAgent(a.id); runAgent(a); }} disabled={running === a.id} className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-medium transition-colors" style={{ background: isActive ? "hsl(var(--primary) / 0.1)" : "hsl(var(--muted) / 0.2)", color: isActive ? "hsl(var(--primary))" : "hsl(var(--muted-foreground))" }}>
                        {running === a.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <Play className="w-3 h-3" />}
                        실행
                      </button>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>

          {/* 감사 에이전트 */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="w-5 h-5 rounded-md bg-status-review/10 flex items-center justify-center">
                <Scale className="w-3 h-3 text-status-review" />
              </div>
              <h3 className="text-[12px] font-semibold text-foreground">감사 에이전트</h3>
              <span className="text-[9px] text-muted-foreground px-1.5 py-0.5 rounded-md bg-status-review/5">Audit & Compliance</span>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {agentConfigs.filter(a => a.category === "audit").map((a, i) => {
                const isActive = agentStates[a.id] ?? false;
                const relatedCount = tasks.filter(a.taskFilter).length;
                return (
                  <motion.div
                    key={a.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 + i * 0.05 }}
                    className="p-5 rounded-2xl border hover:border-status-review/40 transition-all"
                    style={{ background: "hsl(var(--status-review) / 0.03)", borderColor: "hsl(var(--status-review) / 0.15)" }}
                  >
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2.5 cursor-pointer" onClick={() => setSelectedAgent(a.id)}>
                        <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: `${a.color}15` }}>
                          <a.icon className="w-4 h-4" style={{ color: a.color }} />
                        </div>
                        <div>
                          <p className="text-[12px] font-medium text-foreground">{a.nameKo}</p>
                          <p className="text-[10px] text-muted-foreground">{a.name}</p>
                        </div>
                      </div>
                      <button onClick={() => toggleAgent(a.id)} className="w-7 h-7 rounded-lg flex items-center justify-center transition-colors" style={{ background: isActive ? "hsl(var(--status-completed) / 0.1)" : "hsl(var(--muted) / 0.3)" }}>
                        <Power className="w-3.5 h-3.5" style={{ color: isActive ? "hsl(var(--status-completed))" : "hsl(var(--muted-foreground))" }} />
                      </button>
                    </div>
                    <p className="text-[11px] text-muted-foreground leading-relaxed mb-3">{a.description}</p>
                    <div className="flex items-center justify-between">
                      <span className="text-[9px] text-muted-foreground">관련 작업 {relatedCount}건</span>
                      <button onClick={() => { if (!isActive) { toast.error("에이전트를 먼저 활성화해주세요"); return; } setSelectedAgent(a.id); runAgent(a); }} disabled={running === a.id} className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-[10px] font-medium transition-colors" style={{ background: isActive ? "hsl(var(--status-review) / 0.1)" : "hsl(var(--muted) / 0.2)", color: isActive ? "hsl(var(--status-review))" : "hsl(var(--muted-foreground))" }}>
                        {running === a.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <Play className="w-3 h-3" />}
                        실행
                      </button>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </div>
        </div>
      ) : agent ? (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
          <button onClick={() => setSelectedAgent(null)} className="flex items-center gap-1.5 text-[11px] text-muted-foreground hover:text-foreground">
            <ArrowLeft className="w-3 h-3" /> 에이전트 목록으로
          </button>

          {/* Agent header */}
          <div className="p-5 rounded-2xl bg-secondary/20 border border-border/30">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: `${agent.color}20` }}>
                <agent.icon className="w-5 h-5" style={{ color: agent.color }} />
              </div>
              <div className="flex-1">
                <h2 className="text-[14px] font-semibold">{agent.nameKo}</h2>
                <p className="text-[10px] text-muted-foreground">{agent.name}</p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => runAgent(agent)}
                  disabled={running === agent.id || !agentStates[agent.id]}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-semibold transition-colors"
                  style={{ background: "hsl(var(--primary))", color: "hsl(var(--primary-foreground))" }}
                >
                  {running === agent.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
                  {running === agent.id ? "분석 중..." : "에이전트 실행"}
                </button>
                <button
                  onClick={() => toggleAgent(agent.id)}
                  className="w-8 h-8 rounded-lg flex items-center justify-center transition-colors"
                  style={{
                    background: agentStates[agent.id] ? "hsl(var(--status-completed) / 0.1)" : "hsl(var(--muted) / 0.3)",
                  }}
                >
                  <Power className="w-4 h-4" style={{ color: agentStates[agent.id] ? "hsl(var(--status-completed))" : "hsl(var(--muted-foreground))" }} />
                </button>
              </div>
            </div>
            <p className="text-[11px] text-muted-foreground mb-3">{agent.description}</p>
            <div className="flex flex-wrap gap-2">
              {agent.capabilities.map((cap, i) => (
                <span key={i} className="flex items-center gap-1 text-[10px] px-2 py-1 rounded-lg bg-primary/5 text-muted-foreground">
                  <Zap className="w-2.5 h-2.5 text-primary" />
                  {cap}
                </span>
              ))}
            </div>
          </div>

          {/* AI Result */}
          <AnimatePresence>
            {results[agent.id] && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-5 rounded-2xl bg-primary/5 border border-primary/10"
              >
                <div className="flex items-center gap-2 mb-3">
                  {running === agent.id ? (
                    <Loader2 className="w-4 h-4 text-primary animate-spin" />
                  ) : (
                    <CheckCircle2 className="w-4 h-4 text-primary" />
                  )}
                  <h3 className="text-[12px] font-semibold">
                    {running === agent.id ? "분석 진행 중..." : "분석 결과"}
                  </h3>
                </div>
                <div className="prose prose-sm prose-invert max-w-none text-[12px] leading-relaxed text-secondary-foreground">
                  <ReactMarkdown>{results[agent.id]}</ReactMarkdown>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Activity log from tasks */}
          <div>
            <h3 className="text-[12px] font-semibold mb-2 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-muted-foreground" />
              관련 활동 로그
            </h3>
            {(() => {
              const relatedTasks = tasks.filter(agent.taskFilter).slice(0, 8);
              if (relatedTasks.length === 0) {
                return <p className="text-[11px] text-muted-foreground py-4 text-center">관련 활동이 없습니다.</p>;
              }
              const sevColors: Record<string, string> = {
                critical: "hsl(var(--status-alert))", high: "hsl(var(--status-review))",
                medium: "hsl(var(--status-review))", low: "hsl(var(--status-completed))",
              };
              return (
                <div className="space-y-1.5">
                  {relatedTasks.map((task) => (
                    <div key={task.id} className="flex items-center justify-between p-3 rounded-xl bg-secondary/10 border border-border/20">
                      <div className="flex items-center gap-2.5">
                        <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: sevColors[task.severity ?? ""] || "hsl(var(--muted-foreground))" }} />
                        <div>
                          <p className="text-[11px] text-foreground">{task.title}</p>
                          <p className="text-[9px] text-muted-foreground mt-0.5">
                            {task.customer || "미지정"} · {task.status === "done" ? "완료" : task.status === "in_progress" ? "진행 중" : "대기"}
                          </p>
                        </div>
                      </div>
                      <span className="text-[9px] text-muted-foreground">
                        {new Date(task.created_at).toLocaleDateString("ko-KR", { month: "numeric", day: "numeric" })}
                      </span>
                    </div>
                  ))}
                </div>
              );
            })()}
          </div>
        </motion.div>
      ) : null}
    </div>
  );
}
