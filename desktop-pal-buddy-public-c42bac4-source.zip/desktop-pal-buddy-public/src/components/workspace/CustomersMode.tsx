import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { supabase } from "@/integrations/supabase/client";
import { ArrowLeft, Building2, AlertTriangle, Clock, ArrowRight } from "lucide-react";
import type { TaskRecord } from "@/types/task";

interface CustomersModeProps {
  onBack: () => void;
  onModeSelect: (mode: string) => void;
  initialCustomer?: string;
}

interface CustomerSummary {
  name: string;
  taskCount: number;
  pendingCount: number;
  criticalCount: number;
  latestTask: TaskRecord;
  categories: string[];
}

const categoryLabels: Record<string, string> = {
  delivery: "납기",
  quality: "품질",
  price: "가격",
};

const sevColors: Record<string, string> = {
  critical: "hsl(var(--status-alert))",
  high: "hsl(var(--status-review))",
  medium: "hsl(var(--status-review))",
  low: "hsl(var(--status-completed))",
};

export function CustomersMode({ onBack, initialCustomer }: CustomersModeProps) {
  const [customers, setCustomers] = useState<CustomerSummary[]>([]);
  const [selectedCustomer, setSelectedCustomer] = useState<string | null>(initialCustomer || null);
  const [allTasks, setAllTasks] = useState<TaskRecord[]>([]);

  useEffect(() => {
    supabase
      .from("tasks")
      .select("*")
      .order("created_at", { ascending: false })
      .then(({ data }) => {
        const tasks = data || [];
        setAllTasks(tasks);

        const map = new Map<string, TaskRecord[]>();
        tasks.forEach((t) => {
          const name = t.customer || "미지정";
          if (!map.has(name)) map.set(name, []);
          map.get(name)!.push(t);
        });

        const summaries: CustomerSummary[] = Array.from(map.entries()).map(([name, tasks]) => ({
          name,
          taskCount: tasks.length,
          pendingCount: tasks.filter((t) => t.status === "pending").length,
          criticalCount: tasks.filter((t) => t.severity === "critical" || t.severity === "high").length,
          latestTask: tasks[0],
          categories: [...new Set(tasks.map((t) => t.category).filter((category): category is string => Boolean(category)))],
        }));

        summaries.sort((a, b) => b.criticalCount - a.criticalCount || b.taskCount - a.taskCount);
        setCustomers(summaries);
      });
  }, []);

  const customerTasks = selectedCustomer
    ? allTasks.filter((t) => (t.customer || "미지정") === selectedCustomer)
    : [];

  return (
    <div className="flex-1 h-full overflow-y-auto p-6 space-y-6 scrollbar-thin">
      <div className="flex items-center gap-3">
        <button onClick={onBack} className="p-1.5 rounded-lg hover:bg-secondary transition-colors">
          <ArrowLeft className="w-4 h-4 text-muted-foreground" />
        </button>
        <div>
          <h1 className="text-xl font-semibold tracking-tight">고객 관리</h1>
          <p className="text-[13px] text-muted-foreground mt-0.5">고객별 현황과 이슈를 한눈에 확인</p>
        </div>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: "전체 고객", value: `${customers.length}사`, icon: Building2, color: "hsl(var(--primary))" },
          { label: "긴급 대응 필요", value: `${customers.filter(c => c.criticalCount > 0).length}사`, icon: AlertTriangle, color: "hsl(var(--status-alert))" },
          { label: "미결 항목 보유", value: `${customers.filter(c => c.pendingCount > 0).length}사`, icon: Clock, color: "hsl(var(--status-review))" },
        ].map((stat, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.05 }}
            className="p-4 rounded-2xl bg-secondary/20 border border-border/30"
          >
            <stat.icon className="w-4 h-4 mb-2" style={{ color: stat.color }} />
            <p className="text-[10px] text-muted-foreground">{stat.label}</p>
            <p className="text-lg font-semibold mt-0.5 font-mono" style={{ color: stat.color }}>{stat.value}</p>
          </motion.div>
        ))}
      </div>

      {/* Customer list or detail */}
      {!selectedCustomer ? (
        <section className="space-y-2">
          <h2 className="text-[13px] font-semibold mb-3">고객 목록</h2>
          {customers.length === 0 ? (
            <p className="text-[12px] text-muted-foreground py-8 text-center">등록된 고객이 없습니다.</p>
          ) : (
            customers.map((c, i) => (
              <motion.button
                key={c.name}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.1 + i * 0.04 }}
                onClick={() => setSelectedCustomer(c.name)}
                className="w-full text-left flex items-center justify-between p-4 rounded-xl bg-secondary/20 border border-border/30 hover:border-border/60 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center text-[13px] font-bold text-primary">
                    {c.name.charAt(0)}
                  </div>
                  <div>
                    <p className="text-[13px] font-medium text-foreground">{c.name}</p>
                    <div className="flex items-center gap-2 mt-0.5">
                      <span className="text-[10px] text-muted-foreground">작업 {c.taskCount}건</span>
                      {c.pendingCount > 0 && (
                        <span className="text-[10px] text-status-review">대기 {c.pendingCount}</span>
                      )}
                      {c.criticalCount > 0 && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-status-alert/10 text-status-alert font-medium">
                          긴급 {c.criticalCount}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {c.categories.slice(0, 3).map((cat) => (
                    <span key={cat} className="text-[9px] px-1.5 py-0.5 rounded bg-muted/50 text-muted-foreground">
                      {categoryLabels[cat] || cat}
                    </span>
                  ))}
                  <ArrowRight className="w-3.5 h-3.5 text-muted-foreground" />
                </div>
              </motion.button>
            ))
          )}
        </section>
      ) : (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button onClick={() => setSelectedCustomer(null)} className="p-1 rounded hover:bg-secondary">
                <ArrowLeft className="w-3.5 h-3.5 text-muted-foreground" />
              </button>
              <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-[12px] font-bold text-primary">
                {selectedCustomer.charAt(0)}
              </div>
              <h2 className="text-[15px] font-semibold">{selectedCustomer}</h2>
            </div>
          </div>

          <div className="space-y-2">
            {customerTasks.map((task, i) => {
              const statusLabels: Record<string, string> = { pending: "대기", in_progress: "진행 중", done: "완료" };
              return (
                <motion.div
                  key={task.id}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.04 }}
                  className="p-4 rounded-xl bg-secondary/20 border border-border/30"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <div
                        className="w-2 h-2 rounded-full mt-1.5 flex-shrink-0"
                        style={{ background: sevColors[task.severity ?? ""] || "hsl(var(--muted-foreground))" }}
                      />
                      <div>
                        <p className="text-[12px] font-medium text-foreground">{task.title}</p>
                        {task.description && (
                          <p className="text-[11px] text-muted-foreground mt-1 line-clamp-2">{task.description}</p>
                        )}
                        <div className="flex items-center gap-2 mt-2">
                          {task.category && (
                            <span className="text-[9px] px-1.5 py-0.5 rounded bg-muted/50 text-muted-foreground">
                              {categoryLabels[task.category] || task.category}
                            </span>
                          )}
                          <span className="text-[9px] text-muted-foreground">
                            {statusLabels[task.status] || task.status}
                          </span>
                          <span className="text-[9px] text-muted-foreground">
                            {new Date(task.created_at).toLocaleDateString("ko-KR")}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </section>
      )}
    </div>
  );
}
