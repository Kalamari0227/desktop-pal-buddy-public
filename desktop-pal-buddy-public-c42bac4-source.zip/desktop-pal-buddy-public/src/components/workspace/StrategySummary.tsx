import type { Strategy, StrategyVersion } from "@/lib/agentic";

interface StrategySummaryProps {
  strategy: Strategy;
  version: StrategyVersion;
  showFixtureNote?: boolean;
  contentHash?: string;
  onOpenLineage?: () => void;
}

export function StrategySummary({ strategy, version, showFixtureNote = false, contentHash, onOpenLineage }: StrategySummaryProps) {
  return (
    <section aria-label="연결된 전략" className="rounded-lg border border-blue-500/20 bg-blue-500/5 p-3">
      <div className="flex items-center justify-between gap-3">
        <div className="min-w-0">
          <p className="text-[10px] text-muted-foreground">연결된 전략</p>
          <p className="mt-1 truncate text-[12px] font-semibold text-foreground">{strategy.title}</p>
        </div>
        <span className="shrink-0 rounded-md border border-blue-500/20 bg-blue-500/10 px-2 py-1 text-[11px] font-medium text-blue-300">
          v{version.version}
        </span>
      </div>
      <p className="mt-2 text-[11px] leading-relaxed text-foreground">{version.objective}</p>
      <p className="mt-2 text-[10px] leading-relaxed text-muted-foreground">검토 질문 · {version.review_question}</p>
      {contentHash && <p className="mt-2 font-mono text-[10px] text-muted-foreground">hash {contentHash.slice(0, 12)}…</p>}
      {showFixtureNote && <p className="mt-2 text-[10px] text-muted-foreground">가상 데이터 · 새로고침 시 초기화</p>}
      {onOpenLineage && (
        <button type="button" onClick={onOpenLineage} className="mt-3 h-8 rounded-lg border border-blue-500/30 bg-blue-500/10 px-3 text-[11px] font-semibold text-blue-200">
          전략 계보 보기
        </button>
      )}
    </section>
  );
}
