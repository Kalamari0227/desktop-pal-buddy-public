import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import ReactMarkdown from "react-markdown";
import { streamChat, type Msg } from "@/lib/streamChat";
import { toast } from "sonner";
import {
  ArrowLeft,
  ArrowRight,
  Building2,
  Calendar,
  Clock,
  Loader2,
  MapPin,
  Sparkles,
  User,
  FileText,
  CheckCircle2,
  RotateCcw,
} from "lucide-react";

/* ── Mock customer data ── */
const customers = [
  {
    id: "hyundai",
    name: "현대자동차",
    code: "현대자동차",
    contact: "김철수 부장",
    segment: "자동차 강판",
    recentTopics: ["납기 조정", "GA 강판 품질", "2분기 물량 협의"],
    lastMeeting: "2025-02-20",
    riskLevel: "high" as const,
  },
  {
    id: "kia",
    name: "기아",
    code: "기아",
    contact: "박영희 차장",
    segment: "자동차 강판",
    recentTopics: ["신규 모델 강판 사양", "가격 재협상", "친환경 강판"],
    lastMeeting: "2025-02-28",
    riskLevel: "medium" as const,
  },
  {
    id: "toyota",
    name: "도요타",
    code: "도요타",
    contact: "田中 太郎 (다나카)",
    segment: "수출 강판",
    recentTopics: ["품질 이슈 재발 방지", "납기 일정", "JIS 규격 확인"],
    lastMeeting: "2025-03-01",
    riskLevel: "low" as const,
  },
  {
    id: "gm",
    name: "GM Korea",
    code: "GM Korea",
    contact: "이준호 과장",
    segment: "자동차 강판",
    recentTopics: ["DP강 공급 확대", "원가 절감 협의"],
    lastMeeting: "2025-02-15",
    riskLevel: "low" as const,
  },
];

type MeetingType = "visit" | "video" | "internal";
const meetingTypes: { id: MeetingType; label: string; icon: typeof Calendar }[] = [
  { id: "visit", label: "방문 미팅", icon: MapPin },
  { id: "video", label: "화상 미팅", icon: Calendar },
  { id: "internal", label: "내부 협의", icon: User },
];

interface MeetingPrepModeProps {
  onBack: () => void;
}

type Step = "select" | "configure" | "generating" | "result";

export function MeetingPrepMode({ onBack }: MeetingPrepModeProps) {
  const [step, setStep] = useState<Step>("select");
  const [selectedCustomer, setSelectedCustomer] = useState<string | null>(null);
  const [selectedType, setSelectedType] = useState<MeetingType>("visit");
  const [selectedTopics, setSelectedTopics] = useState<string[]>([]);
  const [briefing, setBriefing] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const resultRef = useRef<HTMLDivElement>(null);

  const customer = customers.find((c) => c.id === selectedCustomer);

  const toggleTopic = (topic: string) => {
    setSelectedTopics((prev) =>
      prev.includes(topic) ? prev.filter((t) => t !== topic) : [...prev, topic]
    );
  };

  const handleSelectCustomer = (id: string) => {
    setSelectedCustomer(id);
    const c = customers.find((x) => x.id === id);
    if (c) setSelectedTopics(c.recentTopics.slice(0, 2));
    setStep("configure");
  };

  const handleGenerate = async () => {
    if (!customer) return;
    setStep("generating");
    setIsGenerating(true);
    setBriefing("");

    const prompt = `당신은 자동차 강판 마케팅/판매 전문 AI 비서입니다.
다음 고객과의 ${selectedType === "visit" ? "방문" : selectedType === "video" ? "화상" : "내부"} 미팅을 위한 브리핑 자료를 작성해주세요.

**고객 정보:**
- 고객사: ${customer.name} (${customer.code})
- 담당자: ${customer.contact}
- 세그먼트: ${customer.segment}
- 최근 미팅일: ${customer.lastMeeting}

**이번 미팅 주요 안건:**
${selectedTopics.map((t) => `- ${t}`).join("\n")}

다음 항목을 포함하여 브리핑을 작성해주세요:
1. **고객 현황 요약** - 최근 거래 동향 및 이슈
2. **안건별 준비사항** - 각 안건에 대한 핵심 포인트와 대응 전략
3. **리스크 체크포인트** - 주의해야 할 사항
4. **제안/협상 포인트** - 우리 측에서 제안할 수 있는 내용
5. **참고 데이터** - 관련 수치나 시장 동향

마크다운 형식으로 깔끔하게 작성해주세요.`;

    const messages: Msg[] = [{ role: "user", content: prompt }];
    let fullText = "";

    try {
      await streamChat({
        messages,
        onDelta: (chunk) => {
          fullText += chunk;
          setBriefing(fullText);
        },
        onDone: () => {
          setIsGenerating(false);
          setStep("result");
        },
        onError: (e) => {
          toast.error(e);
          setIsGenerating(false);
          setStep("configure");
        },
      });
    } catch {
      toast.error("브리핑 생성에 실패했습니다.");
      setIsGenerating(false);
      setStep("configure");
    }
  };

  const handleReset = () => {
    setStep("select");
    setSelectedCustomer(null);
    setSelectedTopics([]);
    setBriefing("");
  };

  useEffect(() => {
    if (resultRef.current && (step === "generating" || step === "result")) {
      resultRef.current.scrollTop = resultRef.current.scrollHeight;
    }
  }, [briefing, step]);

  const riskColor = (level: string) =>
    level === "high"
      ? "bg-status-alert/15 text-status-alert border-status-alert/20"
      : level === "medium"
      ? "bg-status-review/15 text-status-review border-status-review/20"
      : "bg-status-completed/15 text-status-completed border-status-completed/20";

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-3 px-6 py-4 border-b border-border/50">
        <button
          onClick={step === "select" ? onBack : handleReset}
          className="w-8 h-8 rounded-lg hover:bg-secondary flex items-center justify-center transition-colors"
        >
          <ArrowLeft className="w-4 h-4 text-muted-foreground" />
        </button>
        <div className="flex-1">
          <h2 className="text-[14px] font-semibold">회의/방문 준비</h2>
          <p className="text-[11px] text-muted-foreground">
            {step === "select" && "고객사를 선택하세요"}
            {step === "configure" && `${customer?.name} — 미팅 설정`}
            {step === "generating" && "AI 브리핑 생성 중..."}
            {step === "result" && `${customer?.name} 미팅 브리핑`}
          </p>
        </div>
        {/* Step indicator */}
        <div className="flex items-center gap-1.5">
          {(["select", "configure", "result"] as const).map((s, i) => (
            <div
              key={s}
              className={`h-1.5 rounded-full transition-all ${
                (step === s || (step === "generating" && s === "result"))
                  ? "w-6 bg-primary"
                  : i < ["select", "configure", "result"].indexOf(step === "generating" ? "result" : step)
                  ? "w-4 bg-primary/40"
                  : "w-4 bg-secondary"
              }`}
            />
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto">
        <AnimatePresence mode="wait">
          {/* Step 1: Customer Selection */}
          {step === "select" && (
            <motion.div
              key="select"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="p-6 space-y-4"
            >
              <div className="grid grid-cols-2 gap-3">
                {customers.map((c) => (
                  <motion.button
                    key={c.id}
                    whileHover={{ scale: 1.02, y: -2 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => handleSelectCustomer(c.id)}
                    className="text-left p-4 rounded-2xl bg-secondary/30 border border-border/50 hover:border-border transition-all group"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="w-10 h-10 rounded-xl bg-primary/5 border border-primary/10 flex items-center justify-center">
                        <Building2 className="w-5 h-5 text-primary/60" />
                      </div>
                      <span
                        className={`text-[10px] px-2 py-0.5 rounded-full border ${riskColor(c.riskLevel)}`}
                      >
                        {c.riskLevel === "high" ? "높음" : c.riskLevel === "medium" ? "보통" : "낮음"}
                      </span>
                    </div>
                    <h3 className="text-[13px] font-semibold group-hover:text-primary transition-colors">
                      {c.name}
                    </h3>
                    <p className="text-[11px] text-muted-foreground mt-0.5">{c.contact}</p>
                    <div className="flex items-center gap-1.5 mt-2 text-[10px] text-muted-foreground/70">
                      <Clock className="w-3 h-3" />
                      최근 미팅: {c.lastMeeting}
                    </div>
                    <div className="mt-2 flex flex-wrap gap-1">
                      {c.recentTopics.slice(0, 2).map((topic) => (
                        <span
                          key={topic}
                          className="text-[9px] px-1.5 py-0.5 rounded bg-secondary/60 text-muted-foreground"
                        >
                          {topic}
                        </span>
                      ))}
                    </div>
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}

          {/* Step 2: Configure Meeting */}
          {step === "configure" && customer && (
            <motion.div
              key="configure"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="p-6 space-y-5"
            >
              {/* Customer summary */}
              <div className="flex items-center gap-3 p-4 rounded-xl bg-secondary/20 border border-border/30">
                <div className="w-10 h-10 rounded-xl bg-primary/5 border border-primary/10 flex items-center justify-center">
                  <Building2 className="w-5 h-5 text-primary/60" />
                </div>
                <div>
                  <h3 className="text-[13px] font-semibold">{customer.name}</h3>
                  <p className="text-[11px] text-muted-foreground">
                    {customer.contact} · {customer.segment}
                  </p>
                </div>
              </div>

              {/* Meeting type */}
              <div>
                <label className="text-[12px] font-medium text-foreground mb-2 block">미팅 유형</label>
                <div className="grid grid-cols-3 gap-2">
                  {meetingTypes.map((mt) => (
                    <button
                      key={mt.id}
                      onClick={() => setSelectedType(mt.id)}
                      className={`p-3 rounded-xl border text-center transition-all ${
                        selectedType === mt.id
                          ? "border-primary bg-primary/5 text-primary"
                          : "border-border/50 bg-secondary/20 text-muted-foreground hover:border-border"
                      }`}
                    >
                      <mt.icon className="w-4 h-4 mx-auto mb-1" />
                      <span className="text-[11px] font-medium">{mt.label}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Topics */}
              <div>
                <label className="text-[12px] font-medium text-foreground mb-2 block">
                  주요 안건 선택
                </label>
                <div className="flex flex-wrap gap-2">
                  {customer.recentTopics.map((topic) => (
                    <button
                      key={topic}
                      onClick={() => toggleTopic(topic)}
                      className={`px-3 py-1.5 rounded-lg border text-[11px] transition-all ${
                        selectedTopics.includes(topic)
                          ? "border-primary bg-primary/10 text-primary font-medium"
                          : "border-border/50 bg-secondary/20 text-muted-foreground hover:border-border"
                      }`}
                    >
                      {topic}
                    </button>
                  ))}
                </div>
              </div>

              {/* Generate button */}
              <motion.button
                whileHover={{ scale: 1.01 }}
                whileTap={{ scale: 0.99 }}
                onClick={handleGenerate}
                disabled={selectedTopics.length === 0}
                className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-primary text-primary-foreground font-medium text-[13px] hover:bg-primary/90 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <Sparkles className="w-4 h-4" />
                AI 브리핑 생성
                <ArrowRight className="w-4 h-4" />
              </motion.button>
            </motion.div>
          )}

          {/* Step 3: Generating / Result */}
          {(step === "generating" || step === "result") && (
            <motion.div
              key="result"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex flex-col h-full"
            >
              {/* Generating indicator */}
              {isGenerating && (
                <div className="flex items-center gap-2 px-6 py-3 border-b border-border/30 bg-primary/5">
                  <Loader2 className="w-3.5 h-3.5 text-primary animate-spin" />
                  <span className="text-[11px] text-primary font-medium">브리핑 생성 중...</span>
                </div>
              )}
              {step === "result" && !isGenerating && (
                <div className="flex items-center gap-2 px-6 py-3 border-b border-border/30 bg-status-completed/5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-status-completed" />
                  <span className="text-[11px] text-status-completed font-medium">브리핑 생성 완료</span>
                </div>
              )}

              {/* Briefing content */}
              <div ref={resultRef} className="flex-1 overflow-y-auto px-6 py-4 scrollbar-thin">
                <div className="prose prose-sm dark:prose-invert max-w-none text-[13px] leading-relaxed">
                  <ReactMarkdown>{briefing}</ReactMarkdown>
                </div>
              </div>

              {/* Bottom actions */}
              {step === "result" && (
                <div className="px-6 py-3 border-t border-border/50 flex items-center gap-2">
                  <button
                    onClick={handleReset}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-lg border border-border/50 text-[11px] text-muted-foreground hover:bg-secondary transition-colors"
                  >
                    <RotateCcw className="w-3 h-3" />
                    다시 준비
                  </button>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(briefing);
                      toast.success("클립보드에 복사되었습니다");
                    }}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-lg border border-border/50 text-[11px] text-muted-foreground hover:bg-secondary transition-colors"
                  >
                    <FileText className="w-3 h-3" />
                    복사
                  </button>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
