import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search,
  Plus,
  Star,
  Download,
  Sparkles,
  TrendingUp,
  X,
  Loader2,
  MessageSquare,
  Send,
  GitBranch,
  Zap,
  Clock,
  Play,
} from "lucide-react";
import { toast } from "sonner";
import { useInstalledItems } from "@/hooks/useInstalledItems";
import { createMarketplaceProvider, type MarketplaceReview } from "@/lib/marketplaceProvider";

const marketplaceProvider = createMarketplaceProvider();

type WorkflowStep = {
  type: string;
  label: string;
};

interface MarketplaceWorkflow {
  id: string;
  name: string;
  description: string | null;
  category: string;
  trigger_type: string;
  steps: WorkflowStep[];
  creator_name: string;
  installs: number;
  rating: number;
  tags: string[];
  is_featured: boolean;
  created_at: string;
}

const WORKFLOW_CATEGORIES = [
  { id: "all", label: "전체" },
  { id: "automation", label: "자동화" },
  { id: "reporting", label: "보고서" },
  { id: "alert", label: "알림" },
  { id: "quality", label: "품질" },
  { id: "market", label: "시장분석" },
  { id: "sales", label: "영업" },
];

const TRIGGER_LABELS: Record<string, { label: string; icon: typeof Zap }> = {
  manual: { label: "수동 실행", icon: Play },
  schedule: { label: "스케줄", icon: Clock },
  event: { label: "이벤트 트리거", icon: Zap },
};

const STEP_COLORS: Record<string, string> = {
  trigger: "hsl(var(--primary))",
  action: "hsl(var(--status-thinking))",
  condition: "hsl(var(--status-alert))",
  output: "hsl(var(--status-completed))",
};

export function WorkflowMarketplace() {
  const [workflows, setWorkflows] = useState<MarketplaceWorkflow[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");
  const [selectedWorkflow, setSelectedWorkflow] = useState<MarketplaceWorkflow | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const { install: installItem } = useInstalledItems();

  useEffect(() => {
    fetchWorkflows();
  }, []);

  const fetchWorkflows = async () => {
    setLoading(true);
    try {
      setWorkflows(await marketplaceProvider.list<MarketplaceWorkflow>("workflow"));
    } catch {
      toast.error("자동화 목록을 불러오는데 실패했습니다");
    }
    setLoading(false);
  };

  const handleInstall = async (wf: MarketplaceWorkflow) => {
    try {
      await marketplaceProvider.incrementInstalls("workflow", wf.id, wf.installs);
      setWorkflows((prev) =>
        prev.map((w) => (w.id === wf.id ? { ...w, installs: w.installs + 1 } : w))
      );
      await installItem({
        item_id: wf.id,
        item_type: "workflow",
        item_name: wf.name,
        item_icon: "GitBranch",
        item_description: wf.description || undefined,
      });
    } catch {
      toast.error("자동화 설치에 실패했습니다");
    }
  };

  const filtered = workflows.filter((w) => {
    const matchCategory = activeCategory === "all" || w.category === activeCategory;
    const matchSearch =
      !searchQuery ||
      w.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      w.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      w.tags.some((t) => t.includes(searchQuery.toLowerCase()));
    return matchCategory && matchSearch;
  });

  const featured = workflows.filter((w) => w.is_featured);

  return (
    <div className="space-y-6">
      {/* Search + Create */}
      <div className="flex gap-2">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="자동화 검색..."
            className="w-full pl-9 pr-4 py-2.5 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none transition-colors"
          />
        </div>
        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-[12px] font-semibold transition-colors"
          style={{ background: "hsl(var(--primary))", color: "hsl(var(--primary-foreground))" }}
        >
          <Plus className="w-3.5 h-3.5" />
          자동화 만들기
        </button>
      </div>

      {/* Category tabs */}
      <div className="flex gap-1.5 overflow-x-auto scrollbar-none">
        {WORKFLOW_CATEGORIES.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            className={`px-3 py-1.5 rounded-lg text-[11px] font-medium whitespace-nowrap transition-colors ${
              activeCategory === cat.id
                ? "bg-primary/15 text-primary"
                : "text-muted-foreground hover:bg-secondary"
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
        </div>
      ) : (
        <>
          {/* Featured */}
          {activeCategory === "all" && featured.length > 0 && !searchQuery && (
            <section>
              <div className="flex items-center gap-2 mb-3">
                <TrendingUp className="w-3.5 h-3.5 text-primary" />
                <h2 className="text-[12px] font-semibold text-foreground">추천 자동화</h2>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {featured.slice(0, 4).map((wf) => (
                  <WorkflowCard key={wf.id} workflow={wf} onInstall={handleInstall} onSelect={setSelectedWorkflow} featured />
                ))}
              </div>
            </section>
          )}

          {/* All */}
          <section>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-[12px] font-semibold text-foreground">
                {activeCategory === "all" ? "모든 자동화" : WORKFLOW_CATEGORIES.find((c) => c.id === activeCategory)?.label}
                <span className="text-muted-foreground font-normal ml-1.5">({filtered.length})</span>
              </h2>
            </div>
            {filtered.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-[12px] text-muted-foreground">검색 결과가 없습니다</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-3">
                {filtered.map((wf) => (
                  <WorkflowCard key={wf.id} workflow={wf} onInstall={handleInstall} onSelect={setSelectedWorkflow} />
                ))}
              </div>
            )}
          </section>
        </>
      )}

      {/* Detail Modal */}
      <AnimatePresence>
        {selectedWorkflow && (
          <WorkflowDetailModal
            workflow={selectedWorkflow}
            onClose={() => setSelectedWorkflow(null)}
            onInstall={handleInstall}
          />
        )}
      </AnimatePresence>

      {/* Create Modal */}
      <AnimatePresence>
        {showCreateModal && (
          <CreateWorkflowModal
            onClose={() => setShowCreateModal(false)}
            onCreated={() => { setShowCreateModal(false); fetchWorkflows(); }}
          />
        )}
      </AnimatePresence>
    </div>
  );
}

/* ─── Workflow Card ─── */
function WorkflowCard({
  workflow: wf,
  onInstall,
  onSelect,
  featured,
}: {
  workflow: MarketplaceWorkflow;
  onInstall: (w: MarketplaceWorkflow) => void;
  onSelect: (w: MarketplaceWorkflow) => void;
  featured?: boolean;
}) {
  const trigger = TRIGGER_LABELS[wf.trigger_type] || TRIGGER_LABELS.manual;
  const TriggerIcon = trigger.icon;
  const steps = Array.isArray(wf.steps) ? wf.steps : [];

  return (
    <motion.div
      whileHover={{ y: -2 }}
      onClick={() => onSelect(wf)}
      className={`rounded-2xl p-4 border cursor-pointer transition-colors group ${
        featured ? "border-primary/20 bg-primary/[0.03]" : "border-border/50 bg-card/50 hover:border-border"
      }`}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: "hsl(var(--secondary))" }}>
          <GitBranch className="w-5 h-5 text-muted-foreground" />
        </div>
        <div className="flex items-center gap-1.5">
          <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-secondary/80 text-muted-foreground flex items-center gap-0.5">
            <TriggerIcon className="w-2.5 h-2.5" />
            {trigger.label}
          </span>
          {featured && (
            <span className="text-[9px] px-2 py-0.5 rounded-full bg-primary/10 text-primary font-semibold">추천</span>
          )}
        </div>
      </div>

      <h3 className="text-[13px] font-semibold text-foreground mb-1 line-clamp-1">{wf.name}</h3>
      <p className="text-[11px] text-muted-foreground line-clamp-2 mb-3">{wf.description}</p>

      {/* Step preview */}
      <div className="flex items-center gap-1 mb-3">
        {steps.slice(0, 4).map((step, i) => (
          <div key={i} className="flex items-center gap-1">
            <div
              className="w-2 h-2 rounded-full"
              style={{ background: STEP_COLORS[step.type] || "hsl(var(--muted-foreground))" }}
            />
            {i < Math.min(steps.length, 4) - 1 && (
              <div className="w-3 h-px" style={{ background: "hsl(var(--border))" }} />
            )}
          </div>
        ))}
        {steps.length > 4 && <span className="text-[9px] text-muted-foreground">+{steps.length - 4}</span>}
        <span className="text-[9px] text-muted-foreground ml-1">{steps.length}단계</span>
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
          <span className="flex items-center gap-1">
            <Star className="w-3 h-3 text-amber-500" fill="currentColor" />
            {wf.rating}
          </span>
          <span className="flex items-center gap-1">
            <Download className="w-3 h-3" />
            {wf.installs}
          </span>
        </div>
        <button
          onClick={(e) => { e.stopPropagation(); onInstall(wf); }}
          className="px-2.5 py-1 rounded-lg text-[10px] font-semibold bg-primary/10 text-primary hover:bg-primary/20 transition-colors"
        >
          설치
        </button>
      </div>

      <div className="flex gap-1 mt-2 flex-wrap">
        {wf.tags.slice(0, 3).map((tag) => (
          <span key={tag} className="text-[9px] px-1.5 py-0.5 rounded-md bg-secondary/60 text-muted-foreground">#{tag}</span>
        ))}
      </div>
    </motion.div>
  );
}

/* ─── Detail Modal ─── */
function WorkflowDetailModal({
  workflow: wf,
  onClose,
  onInstall,
}: {
  workflow: MarketplaceWorkflow;
  onClose: () => void;
  onInstall: (w: MarketplaceWorkflow) => void;
}) {
  const [reviews, setReviews] = useState<MarketplaceReview[]>([]);
  const [loadingReviews, setLoadingReviews] = useState(true);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState("");
  const [reviewerName, setReviewerName] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [hoverRating, setHoverRating] = useState(0);
  const [currentRating, setCurrentRating] = useState(wf.rating);

  const steps = Array.isArray(wf.steps) ? wf.steps : [];
  const trigger = TRIGGER_LABELS[wf.trigger_type] || TRIGGER_LABELS.manual;
  const TriggerIcon = trigger.icon;

  const fetchReviews = useCallback(async () => {
    setLoadingReviews(true);
    try {
      setReviews(await marketplaceProvider.listReviews("workflow", wf.id));
    } catch {
      toast.error("리뷰를 불러오지 못했습니다");
    }
    setLoadingReviews(false);
  }, [wf.id]);

  useEffect(() => { fetchReviews(); }, [fetchReviews]);

  const submitReview = async () => {
    if (!reviewComment.trim()) { toast.error("리뷰 내용을 입력해주세요"); return; }
    setSubmitting(true);
    try {
      await marketplaceProvider.submitReview("workflow", wf.id, {
        reviewer_name: reviewerName.trim() || "익명",
        rating: reviewRating,
        comment: reviewComment.trim(),
      });
      toast.success("리뷰가 등록되었습니다!");
      setShowReviewForm(false);
      setReviewComment("");
      setReviewRating(5);
      await fetchReviews();
      const rating = await marketplaceProvider.getRating("workflow", wf.id);
      if (rating !== null) setCurrentRating(rating);
    } catch {
      toast.error("리뷰 등록에 실패했습니다");
    }
    setSubmitting(false);
  };

  const ratingDistribution = [5, 4, 3, 2, 1].map((r) => ({
    stars: r,
    count: reviews.filter((rv) => rv.rating === r).length,
  }));
  const maxCount = Math.max(...ratingDistribution.map((d) => d.count), 1);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[60] bg-black/40 flex items-center justify-center p-8"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.95, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.95, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-lg rounded-2xl bg-card border border-border p-6 space-y-4 max-h-[85vh] overflow-y-auto scrollbar-thin"
        style={{ boxShadow: "var(--shadow-3)" }}
      >
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ background: "hsl(var(--secondary))" }}>
              <GitBranch className="w-6 h-6 text-muted-foreground" />
            </div>
            <div>
              <h2 className="text-[14px] font-bold text-foreground">{wf.name}</h2>
              <p className="text-[11px] text-muted-foreground">by {wf.creator_name}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg hover:bg-secondary transition-colors">
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>

        <p className="text-[12px] text-foreground/80 leading-relaxed">{wf.description}</p>

        <div className="flex items-center gap-4 text-[11px] text-muted-foreground">
          <span className="flex items-center gap-1">
            <Star className="w-3.5 h-3.5 text-amber-500" fill="currentColor" />
            {currentRating}
          </span>
          <span className="flex items-center gap-1">
            <Download className="w-3.5 h-3.5" />
            {wf.installs}회 설치
          </span>
          <span className="flex items-center gap-1">
            <TriggerIcon className="w-3.5 h-3.5" />
            {trigger.label}
          </span>
          <span className="flex items-center gap-1">
            <MessageSquare className="w-3.5 h-3.5" />
            {reviews.length}개 리뷰
          </span>
        </div>

        {/* Step visualization */}
        {steps.length > 0 && (
          <div className="rounded-xl bg-secondary/20 p-4">
            <p className="text-[10px] font-semibold text-muted-foreground mb-3">자동화 단계</p>
            <div className="space-y-2">
              {steps.map((step, i) => (
                <div key={i} className="flex items-center gap-2.5">
                  <div className="flex flex-col items-center">
                    <div
                      className="w-3 h-3 rounded-full flex-shrink-0"
                      style={{ background: STEP_COLORS[step.type] || "hsl(var(--muted-foreground))" }}
                    />
                    {i < steps.length - 1 && (
                      <div className="w-px h-4 mt-0.5" style={{ background: "hsl(var(--border))" }} />
                    )}
                  </div>
                  <div className="flex items-center gap-2 flex-1">
                    <span className="text-[9px] px-1.5 py-0.5 rounded font-semibold uppercase tracking-wider"
                      style={{
                        background: `${STEP_COLORS[step.type] || "hsl(var(--muted-foreground))"}15`,
                        color: STEP_COLORS[step.type] || "hsl(var(--muted-foreground))",
                      }}
                    >
                      {step.type}
                    </span>
                    <span className="text-[11px] text-foreground/80">{step.label}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="flex gap-1.5 flex-wrap">
          {wf.tags.map((tag) => (
            <span key={tag} className="text-[10px] px-2 py-0.5 rounded-md bg-secondary/60 text-muted-foreground">#{tag}</span>
          ))}
        </div>

        <button
          onClick={() => { onInstall(wf); onClose(); }}
          className="w-full py-2.5 rounded-xl text-[12px] font-semibold transition-colors"
          style={{ background: "hsl(var(--primary))", color: "hsl(var(--primary-foreground))" }}
        >
          자동화 설치하기
        </button>

        {/* Reviews */}
        <div className="border-t border-border/50 pt-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-[13px] font-semibold text-foreground">평점 및 리뷰</h3>
            <button onClick={() => setShowReviewForm(!showReviewForm)}
              className="text-[11px] font-medium text-primary hover:underline flex items-center gap-1">
              <Send className="w-3 h-3" />리뷰 작성
            </button>
          </div>

          {reviews.length > 0 && (
            <div className="flex gap-4 mb-4">
              <div className="text-center">
                <div className="text-[28px] font-bold text-foreground">{currentRating}</div>
                <div className="flex items-center gap-0.5 justify-center mt-0.5">
                  {[1, 2, 3, 4, 5].map((s) => (
                    <Star key={s} className={`w-3 h-3 ${s <= Math.round(Number(currentRating)) ? "text-amber-500" : "text-muted-foreground/30"}`} fill="currentColor" />
                  ))}
                </div>
                <p className="text-[10px] text-muted-foreground mt-1">{reviews.length}개</p>
              </div>
              <div className="flex-1 space-y-1">
                {ratingDistribution.map((d) => (
                  <div key={d.stars} className="flex items-center gap-2">
                    <span className="text-[10px] text-muted-foreground w-3 text-right">{d.stars}</span>
                    <div className="flex-1 h-2 rounded-full bg-secondary/50 overflow-hidden">
                      <div className="h-full rounded-full bg-amber-500/70 transition-all" style={{ width: `${(d.count / maxCount) * 100}%` }} />
                    </div>
                    <span className="text-[10px] text-muted-foreground w-4">{d.count}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Review Form */}
          <AnimatePresence>
            {showReviewForm && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden mb-4">
                <div className="rounded-xl border border-border/50 p-3 space-y-3 bg-secondary/20">
                  <div>
                    <label className="text-[10px] font-medium text-muted-foreground block mb-1.5">평점</label>
                    <div className="flex items-center gap-1">
                      {[1, 2, 3, 4, 5].map((s) => (
                        <button key={s} onMouseEnter={() => setHoverRating(s)} onMouseLeave={() => setHoverRating(0)} onClick={() => setReviewRating(s)} className="p-0.5 transition-transform hover:scale-110">
                          <Star className={`w-5 h-5 ${s <= (hoverRating || reviewRating) ? "text-amber-500" : "text-muted-foreground/30"}`} fill="currentColor" />
                        </button>
                      ))}
                      <span className="text-[11px] text-muted-foreground ml-2">{reviewRating}점</span>
                    </div>
                  </div>
                  <div>
                    <label className="text-[10px] font-medium text-muted-foreground block mb-1">이름</label>
                    <input value={reviewerName} onChange={(e) => setReviewerName(e.target.value)} placeholder="익명"
                      className="w-full px-3 py-1.5 rounded-lg text-[11px] bg-background border border-border/50 focus:border-primary/30 focus:outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] font-medium text-muted-foreground block mb-1">리뷰 *</label>
                    <textarea value={reviewComment} onChange={(e) => setReviewComment(e.target.value)} rows={2} placeholder="이 자동화에 대한 의견을 남겨주세요"
                      className="w-full px-3 py-1.5 rounded-lg text-[11px] bg-background border border-border/50 focus:border-primary/30 focus:outline-none resize-none" />
                  </div>
                  <div className="flex gap-2 justify-end">
                    <button onClick={() => setShowReviewForm(false)} className="px-3 py-1.5 rounded-lg text-[11px] text-muted-foreground hover:bg-secondary transition-colors">취소</button>
                    <button onClick={submitReview} disabled={submitting || !reviewComment.trim()}
                      className="px-3 py-1.5 rounded-lg text-[11px] font-semibold transition-colors disabled:opacity-50"
                      style={{ background: "hsl(var(--primary))", color: "hsl(var(--primary-foreground))" }}>
                      {submitting ? "등록 중..." : "리뷰 등록"}
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Review List */}
          {loadingReviews ? (
            <div className="flex justify-center py-4"><Loader2 className="w-4 h-4 animate-spin text-muted-foreground" /></div>
          ) : reviews.length === 0 ? (
            <p className="text-[11px] text-muted-foreground text-center py-4">아직 리뷰가 없습니다. 첫 번째 리뷰를 남겨보세요!</p>
          ) : (
            <div className="space-y-3">
              {reviews.map((review) => (
                <div key={review.id} className="rounded-xl bg-secondary/20 p-3">
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] font-semibold text-foreground">{review.reviewer_name}</span>
                      <div className="flex items-center gap-0.5">
                        {[1, 2, 3, 4, 5].map((s) => (
                          <Star key={s} className={`w-2.5 h-2.5 ${s <= review.rating ? "text-amber-500" : "text-muted-foreground/30"}`} fill="currentColor" />
                        ))}
                      </div>
                    </div>
                    <span className="text-[9px] text-muted-foreground">{new Date(review.created_at).toLocaleDateString("ko-KR")}</span>
                  </div>
                  <p className="text-[11px] text-foreground/70 leading-relaxed">{review.comment}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}

/* ─── Create Modal ─── */
function CreateWorkflowModal({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("automation");
  const [triggerType, setTriggerType] = useState("manual");
  const [creatorName, setCreatorName] = useState("");
  const [tags, setTags] = useState("");
  const [saving, setSaving] = useState(false);
  const [aiGenerating, setAiGenerating] = useState(false);

  const handleAiAssist = async () => {
    if (!name.trim()) { toast.error("자동화 이름을 먼저 입력해주세요"); return; }
    setAiGenerating(true);
    try {
      const parsed = await marketplaceProvider.assistWorkflow(name);
      if (parsed.description) setDescription(parsed.description);
      if (parsed.tags) setTags(parsed.tags.join(", "));
      if (parsed.category) setCategory(parsed.category);
    } catch { toast.error("AI 보조를 불러오지 못했습니다"); }
    setAiGenerating(false);
  };

  const handleSubmit = async () => {
    if (!name.trim()) { toast.error("이름을 입력해주세요"); return; }
    setSaving(true);
    try {
      await marketplaceProvider.create("workflow", {
        name,
        description: description || null,
        category,
        trigger_type: triggerType,
        creator_name: creatorName || "익명",
        tags: tags.split(",").map((t) => t.trim()).filter(Boolean),
      });
      toast.success("자동화가 연결 센터에 등록되었습니다!");
      onCreated();
    } catch {
      toast.error("자동화 등록에 실패했습니다");
    }
    setSaving(false);
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-[60] bg-black/40 flex items-center justify-center p-8" onClick={onClose}>
      <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }}
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md rounded-2xl bg-card border border-border p-6 space-y-4 max-h-[80vh] overflow-y-auto scrollbar-thin"
        style={{ boxShadow: "var(--shadow-3)" }}>
        <div className="flex items-center justify-between">
          <h2 className="text-[14px] font-bold text-foreground">새 자동화 만들기</h2>
          <button onClick={onClose} className="p-1 rounded-lg hover:bg-secondary transition-colors">
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>

        <div className="space-y-3">
          <div>
            <label className="text-[11px] font-medium text-muted-foreground block mb-1">이름 *</label>
            <div className="flex gap-2">
              <input value={name} onChange={(e) => setName(e.target.value)} placeholder="예: 클레임 자동 대응"
                className="flex-1 px-3 py-2 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none" />
              <button onClick={handleAiAssist} disabled={aiGenerating || !name.trim()}
                className="px-2.5 py-2 rounded-xl text-[11px] font-medium bg-primary/10 text-primary hover:bg-primary/20 transition-colors flex items-center gap-1 disabled:opacity-50 whitespace-nowrap">
                {aiGenerating ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
                AI 채우기
              </button>
            </div>
          </div>
          <div>
            <label className="text-[11px] font-medium text-muted-foreground block mb-1">설명</label>
            <textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={2} placeholder="자동화가 무엇을 하는지 설명해주세요"
              className="w-full px-3 py-2 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none resize-none" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-medium text-muted-foreground block mb-1">카테고리</label>
              <select value={category} onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3 py-2 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none">
                <option value="automation">자동화</option>
                <option value="reporting">보고서</option>
                <option value="alert">알림</option>
                <option value="quality">품질</option>
                <option value="market">시장분석</option>
                <option value="sales">영업</option>
              </select>
            </div>
            <div>
              <label className="text-[11px] font-medium text-muted-foreground block mb-1">트리거 타입</label>
              <select value={triggerType} onChange={(e) => setTriggerType(e.target.value)}
                className="w-full px-3 py-2 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none">
                <option value="manual">수동 실행</option>
                <option value="schedule">스케줄</option>
                <option value="event">이벤트 트리거</option>
              </select>
            </div>
          </div>
          <div>
            <label className="text-[11px] font-medium text-muted-foreground block mb-1">태그 (쉼표 구분)</label>
            <input value={tags} onChange={(e) => setTags(e.target.value)} placeholder="예: 자동화, 알림, 납기"
              className="w-full px-3 py-2 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none" />
          </div>
          <div>
            <label className="text-[11px] font-medium text-muted-foreground block mb-1">만든 사람</label>
            <input value={creatorName} onChange={(e) => setCreatorName(e.target.value)} placeholder="이름 (비워두면 '익명')"
              className="w-full px-3 py-2 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none" />
          </div>
        </div>

        <button onClick={handleSubmit} disabled={saving || !name.trim()}
          className="w-full py-2.5 rounded-xl text-[12px] font-semibold transition-colors disabled:opacity-50"
          style={{ background: "hsl(var(--primary))", color: "hsl(var(--primary-foreground))" }}>
          {saving ? "등록 중..." : "연결 센터에 등록"}
        </button>
      </motion.div>
    </motion.div>
  );
}
