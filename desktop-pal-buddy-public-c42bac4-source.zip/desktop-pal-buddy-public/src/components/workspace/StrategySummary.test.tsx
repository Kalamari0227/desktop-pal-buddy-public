import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { vi } from "vitest";
import { demoStrategies, demoStrategyVersions } from "@/data/demoStrategyCatalog";
import { StrategySummary } from "./StrategySummary";

describe("StrategySummary", () => {
  it("shows the pinned version objective and review question", () => {
    render(
      <StrategySummary
        strategy={demoStrategies[0]}
        version={demoStrategyVersions[1]}
      />,
    );

    expect(screen.getByText("납기 위험 조기 확인")).toBeInTheDocument();
    expect(screen.getByText("v2")).toBeInTheDocument();
    expect(screen.getByText("주문·납기 신호와 공급 여유를 함께 확인해 조기 경보의 정확도를 높인다.")).toBeInTheDocument();
    expect(screen.getByLabelText("연결된 전략")).toHaveTextContent("공급 여유 신호를 추가한 판단이 더 빠르고 명확한 대응을 만드는가?");
  });

  it("opens lineage for the same pinned version without changing its fixture note", () => {
    const onOpenLineage = vi.fn();
    render(
      <StrategySummary
        strategy={demoStrategies[0]}
        version={demoStrategyVersions[0]}
        contentHash={"a".repeat(64)}
        showFixtureNote
        onOpenLineage={onOpenLineage}
      />,
    );

    fireEvent.click(screen.getByRole("button", { name: "전략 계보 보기" }));

    expect(onOpenLineage).toHaveBeenCalledOnce();
    expect(screen.getByText(`hash ${"a".repeat(12)}…`)).toBeInTheDocument();
    expect(screen.getByText("가상 데이터 · 새로고침 시 초기화")).toBeInTheDocument();
  });
});
