import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { createInitialCompanyState } from "@/lib/company-runtime";
import type { CompanyRuntimeClient, CompanyRuntimeResponse } from "@/lib/companyRuntimeClient";
import { CompanyRequestPanel } from "./CompanyRequestPanel";

const epoch = "85c540f3-5e30-4a42-97f0-3f46577cf339";
const strategyVersionId = "266cae99-24da-4595-95ed-c2c782a20417";
const workboardTaskId = "719c1670-0035-437a-8f80-245edb22e99a";

const state = createInitialCompanyState({
  epoch,
  strategyVersionId,
  createdAt: "2026-09-18T00:00:00.000Z",
  strategyContentHash: "a".repeat(64),
});

function success(payload: unknown, revision = 0): CompanyRuntimeResponse {
  return {
    schemaVersion: 1,
    requestId: crypto.randomUUID(),
    epoch,
    actorSessionRevision: revision,
    ok: true,
    payload,
  };
}

function failure(code: "unavailable" | "invalid_input" | "stale_context" | "stopped" | "ai_failed", message: string): CompanyRuntimeResponse {
  return {
    schemaVersion: 1,
    requestId: crypto.randomUUID(),
    epoch,
    actorSessionRevision: 0,
    ok: false,
    error: { code, message },
  };
}

function bootstrap(): CompanyRuntimeResponse {
  return success({
    snapshot: {
      formatVersion: 1,
      revision: 0,
      currentEpoch: epoch,
      stopped: false,
      current: state,
      records: {},
      projection: { actorId: "sales-demo", role: "sales" },
    },
    status: { epoch, actorId: "sales-demo", role: "sales", actorSessionRevision: 0, stopped: false },
  });
}

function proposed(): CompanyRuntimeResponse {
  return success({
    interpretation: {
      kind: "interpretation",
      intent: "change_production_priority",
      targetIds: ["SO-DEMO-1001", "PP-DEMO-1001"],
      requestedPriority: 1,
      citedEvidenceIds: [],
      clarificationQuestions: [],
    },
    task: { workboardTaskId, packetTaskId: "2e03a8e9-c48d-470b-8470-e925965891d2" },
    proposal: {
      intent: {
        targetPlanId: "PP-DEMO-1001",
        fromPriority: 5,
        toPriority: 1,
        strategyRef: state.activeStrategyRef,
      },
      shadow: {
        diff: { priority: { before: 5, after: 1 }, version: { before: 1, after: 1 } },
        mutationCount: 0,
      },
    },
    runtimeMode: "stub",
    actualAI: false,
  });
}

function clientWith(submit: CompanyRuntimeClient["submit"]): CompanyRuntimeClient {
  return {
    bootstrap: vi.fn(async () => bootstrap()),
    read: vi.fn(),
    submit,
    approve: vi.fn(),
    execute: vi.fn(),
    role: vi.fn(),
    stop: vi.fn(),
    resume: vi.fn(),
    reset: vi.fn(),
    cancel: vi.fn(async () => success({ canceled: true })),
    reconcile: vi.fn(),
    reviewReadiness: vi.fn(),
    subscribe: vi.fn(() => () => undefined),
    getContext: vi.fn(() => ({ epoch, actorSessionRevision: 0 })),
  } as CompanyRuntimeClient;
}

describe("CompanyRequestPanel", () => {
  it("describes a ready connection as preflight and keeps the next action an explicit review", async () => {
    const client = clientWith(vi.fn(async () => proposed()));
    client.bootstrap = vi.fn(async () => success({
      snapshot: {
        formatVersion: 1,
        revision: 0,
        currentEpoch: epoch,
        stopped: false,
        current: state,
        records: {},
        projection: { actorId: "sales-demo", role: "sales" },
      },
      status: { epoch, actorId: "sales-demo", role: "sales", actorSessionRevision: 0, stopped: false },
      aiConnection: { state: "ready", reasonCode: "local_profile_ready" },
    }));
    render(<CompanyRequestPanel client={client} />);

    expect(await screen.findByText("AI 연결 준비됨 · 실제 AI 해석 전")).toBeInTheDocument();
    expect(screen.getByText("다음 행동: 회사 요청을 입력한 뒤 직접 검토하세요.")).toBeInTheDocument();
  });

  beforeEach(() => vi.clearAllMocks());

  it("shows grounded sales and production facts plus a zero-mutation 5 to 1 Shadow preview", async () => {
    const onOpenTasks = vi.fn();
    const submit = vi.fn(async () => proposed());
    render(<CompanyRequestPanel client={clientWith(submit)} onOpenTasks={onOpenTasks} />);

    await waitFor(() => expect(screen.getByRole("combobox", { name: "회사 전략 버전" })).toHaveValue(strategyVersionId));
    fireEvent.change(screen.getByRole("textbox", { name: "회사 요청" }), { target: { value: "주문 1001 생산 우선순위를 1로 올려줘" } });
    fireEvent.click(screen.getByRole("button", { name: "회사 요청 검토" }));

    await screen.findByRole("heading", { name: "Shadow 변경 미리보기" });
    expect(screen.getByText("결정론적 Stub · 실제 AI 아님")).toBeInTheDocument();
    expect(submit).toHaveBeenCalledWith({ requestText: "주문 1001 생산 우선순위를 1로 올려줘" });
    expect(screen.getByText("priority 5 → 1")).toBeInTheDocument();
    expect(screen.getByText("변경 건수 0")).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "영업 판단" })).toBeInTheDocument();
    expect(screen.getByText(/SO-DEMO-1001 requires 20000kg/)).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "생산 판단" })).toBeInTheDocument();
    expect(screen.getByText(/PP-DEMO-1001 is queued at priority 5/)).toBeInTheDocument();
    expect(screen.getByText("sales_order · SO-DEMO-1001 · v1")).toBeInTheDocument();
    expect(screen.getByText(/No promised delivery date/)).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: /실행|적용/ })).not.toBeInTheDocument();

    fireEvent.click(screen.getByRole("button", { name: "Workboard에서 계속" }));
    expect(onOpenTasks).toHaveBeenCalledWith(workboardTaskId);
  });

  it("keeps an ambiguous request in clarification without a proposal or navigation", async () => {
    const response = success({
      interpretation: {
        kind: "interpretation",
        intent: "clarification",
        targetIds: [],
        citedEvidenceIds: [],
        clarificationQuestions: ["어느 주문의 우선순위를 변경할까요?"],
      },
      clarificationRequired: true,
      runtimeMode: "stub",
      actualAI: false,
    });
    render(<CompanyRequestPanel client={clientWith(vi.fn(async () => response))} />);

    await waitFor(() => expect(screen.getByRole("combobox", { name: "회사 전략 버전" })).toHaveValue(strategyVersionId));
    fireEvent.change(screen.getByRole("textbox", { name: "회사 요청" }), { target: { value: "우선순위 올려줘" } });
    fireEvent.click(screen.getByRole("button", { name: "회사 요청 검토" }));

    expect(await screen.findByText("추가 정보가 필요합니다")).toBeInTheDocument();
    expect(screen.getByText("어느 주문의 우선순위를 변경할까요?")).toBeInTheDocument();
    expect(screen.queryByRole("heading", { name: "Shadow 변경 미리보기" })).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Workboard에서 계속" })).not.toBeInTheDocument();
  });

  it.each([
    ["ai_failed", "timeout", "AI 해석에 실패했습니다"],
    ["unavailable", "network_unavailable", "회사 런타임을 사용할 수 없습니다"],
    ["invalid_input", "missing_sales_order", "주문을 찾을 수 없습니다"],
    ["invalid_input", "missing_inventory", "확인 가능한 정보가 부족합니다"],
    ["invalid_input", "quality_hold", "요청이 정책 검토에서 차단되었습니다"],
    ["stopped", "runtime_stopped", "회사 런타임이 중지되었습니다"],
    ["stale_context", "stale_client_reply", "작업 맥락이 변경되었습니다"],
  ] as const)("surfaces %s without clearing text or exposing proposal controls", async (code, message, label) => {
    render(<CompanyRequestPanel client={clientWith(vi.fn(async () => failure(code, message)))} />);
    await waitFor(() => expect(screen.getByRole("combobox", { name: "회사 전략 버전" })).toHaveValue(strategyVersionId));
    fireEvent.change(screen.getByRole("textbox", { name: "회사 요청" }), { target: { value: "주문 9999 우선순위 변경" } });
    fireEvent.click(screen.getByRole("button", { name: "회사 요청 검토" }));

    expect(await screen.findByText(label)).toBeInTheDocument();
    expect(screen.getByRole("textbox", { name: "회사 요청" })).toHaveValue("주문 9999 우선순위 변경");
    expect(screen.queryByRole("heading", { name: "Shadow 변경 미리보기" })).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "Workboard에서 계속" })).not.toBeInTheDocument();
  });

  it("discards a late successful response after cancellation", async () => {
    let release: ((value: CompanyRuntimeResponse) => void) | undefined;
    const submit = vi.fn(() => new Promise<CompanyRuntimeResponse>((resolve) => { release = resolve; }));
    const client = clientWith(submit);
    render(<CompanyRequestPanel client={client} />);

    await waitFor(() => expect(screen.getByRole("combobox", { name: "회사 전략 버전" })).toHaveValue(strategyVersionId));
    fireEvent.change(screen.getByRole("textbox", { name: "회사 요청" }), { target: { value: "주문 1001 우선순위를 1로" } });
    fireEvent.click(screen.getByRole("button", { name: "회사 요청 검토" }));
    expect(await screen.findByText("회사 자료와 요청을 확인하고 있습니다" )).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "검토 취소" }));
    await waitFor(() => expect(client.cancel).toHaveBeenCalledTimes(1));
    release?.(proposed());

    expect(await screen.findByText("검토가 취소되었습니다")).toBeInTheDocument();
    expect(screen.queryByRole("heading", { name: "Shadow 변경 미리보기" })).not.toBeInTheDocument();
  });

  it("discards a late successful response after the host role context changes without clearing the draft", async () => {
    let release: ((value: CompanyRuntimeResponse) => void) | undefined;
    let publish: ((value: CompanyRuntimeResponse) => void) | undefined;
    const client = clientWith(vi.fn(() => new Promise<CompanyRuntimeResponse>((resolve) => { release = resolve; })));
    client.subscribe = vi.fn((callback) => {
      publish = callback;
      return () => undefined;
    });
    render(<CompanyRequestPanel client={client} />);

    await waitFor(() => expect(screen.getByRole("combobox", { name: "회사 전략 버전" })).toHaveValue(strategyVersionId));
    fireEvent.change(screen.getByRole("textbox", { name: "회사 요청" }), { target: { value: "주문 1001 우선순위를 1로" } });
    fireEvent.click(screen.getByRole("button", { name: "회사 요청 검토" }));
    await screen.findByText("회사 자료와 요청을 확인하고 있습니다");
    publish?.(success({
      status: { epoch, actorId: "production-demo", role: "production", actorSessionRevision: 1, stopped: false },
    }, 1));
    release?.(proposed());

    expect(await screen.findByText("작업 맥락이 변경되었습니다")).toBeInTheDocument();
    expect(screen.getByRole("textbox", { name: "회사 요청" })).toHaveValue("주문 1001 우선순위를 1로");
    expect(screen.queryByRole("heading", { name: "Shadow 변경 미리보기" })).not.toBeInTheDocument();
  });

  it("runs baseline and approved-learning readiness as explicit read-only production reviews", async () => {
    // Given: the production role and two main-owned readiness results.
    const onOpenTasks = vi.fn();
    const reviewReadiness = vi.fn()
      .mockResolvedValueOnce(success({
        task: { workboardTaskId, status: "done" },
        assessment: {
          finding: "needs_review",
          requiredChecks: [],
          usedAssetRef: null,
          additionalReadSet: [],
          reuse: { status: "baseline", code: null },
        },
      }, 1))
      .mockResolvedValueOnce(success({
        task: { workboardTaskId, status: "done" },
        assessment: {
          finding: "needs_review",
          requiredChecks: ["inspection", "packaging"],
          usedAssetRef: { assetId: "learning-ready", version: 2 },
          additionalReadSet: [
            { kind: "inspection", id: "INSPECTION-DEMO-1002", version: 1 },
            { kind: "shipment", id: "SHIPMENT-DEMO-1002", version: 1 },
          ],
          reuse: { status: "selected", code: null },
        },
      }, 1));
    const client = clientWith(vi.fn());
    client.bootstrap = vi.fn(async () => success({
      snapshot: {
        formatVersion: 1,
        revision: 0,
        currentEpoch: epoch,
        stopped: false,
        current: state,
        records: {},
        projection: { actorId: "production-demo", role: "production" },
      },
      status: { epoch, actorId: "production-demo", role: "production", actorSessionRevision: 1, stopped: false },
    }, 1));
    client.reviewReadiness = reviewReadiness;
    render(<CompanyRequestPanel client={client} onOpenTasks={onOpenTasks} />);

    // When: the employee runs the baseline and then explicitly requests reuse.
    fireEvent.click(await screen.findByRole("button", { name: "기준선 준비 상태 읽기" }));
    await screen.findByText("사용 학습 없음");
    fireEvent.click(screen.getByRole("button", { name: "승인 학습으로 다시 확인" }));

    // Then: exact asset/version, extra sources, needs-review, and unobserved outcome are visible without execute controls.
    expect(await screen.findByText("learning-ready · v2")).toBeInTheDocument();
    expect(screen.getByText("inspection · INSPECTION-DEMO-1002 · v1")).toBeInTheDocument();
    expect(screen.getByText("shipment · SHIPMENT-DEMO-1002 · v1")).toBeInTheDocument();
    expect(screen.getByText("추가 확인 필요 · needs_review")).toBeInTheDocument();
    expect(screen.getByText("사업 결과 미관찰")).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: /승인된 변경 적용|생산 승인/ })).not.toBeInTheDocument();
    expect(reviewReadiness).toHaveBeenNthCalledWith(1, { useLatestLearning: false });
    expect(reviewReadiness).toHaveBeenNthCalledWith(2, { useLatestLearning: true });
    fireEvent.click(screen.getByRole("button", { name: "Workboard에서 근거 보기" }));
    expect(onOpenTasks).toHaveBeenCalledWith(workboardTaskId);
  });

  it("keeps an empty request local and does not submit it", async () => {
    const submit = vi.fn(async () => proposed());
    render(<CompanyRequestPanel client={clientWith(submit)} />);

    const review = await screen.findByRole("button", { name: "회사 요청 검토" });
    expect(screen.getByRole("textbox", { name: "회사 요청" })).toHaveValue("");
    expect(review).toBeDisabled();
    fireEvent.click(review);
    expect(submit).not.toHaveBeenCalled();
  });

  it("prefills each transferred draft once, preserves a user edit, and waits for explicit review", async () => {
    const submit = vi.fn(async () => proposed());
    const draft = { id: "workspace-draft-1", text: "SO-DEMO-1001 priority 1" };
    const { rerender } = render(<CompanyRequestPanel client={clientWith(submit)} companyDraft={draft} />);

    const request = await screen.findByRole("textbox", { name: "회사 요청" });
    expect(request).toHaveValue(draft.text);
    expect(submit).not.toHaveBeenCalled();

    fireEvent.change(request, { target: { value: "사용자가 수정한 요청" } });
    rerender(<CompanyRequestPanel client={clientWith(submit)} companyDraft={draft} />);

    expect(screen.getByRole("textbox", { name: "회사 요청" })).toHaveValue("사용자가 수정한 요청");
    expect(submit).not.toHaveBeenCalled();

    fireEvent.click(screen.getByRole("button", { name: "회사 요청 검토" }));
    await screen.findByRole("heading", { name: "Shadow 변경 미리보기" });
    expect(submit).toHaveBeenCalledTimes(1);
    expect(submit).toHaveBeenCalledWith({ requestText: "사용자가 수정한 요청" });
  });
});
