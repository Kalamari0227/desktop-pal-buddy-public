import { useState, useRef, useEffect, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import ReactMarkdown from "react-markdown";
import { streamChat, type Msg } from "@/lib/streamChat";
import { createCustomerResponseGatewayDraft, gatewayPacketToWorkboardTaskInsert } from "@/lib/agentic";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import {
  ArrowLeft,
  ArrowRight,
  Building2,
  CheckCircle2,
  Clock,
  Copy,
  Edit3,
  Loader2,
  Mail,
  MessageSquare,
  Phone,
  RotateCcw,
  Send,
  Sparkles,
  AlertTriangle,
  HelpCircle,
  DollarSign,
  Package,
  ShieldAlert,
  Save,
} from "lucide-react";

/* ── Mock data ── */
const customers = [
  { id: "hyundai", name: "현대자동차", code: "현대자동차", contact: "김철수 부장", email: "kim.cs@hyundai.com" },
  { id: "kia", name: "기아", code: "기아", contact: "박영희 차장", email: "park.yh@kia.com" },
  { id: "toyota", name: "도요타", code: "도요타", contact: "田中 太郎", email: "tanaka@toyota.co.jp" },
  { id: "gm", name: "GM Korea", code: "GM Korea", contact: "이준호 과장", email: "lee.jh@gm.com" },
];

type InquiryType = "quality" | "delivery" | "price" | "spec" | "complaint" | "general";

const inquiryTypes: { id: InquiryType; label: string; icon: typeof Mail; description: string }[] = [
  { id: "quality", label: "품질 이슈", icon: ShieldAlert, description: "품질 불량/이슈 관련 문의" },
  { id: "delivery", label: "납기 문의", icon: Package, description: "납기 일정 확인/조정 요청" },
  { id: "price", label: "가격 협의", icon: DollarSign, description: "가격 조정/재협상 요청" },
  { id: "spec", label: "사양 문의", icon: HelpCircle, description: "강판 사양/규격 문의" },
  { id: "complaint", label: "클레임", icon: AlertTriangle, description: "클레임/불만 접수 대응" },
  { id: "general", label: "일반 문의", icon: MessageSquare, description: "기타 일반 문의 사항" },
];

type Channel = "email" | "phone" | "message";
const channels: { id: Channel; label: string; icon: typeof Mail }[] = [
  { id: "email", label: "이메일", icon: Mail },
  { id: "phone", label: "전화 메모", icon: Phone },
  { id: "message", label: "메신저", icon: MessageSquare },
];

const toneOptions = ["정중/공식", "친근/협력", "단호/명확"] as const;

interface CustomerResponseModeProps {
  onBack: () => void;
  onOpenTasks?: (taskId?: string) => void;
}

type Step = "setup" | "generating" | "edit" | "sent";

export function CustomerResponseMode({ onBack, onOpenTasks }: CustomerResponseModeProps) {
  const [step, setStep] = useState<Step>("setup");
  const [selectedCustomer, setSelectedCustomer] = useState<string>(customers[0].id);
  const [selectedInquiry, setSelectedInquiry] = useState<InquiryType | null>(null);
  const [selectedChannel, setSelectedChannel] = useState<Channel>("email");
  const [selectedTone, setSelectedTone] = useState<string>(toneOptions[0]);
  const [contextNote, setContextNote] = useState("");
  const [draft, setDraft] = useState("");
  const [editedDraft, setEditedDraft] = useState("");
  const [isEditing, setIsEditing] = useState(false);
  const [, setIsGenerating] = useState(false);
  const [savingTask, setSavingTask] = useState(false);
  const [createdWorkboardTaskId, setCreatedWorkboardTaskId] = useState<string | null>(null);
  const resultRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const customer = customers.find((c) => c.id === selectedCustomer);
  const inquiry = inquiryTypes.find((t) => t.id === selectedInquiry);
  const channel = channels.find((c) => c.id === selectedChannel);
  const gatewayDraft = useMemo(() => {
    if (!customer || !inquiry || !channel) {
      return null;
    }

    return createCustomerResponseGatewayDraft({
      customer_id: customer.id,
      customer_name: customer.name,
      customer_code: customer.code,
      inquiry_type: inquiry.id,
      inquiry_label: inquiry.label,
      inquiry_description: inquiry.description,
      channel: selectedChannel,
      channel_label: channel.label,
      tone: selectedTone,
      context_note: contextNote,
    });
  }, [channel, contextNote, customer, inquiry, selectedChannel, selectedTone]);
  const packet = gatewayDraft?.packet ?? null;

  const handleGenerate = async () => {
    if (!customer || !inquiry) return;
    setStep("generating");
    setIsGenerating(true);
    setDraft("");
    setEditedDraft("");

    const channelLabel = channels.find((c) => c.id === selectedChannel)?.label;

    const prompt = `당신은 철강회사의 자동차 강판 마케팅/판매 담당자의 AI 비서입니다.
다음 고객 문의에 대한 ${channelLabel} 회신 초안을 작성해주세요.

**고객 정보:**
- 고객사: ${customer.name} (${customer.code})
- 담당자: ${customer.contact}
- 이메일: ${customer.email}

**문의 유형:** ${inquiry.label} — ${inquiry.description}
**회신 채널:** ${channelLabel}
**톤앤매너:** ${selectedTone}
${contextNote ? `**추가 맥락:** ${contextNote}` : ""}

작성 가이드라인:
1. ${selectedChannel === "email" ? "이메일 형식(제목, 인사, 본문, 맺음말, 서명)으로 작성" : selectedChannel === "phone" ? "전화 통화 스크립트 형식으로 작성" : "메신저 대화 형식으로 간결하게 작성"}
2. ${selectedTone} 톤으로 작성
3. ${inquiry.id === "quality" ? "품질 이슈에 대한 원인 분석 및 개선 계획 포함" : ""}
${inquiry.id === "delivery" ? "구체적 납기 일정과 대안 제시" : ""}
${inquiry.id === "price" ? "가격 근거와 협상 여지 포함" : ""}
${inquiry.id === "complaint" ? "사과 표현과 구체적 해결 방안 제시" : ""}
4. 자동차 강판 업계 전문 용어를 적절히 사용
5. 마크다운으로 포맷팅

회신 초안을 작성해주세요.`;

    const messages: Msg[] = [{ role: "user", content: prompt }];
    let fullText = "";

    try {
      await streamChat({
        messages,
        onDelta: (chunk) => {
          fullText += chunk;
          setDraft(fullText);
        },
        onDone: () => {
          setIsGenerating(false);
          setEditedDraft(fullText);
          setStep("edit");
        },
        onError: (e) => {
          toast.error(e);
          setIsGenerating(false);
          setStep("setup");
        },
      });
    } catch {
      toast.error("초안 생성에 실패했습니다.");
      setIsGenerating(false);
      setStep("setup");
    }
  };

  const handleSend = () => {
    toast.warning("외부 발송은 자동화하지 않습니다. Workboard에 등록한 뒤 검토/승인 흐름으로 진행하세요.");
  };

  const handleReset = () => {
    setStep("setup");
    setSelectedInquiry(null);
    setContextNote("");
    setDraft("");
    setEditedDraft("");
    setIsEditing(false);
    setCreatedWorkboardTaskId(null);
  };

  const createWorkboardTask = async () => {
    if (!packet || !customer || !inquiry) {
      toast.error("Gateway 판단을 만들 수 없어 작업으로 등록하지 못했습니다");
      return;
    }

    setSavingTask(true);

    const { data: existingTasks, error: existingError } = await supabase
      .from("tasks")
      .select("id")
      .eq("source", "gateway")
      .eq("source_id", packet.task_id)
      .limit(1);

    if (existingError) {
      setSavingTask(false);
      toast.error("기존 작업 확인에 실패했습니다");
      return;
    }

    const existingTaskId = (existingTasks?.[0] as { id?: string } | undefined)?.id;
    if (existingTaskId) {
      setSavingTask(false);
      setCreatedWorkboardTaskId(existingTaskId);
      toast.info("이미 Workboard에 등록된 회신 작업입니다");
      return;
    }

    const workboardTaskId = globalThis.crypto?.randomUUID?.() ?? `customer-response-${Date.now()}`;
    const createdAt = new Date().toISOString();
    const payload = gatewayPacketToWorkboardTaskInsert({
      packet,
      workboard_task_id: workboardTaskId,
      created_at: createdAt,
    });
    const { error } = await supabase.from("tasks").insert({
      ...payload,
      title: `${customer.name} ${inquiry.label} 회신 초안`,
      description: [
        payload.description,
        `Gateway packet id: ${packet.task_id}`,
        `문의 유형: ${inquiry.label}`,
        `회신 채널: ${channel?.label ?? selectedChannel}`,
        `톤앤매너: ${selectedTone}`,
        `금지 작업: ${packet.forbidden_actions.join(", ")}`,
        "외부 발송은 자동화하지 않고 검토/승인 이후 별도 진행합니다.",
      ].filter(Boolean).join("\n"),
    });

    setSavingTask(false);

    if (error) {
      toast.error("작업 등록에 실패했습니다");
      return;
    }

    setCreatedWorkboardTaskId(workboardTaskId);
    toast.success("Workboard에 회신 작업이 등록되었습니다");
  };

  useEffect(() => {
    if (resultRef.current && step === "generating") {
      resultRef.current.scrollTop = resultRef.current.scrollHeight;
    }
  }, [draft, step]);

  useEffect(() => {
    if (isEditing && textareaRef.current) {
      textareaRef.current.focus();
      textareaRef.current.style.height = "auto";
      textareaRef.current.style.height = textareaRef.current.scrollHeight + "px";
    }
  }, [isEditing]);

  useEffect(() => {
    setCreatedWorkboardTaskId(null);
  }, [packet?.task_id, selectedTone, contextNote]);

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-3 px-6 py-4 border-b border-border/50">
        <button
          onClick={step === "setup" ? onBack : handleReset}
          className="w-8 h-8 rounded-lg hover:bg-secondary flex items-center justify-center transition-colors"
        >
          <ArrowLeft className="w-4 h-4 text-muted-foreground" />
        </button>
        <div className="flex-1">
          <h2 className="text-[14px] font-semibold">고객 대응</h2>
          <p className="text-[11px] text-muted-foreground">
            {step === "setup" && "문의 유형과 설정을 선택하세요"}
            {step === "generating" && "AI가 회신 초안을 작성 중입니다..."}
            {step === "edit" && "초안을 검토하고 편집하세요"}
            {step === "sent" && "회신이 발송되었습니다"}
          </p>
        </div>
        <div className="flex items-center gap-1.5">
          {(["setup", "edit", "sent"] as const).map((s, i) => (
            <div
              key={s}
              className={`h-1.5 rounded-full transition-all ${
                (step === s || (step === "generating" && s === "edit"))
                  ? "w-6 bg-primary"
                  : i < ["setup", "edit", "sent"].indexOf(step === "generating" ? "edit" : step)
                  ? "w-4 bg-primary/40"
                  : "w-4 bg-secondary"
              }`}
            />
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        <AnimatePresence mode="wait">
          {/* Step 1: Setup */}
          {step === "setup" && (
            <motion.div
              key="setup"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="p-6 space-y-5"
            >
              {/* Customer select */}
              <div>
                <label className="text-[12px] font-medium text-foreground mb-2 block">고객사 선택</label>
                <div className="grid grid-cols-2 gap-2">
                  {customers.map((c) => (
                    <button
                      key={c.id}
                      onClick={() => setSelectedCustomer(c.id)}
                      className={`text-left p-3 rounded-xl border transition-all ${
                        selectedCustomer === c.id
                          ? "border-primary bg-primary/5"
                          : "border-border/50 bg-secondary/20 hover:border-border"
                      }`}
                    >
                      <div className="flex items-center gap-2">
                        <Building2 className="w-4 h-4 text-muted-foreground" />
                        <div>
                          <p className="text-[12px] font-medium">{c.name}</p>
                          <p className="text-[10px] text-muted-foreground">{c.contact}</p>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>

              {/* Inquiry type */}
              <div>
                <label className="text-[12px] font-medium text-foreground mb-2 block">문의 유형</label>
                <div className="grid grid-cols-3 gap-2">
                  {inquiryTypes.map((t) => (
                    <button
                      key={t.id}
                      onClick={() => setSelectedInquiry(t.id)}
                      className={`text-left p-3 rounded-xl border transition-all ${
                        selectedInquiry === t.id
                          ? "border-primary bg-primary/5"
                          : "border-border/50 bg-secondary/20 hover:border-border"
                      }`}
                    >
                      <t.icon className={`w-4 h-4 mb-1.5 ${selectedInquiry === t.id ? "text-primary" : "text-muted-foreground"}`} />
                      <p className="text-[11px] font-medium">{t.label}</p>
                      <p className="text-[9px] text-muted-foreground mt-0.5">{t.description}</p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Channel & Tone */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[12px] font-medium text-foreground mb-2 block">회신 채널</label>
                  <div className="flex gap-2">
                    {channels.map((ch) => (
                      <button
                        key={ch.id}
                        onClick={() => setSelectedChannel(ch.id)}
                        className={`flex-1 flex flex-col items-center gap-1 p-2.5 rounded-xl border transition-all ${
                          selectedChannel === ch.id
                            ? "border-primary bg-primary/5 text-primary"
                            : "border-border/50 bg-secondary/20 text-muted-foreground hover:border-border"
                        }`}
                      >
                        <ch.icon className="w-4 h-4" />
                        <span className="text-[10px] font-medium">{ch.label}</span>
                      </button>
                    ))}
                  </div>
                </div>
                <div>
                  <label className="text-[12px] font-medium text-foreground mb-2 block">톤앤매너</label>
                  <div className="flex flex-wrap gap-1.5">
                    {toneOptions.map((tone) => (
                      <button
                        key={tone}
                        onClick={() => setSelectedTone(tone)}
                        className={`px-3 py-1.5 rounded-lg border text-[11px] transition-all ${
                          selectedTone === tone
                            ? "border-primary bg-primary/10 text-primary font-medium"
                            : "border-border/50 bg-secondary/20 text-muted-foreground hover:border-border"
                        }`}
                      >
                        {tone}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Context note */}
              <div>
                <label className="text-[12px] font-medium text-foreground mb-2 block">추가 맥락 (선택)</label>
                <textarea
                  value={contextNote}
                  onChange={(e) => setContextNote(e.target.value)}
                  placeholder="예: 지난주 품질 테스트 결과 불량률 0.3%로 개선됨, 납기는 2주 연장 가능..."
                  className="w-full h-20 p-3 rounded-xl border border-border/50 bg-secondary/10 text-[12px] text-foreground placeholder:text-muted-foreground/50 resize-none focus:outline-none focus:border-primary/50 transition-colors"
                />
              </div>

              {packet && (
                <section aria-label="Gateway customer reply route" className="rounded-xl border border-primary/15 bg-primary/5 p-3">
                  <div className="mb-2 flex items-center justify-between gap-3">
                    <div>
                      <p className="text-[10px] font-semibold text-primary">Gateway Task Packet</p>
                      <p className="text-[11px] text-muted-foreground">회신 초안은 Workboard에서 검토와 증거 기록으로 이어집니다</p>
                    </div>
                    <span className="rounded-md border border-primary/20 bg-background px-2 py-1 text-[10px] font-medium text-primary">
                      {packet.task_type}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-[11px]">
                    <div className="rounded-lg border border-border/40 bg-background/70 p-2">
                      <p className="text-[9px] uppercase text-muted-foreground">Risk</p>
                      <p className="font-medium">{packet.risk_level}</p>
                    </div>
                    <div className="rounded-lg border border-border/40 bg-background/70 p-2">
                      <p className="text-[9px] uppercase text-muted-foreground">Approval</p>
                      <p className="font-medium">{packet.required_approval ? "승인 필요" : "draft-only"}</p>
                    </div>
                  </div>
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {packet.verification_requirements.map((requirement) => (
                      <span key={`${requirement.type}-${requirement.command_or_source}`} className="rounded-md bg-background px-2 py-1 text-[10px] text-muted-foreground">
                        {requirement.type}
                      </span>
                    ))}
                  </div>
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {packet.forbidden_actions.slice(0, 3).map((action) => (
                      <span key={action} className="rounded-md border border-destructive/20 bg-destructive/5 px-2 py-1 text-[10px] text-destructive">
                        {action}
                      </span>
                    ))}
                  </div>
                </section>
              )}

              {/* Generate */}
              <motion.button
                whileHover={{ scale: 1.01 }}
                whileTap={{ scale: 0.99 }}
                onClick={handleGenerate}
                disabled={!selectedInquiry}
                className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-primary text-primary-foreground font-medium text-[13px] hover:bg-primary/90 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <Sparkles className="w-4 h-4" />
                회신 초안 생성
                <ArrowRight className="w-4 h-4" />
              </motion.button>
            </motion.div>
          )}

          {/* Step 2: Generating */}
          {step === "generating" && (
            <motion.div
              key="generating"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="flex flex-col h-full"
            >
              <div className="flex items-center gap-2 px-6 py-3 border-b border-border/30 bg-primary/5">
                <Loader2 className="w-3.5 h-3.5 text-primary animate-spin" />
                <span className="text-[11px] text-primary font-medium">
                  {customer?.name} — {inquiry?.label} 회신 초안 생성 중...
                </span>
              </div>
              <div ref={resultRef} className="flex-1 overflow-y-auto px-6 py-4 scrollbar-thin">
                <div className="prose prose-sm dark:prose-invert max-w-none text-[13px] leading-relaxed">
                  <ReactMarkdown>{draft}</ReactMarkdown>
                </div>
              </div>
            </motion.div>
          )}

          {/* Step 3: Edit & Send */}
          {step === "edit" && (
            <motion.div
              key="edit"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex flex-col h-full"
            >
              <div className="flex items-center justify-between px-6 py-3 border-b border-border/30 bg-status-completed/5">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-status-completed" />
                  <span className="text-[11px] text-status-completed font-medium">초안 생성 완료</span>
                </div>
                <div className="flex items-center gap-1.5 text-[10px] text-muted-foreground">
                  <Clock className="w-3 h-3" />
                  {customer?.name} · {inquiry?.label}
                </div>
              </div>

              <div className="flex-1 overflow-y-auto px-6 py-4 scrollbar-thin">
                {isEditing ? (
                  <textarea
                    ref={textareaRef}
                    value={editedDraft}
                    onChange={(e) => {
                      setEditedDraft(e.target.value);
                      e.target.style.height = "auto";
                      e.target.style.height = e.target.scrollHeight + "px";
                    }}
                    className="w-full min-h-[300px] p-4 rounded-xl border border-primary/30 bg-secondary/10 text-[13px] text-foreground leading-relaxed resize-none focus:outline-none focus:border-primary/50 font-mono"
                  />
                ) : (
                  <div className="prose prose-sm dark:prose-invert max-w-none text-[13px] leading-relaxed">
                    <ReactMarkdown>{editedDraft}</ReactMarkdown>
                  </div>
                )}
              </div>

              {/* Bottom actions */}
              <div className="px-6 py-3 border-t border-border/50 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleReset}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-border/50 text-[11px] text-muted-foreground hover:bg-secondary transition-colors"
                  >
                    <RotateCcw className="w-3 h-3" />
                    다시 작성
                  </button>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(editedDraft);
                      toast.success("클립보드에 복사되었습니다");
                    }}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-border/50 text-[11px] text-muted-foreground hover:bg-secondary transition-colors"
                  >
                    <Copy className="w-3 h-3" />
                    복사
                  </button>
                  <button
                    onClick={() => {
                      if (isEditing) {
                        toast.success("편집 내용이 저장되었습니다");
                      }
                      setIsEditing(!isEditing);
                    }}
                    className={`flex items-center gap-1.5 px-3 py-2 rounded-lg border text-[11px] transition-colors ${
                      isEditing
                        ? "border-primary bg-primary/10 text-primary"
                        : "border-border/50 text-muted-foreground hover:bg-secondary"
                    }`}
                  >
                    {isEditing ? <Save className="w-3 h-3" /> : <Edit3 className="w-3 h-3" />}
                    {isEditing ? "저장" : "편집"}
                  </button>
                  <button
                    onClick={createWorkboardTask}
                    disabled={!packet || savingTask || Boolean(createdWorkboardTaskId)}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-primary/30 bg-primary/5 text-[11px] text-primary hover:bg-primary/10 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {savingTask ? <Loader2 className="w-3 h-3 animate-spin" /> : <CheckCircle2 className="w-3 h-3" />}
                    {createdWorkboardTaskId ? "작업 등록됨" : savingTask ? "등록 중" : "작업 등록"}
                  </button>
                  {createdWorkboardTaskId && onOpenTasks && (
                    <button
                      onClick={() => onOpenTasks(createdWorkboardTaskId)}
                      className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-border/50 text-[11px] text-muted-foreground hover:bg-secondary transition-colors"
                    >
                      <ArrowRight className="w-3 h-3" />
                      작업에서 계속
                    </button>
                  )}
                </div>
                <button
                  onClick={handleSend}
                  className="flex items-center gap-1.5 px-5 py-2 rounded-lg bg-primary text-primary-foreground text-[11px] font-medium hover:bg-primary/90 transition-colors"
                >
                  <Send className="w-3 h-3" />
                  발송 승인 필요
                </button>
              </div>
            </motion.div>
          )}

          {/* Step 4: Sent confirmation */}
          {step === "sent" && (
            <motion.div
              key="sent"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="flex-1 flex items-center justify-center"
            >
              <div className="text-center space-y-4">
                <motion.div
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: "spring", stiffness: 200, delay: 0.1 }}
                  className="w-16 h-16 rounded-2xl bg-status-completed/10 border border-status-completed/20 flex items-center justify-center mx-auto"
                >
                  <CheckCircle2 className="w-8 h-8 text-status-completed" />
                </motion.div>
                <div>
                  <p className="text-[14px] font-semibold">회신이 발송되었습니다</p>
                  <p className="text-[12px] text-muted-foreground mt-1">
                    {customer?.name} {customer?.contact}에게 {inquiry?.label} 회신 완료
                  </p>
                </div>
                <button
                  onClick={handleReset}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-secondary text-[11px] text-foreground hover:bg-secondary/80 transition-colors mx-auto"
                >
                  <RotateCcw className="w-3 h-3" />
                  새 회신 작성
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
