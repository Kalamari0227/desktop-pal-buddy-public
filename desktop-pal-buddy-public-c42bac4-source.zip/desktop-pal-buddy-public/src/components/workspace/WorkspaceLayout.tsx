import { lazy, Suspense, useEffect, useState } from "react";
import { motion } from "framer-motion";
import { WorkspaceNav } from "./WorkspaceNav";
import { WorkspaceChat } from "./WorkspaceChat";
import { ContextPanel } from "./ContextPanel";
import { CompanyRuntimeControls } from "./CompanyRuntimeControls";
import { RuntimeConnectionStatus } from "./RuntimeConnectionStatus";
import type { Agent, DockAlert } from "@/types/dock";

import type { Msg } from "@/lib/streamChat";

type CompanyDraft = { id: string; text: string };
type ModeContext = Record<string, string | CompanyDraft | undefined>;

const HomeCommandCenter = lazy(() => import("./HomeCommandCenter").then((module) => ({ default: module.HomeCommandCenter })));
const GatewayMode = lazy(() => import("./GatewayMode").then((module) => ({ default: module.GatewayMode })));
const MeetingPrepMode = lazy(() => import("./MeetingPrepMode").then((module) => ({ default: module.MeetingPrepMode })));
const CustomerResponseMode = lazy(() => import("./CustomerResponseMode").then((module) => ({ default: module.CustomerResponseMode })));
const DocSearchMode = lazy(() => import("./DocSearchMode").then((module) => ({ default: module.DocSearchMode })));
const RiskCheckMode = lazy(() => import("./RiskCheckMode").then((module) => ({ default: module.RiskCheckMode })));
const PerformanceMode = lazy(() => import("./PerformanceMode").then((module) => ({ default: module.PerformanceMode })));
const ReportDraftMode = lazy(() => import("./ReportDraftMode").then((module) => ({ default: module.ReportDraftMode })));
const TasksMode = lazy(() => import("./TasksMode").then((module) => ({ default: module.TasksMode })));
const CustomersMode = lazy(() => import("./CustomersMode").then((module) => ({ default: module.CustomersMode })));
const AgentsMode = lazy(() => import("./AgentsMode").then((module) => ({ default: module.AgentsMode })));
const WorkflowsMode = lazy(() => import("./WorkflowsMode").then((module) => ({ default: module.WorkflowsMode })));
const AgentMeetingMode = lazy(() => import("./AgentMeetingMode").then((module) => ({ default: module.AgentMeetingMode })));
const AlertsMode = lazy(() => import("./AlertsMode").then((module) => ({ default: module.AlertsMode })));
const SettingsMode = lazy(() => import("./SettingsMode").then((module) => ({ default: module.SettingsMode })));
const ReportsMode = lazy(() => import("./ReportsMode").then((module) => ({ default: module.ReportsMode })));
const MarketplaceMode = lazy(() => import("./MarketplaceMode").then((module) => ({ default: module.MarketplaceMode })));
const MyInstallationsMode = lazy(() => import("./MyInstallationsMode").then((module) => ({ default: module.MyInstallationsMode })));

interface WorkspaceLayoutProps {
  agents: Agent[];
  alerts: DockAlert[];
  onClose: () => void;
  initialMode?: string;
  initialContext?: Record<string, string>;
  initialPrompt?: string;
  initialPromptId?: number;
  isElectronShell?: boolean;
  chatMessages?: Msg[];
  onAlertDismissChange?: (dismissedIds: Set<string>) => void;
}

const modeLabels: Record<string, string> = {
  home: "홈",
  gateway: "요청",
  customers: "고객",
  tasks: "작업",
  agents: "에이전트",
  workflows: "자동화",
  reports: "보고서",
  alerts: "알림",
  marketplace: "연결",
  "my-installations": "설치 항목",
  "agent-meeting": "에이전트 회의",
  settings: "설정",
  meeting: "회의/방문 준비",
  response: "고객 대응",
  search: "문서",
  risk: "리스크",
  performance: "실적/수익성",
  report: "보고 초안",
};

function WorkspaceModeFallback() {
  return (
    <div className="flex h-full items-center justify-center text-[12px] text-muted-foreground">
      불러오는 중...
    </div>
  );
}

export function WorkspaceLayout({
  agents,
  alerts,
  onClose,
  initialMode,
  initialContext,
  initialPrompt,
  initialPromptId,
  isElectronShell,
  chatMessages,
  onAlertDismissChange,
}: WorkspaceLayoutProps) {
  const [activeMode, setActiveMode] = useState(initialMode || "home");
  const [modeContext, setModeContext] = useState<ModeContext>(initialContext || {});
  const shellMotion = isElectronShell
    ? {
        initial: { opacity: 1, scale: 1, y: 0 },
        animate: { opacity: 1, scale: 1, y: 0 },
        exit: { opacity: 1, scale: 1, y: 0 },
        transition: { duration: 0.01 },
      }
    : {
        initial: { opacity: 0, scale: 0.97, y: 20 },
        animate: { opacity: 1, scale: 1, y: 0 },
        exit: { opacity: 0, scale: 0.97, y: 20 },
        transition: { duration: 0.4, ease: [0.16, 1, 0.3, 1] as const },
      };

  useEffect(() => {
    setActiveMode(initialMode || "home");
    setModeContext(initialContext || {});
  }, [initialContext, initialMode]);

  const stringModeContext = (): Record<string, string> => Object.fromEntries(
    Object.entries(modeContext).filter((entry): entry is [string, string] => typeof entry[1] === "string"),
  );
  const companyDraft = modeContext.companyDraft && typeof modeContext.companyDraft !== "string"
    ? modeContext.companyDraft
    : undefined;

  const handleModeSelect = (mode: string, context?: Record<string, string>) => {
    setActiveMode(mode);
    setModeContext(context || {});
  };

  const handleCompanyWorkStart = (draftText: string) => {
    const text = draftText.trim();
    setActiveMode("gateway");
    setModeContext(text ? { companyDraft: { id: crypto.randomUUID(), text } } : {});
  };

  const handleCompanyDraftChange = (draft: CompanyDraft) => {
    setModeContext((current) => {
      const currentDraft = current.companyDraft;
      return typeof currentDraft !== "string" && currentDraft?.id === draft.id
      ? { ...current, companyDraft: draft }
      : current;
    });
  };

  const renderContent = () => {
    switch (activeMode) {
      case "home":
        return <HomeCommandCenter onModeSelect={handleModeSelect} initialContext={stringModeContext()} />;
      case "gateway":
        return (
          <GatewayMode
            onBack={() => setActiveMode("home")}
            onOpenTasks={(taskId) => handleModeSelect("tasks", taskId ? { taskId } : undefined)}
            companyDraft={companyDraft}
            onCompanyDraftChange={handleCompanyDraftChange}
          />
        );
      case "meeting":
        return <MeetingPrepMode onBack={() => setActiveMode("home")} />;
      case "response":
        return (
          <CustomerResponseMode
            onBack={() => setActiveMode("home")}
            onOpenTasks={(taskId) => handleModeSelect("tasks", taskId ? { taskId } : undefined)}
          />
        );
      case "search":
        return <DocSearchMode onBack={() => setActiveMode("home")} />;
      case "risk":
        return <RiskCheckMode onBack={() => setActiveMode("home")} />;
      case "performance":
        return <PerformanceMode onBack={() => setActiveMode("home")} />;
      case "report":
        return <ReportDraftMode onBack={() => setActiveMode("home")} />;
      case "tasks":
        return <TasksMode onBack={() => setActiveMode("home")} initialTaskId={typeof modeContext.taskId === "string" ? modeContext.taskId : undefined} />;
      case "customers":
        return <CustomersMode onBack={() => setActiveMode("home")} onModeSelect={handleModeSelect} initialCustomer={typeof modeContext.customer === "string" ? modeContext.customer : undefined} />;
      case "agents":
        return <AgentsMode onBack={() => setActiveMode("home")} />;
      case "marketplace":
        return <MarketplaceMode onBack={() => setActiveMode("home")} />;
      case "my-installations":
        return <MyInstallationsMode onBack={() => setActiveMode("home")} />;
      case "workflows":
        return <WorkflowsMode onBack={() => setActiveMode("home")} />;
      case "agent-meeting":
        return <AgentMeetingMode onBack={() => setActiveMode("home")} />;
      case "alerts":
        return <AlertsMode onBack={() => setActiveMode("home")} onDismissChange={onAlertDismissChange} />;
      case "reports":
        return <ReportsMode onBack={() => setActiveMode("home")} onModeSelect={handleModeSelect} />;
      case "settings":
        return <SettingsMode onBack={() => setActiveMode("home")} />;
      default:
        return (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center space-y-3">
              <div className="w-16 h-16 rounded-2xl bg-secondary/30 border border-border/50 flex items-center justify-center mx-auto">
                <span className="text-2xl">🚧</span>
              </div>
              <div>
                <p className="text-[13px] font-medium text-foreground">{activeMode} 모드</p>
                <p className="text-[11px] text-muted-foreground mt-1">이 워크스페이스는 추후 구현 예정입니다</p>
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <motion.div
      initial={shellMotion.initial}
      animate={shellMotion.animate}
      exit={shellMotion.exit}
      transition={shellMotion.transition}
      className="fixed inset-2 md:inset-4 z-50 rounded-3xl overflow-hidden glass-elevated flex"
    >
      <WorkspaceNav activeMode={activeMode} onModeChange={handleModeSelect} onClose={onClose} />

      <div className="flex-1 min-w-0 flex flex-col bg-background/80 relative overflow-hidden">
        <div className="h-12 flex items-center justify-between px-6 border-b border-border/50 flex-shrink-0">
          <div className="flex items-center gap-3">
            <h2 className="text-[13px] font-semibold">
              {modeLabels[activeMode] || activeMode}
            </h2>
          </div>
          <div className="flex items-center gap-2">
            <RuntimeConnectionStatus />
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-secondary/50 text-[10px] text-muted-foreground">
              <div className="w-1.5 h-1.5 rounded-full bg-status-completed" />
              시스템 정상
            </div>
          </div>
        </div>

        <CompanyRuntimeControls />

        <div className="flex-1 overflow-hidden" style={{ paddingBottom: '56px' }}>
          <Suspense fallback={<WorkspaceModeFallback />}>
            {renderContent()}
          </Suspense>
        </div>
        <WorkspaceChat
          initialMessages={chatMessages}
          initialPrompt={initialPrompt}
          initialPromptId={initialPromptId}
          onStartCompanyWork={handleCompanyWorkStart}
        />
      </div>

      <ContextPanel agents={agents} alerts={alerts} onModeSelect={handleModeSelect} />
    </motion.div>
  );
}
