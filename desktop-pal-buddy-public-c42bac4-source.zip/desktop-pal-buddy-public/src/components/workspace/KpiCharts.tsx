import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
  LineChart, Line, Legend,
} from "recharts";
import { TrendingUp, BarChart3, PieChart as PieIcon, CalendarDays, Users, Filter, RotateCcw } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import type { TaskRecord } from "@/types/task";

interface KpiChartsProps {
  tasks: TaskRecord[];
}

/* POSCO Brand Colors for charts */
const POSCO_GOLD = "hsl(43, 65%, 47%)";
const POSCO_LIGHT_BLUE = "hsl(197, 100%, 45%)";

const COLORS = {
  critical: "hsl(0, 72%, 51%)",
  high: "hsl(25, 90%, 55%)",
  medium: POSCO_GOLD,
  low: "hsl(145, 60%, 45%)",
};

const CATEGORY_COLORS = [POSCO_GOLD, POSCO_LIGHT_BLUE, "hsl(340, 65%, 55%)", "hsl(145, 60%, 45%)"];

const categoryLabels: Record<string, string> = {
  delivery: "납기",
  quality: "품질",
  price: "가격",
};

const severityLabels: Record<string, string> = {
  critical: "심각",
  high: "높음",
  medium: "보통",
  low: "낮음",
};

/* Theme-aware chart styles — uses CSS custom properties resolved at render time */
function useChartTheme() {
  const isLight = typeof document !== "undefined" && document.documentElement.classList.contains("light");
  const grid = isLight ? "hsl(210, 8%, 82%)" : "hsl(220, 14%, 18%)";
  const axisText = isLight ? "hsl(202, 20%, 45%)" : "hsl(220, 10%, 55%)";
  const tooltipBg = isLight ? "hsl(0, 0%, 100%)" : "hsl(220, 18%, 12%)";
  const tooltipBorder = isLight ? "hsl(210, 8%, 85%)" : "hsl(220, 14%, 22%)";
  const tooltipText = isLight ? "hsl(202, 80%, 18%)" : "hsl(40, 10%, 85%)";
  return {
    grid, axisText,
    tooltipStyle: {
      contentStyle: { background: tooltipBg, border: `1px solid ${tooltipBorder}`, borderRadius: "8px", fontSize: "11px", color: tooltipText },
      itemStyle: { color: tooltipText },
    },
  };
}

export function KpiCharts({ tasks }: KpiChartsProps) {
  const { grid, axisText, tooltipStyle } = useChartTheme();
  const [startDate, setStartDate] = useState<Date | undefined>(undefined);
  const [endDate, setEndDate] = useState<Date | undefined>(undefined);

  // Filter tasks by date range
  const filteredTasks = useMemo(() => {
    if (!startDate && !endDate) return tasks;
    return tasks.filter((t) => {
      const created = t.created_at ? new Date(t.created_at) : null;
      if (!created) return false;
      if (startDate) {
        const start = new Date(startDate);
        start.setHours(0, 0, 0, 0);
        if (created < start) return false;
      }
      if (endDate) {
        const end = new Date(endDate);
        end.setHours(23, 59, 59, 999);
        if (created > end) return false;
      }
      return true;
    });
  }, [tasks, startDate, endDate]);

  const hasFilter = startDate || endDate;

  // Weekly trend data (last 7 days)
  const trendData = useMemo(() => {
    const days: { date: string; label: string; count: number; resolved: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dateStr = d.toISOString().slice(0, 10);
      const label = d.toLocaleDateString("ko-KR", { month: "numeric", day: "numeric" });
      const count = filteredTasks.filter((t) => t.created_at?.slice(0, 10) === dateStr).length;
      const resolved = filteredTasks.filter((t) => t.status === "done" && t.updated_at?.slice(0, 10) === dateStr).length;
      days.push({ date: dateStr, label, count, resolved });
    }
    return days;
  }, [filteredTasks]);

  // Monthly trend data (last 6 months)
  const monthlyData = useMemo(() => {
    const months: { month: string; label: string; total: number; completed: number; pending: number }[] = [];
    for (let i = 5; i >= 0; i--) {
      const d = new Date();
      d.setMonth(d.getMonth() - i);
      const yearMonth = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      const label = d.toLocaleDateString("ko-KR", { month: "short" });
      const monthTasks = filteredTasks.filter((t) => t.created_at?.slice(0, 7) === yearMonth);
      months.push({
        month: yearMonth,
        label,
        total: monthTasks.length,
        completed: monthTasks.filter((t) => t.status === "done").length,
        pending: monthTasks.filter((t) => t.status === "pending" || t.status === "in_progress").length,
      });
    }
    return months;
  }, [filteredTasks]);

  // Customer activity analysis
  const customerData = useMemo(() => {
    const map: Record<string, { total: number; critical: number; resolved: number }> = {};
    filteredTasks.forEach((t) => {
      const cust = t.customer || "미지정";
      if (!map[cust]) map[cust] = { total: 0, critical: 0, resolved: 0 };
      map[cust].total++;
      if (t.severity === "critical" || t.severity === "high") map[cust].critical++;
      if (t.status === "done") map[cust].resolved++;
    });
    return Object.entries(map)
      .sort(([, a], [, b]) => b.total - a.total)
      .slice(0, 6)
      .map(([name, data]) => ({ name, ...data }));
  }, [filteredTasks]);

  // Category distribution
  const categoryData = useMemo(() => {
    const map: Record<string, number> = {};
    filteredTasks.forEach((t) => {
      const cat = t.category || "기타";
      map[cat] = (map[cat] || 0) + 1;
    });
    return Object.entries(map).map(([key, value]) => ({
      name: categoryLabels[key] || key,
      value,
    }));
  }, [filteredTasks]);

  // Severity distribution
  const severityData = useMemo(() => {
    const map: Record<string, number> = {};
    filteredTasks.forEach((t) => {
      const sev = t.severity || "none";
      if (sev !== "none") map[sev] = (map[sev] || 0) + 1;
    });
    const order = ["critical", "high", "medium", "low"];
    return order
      .filter((k) => map[k])
      .map((key) => ({
        name: severityLabels[key] || key,
        value: map[key],
        color: COLORS[key as keyof typeof COLORS],
      }));
  }, [filteredTasks]);

  return (
    <section className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-[13px] font-semibold">KPI 차트</h2>
        <div className="flex items-center gap-2">
          <Filter className="w-3.5 h-3.5 text-muted-foreground" />
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" size="sm" className={cn("h-7 text-[11px] px-2.5 border-border/50", !startDate && "text-muted-foreground")}>
                <CalendarDays className="w-3 h-3 mr-1" />
                {startDate ? format(startDate, "yyyy.MM.dd") : "시작일"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="end">
              <Calendar mode="single" selected={startDate} onSelect={setStartDate} initialFocus className={cn("p-3 pointer-events-auto")} />
            </PopoverContent>
          </Popover>
          <span className="text-[11px] text-muted-foreground">~</span>
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" size="sm" className={cn("h-7 text-[11px] px-2.5 border-border/50", !endDate && "text-muted-foreground")}>
                <CalendarDays className="w-3 h-3 mr-1" />
                {endDate ? format(endDate, "yyyy.MM.dd") : "종료일"}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-auto p-0" align="end">
              <Calendar mode="single" selected={endDate} onSelect={setEndDate} initialFocus className={cn("p-3 pointer-events-auto")} />
            </PopoverContent>
          </Popover>
          {hasFilter && (
            <Button variant="ghost" size="sm" className="h-7 text-[11px] px-2 text-muted-foreground hover:text-foreground" onClick={() => { setStartDate(undefined); setEndDate(undefined); }}>
              <RotateCcw className="w-3 h-3 mr-1" />
              초기화
            </Button>
          )}
          {hasFilter && (
            <span className="text-[10px] text-primary ml-1">{filteredTasks.length}건</span>
          )}
        </div>
      </div>

      {/* Row 1: Weekly Trend + Severity Donut */}
      <div className="grid grid-cols-3 gap-4">
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="col-span-2 rounded-2xl p-4 bg-secondary/20 border border-border/30"
        >
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp className="w-4 h-4 text-primary" />
            <span className="text-[12px] font-medium">주간 작업 트렌드</span>
          </div>
          <ResponsiveContainer width="100%" height={180}>
            <AreaChart data={trendData}>
              <defs>
                <linearGradient id="colorCount" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={POSCO_GOLD} stopOpacity={0.3} />
                  <stop offset="95%" stopColor={POSCO_GOLD} stopOpacity={0} />
                </linearGradient>
                <linearGradient id="colorResolved" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(145, 60%, 45%)" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="hsl(145, 60%, 45%)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke={grid} />
              <XAxis dataKey="label" tick={{ fontSize: 10, fill: axisText }} axisLine={{ stroke: grid }} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: axisText }} axisLine={false} tickLine={false} allowDecimals={false} />
              <Tooltip {...tooltipStyle} />
              <Area type="monotone" dataKey="count" name="등록" stroke={POSCO_GOLD} strokeWidth={2} fill="url(#colorCount)" />
              <Area type="monotone" dataKey="resolved" name="완료" stroke="hsl(145, 60%, 45%)" strokeWidth={2} fill="url(#colorResolved)" />
            </AreaChart>
          </ResponsiveContainer>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="rounded-2xl p-4 bg-secondary/20 border border-border/30"
        >
          <div className="flex items-center gap-2 mb-3">
            <PieIcon className="w-4 h-4 text-primary" />
            <span className="text-[12px] font-medium">심각도 분포</span>
          </div>
          {severityData.length > 0 ? (
            <>
              <ResponsiveContainer width="100%" height={130}>
                <PieChart>
                  <Pie data={severityData} cx="50%" cy="50%" innerRadius={35} outerRadius={55} paddingAngle={3} dataKey="value" stroke="none">
                    {severityData.map((entry, i) => (
                      <Cell key={i} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip {...tooltipStyle} />
                </PieChart>
              </ResponsiveContainer>
              <div className="flex flex-wrap gap-2 mt-2 justify-center">
                {severityData.map((s, i) => (
                  <div key={i} className="flex items-center gap-1">
                    <div className="w-2 h-2 rounded-full" style={{ background: s.color }} />
                    <span className="text-[9px] text-muted-foreground">{s.name} {s.value}</span>
                  </div>
                ))}
              </div>
            </>
          ) : (
            <p className="text-[11px] text-muted-foreground text-center py-8">데이터 없음</p>
          )}
        </motion.div>
      </div>

      {/* Row 2: Monthly Trend */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
        className="rounded-2xl p-4 bg-secondary/20 border border-border/30"
      >
        <div className="flex items-center gap-2 mb-3">
          <CalendarDays className="w-4 h-4 text-primary" />
          <span className="text-[12px] font-medium">월간 작업 트렌드</span>
          <span className="text-[10px] text-muted-foreground ml-auto">최근 6개월</span>
        </div>
        <ResponsiveContainer width="100%" height={200}>
          <LineChart data={monthlyData}>
            <CartesianGrid strokeDasharray="3 3" stroke={grid} />
            <XAxis dataKey="label" tick={{ fontSize: 10, fill: axisText }} axisLine={{ stroke: grid }} tickLine={false} />
            <YAxis tick={{ fontSize: 10, fill: axisText }} axisLine={false} tickLine={false} allowDecimals={false} />
            <Tooltip {...tooltipStyle} />
            <Legend wrapperStyle={{ fontSize: "10px", color: axisText }} />
            <Line type="monotone" dataKey="total" name="전체" stroke={POSCO_GOLD} strokeWidth={2} dot={{ r: 4, fill: POSCO_GOLD }} activeDot={{ r: 6 }} />
            <Line type="monotone" dataKey="completed" name="완료" stroke="hsl(145, 60%, 45%)" strokeWidth={2} dot={{ r: 4, fill: "hsl(145, 60%, 45%)" }} />
            <Line type="monotone" dataKey="pending" name="미결" stroke="hsl(0, 72%, 51%)" strokeWidth={2} dot={{ r: 4, fill: "hsl(0, 72%, 51%)" }} strokeDasharray="5 5" />
          </LineChart>
        </ResponsiveContainer>
      </motion.div>

      {/* Row 3: Customer Analysis + Category Bar */}
      <div className="grid grid-cols-2 gap-4">
        {/* Customer Analysis */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className="rounded-2xl p-4 bg-secondary/20 border border-border/30"
        >
          <div className="flex items-center gap-2 mb-3">
            <Users className="w-4 h-4 text-primary" />
            <span className="text-[12px] font-medium">고객별 작업 분석</span>
          </div>
          {customerData.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={customerData} layout="vertical" barSize={14}>
                <CartesianGrid strokeDasharray="3 3" stroke={grid} horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 10, fill: axisText }} axisLine={false} tickLine={false} allowDecimals={false} />
                <YAxis dataKey="name" type="category" tick={{ fontSize: 10, fill: axisText }} axisLine={false} tickLine={false} width={70} />
                <Tooltip {...tooltipStyle} />
                <Legend wrapperStyle={{ fontSize: "10px", color: axisText }} />
                <Bar dataKey="total" name="전체" fill={POSCO_LIGHT_BLUE} radius={[0, 4, 4, 0]} />
                <Bar dataKey="critical" name="긴급" fill="hsl(0, 72%, 51%)" radius={[0, 4, 4, 0]} />
                <Bar dataKey="resolved" name="완료" fill="hsl(145, 60%, 45%)" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <p className="text-[11px] text-muted-foreground text-center py-8">데이터 없음</p>
          )}
        </motion.div>

        {/* Category Bar Chart */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="rounded-2xl p-4 bg-secondary/20 border border-border/30"
        >
          <div className="flex items-center gap-2 mb-3">
            <BarChart3 className="w-4 h-4 text-primary" />
            <span className="text-[12px] font-medium">카테고리별 작업</span>
          </div>
          {categoryData.length > 0 ? (
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={categoryData} barSize={32}>
                <CartesianGrid strokeDasharray="3 3" stroke={grid} />
                <XAxis dataKey="name" tick={{ fontSize: 11, fill: axisText }} axisLine={{ stroke: grid }} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: axisText }} axisLine={false} tickLine={false} allowDecimals={false} />
                <Tooltip {...tooltipStyle} />
                <Bar dataKey="value" name="건수" radius={[6, 6, 0, 0]}>
                  {categoryData.map((_, i) => (
                    <Cell key={i} fill={CATEGORY_COLORS[i % CATEGORY_COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <p className="text-[11px] text-muted-foreground text-center py-8">데이터 없음</p>
          )}
        </motion.div>
      </div>
    </section>
  );
}
