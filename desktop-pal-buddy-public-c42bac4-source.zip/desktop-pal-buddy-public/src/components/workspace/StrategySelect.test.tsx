import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { demoStrategies, demoStrategyVersions } from "@/data/demoStrategyCatalog";
import { StrategySelect } from "./StrategySelect";

describe("StrategySelect", () => {
  it("lets a demo user choose an optional strategy and one of its versions", () => {
    const onSelectionChange = vi.fn();

    render(
      <StrategySelect
        strategies={demoStrategies}
        versions={demoStrategyVersions}
        strategyId="delivery-risk-early-warning"
        versionId="delivery-risk-early-warning-v1"
        onSelectionChange={onSelectionChange}
      />,
    );

    expect(screen.getByLabelText("전략 선택")).toHaveValue("delivery-risk-early-warning");
    expect(screen.getByLabelText("전략 버전 선택")).toHaveValue("delivery-risk-early-warning-v1");

    fireEvent.change(screen.getByLabelText("전략 버전 선택"), {
      target: { value: "delivery-risk-early-warning-v2" },
    });

    expect(onSelectionChange).toHaveBeenCalledWith({
      strategyId: "delivery-risk-early-warning",
      versionId: "delivery-risk-early-warning-v2",
    });
  });
});
