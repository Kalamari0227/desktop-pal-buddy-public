import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { supabase } from "@/integrations/supabase/client";
import {
  Calendar,
  PenLine,
  Search,
  ShieldAlert,
  CheckSquare,
  FileText,
  BarChart3,
  AlertTriangle,
  Clock,
  ArrowRight,
  Sparkles,
  Users,
  Bot,
  Zap,
  Server,
  Package,
  Wand2,
} from "lucide-react";
import { KpiCharts } from "./KpiCharts";
import { useInstalledItems } from "@/hooks/useInstalledItems";
import type { TaskRecord } from "@/types/task";

// taskModes is static UI config (kept as-is)

const taskModes = [
  {
    id: "gateway",
    label: "요청",
    description: "요청을 작업으로 정리",
    icon: Wand2,
    color: "var(--agent-planner)",
  },
  {
    id: "meeting",
    label: "회의/방문 준비",
    description: "고객 미팅 브리핑 생성",
    icon: Calendar,
    color: "var(--agent-market)",
  },
  {
    id: "response",
    label: "고객 대응",
    description: "회신 초안 작성",
    icon: PenLine,
    color: "var(--agent-docs)",
  },
  {
    id: "search",
    label: "문서",
    description: "관련 자료 탐색",
    icon: Search,
    color: "var(--agent-docs)",
  },
  {
    id: "risk",
    label: "리스크",
    description: "납기/품질/가격 리스크",
    icon: ShieldAlert,
    color: "var(--agent-risk)",
  },
  {
    id: "report",
    label: "보고서",
    description: "보고서 초안 작성",
    icon: FileText,
    color: "var(--agent-planner)",
  },
  {
    id: "performance",
    label: "실적/수익성",
    description: "KPI 분석",
    icon: BarChart3,
    color: "var(--agent-sales)",
  },
];



interface HomeCommandCenterProps {
  onModeSelect: (mode: string) => void;
  initialContext?: Record<string, string>;
}

export function HomeCommandCenter({ onModeSelect, initialContext }: HomeCommandCenterProps) {
  const [recentTasks, setRecentTasks] = useState<TaskRecord[]>([]);
  const [allTasks, setAllTasks] = useState<TaskRecord[]>([]);

  const { items: installedItems } = useInstalledItems();
  const installedAgents = installedItems.filter(i => i.item_type === "agent");
  const installedSkills = installedItems.filter(i => i.item_type === "skill");
  const installedMcps = installedItems.filter(i => i.item_type === "mcp");
  const activeInstalledCount = installedItems.filter(i => i.is_active).length;

  useEffect(() => {
    supabase
      .from("tasks")
      .select("*")
      .order("created_at", { ascending: false })
      .then(({ data }) => {
        const tasks = data || [];
        setAllTasks(tasks);
        setRecentTasks(tasks.slice(0, 5));
      });
  }, []);

  // Compute live metrics from tasks
  const pendingCount = allTasks.filter((t) => t.status === "pending").length;
  const riskTasks = allTasks.filter((t) => t.source === "risk" || t.category === "delivery" || t.category === "quality" || t.category === "price");
  const riskCount = riskTasks.length;
  const criticalCount = allTasks.filter((t) => t.severity === "critical" || t.severity === "high").length;
  const completedCount = allTasks.filter((t) => t.status === "done").length;
  const inProgressCount = allTasks.filter((t) => t.status === "in_progress").length;

  // Live briefing from tasks
  const categoryLabelsMap: Record<string, string> = { delivery: "납기", quality: "품질", price: "가격" };
  const briefingHighlights = allTasks.slice(0, 5).map((t) => {
    const cat = categoryLabelsMap[t.category ?? ""] || t.category || "";
    const cust = t.customer || "";
    return `${cust ? cust + " " : ""}${cat ? "[" + cat + "] " : ""}${t.title}`;
  });
  const briefingSummary = allTasks.length > 0
    ? `현재 ${allTasks.length}건의 작업이 등록되어 있으며, ${pendingCount}건이 대기 중입니다.${criticalCount > 0 ? ` 긴급 ${criticalCount}건에 주의가 필요합니다.` : ""}`
    : "현재 등록된 작업이 없습니다. 새로운 업무를 시작해보세요.";

  // Live risk summary from tasks
  const liveRiskSummary = riskTasks
    .sort((a, b) => {
      const order: Record<string, number> = { critical: 0, high: 1, medium: 2, low: 3 };
      return (order[a.severity ?? ""] ?? 4) - (order[b.severity ?? ""] ?? 4);
    })
    .slice(0, 5)
    .map((t) => ({
      label: `${t.customer || ""} ${t.title}`.trim(),
      severity: t.severity || "medium",
    }));

  const liveStats = [
    { label: "전체 작업", value: `${allTasks.length}건`, detail: `진행 ${inProgressCount} · 완료 ${completedCount}`, color: "hsl(var(--primary))" },
    { label: "미결 대응 항목", value: `${pendingCount}건`, detail: `긴급 ${criticalCount}건 포함`, color: pendingCount > 0 ? "hsl(var(--status-review))" : "hsl(var(--status-completed))" },
    { label: "리스크 항목", value: `${riskCount}건`, detail: `심각/높음 ${criticalCount}건`, color: riskCount > 0 ? "hsl(var(--status-alert))" : "hsl(var(--status-completed))" },
  ];
  const dockEntryLabel = initialContext?.entryLabel;
  const suggestedMode = initialContext?.suggestedMode;
  const suggestedTaskLabel = taskModes.find((mode) => mode.id === suggestedMode)?.label;

  return (
    <div className="flex-1 h-full overflow-y-auto p-6 space-y-6 scrollbar-thin">
      {/* Page header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold tracking-tight">홈</h1>
          <p className="text-[13px] text-muted-foreground mt-0.5">오늘의 업무 현황과 빠른 시작</p>
        </div>
        <div className="flex items-center gap-2 text-[11px] text-muted-foreground">
          <Clock className="w-3.5 h-3.5" />
          {new Date().toLocaleDateString("ko-KR", {
            month: "long",
            day: "numeric",
            weekday: "short",
          })}
        </div>
      </div>

      {dockEntryLabel && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-2xl border border-primary/15 bg-primary/5 px-5 py-4 flex items-center justify-between gap-4"
        >
          <div>
            <p className="text-[11px] font-medium text-primary">Ambient Dock에서 진입</p>
            <p className="text-[13px] text-foreground mt-1">
              {dockEntryLabel}에서 넘어왔습니다. 홈에서 다음 작업을 이어갈 수 있습니다.
            </p>
          </div>
          {suggestedMode && suggestedMode !== "home" && (
            <button
              onClick={() => onModeSelect(suggestedMode)}
              className="px-3 py-2 rounded-xl text-[12px] font-semibold whitespace-nowrap"
              style={{ background: "hsl(var(--primary))", color: "hsl(var(--primary-foreground))" }}
            >
              {suggestedTaskLabel || "관련 모드"} 열기
            </button>
          )}
        </motion.div>
      )}

      {/* Top row: Briefing + Risk */}
      <div className="grid grid-cols-3 gap-4">
        {/* Today Briefing - hero card */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="col-span-2 rounded-2xl p-5 bg-primary/5 border border-primary/10"
        >
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="w-4 h-4 text-primary" />
            <h2 className="text-[13px] font-semibold">오늘의 브리핑</h2>
          </div>
          <p className="text-[13px] text-secondary-foreground leading-relaxed mb-3">
            {briefingSummary}
          </p>
          <ul className="space-y-1.5">
            {briefingHighlights.map((item, i) => (
              <li key={i} className="flex items-center gap-2 text-[12px] text-muted-foreground">
                <div className="w-1 h-1 rounded-full bg-primary" />
                {item}
              </li>
            ))}
          </ul>
          <button className="mt-4 flex items-center gap-1.5 text-[11px] font-medium text-primary hover:underline">
            상세 브리핑 보기
            <ArrowRight className="w-3 h-3" />
          </button>
        </motion.div>

        {/* Risk Summary */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="rounded-2xl p-5 bg-status-alert/5 border border-status-alert/10"
        >
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle className="w-4 h-4 text-status-alert" />
            <h2 className="text-[13px] font-semibold">리스크 요약</h2>
          </div>
          <div className="space-y-2.5">
            {liveRiskSummary.length === 0 ? (
              <p className="text-[12px] text-muted-foreground">현재 리스크 항목이 없습니다.</p>
            ) : (
              liveRiskSummary.map((risk, i) => (
                <div key={i} className="flex items-start gap-2">
                  <div
                    className="w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0"
                    style={{
                      background:
                        risk.severity === "critical" || risk.severity === "high"
                          ? "hsl(var(--status-alert))"
                          : "hsl(var(--status-review))",
                    }}
                  />
                  <p className="text-[12px] text-secondary-foreground">{risk.label}</p>
                </div>
              ))
            )}
          </div>
          <button className="mt-4 flex items-center gap-1.5 text-[11px] font-medium text-status-alert hover:underline">
            전체 리스크 보기
            <ArrowRight className="w-3 h-3" />
          </button>
        </motion.div>
      </div>

      {/* Task modes */}
      <section>
        <h2 className="text-[13px] font-semibold mb-3">빠른 시작</h2>
        <div className="grid grid-cols-3 gap-3">
          {taskModes.map((mode, i) => (
            <motion.button
              key={mode.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 + i * 0.05 }}
              whileHover={{ scale: 1.02, y: -2 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => onModeSelect(mode.id)}
              className={`text-left p-4 rounded-2xl bg-secondary/30 border transition-all group ${
                suggestedMode === mode.id
                  ? "border-primary/40 shadow-[0_0_0_1px_hsl(var(--primary)/0.2)]"
                  : "border-border/50 hover:border-border"
              }`}
            >
              <mode.icon className="w-5 h-5 mb-2 text-muted-foreground group-hover:text-foreground transition-colors" />
              <div className="text-[12px] font-medium text-foreground">{mode.label}</div>
              <div className="text-[10px] text-muted-foreground mt-0.5">{mode.description}</div>
              {suggestedMode === mode.id && (
                <div className="mt-2 text-[10px] font-medium text-primary">도크에서 추천된 이어가기</div>
              )}
            </motion.button>
          ))}
        </div>
      </section>

      {/* Installed Items Widget */}
      {installedItems.length > 0 && (
        <section>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Package className="w-4 h-4 text-primary" />
              <h2 className="text-[13px] font-semibold">내 설치 항목</h2>
              <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-primary/10 text-primary font-medium">
                {activeInstalledCount}/{installedItems.length} 활성
              </span>
            </div>
            <button onClick={() => onModeSelect("my-installations")}
              className="flex items-center gap-1 text-[10px] font-medium text-primary hover:underline">
              전체 관리 <ArrowRight className="w-3 h-3" />
            </button>
          </div>
          <div className="grid grid-cols-3 gap-3">
            {[
              { label: "에이전트", items: installedAgents, icon: Bot, color: "hsl(var(--primary))" },
              { label: "스킬", items: installedSkills, icon: Zap, color: "hsl(var(--status-review))" },
              { label: "MCP", items: installedMcps, icon: Server, color: "hsl(var(--status-completed))" },
            ].map((cat, i) => (
              <motion.div key={cat.label}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 + i * 0.05 }}
                className="rounded-xl p-3 bg-secondary/20 border border-border/30">
                <div className="flex items-center gap-2 mb-2">
                  <cat.icon className="w-4 h-4" style={{ color: cat.color }} />
                  <span className="text-[11px] font-medium text-foreground">{cat.label}</span>
                </div>
                {cat.items.length === 0 ? (
                  <p className="text-[10px] text-muted-foreground">없음</p>
                ) : (
                  <div className="space-y-1">
                    {cat.items.slice(0, 3).map(item => (
                      <div key={item.id} className="flex items-center gap-1.5">
                        <div className={`w-1.5 h-1.5 rounded-full ${item.is_active ? "bg-emerald-500" : "bg-muted-foreground/30"}`} />
                        <span className="text-[10px] text-foreground/80 truncate">{item.item_name}</span>
                      </div>
                    ))}
                    {cat.items.length > 3 && (
                      <p className="text-[9px] text-muted-foreground">+{cat.items.length - 3}개 더</p>
                    )}
                  </div>
                )}
              </motion.div>
            ))}
          </div>
        </section>
      )}

      {/* Recent Tasks Widget */}
      {recentTasks.length > 0 && (
        <section>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <CheckSquare className="w-4 h-4 text-primary" />
              <h2 className="text-[13px] font-semibold">최근 작업</h2>
            </div>
            <button
              onClick={() => onModeSelect("tasks")}
              className="flex items-center gap-1 text-[10px] font-medium text-primary hover:underline"
            >
              전체 보기 <ArrowRight className="w-3 h-3" />
            </button>
          </div>
          <div className="space-y-1.5">
            {recentTasks.map((task, i) => {
              const sevColors: Record<string, string> = {
                critical: "bg-red-400", high: "bg-orange-400", medium: "bg-yellow-400", low: "bg-green-400",
              };
              const statusLabels: Record<string, string> = {
                pending: "대기", in_progress: "진행 중", done: "완료",
              };
              return (
                <motion.div
                  key={task.id}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 + i * 0.04 }}
                  onClick={() => onModeSelect("tasks")}
                  className="flex items-center justify-between p-3 rounded-xl bg-secondary/20 border border-border/30 hover:border-border/60 transition-colors cursor-pointer"
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-2 h-2 rounded-full flex-shrink-0 ${sevColors[task.severity ?? ""] || "bg-muted-foreground/30"}`} />
                    <div>
                      <p className="text-[12px] text-foreground">{task.title}</p>
                      <p className="text-[10px] text-muted-foreground mt-0.5">
                        {task.customer || "미지정"} · {statusLabels[task.status] || task.status} · {new Date(task.created_at).toLocaleDateString("ko-KR")}
                      </p>
                    </div>
                  </div>
                  <ArrowRight className="w-3.5 h-3.5 text-muted-foreground" />
                </motion.div>
              );
            })}
          </div>
        </section>
      )}

      {/* Open items — from DB */}
      {(() => {
        const openTasks = allTasks.filter((t) => t.status === "pending" || t.status === "in_progress");
        if (openTasks.length === 0) return null;
        const statusMap: Record<string, { label: string; color: string }> = {
          pending: { label: "대기", color: "hsl(var(--status-review))" },
          in_progress: { label: "진행 중", color: "hsl(var(--status-active))" },
        };
        const timeAgo = (d: string) => {
          const diff = Date.now() - new Date(d).getTime();
          const h = Math.floor(diff / 3600000);
          if (h < 1) return "방금 전";
          if (h < 24) return `${h}시간 전`;
          return `${Math.floor(h / 24)}일 전`;
        };
        return (
          <section>
            <h2 className="text-[13px] font-semibold mb-3">진행 중인 작업</h2>
            <div className="space-y-2">
              {openTasks.slice(0, 5).map((task, i) => {
                const st = statusMap[task.status] || statusMap.pending;
                return (
                  <motion.div
                    key={task.id}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.3 + i * 0.05 }}
                    onClick={() => onModeSelect("tasks")}
                    className="flex items-center justify-between p-3 rounded-xl bg-secondary/20 border border-border/30 hover:border-border/60 transition-colors cursor-pointer"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: st.color }} />
                      <div>
                        <p className="text-[12px] text-foreground">{task.title}</p>
                        <p className="text-[10px] text-muted-foreground mt-0.5">
                          {task.customer || "미지정"} · {st.label} · {timeAgo(task.created_at)}
                        </p>
                      </div>
                    </div>
                    <ArrowRight className="w-3.5 h-3.5 text-muted-foreground" />
                  </motion.div>
                );
              })}
            </div>
          </section>
        );
      })()}

      {/* Quick stats — live from DB */}
      <section>
        <h2 className="text-[13px] font-semibold mb-3">주요 지표</h2>
        <div className="grid grid-cols-3 gap-3">
          {liveStats.map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 + i * 0.05 }}
              className="p-4 rounded-2xl bg-secondary/20 border border-border/30"
            >
              <p className="text-[10px] text-muted-foreground">{stat.label}</p>
              <p className="text-lg font-semibold mt-1 font-mono" style={{ color: stat.color }}>{stat.value}</p>
              <p className="text-[10px] text-muted-foreground mt-1">{stat.detail}</p>
            </motion.div>
          ))}
        </div>
      </section>

      {/* KPI Charts */}
      <KpiCharts tasks={allTasks} />

      {/* Customer Activity Timeline */}
      <section>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-primary" />
            <h2 className="text-[13px] font-semibold">고객별 최근 활동</h2>
          </div>
          <button
            onClick={() => onModeSelect("customers")}
            className="flex items-center gap-1 text-[10px] font-medium text-primary hover:underline"
          >
            전체 고객 보기 <ArrowRight className="w-3 h-3" />
          </button>
        </div>
        {(() => {
          // Group tasks by customer
          const customerMap = new Map<string, TaskRecord[]>();
          allTasks.forEach((t) => {
            const name = t.customer || "미지정";
            if (!customerMap.has(name)) customerMap.set(name, []);
            customerMap.get(name)!.push(t);
          });

          const customers = Array.from(customerMap.entries())
            .map(([name, tasks]) => ({
              name,
              tasks: tasks.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()),
              latestAt: new Date(tasks[0].created_at),
            }))
            .sort((a, b) => b.latestAt.getTime() - a.latestAt.getTime())
            .slice(0, 5);

          if (customers.length === 0) {
            return (
              <p className="text-[12px] text-muted-foreground py-4 text-center">등록된 고객 활동이 없습니다.</p>
            );
          }

          const sevColors: Record<string, string> = {
            critical: "hsl(var(--status-alert))",
            high: "hsl(var(--status-review))",
            medium: "hsl(var(--status-review))",
            low: "hsl(var(--status-completed))",
          };
          const statusLabels: Record<string, string> = {
            pending: "대기",
            in_progress: "진행 중",
            done: "완료",
          };
          const categoryLabels: Record<string, string> = {
            delivery: "납기",
            quality: "품질",
            price: "가격",
          };

          return (
            <div className="space-y-4">
              {customers.map((customer, ci) => (
                <motion.div
                  key={customer.name}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5 + ci * 0.06 }}
                  className="rounded-xl bg-secondary/20 border border-border/30 p-4"
                >
                  {/* Customer header */}
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center text-[10px] font-bold text-primary">
                        {customer.name.charAt(0)}
                      </div>
                      <span className="text-[12px] font-medium text-foreground">{customer.name}</span>
                      <span className="text-[10px] text-muted-foreground">· {customer.tasks.length}건</span>
                    </div>
                    <span className="text-[10px] text-muted-foreground">
                      최근 {customer.latestAt.toLocaleDateString("ko-KR", { month: "short", day: "numeric" })}
                    </span>
                  </div>

                  {/* Timeline items */}
                  <div className="relative pl-4 border-l border-border/40 space-y-2.5">
                    {customer.tasks.slice(0, 3).map((task) => (
                      <div key={task.id} className="relative">
                        <div
                          className="absolute -left-[21px] top-1 w-2.5 h-2.5 rounded-full border-2 border-background"
                          style={{ background: sevColors[task.severity ?? ""] || "hsl(var(--muted-foreground))" }}
                        />
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <p className="text-[11px] text-foreground leading-snug">{task.title}</p>
                            <div className="flex items-center gap-1.5 mt-0.5">
                              {task.category && (
                                <span className="text-[9px] px-1.5 py-0.5 rounded bg-muted/50 text-muted-foreground">
                                  {categoryLabels[task.category] || task.category}
                                </span>
                              )}
                              <span className="text-[9px] text-muted-foreground">
                                {statusLabels[task.status] || task.status}
                              </span>
                            </div>
                          </div>
                          <span className="text-[9px] text-muted-foreground whitespace-nowrap mt-0.5">
                            {new Date(task.created_at).toLocaleDateString("ko-KR", { month: "numeric", day: "numeric" })}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </motion.div>
              ))}
            </div>
          );
        })()}
      </section>
    </div>
  );
}
