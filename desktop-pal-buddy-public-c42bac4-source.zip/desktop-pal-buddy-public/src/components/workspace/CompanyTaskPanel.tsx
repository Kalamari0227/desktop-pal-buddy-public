import { useEffect, useMemo, useRef, useState } from "react";
import { z } from "zod";
import {
  REGISTERED_SKILLS,
  actionIntentSchema,
  assessmentEvidenceSchema,
  approvalSchema,
  canonicalizeActionIntentDigestInput,
  canonicalizeReadSetDigestInput,
  companyStateSchema,
  executionSchema,
  experienceDraftSchema,
  learningAssetVersionSchema,
  learningProvenanceSchema,
  learningPreviewSchema,
  learningWithdrawalSchema,
  readbackEvidenceSchema,
  runtimeTaskRecordSchema,
  type CompanyState,
  type ObjectKind,
} from "@/lib/company-runtime";
import type { ExperienceDraft, ExperienceDraftSaveResult, ExperienceSource } from "@/lib/company-runtime/experience";
import type {
  LearningPreviewResult,
  LearningProvenance,
  LearningPublishResult,
  LearningWithdrawResult,
} from "@/lib/company-runtime/learning";
import type { CompanyRuntimeTaskView } from "@/lib/company-runtime/projection";
import {
  companyRuntimeClient,
  resultExplanationPayloadSchema,
  type CompanyRuntimeClient,
  type CompanyRuntimeResponse,
} from "@/lib/companyRuntimeClient";
import { useCompanyRuntime } from "@/hooks/useCompanyRuntime";
import { Button } from "@/components/ui/button";
import { ExperiencePanel } from "./ExperiencePanel";

const runtimeStatusSchema = z.object({
  epoch: z.string().uuid(),
  actorId: z.enum(["sales-demo", "production-demo", "management-demo"]),
  role: z.enum(["sales", "production", "management"]),
  actorSessionRevision: z.number().int().nonnegative(),
  stopped: z.boolean(),
}).strict();

const detailSnapshotSchema = z.object({
  currentEpoch: z.string().uuid(),
  stopped: z.boolean(),
  current: companyStateSchema,
  records: z.object({
    tasks: z.array(runtimeTaskRecordSchema),
    actionIntents: z.array(actionIntentSchema),
    approvals: z.array(approvalSchema),
    executions: z.array(executionSchema),
    readbackEvidence: z.array(readbackEvidenceSchema),
    assessmentEvidence: z.array(assessmentEvidenceSchema).default([]),
    experienceDrafts: z.array(experienceDraftSchema).default([]),
    learningProvenance: z.array(learningProvenanceSchema).default([]),
  }).passthrough(),
}).passthrough();

type RuntimeDetail = {
  readonly task: z.infer<typeof runtimeTaskRecordSchema>;
  readonly intent: z.infer<typeof actionIntentSchema> | null;
  readonly approval: z.infer<typeof approvalSchema> | null;
  readonly execution: z.infer<typeof executionSchema> | null;
  readonly readback: z.infer<typeof readbackEvidenceSchema> | null;
  readonly assessment: z.infer<typeof assessmentEvidenceSchema> | null;
  readonly strategyVersion: number | null;
  readonly skillPolicyVersion: string | null;
  readonly displacedPlanIds: readonly string[];
  readonly state: CompanyState;
  readonly experienceDrafts: readonly ExperienceDraft[];
  readonly learningProvenance: readonly LearningProvenance[];
};

interface CompanyTaskPanelProps {
  readonly task: CompanyRuntimeTaskView;
  readonly client?: CompanyRuntimeClient;
}

function detailFromSnapshot(
  snapshotValue: unknown,
  taskView: CompanyRuntimeTaskView,
): RuntimeDetail | null {
  const parsed = detailSnapshotSchema.safeParse(snapshotValue);
  if (!parsed.success || parsed.data.currentEpoch !== taskView.epoch) return null;
  const task = parsed.data.records.tasks.find((candidate) =>
    candidate.workboardTaskId === taskView.sourceId
    && candidate.packetTaskId === taskView.packetTaskId
    && candidate.epoch === taskView.epoch);
  if (!task) return null;
  const intent = task.currentProposal
    ? parsed.data.records.actionIntents.find((candidate) =>
      candidate.id === task.currentProposal?.intentId
      && candidate.revision === task.currentProposal.revision
      && candidate.proposalDigest === task.currentProposal.proposalDigest
      && candidate.workboardTaskId === task.workboardTaskId
      && candidate.packetTaskId === task.packetTaskId
      && candidate.epoch === task.epoch) ?? null
    : null;
  const approval = task.currentApprovalId
    ? parsed.data.records.approvals.find((candidate) => candidate.id === task.currentApprovalId) ?? null
    : null;
  const storedExecution = task.executionId
    ? parsed.data.records.executions.find((candidate) => candidate.id === task.executionId) ?? null
    : null;
  const targetVersion = intent?.readSet.find((reference) =>
    reference.kind === "production_plan" && reference.id === intent.targetPlanId)?.version;
  const execution = storedExecution
    && intent
    && approval
    && targetVersion !== undefined
    && storedExecution.id === approval.consumedByExecutionId
    && storedExecution.intentId === intent.id
    && storedExecution.epoch === intent.epoch
    && storedExecution.approvalId === approval.id
    && storedExecution.idempotencyKey === `${intent.epoch}:${intent.id}:${intent.proposalDigest}`
    && storedExecution.mode === "apply"
    && storedExecution.before.priority === intent.fromPriority
    && storedExecution.before.version === targetVersion
    && storedExecution.expectedAfter.priority === intent.toPriority
    && storedExecution.expectedAfter.version === targetVersion + 1
    && ["applied_pending_readback", "verified", "verification_required"].includes(storedExecution.state)
    ? storedExecution
    : null;
  const storedReadback = execution
    ? parsed.data.records.readbackEvidence.find((candidate) => candidate.executionId === execution.id) ?? null
    : null;
  const readback = storedReadback
    && intent
    && storedReadback.targetPlanId === intent.targetPlanId
    && storedReadback.epoch === intent.epoch
    && storedReadback.expectedPriority === execution?.expectedAfter.priority
    && storedReadback.expectedVersion === execution.expectedAfter.version
    ? storedReadback
    : null;
  const assessment = parsed.data.records.assessmentEvidence.find((candidate) =>
    candidate.packetTaskId === task.packetTaskId
    && candidate.epoch === task.epoch) ?? null;
  const strategy = intent
    ? parsed.data.current.strategyVersions.find((candidate) =>
      candidate.strategy_id === intent.strategyRef.strategy_id
      && candidate.strategy_version_id === intent.strategyRef.strategy_version_id)
    : null;
  const skill = intent
    ? parsed.data.current.skills.find((candidate) =>
      candidate.id === intent.skillRef.id && candidate.version === intent.skillRef.version)
    : null;
  const target = intent
    ? parsed.data.current.productionPlans.find((candidate) => candidate.id === intent.targetPlanId)
    : null;
  const groupPlans = target
    ? parsed.data.current.productionPlans.filter((candidate) => candidate.productionGroupId === target.productionGroupId)
    : [];
  const order = (priority: number) => groupPlans
    .map((candidate) => candidate.id === intent?.targetPlanId ? { ...candidate, priority } : candidate)
    .sort((left, right) => left.priority - right.priority || left.id.localeCompare(right.id))
    .map((candidate) => candidate.id);
  const beforeOrder = intent ? order(intent.fromPriority) : [];
  const proposedOrder = intent ? order(intent.toPriority) : [];
  const displacedPlanIds = groupPlans
    .filter((candidate) => candidate.id !== intent?.targetPlanId
      && proposedOrder.indexOf(candidate.id) > beforeOrder.indexOf(candidate.id))
    .sort((left, right) => proposedOrder.indexOf(left.id) - proposedOrder.indexOf(right.id))
    .map((candidate) => candidate.id);
  return {
    task,
    intent,
    approval,
    execution,
    readback,
    assessment,
    strategyVersion: strategy?.version ?? null,
    skillPolicyVersion: skill?.policyVersion ?? null,
    displacedPlanIds,
    state: parsed.data.current,
    experienceDrafts: parsed.data.records.experienceDrafts,
    learningProvenance: parsed.data.records.learningProvenance,
  };
}

function shortDigest(value: string): string {
  return `${value.slice(0, 12)}…${value.slice(-8)}`;
}

function approvalIsUnexpired(expiresAt: string): boolean {
  const expiry = Date.parse(expiresAt);
  return Number.isFinite(expiry) && expiry > Date.now();
}

function displayOperationError(response: CompanyRuntimeResponse): string | null {
  return response.ok ? null : `${response.error.code}: ${response.error.message}`;
}

function objectVersion(state: CompanyState, kind: ObjectKind, id: string): number | undefined {
  switch (kind) {
    case "customer": return state.customers.find((item) => item.id === id)?.version;
    case "sales_opportunity": return state.salesOpportunities.find((item) => item.id === id)?.version;
    case "quote": return state.quotes.find((item) => item.id === id)?.version;
    case "sales_order": return state.salesOrders.find((item) => item.id === id)?.version;
    case "inventory": return state.inventory.find((item) => item.id === id)?.version;
    case "production_plan": return state.productionPlans.find((item) => item.id === id)?.version;
    case "inspection": return state.inspections.find((item) => item.id === id)?.version;
    case "shipment": return state.shipments.find((item) => item.id === id)?.version;
  }
}

function experienceSources(detail: RuntimeDetail): readonly ExperienceSource[] {
  if (!detail.intent) return [];
  const targetSource = detail.intent.readSet.find((reference) =>
    reference.kind === "production_plan" && reference.id === detail.intent?.targetPlanId);
  if (!targetSource) return [];
  const workItem = {
    workboardTaskId: detail.task.workboardTaskId,
    packetTaskId: detail.task.packetTaskId,
  };
  const asset = { id: targetSource.id, version: targetSource.version };
  const sources: ExperienceSource[] = detail.intent.evidenceRefs.map((evidenceId) => ({
    evidenceId,
    kind: "work_fact",
    workItem,
    asset,
  }));
  if (detail.readback && detail.execution) {
    sources.push({
      evidenceId: `readback:${detail.execution.id}`,
      kind: "readback",
      workItem,
      asset: { id: detail.readback.targetPlanId, version: detail.readback.observedVersion },
    });
  }
  return sources;
}

async function sha256(value: string): Promise<string> {
  const bytes = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(value));
  return Array.from(new Uint8Array(bytes), (byte) => byte.toString(16).padStart(2, "0")).join("");
}

export function CompanyTaskPanel({ task, client = companyRuntimeClient }: CompanyTaskPanelProps) {
  const runtime = useCompanyRuntime(client);
  const [pendingAction, setPendingAction] = useState<"approve" | "execute" | null>(null);
  const [operationError, setOperationError] = useState<string | null>(null);
  const [explanation, setExplanation] = useState<z.infer<typeof resultExplanationPayloadSchema> | null>(null);
  const [explanationState, setExplanationState] = useState<"idle" | "pending" | "error">("idle");
  const explanationRequest = useRef(0);
  const explainingTask = useRef<string | null>(null);
  const [authorityProof, setAuthorityProof] = useState<{ proposal: boolean; approval: boolean }>({ proposal: false, approval: false });
  const [, invalidateApprovalExpiry] = useState(0);
  const detail = useMemo(() => detailFromSnapshot(runtime.snapshot, task), [runtime.snapshot, task]);
  const status = runtimeStatusSchema.safeParse(runtime.status);
  const sources = useMemo(() => detail ? experienceSources(detail) : [], [detail]);
  const isProduction = status.success && status.data.role === "production";
  const stopped = status.success ? status.data.stopped : true;
  const approvalId = detail?.approval?.id;
  const approvalExpiresAt = detail?.approval?.expiresAt;
  useEffect(() => {
    if (!approvalId || !approvalExpiresAt) return;
    let timerId: number | undefined;
    const scheduleExpiry = () => {
      const remaining = Date.parse(approvalExpiresAt) - Date.now();
      if (!Number.isFinite(remaining) || remaining <= 0) {
        invalidateApprovalExpiry((value) => value + 1);
        return;
      }
      timerId = window.setTimeout(scheduleExpiry, Math.min(remaining, 2_147_483_647));
    };
    scheduleExpiry();
    return () => {
      if (timerId !== undefined) window.clearTimeout(timerId);
    };
  }, [approvalExpiresAt, approvalId]);
  useEffect(() => {
    let active = true;
    setAuthorityProof({ proposal: false, approval: false });
    if (!detail?.intent || detail.execution) return () => { active = false; };
    const { intent, approval, state: currentState } = detail;
    void Promise.all([
      sha256(canonicalizeActionIntentDigestInput(intent)),
      sha256(canonicalizeReadSetDigestInput(intent.readSet)),
    ]).then(([proposalDigest, readSetDigest]) => {
      if (!active) return;
      const registeredSkill = REGISTERED_SKILLS.find((candidate) =>
        candidate.id === intent.skillRef.id && candidate.version === intent.skillRef.version);
      const storedSkill = currentState.skills.find((candidate) =>
        candidate.id === intent.skillRef.id && candidate.version === intent.skillRef.version);
      const target = currentState.productionPlans.find((candidate) => candidate.id === intent.targetPlanId);
      const pinnedStrategy = currentState.strategyVersions.find((candidate) =>
        candidate.strategy_id === intent.strategyRef.strategy_id
        && candidate.strategy_version_id === intent.strategyRef.strategy_version_id);
      const proposal = proposalDigest === intent.proposalDigest
        && intent.epoch === currentState.currentEpoch
        && intent.requesterActorId === "sales-demo"
        && pinnedStrategy !== undefined
        && registeredSkill !== undefined
        && storedSkill !== undefined
        && JSON.stringify(registeredSkill) === JSON.stringify(storedSkill)
        && registeredSkill.id === "change-production-priority"
        && registeredSkill.policyVersion === intent.policyVersion
        && target?.priority === intent.fromPriority
        && intent.readSet.every((reference) => objectVersion(currentState, reference.kind, reference.id) === reference.version);
      const exactApproval = Boolean(approval
        && approval.id === detail.task.currentApprovalId
        && approval.decision === "approved"
        && approval.intentId === intent.id
        && approval.intentRevision === intent.revision
        && approval.proposalDigest === intent.proposalDigest
        && approval.epoch === intent.epoch
        && approval.readSetDigest === readSetDigest
        && approval.policyVersion === intent.policyVersion
        && approval.skillRef.id === intent.skillRef.id
        && approval.skillRef.version === intent.skillRef.version
        && approval.strategyRef.strategy_id === intent.strategyRef.strategy_id
        && approval.strategyRef.strategy_version_id === intent.strategyRef.strategy_version_id
        && approval.requesterActorId === intent.requesterActorId
        && approval.approverActorId === "production-demo"
        && approvalIsUnexpired(approval.expiresAt)
        && approval.consumedByExecutionId === null);
      setAuthorityProof({ proposal, approval: proposal && exactApproval });
    }).catch(() => {
      if (active) setAuthorityProof({ proposal: false, approval: false });
    });
    return () => { active = false; };
  }, [detail]);
  const approvalExpired = Boolean(detail?.approval && !approvalIsUnexpired(detail.approval.expiresAt));
  const canApprove = Boolean(detail?.intent && !detail.approval && authorityProof.proposal && isProduction && !stopped && pendingAction === null && !detail.execution);
  const canExecute = Boolean(authorityProof.approval && !approvalExpired && isProduction && !stopped && pendingAction === null && !detail?.execution);
  const readbackVerified = Boolean(
    detail?.execution?.state === "verified"
    && detail.readback?.matches
    && detail.readback.expectedPriority === detail.readback.observedPriority
    && detail.readback.expectedVersion === detail.readback.observedVersion,
  );
  const displayedTaskStatus = detail?.assessment?.finding ?? (detail?.task.status === "done" && !readbackVerified
    ? "verification_required"
    : detail?.task.status);

  useEffect(() => {
    explanationRequest.current += 1;
    setExplanation(null);
    setExplanationState("idle");
    return () => {
      if (explainingTask.current === task.sourceId) {
        explanationRequest.current += 1;
        explainingTask.current = null;
        void client.cancel();
      }
    };
  }, [client, task.sourceId]);

  const run = async (action: "approve" | "execute") => {
    if (!detail) return;
    if ((action === "approve" && !canApprove) || (action === "execute" && !canExecute)) return;
    if (action === "execute" && (!detail.approval || !approvalIsUnexpired(detail.approval.expiresAt))) return;
    setPendingAction(action);
    setOperationError(null);
    const response = action === "approve"
      ? await client.approve({ workboardTaskId: task.sourceId, decision: "approved" })
      : await client.execute({
        workboardTaskId: task.sourceId,
        ...(detail.approval ? { approvalId: detail.approval.id } : {}),
      });
    setOperationError(displayOperationError(response));
    setPendingAction(null);
  };

  const explainVerifiedResult = async () => {
    if (explanationState === "pending") {
      explanationRequest.current += 1;
      explainingTask.current = null;
      setExplanationState("idle");
      await client.cancel();
      return;
    }
    if (!readbackVerified || !client.explainResult) return;
    const request = explanationRequest.current + 1;
    explanationRequest.current = request;
    explainingTask.current = task.sourceId;
    setExplanationState("pending");
    const response = await client.explainResult({ workboardTaskId: task.sourceId });
    if (explanationRequest.current !== request || explainingTask.current !== task.sourceId) return;
    explainingTask.current = null;
    if (!response.ok) {
      setExplanationState("error");
      return;
    }
    const parsed = resultExplanationPayloadSchema.safeParse(response.payload);
    if (!parsed.success) {
      setExplanationState("error");
      return;
    }
    setExplanation(parsed.data);
    setExplanationState("idle");
  };

  const saveExperienceDraft = async (draft: unknown): Promise<ExperienceDraftSaveResult> => {
    if (!client.saveExperienceDraft) return { ok: false, code: "invalid_input", persistedCount: detail?.experienceDrafts.length ?? 0 };
    const response = await client.saveExperienceDraft({ workboardTaskId: task.sourceId, draft });
    if (!response.ok) return { ok: false, code: "invalid_input", persistedCount: detail?.experienceDrafts.length ?? 0 };
    const parsed = experienceDraftSchema.safeParse(response.payload);
    if (!parsed.success) return { ok: false, code: "invalid_input", persistedCount: detail?.experienceDrafts.length ?? 0 };
    return { ok: true, draft: parsed.data, persistedCount: (detail?.experienceDrafts.length ?? 0) + 1 };
  };

  const previewLearning = async (input: unknown): Promise<LearningPreviewResult> => {
    if (!client.learning) return { ok: false, code: "invalid_input" };
    const parsedInput = z.object({
      actorId: z.enum(["sales-demo", "production-demo", "management-demo"]),
      draftId: z.string().trim().min(1),
      exactPublishableSentence: z.string().trim().min(1),
      applicability: z.array(z.string().trim().min(1)).min(1),
      targetDepartments: z.array(z.enum(["sales", "production", "management"])).min(1),
      includeManagementStrategyReview: z.boolean(),
    }).strict().safeParse(input);
    if (!parsedInput.success) return { ok: false, code: "invalid_input" };
    const { actorId: _actorId, ...request } = parsedInput.data;
    const response = await client.learning({ action: "preview", ...request });
    if (!response.ok) return { ok: false, code: response.error.message === "author_required" ? "author_required" : "invalid_input" };
    const preview = learningPreviewSchema.safeParse(response.payload);
    return preview.success ? { ok: true, preview: preview.data } : { ok: false, code: "invalid_input" };
  };

  const publishLearning = async (input: unknown): Promise<LearningPublishResult> => {
    if (!client.learning) return { ok: false, code: "invalid_input" };
    const parsedInput = z.object({
      actorId: z.enum(["sales-demo", "production-demo", "management-demo"]),
      preview: learningPreviewSchema,
      consentGranted: z.literal(true),
    }).strict().safeParse(input);
    if (!parsedInput.success) return { ok: false, code: "invalid_input" };
    const response = await client.learning({
      action: "publish",
      preview: parsedInput.data.preview,
      consentGranted: parsedInput.data.consentGranted,
    });
    if (!response.ok) return { ok: false, code: response.error.message === "author_required" ? "author_required" : "invalid_input" };
    const asset = learningAssetVersionSchema.safeParse(response.payload);
    return asset.success ? { ok: true, asset: asset.data } : { ok: false, code: "invalid_input" };
  };

  const withdrawLearning = async (input: unknown): Promise<LearningWithdrawResult> => {
    if (!client.learning) return { ok: false, code: "invalid_input" };
    const parsedInput = z.object({
      actorId: z.enum(["sales-demo", "production-demo", "management-demo"]),
      assetId: z.string().trim().min(1),
      version: z.number().int().positive(),
    }).strict().safeParse(input);
    if (!parsedInput.success) return { ok: false, code: "invalid_input" };
    const response = await client.learning({
      action: "withdraw",
      assetId: parsedInput.data.assetId,
      version: parsedInput.data.version,
    });
    if (!response.ok) return { ok: false, code: response.error.message === "author_required" ? "author_required" : "invalid_input" };
    const withdrawal = learningWithdrawalSchema.safeParse(response.payload);
    return withdrawal.success ? { ok: true, withdrawal: withdrawal.data } : { ok: false, code: "invalid_input" };
  };

  if (!detail) {
    return (
      <section aria-label="런타임 소유 작업 상세" className="rounded-xl border border-primary/20 bg-primary/5 p-4">
        <h3 className="text-[13px] font-semibold">가상 ERP 런타임 작업</h3>
        <p className="mt-2 text-[10px] text-muted-foreground">런타임 소유 · 읽기 전용</p>
        <p className="mt-2 text-[11px] text-muted-foreground">런타임 상세를 신뢰할 수 있게 읽지 못했습니다.</p>
        <p className="mt-2 text-[10px] text-muted-foreground">사업 결과 미관찰</p>
      </section>
    );
  }

  return (
    <section aria-label="런타임 소유 작업 상세" className="space-y-4 rounded-xl border border-primary/20 bg-primary/5 p-4">
      <div>
        <h3 className="text-[13px] font-semibold">가상 ERP 런타임 작업</h3>
        <p className="mt-1 text-[12px] font-medium text-foreground">{task.title}</p>
        <div className="mt-2 flex flex-wrap gap-1.5 text-[10px]">
          <span className="rounded-md border border-primary/20 bg-primary/10 px-2 py-1 text-primary">
            {detail.assessment ? "런타임 소유 · 읽기 전용" : "런타임 소유 · 승인된 명령만 실행"}
          </span>
          <span className="rounded-md border border-border/40 bg-background/70 px-2 py-1">{displayedTaskStatus}</span>
          {stopped && <span className="rounded-md border border-primary/30 bg-primary/10 px-2 py-1 text-primary">정지됨</span>}
        </div>
      </div>

      {detail.assessment ? (
        <div aria-label="생산 준비 검토 근거" className="space-y-3 rounded-lg border border-primary/20 bg-background/70 p-3 text-[11px]">
          <div>
            <h4 className="font-semibold">생산 준비 검토 근거</h4>
            <p className="mt-1 text-primary">추가 확인 필요 · {detail.assessment.finding}</p>
          </div>
          <dl className="grid gap-1 text-muted-foreground">
            <div>사용 학습 {detail.assessment.usedAssetRef
              ? `${detail.assessment.usedAssetRef.assetId} · v${detail.assessment.usedAssetRef.version}`
              : "없음"}</div>
            <div>재사용 상태 {detail.assessment.reuse.status}{detail.assessment.reuse.code ? ` · ${detail.assessment.reuse.code}` : ""}</div>
            <div>필수 확인 {detail.assessment.requiredChecks.length > 0 ? detail.assessment.requiredChecks.join(", ") : "기준선"}</div>
          </dl>
          <div>
            <p className="font-medium">추가로 읽은 근거</p>
            {detail.assessment.additionalReadSet.length > 0 ? (
              <ul className="mt-1 space-y-1 text-muted-foreground">
                {detail.assessment.additionalReadSet.map((reference) => (
                  <li key={`${reference.kind}:${reference.id}`}>{reference.kind}/{reference.id} · v{reference.version}</li>
                ))}
              </ul>
            ) : <p className="mt-1 text-muted-foreground">없음 · 기준선 읽기만 수행</p>}
          </div>
          <p className="text-muted-foreground">사업 결과 미관찰 · 준비 검토 완료는 출하 완료를 뜻하지 않습니다.</p>
        </div>
      ) : detail.intent ? (
        <div aria-label="현재 변경 제안" className="space-y-2 rounded-lg border border-border/40 bg-background/50 p-3 text-[11px]">
          <h4 className="font-semibold">현재 변경 제안</h4>
          <p>대상 {detail.intent.targetPlanId} · priority {detail.intent.fromPriority} → {detail.intent.toPriority}</p>
          <p>영향 계획 {detail.displacedPlanIds.length > 0 ? detail.displacedPlanIds.join(", ") : "없음"}</p>
          <dl className="grid gap-1 text-muted-foreground">
            <div>전략 {detail.intent.strategyRef.strategy_id} · v{detail.strategyVersion ?? "?"} · {detail.intent.strategyRef.strategy_version_id}</div>
            <div>스킬 {detail.intent.skillRef.id}@{detail.intent.skillRef.version}</div>
            <div>정책 {detail.intent.policyVersion}{detail.skillPolicyVersion ? ` · 등록 ${detail.skillPolicyVersion}` : ""}</div>
            <div>제안 revision {detail.intent.revision} · digest {shortDigest(detail.intent.proposalDigest)}</div>
          </dl>
          <ul aria-label="제안 readSet" className="space-y-1 text-muted-foreground">
            {detail.intent.readSet.map((reference) => (
              <li key={`${reference.kind}:${reference.id}`}>{reference.kind}/{reference.id} · v{reference.version}</li>
            ))}
          </ul>
        </div>
      ) : (
        <p className="rounded-lg border border-border/40 bg-background/50 p-3 text-[11px] text-muted-foreground">현재 제안 없음</p>
      )}

      {!detail.assessment && <div aria-label="승인 상태" className="rounded-lg border border-border/40 bg-background/50 p-3 text-[11px]">
        <h4 className="font-semibold">사람 승인</h4>
        {detail.approval ? (
          <div className="mt-2 space-y-1 text-muted-foreground">
            <p>{detail.approval.decision} · 승인자 {detail.approval.approverActorId}</p>
            <p>결정 {detail.approval.decidedAt} · 만료 {detail.approval.expiresAt}</p>
            <p>승인 digest {shortDigest(detail.approval.proposalDigest)}</p>
            {approvalExpired && <p className="text-destructive">승인 만료 · 새 제안 또는 명시적 재승인 흐름 필요</p>}
            {!detail.execution && !authorityProof.approval && <p className="text-primary">현재 제안과 승인 범위 불일치</p>}
          </div>
        ) : <p className="mt-2 text-muted-foreground">승인 기록 없음</p>}
        <Button type="button" size="sm" variant="outline" disabled={!canApprove} onClick={() => void run("approve")} className="mt-3 h-8 text-[11px]">
          {pendingAction === "approve" ? "승인 기록 중" : "생산 승인"}
        </Button>
      </div>}

      {!detail.assessment && <div aria-label="실행 및 재조회 증거" className="rounded-lg border border-border/40 bg-background/50 p-3 text-[11px]">
        <h4 className="font-semibold">실행과 원장 재조회</h4>
        {detail.execution ? (
          <div className="mt-2 space-y-1 text-muted-foreground">
            <p>실행 {detail.execution.state} · mode {detail.execution.mode}</p>
            <p>기대 priority/version {detail.execution.expectedAfter.priority}/v{detail.execution.expectedAfter.version}</p>
            {detail.readback ? (
              <p>관찰 priority/version {detail.readback.observedPriority}/v{detail.readback.observedVersion} · {detail.readback.matches ? "일치" : "불일치"} · {detail.readback.readAt}</p>
            ) : <p>재조회 증거 없음 · 완료 확인 불가</p>}
          </div>
        ) : <p className="mt-2 text-muted-foreground">실행 기록 없음</p>}
        <Button type="button" size="sm" disabled={!canExecute} onClick={() => void run("execute")} className="mt-3 h-8 text-[11px]">
          {pendingAction === "execute" ? "적용 중" : "승인된 변경 적용"}
        </Button>
        {readbackVerified && (
          <Button type="button" size="sm" variant="outline" onClick={() => void explainVerifiedResult()} className="ml-2 mt-3 h-8 text-[11px]">
            {explanationState === "pending" ? "설명 취소" : "결과 설명"}
          </Button>
        )}
      </div>}

      {explanation && (
        <section aria-label="확인된 결과 설명" className="space-y-2 rounded-lg border border-primary/20 bg-background/70 p-3 text-[11px]">
          <h4 className="font-semibold">확인된 결과 설명</h4>
          {explanation.runtimeMode === "stub" && !explanation.actualAI && (
            <p className="text-primary">결정론적 Stub · 실제 AI 아님</p>
          )}
          <p>{explanation.explanation.summary}</p>
          <ul aria-label="설명 근거" className="space-y-1 text-muted-foreground">
            {explanation.explanation.citedEvidenceIds.map((evidenceId) => <li key={evidenceId}>{evidenceId}</li>)}
          </ul>
          {explanation.explanation.uncertainties.map((uncertainty) => <p key={uncertainty} className="text-muted-foreground">{uncertainty}</p>)}
          <p className="text-muted-foreground">사업 결과 미확인 · 이 설명은 실행·승인 권한이나 완료 근거가 아닙니다.</p>
        </section>
      )}
      {explanationState === "error" && (
        <p role="alert" className="text-[11px] text-destructive">결과 설명을 완료하지 못했습니다. 확인된 실행·재조회 증거는 그대로 유지됩니다.</p>
      )}

      {!detail.assessment && <div aria-label="사업 결과" className="rounded-lg border border-border/40 bg-background/50 p-3 text-[11px]">
        <h4 className="font-semibold">사업 결과</h4>
        {detail.task.businessOutcome.status === "unobserved" ? (
          <p className="mt-2 text-muted-foreground">사업 결과 미관찰 · 우선순위 변경 완료는 납품 완료를 뜻하지 않습니다.</p>
        ) : (
          <div className="mt-2 space-y-1 text-muted-foreground">
            <p>시뮬레이션 관찰 · observed_simulated</p>
            <p>입력자 {detail.task.businessOutcome.recordedByActorId} · 관찰 시각 {detail.task.businessOutcome.observedAt}</p>
            <p>근거 {detail.task.businessOutcome.evidenceRefs.join(", ")}</p>
          </div>
        )}
      </div>}

      {status.success && !detail.assessment && (
        <ExperiencePanel
          actorId={status.data.actorId}
          workItem={{ workboardTaskId: detail.task.workboardTaskId, packetTaskId: detail.task.packetTaskId }}
          sources={sources}
          persistedDrafts={detail.experienceDrafts}
          saveDraft={saveExperienceDraft}
          previewLearning={previewLearning}
          publishLearning={publishLearning}
          withdrawLearning={withdrawLearning}
          learningProvenance={detail.learningProvenance}
        />
      )}

      {!isProduction && <p className="text-[10px] text-muted-foreground">현재 역할은 승인하거나 적용할 수 없습니다.</p>}
      {(operationError !== null || runtime.state === "error") && (
        <p role="alert" className="text-[11px] text-destructive">{operationError ?? "런타임 요청 실패"}</p>
      )}
      <p className="text-[10px] leading-relaxed text-muted-foreground">AI 설명은 승인·실행·납품 권한이나 완료 근거로 사용되지 않습니다.</p>
    </section>
  );
}
