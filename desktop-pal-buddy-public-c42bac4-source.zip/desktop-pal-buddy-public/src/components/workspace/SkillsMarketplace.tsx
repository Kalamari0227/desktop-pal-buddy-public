import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search, Plus, Star, Download, TrendingUp, X, Loader2,
  MessageSquare, Send, Zap, Puzzle, ArrowRight,
  Trash2, ChevronDown,
} from "lucide-react";
import { toast } from "sonner";
import { useInstalledItems } from "@/hooks/useInstalledItems";
import { createMarketplaceProvider, type MarketplaceReview } from "@/lib/marketplaceProvider";

const marketplaceProvider = createMarketplaceProvider();

interface MarketplaceSkill {
  id: string;
  name: string;
  description: string | null;
  category: string;
  icon: string;
  skill_type: string;
  input_schema: unknown;
  output_schema: unknown;
  implementation: string | null;
  creator_name: string;
  installs: number;
  rating: number;
  tags: string[];
  is_featured: boolean;
  is_composable: boolean;
  created_at: string;
}

const SKILL_CATEGORIES = [
  { id: "all", label: "전체" },
  { id: "transform", label: "데이터 변환" },
  { id: "analysis", label: "분석" },
  { id: "format", label: "포맷팅" },
  { id: "filter", label: "필터링" },
  { id: "enrich", label: "데이터 보강" },
  { id: "validate", label: "검증" },
];

const SKILL_TYPE_LABELS: Record<string, { label: string; color: string }> = {
  transform: { label: "변환", color: "hsl(var(--primary))" },
  analysis: { label: "분석", color: "hsl(var(--status-thinking))" },
  format: { label: "포맷", color: "hsl(var(--status-completed))" },
  filter: { label: "필터", color: "hsl(var(--status-alert))" },
  enrich: { label: "보강", color: "hsl(var(--agent-market))" },
  validate: { label: "검증", color: "hsl(var(--agent-risk))" },
};

export function SkillsMarketplace() {
  const [skills, setSkills] = useState<MarketplaceSkill[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");
  const [selectedSkill, setSelectedSkill] = useState<MarketplaceSkill | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showPluginBuilder, setShowPluginBuilder] = useState(false);
  const { install: installItem } = useInstalledItems();

  useEffect(() => { fetchSkills(); }, []);

  const fetchSkills = async () => {
    setLoading(true);
    try {
      setSkills(await marketplaceProvider.list<MarketplaceSkill>("skill"));
    } catch {
      toast.error("스킬 목록을 불러오는데 실패했습니다");
    }
    setLoading(false);
  };

  const handleInstall = async (skill: MarketplaceSkill) => {
    try {
      await marketplaceProvider.incrementInstalls("skill", skill.id, skill.installs);
      setSkills(prev => prev.map(s => s.id === skill.id ? { ...s, installs: s.installs + 1 } : s));
      await installItem({
        item_id: skill.id,
        item_type: "skill",
        item_name: skill.name,
        item_icon: skill.icon || "Zap",
        item_description: skill.description || undefined,
      });
    } catch {
      toast.error("스킬 설치에 실패했습니다");
    }
  };

  const filtered = skills.filter(s => {
    const matchCat = activeCategory === "all" || s.category === activeCategory || s.skill_type === activeCategory;
    const matchSearch = !searchQuery ||
      s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      s.tags.some(t => t.includes(searchQuery.toLowerCase()));
    return matchCat && matchSearch;
  });

  const featured = skills.filter(s => s.is_featured);

  return (
    <div className="space-y-6">
      {/* Search + Actions */}
      <div className="flex gap-2">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="스킬 검색..."
            className="w-full pl-9 pr-4 py-2.5 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none transition-colors"
          />
        </div>
        <button
          onClick={() => setShowPluginBuilder(true)}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-[12px] font-semibold bg-accent/20 text-accent-foreground border border-border/50 hover:bg-accent/30 transition-colors"
        >
          <Puzzle className="w-3.5 h-3.5" />
          플러그인 빌더
        </button>
        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-[12px] font-semibold transition-colors"
          style={{ background: "hsl(var(--primary))", color: "hsl(var(--primary-foreground))" }}
        >
          <Plus className="w-3.5 h-3.5" />
          스킬 만들기
        </button>
      </div>

      {/* Categories */}
      <div className="flex gap-1.5 overflow-x-auto scrollbar-none">
        {SKILL_CATEGORIES.map(cat => (
          <button
            key={cat.id}
            onClick={() => setActiveCategory(cat.id)}
            className={`px-3 py-1.5 rounded-lg text-[11px] font-medium whitespace-nowrap transition-colors ${
              activeCategory === cat.id ? "bg-primary/15 text-primary" : "text-muted-foreground hover:bg-secondary"
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
        </div>
      ) : (
        <>
          {activeCategory === "all" && featured.length > 0 && !searchQuery && (
            <section>
              <div className="flex items-center gap-2 mb-3">
                <TrendingUp className="w-3.5 h-3.5 text-primary" />
                <h2 className="text-[12px] font-semibold text-foreground">추천 스킬</h2>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {featured.slice(0, 4).map(skill => (
                  <SkillCard key={skill.id} skill={skill} onInstall={handleInstall} onSelect={setSelectedSkill} featured />
                ))}
              </div>
            </section>
          )}

          <section>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-[12px] font-semibold text-foreground">
                {activeCategory === "all" ? "모든 스킬" : SKILL_CATEGORIES.find(c => c.id === activeCategory)?.label}
                <span className="text-muted-foreground font-normal ml-1.5">({filtered.length})</span>
              </h2>
            </div>
            {filtered.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-[12px] text-muted-foreground">검색 결과가 없습니다</p>
                <button onClick={() => setShowCreateModal(true)} className="mt-2 text-[11px] text-primary hover:underline">
                  직접 스킬을 만들어보세요
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-3">
                {filtered.map(skill => (
                  <SkillCard key={skill.id} skill={skill} onInstall={handleInstall} onSelect={setSelectedSkill} />
                ))}
              </div>
            )}
          </section>
        </>
      )}

      {/* Modals */}
      <AnimatePresence>
        {selectedSkill && (
          <SkillDetailModal skill={selectedSkill} onClose={() => setSelectedSkill(null)} onInstall={handleInstall} />
        )}
      </AnimatePresence>
      <AnimatePresence>
        {showCreateModal && (
          <CreateSkillModal onClose={() => setShowCreateModal(false)} onCreated={() => { setShowCreateModal(false); fetchSkills(); }} />
        )}
      </AnimatePresence>
      <AnimatePresence>
        {showPluginBuilder && (
          <PluginBuilderModal skills={skills} onClose={() => setShowPluginBuilder(false)} />
        )}
      </AnimatePresence>
    </div>
  );
}

/* ─── Skill Card ─── */
function SkillCard({ skill, onInstall, onSelect, featured }: {
  skill: MarketplaceSkill; onInstall: (s: MarketplaceSkill) => void; onSelect: (s: MarketplaceSkill) => void; featured?: boolean;
}) {
  const typeInfo = SKILL_TYPE_LABELS[skill.skill_type] || { label: skill.skill_type, color: "hsl(var(--muted-foreground))" };

  return (
    <motion.div
      whileHover={{ y: -2 }}
      onClick={() => onSelect(skill)}
      className={`rounded-2xl p-4 border cursor-pointer transition-colors group ${
        featured ? "border-primary/20 bg-primary/[0.03]" : "border-border/50 bg-card/50 hover:border-border"
      }`}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ background: `${typeInfo.color}15` }}>
          <Zap className="w-5 h-5" style={{ color: typeInfo.color }} />
        </div>
        <div className="flex items-center gap-1.5">
          <span className="text-[9px] px-1.5 py-0.5 rounded-full font-medium" style={{ background: `${typeInfo.color}15`, color: typeInfo.color }}>
            {typeInfo.label}
          </span>
          {skill.is_composable && (
            <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-accent/20 text-accent-foreground">
              <Puzzle className="w-2.5 h-2.5 inline mr-0.5" />조합
            </span>
          )}
          {featured && (
            <span className="text-[9px] px-2 py-0.5 rounded-full bg-primary/10 text-primary font-semibold">추천</span>
          )}
        </div>
      </div>
      <h3 className="text-[13px] font-semibold text-foreground mb-1 line-clamp-1">{skill.name}</h3>
      <p className="text-[11px] text-muted-foreground line-clamp-2 mb-3">{skill.description}</p>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
          <span className="flex items-center gap-1"><Star className="w-3 h-3 text-amber-500" fill="currentColor" />{skill.rating}</span>
          <span className="flex items-center gap-1"><Download className="w-3 h-3" />{skill.installs}</span>
        </div>
        <button onClick={e => { e.stopPropagation(); onInstall(skill); }}
          className="px-2.5 py-1 rounded-lg text-[10px] font-semibold bg-primary/10 text-primary hover:bg-primary/20 transition-colors">
          설치
        </button>
      </div>
      <div className="flex gap-1 mt-2 flex-wrap">
        {skill.tags.slice(0, 3).map(tag => (
          <span key={tag} className="text-[9px] px-1.5 py-0.5 rounded-md bg-secondary/60 text-muted-foreground">#{tag}</span>
        ))}
      </div>
    </motion.div>
  );
}

/* ─── Skill Detail Modal ─── */
function SkillDetailModal({ skill, onClose, onInstall }: {
  skill: MarketplaceSkill; onClose: () => void; onInstall: (s: MarketplaceSkill) => void;
}) {
  const [reviews, setReviews] = useState<MarketplaceReview[]>([]);
  const [loadingReviews, setLoadingReviews] = useState(true);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState("");
  const [reviewerName, setReviewerName] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [hoverRating, setHoverRating] = useState(0);
  const [currentRating, setCurrentRating] = useState(skill.rating);

  const typeInfo = SKILL_TYPE_LABELS[skill.skill_type] || { label: skill.skill_type, color: "hsl(var(--muted-foreground))" };

  const fetchReviews = useCallback(async () => {
    setLoadingReviews(true);
    try {
      setReviews(await marketplaceProvider.listReviews("skill", skill.id));
    } catch {
      toast.error("리뷰를 불러오지 못했습니다");
    }
    setLoadingReviews(false);
  }, [skill.id]);

  useEffect(() => { fetchReviews(); }, [fetchReviews]);

  const submitReview = async () => {
    if (!reviewComment.trim()) { toast.error("리뷰 내용을 입력해주세요"); return; }
    setSubmitting(true);
    try {
      await marketplaceProvider.submitReview("skill", skill.id, {
        reviewer_name: reviewerName.trim() || "익명",
        rating: reviewRating,
        comment: reviewComment.trim(),
      });
      toast.success("리뷰가 등록되었습니다!");
      setShowReviewForm(false); setReviewComment(""); setReviewRating(5);
      await fetchReviews();
      const rating = await marketplaceProvider.getRating("skill", skill.id);
      if (rating !== null) setCurrentRating(rating);
    } catch {
      toast.error("리뷰 등록에 실패했습니다");
    }
    setSubmitting(false);
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-[60] bg-black/40 flex items-center justify-center p-8" onClick={onClose}>
      <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }}
        onClick={e => e.stopPropagation()}
        className="w-full max-w-lg rounded-2xl bg-card border border-border p-6 space-y-4 max-h-[85vh] overflow-y-auto scrollbar-thin"
        style={{ boxShadow: "var(--shadow-3)" }}>

        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ background: `${typeInfo.color}15` }}>
              <Zap className="w-6 h-6" style={{ color: typeInfo.color }} />
            </div>
            <div>
              <h2 className="text-[14px] font-bold text-foreground">{skill.name}</h2>
              <p className="text-[11px] text-muted-foreground">by {skill.creator_name}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg hover:bg-secondary transition-colors"><X className="w-4 h-4 text-muted-foreground" /></button>
        </div>

        <p className="text-[12px] text-foreground/80 leading-relaxed">{skill.description}</p>

        <div className="flex items-center gap-3 text-[11px] text-muted-foreground flex-wrap">
          <span className="flex items-center gap-1"><Star className="w-3.5 h-3.5 text-amber-500" fill="currentColor" />{currentRating}</span>
          <span className="flex items-center gap-1"><Download className="w-3.5 h-3.5" />{skill.installs}회 설치</span>
          <span className="px-1.5 py-0.5 rounded-md text-[10px] font-medium" style={{ background: `${typeInfo.color}15`, color: typeInfo.color }}>{typeInfo.label}</span>
          {skill.is_composable && <span className="px-1.5 py-0.5 rounded-md bg-accent/20 text-accent-foreground text-[10px]">조합 가능</span>}
          <span className="flex items-center gap-1"><MessageSquare className="w-3.5 h-3.5" />{reviews.length}개 리뷰</span>
        </div>

        {skill.implementation && (
          <div className="rounded-xl bg-secondary/20 p-3">
            <p className="text-[10px] font-semibold text-muted-foreground mb-1">구현 로직</p>
            <pre className="text-[11px] text-foreground/70 font-mono leading-relaxed whitespace-pre-wrap">{skill.implementation}</pre>
          </div>
        )}

        <div className="flex gap-1.5 flex-wrap">
          {skill.tags.map(tag => (
            <span key={tag} className="text-[10px] px-2 py-0.5 rounded-md bg-secondary/60 text-muted-foreground">#{tag}</span>
          ))}
        </div>

        <button onClick={() => { onInstall(skill); onClose(); }}
          className="w-full py-2.5 rounded-xl text-[12px] font-semibold transition-colors"
          style={{ background: "hsl(var(--primary))", color: "hsl(var(--primary-foreground))" }}>
          스킬 설치하기
        </button>

        {/* Reviews */}
        <div className="border-t border-border/50 pt-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-[13px] font-semibold text-foreground">평점 및 리뷰</h3>
            <button onClick={() => setShowReviewForm(!showReviewForm)} className="text-[11px] font-medium text-primary hover:underline flex items-center gap-1">
              <Send className="w-3 h-3" />리뷰 작성
            </button>
          </div>

          <AnimatePresence>
            {showReviewForm && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden mb-4">
                <div className="rounded-xl border border-border/50 p-3 space-y-3 bg-secondary/20">
                  <div>
                    <label className="text-[10px] font-medium text-muted-foreground block mb-1.5">평점</label>
                    <div className="flex items-center gap-1">
                      {[1,2,3,4,5].map(s => (
                        <button key={s} onMouseEnter={() => setHoverRating(s)} onMouseLeave={() => setHoverRating(0)} onClick={() => setReviewRating(s)} className="p-0.5 transition-transform hover:scale-110">
                          <Star className={`w-5 h-5 ${s <= (hoverRating || reviewRating) ? "text-amber-500" : "text-muted-foreground/30"}`} fill="currentColor" />
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="text-[10px] font-medium text-muted-foreground block mb-1">이름</label>
                    <input value={reviewerName} onChange={e => setReviewerName(e.target.value)} placeholder="익명"
                      className="w-full px-3 py-1.5 rounded-lg text-[11px] bg-background border border-border/50 focus:border-primary/30 focus:outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] font-medium text-muted-foreground block mb-1">리뷰 *</label>
                    <textarea value={reviewComment} onChange={e => setReviewComment(e.target.value)} rows={2} placeholder="이 스킬에 대한 의견을 남겨주세요"
                      className="w-full px-3 py-1.5 rounded-lg text-[11px] bg-background border border-border/50 focus:border-primary/30 focus:outline-none resize-none" />
                  </div>
                  <div className="flex gap-2 justify-end">
                    <button onClick={() => setShowReviewForm(false)} className="px-3 py-1.5 rounded-lg text-[11px] text-muted-foreground hover:bg-secondary transition-colors">취소</button>
                    <button onClick={submitReview} disabled={submitting || !reviewComment.trim()}
                      className="px-3 py-1.5 rounded-lg text-[11px] font-semibold transition-colors disabled:opacity-50"
                      style={{ background: "hsl(var(--primary))", color: "hsl(var(--primary-foreground))" }}>
                      {submitting ? "등록 중..." : "리뷰 등록"}
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {loadingReviews ? (
            <div className="flex justify-center py-4"><Loader2 className="w-4 h-4 animate-spin text-muted-foreground" /></div>
          ) : reviews.length === 0 ? (
            <p className="text-[11px] text-muted-foreground text-center py-4">아직 리뷰가 없습니다</p>
          ) : (
            <div className="space-y-3">
              {reviews.map(review => (
                <div key={review.id} className="rounded-xl bg-secondary/20 p-3">
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] font-semibold text-foreground">{review.reviewer_name}</span>
                      <div className="flex items-center gap-0.5">
                        {[1,2,3,4,5].map(s => (
                          <Star key={s} className={`w-2.5 h-2.5 ${s <= review.rating ? "text-amber-500" : "text-muted-foreground/30"}`} fill="currentColor" />
                        ))}
                      </div>
                    </div>
                    <span className="text-[9px] text-muted-foreground">{new Date(review.created_at).toLocaleDateString("ko-KR")}</span>
                  </div>
                  <p className="text-[11px] text-foreground/70 leading-relaxed">{review.comment}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}

/* ─── Create Skill Modal ─── */
function CreateSkillModal({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("transform");
  const [skillType, setSkillType] = useState("transform");
  const [implementation, setImplementation] = useState("");
  const [creatorName, setCreatorName] = useState("");
  const [tags, setTags] = useState("");
  const [saving, setSaving] = useState(false);

  const handleSubmit = async () => {
    if (!name.trim()) { toast.error("이름을 입력해주세요"); return; }
    setSaving(true);
    try {
      await marketplaceProvider.create("skill", {
        name, description: description || null, category, skill_type: skillType,
        implementation: implementation || null, creator_name: creatorName || "익명",
        tags: tags.split(",").map(t => t.trim()).filter(Boolean),
      });
      toast.success("스킬이 연결 센터에 등록되었습니다!");
      onCreated();
    } catch {
      toast.error("스킬 등록에 실패했습니다");
    }
    setSaving(false);
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-[60] bg-black/40 flex items-center justify-center p-8" onClick={onClose}>
      <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }}
        onClick={e => e.stopPropagation()}
        className="w-full max-w-md rounded-2xl bg-card border border-border p-6 space-y-4 max-h-[80vh] overflow-y-auto scrollbar-thin"
        style={{ boxShadow: "var(--shadow-3)" }}>

        <div className="flex items-center justify-between">
          <h2 className="text-[14px] font-bold text-foreground">새 스킬 만들기</h2>
          <button onClick={onClose} className="p-1 rounded-lg hover:bg-secondary transition-colors"><X className="w-4 h-4 text-muted-foreground" /></button>
        </div>

        <div className="space-y-3">
          <div>
            <label className="text-[11px] font-medium text-muted-foreground block mb-1">이름 *</label>
            <input value={name} onChange={e => setName(e.target.value)} placeholder="예: JSON 데이터 정규화"
              className="w-full px-3 py-2 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none" />
          </div>
          <div>
            <label className="text-[11px] font-medium text-muted-foreground block mb-1">설명</label>
            <textarea value={description} onChange={e => setDescription(e.target.value)} rows={2} placeholder="스킬이 무엇을 하는지 설명해주세요"
              className="w-full px-3 py-2 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none resize-none" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-medium text-muted-foreground block mb-1">스킬 타입</label>
              <select value={skillType} onChange={e => { setSkillType(e.target.value); setCategory(e.target.value); }}
                className="w-full px-3 py-2 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none">
                <option value="transform">데이터 변환</option>
                <option value="analysis">분석</option>
                <option value="format">포맷팅</option>
                <option value="filter">필터링</option>
                <option value="enrich">데이터 보강</option>
                <option value="validate">검증</option>
              </select>
            </div>
            <div>
              <label className="text-[11px] font-medium text-muted-foreground block mb-1">만든 사람</label>
              <input value={creatorName} onChange={e => setCreatorName(e.target.value)} placeholder="익명"
                className="w-full px-3 py-2 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none" />
            </div>
          </div>
          <div>
            <label className="text-[11px] font-medium text-muted-foreground block mb-1">구현 로직 (선택)</label>
            <textarea value={implementation} onChange={e => setImplementation(e.target.value)} rows={4} placeholder="스킬의 구현 로직을 작성하세요..."
              className="w-full px-3 py-2 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none resize-none font-mono" />
          </div>
          <div>
            <label className="text-[11px] font-medium text-muted-foreground block mb-1">태그 (쉼표 구분)</label>
            <input value={tags} onChange={e => setTags(e.target.value)} placeholder="예: 데이터, 변환, JSON"
              className="w-full px-3 py-2 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none" />
          </div>
        </div>

        <button onClick={handleSubmit} disabled={saving || !name.trim()}
          className="w-full py-2.5 rounded-xl text-[12px] font-semibold transition-colors disabled:opacity-50"
          style={{ background: "hsl(var(--primary))", color: "hsl(var(--primary-foreground))" }}>
          {saving ? "등록 중..." : "스킬 등록"}
        </button>
      </motion.div>
    </motion.div>
  );
}

/* ─── Plugin Builder Modal ─── */
function PluginBuilderModal({ skills, onClose }: { skills: MarketplaceSkill[]; onClose: () => void }) {
  const [pluginName, setPluginName] = useState("");
  const [pluginDesc, setPluginDesc] = useState("");
  const [selectedSkills, setSelectedSkills] = useState<MarketplaceSkill[]>([]);
  const [creatorName, setCreatorName] = useState("");
  const [tags, setTags] = useState("");
  const [saving, setSaving] = useState(false);
  const [showSkillPicker, setShowSkillPicker] = useState(false);

  const composableSkills = skills.filter(s => s.is_composable);

  const addSkill = (skill: MarketplaceSkill) => {
    if (!selectedSkills.find(s => s.id === skill.id)) {
      setSelectedSkills(prev => [...prev, skill]);
    }
    setShowSkillPicker(false);
  };

  const removeSkill = (id: string) => {
    setSelectedSkills(prev => prev.filter(s => s.id !== id));
  };

  const moveSkill = (index: number, direction: "up" | "down") => {
    const newList = [...selectedSkills];
    const target = direction === "up" ? index - 1 : index + 1;
    if (target < 0 || target >= newList.length) return;
    [newList[index], newList[target]] = [newList[target], newList[index]];
    setSelectedSkills(newList);
  };

  const handleSubmit = async () => {
    if (!pluginName.trim()) { toast.error("플러그인 이름을 입력해주세요"); return; }
    if (selectedSkills.length < 2) { toast.error("2개 이상의 스킬을 선택해주세요"); return; }
    setSaving(true);
    try {
      await marketplaceProvider.create("plugin", {
        name: pluginName,
        description: pluginDesc || null,
        skill_ids: selectedSkills.map(s => s.id),
        skill_config: selectedSkills.map((s, i) => ({ order: i, skill_id: s.id, skill_name: s.name, skill_type: s.skill_type })),
        creator_name: creatorName || "익명",
        tags: tags.split(",").map(t => t.trim()).filter(Boolean),
      });
      toast.success("플러그인이 연결 센터에 등록되었습니다!");
      onClose();
    } catch {
      toast.error("플러그인 등록에 실패했습니다");
    }
    setSaving(false);
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-[60] bg-black/40 flex items-center justify-center p-8" onClick={onClose}>
      <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }}
        onClick={e => e.stopPropagation()}
        className="w-full max-w-lg rounded-2xl bg-card border border-border p-6 space-y-4 max-h-[85vh] overflow-y-auto scrollbar-thin"
        style={{ boxShadow: "var(--shadow-3)" }}>

        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Puzzle className="w-5 h-5 text-primary" />
            <h2 className="text-[14px] font-bold text-foreground">플러그인 빌더</h2>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg hover:bg-secondary transition-colors"><X className="w-4 h-4 text-muted-foreground" /></button>
        </div>

        <p className="text-[11px] text-muted-foreground">여러 스킬을 조합하여 하나의 플러그인으로 만들 수 있습니다. 스킬은 순서대로 실행됩니다.</p>

        <div className="space-y-3">
          <div>
            <label className="text-[11px] font-medium text-muted-foreground block mb-1">플러그인 이름 *</label>
            <input value={pluginName} onChange={e => setPluginName(e.target.value)} placeholder="예: 고객 데이터 분석 파이프라인"
              className="w-full px-3 py-2 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none" />
          </div>
          <div>
            <label className="text-[11px] font-medium text-muted-foreground block mb-1">설명</label>
            <textarea value={pluginDesc} onChange={e => setPluginDesc(e.target.value)} rows={2} placeholder="플러그인이 어떤 작업을 수행하는지..."
              className="w-full px-3 py-2 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none resize-none" />
          </div>

          {/* Skill pipeline */}
          <div>
            <label className="text-[11px] font-medium text-muted-foreground block mb-2">스킬 파이프라인</label>
            <div className="space-y-2">
              {selectedSkills.map((skill, i) => {
                const typeInfo = SKILL_TYPE_LABELS[skill.skill_type] || { label: skill.skill_type, color: "hsl(var(--muted-foreground))" };
                return (
                  <div key={skill.id} className="flex items-center gap-2">
                    <div className="flex flex-col gap-0.5">
                      <button onClick={() => moveSkill(i, "up")} disabled={i === 0}
                        className="p-0.5 rounded text-muted-foreground hover:text-foreground disabled:opacity-20">
                        <ChevronDown className="w-3 h-3 rotate-180" />
                      </button>
                      <button onClick={() => moveSkill(i, "down")} disabled={i === selectedSkills.length - 1}
                        className="p-0.5 rounded text-muted-foreground hover:text-foreground disabled:opacity-20">
                        <ChevronDown className="w-3 h-3" />
                      </button>
                    </div>
                    <div className="flex-1 flex items-center gap-2 p-2.5 rounded-xl bg-secondary/20 border border-border/30">
                      <span className="text-[9px] px-1 py-0.5 rounded bg-secondary font-mono text-muted-foreground">{i + 1}</span>
                      <div className="w-6 h-6 rounded-lg flex items-center justify-center" style={{ background: `${typeInfo.color}15` }}>
                        <Zap className="w-3 h-3" style={{ color: typeInfo.color }} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-[11px] font-medium text-foreground truncate">{skill.name}</p>
                        <p className="text-[9px] text-muted-foreground">{typeInfo.label}</p>
                      </div>
                      <button onClick={() => removeSkill(skill.id)} className="p-1 rounded-lg hover:bg-destructive/10 transition-colors">
                        <Trash2 className="w-3 h-3 text-destructive/60" />
                      </button>
                    </div>
                    {i < selectedSkills.length - 1 && (
                      <ArrowRight className="w-3 h-3 text-muted-foreground flex-shrink-0 mx-1" />
                    )}
                  </div>
                );
              })}

              <button onClick={() => setShowSkillPicker(true)}
                className="w-full py-2.5 rounded-xl border-2 border-dashed border-border/50 text-[11px] text-muted-foreground hover:border-primary/30 hover:text-primary transition-colors flex items-center justify-center gap-1.5">
                <Plus className="w-3.5 h-3.5" />
                스킬 추가 ({composableSkills.length}개 사용 가능)
              </button>
            </div>
          </div>

          {/* Skill picker dropdown */}
          <AnimatePresence>
            {showSkillPicker && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }}
                className="overflow-hidden">
                <div className="rounded-xl border border-border/50 bg-secondary/10 p-2 max-h-40 overflow-y-auto scrollbar-thin space-y-1">
                  {composableSkills.filter(s => !selectedSkills.find(ss => ss.id === s.id)).length === 0 ? (
                    <p className="text-[11px] text-muted-foreground text-center py-3">추가 가능한 스킬이 없습니다</p>
                  ) : (
                    composableSkills.filter(s => !selectedSkills.find(ss => ss.id === s.id)).map(skill => {
                      const t = SKILL_TYPE_LABELS[skill.skill_type] || { label: skill.skill_type, color: "hsl(var(--muted-foreground))" };
                      return (
                        <button key={skill.id} onClick={() => addSkill(skill)}
                          className="w-full flex items-center gap-2 p-2 rounded-lg hover:bg-secondary/30 transition-colors text-left">
                          <Zap className="w-3 h-3 flex-shrink-0" style={{ color: t.color }} />
                          <div className="flex-1 min-w-0">
                            <p className="text-[11px] font-medium text-foreground truncate">{skill.name}</p>
                            <p className="text-[9px] text-muted-foreground">{t.label} · {skill.description?.slice(0, 40)}...</p>
                          </div>
                        </button>
                      );
                    })
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-medium text-muted-foreground block mb-1">만든 사람</label>
              <input value={creatorName} onChange={e => setCreatorName(e.target.value)} placeholder="익명"
                className="w-full px-3 py-2 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none" />
            </div>
            <div>
              <label className="text-[11px] font-medium text-muted-foreground block mb-1">태그 (쉼표)</label>
              <input value={tags} onChange={e => setTags(e.target.value)} placeholder="파이프라인, 분석"
                className="w-full px-3 py-2 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none" />
            </div>
          </div>
        </div>

        <button onClick={handleSubmit} disabled={saving || !pluginName.trim() || selectedSkills.length < 2}
          className="w-full py-2.5 rounded-xl text-[12px] font-semibold transition-colors disabled:opacity-50"
          style={{ background: "hsl(var(--primary))", color: "hsl(var(--primary-foreground))" }}>
          {saving ? "등록 중..." : `플러그인 등록 (${selectedSkills.length}개 스킬)`}
        </button>
      </motion.div>
    </motion.div>
  );
}
