import { useState, useEffect, useMemo, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { supabase } from "@/integrations/supabase/client";
import { demoStrategies, demoStrategyVersions } from "@/data/demoStrategyCatalog";
import {
  EVIDENCE_SOURCE_SYSTEMS,
  EVIDENCE_STATUSES,
  agentResultRowToWorkerResultIntake,
  agentEventRowsToWorkerEvents,
  agentEvidenceRowsToEvidenceItems,
  createWorkerEvent,
  createTaskCompletionPreview,
  createTaskEvidenceItem,
  createTaskWorkboardDraft,
  resolveDemoTaskDraft,
  evidenceItemToAgentEvidenceInsert,
  gatewayPacketToWorkboardTaskInsert,
  isAgentApprovalRecorded,
  latestAgentApprovalRow,
  latestAgentResultRow,
  parseManualCodexResult,
  recommendWorkboardStatusAfterResult,
  renderManualCodexResultGuide,
  suggestNextEvidenceType,
  suggestEvidenceTypesForTask,
  taskPacketToAgentApprovalInsert,
  validateWorkboardStatusGate,
  workerResultToAgentResultInsert,
  type AgentApprovalRow,
  type AgentEventRow,
  type AgentResultRow,
  type ApprovalDecision,
  type EventSeverity,
  type AgentEvidenceRow,
  type EvidenceItem,
  type EvidenceSourceSystem,
  type EvidenceStatus,
  type EvidenceType,
  type ManualCodexResultIntake,
  type TaskPacket,
  type WorkerEvent,
  type WorkerEventType,
  type WorkerResultIntakeRecord,
  type WorkboardTaskStatus,
  workerEventToAgentEventInsert,
  type GatewayCodexDraft,
} from "@/lib/agentic";
import { resolveAppRuntimeMode } from "@/lib/runtimeMode";
import {
  projectLegacyTask,
  type CompanyRuntimeTaskView,
  type LegacyTaskRecord,
  type WorkboardTaskView,
} from "@/lib/company-runtime/projection";
import { StaleTaskLoadError, taskRepository, type LegacyMutationKind } from "@/lib/taskRepository";
import { StrategySummary } from "./StrategySummary";
import { CompanyTaskPanel } from "./CompanyTaskPanel";
import { CompanyLineagePanel } from "./CompanyLineagePanel";
import { selectCompanyTaskGuidance } from "./companyTaskGuidance";
import { toast } from "sonner";
import {
  ArrowLeft,
  Bot,
  CheckCircle2,
  Clock,
  Copy,
  Trash2,
  Building2,
  ShieldAlert,
  Package,
  DollarSign,
  Loader2,
  RefreshCw,
  Plus,
  X,
  Pencil,
} from "lucide-react";

type Task = WorkboardTaskView;

type TaskFilter = "all" | "pending" | "in_progress" | "done" | "follow_up" | "blocked";

const taskFilterOptions: { key: TaskFilter; label: string }[] = [
  { key: "all", label: "전체" },
  { key: "pending", label: "대기" },
  { key: "in_progress", label: "진행 중" },
  { key: "done", label: "완료" },
  { key: "follow_up", label: "후속" },
  { key: "blocked", label: "보류" },
];

const statusMeta: Record<string, { label: string; color: string; bg: string }> = {
  pending: { label: "대기", color: "text-yellow-400", bg: "bg-yellow-500/15 border-yellow-500/20" },
  in_progress: { label: "진행 중", color: "text-blue-400", bg: "bg-blue-500/15 border-blue-500/20" },
  done: { label: "완료", color: "text-green-400", bg: "bg-green-500/15 border-green-500/20" },
};

const severityMeta: Record<string, { label: string; color: string }> = {
  critical: { label: "심각", color: "text-red-400" },
  high: { label: "높음", color: "text-orange-400" },
  medium: { label: "보통", color: "text-yellow-400" },
  low: { label: "낮음", color: "text-green-400" },
};

const severityOrder: Record<string, number> = { critical: 0, high: 1, medium: 2, low: 3 };

const categoryIcon: Record<string, typeof Package> = {
  delivery: Package,
  quality: ShieldAlert,
  price: DollarSign,
};

const taskTypeLabels: Record<string, string> = {
  inventory_check: "재고 확인",
  urgent_material_risk_assessment: "긴급재 리스크 평가",
  delivery_delay_risk_check: "납기 지연 리스크 확인",
  business_risk_review: "업무 리스크 점검",
  customer_reply_draft: "고객 답장 초안",
  order_status_check: "주문 상태 확인",
  material_substitution_review: "대체 자재 검토",
  pr_verification: "PR 검증",
  supabase_staging_check: "스테이징 확인",
  document_to_prd: "PRD 초안",
};

const gatewayStatusLabels: Record<string, string> = {
  queued: "접수됨",
  triaging: "정리 중",
  waiting_for_approval: "승인 대기",
  running: "실행 중",
  blocked: "보류",
  verifying: "검증 중",
  completed: "완료",
  failed: "실패",
  archived: "보관됨",
};

const riskLabels: Record<string, string> = {
  low: "낮음",
  medium: "보통",
  high: "높음",
  blocked: "보류",
};

const riskTone: Record<string, string> = {
  low: "border-emerald-500/20 bg-emerald-500/10 text-emerald-300",
  medium: "border-amber-500/20 bg-amber-500/10 text-amber-300",
  high: "border-red-500/20 bg-red-500/10 text-red-300",
  blocked: "border-muted-foreground/20 bg-secondary text-muted-foreground",
};

const verificationLabels: Record<string, string> = {
  inventory_status: "재고 상태",
  order_status: "주문 상태",
  delivery_status: "납기 상태",
  risk_assessment: "리스크 평가",
  manual_review: "수동 검토",
  reply_draft: "답장 초안",
  substitution_review: "대체 자재 검토",
  ci_status: "CI 상태",
  diff_review: "변경 내용 검토",
  supabase_status: "Supabase 상태",
  document_created: "문서 생성 확인",
  test: "테스트",
  lint: "린트",
  typecheck: "타입 확인",
  build: "빌드",
};

const evidenceTypeLabels: Record<string, string> = {
  command_output: "명령 결과",
  test_result: "테스트 결과",
  ci_status: "CI 상태",
  github_pr: "GitHub PR",
  github_commit: "GitHub 커밋",
  file_diff: "변경 내용",
  supabase_project_status: "Supabase 프로젝트 상태",
  supabase_migration_status: "Supabase 마이그레이션 상태",
  edge_function_status: "Edge Function 상태",
  advisor_result: "Advisor 결과",
  generated_document: "생성 문서",
  manual_observation: "수동 확인",
  inventory_snapshot: "재고 스냅샷",
  order_status: "주문 상태",
  delivery_schedule: "납기 일정",
  risk_assessment: "리스크 평가",
  generated_reply: "답장 초안",
  substitution_option: "대체 자재 후보",
};

const sourceSystemLabels: Record<string, string> = {
  github: "GitHub",
  supabase: "Supabase",
  local_shell: "로컬 실행",
  repo: "저장소",
  gateway: "Gateway",
  codex_worker: "Codex",
  user: "사용자 확인",
  erp: "ERP",
  crm: "CRM",
  spreadsheet: "스프레드시트",
};

const evidenceStatusLabels: Record<string, string> = {
  passed: "통과",
  failed: "실패",
  warning: "주의",
  info: "참고",
};

const approvalDecisionLabels: Record<string, string> = {
  approved: "승인됨",
  rejected: "거절됨",
};

const workerEventLabels: Record<string, string> = {
  accepted: "접수됨",
  plan_created: "계획 생성",
  approval_required: "승인 필요",
  started: "시작됨",
  progress: "진행",
  evidence_added: "증거 추가",
  blocked: "보류",
  verification_started: "검증 시작",
  verification_passed: "검증 통과",
  verification_failed: "검증 실패",
  completed: "완료",
  failed: "실패",
};

const eventSeverityTone: Record<string, string> = {
  info: "border-border/40 bg-background/70 text-muted-foreground",
  warning: "border-amber-500/20 bg-amber-500/10 text-amber-300",
  error: "border-red-500/20 bg-red-500/10 text-red-300",
};

const workerOutcomeLabels: Record<string, string> = {
  passed: "통과",
  passed_with_warnings: "주의 포함 통과",
  blocked: "보류",
  failed: "실패",
  advisory_only: "참고 결과",
};

const workerOutcomeTone: Record<string, string> = {
  passed: "border-emerald-500/20 bg-emerald-500/10 text-emerald-300",
  passed_with_warnings: "border-amber-500/20 bg-amber-500/10 text-amber-300",
  blocked: "border-muted-foreground/20 bg-secondary text-muted-foreground",
  failed: "border-red-500/20 bg-red-500/10 text-red-300",
  advisory_only: "border-blue-500/20 bg-blue-500/10 text-blue-300",
};

const retentionDecisionLabels: Record<string, string> = {
  memory: "메모리",
  skill: "스킬",
  docs_or_wiki: "문서/위키",
  workboard: "워크보드",
  artifact_or_log: "증거/로그",
  no_save: "저장 안 함",
};

const forbiddenActionLabels: Record<string, string> = {
  "do not reserve inventory": "재고 예약 금지",
  "do not update ERP stock records": "ERP 재고 기록 변경 금지",
  "do not create sales or purchase orders": "판매/구매 주문 생성 금지",
  "do not expedite shipment": "출하 가속 지시 금지",
  "do not send customer commitment": "고객 확약 발송 금지",
  "do not change delivery schedule": "납기 일정 변경 금지",
  "do not create compensation offer": "보상 제안 생성 금지",
  "do not send external message": "외부 메시지 발송 금지",
  "do not make binding price or delivery commitment": "가격/납기 확약 금지",
  "do not expose internal-only context": "내부 전용 정보 노출 금지",
  "do not change order status": "주문 상태 변경 금지",
  "do not update ERP order records": "ERP 주문 기록 변경 금지",
  "do not approve material substitution": "대체 자재 승인 금지",
  "do not change customer specification": "고객 사양 변경 금지",
  "do not change price or customer terms": "가격/거래 조건 변경 금지",
  "do not update ERP or CRM records": "ERP/CRM 기록 변경 금지",
  "do not merge PR": "PR 병합 금지",
  "do not push commits": "커밋 푸시 금지",
  "do not deploy": "배포 금지",
  "do not run migration": "마이그레이션 실행 금지",
  "do not change secrets": "시크릿 변경 금지",
  "do not deploy functions": "함수 배포 금지",
  "do not modify production systems": "운영 시스템 변경 금지",
  "do not overwrite existing docs without approval": "승인 없는 문서 덮어쓰기 금지",
  "do not expose secrets from uploaded files": "민감 정보 노출 금지",
};

function displayTaskType(value: string): string {
  return taskTypeLabels[value] ?? value;
}

function displayGatewayStatus(value: string): string {
  return gatewayStatusLabels[value] ?? value;
}

function displayRisk(value: string): string {
  return riskLabels[value] ?? value;
}

function displayEvidenceType(value: string): string {
  return evidenceTypeLabels[value] ?? value;
}

function displaySourceSystem(value: string): string {
  return sourceSystemLabels[value] ?? value;
}

function displayEvidenceStatus(value: string): string {
  return evidenceStatusLabels[value] ?? value;
}

function displayWorkerOutcome(value: string): string {
  return workerOutcomeLabels[value] ?? value;
}

function displayRetentionDecision(value: string): string {
  return retentionDecisionLabels[value] ?? value;
}

function displayApprovalDecision(value?: string | null): string {
  return value ? approvalDecisionLabels[value] ?? value : "승인 필요";
}

function displayWorkerEventType(value: string): string {
  return workerEventLabels[value] ?? value;
}

function displayEventTime(value: string): string {
  return new Date(value).toLocaleString("ko-KR", {
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function displayValidationIssue(value: string): string {
  if (value === "completed task requires at least one evidence item") {
    return "완료하려면 최소 1개의 증거가 필요합니다.";
  }
  if (value === "completed task requires passing evidence for every required verification") {
    return "필수 확인 항목마다 통과한 증거가 필요합니다.";
  }
  if (value === "raw_excerpt contains sensitive content") {
    return "짧은 원문에 민감 정보가 포함되어 있습니다.";
  }
  if (value === "pasted result contains sensitive content") {
    return "붙여넣은 결과에 민감 정보가 포함되어 있습니다.";
  }
  if (value === "passed worker result requires at least one evidence item") {
    return "통과 결과로 적용하려면 최소 1개의 증거가 필요합니다.";
  }
  if (value === "completed task requires a passed worker outcome") {
    return "완료하려면 Codex 결과가 통과 상태여야 합니다.";
  }
  return value;
}

function displayTaskGateIssue(value: string): string {
  if (value === "approval required before task can move past pending") {
    return "승인 필요한 작업은 승인 기록 전에는 진행하거나 완료할 수 없습니다.";
  }
  if (value.startsWith("invalid status transition: completed ->")) {
    return "완료된 작업은 다시 진행 상태로 되돌릴 수 없습니다.";
  }
  if (value.startsWith("invalid status transition: running -> queued")) {
    return "진행 중인 작업은 대기 상태로 되돌릴 수 없습니다.";
  }
  if (value.startsWith("unsupported workboard status")) {
    return "지원하지 않는 작업 상태입니다.";
  }
  return displayValidationIssue(value);
}

function displayForbiddenAction(value: string): string {
  const approvalMatch = value.match(/^do not perform (.+) without explicit approval$/);
  if (approvalMatch) {
    return `승인 없는 ${approvalMatch[1]} 금지`;
  }
  return forbiddenActionLabels[value] ?? value;
}

interface TaskFormData {
  title: string;
  description: string;
  customer: string;
  category: string;
  severity: string;
  status: string;
}

interface EvidenceFormData {
  evidence_type: EvidenceType;
  source_system: EvidenceSourceSystem;
  status: EvidenceStatus;
  summary: string;
  raw_excerpt: string;
}

const emptyForm: TaskFormData = {
  title: "",
  description: "",
  customer: "",
  category: "",
  severity: "medium",
  status: "pending",
};

const emptyEvidenceForm: EvidenceFormData = {
  evidence_type: "manual_observation",
  source_system: "user",
  status: "passed",
  summary: "",
  raw_excerpt: "",
};

interface TasksModeProps {
  onBack: () => void;
  initialTaskId?: string;
}

interface FollowUpTaskDraft {
  title: string;
  description: string;
  customer: string | null;
  category: string | null;
  severity: string | null;
  status: string;
  source: string;
  source_id: string;
  requires_user_action: boolean;
}

interface FollowUpLineage {
  origin_packet_id: string;
  origin_task: Task | null;
  origin_title: string | null;
  follow_up_action: string | null;
}

const FOLLOW_UP_SOURCE_PREFIX = "follow-up-";

function compactForTask(value: string): string {
  return value.replace(/\s+/g, " ").trim();
}

function truncateTaskTitle(value: string): string {
  const compacted = compactForTask(value);
  return compacted.length > 72 ? `${compacted.slice(0, 69)}...` : compacted;
}

function createFollowUpTaskDraft(input: {
  task: Task;
  packet: TaskPacket;
  result: WorkerResultIntakeRecord;
}): FollowUpTaskDraft | null {
  const blocker = input.result.blockers.find((item) => item.requires_user_action) ?? input.result.blockers[0] ?? null;
  const action = compactForTask(
    input.result.next_action ||
    blocker?.suggested_resolution ||
    blocker?.summary ||
    "",
  );

  if (!action) {
    return null;
  }

  const requiresUserAction = blocker?.requires_user_action ?? input.result.result.outcome === "blocked";
  const severity = requiresUserAction && input.task.severity !== "critical"
    ? "high"
    : input.task.severity || "medium";
  const description = [
    `원 작업: ${input.task.title}`,
    `Codex 후속 액션: ${action}`,
    blocker?.summary ? `Blocker: ${blocker.summary}` : null,
    input.result.result.summary ? `Codex 결과: ${input.result.result.summary}` : null,
  ].filter(Boolean).join("\n");

  return {
    title: `후속: ${truncateTaskTitle(action)}`,
    description,
    customer: input.task.customer,
    category: input.task.category,
    severity,
    status: "pending",
    source: "gateway",
    source_id: `${FOLLOW_UP_SOURCE_PREFIX}${input.packet.task_id}`,
    requires_user_action: requiresUserAction,
  };
}

function extractLineFromDescription(description: string | null | undefined, label: string): string | null {
  if (!description) {
    return null;
  }

  const match = description.match(new RegExp(`^${label}:\\s*(.+)$`, "m"));
  return match?.[1]?.trim() || null;
}

function originPacketIdForFollowUp(task: Task): string | null {
  if (task.source !== "gateway" || !task.source_id?.startsWith(FOLLOW_UP_SOURCE_PREFIX)) {
    return null;
  }

  return task.source_id.slice(FOLLOW_UP_SOURCE_PREFIX.length) || null;
}

function resolveFollowUpLineage(task: Task, tasks: Task[], isDemoMode = false): FollowUpLineage | null {
  const originPacketId = originPacketIdForFollowUp(task);

  if (!originPacketId) {
    return null;
  }

  const originTask = tasks.find((candidate) => resolveWorkboardDraft(candidate, isDemoMode).packet?.task_id === originPacketId) ?? null;

  return {
    origin_packet_id: originPacketId,
    origin_task: originTask,
    origin_title: originTask?.title ?? extractLineFromDescription(task.description, "원 작업"),
    follow_up_action: extractLineFromDescription(task.description, "Codex 후속 액션"),
  };
}

interface RuntimeWorkboardDraft {
  readonly bridge_status: "manual_handoff_ready";
  readonly packet: TaskPacket;
  readonly handoff_markdown: "";
}

function resolveWorkboardDraft(task: CompanyRuntimeTaskView, isDemoMode: boolean): RuntimeWorkboardDraft;
function resolveWorkboardDraft(task: LegacyTaskRecord, isDemoMode: boolean): GatewayCodexDraft;
function resolveWorkboardDraft(task: Task, isDemoMode: boolean): GatewayCodexDraft | RuntimeWorkboardDraft;
function resolveWorkboardDraft(task: Task | LegacyTaskRecord, isDemoMode: boolean): GatewayCodexDraft | RuntimeWorkboardDraft {
  if ("origin" in task && task.origin === "company_runtime") {
    return { bridge_status: "manual_handoff_ready", packet: task.packet, handoff_markdown: "" };
  }
  return isDemoMode ? resolveDemoTaskDraft(task) : createTaskWorkboardDraft(task);
}

function hasInvalidDemoIntake(
  task: Task,
  draft: ReturnType<typeof resolveWorkboardDraft>,
  isDemoMode: boolean,
): boolean {
  const hasDemoIntakeMetadata = task.demo_intake_required !== undefined || task.demo_intake_packet !== undefined;
  return isDemoMode && hasDemoIntakeMetadata && draft.bridge_status === "needs_manual_review";
}

function resultRecordForTask(
  task: Task,
  resultRecordByTaskId: Record<string, WorkerResultIntakeRecord | null>,
  isDemoMode = false,
): WorkerResultIntakeRecord | null {
  const packetTaskId = resolveWorkboardDraft(task, isDemoMode).packet?.task_id;

  return packetTaskId ? resultRecordByTaskId[packetTaskId] ?? null : null;
}

function hasBlockedResult(result: WorkerResultIntakeRecord | null): boolean {
  return Boolean(result && (result.result.outcome === "blocked" || result.blockers.length > 0));
}

function isBlockedResultRecord(result: WorkerResultIntakeRecord): boolean {
  return result.result.outcome === "blocked" || result.blockers.length > 0;
}

function previousBlockedResultsFromHistory(
  history: WorkerResultIntakeRecord[],
  latestResult: WorkerResultIntakeRecord | null,
): WorkerResultIntakeRecord[] {
  const latestCreatedAt = latestResult?.created_at ?? history[0]?.created_at;

  return history.filter((result, index) => {
    const isLatest = latestCreatedAt ? result.created_at === latestCreatedAt : index === 0;
    return !isLatest && isBlockedResultRecord(result);
  });
}

function resultHistoryFromRows(rows: AgentResultRow[]): WorkerResultIntakeRecord[] {
  return [...rows]
    .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
    .map(agentResultRowToWorkerResultIntake);
}

function evidenceWasAddedAfterResult(evidence: EvidenceItem, result: WorkerResultIntakeRecord | null): boolean {
  if (!result?.created_at) {
    return true;
  }

  const evidenceTime = new Date(evidence.created_at).getTime();
  const resultTime = new Date(result.created_at).getTime();

  if (Number.isNaN(evidenceTime) || Number.isNaN(resultTime)) {
    return true;
  }

  return evidenceTime >= resultTime;
}

function renderReverificationContext(result: WorkerResultIntakeRecord, evidence: EvidenceItem[]): string {
  const blockerLines = result.blockers.length > 0
    ? result.blockers.map((blocker) => {
      const resolution = blocker.suggested_resolution ? ` Suggested resolution: ${blocker.suggested_resolution}` : "";
      const action = blocker.requires_user_action ? " Requires user action." : "";
      return `- [${blocker.type}] ${blocker.summary}${resolution}${action}`;
    })
    : ["- none"];
  const evidenceLines = evidence.length > 0
    ? evidence.map((item) => (
      `- [${item.status}] ${item.evidence_type} from ${item.source.system}: ${item.summary}`
    ))
    : ["- none"];

  return [
    "## Reverification Context",
    "Previous worker result was blocked. Re-verify the same Task Packet using the additional evidence below.",
    "",
    "### Previous Result",
    `- outcome: ${result.result.outcome}`,
    `- summary: ${result.result.summary}`,
    "",
    "### Previous Blockers",
    ...blockerLines,
    "",
    "### New Evidence Since Blocked Result",
    ...evidenceLines,
    "",
    "### Reverification Instruction",
    "- Determine whether the blocker is resolved by the new evidence.",
    "- Keep all forbidden actions in force.",
    "- Return a fresh worker result using the Result Format below.",
  ].join("\n");
}

function renderHandoffWithReverificationContext(
  handoff: string,
  result: WorkerResultIntakeRecord | null,
  evidence: EvidenceItem[],
): string {
  if (!result || evidence.length === 0 || (result.result.outcome !== "blocked" && result.blockers.length === 0)) {
    return handoff;
  }

  const context = renderReverificationContext(result, evidence);
  const marker = "\n## Result Format";

  return handoff.includes(marker)
    ? handoff.replace(marker, `\n${context}\n${marker}`)
    : [handoff, "", context].join("\n");
}

export function TasksMode({ onBack, initialTaskId }: TasksModeProps) {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<TaskFilter>("all");
  const [sortBy, setSortBy] = useState<"date" | "severity">("date");
  const [strategyFilter, setStrategyFilter] = useState("all");
  const [showForm, setShowForm] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [form, setForm] = useState<TaskFormData>(emptyForm);
  const [saving, setSaving] = useState(false);
  const [selectedTaskId, setSelectedTaskId] = useState<string | null>(initialTaskId ?? null);
  const [evidenceByTaskId, setEvidenceByTaskId] = useState<Record<string, EvidenceItem[]>>({});
  const [resultSummaryByTaskId, setResultSummaryByTaskId] = useState<Record<string, string>>({});
  const [evidenceForm, setEvidenceForm] = useState<EvidenceFormData>(emptyEvidenceForm);
  const [evidenceFormTaskId, setEvidenceFormTaskId] = useState<string | null>(null);
  const [loadingEvidenceTaskId, setLoadingEvidenceTaskId] = useState<string | null>(null);
  const [persistingEvidence, setPersistingEvidence] = useState(false);
  const [approvalByTaskId, setApprovalByTaskId] = useState<Record<string, AgentApprovalRow | null>>({});
  const [loadingApprovalTaskId, setLoadingApprovalTaskId] = useState<string | null>(null);
  const [persistingApproval, setPersistingApproval] = useState(false);
  const [eventsByTaskId, setEventsByTaskId] = useState<Record<string, WorkerEvent[]>>({});
  const [loadingEventsTaskId, setLoadingEventsTaskId] = useState<string | null>(null);
  const [resultPasteByTaskId, setResultPasteByTaskId] = useState<Record<string, string>>({});
  const [parsedResultByTaskId, setParsedResultByTaskId] = useState<Record<string, ManualCodexResultIntake | null>>({});
  const [resultRecordByTaskId, setResultRecordByTaskId] = useState<Record<string, WorkerResultIntakeRecord | null>>({});
  const [resultHistoryByTaskId, setResultHistoryByTaskId] = useState<Record<string, WorkerResultIntakeRecord[]>>({});
  const [loadingResultTaskId, setLoadingResultTaskId] = useState<string | null>(null);
  const [persistingResult, setPersistingResult] = useState(false);
  const [highlightedFollowUpTaskId, setHighlightedFollowUpTaskId] = useState<string | null>(null);
  const [highlightedEvidenceTaskId, setHighlightedEvidenceTaskId] = useState<string | null>(null);
  const [creatingFollowUpTaskId, setCreatingFollowUpTaskId] = useState<string | null>(null);
  const [startingReverificationTaskId, setStartingReverificationTaskId] = useState<string | null>(null);
  const followUpSectionRef = useRef<HTMLElement | null>(null);
  const evidenceSectionRef = useRef<HTMLElement | null>(null);
  const isDemoMode = resolveAppRuntimeMode() === "demo";

  const fetchTasks = async () => {
    setLoading(true);
    try {
      const result = await taskRepository.load();
      setTasks([...result.tasks]);
      setSelectedTaskId((current) => {
        if (current) {
          return result.tasks.find((task) => task.viewKey === current || task.id === current)?.viewKey ?? current;
        }
        return result.tasks[0]?.viewKey ?? null;
      });
    } catch (error) {
      if (!(error instanceof StaleTaskLoadError)) {
        toast.error("작업 로딩 실패");
      }
    }
    setLoading(false);
  };

  useEffect(() => { fetchTasks(); }, []);

  useEffect(() => taskRepository.subscribe((projection) => {
    if (projection.state !== "ready") {
      return;
    }
    setTasks((current) => [
      ...current.filter((task) => task.origin === "legacy"),
      ...projection.tasks,
    ]);
  }), []);

  useEffect(() => {
    if (initialTaskId) {
      setSelectedTaskId(initialTaskId);
    }
  }, [initialTaskId]);

  const runLegacyMutation = async <T,>(
    task: Task,
    kind: LegacyMutationKind,
    mutate: () => Promise<T>,
  ) => {
    const result = await taskRepository.mutateLegacy({
      kind,
      origin: task.origin,
      sourceId: task.sourceId,
      viewKey: task.viewKey,
      mutate,
    });
    if (!result.ok) {
      toast.error("런타임 소유 작업은 이 메뉴에서 변경할 수 없습니다");
    }
    return result;
  };

  useEffect(() => {
    if (!highlightedFollowUpTaskId || selectedTaskId !== highlightedFollowUpTaskId) {
      return;
    }

    followUpSectionRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  }, [highlightedFollowUpTaskId, selectedTaskId]);

  useEffect(() => {
    if (!highlightedEvidenceTaskId || selectedTaskId !== highlightedEvidenceTaskId) {
      return;
    }

    evidenceSectionRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  }, [highlightedEvidenceTaskId, selectedTaskId]);

  useEffect(() => {
    if (tasks.length === 0) {
      return;
    }

    let cancelled = false;

    void Promise.all(tasks.map(async (task) => {
      if (task.origin === "company_runtime") {
        return null;
      }
      const draft = resolveWorkboardDraft(task, isDemoMode);

      if (!draft.packet) {
        return null;
      }

      const { data, error } = await supabase
        .from("agent_results")
        .select("*")
        .eq("task_id", task.id)
        .eq("packet_task_id", draft.packet.task_id)
        .order("created_at", { ascending: false });

      if (error) {
        return null;
      }

      const rows = (data ?? []) as AgentResultRow[];
      const history = resultHistoryFromRows(rows);
      const row = latestAgentResultRow(rows);

      return {
        packetTaskId: draft.packet.task_id,
        record: row ? agentResultRowToWorkerResultIntake(row) : null,
        history,
      };
    })).then((records) => {
      if (cancelled) {
        return;
      }

      const nextRecords: Record<string, WorkerResultIntakeRecord | null> = {};
      const nextHistory: Record<string, WorkerResultIntakeRecord[]> = {};
      const nextSummaries: Record<string, string> = {};

      for (const item of records) {
        if (!item) {
          continue;
        }
        nextRecords[item.packetTaskId] = item.record;
        nextHistory[item.packetTaskId] = item.history;
        if (item.record?.result.summary) {
          nextSummaries[item.packetTaskId] = item.record.result.summary;
        }
      }

      setResultRecordByTaskId((prev) => ({ ...prev, ...nextRecords }));
      setResultHistoryByTaskId((prev) => ({ ...prev, ...nextHistory }));
      if (Object.keys(nextSummaries).length > 0) {
        setResultSummaryByTaskId((prev) => ({ ...prev, ...nextSummaries }));
      }
    });

    return () => {
      cancelled = true;
    };
  }, [isDemoMode, tasks]);

  const openCreate = () => {
    setEditingTask(null);
    setForm(emptyForm);
    setShowForm(true);
  };

  const openEdit = (task: Task) => {
    setEditingTask(task);
    setForm({
      title: task.title,
      description: task.description || "",
      customer: task.customer || "",
      category: task.category || "",
      severity: task.severity || "medium",
      status: task.status,
    });
    setShowForm(true);
  };

  const focusTaskFollowUp = (task: Task) => {
    setSelectedTaskId(task.viewKey);
    setHighlightedFollowUpTaskId(task.viewKey);
  };

  const closeForm = () => {
    setShowForm(false);
    setEditingTask(null);
    setForm(emptyForm);
  };

  const handleSave = async () => {
    if (!form.title.trim()) {
      toast.error("제목을 입력해주세요");
      return;
    }

    if (!editingTask && form.status === "done") {
      toast.error("새 작업은 먼저 생성한 뒤 증거를 붙여 완료하세요");
      return;
    }

    setSaving(true);

    if (editingTask && form.status !== editingTask.status) {
      const allowed = await validateTaskStatusChange(editingTask, form.status);

      if (!allowed) {
        setSaving(false);
        return;
      }
    }

    const updatedAt = new Date().toISOString();
    const payload = {
      title: form.title.trim(),
      description: form.description.trim() || null,
      customer: form.customer.trim() || null,
      category: form.category || null,
      severity: form.severity || null,
      status: form.status,
      updated_at: updatedAt,
    };

    if (editingTask) {
      const mutation = await runLegacyMutation(
        editingTask,
        form.status !== editingTask.status ? "status" : "edit",
        async () => supabase.from("tasks").update(payload).eq("id", editingTask.id),
      );
      if (!mutation.ok) {
        setSaving(false);
        return;
      }
      const { error } = mutation.value;
      if (error) {
        toast.error("수정 실패");
      } else {
        setTasks((prev) => prev.map((t) => (t.viewKey === editingTask.viewKey ? { ...t, ...payload } : t)));
        if (form.status !== editingTask.status) {
          const draft = resolveWorkboardDraft(editingTask, isDemoMode);
          if (draft.packet) {
            void appendWorkerEvent({
              task: editingTask,
              packet: draft.packet,
              event_type: form.status === "done" ? "completed" : form.status === "in_progress" ? "started" : "progress",
              message: `작업 상태가 ${statusMeta[form.status]?.label ?? form.status}(으)로 변경되었습니다.`,
              severity: "info",
            });
          }
        }
        toast.success("작업이 수정되었습니다");
        closeForm();
      }
    } else {
      const workboardTaskId = globalThis.crypto?.randomUUID?.() ?? `task-${Date.now()}`;
      const draft = resolveWorkboardDraft({
        id: workboardTaskId,
        title: payload.title,
        description: payload.description,
        customer: payload.customer,
        category: payload.category,
        severity: payload.severity,
        status: payload.status,
        source: "manual",
        source_id: null,
        created_at: updatedAt,
      }, isDemoMode);
      const gatewayPayload = draft.packet
        ? gatewayPacketToWorkboardTaskInsert({
            packet: draft.packet,
            workboard_task_id: workboardTaskId,
            created_at: updatedAt,
          })
        : null;
      const insertPayload = gatewayPayload && draft.packet
        ? {
            ...gatewayPayload,
            title: payload.title,
            description: [
              payload.description,
              gatewayPayload.description,
              `Gateway packet id: ${draft.packet.task_id}`,
              `금지 작업: ${draft.packet.forbidden_actions.map(displayForbiddenAction).join(", ")}`,
            ].filter(Boolean).join("\n\n"),
            customer: payload.customer ?? gatewayPayload.customer,
            category: payload.category ?? gatewayPayload.category,
            severity: form.severity === emptyForm.severity ? gatewayPayload.severity : payload.severity,
            status: payload.status,
            updated_at: updatedAt,
          }
        : {
            ...payload,
            id: workboardTaskId,
            source: "manual",
            source_id: null,
            created_at: updatedAt,
          };
      const { data, error } = await supabase
        .from("tasks")
        .insert(insertPayload)
        .select()
        .single();
      if (error) {
        toast.error("생성 실패");
      } else if (data) {
        const createdTask = projectLegacyTask(data);
        setTasks((prev) => [createdTask, ...prev]);
        setFilter("all");
        setStrategyFilter("all");
        setSelectedTaskId(createdTask.viewKey);
        if (draft.packet) {
          void appendWorkerEvent({
            task: createdTask,
            packet: draft.packet,
            event_type: "accepted",
            message: "작업 메뉴에서 Gateway 작업이 생성되었습니다.",
            severity: "info",
          });
        }
        toast.success("작업이 생성되었습니다");
        closeForm();
      }
    }
    setSaving(false);
  };

  const fetchEvidenceForGate = async (task: Task, packetTaskId: string): Promise<EvidenceItem[] | null> => {
    setLoadingEvidenceTaskId(task.id);

    const { data, error } = await supabase
      .from("agent_evidence")
      .select("*")
      .eq("task_id", task.id)
      .eq("packet_task_id", packetTaskId)
      .order("created_at", { ascending: true });

    setLoadingEvidenceTaskId(null);

    if (error) {
      toast.error("저장된 증거를 불러오지 못했습니다");
      return null;
    }

    const evidence = agentEvidenceRowsToEvidenceItems((data ?? []) as AgentEvidenceRow[]);

    setEvidenceByTaskId((prev) => ({
      ...prev,
      [packetTaskId]: evidence,
    }));

    return evidence;
  };

  const fetchApprovalForGate = async (task: Task, packetTaskId: string): Promise<AgentApprovalRow | null> => {
    setLoadingApprovalTaskId(task.id);

    const { data, error } = await supabase
      .from("agent_approvals")
      .select("*")
      .eq("task_id", task.id)
      .eq("packet_task_id", packetTaskId)
      .order("created_at", { ascending: false });

    setLoadingApprovalTaskId(null);

    if (error) {
      toast.error("승인 기록을 불러오지 못했습니다");
      return null;
    }

    const approval = latestAgentApprovalRow((data ?? []) as AgentApprovalRow[]);

    setApprovalByTaskId((prev) => ({
      ...prev,
      [packetTaskId]: approval,
    }));

    return approval;
  };

  const appendWorkerEvent = async (input: {
    task: Task;
    packet: TaskPacket;
    event_type: WorkerEventType;
    message: string;
    evidence_ref_id?: string;
    severity?: EventSeverity;
    requires_user_action?: boolean;
  }) => {
    const event = createWorkerEvent({
      packet_task_id: input.packet.task_id,
      event_type: input.event_type,
      message: input.message,
      evidence_ref_id: input.evidence_ref_id,
      severity: input.severity,
      requires_user_action: input.requires_user_action,
    });

    const mutation = await runLegacyMutation(input.task, "event", async () => supabase
      .from("agent_events")
      .insert(workerEventToAgentEventInsert({
        workboard_task_id: input.task.id,
        event,
      })));
    if (!mutation.ok) {
      return;
    }
    const { error } = mutation.value;

    if (error) {
      toast.error("이벤트 기록에 실패했습니다");
      return;
    }

    setEventsByTaskId((prev) => ({
      ...prev,
      [input.packet.task_id]: [...(prev[input.packet.task_id] ?? []), event]
        .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime()),
    }));
  };

  const validateTaskStatusChange = async (task: Task, targetStatus: string): Promise<boolean> => {
    if (task.origin === "company_runtime") {
      toast.error("런타임 소유 작업 상태는 런타임 명령으로만 변경할 수 있습니다");
      setSelectedTaskId(task.viewKey);
      return false;
    }
    const draft = resolveWorkboardDraft(task, isDemoMode);

    if (!draft.packet) {
      toast.error("Gateway 판단이 필요한 작업입니다");
      setSelectedTaskId(task.viewKey);
      return false;
    }

    const evidence = targetStatus === "done"
      ? await fetchEvidenceForGate(task, draft.packet.task_id)
      : evidenceByTaskId[draft.packet.task_id] ?? [];

    if (!evidence) {
      setSelectedTaskId(task.viewKey);
      return false;
    }

    const approval = draft.packet.required_approval && targetStatus !== "pending"
      ? await fetchApprovalForGate(task, draft.packet.task_id)
      : approvalByTaskId[draft.packet.task_id] ?? null;

    if (draft.packet.required_approval && targetStatus !== "pending" && approval?.decision === "rejected") {
      setSelectedTaskId(task.viewKey);
      toast.error("승인이 거절된 작업은 진행할 수 없습니다");
      return false;
    }

    const gate = validateWorkboardStatusGate({
      packet: draft.packet,
      current_status: task.status as WorkboardTaskStatus,
      target_status: targetStatus,
      evidence,
      result_summary: resultSummaryByTaskId[draft.packet.task_id],
      approval_recorded: isAgentApprovalRecorded(approval),
    });

    if (!gate.allowed) {
      setSelectedTaskId(task.viewKey);
      toast.error(displayTaskGateIssue(gate.issues[0] ?? "상태 변경 조건을 확인해주세요"));
      return false;
    }

    return true;
  };

  const updateStatus = async (viewKey: string, status: string) => {
    const task = tasks.find((item) => item.viewKey === viewKey);

    if (!task) {
      toast.error("작업을 찾을 수 없습니다");
      return;
    }

    const allowed = await validateTaskStatusChange(task, status);

    if (!allowed) {
      return;
    }

    const mutation = await runLegacyMutation(task, "status", async () => supabase
      .from("tasks")
      .update({ status, updated_at: new Date().toISOString() })
      .eq("id", task.id));
    if (!mutation.ok) {
      return;
    }
    const { error } = mutation.value;
    if (error) {
      toast.error("상태 변경 실패");
    } else {
      setTasks((prev) => prev.map((t) => (t.viewKey === task.viewKey ? { ...t, status } : t)));
      const draft = resolveWorkboardDraft(task, isDemoMode);
      if (draft.packet) {
        void appendWorkerEvent({
          task,
          packet: draft.packet,
          event_type: status === "done" ? "completed" : status === "in_progress" ? "started" : "progress",
          message: `작업 상태가 ${statusMeta[status]?.label ?? status}(으)로 변경되었습니다.`,
          severity: "info",
        });
      }
      toast.success("상태가 변경되었습니다");
    }
  };

  const applyResultDrivenStatus = async (input: {
    task: Task;
    packet: TaskPacket;
    intake: ManualCodexResultIntake;
    evidence: EvidenceItem[];
  }): Promise<WorkboardTaskStatus | null> => {
    const approval = input.packet.required_approval
      ? await fetchApprovalForGate(input.task, input.packet.task_id)
      : approvalByTaskId[input.packet.task_id] ?? null;

    if (input.packet.required_approval && approval?.decision === "rejected") {
      return null;
    }

    const recommendation = recommendWorkboardStatusAfterResult({
      packet: input.packet,
      current_status: input.task.status as WorkboardTaskStatus,
      evidence: input.evidence,
      result_summary: input.intake.result.summary,
      result_details: input.intake.result.details,
      outcome: input.intake.result.outcome,
      approval_recorded: isAgentApprovalRecorded(approval),
      blocker_count: input.intake.blockers.length,
    });

    if (!recommendation.target_status || recommendation.target_status === input.task.status) {
      return null;
    }
    const targetStatus = recommendation.target_status;

    const mutation = await runLegacyMutation(input.task, "status", async () => supabase
      .from("tasks")
      .update({ status: targetStatus, updated_at: new Date().toISOString() })
      .eq("id", input.task.id));
    if (!mutation.ok) {
      return null;
    }
    const { error } = mutation.value;

    if (error) {
      toast.error("작업 상태 자동 변경에 실패했습니다");
      return null;
    }

    setTasks((prev) => prev.map((task) => (
      task.viewKey === input.task.viewKey ? { ...task, status: targetStatus } : task
    )));

    const completed = targetStatus === "done";
    await appendWorkerEvent({
      task: input.task,
      packet: input.packet,
      event_type: completed
        ? "completed"
        : recommendation.reason === "blocked_or_failed_result"
          ? "blocked"
          : "started",
      message: completed
        ? "결과와 증거가 완료 기준을 충족해 작업 상태를 완료로 변경했습니다."
        : "Codex 결과가 저장되어 작업 상태를 진행 중으로 변경했습니다.",
      severity: completed ? "info" : recommendation.reason === "blocked_or_failed_result" ? "warning" : "info",
      requires_user_action: recommendation.reason === "blocked_or_failed_result" && input.intake.blockers.some((blocker) => blocker.requires_user_action),
    });

    return targetStatus;
  };

  const deleteTask = async (viewKey: string) => {
    const task = tasks.find((candidate) => candidate.viewKey === viewKey);
    if (!task) {
      return;
    }
    const mutation = await runLegacyMutation(task, "delete", async () => supabase.from("tasks").delete().eq("id", task.id));
    if (!mutation.ok) {
      return;
    }
    const { error } = mutation.value;
    if (error) {
      toast.error("삭제 실패");
    } else {
      setTasks((prev) => prev.filter((t) => t.viewKey !== task.viewKey));
      setSelectedTaskId((current) => (current === task.viewKey ? null : current));
      toast.success("작업이 삭제되었습니다");
    }
  };

  const runtimeStrategyRefs = useMemo(() => {
    const refs = tasks.flatMap((task) => task.origin === "company_runtime" && task.strategyRef
      ? [task.strategyRef]
      : []);
    return refs.filter((ref, index) => refs.findIndex((candidate) => (
      candidate.strategy_id === ref.strategy_id
      && candidate.strategy_version_id === ref.strategy_version_id
    )) === index);
  }, [tasks]);

  const filtered = useMemo(() => {
    const matches = tasks.filter((task) => {
      const matchesStatus = filter === "all"
        ? true
        : filter === "follow_up"
          ? Boolean(resolveFollowUpLineage(task, tasks, isDemoMode))
          : filter === "blocked"
            ? hasBlockedResult(resultRecordForTask(task, resultRecordByTaskId, isDemoMode))
            : task.status === filter;

      if (!matchesStatus) {
        return false;
      }

      if (!isDemoMode || strategyFilter === "all") {
        return true;
      }

      const draft = resolveWorkboardDraft(task, true);
      const strategyVersionId = draft.packet?.strategy_ref?.strategy_version_id;
      const invalidDemoIntake = hasInvalidDemoIntake(task, draft, true);
      if (strategyFilter === "unlinked") {
        return !strategyVersionId && !invalidDemoIntake;
      }

      return strategyVersionId === strategyFilter;
    });

    return [...matches].sort((a, b) => {
      if (sortBy === "severity") {
        return (severityOrder[a.severity || "low"] ?? 4) - (severityOrder[b.severity || "low"] ?? 4);
      }
      return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
    });
  }, [filter, isDemoMode, resultRecordByTaskId, sortBy, strategyFilter, tasks]);

  useEffect(() => {
    if (filtered.length === 0) {
      if (!loading) {
        setSelectedTaskId(null);
      }
      return;
    }

    if (!selectedTaskId || !filtered.some((task) => task.viewKey === selectedTaskId)) {
      setSelectedTaskId(filtered[0].viewKey);
    }
  }, [filtered, loading, selectedTaskId]);

  const selectedTask = useMemo(
    () => filtered.find((task) => task.viewKey === selectedTaskId) ?? filtered[0] ?? null,
    [filtered, selectedTaskId],
  );
  const selectedFollowUpLineage = useMemo(
    () => (selectedTask ? resolveFollowUpLineage(selectedTask, tasks, isDemoMode) : null),
    [isDemoMode, selectedTask, tasks],
  );

  const selectedGatewayDraft = useMemo(
    () => (selectedTask?.origin === "legacy" ? resolveWorkboardDraft(selectedTask, isDemoMode) : null),
    [isDemoMode, selectedTask],
  );
  const createFormGatewayDraft = useMemo(() => {
    if (!showForm || editingTask || !form.title.trim()) {
      return null;
    }

    return resolveWorkboardDraft({
      id: "preview-workboard-task",
      title: form.title.trim(),
      description: form.description.trim() || null,
      customer: form.customer.trim() || null,
      category: form.category || null,
      severity: form.severity || null,
      status: form.status,
      source: "manual",
      source_id: null,
      created_at: "1970-01-01T00:00:00.000Z",
    }, isDemoMode);
  }, [editingTask, form.category, form.customer, form.description, form.severity, form.status, form.title, isDemoMode, showForm]);
  const createFormPacket = createFormGatewayDraft?.packet ?? null;
  const selectedPacket = selectedTask?.origin === "company_runtime"
    ? selectedTask.packet
    : selectedGatewayDraft?.packet ?? null;
  const selectedWorkboardTaskId = selectedTask?.id ?? null;
  const selectedPacketTaskId = selectedPacket?.task_id ?? null;
  const selectedStrategyVersion = selectedPacket?.strategy_ref
    ? demoStrategyVersions.find((version) => version.strategy_version_id === selectedPacket.strategy_ref?.strategy_version_id)
    : undefined;
  const selectedStrategy = selectedStrategyVersion
    ? demoStrategies.find((strategy) => strategy.strategy_id === selectedStrategyVersion.strategy_id)
    : undefined;
  const selectedEvidence = useMemo(
    () => (selectedPacket ? evidenceByTaskId[selectedPacket.task_id] ?? [] : []),
    [evidenceByTaskId, selectedPacket],
  );
  const selectedApproval = useMemo(
    () => (selectedPacket ? approvalByTaskId[selectedPacket.task_id] ?? null : null),
    [approvalByTaskId, selectedPacket],
  );
  const selectedApprovalRecorded = isAgentApprovalRecorded(selectedApproval);
  const selectedEvents = useMemo(
    () => (selectedPacket ? eventsByTaskId[selectedPacket.task_id] ?? [] : []),
    [eventsByTaskId, selectedPacket],
  );
  const selectedResultPaste = selectedPacket ? resultPasteByTaskId[selectedPacket.task_id] ?? "" : "";
  const selectedParsedResult = selectedPacket ? parsedResultByTaskId[selectedPacket.task_id] ?? null : null;
  const selectedResultRecord = selectedPacket ? resultRecordByTaskId[selectedPacket.task_id] ?? null : null;
  const selectedResultHistory = useMemo(
    () => (selectedPacketTaskId ? resultHistoryByTaskId[selectedPacketTaskId] ?? [] : []),
    [resultHistoryByTaskId, selectedPacketTaskId],
  );
  const selectedResultForDisplay = selectedParsedResult ?? selectedResultRecord;
  const selectedResultGuide = useMemo(
    () => (selectedPacket ? renderManualCodexResultGuide(selectedPacket) : ""),
    [selectedPacket],
  );
  const selectedReverificationEvidence = useMemo(
    () => selectedEvidence.filter((evidence) => (
      evidence.status === "passed" &&
      evidenceWasAddedAfterResult(evidence, selectedResultRecord)
    )),
    [selectedEvidence, selectedResultRecord],
  );
  const selectedCodexHandoff = useMemo(
    () => selectedGatewayDraft
      ? renderHandoffWithReverificationContext(
        selectedGatewayDraft.handoff_markdown,
        selectedResultRecord,
        selectedReverificationEvidence,
      )
      : "",
    [selectedGatewayDraft, selectedResultRecord, selectedReverificationEvidence],
  );
  const selectedHistoricalBlockedResults = useMemo(
    () => previousBlockedResultsFromHistory(selectedResultHistory, selectedResultRecord),
    [selectedResultHistory, selectedResultRecord],
  );
  const selectedFollowUpTaskDraft = useMemo(
    () => selectedTask && selectedPacket && selectedResultRecord
      ? createFollowUpTaskDraft({
        task: selectedTask,
        packet: selectedPacket,
        result: selectedResultRecord,
      })
      : null,
    [selectedPacket, selectedResultRecord, selectedTask],
  );
  const existingSelectedFollowUpTask = useMemo(
    () => selectedFollowUpTaskDraft
      ? tasks.find((task) => task.source === "gateway" && task.source_id === selectedFollowUpTaskDraft.source_id) ?? null
      : null,
    [selectedFollowUpTaskDraft, tasks],
  );
  const evidenceTypeOptions = useMemo(
    () => (selectedPacket ? suggestEvidenceTypesForTask(selectedPacket) : ["manual_observation" as EvidenceType]),
    [selectedPacket],
  );
  const completionPreview = useMemo(
    () => selectedPacket
      ? createTaskCompletionPreview({
        packet: selectedPacket,
        evidence: selectedEvidence,
        result_summary: resultSummaryByTaskId[selectedPacket.task_id],
        outcome: selectedResultForDisplay?.result.outcome,
        next_action: selectedResultForDisplay?.next_action,
      })
      : null,
    [resultSummaryByTaskId, selectedEvidence, selectedPacket, selectedResultForDisplay],
  );
  const canStartSelectedBlockedReverification = useMemo(
    () => Boolean(
      selectedResultForDisplay &&
      (selectedResultForDisplay.result.outcome === "blocked" || selectedResultForDisplay.blockers.length > 0) &&
      selectedReverificationEvidence.length > 0,
    ),
    [selectedResultForDisplay, selectedReverificationEvidence],
  );

  useEffect(() => {
    if (!selectedPacket) {
      setEvidenceForm(emptyEvidenceForm);
      setEvidenceFormTaskId(null);
      return;
    }

    setEvidenceForm((current) => ({
      ...current,
      evidence_type: evidenceFormTaskId === selectedPacket.task_id && evidenceTypeOptions.includes(current.evidence_type)
        ? current.evidence_type
        : evidenceTypeOptions[0] ?? "manual_observation",
    }));
    setEvidenceFormTaskId(selectedPacket.task_id);
  }, [evidenceFormTaskId, evidenceTypeOptions, selectedPacket]);

  useEffect(() => {
    if (!selectedWorkboardTaskId || !selectedPacketTaskId || selectedTask?.origin === "company_runtime") {
      return;
    }

    let cancelled = false;
    setLoadingEvidenceTaskId(selectedWorkboardTaskId);

    const evidenceQuery = supabase
      .from("agent_evidence")
      .select("*")
      .eq("task_id", selectedWorkboardTaskId)
      .eq("packet_task_id", selectedPacketTaskId)
      .order("created_at", { ascending: true });

    void Promise.resolve(evidenceQuery)
      .then(({ data, error }) => {
        if (cancelled) {
          return;
        }

        if (error) {
          toast.error("저장된 증거를 불러오지 못했습니다");
          return;
        }

        setEvidenceByTaskId((prev) => ({
          ...prev,
          [selectedPacketTaskId]: agentEvidenceRowsToEvidenceItems((data ?? []) as AgentEvidenceRow[]),
        }));
      })
      .finally(() => {
        if (!cancelled) {
          setLoadingEvidenceTaskId(null);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [selectedPacketTaskId, selectedTask?.origin, selectedWorkboardTaskId]);

  useEffect(() => {
    if (!selectedWorkboardTaskId || !selectedPacketTaskId || !selectedPacket?.required_approval || selectedTask?.origin === "company_runtime") {
      return;
    }

    let cancelled = false;
    setLoadingApprovalTaskId(selectedWorkboardTaskId);

    const approvalQuery = supabase
      .from("agent_approvals")
      .select("*")
      .eq("task_id", selectedWorkboardTaskId)
      .eq("packet_task_id", selectedPacketTaskId)
      .order("created_at", { ascending: false });

    void Promise.resolve(approvalQuery)
      .then(({ data, error }) => {
        if (cancelled) {
          return;
        }

        if (error) {
          toast.error("승인 기록을 불러오지 못했습니다");
          return;
        }

        setApprovalByTaskId((prev) => ({
          ...prev,
          [selectedPacketTaskId]: latestAgentApprovalRow((data ?? []) as AgentApprovalRow[]),
        }));
      })
      .finally(() => {
        if (!cancelled) {
          setLoadingApprovalTaskId(null);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [selectedPacket?.required_approval, selectedPacketTaskId, selectedTask?.origin, selectedWorkboardTaskId]);

  useEffect(() => {
    if (!selectedWorkboardTaskId || !selectedPacketTaskId || selectedTask?.origin === "company_runtime") {
      return;
    }

    let cancelled = false;
    setLoadingEventsTaskId(selectedWorkboardTaskId);

    const eventsQuery = supabase
      .from("agent_events")
      .select("*")
      .eq("task_id", selectedWorkboardTaskId)
      .eq("packet_task_id", selectedPacketTaskId)
      .order("created_at", { ascending: true });

    void Promise.resolve(eventsQuery)
      .then(({ data, error }) => {
        if (cancelled) {
          return;
        }

        if (error) {
          toast.error("이벤트 타임라인을 불러오지 못했습니다");
          return;
        }

        setEventsByTaskId((prev) => ({
          ...prev,
          [selectedPacketTaskId]: agentEventRowsToWorkerEvents((data ?? []) as AgentEventRow[]),
        }));
      })
      .finally(() => {
        if (!cancelled) {
          setLoadingEventsTaskId(null);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [selectedPacketTaskId, selectedTask?.origin, selectedWorkboardTaskId]);

  useEffect(() => {
    if (!selectedWorkboardTaskId || !selectedPacketTaskId || selectedTask?.origin === "company_runtime") {
      return;
    }

    let cancelled = false;
    setLoadingResultTaskId(selectedWorkboardTaskId);

    const resultsQuery = supabase
      .from("agent_results")
      .select("*")
      .eq("task_id", selectedWorkboardTaskId)
      .eq("packet_task_id", selectedPacketTaskId)
      .order("created_at", { ascending: false });

    void Promise.resolve(resultsQuery)
      .then(({ data, error }) => {
        if (cancelled) {
          return;
        }

        if (error) {
          toast.error("작업 결과를 불러오지 못했습니다");
          return;
        }

        const rows = (data ?? []) as AgentResultRow[];
        const history = resultHistoryFromRows(rows);
        const row = latestAgentResultRow(rows);
        const record = row ? agentResultRowToWorkerResultIntake(row) : null;

        setResultRecordByTaskId((prev) => ({
          ...prev,
          [selectedPacketTaskId]: record,
        }));
        setResultHistoryByTaskId((prev) => ({
          ...prev,
          [selectedPacketTaskId]: history,
        }));

        if (record?.result.summary) {
          setResultSummaryByTaskId((prev) => ({
            ...prev,
            [selectedPacketTaskId]: record.result.summary,
          }));
        }
      })
      .finally(() => {
        if (!cancelled) {
          setLoadingResultTaskId(null);
        }
      });

    return () => {
      cancelled = true;
    };
  }, [selectedPacketTaskId, selectedTask?.origin, selectedWorkboardTaskId]);

  const copyHandoff = async () => {
    const handoff = selectedCodexHandoff;
    if (!handoff) {
      toast.error("복사할 전달문이 없습니다");
      return;
    }
    if (!navigator.clipboard?.writeText) {
      toast.error("클립보드를 사용할 수 없습니다");
      return;
    }

    try {
      await navigator.clipboard.writeText(handoff);
      if (selectedPacket && selectedTask) {
        void appendWorkerEvent({
          task: selectedTask,
          packet: selectedPacket,
          event_type: "plan_created",
          message: "Codex 전달문이 복사되었습니다.",
          severity: "info",
        });
      }
      toast.success("Codex 전달문이 복사되었습니다");
    } catch {
      toast.error("복사에 실패했습니다");
    }
  };

  const copyResultGuide = async () => {
    if (!selectedResultGuide) {
      toast.error("복사할 결과 형식이 없습니다");
      return;
    }
    if (!navigator.clipboard?.writeText) {
      toast.error("클립보드를 사용할 수 없습니다");
      return;
    }

    try {
      await navigator.clipboard.writeText(selectedResultGuide);
      toast.success("결과 형식이 복사되었습니다");
    } catch {
      toast.error("복사에 실패했습니다");
    }
  };

  const createFollowUpTask = async () => {
    if (!selectedTask || !selectedPacket || !selectedFollowUpTaskDraft) {
      toast.error("만들 후속 작업이 없습니다");
      return;
    }

    if (existingSelectedFollowUpTask) {
      setFilter("all");
      setStrategyFilter("all");
      setSelectedTaskId(existingSelectedFollowUpTask.viewKey);
      toast.success("이미 만든 후속 작업으로 이동했습니다");
      return;
    }

    const authority = await runLegacyMutation(selectedTask, "follow_up", async () => true);
    if (!authority.ok) {
      return;
    }

    setCreatingFollowUpTaskId(selectedPacket.task_id);
    const now = new Date().toISOString();
    const { data, error } = await supabase
      .from("tasks")
      .insert({
        title: selectedFollowUpTaskDraft.title,
        description: selectedFollowUpTaskDraft.description,
        customer: selectedFollowUpTaskDraft.customer,
        category: selectedFollowUpTaskDraft.category,
        severity: selectedFollowUpTaskDraft.severity,
        status: selectedFollowUpTaskDraft.status,
        source: selectedFollowUpTaskDraft.source,
        source_id: selectedFollowUpTaskDraft.source_id,
        updated_at: now,
      })
      .select()
      .single();
    setCreatingFollowUpTaskId(null);

    if (error) {
      toast.error("후속 작업 생성에 실패했습니다");
      return;
    }

    if (!data) {
      toast.error("생성된 후속 작업을 확인하지 못했습니다");
      return;
    }

    const createdTask = projectLegacyTask(data);
    setTasks((prev) => [createdTask, ...prev]);
    setFilter("all");
    setStrategyFilter("all");
    setSelectedTaskId(createdTask.viewKey);
    void appendWorkerEvent({
      task: selectedTask,
      packet: selectedPacket,
      event_type: "progress",
      message: `후속 작업이 생성되었습니다: ${data.title}`,
      severity: selectedFollowUpTaskDraft.requires_user_action ? "warning" : "info",
      requires_user_action: selectedFollowUpTaskDraft.requires_user_action,
    });
    toast.success("후속 작업을 만들었습니다");
  };

  const previewPastedWorkerResult = (): ManualCodexResultIntake | null => {
    if (!selectedPacket) {
      toast.error("결과를 붙일 작업이 없습니다");
      return null;
    }
    if (!selectedResultPaste.trim()) {
      toast.error("Codex 결과를 붙여넣어주세요");
      return null;
    }

    const intake = parseManualCodexResult({
      packet: selectedPacket,
      pasted_result: selectedResultPaste,
      evidence_sequence_start: selectedEvidence.length + 1,
      blocker_sequence_start: (selectedResultRecord?.blockers.length ?? 0) + 1,
    });

    setParsedResultByTaskId((prev) => ({
      ...prev,
      [selectedPacket.task_id]: intake,
    }));

    if (!intake.validation.valid) {
      toast.error(displayValidationIssue(intake.validation.issues[0] ?? "결과 형식을 확인해주세요"));
      return intake;
    }

    toast.success("Codex 결과를 구조화했습니다");
    return intake;
  };

  const applyPastedWorkerResult = async () => {
    if (!selectedPacket || !selectedTask) {
      toast.error("결과를 붙일 작업이 없습니다");
      return;
    }

    const authority = await runLegacyMutation(selectedTask, "manual_result", async () => true);
    if (!authority.ok) {
      return;
    }
    if (!selectedResultPaste.trim()) {
      toast.error("Codex 결과를 붙여넣어주세요");
      return;
    }

    const createdAt = new Date().toISOString();
    const intake = parseManualCodexResult({
      packet: selectedPacket,
      pasted_result: selectedResultPaste,
      created_at: createdAt,
      evidence_sequence_start: selectedEvidence.length + 1,
      blocker_sequence_start: (selectedResultRecord?.blockers.length ?? 0) + 1,
    });

    setParsedResultByTaskId((prev) => ({
      ...prev,
      [selectedPacket.task_id]: intake,
    }));

    if (!intake.validation.valid) {
      toast.error(displayValidationIssue(intake.validation.issues[0] ?? "결과 형식을 확인해주세요"));
      return;
    }

    setPersistingResult(true);

    if (intake.evidence.length > 0) {
      const { error: evidenceError } = await supabase
        .from("agent_evidence")
        .insert(intake.evidence.map((evidence) => evidenceItemToAgentEvidenceInsert({
          workboard_task_id: selectedTask.id,
          evidence,
        })));

      if (evidenceError) {
        setPersistingResult(false);
        toast.error("결과 증거 저장에 실패했습니다");
        return;
      }
    }

    const resultRecord: WorkerResultIntakeRecord = {
      result: intake.result,
      blockers: intake.blockers,
      next_action: intake.next_action,
      retention_decision: intake.retention_decision,
      created_at: createdAt,
    };
    const { error: resultError } = await supabase
      .from("agent_results")
      .insert(workerResultToAgentResultInsert({
        workboard_task_id: selectedTask.id,
        packet_task_id: selectedPacket.task_id,
        ...resultRecord,
      }));

    setPersistingResult(false);

    if (resultError) {
      toast.error("작업 결과 저장에 실패했습니다");
      return;
    }

    const nextEvidence = [...selectedEvidence, ...intake.evidence];

    setEvidenceByTaskId((prev) => ({
      ...prev,
      [selectedPacket.task_id]: nextEvidence,
    }));
    setResultRecordByTaskId((prev) => ({
      ...prev,
      [selectedPacket.task_id]: resultRecord,
    }));
    setResultHistoryByTaskId((prev) => ({
      ...prev,
      [selectedPacket.task_id]: [resultRecord, ...(prev[selectedPacket.task_id] ?? [])]
        .sort((a, b) => {
          if (!a.created_at || !b.created_at) {
            return 0;
          }
          return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
        }),
    }));
    setResultSummaryByTaskId((prev) => ({
      ...prev,
      [selectedPacket.task_id]: intake.result.summary,
    }));
    setResultPasteByTaskId((prev) => ({
      ...prev,
      [selectedPacket.task_id]: "",
    }));

    await appendWorkerEvent({
      task: selectedTask,
      packet: selectedPacket,
      event_type: intake.result.outcome === "failed"
        ? "failed"
        : intake.result.outcome === "blocked"
          ? "blocked"
          : "verification_passed",
      message: `Codex 결과가 구조화되었습니다: ${intake.result.summary}`,
      severity: intake.result.outcome === "failed" ? "error" : intake.result.outcome === "blocked" ? "warning" : "info",
      requires_user_action: intake.blockers.some((blocker) => blocker.requires_user_action),
    });

    if (intake.evidence.length > 0) {
      await appendWorkerEvent({
        task: selectedTask,
        packet: selectedPacket,
        event_type: "evidence_added",
        message: `Codex 결과에서 증거 ${intake.evidence.length}개를 추가했습니다.`,
        severity: intake.evidence.some((evidence) => evidence.status === "failed")
          ? "error"
          : intake.evidence.some((evidence) => evidence.status === "warning")
            ? "warning"
            : "info",
        requires_user_action: intake.evidence.some((evidence) => evidence.status === "failed"),
      });
    }

    if (intake.blockers.length > 0) {
      await appendWorkerEvent({
        task: selectedTask,
        packet: selectedPacket,
        event_type: "blocked",
        message: `Codex 결과에 blocker ${intake.blockers.length}개가 포함되었습니다.`,
        severity: "warning",
        requires_user_action: intake.blockers.some((blocker) => blocker.requires_user_action),
      });
    }

    const updatedStatus = await applyResultDrivenStatus({
      task: selectedTask,
      packet: selectedPacket,
      intake,
      evidence: nextEvidence,
    });

    toast.success(updatedStatus === "done" ? "Codex 결과가 반영되어 작업이 완료되었습니다" : "Codex 결과가 작업에 반영되었습니다");
  };

  const recordApprovalDecision = async (decision: ApprovalDecision) => {
    if (!selectedPacket || !selectedTask) {
      toast.error("승인 기록을 붙일 작업이 없습니다");
      return;
    }

    const authority = await runLegacyMutation(selectedTask, "approval", async () => true);
    if (!authority.ok) {
      return;
    }

    const insert = taskPacketToAgentApprovalInsert({
      workboard_task_id: selectedTask.id,
      packet: selectedPacket,
      decision,
    });

    setPersistingApproval(true);
    const { error } = await supabase
      .from("agent_approvals")
      .insert(insert);
    setPersistingApproval(false);

    if (error) {
      toast.error("승인 기록 저장에 실패했습니다");
      return;
    }

    const createdAt = insert.created_at ?? new Date().toISOString();
    const approval: AgentApprovalRow = {
      id: `local-${selectedPacket.task_id}-${createdAt}`,
      owner_id: null,
      task_id: insert.task_id,
      packet_task_id: insert.packet_task_id,
      decision: insert.decision,
      action_type: insert.action_type ?? null,
      approval_reason: insert.approval_reason,
      approved_scope: insert.approved_scope,
      created_at: createdAt,
    };

    setApprovalByTaskId((prev) => ({
      ...prev,
      [selectedPacket.task_id]: approval,
    }));
    void appendWorkerEvent({
      task: selectedTask,
      packet: selectedPacket,
      event_type: decision === "approved" ? "progress" : "blocked",
      message: decision === "approved" ? "명시적 승인이 기록되었습니다." : "승인 거절이 기록되었습니다.",
      severity: decision === "approved" ? "info" : "warning",
      requires_user_action: decision === "rejected",
    });
    toast.success(decision === "approved" ? "승인이 기록되었습니다" : "거절이 기록되었습니다");
  };

  const addEvidence = async () => {
    if (!selectedPacket || !selectedTask) {
      toast.error("증거를 붙일 작업이 없습니다");
      return;
    }

    const authority = await runLegacyMutation(selectedTask, "manual_evidence", async () => true);
    if (!authority.ok) {
      return;
    }
    if (!evidenceForm.summary.trim()) {
      toast.error("증거 요약을 입력해주세요");
      return;
    }

    const result = createTaskEvidenceItem({
      packet: selectedPacket,
      evidence_type: evidenceForm.evidence_type,
      source_system: evidenceForm.source_system,
      status: evidenceForm.status,
      summary: evidenceForm.summary,
      raw_excerpt: evidenceForm.raw_excerpt,
      sequence: selectedEvidence.length + 1,
    });

    if (!result.validation.valid) {
      toast.error(displayValidationIssue(result.validation.issues[0] ?? "증거 형식을 확인해주세요"));
      return;
    }

    const nextEvidence = [...selectedEvidence, result.evidence];
    const nextMissing = createTaskCompletionPreview({
      packet: selectedPacket,
      evidence: nextEvidence,
      result_summary: resultSummaryByTaskId[selectedPacket.task_id],
    }).missing_verification_types;

    setPersistingEvidence(true);
    const { error } = await supabase
      .from("agent_evidence")
      .insert(evidenceItemToAgentEvidenceInsert({
        workboard_task_id: selectedTask.id,
        evidence: result.evidence,
      }));
    setPersistingEvidence(false);

    if (error) {
      toast.error("증거 저장에 실패했습니다");
      return;
    }

    setEvidenceByTaskId((prev) => ({
      ...prev,
      [selectedPacket.task_id]: nextEvidence,
    }));
    setEvidenceForm({
      ...emptyEvidenceForm,
      evidence_type: nextMissing.length > 0
        ? suggestNextEvidenceType(selectedPacket, nextEvidence)
        : evidenceTypeOptions[0] ?? "manual_observation",
    });
    void appendWorkerEvent({
      task: selectedTask,
      packet: selectedPacket,
      event_type: "evidence_added",
      message: `증거 추가: ${result.evidence.summary}`,
      evidence_ref_id: result.evidence.evidence_id,
      severity: result.evidence.status === "failed" ? "error" : result.evidence.status === "warning" ? "warning" : "info",
      requires_user_action: result.evidence.status === "failed",
    });
    toast.success("증거가 저장되었습니다");
  };

  const startBlockerResolutionEvidence = (blockerSummary?: string, suggestedResolution?: string) => {
    if (!selectedPacket || !selectedTask) {
      return;
    }

    const nextEvidenceType = suggestNextEvidenceType(selectedPacket, selectedEvidence);
    const blockerContext = [
      blockerSummary ? `Blocker: ${blockerSummary}` : null,
      suggestedResolution ? `Suggested resolution: ${suggestedResolution}` : null,
    ].filter(Boolean).join("\n");

    setEvidenceForm({
      evidence_type: evidenceTypeOptions.includes(nextEvidenceType)
        ? nextEvidenceType
        : evidenceTypeOptions[0] ?? "manual_observation",
      source_system: "user",
      status: "passed",
      summary: "",
      raw_excerpt: blockerContext,
    });
    setEvidenceFormTaskId(selectedPacket.task_id);
    setHighlightedEvidenceTaskId(selectedTask.viewKey);
  };

  const startBlockedTaskReverification = async () => {
    if (!selectedPacket || !selectedTask || !selectedResultForDisplay) {
      toast.error("재검증할 작업이 없습니다");
      return;
    }

    const authority = await runLegacyMutation(selectedTask, "reverification", async () => true);
    if (!authority.ok) {
      return;
    }

    if (!canStartSelectedBlockedReverification) {
      setHighlightedEvidenceTaskId(selectedTask.viewKey);
      toast.error("blocker 이후의 통과 증거를 먼저 추가해주세요");
      return;
    }

    setStartingReverificationTaskId(selectedTask.id);

    const allowed = await validateTaskStatusChange(selectedTask, "in_progress");

    if (!allowed) {
      setStartingReverificationTaskId(null);
      return;
    }

    if (selectedTask.status !== "in_progress") {
      const { error } = await supabase
        .from("tasks")
        .update({ status: "in_progress", updated_at: new Date().toISOString() })
        .eq("id", selectedTask.id);

      if (error) {
        setStartingReverificationTaskId(null);
        toast.error("재검증 상태 변경에 실패했습니다");
        return;
      }

      setTasks((prev) => prev.map((task) => (
        task.viewKey === selectedTask.viewKey ? { ...task, status: "in_progress" } : task
      )));
    }

    await appendWorkerEvent({
      task: selectedTask,
      packet: selectedPacket,
      event_type: "verification_started",
      message: "blocker 해결 증거가 추가되어 재검증을 시작했습니다.",
      severity: "info",
    });

    setStartingReverificationTaskId(null);
    toast.success("재검증을 시작했습니다");
  };

  const removeEvidence = async (evidenceId: string) => {
    if (!selectedPacket || !selectedTask) {
      return;
    }

    const authority = await runLegacyMutation(selectedTask, "manual_evidence", async () => true);
    if (!authority.ok) {
      return;
    }

    const { error } = await supabase
      .from("agent_evidence")
      .delete()
      .eq("task_id", selectedTask.id)
      .eq("evidence_id", evidenceId);

    if (error) {
      toast.error("증거 삭제에 실패했습니다");
      return;
    }

    setEvidenceByTaskId((prev) => ({
      ...prev,
      [selectedPacket.task_id]: (prev[selectedPacket.task_id] ?? []).filter((item) => item.evidence_id !== evidenceId),
    }));
  };

  const counts = {
    all: tasks.length,
    pending: tasks.filter((t) => t.status === "pending").length,
    in_progress: tasks.filter((t) => t.status === "in_progress").length,
    done: tasks.filter((t) => t.status === "done").length,
    follow_up: tasks.filter((task) => resolveFollowUpLineage(task, tasks, isDemoMode)).length,
    blocked: tasks.filter((task) => hasBlockedResult(resultRecordForTask(task, resultRecordByTaskId, isDemoMode))).length,
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-3 px-6 py-4 border-b border-border/50">
        <button onClick={onBack} className="w-8 h-8 rounded-lg hover:bg-secondary flex items-center justify-center transition-colors">
          <ArrowLeft className="w-4 h-4 text-muted-foreground" />
        </button>
        <div className="flex-1">
          <h2 className="text-[14px] font-semibold">작업 관리</h2>
          <p className="text-[11px] text-muted-foreground">등록된 대응 액션 및 업무 목록</p>
        </div>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={openCreate}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-medium transition-colors"
          style={{ background: "hsl(var(--primary))", color: "hsl(var(--primary-foreground))" }}
        >
          <Plus className="w-3.5 h-3.5" />
          새 작업
        </motion.button>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={fetchTasks}
          disabled={loading}
          className="w-8 h-8 rounded-lg hover:bg-secondary flex items-center justify-center transition-colors"
        >
          <RefreshCw className={`w-4 h-4 text-muted-foreground ${loading ? "animate-spin" : ""}`} />
        </motion.button>
      </div>

      {/* Filters */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border/30 px-6 py-2.5">
        <div className="flex flex-wrap items-center gap-1.5">
          {taskFilterOptions.map(({ key, label }) => (
            <button
              key={key}
              onClick={() => setFilter(key)}
              className={`px-3 py-1 rounded-md text-[10px] font-medium transition-all ${
                filter === key ? "bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {label} {counts[key]}
            </button>
          ))}
        </div>
        <div className="flex items-center gap-1">
          {isDemoMode && (
            <label className="mr-2 flex items-center gap-1.5 text-[9px] text-muted-foreground">
              <span>가상 데이터 · 새로고침 시 초기화</span>
              <select
                aria-label="전략 버전 필터"
                value={strategyFilter}
                onChange={(event) => setStrategyFilter(event.target.value)}
                className="h-7 max-w-[190px] rounded-md border border-border/40 bg-background px-2 text-[10px] text-foreground outline-none"
              >
                <option value="all">전략 전체</option>
                <option value="unlinked">전략 미연결</option>
                {demoStrategyVersions.map((version) => {
                  const strategy = demoStrategies.find((item) => item.strategy_id === version.strategy_id);
                  return (
                    <option key={version.strategy_version_id} value={version.strategy_version_id}>
                      {strategy?.title ?? version.strategy_id} v{version.version}
                    </option>
                  );
                })}
                {runtimeStrategyRefs
                  .filter((ref) => !demoStrategyVersions.some((version) => version.strategy_version_id === ref.strategy_version_id))
                  .map((ref) => (
                    <option key={ref.strategy_version_id} value={ref.strategy_version_id}>
                      {ref.strategy_id} · 고정 버전
                    </option>
                  ))}
              </select>
            </label>
          )}
          <span className="text-[9px] text-muted-foreground mr-1">정렬:</span>
          {([["date", "최신순"], ["severity", "우선순위"]] as ["date" | "severity", string][]).map(([key, label]) => (
            <button
              key={key}
              onClick={() => setSortBy(key)}
              className={`px-2 py-0.5 rounded text-[9px] font-medium transition-all ${
                sortBy === key ? "bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* Create/Edit Form */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden border-b border-border/30"
          >
            <div className="px-6 py-4 space-y-3 bg-secondary/10">
              <div className="flex items-center justify-between">
                <h3 className="text-[12px] font-semibold">{editingTask ? "작업 수정" : "새 작업 생성"}</h3>
                <button onClick={closeForm} className="w-6 h-6 rounded-md hover:bg-secondary flex items-center justify-center">
                  <X className="w-3.5 h-3.5 text-muted-foreground" />
                </button>
              </div>

              <input
                type="text"
                placeholder="제목 *"
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
                className="w-full px-3 py-2 rounded-lg bg-background border border-border/50 text-[12px] text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:border-primary/50"
              />

              <textarea
                placeholder="설명 (선택)"
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                rows={2}
                className="w-full px-3 py-2 rounded-lg bg-background border border-border/50 text-[12px] text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:border-primary/50 resize-none"
              />

              <div className="grid grid-cols-4 gap-2">
                <input
                  type="text"
                  placeholder="고객사"
                  value={form.customer}
                  onChange={(e) => setForm({ ...form, customer: e.target.value })}
                  className="px-3 py-1.5 rounded-lg bg-background border border-border/50 text-[11px] text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:border-primary/50"
                />
                <select
                  value={form.category}
                  onChange={(e) => setForm({ ...form, category: e.target.value })}
                  className="px-2 py-1.5 rounded-lg bg-background border border-border/50 text-[11px] text-foreground focus:outline-none focus:border-primary/50"
                >
                  <option value="">카테고리</option>
                  <option value="delivery">납기</option>
                  <option value="quality">품질</option>
                  <option value="price">가격</option>
                </select>
                <select
                  value={form.severity}
                  onChange={(e) => setForm({ ...form, severity: e.target.value })}
                  className="px-2 py-1.5 rounded-lg bg-background border border-border/50 text-[11px] text-foreground focus:outline-none focus:border-primary/50"
                >
                  <option value="low">낮음</option>
                  <option value="medium">보통</option>
                  <option value="high">높음</option>
                  <option value="critical">심각</option>
                </select>
                <select
                  value={form.status}
                  onChange={(e) => setForm({ ...form, status: e.target.value })}
                  className="px-2 py-1.5 rounded-lg bg-background border border-border/50 text-[11px] text-foreground focus:outline-none focus:border-primary/50"
                >
                  <option value="pending">대기</option>
                  <option value="in_progress">진행 중</option>
                  <option value="done">완료</option>
                </select>
              </div>

              {createFormPacket && (
                <section
                  aria-label="새 작업 Gateway 판단 미리보기"
                  className="rounded-lg border border-border/50 bg-background/70 p-3"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-2">
                      <span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-md bg-primary/10 text-primary">
                        <Bot className="h-3.5 w-3.5" />
                      </span>
                      <div className="min-w-0">
                        <p className="text-[11px] font-semibold text-foreground">Gateway 판단 미리보기</p>
                        <p className="mt-0.5 text-[10px] text-muted-foreground">
                          저장하면 이 판단을 기준으로 작업 패킷이 고정됩니다
                        </p>
                      </div>
                    </div>
                    <div className="flex shrink-0 flex-wrap justify-end gap-1.5">
                      <span className="inline-flex h-6 items-center rounded-md border border-primary/20 bg-primary/10 px-2 text-[10px] font-medium text-primary">
                        {displayTaskType(createFormPacket.task_type)}
                      </span>
                      <span className={`inline-flex h-6 items-center rounded-md border px-2 text-[10px] font-medium ${riskTone[createFormPacket.risk_level] ?? riskTone.blocked}`}>
                        위험도 {displayRisk(createFormPacket.risk_level)}
                      </span>
                      <span className={`inline-flex h-6 items-center rounded-md border px-2 text-[10px] font-medium ${
                        createFormPacket.required_approval
                          ? "border-red-500/20 bg-red-500/10 text-red-300"
                          : "border-emerald-500/20 bg-emerald-500/10 text-emerald-300"
                      }`}
                      >
                        {createFormPacket.required_approval ? "승인 필요" : "승인 불필요"}
                      </span>
                    </div>
                  </div>

                  <div className="mt-3 grid gap-2 md:grid-cols-2">
                    <div>
                      <p className="text-[9px] font-medium uppercase text-muted-foreground">필수 확인</p>
                      <div className="mt-1 flex flex-wrap gap-1.5">
                        {createFormPacket.verification_requirements.map((requirement) => (
                          <span
                            key={requirement.type}
                            className="inline-flex h-5 items-center rounded-md border border-border/50 bg-secondary/40 px-1.5 text-[9px] text-muted-foreground"
                          >
                            {verificationLabels[requirement.type] ?? requirement.type}
                          </span>
                        ))}
                      </div>
                    </div>
                    <div>
                      <p className="text-[9px] font-medium uppercase text-muted-foreground">금지 작업</p>
                      <div className="mt-1 flex flex-wrap gap-1.5">
                        {createFormPacket.forbidden_actions.slice(0, 3).map((action) => (
                          <span
                            key={action}
                            className="inline-flex h-5 items-center rounded-md border border-border/50 bg-secondary/40 px-1.5 text-[9px] text-muted-foreground"
                          >
                            {displayForbiddenAction(action)}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                </section>
              )}

              <div className="flex justify-end gap-2">
                <button
                  onClick={closeForm}
                  className="px-3 py-1.5 rounded-lg text-[11px] font-medium text-muted-foreground hover:bg-secondary transition-colors"
                >
                  취소
                </button>
                <button
                  onClick={handleSave}
                  disabled={saving}
                  className="px-4 py-1.5 rounded-lg text-[11px] font-semibold transition-colors flex items-center gap-1.5"
                  style={{ background: "hsl(var(--primary))", color: "hsl(var(--primary-foreground))" }}
                >
                  {saving && <Loader2 className="w-3 h-3 animate-spin" />}
                  {editingTask ? "수정" : "생성"}
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Task list */}
      <div className="grid min-h-0 flex-1 grid-cols-1 lg:grid-cols-[minmax(0,1fr)_360px]">
        <div aria-label="작업 목록" className="min-h-0 overflow-y-auto px-6 py-3 pb-24 space-y-2 scrollbar-thin">
          {loading ? (
            <div className="flex items-center justify-center h-40">
              <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
            </div>
          ) : filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-40 gap-2">
              <CheckCircle2 className="w-8 h-8 text-muted-foreground/30" />
              <p className="text-[11px] text-muted-foreground">
                {filter === "all" ? "등록된 작업이 없습니다" : "조건에 맞는 작업이 없습니다"}
              </p>
            </div>
          ) : (
            <AnimatePresence>
              {filtered.map((task, i) => {
                const st = statusMeta[task.status] || statusMeta.pending;
                const sev = task.severity ? severityMeta[task.severity] : null;
                const CatIcon = task.category ? categoryIcon[task.category] : null;
                const selected = selectedTask?.viewKey === task.viewKey;
                const cardDraft = resolveWorkboardDraft(task, isDemoMode);
                const cardResult = cardDraft.packet ? resultRecordByTaskId[cardDraft.packet.task_id] ?? null : null;
                const cardResultHistory = cardDraft.packet ? resultHistoryByTaskId[cardDraft.packet.task_id] ?? [] : [];
                const cardPreviousBlockedResults = previousBlockedResultsFromHistory(cardResultHistory, cardResult);
                const cardApprovalTone = cardDraft.packet?.required_approval
                  ? "border-red-500/20 bg-red-500/10 text-red-300"
                  : "border-emerald-500/20 bg-emerald-500/10 text-emerald-300";
                const cardBlocker = cardResult?.blockers[0];
                const cardFollowUp = cardBlocker?.summary ?? cardResult?.next_action;
                const cardLineage = resolveFollowUpLineage(task, tasks, isDemoMode);
                const cardStrategyVersion = cardDraft.packet?.strategy_ref
                  ? demoStrategyVersions.find((version) => version.strategy_version_id === cardDraft.packet?.strategy_ref?.strategy_version_id)
                  : undefined;
                const invalidDemoIntake = hasInvalidDemoIntake(task, cardDraft, isDemoMode);
                const runtimeGuidance = task.origin === "company_runtime" && task.card
                  ? selectCompanyTaskGuidance(task.card)
                  : null;
                return (
                  <motion.div
                    key={task.viewKey}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ delay: i * 0.03 }}
                    onClick={() => setSelectedTaskId(task.viewKey)}
                    onKeyDown={(event) => {
                      if (event.key === "Enter" || event.key === " ") {
                        setSelectedTaskId(task.viewKey);
                      }
                    }}
                    role="button"
                    tabIndex={0}
                    aria-pressed={selected}
                    className={`p-3.5 rounded-xl border bg-secondary/10 hover:border-border/60 transition-all group outline-none ${
                      selected ? "border-primary/50 ring-1 ring-primary/20" : "border-border/30"
                    }`}
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className={`text-[9px] px-1.5 py-0.5 rounded border font-medium ${st.bg} ${st.color}`}>{st.label}</span>
                        {sev && <span className={`text-[9px] ${sev.color} font-medium`}>{sev.label}</span>}
                        {CatIcon && <CatIcon className="w-3 h-3 text-muted-foreground" />}
                        {task.source === "risk" && (
                          <span className="text-[9px] px-1.5 py-0.5 rounded bg-status-alert/10 text-status-alert font-medium">리스크</span>
                        )}
                        {task.source === "gateway" && (
                          <span className="text-[9px] px-1.5 py-0.5 rounded bg-primary/10 text-primary font-medium">Gateway</span>
                        )}
                        {task.origin === "company_runtime" && runtimeGuidance ? (
                          <span className="text-[9px] px-1.5 py-0.5 rounded border font-medium border-blue-500/20 bg-blue-500/10 text-blue-300">
                            {runtimeGuidance.pinnedStrategy}
                          </span>
                        ) : isDemoMode && (
                          <span className={`text-[9px] px-1.5 py-0.5 rounded border font-medium ${
                            invalidDemoIntake
                              ? "border-amber-500/20 bg-amber-500/10 text-amber-300"
                              : cardStrategyVersion
                                ? "border-blue-500/20 bg-blue-500/10 text-blue-300"
                                : "border-border/40 bg-background/60 text-muted-foreground"
                          }`}>
                            {invalidDemoIntake ? "검토 필요" : cardStrategyVersion ? `전략 v${cardStrategyVersion.version}` : "전략 미연결"}
                          </span>
                        )}
                        {cardLineage && (
                          <span className="text-[9px] px-1.5 py-0.5 rounded bg-blue-500/10 text-blue-300 font-medium">파생</span>
                        )}
                        {cardResult && (
                          <span className={`text-[9px] px-1.5 py-0.5 rounded border font-medium ${workerOutcomeTone[cardResult.result.outcome] ?? workerOutcomeTone.advisory_only}`}>
                            최신 {displayWorkerOutcome(cardResult.result.outcome)}
                          </span>
                        )}
                        {cardPreviousBlockedResults.length > 0 && (
                          <span className="text-[9px] px-1.5 py-0.5 rounded border border-amber-500/20 bg-amber-500/10 text-amber-300 font-medium">
                            이전 blocker {cardPreviousBlockedResults.length}
                          </span>
                        )}
                      </div>
                      {task.origin === "legacy" && <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={(event) => {
                            event.stopPropagation();
                            openEdit(task);
                          }}
                          className="w-6 h-6 rounded-md hover:bg-secondary flex items-center justify-center"
                          aria-label="작업 수정"
                        >
                          <Pencil className="w-3 h-3 text-muted-foreground" />
                        </button>
                        <button
                          onClick={(event) => {
                            event.stopPropagation();
                            deleteTask(task.viewKey);
                          }}
                          className="w-6 h-6 rounded-md hover:bg-destructive/20 flex items-center justify-center"
                          aria-label="작업 삭제"
                        >
                          <Trash2 className="w-3 h-3 text-muted-foreground" />
                        </button>
                      </div>}
                    </div>

                    <h3 className="text-[12px] font-medium text-foreground mb-1">{task.title}</h3>

                    {task.description && (
                      <p className="text-[10px] text-muted-foreground line-clamp-2 mb-2">{task.description}</p>
                    )}

                    {task.origin === "legacy" && cardDraft.packet && (
                      <div
                        aria-label={`${task.title} Gateway 판단 신호`}
                        className="mb-2 flex flex-wrap gap-1.5"
                      >
                        <span className="inline-flex h-5 items-center rounded-md border border-border/40 bg-background/60 px-1.5 text-[9px] font-medium text-muted-foreground">
                          업무 {displayTaskType(cardDraft.packet.task_type)}
                        </span>
                        <span className={`inline-flex h-5 items-center rounded-md border px-1.5 text-[9px] font-medium ${riskTone[cardDraft.packet.risk_level] ?? riskTone.blocked}`}>
                          위험도 {displayRisk(cardDraft.packet.risk_level)}
                        </span>
                        <span className={`inline-flex h-5 items-center rounded-md border px-1.5 text-[9px] font-medium ${cardApprovalTone}`}>
                          {cardDraft.packet.required_approval ? "승인 필요" : "승인 불필요"}
                        </span>
                      </div>
                    )}

                    {runtimeGuidance && (
                      <div aria-label={`${task.title} 저장된 실행 상태`} className="mb-2 grid gap-1 rounded-md border border-border/40 bg-background/50 px-2 py-1.5 text-[9px] text-muted-foreground sm:grid-cols-2">
                        <span>{runtimeGuidance.approval}</span>
                        <span>{runtimeGuidance.execution}</span>
                        <span>{runtimeGuidance.readback}</span>
                        <span>{runtimeGuidance.businessOutcome}</span>
                        <p className="sm:col-span-2 text-foreground">{runtimeGuidance.nextAction}</p>
                      </div>
                    )}

                    {cardLineage && (
                      <div
                        aria-label={`${task.title} 파생 원 작업`}
                        className="mb-2 rounded-md border border-border/40 bg-background/50 px-2 py-1.5"
                      >
                        <p className="text-[9px] font-medium text-muted-foreground">원 작업</p>
                        <p className="mt-0.5 truncate text-[10px] text-foreground">
                          {cardLineage.origin_title ?? cardLineage.origin_packet_id}
                        </p>
                      </div>
                    )}

                    {cardResult && cardFollowUp && (
                      <button
                        type="button"
                        aria-label={`${task.title} 후속 액션 보기`}
                        onClick={(event) => {
                          event.stopPropagation();
                          focusTaskFollowUp(task);
                        }}
                        className="mb-2 w-full rounded-md border border-border/40 bg-background/60 px-2 py-1.5 text-left transition-colors hover:border-primary/40 hover:bg-primary/5"
                      >
                        <div className="flex items-start justify-between gap-2">
                          <p className="min-w-0 truncate text-[10px] leading-relaxed text-foreground">
                            {cardBlocker ? "보류: " : "다음: "}{cardFollowUp}
                          </p>
                          {cardBlocker?.requires_user_action && (
                            <span className="shrink-0 rounded border border-amber-500/20 bg-amber-500/10 px-1.5 py-0.5 text-[9px] font-medium text-amber-300">
                              확인 필요
                            </span>
                          )}
                        </div>
                      </button>
                    )}

                    <div className="flex items-center justify-between gap-3">
                      <div className="flex items-center gap-3">
                        {task.customer && (
                          <span className="text-[9px] text-muted-foreground/70 flex items-center gap-1">
                            <Building2 className="w-2.5 h-2.5" />{task.customer}
                          </span>
                        )}
                        <span className="text-[9px] text-muted-foreground/50 flex items-center gap-1">
                          <Clock className="w-2.5 h-2.5" />{new Date(task.created_at).toLocaleDateString("ko-KR")}
                        </span>
                      </div>

                      {task.origin === "legacy" && !invalidDemoIntake && <div className="flex items-center gap-1">
                        {task.status !== "pending" && (
                          <button
                            onClick={(event) => {
                              event.stopPropagation();
                              updateStatus(task.viewKey, "pending");
                            }}
                            className="text-[9px] px-2 py-0.5 rounded-md bg-yellow-500/10 text-yellow-400 hover:bg-yellow-500/20 transition-colors"
                          >
                            대기
                          </button>
                        )}
                        {task.status !== "in_progress" && (
                          <button
                            onClick={(event) => {
                              event.stopPropagation();
                              updateStatus(task.viewKey, "in_progress");
                            }}
                            className="text-[9px] px-2 py-0.5 rounded-md bg-blue-500/10 text-blue-400 hover:bg-blue-500/20 transition-colors"
                          >
                            진행
                          </button>
                        )}
                        {task.status !== "done" && (
                          <button
                            onClick={(event) => {
                              event.stopPropagation();
                              updateStatus(task.viewKey, "done");
                            }}
                            className="text-[9px] px-2 py-0.5 rounded-md bg-green-500/10 text-green-400 hover:bg-green-500/20 transition-colors"
                          >
                            완료
                          </button>
                        )}
                      </div>}
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          )}
        </div>

        <aside
          aria-label="Gateway 작업 판단"
          className="min-h-0 border-t border-border/40 bg-background/60 p-4 lg:border-l lg:border-t-0 lg:overflow-y-auto lg:scrollbar-thin"
        >
          {selectedTask?.origin === "company_runtime" ? (
            <div className="space-y-4">
              <CompanyTaskPanel task={selectedTask} />
              <CompanyLineagePanel
                originTaskId={selectedTask.id}
                onOpenTask={(taskId) => {
                  const target = tasks.find((task) => task.origin === "company_runtime" && task.id === taskId);
                  if (target) {
                    setFilter("all");
                    setStrategyFilter("all");
                    setSelectedTaskId(target.viewKey);
                  }
                }}
              />
            </div>
          ) : selectedTask && selectedGatewayDraft?.packet && selectedPacketTaskId ? (
            <div className="space-y-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <Bot className="h-4 w-4 text-primary" />
                    <h3 className="text-[13px] font-semibold">Gateway 작업 판단</h3>
                  </div>
                  <p className="mt-1 line-clamp-2 text-[11px] text-muted-foreground">{selectedTask.title}</p>
                  {selectedTask.source === "gateway" && (
                    <div className="mt-2 flex flex-wrap items-center gap-1.5">
                      <span className="inline-flex h-5 items-center rounded-md border border-primary/20 bg-primary/10 px-2 text-[10px] font-medium text-primary">
                        {selectedFollowUpLineage ? "Gateway 후속 작업" : "Gateway에서 생성됨"}
                      </span>
                      {selectedTask.source_id && (
                        <span className="inline-flex h-5 max-w-full items-center truncate rounded-md border border-border/40 bg-background px-2 text-[10px] text-muted-foreground">
                          {selectedFollowUpLineage ? "원 작업 연결됨" : "원본 작업 ID 유지"}
                        </span>
                      )}
                    </div>
                  )}
                </div>
                <button
                  onClick={() => void copyHandoff()}
                  className="flex shrink-0 items-center gap-1.5 rounded-lg border border-border/40 bg-secondary/20 px-2.5 py-1.5 text-[11px] font-medium transition-colors hover:bg-secondary"
                >
                  <Copy className="h-3.5 w-3.5" />
                  전달문 복사
                </button>
              </div>

              {selectedStrategy && selectedStrategyVersion && (
                <>
                  <StrategySummary
                    strategy={selectedStrategy}
                    version={selectedStrategyVersion}
                    showFixtureNote
                  />
                  <section aria-label="보존된 원 요청" className="rounded-lg border border-border/40 bg-secondary/10 p-3">
                    <p className="text-[10px] text-muted-foreground">보존된 원 요청</p>
                    <p className="mt-1 text-[11px] leading-relaxed text-foreground">{selectedGatewayDraft.packet.raw_user_request}</p>
                  </section>
                </>
              )}

              {selectedFollowUpLineage && (
                <section aria-label="작업 파생 관계" className="rounded-lg border border-blue-500/20 bg-blue-500/10 p-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="text-[10px] text-blue-200/80">파생 관계</p>
                      <p className="mt-1 text-[12px] font-semibold text-foreground">
                        {selectedFollowUpLineage.origin_title ?? "원 작업 확인 필요"}
                      </p>
                      {selectedFollowUpLineage.follow_up_action && (
                        <p className="mt-1 text-[11px] leading-relaxed text-muted-foreground">
                          {selectedFollowUpLineage.follow_up_action}
                        </p>
                      )}
                    </div>
                    {selectedFollowUpLineage.origin_task && (
                      <button
                        type="button"
                        onClick={() => {
                          setFilter("all");
                          setStrategyFilter("all");
                          setSelectedTaskId(selectedFollowUpLineage.origin_task!.viewKey);
                        }}
                        className="inline-flex h-7 shrink-0 items-center gap-1 rounded-md border border-border/40 bg-background px-2 text-[10px] font-medium text-foreground transition-colors hover:bg-secondary"
                      >
                        <ArrowLeft className="h-3 w-3" />
                        원 작업 보기
                      </button>
                    )}
                  </div>
                  {!selectedFollowUpLineage.origin_task && (
                    <p className="mt-2 rounded-md border border-border/40 bg-background/60 px-2 py-1.5 text-[10px] text-muted-foreground">
                      연결 ID: {selectedFollowUpLineage.origin_packet_id}
                    </p>
                  )}
                </section>
              )}

              <div aria-label="전략 작업 상태" className="grid grid-cols-2 gap-2">
                <div className="rounded-lg border border-border/40 bg-secondary/10 p-3">
                  <p className="text-[10px] text-muted-foreground">작업 종류</p>
                  <p className="mt-1 text-[12px] font-semibold text-foreground">
                    {displayTaskType(selectedGatewayDraft.packet.task_type)}
                  </p>
                </div>
                <div className="rounded-lg border border-border/40 bg-secondary/10 p-3">
                  <p className="text-[10px] text-muted-foreground">접수 시 상태</p>
                  <p className="mt-1 text-[12px] font-semibold text-foreground">
                    {displayGatewayStatus(selectedGatewayDraft.packet.status)}
                  </p>
                  <p className="mt-1 text-[10px] text-muted-foreground">
                    현재 Workboard 상태
                    <span className="ml-1 font-medium text-foreground">
                      {statusMeta[selectedTask.status]?.label ?? selectedTask.status}
                    </span>
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                <span className={`inline-flex h-6 items-center rounded-md border px-2 text-[11px] font-medium ${riskTone[selectedGatewayDraft.packet.risk_level] ?? riskTone.blocked}`}>
                  위험도 {displayRisk(selectedGatewayDraft.packet.risk_level)}
                </span>
                <span className={`inline-flex h-6 items-center rounded-md border px-2 text-[11px] font-medium ${
                  selectedApprovalRecorded
                    ? "border-emerald-500/20 bg-emerald-500/10 text-emerald-300"
                    : selectedApproval?.decision === "rejected"
                      ? "border-muted-foreground/20 bg-secondary text-muted-foreground"
                      : selectedGatewayDraft.packet.required_approval
                    ? "border-red-500/20 bg-red-500/10 text-red-300"
                    : "border-emerald-500/20 bg-emerald-500/10 text-emerald-300"
                }`}>
                  {selectedGatewayDraft.packet.required_approval
                    ? displayApprovalDecision(selectedApproval?.decision)
                    : "승인 불필요"}
                </span>
              </div>

              <section className="rounded-lg border border-border/40 bg-secondary/10 p-3">
                <p className="text-[10px] text-muted-foreground">판단 요약</p>
                <p className="mt-1 text-[12px] leading-relaxed text-foreground">
                  {selectedGatewayDraft.suggestion.request_summary}
                </p>
                <p className="mt-2 text-[10px] text-muted-foreground">완료 기준</p>
                <p className="mt-1 text-[11px] leading-relaxed text-muted-foreground">
                  {selectedGatewayDraft.suggestion.desired_outcome}
                </p>
              </section>

              <section className="rounded-lg border border-border/40 bg-secondary/10 p-3">
                <p className="mb-2 text-[10px] font-medium text-muted-foreground">필요한 증거</p>
                <div className="flex flex-wrap gap-1.5">
                  {selectedGatewayDraft.packet.verification_requirements.map((requirement) => (
                    <span key={`${requirement.type}-${requirement.command_or_source}`} className="inline-flex h-6 items-center rounded-md border border-border/40 bg-background px-2 text-[11px] text-foreground">
                      {verificationLabels[requirement.type] ?? requirement.type}
                    </span>
                  ))}
                </div>
              </section>

              <section className="rounded-lg border border-border/40 bg-secondary/10 p-3">
                <p className="mb-2 text-[10px] font-medium text-muted-foreground">금지 작업</p>
                <div className="flex flex-wrap gap-1.5">
                  {selectedGatewayDraft.packet.forbidden_actions.map((action) => (
                    <span key={action} className="inline-flex min-h-6 items-center rounded-md border border-border/40 bg-background px-2 py-1 text-[11px] text-foreground">
                      {displayForbiddenAction(action)}
                    </span>
                  ))}
                </div>
              </section>

              {selectedGatewayDraft.packet.required_approval && (
                <section aria-label="승인 게이트" className="rounded-lg border border-border/40 bg-secondary/10 p-3">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-[10px] text-muted-foreground">승인 게이트</p>
                      <p className="mt-1 text-[12px] font-semibold text-foreground">
                        {loadingApprovalTaskId === selectedTask.id ? "확인 중" : displayApprovalDecision(selectedApproval?.decision)}
                      </p>
                    </div>
                    <span className={`inline-flex h-6 shrink-0 items-center rounded-md border px-2 text-[11px] font-medium ${
                      selectedApprovalRecorded
                        ? "border-emerald-500/20 bg-emerald-500/10 text-emerald-300"
                        : selectedApproval?.decision === "rejected"
                          ? "border-muted-foreground/20 bg-secondary text-muted-foreground"
                          : "border-red-500/20 bg-red-500/10 text-red-300"
                    }`}>
                      {selectedApprovalRecorded ? "기록됨" : "대기"}
                    </span>
                  </div>
                  <p className="mt-2 text-[11px] leading-relaxed text-muted-foreground">
                    {selectedGatewayDraft.packet.approval_reason ?? "이 작업은 명시적 승인이 필요합니다."}
                  </p>
                  {selectedApproval && (
                    <p className="mt-2 rounded-md border border-border/40 bg-background/70 px-2 py-1.5 text-[10px] leading-relaxed text-muted-foreground">
                      {selectedApproval.approved_scope}
                    </p>
                  )}
                  <div className="mt-3 grid grid-cols-2 gap-2">
                    <button
                      onClick={() => void recordApprovalDecision("approved")}
                      disabled={persistingApproval}
                      className="h-8 rounded-lg border border-emerald-500/20 bg-emerald-500/10 text-[11px] font-medium text-emerald-300 transition-colors hover:bg-emerald-500/15 disabled:cursor-not-allowed disabled:opacity-60"
                    >
                      {persistingApproval ? "저장 중" : "승인 기록"}
                    </button>
                    <button
                      onClick={() => void recordApprovalDecision("rejected")}
                      disabled={persistingApproval}
                      className="h-8 rounded-lg border border-border/40 bg-background text-[11px] font-medium text-muted-foreground transition-colors hover:bg-secondary disabled:cursor-not-allowed disabled:opacity-60"
                    >
                      거절 기록
                    </button>
                  </div>
                </section>
              )}

              <section className="rounded-lg border border-border/40 bg-secondary/10 p-3">
                <p className="text-[10px] text-muted-foreground">다음 행동</p>
                <p className="mt-1 text-[11px] leading-relaxed text-foreground">
                  {selectedApproval?.decision === "approved"
                    ? "승인이 기록되었습니다. 승인 범위 안에서 진행하고, 완료 전에는 증거를 붙입니다."
                    : selectedApproval?.decision === "rejected"
                      ? "승인이 거절되었습니다. 진행하려면 범위를 조정하거나 새 승인을 기록해야 합니다."
                      : selectedGatewayDraft.packet.required_approval
                    ? "승인 전에는 읽기 전용 확인만 진행합니다. 실제 변경은 범위를 다시 확인한 뒤 진행합니다."
                    : "전달문을 복사해 Codex에게 넘기고, 결과와 증거를 다시 작업에 붙이면 됩니다."}
                </p>
              </section>

              {selectedResultForDisplay && (
                selectedResultForDisplay.blockers.length > 0 ||
                selectedResultForDisplay.next_action ||
                selectedResultForDisplay.retention_decision
              ) && (
                <section
                  ref={followUpSectionRef}
                  aria-label="작업 후속 액션"
                  tabIndex={-1}
                  className={`rounded-lg border p-3 outline-none transition-colors ${
                    highlightedFollowUpTaskId === selectedTask.viewKey
                      ? "border-primary/50 bg-primary/5 ring-1 ring-primary/25"
                      : "border-border/40 bg-secondary/10"
                  }`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="text-[10px] text-muted-foreground">작업 후속 액션</p>
                      <p className="mt-1 text-[12px] font-semibold text-foreground">
                        {selectedResultForDisplay.blockers.length > 0
                          ? "보류 항목 확인"
                          : selectedResultForDisplay.next_action
                            ? "다음 행동 대기"
                            : "저장 제안 검토"}
                      </p>
                    </div>
                    <div className="flex shrink-0 items-center gap-1.5">
                      {selectedResultForDisplay.blockers.length > 0 && (
                        <button
                          type="button"
                          onClick={() => void startBlockedTaskReverification()}
                          disabled={!canStartSelectedBlockedReverification || startingReverificationTaskId === selectedTask.id}
                          className="inline-flex h-6 items-center gap-1 rounded-md border border-blue-500/20 bg-blue-500/10 px-2 text-[10px] font-medium text-blue-300 transition-colors hover:bg-blue-500/15 disabled:cursor-not-allowed disabled:opacity-50"
                        >
                          {startingReverificationTaskId === selectedTask.id ? (
                            <Loader2 className="h-3 w-3 animate-spin" />
                          ) : (
                            <RefreshCw className="h-3 w-3" />
                          )}
                          재검증 시작
                        </button>
                      )}
                      {selectedFollowUpTaskDraft && (
                        <button
                          type="button"
                          onClick={() => void createFollowUpTask()}
                          disabled={creatingFollowUpTaskId === selectedGatewayDraft.packet.task_id}
                          className="inline-flex h-6 items-center gap-1 rounded-md border border-border/40 bg-background px-2 text-[10px] font-medium text-foreground transition-colors hover:bg-secondary disabled:cursor-not-allowed disabled:opacity-60"
                        >
                          {creatingFollowUpTaskId === selectedGatewayDraft.packet.task_id ? (
                            <Loader2 className="h-3 w-3 animate-spin" />
                          ) : (
                            <Plus className="h-3 w-3" />
                          )}
                          {existingSelectedFollowUpTask ? "후속 작업 보기" : "후속 작업 만들기"}
                        </button>
                      )}
                      <span className={`inline-flex h-6 items-center rounded-md border px-2 text-[11px] font-medium ${workerOutcomeTone[selectedResultForDisplay.result.outcome] ?? workerOutcomeTone.advisory_only}`}>
                        {displayWorkerOutcome(selectedResultForDisplay.result.outcome)}
                      </span>
                    </div>
                  </div>

                  {selectedResultForDisplay.next_action && (
                    <div className="mt-3 space-y-1">
                      <p className="text-[10px] font-medium text-muted-foreground">다음 행동</p>
                      <p className="mt-1 text-[11px] leading-relaxed text-foreground">
                        {selectedResultForDisplay.next_action}
                      </p>
                    </div>
                  )}

                  {selectedResultForDisplay.blockers.length > 0 && (
                    <div className="mt-3 space-y-2">
                      {selectedResultForDisplay.blockers.slice(0, 3).map((blocker) => (
                        <div key={blocker.blocker_id} className="rounded-md border border-amber-500/20 bg-amber-500/10 px-2.5 py-2">
                          <div className="flex items-start justify-between gap-2">
                            <p className="min-w-0 text-[11px] leading-relaxed text-foreground">
                              {blocker.summary}
                            </p>
                            {blocker.requires_user_action && (
                              <span className="shrink-0 rounded-md border border-amber-500/20 bg-background/40 px-1.5 py-0.5 text-[9px] font-medium text-amber-300">
                                사용자 확인 필요
                              </span>
                            )}
                          </div>
                          {blocker.suggested_resolution && (
                            <p className="mt-1 text-[10px] leading-relaxed text-muted-foreground">
                              {blocker.suggested_resolution}
                            </p>
                          )}
                          <button
                            type="button"
                            onClick={() => startBlockerResolutionEvidence(blocker.summary, blocker.suggested_resolution)}
                            className="mt-2 inline-flex h-6 items-center gap-1 rounded-md border border-amber-500/20 bg-background/50 px-2 text-[10px] font-medium text-amber-200 transition-colors hover:bg-background"
                          >
                            <Plus className="h-3 w-3" />
                            해결 증거 추가
                          </button>
                        </div>
                      ))}
                      {selectedResultForDisplay.blockers.length > 3 && (
                        <p className="text-[10px] text-muted-foreground">
                          외 {selectedResultForDisplay.blockers.length - 3}개 blocker
                        </p>
                      )}
                    </div>
                  )}

                  {selectedResultForDisplay.retention_decision && (
                    <p className="mt-3 border-t border-border/40 pt-2 text-[10px] leading-relaxed text-muted-foreground">
                      저장 제안: {displayRetentionDecision(selectedResultForDisplay.retention_decision.save_decision)}
                    </p>
                  )}
                </section>
              )}

              <section aria-label="작업 이벤트 타임라인" className="rounded-lg border border-border/40 bg-secondary/10 p-3">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <p className="text-[10px] text-muted-foreground">이벤트 타임라인</p>
                    <p className="mt-1 text-[12px] font-semibold text-foreground">
                      {loadingEventsTaskId === selectedTask.id ? "불러오는 중" : `이벤트 ${selectedEvents.length}개`}
                    </p>
                  </div>
                </div>

                {selectedEvents.length === 0 ? (
                  <p className="mt-3 rounded-md border border-border/40 bg-background/70 px-2 py-1.5 text-[10px] text-muted-foreground">
                    아직 기록된 이벤트가 없습니다.
                  </p>
                ) : (
                  <div className="mt-3 space-y-2">
                    {selectedEvents.map((event) => (
                      <div key={event.event_id} className={`rounded-lg border px-2.5 py-2 ${eventSeverityTone[event.severity ?? "info"] ?? eventSeverityTone.info}`}>
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <p className="text-[11px] font-medium text-foreground">
                              {displayWorkerEventType(event.event_type)}
                            </p>
                            <p className="mt-1 text-[10px] leading-relaxed text-muted-foreground">
                              {event.message}
                            </p>
                          </div>
                          <span className="shrink-0 text-[9px] text-muted-foreground">
                            {displayEventTime(event.created_at)}
                          </span>
                        </div>
                        {event.requires_user_action && (
                          <p className="mt-1.5 text-[10px] text-amber-300">사용자 확인 필요</p>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </section>

              <section
                ref={evidenceSectionRef}
                aria-label="결과와 증거"
                tabIndex={-1}
                className={`rounded-lg border p-3 outline-none transition-colors ${
                  highlightedEvidenceTaskId === selectedTask.viewKey
                    ? "border-primary/50 bg-primary/5 ring-1 ring-primary/25"
                    : "border-border/40 bg-secondary/10"
                }`}
              >
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <p className="text-[10px] text-muted-foreground">결과와 증거</p>
                    <p className="mt-1 text-[12px] font-semibold text-foreground">
                      {completionPreview?.can_complete ? "완료 가능" : "완료 전 증거 필요"}
                    </p>
                  </div>
                  <span className={`inline-flex h-6 items-center rounded-md border px-2 text-[11px] font-medium ${
                    completionPreview?.can_complete
                      ? "border-emerald-500/20 bg-emerald-500/10 text-emerald-300"
                      : "border-amber-500/20 bg-amber-500/10 text-amber-300"
                  }`}>
                    {loadingEvidenceTaskId === selectedTask.id ? "불러오는 중" : `증거 ${selectedEvidence.length}개`}
                  </span>
                </div>

                {completionPreview && completionPreview.missing_verification_types.length > 0 && (
                  <div className="mt-3">
                    <p className="mb-1.5 text-[10px] text-muted-foreground">남은 증거</p>
                    <div className="flex flex-wrap gap-1.5">
                      {completionPreview.missing_verification_types.map((type) => (
                        <span key={type} className="inline-flex h-6 items-center rounded-md border border-amber-500/20 bg-amber-500/10 px-2 text-[11px] text-amber-300">
                          {verificationLabels[type] ?? type}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {completionPreview && !completionPreview.validation.valid && (
                  <div className="mt-3 space-y-1">
                    {completionPreview.validation.issues.slice(0, 2).map((issue) => (
                      <p key={issue} className="rounded-md border border-border/40 bg-background/70 px-2 py-1.5 text-[10px] text-muted-foreground">
                        {displayValidationIssue(issue)}
                      </p>
                    ))}
                  </div>
                )}

                <textarea
                  aria-label="작업 결과 요약"
                  value={resultSummaryByTaskId[selectedPacketTaskId] ?? ""}
                  onChange={(event) => setResultSummaryByTaskId((prev) => ({
                    ...prev,
                    [selectedPacketTaskId]: event.target.value,
                  }))}
                  placeholder="Codex가 돌려준 결론을 짧게 붙여넣기"
                  rows={2}
                  className="mt-3 w-full resize-none rounded-lg border border-border/40 bg-background px-2.5 py-2 text-[11px] text-foreground outline-none placeholder:text-muted-foreground/50 focus:border-primary/40"
                />

                <div aria-label="Codex 결과 Intake" className="mt-3 rounded-lg border border-border/40 bg-background/70 p-2.5">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <p className="text-[10px] text-muted-foreground">Codex 결과 Intake</p>
                      <p className="mt-1 text-[11px] font-medium text-foreground">
                        {loadingResultTaskId === selectedTask.id
                          ? "결과 불러오는 중"
                          : selectedResultForDisplay
                            ? displayWorkerOutcome(selectedResultForDisplay.result.outcome)
                            : "붙여넣기 대기"}
                      </p>
                    </div>
                    {selectedResultForDisplay && (
                      <span className={`inline-flex h-6 shrink-0 items-center rounded-md border px-2 text-[11px] font-medium ${workerOutcomeTone[selectedResultForDisplay.result.outcome] ?? workerOutcomeTone.advisory_only}`}>
                        {displayWorkerOutcome(selectedResultForDisplay.result.outcome)}
                      </span>
                    )}
                  </div>

                  {selectedResultForDisplay && (
                    <div className="mt-2 space-y-1.5">
                      <p className="text-[10px] font-medium text-muted-foreground">최신 결과</p>
                      <p className="text-[11px] leading-relaxed text-foreground">
                        {selectedResultForDisplay.result.summary}
                      </p>
                      <div className="flex flex-wrap gap-1.5">
                        <span className="inline-flex h-6 items-center rounded-md border border-border/40 bg-secondary/20 px-2 text-[10px] text-muted-foreground">
                          최신 blocker {selectedResultForDisplay.blockers.length}개
                        </span>
                        {selectedResultForDisplay.next_action && (
                          <span className="inline-flex min-h-6 items-center rounded-md border border-border/40 bg-secondary/20 px-2 py-1 text-[10px] text-muted-foreground">
                            다음: {selectedResultForDisplay.next_action}
                          </span>
                        )}
                        {selectedResultForDisplay.retention_decision && (
                          <span className="inline-flex h-6 items-center rounded-md border border-border/40 bg-secondary/20 px-2 text-[10px] text-muted-foreground">
                            저장 제안: {displayRetentionDecision(selectedResultForDisplay.retention_decision.save_decision)}
                          </span>
                        )}
                      </div>
                    </div>
                  )}

                  {selectedHistoricalBlockedResults.length > 0 && (
                    <div aria-label="이전 blocker 기록" className="mt-3 space-y-2 border-t border-border/40 pt-2">
                      <div className="flex items-center justify-between gap-2">
                        <p className="text-[10px] font-medium text-muted-foreground">이전 blocker 기록</p>
                        <span className="inline-flex h-5 items-center rounded-md border border-border/40 bg-secondary/20 px-2 text-[10px] text-muted-foreground">
                          기록 {selectedHistoricalBlockedResults.length}개
                        </span>
                      </div>
                      {selectedHistoricalBlockedResults.slice(0, 2).map((result) => (
                        <div key={result.created_at} className="rounded-md border border-border/40 bg-secondary/20 p-2">
                          <p className="text-[10px] font-medium text-muted-foreground">
                            이전 결과 · {displayWorkerOutcome(result.result.outcome)}
                          </p>
                          <p className="mt-1 text-[10px] leading-relaxed text-muted-foreground">
                            {result.result.summary}
                          </p>
                          {result.blockers.length > 0 && (
                            <div className="mt-1 space-y-1">
                              {result.blockers.slice(0, 2).map((blocker) => (
                                <p key={blocker.blocker_id} className="text-[10px] leading-relaxed text-amber-300">
                                  {blocker.summary}
                                  {blocker.requires_user_action ? " · 사용자 확인 필요" : ""}
                                </p>
                              ))}
                            </div>
                          )}
                        </div>
                      ))}
                      {selectedHistoricalBlockedResults.length > 2 && (
                        <p className="text-[10px] text-muted-foreground/80">
                          외 {selectedHistoricalBlockedResults.length - 2}개 이전 blocker 기록
                        </p>
                      )}
                    </div>
                  )}

                  {selectedParsedResult && (
                    <div aria-label="Codex 결과 적용 미리보기" className="mt-2 space-y-2 rounded-md bg-secondary/20 p-2">
                      <div className="flex items-center justify-between gap-2">
                        <p className="text-[10px] font-medium text-muted-foreground">적용 전 미리보기</p>
                        <div className="flex flex-wrap justify-end gap-1.5">
                          <span className="inline-flex h-6 items-center rounded-md border border-border/40 bg-background/70 px-2 text-[10px] text-muted-foreground">
                            저장될 증거 {selectedParsedResult.evidence.length}개
                          </span>
                          <span className="inline-flex h-6 items-center rounded-md border border-border/40 bg-background/70 px-2 text-[10px] text-muted-foreground">
                            blocker {selectedParsedResult.blockers.length}개
                          </span>
                        </div>
                      </div>

                      {selectedParsedResult.evidence.length > 0 ? (
                        <div className="space-y-1">
                          {selectedParsedResult.evidence.slice(0, 3).map((item) => (
                            <p key={item.evidence_id} className="text-[10px] leading-relaxed text-muted-foreground">
                              {displayEvidenceType(item.evidence_type)} · {displayEvidenceStatus(item.status)} · {item.summary}
                            </p>
                          ))}
                          {selectedParsedResult.evidence.length > 3 && (
                            <p className="text-[10px] text-muted-foreground/80">
                              외 {selectedParsedResult.evidence.length - 3}개 증거
                            </p>
                          )}
                        </div>
                      ) : (
                        <p className="text-[10px] text-muted-foreground/80">저장될 증거가 없습니다.</p>
                      )}

                      {selectedParsedResult.blockers.length > 0 && (
                        <div className="space-y-1 border-t border-border/40 pt-2">
                          {selectedParsedResult.blockers.slice(0, 2).map((blocker) => (
                            <p key={blocker.blocker_id} className="text-[10px] leading-relaxed text-muted-foreground">
                              {blocker.summary}
                              {blocker.requires_user_action ? " · 사용자 확인 필요" : ""}
                            </p>
                          ))}
                          {selectedParsedResult.blockers.length > 2 && (
                            <p className="text-[10px] text-muted-foreground/80">
                              외 {selectedParsedResult.blockers.length - 2}개 blocker
                            </p>
                          )}
                        </div>
                      )}
                    </div>
                  )}

                  {selectedParsedResult && !selectedParsedResult.validation.valid && (
                    <div className="mt-2 space-y-1">
                      {selectedParsedResult.validation.issues.slice(0, 2).map((issue) => (
                        <p key={issue} className="rounded-md border border-red-500/20 bg-red-500/10 px-2 py-1.5 text-[10px] text-red-300">
                          {displayValidationIssue(issue)}
                        </p>
                      ))}
                    </div>
                  )}

                  <div className="mt-2">
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-[10px] font-medium text-muted-foreground">결과 형식</p>
                      <button
                        onClick={() => void copyResultGuide()}
                        className="flex h-6 items-center gap-1 rounded-md border border-border/40 bg-secondary/20 px-2 text-[10px] font-medium transition-colors hover:bg-secondary"
                      >
                        <Copy className="h-3 w-3" />
                        형식 복사
                      </button>
                    </div>
                    <pre
                      aria-label="Codex 결과 형식 안내"
                      className="mt-1.5 max-h-28 overflow-auto rounded-md bg-secondary/20 p-2 text-[10px] leading-relaxed text-muted-foreground scrollbar-thin"
                    >
                      {selectedResultGuide}
                    </pre>
                  </div>

                  <textarea
                    aria-label="Codex 결과 붙여넣기"
                    value={selectedResultPaste}
                    onChange={(event) => {
                      const value = event.target.value;
                      setResultPasteByTaskId((prev) => ({
                        ...prev,
                        [selectedPacketTaskId]: value,
                      }));
                      setParsedResultByTaskId((prev) => ({
                        ...prev,
                        [selectedPacketTaskId]: null,
                      }));
                    }}
                    placeholder="Codex가 돌려준 conclusion, evidence, blockers, next action을 붙여넣기"
                    rows={5}
                    className="mt-2 w-full resize-none rounded-lg border border-border/40 bg-background px-2.5 py-2 text-[11px] text-foreground outline-none placeholder:text-muted-foreground/50 focus:border-primary/40"
                  />
                  <div className="mt-2 grid grid-cols-2 gap-2">
                    <button
                      onClick={previewPastedWorkerResult}
                      className="h-8 rounded-lg border border-border/40 bg-secondary/20 text-[11px] font-medium transition-colors hover:bg-secondary"
                    >
                      미리보기
                    </button>
                    <button
                      onClick={() => void applyPastedWorkerResult()}
                      disabled={persistingResult}
                      className="h-8 rounded-lg border border-primary/20 bg-primary/10 text-[11px] font-medium text-primary transition-colors hover:bg-primary/15 disabled:cursor-not-allowed disabled:opacity-60"
                    >
                      {persistingResult ? "적용 중" : "결과 적용"}
                    </button>
                  </div>
                </div>

                <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-3">
                  <select
                    aria-label="증거 유형"
                    value={evidenceForm.evidence_type}
                    onChange={(event) => setEvidenceForm((prev) => ({ ...prev, evidence_type: event.target.value as EvidenceType }))}
                    className="h-8 rounded-lg border border-border/40 bg-background px-2 text-[11px] outline-none"
                  >
                    {evidenceTypeOptions.map((type) => (
                      <option key={type} value={type}>
                        {displayEvidenceType(type)}
                      </option>
                    ))}
                  </select>
                  <select
                    aria-label="증거 출처"
                    value={evidenceForm.source_system}
                    onChange={(event) => setEvidenceForm((prev) => ({ ...prev, source_system: event.target.value as EvidenceSourceSystem }))}
                    className="h-8 rounded-lg border border-border/40 bg-background px-2 text-[11px] outline-none"
                  >
                    {EVIDENCE_SOURCE_SYSTEMS.map((system) => (
                      <option key={system} value={system}>
                        {displaySourceSystem(system)}
                      </option>
                    ))}
                  </select>
                  <select
                    aria-label="증거 상태"
                    value={evidenceForm.status}
                    onChange={(event) => setEvidenceForm((prev) => ({ ...prev, status: event.target.value as EvidenceStatus }))}
                    className="h-8 rounded-lg border border-border/40 bg-background px-2 text-[11px] outline-none"
                  >
                    {EVIDENCE_STATUSES.map((status) => (
                      <option key={status} value={status}>
                        {displayEvidenceStatus(status)}
                      </option>
                    ))}
                  </select>
                </div>

                <input
                  aria-label="증거 요약"
                  value={evidenceForm.summary}
                  onChange={(event) => setEvidenceForm((prev) => ({ ...prev, summary: event.target.value }))}
                  placeholder="예: SO-1001은 출하 대기 상태로 확인됨"
                  className="mt-2 h-8 w-full rounded-lg border border-border/40 bg-background px-2.5 text-[11px] text-foreground outline-none placeholder:text-muted-foreground/50 focus:border-primary/40"
                />
                <textarea
                  aria-label="짧은 원문"
                  value={evidenceForm.raw_excerpt}
                  onChange={(event) => setEvidenceForm((prev) => ({ ...prev, raw_excerpt: event.target.value }))}
                  placeholder="선택: 민감 정보 없는 짧은 원문만"
                  rows={2}
                  className="mt-2 w-full resize-none rounded-lg border border-border/40 bg-background px-2.5 py-2 text-[11px] text-foreground outline-none placeholder:text-muted-foreground/50 focus:border-primary/40"
                />
                <button
                  onClick={() => void addEvidence()}
                  disabled={persistingEvidence}
                  className="mt-2 flex h-8 w-full items-center justify-center rounded-lg border border-border/40 bg-secondary/20 text-[11px] font-medium transition-colors hover:bg-secondary disabled:cursor-not-allowed disabled:opacity-60"
                >
                  {persistingEvidence ? "저장 중" : "증거 추가"}
                </button>

                {selectedEvidence.length > 0 && (
                  <div aria-label="증거 목록" className="mt-3 space-y-2">
                    {selectedEvidence.map((item) => (
                      <div key={item.evidence_id} className="rounded-lg border border-border/40 bg-background/70 p-2">
                        <div className="flex items-start justify-between gap-2">
                          <div className="min-w-0">
                            <p className="text-[11px] font-medium text-foreground">{item.summary}</p>
                            <p className="mt-1 text-[10px] text-muted-foreground">
                              {displayEvidenceType(item.evidence_type)} · {displaySourceSystem(item.source.system)} · {displayEvidenceStatus(item.status)}
                            </p>
                          </div>
                          <button
                            onClick={() => void removeEvidence(item.evidence_id)}
                            className="rounded-md px-1.5 py-0.5 text-[10px] text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
                          >
                            삭제
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </section>

              <pre
                aria-label="Codex 전달문 미리보기"
                className="max-h-52 overflow-auto rounded-lg border border-border/40 bg-background/80 p-3 text-[10px] leading-relaxed text-muted-foreground scrollbar-thin"
              >
                {selectedCodexHandoff}
              </pre>
            </div>
          ) : selectedTask && selectedGatewayDraft?.bridge_status === "needs_manual_review" ? (
            <section
              aria-label="Gateway 접수 packet 검토 필요"
              className="rounded-xl border border-amber-500/20 bg-amber-500/10 p-4"
            >
              <div className="flex items-center gap-2">
                <ShieldAlert className="h-4 w-4 text-amber-300" />
                <h3 className="text-[13px] font-semibold text-foreground">검토 필요</h3>
              </div>
              <p className="mt-2 text-[11px] leading-relaxed text-muted-foreground">
                {selectedGatewayDraft.blocked_reason ?? "필수 접수 정보를 확인할 수 없어 실행을 차단했습니다."}
              </p>
              <p className="mt-2 text-[10px] leading-relaxed text-amber-200/80">
                실행, 완료, 결과·증거 변경, Codex 전달은 packet을 확인한 뒤에만 사용할 수 있습니다.
              </p>
            </section>
          ) : (
            <div className="flex h-full min-h-40 flex-col items-center justify-center gap-2 text-center">
              <Bot className="h-7 w-7 text-muted-foreground/30" />
              <p className="text-[11px] text-muted-foreground">작업을 선택하면 Gateway 판단이 표시됩니다</p>
            </div>
          )}
        </aside>
      </div>
    </div>
  );
}
