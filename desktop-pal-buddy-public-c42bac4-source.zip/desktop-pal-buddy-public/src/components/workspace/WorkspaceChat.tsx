import { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ChatInput } from "@/components/ChatInput";
import { ChatMessage } from "@/components/ChatMessage";
import { streamChat, type Msg } from "@/lib/streamChat";
import { toast } from "sonner";
import { Sparkles, ChevronDown, ChevronUp, X, Bot, BriefcaseBusiness } from "lucide-react";
import { useInstalledItems } from "@/hooks/useInstalledItems";

interface WorkspaceChatProps {
  initialMessages?: Msg[];
  initialPrompt?: string;
  initialPromptId?: number;
  onStartCompanyWork?: (draft: string) => void;
}

export function WorkspaceChat({ initialMessages, initialPrompt, initialPromptId, onStartCompanyWork }: WorkspaceChatProps) {
  const [isOpen, setIsOpen] = useState(() => !!initialMessages?.length);
  const [messages, setMessages] = useState<Msg[]>(initialMessages || []);
  const [isLoading, setIsLoading] = useState(false);
  const [showMentionMenu, setShowMentionMenu] = useState(false);
  const [mentionFilter, setMentionFilter] = useState("");
  const [draftText, setDraftText] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);
  const lastInitialPromptIdRef = useRef<number | undefined>(undefined);
  const { activeAgents } = useInstalledItems();

  useEffect(() => {
    if (initialMessages?.length) {
      setMessages(initialMessages);
      setIsOpen(true);
    }
  }, [initialMessages]);

  const scrollToBottom = useCallback(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, []);

  useEffect(() => { scrollToBottom(); }, [messages, scrollToBottom]);

  const send = useCallback(async (input: string) => {
    // Check for @agent mentions and build system context
    const mentionRegex = /@(\S+)/g;
    let systemPrompt = "";
    const mentions = input.match(mentionRegex);
    if (mentions) {
      const mentionedAgents = mentions.map(m => {
        const name = m.slice(1);
        return activeAgents.find(a => a.item_name.toLowerCase().includes(name.toLowerCase()));
      }).filter(Boolean);

      if (mentionedAgents.length > 0) {
        systemPrompt = mentionedAgents.map(a =>
          `[호출된 에이전트: ${a!.item_name}] ${a!.item_description || ""}`
        ).join("\n");
      }
    }

    const userMsg: Msg = { role: "user", content: input };
    const contextMessages: Msg[] = systemPrompt
      ? [{ role: "user", content: `[시스템 컨텍스트] ${systemPrompt}` }, ...messages, userMsg]
      : [...messages, userMsg];
    
    setMessages(prev => [...prev, userMsg]);
    setIsLoading(true);
    setIsOpen(true);
    let assistantSoFar = "";
    const upsert = (chunk: string) => {
      assistantSoFar += chunk;
      setMessages((prev) => {
        const last = prev[prev.length - 1];
        if (last?.role === "assistant") return prev.map((m, i) => i === prev.length - 1 ? { ...m, content: assistantSoFar } : m);
        return [...prev, { role: "assistant", content: assistantSoFar }];
      });
    };
    try {
      await streamChat({ messages: contextMessages, onDelta: upsert, onDone: () => setIsLoading(false), onError: (e) => { toast.error(e); setIsLoading(false); } });
    } catch { toast.error("연결에 실패했습니다."); setIsLoading(false); }
  }, [activeAgents, messages]);

  const handleInputChange = (value: string) => {
    setDraftText(value);
    const lastAt = value.lastIndexOf("@");
    if (lastAt >= 0 && !value.slice(lastAt).includes(" ")) {
      setShowMentionMenu(true);
      setMentionFilter(value.slice(lastAt + 1).toLowerCase());
    } else {
      setShowMentionMenu(false);
    }
  };

  const filteredAgents = activeAgents.filter(a =>
    !mentionFilter || a.item_name.toLowerCase().includes(mentionFilter)
  );

  useEffect(() => {
    if (!initialPrompt || !initialPromptId) return;
    if (lastInitialPromptIdRef.current === initialPromptId) return;
    lastInitialPromptIdRef.current = initialPromptId;
    void send(initialPrompt);
  }, [initialPrompt, initialPromptId, send]);

  return (
    <div className="absolute bottom-0 left-0 right-0 z-10 flex flex-col pointer-events-none">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 280, opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
            className="pointer-events-auto border-t border-border/50 bg-background/95 backdrop-blur-sm overflow-hidden"
          >
            <div className="flex items-center justify-between px-4 py-2 border-b border-border/30">
              <div className="flex items-center gap-2">
                <Sparkles className="w-3.5 h-3.5 text-primary" />
                <span className="text-[11px] font-medium">Prometheus</span>
                {activeAgents.length > 0 && (
                  <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-primary/10 text-primary">
                    @로 {activeAgents.length}개 에이전트 호출 가능
                  </span>
                )}
              </div>
              <div className="flex items-center gap-1">
                <button onClick={() => setIsOpen(false)} className="w-6 h-6 rounded-md hover:bg-secondary flex items-center justify-center">
                  <ChevronDown className="w-3.5 h-3.5 text-muted-foreground" />
                </button>
                <button onClick={() => { setIsOpen(false); setMessages([]); }} className="w-6 h-6 rounded-md hover:bg-destructive/20 flex items-center justify-center">
                  <X className="w-3 h-3 text-muted-foreground" />
                </button>
              </div>
            </div>
            <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-3 space-y-3 scrollbar-thin" style={{ height: "calc(100% - 36px)" }}>
              {messages.length === 0 ? (
                <div className="flex items-center justify-center h-full">
                  <div className="text-center">
                    <p className="text-[11px] text-muted-foreground">현재 모드와 관련된 질문을 자유롭게 해보세요</p>
                    {activeAgents.length > 0 && (
                      <p className="text-[10px] text-muted-foreground/60 mt-1">
                        @에이전트명으로 설치된 에이전트를 호출할 수 있습니다
                      </p>
                    )}
                  </div>
                </div>
              ) : (
                messages.map((msg, i) => (
                  <ChatMessage key={i} message={msg} isStreaming={isLoading && i === messages.length - 1 && msg.role === "assistant"} />
                ))
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="pointer-events-auto px-4 py-2.5 bg-background/95 backdrop-blur-sm border-t border-border/40 relative">
        {/* @ Mention dropdown */}
        <AnimatePresence>
          {showMentionMenu && filteredAgents.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              className="absolute bottom-full left-4 right-4 mb-1 rounded-xl border border-border bg-card shadow-lg max-h-40 overflow-y-auto z-20"
            >
              <div className="p-1">
                <p className="text-[9px] text-muted-foreground px-2 py-1 font-medium">설치된 에이전트</p>
                {filteredAgents.map(agent => (
                  <button key={agent.id}
                    className="w-full flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-secondary/60 transition-colors text-left"
                    onClick={() => { setShowMentionMenu(false); }}>
                    <Bot className="w-3.5 h-3.5 text-primary flex-shrink-0" />
                    <div className="min-w-0">
                      <p className="text-[11px] font-medium text-foreground truncate">{agent.item_name}</p>
                      {agent.item_description && (
                        <p className="text-[9px] text-muted-foreground truncate">{agent.item_description}</p>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="mb-2 flex flex-wrap items-center justify-between gap-2 text-[10px] text-muted-foreground">
          <span>일반 대화는 여기에서 계속하고, 회사 요청 초안은 회사 업무 시작에서 검토하세요.</span>
          <button
            type="button"
            onClick={() => onStartCompanyWork?.(draftText.trim())}
            className="inline-flex h-7 items-center gap-1.5 rounded-md border border-blue-500/30 bg-blue-500/10 px-2 text-[10px] font-medium text-blue-300 hover:bg-blue-500/20"
          >
            <BriefcaseBusiness className="h-3 w-3" aria-hidden="true" /> 회사 업무 시작
          </button>
        </div>
        <div className="flex items-center gap-2">
          {!isOpen && messages.length > 0 && (
            <button onClick={() => setIsOpen(true)} className="w-8 h-8 rounded-lg bg-secondary/50 hover:bg-secondary flex items-center justify-center flex-shrink-0 transition-colors">
              <ChevronUp className="w-4 h-4 text-muted-foreground" />
            </button>
          )}
          <div className="flex-1">
            <ChatInput onSend={send} isLoading={isLoading} onChange={handleInputChange} />
          </div>
        </div>
      </div>
    </div>
  );
}
