import type { Strategy, StrategyVersion } from "@/lib/agentic";

interface StrategySelectProps {
  strategies: readonly Strategy[];
  versions: readonly StrategyVersion[];
  strategyId: string;
  versionId: string;
  onSelectionChange: (selection: { strategyId: string; versionId: string }) => void;
}

export function StrategySelect({
  strategies,
  versions,
  strategyId,
  versionId,
  onSelectionChange,
}: StrategySelectProps) {
  const availableVersions = versions.filter((version) => version.strategy_id === strategyId);

  return (
    <section aria-label="전략 탐색" className="rounded-xl border border-border/40 bg-secondary/10 p-3">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-[11px] font-semibold text-foreground">전략 탐색</p>
          <p className="mt-0.5 text-[10px] text-muted-foreground">가상 데이터 · 새로고침 시 초기화</p>
        </div>
        <span className="rounded-md border border-border/40 bg-background px-2 py-1 text-[10px] text-muted-foreground">
          선택 사항
        </span>
      </div>
      <div className="mt-3 grid gap-2 sm:grid-cols-2">
        <label className="space-y-1 text-[10px] text-muted-foreground">
          전략
          <select
            aria-label="전략 선택"
            value={strategyId}
            onChange={(event) => onSelectionChange({ strategyId: event.target.value, versionId: "" })}
            className="h-9 w-full rounded-lg border border-border/40 bg-background px-2 text-[11px] text-foreground outline-none"
          >
            <option value="">전략 미연결</option>
            {strategies.map((strategy) => (
              <option key={strategy.strategy_id} value={strategy.strategy_id}>{strategy.title}</option>
            ))}
          </select>
        </label>
        <label className="space-y-1 text-[10px] text-muted-foreground">
          버전
          <select
            aria-label="전략 버전 선택"
            value={versionId}
            disabled={!strategyId}
            onChange={(event) => onSelectionChange({ strategyId, versionId: event.target.value })}
            className="h-9 w-full rounded-lg border border-border/40 bg-background px-2 text-[11px] text-foreground outline-none disabled:cursor-not-allowed disabled:opacity-50"
          >
            <option value="">버전 선택</option>
            {availableVersions.map((version) => (
              <option key={version.strategy_version_id} value={version.strategy_version_id}>v{version.version}</option>
            ))}
          </select>
        </label>
      </div>
      {strategyId && !versionId && (
        <p className="mt-2 rounded-md border border-amber-500/20 bg-amber-500/10 px-2 py-1.5 text-[10px] text-amber-300">
          전략 버전을 선택해야 작업을 만들 수 있습니다.
        </p>
      )}
    </section>
  );
}
