import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import ReactMarkdown from "react-markdown";
import { streamChat, type Msg } from "@/lib/streamChat";
import { toast } from "sonner";
import {
  ArrowLeft,
  ArrowRight,
  FileText,
  Calendar,
  BarChart3,
  Users,
  ShieldAlert,
  Package,
  Loader2,
  Sparkles,
  CheckCircle2,
  Copy,
  RotateCcw,
  Download,
  Edit3,
  Save,
} from "lucide-react";

type ReportType = "weekly" | "monthly" | "quarterly";
type DataSection = "sales" | "customers" | "risks" | "quality" | "market" | "action";

const reportTypes: { id: ReportType; label: string; description: string; period: string }[] = [
  { id: "weekly", label: "주간 보고", description: "금주 실적 및 주요 이슈", period: "2025.03.03 ~ 03.07" },
  { id: "monthly", label: "월간 보고", description: "월 실적 종합 및 분석", period: "2025년 3월" },
  { id: "quarterly", label: "분기 보고", description: "분기 실적 및 전략 리뷰", period: "2025년 1분기" },
];

const dataSections: { id: DataSection; label: string; icon: typeof BarChart3; description: string }[] = [
  { id: "sales", label: "판매 실적", icon: BarChart3, description: "수주량, 매출, 수익성 데이터" },
  { id: "customers", label: "고객 동향", icon: Users, description: "고객별 이슈 및 거래 현황" },
  { id: "risks", label: "리스크 현황", icon: ShieldAlert, description: "납기/품질/가격 리스크 항목" },
  { id: "quality", label: "품질 현황", icon: Package, description: "품질 지표 및 클레임 현황" },
  { id: "market", label: "시장 동향", icon: BarChart3, description: "철강/자동차 시장 동향" },
  { id: "action", label: "액션 플랜", icon: FileText, description: "후속 조치 및 계획" },
];

const mockData: Record<DataSection, string> = {
  sales: `- 총 수주량: 8,050톤 (전주 대비 +6.3%)
- 월 매출: 124억원 (목표 대비 103%)
- 평균 마진율: 13.2% (목표 13.0%)
- 현대자동차 3,600톤, 기아 2,200톤, 도요타 1,250톤, GM Korea 1,000톤`,
  customers: `- 현대자동차: 납기 조정 합의 완료, 2분기 물량 협의 예정
- 기아: 신규 모델 사양 확정 대기, 가격 재협상 진행 중
- 도요타: 품질 개선 조치 이후 모니터링 중, 수출 물량 안정
- GM Korea: DP강 공급 확대 제안 진행, 설비 투자 검토 중`,
  risks: `- [심각] 현대자동차 3월 납기 지연 리스크 (열연 라인 정비)
- [높음] 현대자동차 GA강판 표면 품질 이슈 (불량률 0.5%)
- [높음] 기아 2분기 가격 재협상 압박 (3% 인하 요구)
- [보통] 도요타 표면 결함 재발 우려 (모니터링 중)`,
  quality: `- 전체 불량률: 0.28% (목표 0.30% 이내)
- GA강판 표면 결함: 0.5% (기준 초과, 개선 조치 중)
- 클레임 건수: 2건 (전월 대비 -1건)
- IATF 16949 재인증 완료`,
  market: `- 글로벌 철강 가격: 하락세 지속 (HRC 톤당 $520)
- 자동차 강판 프리미엄: 유지 (수요 증가)
- 원자재(철광석): 톤당 $105 (전월 대비 -3%)
- 환율: 원/달러 1,320원 (안정)`,
  action: `- 현대자동차 납기 정상화 일정 확정 (3월 셋째 주)
- 기아 가격 협상 대응 자료 준비 (3월 둘째 주)
- 도요타 품질 모니터링 결과 보고 (3월 넷째 주)
- GM Korea DP강 설비 투자 검토 보고 (3월 말)`,
};

const toneOptions = ["간결/핵심 위주", "상세/분석 포함", "경영진 보고용"] as const;

interface ReportDraftModeProps {
  onBack: () => void;
}

type Step = "type" | "config" | "generating" | "result";

export function ReportDraftMode({ onBack }: ReportDraftModeProps) {
  const [step, setStep] = useState<Step>("type");
  const [reportType, setReportType] = useState<ReportType | null>(null);
  const [selectedSections, setSelectedSections] = useState<DataSection[]>(["sales", "customers", "risks"]);
  const [tone, setTone] = useState<string>(toneOptions[0]);
  const [additionalNote, setAdditionalNote] = useState("");
  const [draft, setDraft] = useState("");
  const [editedDraft, setEditedDraft] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const resultRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const selectedReport = reportTypes.find((r) => r.id === reportType);

  const toggleSection = (id: DataSection) => {
    setSelectedSections((prev) => prev.includes(id) ? prev.filter((s) => s !== id) : [...prev, id]);
  };

  const handleSelectType = (type: ReportType) => {
    setReportType(type);
    setStep("config");
  };

  const handleGenerate = async () => {
    if (!selectedReport || selectedSections.length === 0) return;
    setStep("generating");
    setIsGenerating(true);
    setDraft("");
    setEditedDraft("");

    const dataContext = selectedSections.map((s) => {
      const section = dataSections.find((ds) => ds.id === s);
      return `### ${section?.label}\n${mockData[s]}`;
    }).join("\n\n");

    const prompt = `당신은 자동차 강판 마케팅/판매 전문 AI 비서입니다.
다음 데이터를 기반으로 ${selectedReport.label}서 초안을 작성해주세요.

**보고서 유형:** ${selectedReport.label}
**보고 기간:** ${selectedReport.period}
**작성 스타일:** ${tone}
${additionalNote ? `**추가 요청:** ${additionalNote}` : ""}

**데이터:**
${dataContext}

다음 형식으로 보고서를 작성해주세요:

1. **제목** - "${selectedReport.label} (${selectedReport.period})"
2. **요약** - 핵심 내용 3-4줄 요약
3. 선택된 각 섹션별 상세 내용
4. **종합 의견** - 전체적인 평가와 시사점
5. **향후 계획** - 다음 기간 주요 계획

${tone === "경영진 보고용" ? "경영진 대상이므로 핵심 수치와 의사결정 포인트 위주로 작성하세요." : ""}
${tone === "상세/분석 포함" ? "데이터 분석과 근거를 상세히 포함하세요." : ""}
마크다운으로 깔끔하게 작성해주세요.`;

    let fullText = "";
    try {
      await streamChat({
        messages: [{ role: "user", content: prompt }] as Msg[],
        onDelta: (chunk) => { fullText += chunk; setDraft(fullText); },
        onDone: () => { setIsGenerating(false); setEditedDraft(fullText); setStep("result"); },
        onError: (e) => { toast.error(e); setIsGenerating(false); setStep("config"); },
      });
    } catch {
      toast.error("보고서 생성에 실패했습니다.");
      setIsGenerating(false);
      setStep("config");
    }
  };

  const handleReset = () => {
    setStep("type");
    setReportType(null);
    setSelectedSections(["sales", "customers", "risks"]);
    setDraft("");
    setEditedDraft("");
    setIsEditing(false);
  };

  useEffect(() => {
    if (resultRef.current && (step === "generating" || step === "result")) {
      resultRef.current.scrollTop = resultRef.current.scrollHeight;
    }
  }, [draft, step]);

  useEffect(() => {
    if (isEditing && textareaRef.current) {
      textareaRef.current.focus();
      textareaRef.current.style.height = "auto";
      textareaRef.current.style.height = textareaRef.current.scrollHeight + "px";
    }
  }, [isEditing]);

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-3 px-6 py-4 border-b border-border/50">
        <button onClick={step === "type" ? onBack : handleReset} className="w-8 h-8 rounded-lg hover:bg-secondary flex items-center justify-center transition-colors">
          <ArrowLeft className="w-4 h-4 text-muted-foreground" />
        </button>
        <div className="flex-1">
          <h2 className="text-[14px] font-semibold">보고 초안</h2>
          <p className="text-[11px] text-muted-foreground">
            {step === "type" && "보고서 유형을 선택하세요"}
            {step === "config" && `${selectedReport?.label} — 데이터 설정`}
            {step === "generating" && "AI 보고서 초안 생성 중..."}
            {step === "result" && `${selectedReport?.label} 초안 완료`}
          </p>
        </div>
        <div className="flex items-center gap-1.5">
          {(["type", "config", "result"] as const).map((s, i) => (
            <div key={s} className={`h-1.5 rounded-full transition-all ${
              (step === s || (step === "generating" && s === "result"))
                ? "w-6 bg-primary"
                : i < ["type", "config", "result"].indexOf(step === "generating" ? "result" : step)
                ? "w-4 bg-primary/40"
                : "w-4 bg-secondary"
            }`} />
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        <AnimatePresence mode="wait">
          {/* Step 1: Report type */}
          {step === "type" && (
            <motion.div key="type" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="p-6 space-y-4">
              <div className="space-y-3">
                {reportTypes.map((rt, i) => (
                  <motion.button
                    key={rt.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.08 }}
                    whileHover={{ scale: 1.01, x: 4 }}
                    whileTap={{ scale: 0.99 }}
                    onClick={() => handleSelectType(rt.id)}
                    className="w-full flex items-center gap-4 p-5 rounded-2xl bg-secondary/20 border border-border/50 hover:border-border transition-all text-left group"
                  >
                    <div className="w-12 h-12 rounded-xl bg-primary/5 border border-primary/10 flex items-center justify-center flex-shrink-0">
                      <Calendar className="w-6 h-6 text-primary/60" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-[13px] font-semibold group-hover:text-primary transition-colors">{rt.label}</h3>
                      <p className="text-[11px] text-muted-foreground mt-0.5">{rt.description}</p>
                      <p className="text-[10px] text-muted-foreground/70 mt-1">{rt.period}</p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-muted-foreground/40 group-hover:text-primary transition-colors" />
                  </motion.button>
                ))}
              </div>
            </motion.div>
          )}

          {/* Step 2: Config */}
          {step === "config" && (
            <motion.div key="config" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="p-6 pb-20 space-y-5">
              {/* Report info */}
              <div className="flex items-center gap-3 p-3 rounded-xl bg-secondary/20 border border-border/30">
                <Calendar className="w-5 h-5 text-primary/60" />
                <div>
                  <p className="text-[12px] font-medium">{selectedReport?.label}</p>
                  <p className="text-[10px] text-muted-foreground">{selectedReport?.period}</p>
                </div>
              </div>

              {/* Data sections */}
              <div>
                <label className="text-[12px] font-medium text-foreground mb-2 block">포함할 데이터 섹션</label>
                <div className="grid grid-cols-3 gap-2">
                  {dataSections.map((ds) => (
                    <button
                      key={ds.id}
                      onClick={() => toggleSection(ds.id)}
                      className={`text-left p-3 rounded-xl border transition-all ${
                        selectedSections.includes(ds.id)
                          ? "border-primary bg-primary/5"
                          : "border-border/50 bg-secondary/20 hover:border-border"
                      }`}
                    >
                      <ds.icon className={`w-4 h-4 mb-1.5 ${selectedSections.includes(ds.id) ? "text-primary" : "text-muted-foreground"}`} />
                      <p className="text-[11px] font-medium">{ds.label}</p>
                      <p className="text-[9px] text-muted-foreground mt-0.5">{ds.description}</p>
                    </button>
                  ))}
                </div>
              </div>

              {/* Tone */}
              <div>
                <label className="text-[12px] font-medium text-foreground mb-2 block">작성 스타일</label>
                <div className="flex gap-2">
                  {toneOptions.map((t) => (
                    <button
                      key={t}
                      onClick={() => setTone(t)}
                      className={`px-3 py-1.5 rounded-lg border text-[11px] transition-all ${
                        tone === t ? "border-primary bg-primary/10 text-primary font-medium" : "border-border/50 bg-secondary/20 text-muted-foreground hover:border-border"
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>

              {/* Additional note */}
              <div>
                <label className="text-[12px] font-medium text-foreground mb-2 block">추가 요청 (선택)</label>
                <textarea
                  value={additionalNote}
                  onChange={(e) => setAdditionalNote(e.target.value)}
                  placeholder="예: 수익성 개선 방안 강조, 경쟁사 비교 포함..."
                  className="w-full h-16 p-3 rounded-xl border border-border/50 bg-secondary/10 text-[12px] text-foreground placeholder:text-muted-foreground/50 resize-none focus:outline-none focus:border-primary/50 transition-colors"
                />
              </div>

              {/* Generate */}
              <motion.button
                whileHover={{ scale: 1.01 }}
                whileTap={{ scale: 0.99 }}
                onClick={handleGenerate}
                disabled={selectedSections.length === 0}
                className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-primary text-primary-foreground font-medium text-[13px] hover:bg-primary/90 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <Sparkles className="w-4 h-4" />
                보고서 초안 생성
                <ArrowRight className="w-4 h-4" />
              </motion.button>
            </motion.div>
          )}

          {/* Step 3: Generating / Result */}
          {(step === "generating" || step === "result") && (
            <motion.div key="result" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="flex flex-col h-full">
              {isGenerating && (
                <div className="flex items-center gap-2 px-6 py-3 border-b border-border/30 bg-primary/5">
                  <Loader2 className="w-3.5 h-3.5 text-primary animate-spin" />
                  <span className="text-[11px] text-primary font-medium">{selectedReport?.label} 초안 생성 중...</span>
                </div>
              )}
              {step === "result" && !isGenerating && (
                <div className="flex items-center gap-2 px-6 py-3 border-b border-border/30 bg-status-completed/5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-status-completed" />
                  <span className="text-[11px] text-status-completed font-medium">{selectedReport?.label} 초안 완료</span>
                </div>
              )}

              <div ref={resultRef} className="flex-1 overflow-y-auto px-6 py-4 scrollbar-thin">
                {isEditing ? (
                  <textarea
                    ref={textareaRef}
                    value={editedDraft}
                    onChange={(e) => { setEditedDraft(e.target.value); e.target.style.height = "auto"; e.target.style.height = e.target.scrollHeight + "px"; }}
                    className="w-full min-h-[400px] p-4 rounded-xl border border-primary/30 bg-secondary/10 text-[13px] text-foreground leading-relaxed resize-none focus:outline-none focus:border-primary/50 font-mono"
                  />
                ) : (
                  <div className="prose prose-sm dark:prose-invert max-w-none text-[13px] leading-relaxed">
                    <ReactMarkdown>{step === "generating" ? draft : editedDraft}</ReactMarkdown>
                  </div>
                )}
              </div>

              {step === "result" && (
                <div className="px-6 py-3 border-t border-border/50 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <button onClick={handleReset} className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-border/50 text-[11px] text-muted-foreground hover:bg-secondary transition-colors">
                      <RotateCcw className="w-3 h-3" />다시 작성
                    </button>
                    <button onClick={() => { navigator.clipboard.writeText(editedDraft); toast.success("복사되었습니다"); }} className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-border/50 text-[11px] text-muted-foreground hover:bg-secondary transition-colors">
                      <Copy className="w-3 h-3" />복사
                    </button>
                    <button onClick={() => { if (isEditing) toast.success("저장되었습니다"); setIsEditing(!isEditing); }} className={`flex items-center gap-1.5 px-3 py-2 rounded-lg border text-[11px] transition-colors ${isEditing ? "border-primary bg-primary/10 text-primary" : "border-border/50 text-muted-foreground hover:bg-secondary"}`}>
                      {isEditing ? <Save className="w-3 h-3" /> : <Edit3 className="w-3 h-3" />}{isEditing ? "저장" : "편집"}
                    </button>
                  </div>
                  <button onClick={() => toast.success("보고서가 저장되었습니다 (데모)")} className="flex items-center gap-1.5 px-5 py-2 rounded-lg bg-primary text-primary-foreground text-[11px] font-medium hover:bg-primary/90 transition-colors">
                    <Download className="w-3 h-3" />저장
                  </button>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
