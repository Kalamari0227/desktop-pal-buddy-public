import { useState, useRef, useEffect, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import ReactMarkdown from "react-markdown";
import { streamChat, type Msg } from "@/lib/streamChat";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import type { TaskInsert } from "@/types/task";
import { createRiskGatewayDraft } from "@/lib/agentic";
import {
  ArrowLeft,
  AlertTriangle,
  ShieldAlert,
  Clock,
  Package,
  DollarSign,
  Loader2,
  Sparkles,
  CheckCircle2,
  Copy,
  RotateCcw,
  TrendingUp,
  TrendingDown,
  Building2,
  ChevronRight,
  X,
  Calendar,
  Target,
  ClipboardPlus,
} from "lucide-react";

/* ── Mock risk data ── */
type Severity = "critical" | "high" | "medium" | "low";
type RiskCategory = "delivery" | "quality" | "price";

interface RiskItem {
  id: string;
  customer: string;
  customerCode: string;
  category: RiskCategory;
  title: string;
  description: string;
  severity: Severity;
  trend: "up" | "down" | "stable";
  lastUpdated: string;
  dueDate?: string;
  impact: string;
}

const riskData: RiskItem[] = [
  { id: "r1", customer: "현대자동차", customerCode: "현대자동차", category: "delivery", title: "3월 납기 지연 리스크", description: "열연 라인 정비로 인해 GA강판 3월 납기 2주 지연 가능성", severity: "critical", trend: "up", lastUpdated: "2025-03-07", dueDate: "2025-03-20", impact: "약 1,200톤 영향" },
  { id: "r2", customer: "현대자동차", customerCode: "현대자동차", category: "quality", title: "GA강판 표면 품질 이슈", description: "최근 출하분 표면 결함 발생률 0.5% → 기준 0.3% 초과", severity: "high", trend: "stable", lastUpdated: "2025-03-05", impact: "클레임 발생 가능" },
  { id: "r3", customer: "기아", customerCode: "기아", category: "price", title: "2분기 가격 재협상 압박", description: "기아 구매팀에서 3% 인하 재요구. 경쟁사 가격 인하 언급", severity: "high", trend: "up", lastUpdated: "2025-03-06", impact: "연간 약 15억원 매출 영향" },
  { id: "r4", customer: "도요타", customerCode: "도요타", category: "quality", title: "표면 결함 재발 우려", description: "지난 분기 클레임 이후 개선 조치 시행 중. 모니터링 필요", severity: "medium", trend: "down", lastUpdated: "2025-03-04", impact: "수출 물량 감소 리스크" },
  { id: "r5", customer: "기아", customerCode: "기아", category: "delivery", title: "신규 모델 사양 확정 지연", description: "EV6 후속 모델 강판 사양 미확정으로 생산 준비 지연 우려", severity: "medium", trend: "stable", lastUpdated: "2025-03-03", dueDate: "2025-04-15", impact: "4월 양산 일정 차질" },
  { id: "r6", customer: "GM Korea", customerCode: "GM Korea", category: "delivery", title: "DP강 공급 부족 가능성", description: "수요 확대 대비 DP780 생산 능력 부족. 설비 투자 미확정", severity: "medium", trend: "up", lastUpdated: "2025-03-02", impact: "월 300톤 부족 예상" },
  { id: "r7", customer: "현대자동차", customerCode: "현대자동차", category: "price", title: "원자재 가격 연동 리스크", description: "철광석 가격 변동에 따른 마진 축소 리스크", severity: "low", trend: "down", lastUpdated: "2025-03-01", impact: "톤당 마진 2만원 감소" },
  { id: "r8", customer: "도요타", customerCode: "도요타", category: "price", title: "환율 변동 리스크", description: "엔화 약세 지속 시 수출 가격 경쟁력 약화", severity: "low", trend: "stable", lastUpdated: "2025-02-28", impact: "수익성 1~2% 하락" },
];

const categoryMeta: Record<RiskCategory, { label: string; icon: typeof Package; color: string }> = {
  delivery: { label: "납기", icon: Package, color: "text-blue-400" },
  quality: { label: "품질", icon: ShieldAlert, color: "text-amber-400" },
  price: { label: "가격", icon: DollarSign, color: "text-emerald-400" },
};

const severityMeta: Record<Severity, { label: string; color: string; bg: string }> = {
  critical: { label: "심각", color: "text-red-400", bg: "bg-red-500/15 border-red-500/20" },
  high: { label: "높음", color: "text-orange-400", bg: "bg-orange-500/15 border-orange-500/20" },
  medium: { label: "보통", color: "text-yellow-400", bg: "bg-yellow-500/15 border-yellow-500/20" },
  low: { label: "낮음", color: "text-green-400", bg: "bg-green-500/15 border-green-500/20" },
};

const trendLabel: Record<string, string> = { up: "악화 추세", down: "개선 추세", stable: "유지" };

/* ── Register Action Button with duplicate check ── */
function RegisterActionButton({ risk }: { risk: RiskItem }) {
  const [registered, setRegistered] = useState(false);
  const [checking, setChecking] = useState(true);
  const gatewayDraft = useMemo(() => createRiskGatewayDraft(risk), [risk]);
  const packet = gatewayDraft.packet;

  useEffect(() => {
    let cancelled = false;
    const sourceIds = Array.from(new Set([risk.id, packet?.task_id].filter(Boolean) as string[]));

    setChecking(true);
    setRegistered(false);

    void Promise.all(sourceIds.map((sourceId) => (
      supabase
        .from("tasks")
        .select("id")
        .eq("source_id", sourceId)
    ))).then((results) => {
      if (cancelled) {
        return;
      }

      setRegistered(results.some(({ data }) => Array.isArray(data) && data.length > 0));
    }).finally(() => {
      if (!cancelled) {
        setChecking(false);
      }
    });

    return () => {
      cancelled = true;
    };
  }, [packet?.task_id, risk.id]);

  const handleRegister = async () => {
    if (!packet) {
      toast.error("Gateway 판단을 만들 수 없어 작업으로 등록하지 못했습니다");
      return;
    }

    try {
      const task: TaskInsert = {
        title: `${risk.title} 대응`,
        description: [
          risk.description,
          "",
          `영향: ${risk.impact}`,
          `Gateway task type: ${packet.task_type}`,
          `Gateway packet id: ${packet.task_id}`,
          packet.required_approval
            ? `승인 필요: ${packet.approval_reason ?? "명시적 사용자 승인 필요"}`
            : "승인 불필요",
        ].join("\n"),
        source: "gateway",
        source_id: packet.task_id,
        severity: risk.severity,
        customer: risk.customer,
        category: risk.category,
        status: "pending",
      };
      const { error } = await supabase.from("tasks").insert(task);
      if (error) throw error;
      setRegistered(true);
      toast.success("대응 액션이 작업으로 등록되었습니다");
    } catch {
      toast.error("작업 등록에 실패했습니다");
    }
  };

  if (checking) return null;

  if (registered) {
    return (
      <div className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-status-completed/10 text-status-completed text-[11px] font-medium border border-status-completed/20">
        <CheckCircle2 className="w-3.5 h-3.5" />
        이미 등록된 액션입니다
      </div>
    );
  }

  return (
    <motion.button
      whileHover={{ scale: 1.01 }}
      whileTap={{ scale: 0.99 }}
      onClick={handleRegister}
      className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-secondary text-foreground text-[11px] font-medium hover:bg-secondary/80 border border-border/30 transition-colors"
    >
      <ClipboardPlus className="w-3.5 h-3.5" />
      대응 액션 등록
    </motion.button>
  );
}

/* ── Detail Slide Panel ── */
function RiskDetailPanel({
  risk,
  onClose,
  onAnalyze,
  analysis,
  isAnalyzing,
}: {
  risk: RiskItem;
  onClose: () => void;
  onAnalyze: (risk: RiskItem) => void;
  analysis: string;
  isAnalyzing: boolean;
}) {
  const cat = categoryMeta[risk.category];
  const sev = severityMeta[risk.severity];
  const analysisRef = useRef<HTMLDivElement>(null);
  const gatewayDraft = useMemo(() => createRiskGatewayDraft(risk), [risk]);
  const packet = gatewayDraft.packet;

  useEffect(() => {
    if (analysisRef.current) analysisRef.current.scrollTop = analysisRef.current.scrollHeight;
  }, [analysis]);

  return (
    <motion.div
      initial={{ x: "100%" }}
      animate={{ x: 0 }}
      exit={{ x: "100%" }}
      transition={{ type: "spring", stiffness: 300, damping: 30 }}
      className="absolute inset-y-0 right-0 w-[480px] max-w-full bg-background border-l border-border/50 flex flex-col z-10 shadow-2xl"
    >
      {/* Panel header */}
      <div className="flex items-center justify-between px-5 py-3 border-b border-border/50">
        <div className="flex items-center gap-2">
          <span className={`text-[9px] px-1.5 py-0.5 rounded border font-medium ${sev.bg} ${sev.color}`}>{sev.label}</span>
          <span className={`text-[9px] px-1.5 py-0.5 rounded bg-secondary/50 ${cat.color} flex items-center gap-0.5`}>
            <cat.icon className="w-2.5 h-2.5" />{cat.label}
          </span>
        </div>
        <button onClick={onClose} className="w-7 h-7 rounded-lg hover:bg-secondary flex items-center justify-center transition-colors">
          <X className="w-3.5 h-3.5 text-muted-foreground" />
        </button>
      </div>

      {/* Risk details */}
      <div className="flex-1 overflow-y-auto scrollbar-thin">
        <div className="px-5 py-4 space-y-4">
          {/* Title & customer */}
          <div>
            <h3 className="text-[15px] font-semibold text-foreground">{risk.title}</h3>
            <div className="flex items-center gap-2 mt-1.5">
              <Building2 className="w-3.5 h-3.5 text-muted-foreground" />
              <span className="text-[11px] text-muted-foreground">{risk.customer}</span>
            </div>
          </div>

          {/* Info grid */}
          <div className="grid grid-cols-2 gap-2.5">
            <div className="p-2.5 rounded-xl bg-secondary/30 border border-border/20">
              <div className="flex items-center gap-1.5 mb-1">
                <Target className="w-3 h-3 text-muted-foreground" />
                <span className="text-[9px] text-muted-foreground uppercase tracking-wider">영향도</span>
              </div>
              <p className="text-[11px] font-medium text-foreground">{risk.impact}</p>
            </div>
            <div className="p-2.5 rounded-xl bg-secondary/30 border border-border/20">
              <div className="flex items-center gap-1.5 mb-1">
                {risk.trend === "up" ? <TrendingUp className="w-3 h-3 text-red-400" /> : risk.trend === "down" ? <TrendingDown className="w-3 h-3 text-green-400" /> : <span className="w-3 h-0.5 bg-muted-foreground/30 rounded" />}
                <span className="text-[9px] text-muted-foreground uppercase tracking-wider">추세</span>
              </div>
              <p className={`text-[11px] font-medium ${risk.trend === "up" ? "text-red-400" : risk.trend === "down" ? "text-green-400" : "text-muted-foreground"}`}>{trendLabel[risk.trend]}</p>
            </div>
            <div className="p-2.5 rounded-xl bg-secondary/30 border border-border/20">
              <div className="flex items-center gap-1.5 mb-1">
                <Clock className="w-3 h-3 text-muted-foreground" />
                <span className="text-[9px] text-muted-foreground uppercase tracking-wider">최종 업데이트</span>
              </div>
              <p className="text-[11px] font-medium text-foreground">{risk.lastUpdated}</p>
            </div>
            {risk.dueDate && (
              <div className="p-2.5 rounded-xl bg-secondary/30 border border-border/20">
                <div className="flex items-center gap-1.5 mb-1">
                  <Calendar className="w-3 h-3 text-muted-foreground" />
                  <span className="text-[9px] text-muted-foreground uppercase tracking-wider">기한</span>
                </div>
                <p className="text-[11px] font-medium text-foreground">{risk.dueDate}</p>
              </div>
            )}
          </div>

          {/* Description */}
          <div className="p-3 rounded-xl bg-secondary/20 border border-border/20">
            <p className="text-[11px] text-muted-foreground leading-relaxed">{risk.description}</p>
          </div>

          {packet && (
            <section aria-label="Gateway Task Packet route" className="rounded-xl border border-primary/15 bg-primary/5 p-3">
              <div className="mb-2 flex items-center justify-between gap-2">
                <div className="flex items-center gap-1.5">
                  <Sparkles className="h-3.5 w-3.5 text-primary" />
                  <p className="text-[10px] font-semibold text-primary">Gateway Task Packet</p>
                </div>
                <span className="rounded-md border border-border/40 bg-background px-1.5 py-0.5 text-[9px] text-muted-foreground">
                  {gatewayDraft.bridge_status}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="rounded-lg border border-border/30 bg-background/70 p-2">
                  <p className="text-[9px] text-muted-foreground">Task Type</p>
                  <p className="mt-0.5 break-words text-[10px] font-semibold text-foreground">{packet.task_type}</p>
                </div>
                <div className="rounded-lg border border-border/30 bg-background/70 p-2">
                  <p className="text-[9px] text-muted-foreground">Status</p>
                  <p className="mt-0.5 text-[10px] font-semibold text-foreground">{packet.status}</p>
                </div>
              </div>
              <p className="mt-2 text-[9px] text-muted-foreground">Required Evidence</p>
              <div className="mt-1 flex flex-wrap gap-1">
                {packet.verification_requirements.map((requirement) => (
                  <span key={`${requirement.type}-${requirement.command_or_source}`} className="rounded-md border border-border/30 bg-background px-1.5 py-0.5 text-[9px] text-foreground">
                    {requirement.type}
                  </span>
                ))}
              </div>
              <p className="mt-2 text-[9px] text-muted-foreground">Forbidden Actions</p>
              <div className="mt-1 flex flex-wrap gap-1">
                {packet.forbidden_actions.slice(0, 3).map((action) => (
                  <span key={action} className="rounded-md border border-border/30 bg-background px-1.5 py-0.5 text-[9px] text-muted-foreground">
                    {action}
                  </span>
                ))}
              </div>
            </section>
          )}

          {/* AI Analysis button */}
          <motion.button
            whileHover={{ scale: 1.01 }}
            whileTap={{ scale: 0.99 }}
            onClick={() => onAnalyze(risk)}
            disabled={isAnalyzing}
            className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-primary text-primary-foreground text-[11px] font-medium hover:bg-primary/90 transition-colors disabled:opacity-50"
          >
            {isAnalyzing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
            {isAnalyzing ? "AI 분석 중..." : "AI 대응 전략 분석"}
          </motion.button>

          {/* Register action task button */}
          <RegisterActionButton risk={risk} />

          {/* AI Analysis result */}
          <AnimatePresence>
            {(analysis || isAnalyzing) && (
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 8 }}
                className="rounded-xl border border-border/30 overflow-hidden"
              >
                <div className={`flex items-center justify-between px-3.5 py-2 border-b border-border/30 ${isAnalyzing ? "bg-primary/5" : "bg-status-completed/5"}`}>
                  <div className="flex items-center gap-1.5">
                    {isAnalyzing ? (
                      <><Loader2 className="w-3 h-3 text-primary animate-spin" /><span className="text-[10px] text-primary font-medium">분석 중...</span></>
                    ) : (
                      <><CheckCircle2 className="w-3 h-3 text-status-completed" /><span className="text-[10px] text-status-completed font-medium">분석 완료</span></>
                    )}
                  </div>
                  {!isAnalyzing && analysis && (
                    <div className="flex items-center gap-1">
                      <button onClick={() => { navigator.clipboard.writeText(analysis); toast.success("복사되었습니다"); }} className="w-6 h-6 rounded-md hover:bg-secondary flex items-center justify-center"><Copy className="w-2.5 h-2.5 text-muted-foreground" /></button>
                      <button onClick={() => onAnalyze(risk)} className="w-6 h-6 rounded-md hover:bg-secondary flex items-center justify-center"><RotateCcw className="w-2.5 h-2.5 text-muted-foreground" /></button>
                    </div>
                  )}
                </div>
                <div ref={analysisRef} className="px-3.5 py-3 max-h-[400px] overflow-y-auto scrollbar-thin">
                  <div className="prose prose-sm dark:prose-invert max-w-none text-[12px] leading-relaxed">
                    <ReactMarkdown>{analysis}</ReactMarkdown>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </motion.div>
  );
}

/* ── Main Component ── */
interface RiskCheckModeProps {
  onBack: () => void;
}

type FilterCategory = "all" | RiskCategory;

export function RiskCheckMode({ onBack }: RiskCheckModeProps) {
  const [filterCategory, setFilterCategory] = useState<FilterCategory>("all");
  const [filterSeverity, setFilterSeverity] = useState<Severity | "all">("all");
  const [selectedRisk, setSelectedRisk] = useState<RiskItem | null>(null);
  const [analysis, setAnalysis] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [bulkAnalysis, setBulkAnalysis] = useState("");
  const [isBulkAnalyzing, setIsBulkAnalyzing] = useState(false);
  const bulkRef = useRef<HTMLDivElement>(null);

  const filtered = riskData.filter((r) => {
    const catMatch = filterCategory === "all" || r.category === filterCategory;
    const sevMatch = filterSeverity === "all" || r.severity === filterSeverity;
    return catMatch && sevMatch;
  });

  const stats = {
    critical: riskData.filter((r) => r.severity === "critical").length,
    high: riskData.filter((r) => r.severity === "high").length,
    medium: riskData.filter((r) => r.severity === "medium").length,
    low: riskData.filter((r) => r.severity === "low").length,
  };

  const handleCardClick = (risk: RiskItem) => {
    setSelectedRisk(risk);
    setAnalysis("");
  };

  const handleSingleAnalyze = async (risk: RiskItem) => {
    setIsAnalyzing(true);
    setAnalysis("");
    const prompt = buildPrompt([risk]);
    let fullText = "";
    try {
      await streamChat({
        messages: [{ role: "user", content: prompt }] as Msg[],
        onDelta: (chunk) => { fullText += chunk; setAnalysis(fullText); },
        onDone: () => setIsAnalyzing(false),
        onError: (e) => { toast.error(e); setIsAnalyzing(false); },
      });
    } catch {
      toast.error("분석 생성에 실패했습니다.");
      setIsAnalyzing(false);
    }
  };

  const handleBulkAnalyze = async () => {
    setIsBulkAnalyzing(true);
    setBulkAnalysis("");
    setSelectedRisk(null);
    const prompt = buildPrompt(filtered);
    let fullText = "";
    try {
      await streamChat({
        messages: [{ role: "user", content: prompt }] as Msg[],
        onDelta: (chunk) => { fullText += chunk; setBulkAnalysis(fullText); },
        onDone: () => setIsBulkAnalyzing(false),
        onError: (e) => { toast.error(e); setIsBulkAnalyzing(false); },
      });
    } catch {
      toast.error("분석 생성에 실패했습니다.");
      setIsBulkAnalyzing(false);
    }
  };

  useEffect(() => {
    if (bulkRef.current) bulkRef.current.scrollTop = bulkRef.current.scrollHeight;
  }, [bulkAnalysis]);

  const showBulk = bulkAnalysis || isBulkAnalyzing;

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden relative">
      {/* Header */}
      <div className="flex items-center gap-3 px-6 py-4 border-b border-border/50">
        <button onClick={onBack} className="w-8 h-8 rounded-lg hover:bg-secondary flex items-center justify-center transition-colors">
          <ArrowLeft className="w-4 h-4 text-muted-foreground" />
        </button>
        <div className="flex-1">
          <h2 className="text-[14px] font-semibold">리스크 점검</h2>
          <p className="text-[11px] text-muted-foreground">고객별 납기/품질/가격 리스크 현황</p>
        </div>
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={handleBulkAnalyze}
          disabled={isBulkAnalyzing}
          className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-primary text-primary-foreground text-[11px] font-medium hover:bg-primary/90 transition-colors disabled:opacity-50"
        >
          {isBulkAnalyzing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
          전체 AI 분석
        </motion.button>
      </div>

      <div className="flex-1 flex overflow-hidden relative">
        {/* Left: Dashboard */}
        <div className={`flex flex-col overflow-hidden transition-all ${showBulk ? "w-1/2 border-r border-border/30" : "flex-1"}`}>
          {/* Stats bar */}
          <div className="px-6 py-3 border-b border-border/30 flex items-center gap-3">
            {(["critical", "high", "medium", "low"] as Severity[]).map((sev) => (
              <button
                key={sev}
                onClick={() => setFilterSeverity(filterSeverity === sev ? "all" : sev)}
                className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg border text-[10px] font-medium transition-all ${
                  filterSeverity === sev ? severityMeta[sev].bg + " " + severityMeta[sev].color : "border-border/30 text-muted-foreground hover:border-border/60"
                }`}
              >
                <div className={`w-2 h-2 rounded-full ${sev === "critical" ? "bg-red-400" : sev === "high" ? "bg-orange-400" : sev === "medium" ? "bg-yellow-400" : "bg-green-400"}`} />
                {severityMeta[sev].label} {stats[sev]}
              </button>
            ))}
          </div>

          {/* Category filter */}
          <div className="px-6 py-2 border-b border-border/20 flex items-center gap-1.5">
            {([["all", "전체"], ["delivery", "납기"], ["quality", "품질"], ["price", "가격"]] as [FilterCategory, string][]).map(([cat, label]) => (
              <button
                key={cat}
                onClick={() => setFilterCategory(cat)}
                className={`px-3 py-1 rounded-md text-[10px] font-medium transition-all ${
                  filterCategory === cat ? "bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          {/* Risk list */}
          <div className="flex-1 overflow-y-auto px-6 py-3 space-y-2 scrollbar-thin">
            {filtered.map((risk, i) => {
              const cat = categoryMeta[risk.category];
              const sev = severityMeta[risk.severity];
              return (
                <motion.div
                  key={risk.id}
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.03 }}
                  onClick={() => handleCardClick(risk)}
                  className={`p-3.5 rounded-xl border cursor-pointer transition-all hover:border-border/80 group ${
                    selectedRisk?.id === risk.id ? "border-primary bg-primary/5" : "border-border/30 bg-secondary/10"
                  }`}
                >
                  <div className="flex items-start justify-between mb-1.5">
                    <div className="flex items-center gap-2">
                      <span className={`text-[9px] px-1.5 py-0.5 rounded border font-medium ${sev.bg} ${sev.color}`}>{sev.label}</span>
                      <span className={`text-[9px] px-1.5 py-0.5 rounded bg-secondary/50 ${cat.color} flex items-center gap-0.5`}>
                        <cat.icon className="w-2.5 h-2.5" />{cat.label}
                      </span>
                    </div>
                    <div className="flex items-center gap-1">
                      {risk.trend === "up" ? (
                        <TrendingUp className="w-3 h-3 text-red-400" />
                      ) : risk.trend === "down" ? (
                        <TrendingDown className="w-3 h-3 text-green-400" />
                      ) : (
                        <span className="w-3 h-0.5 bg-muted-foreground/30 rounded" />
                      )}
                      <ChevronRight className="w-3 h-3 text-muted-foreground/40 group-hover:text-muted-foreground transition-colors" />
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 mb-1">
                    <Building2 className="w-3 h-3 text-muted-foreground" />
                    <span className="text-[10px] text-muted-foreground">{risk.customerCode}</span>
                  </div>
                  <h3 className="text-[12px] font-medium text-foreground">{risk.title}</h3>
                  <p className="text-[10px] text-muted-foreground mt-1 line-clamp-1">{risk.description}</p>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-[9px] text-muted-foreground/70 flex items-center gap-1">
                      <AlertTriangle className="w-2.5 h-2.5" />{risk.impact}
                    </span>
                    <span className="text-[9px] text-muted-foreground/50 flex items-center gap-1">
                      <Clock className="w-2.5 h-2.5" />{risk.lastUpdated}
                    </span>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Right: Bulk AI Analysis */}
        <AnimatePresence>
          {showBulk && (
            <motion.div
              initial={{ opacity: 0, width: 0 }}
              animate={{ opacity: 1, width: "50%" }}
              exit={{ opacity: 0, width: 0 }}
              className="flex flex-col overflow-hidden"
            >
              <div className={`flex items-center justify-between px-5 py-3 border-b border-border/30 ${isBulkAnalyzing ? "bg-primary/5" : "bg-status-completed/5"}`}>
                <div className="flex items-center gap-2">
                  {isBulkAnalyzing ? (
                    <><Loader2 className="w-3.5 h-3.5 text-primary animate-spin" /><span className="text-[11px] text-primary font-medium">AI 분석 중...</span></>
                  ) : (
                    <><CheckCircle2 className="w-3.5 h-3.5 text-status-completed" /><span className="text-[11px] text-status-completed font-medium">분석 완료</span></>
                  )}
                </div>
                {!isBulkAnalyzing && (
                  <div className="flex items-center gap-1">
                    <button onClick={() => { navigator.clipboard.writeText(bulkAnalysis); toast.success("복사되었습니다"); }} className="w-7 h-7 rounded-md hover:bg-secondary flex items-center justify-center"><Copy className="w-3 h-3 text-muted-foreground" /></button>
                    <button onClick={() => setBulkAnalysis("")} className="w-7 h-7 rounded-md hover:bg-secondary flex items-center justify-center"><RotateCcw className="w-3 h-3 text-muted-foreground" /></button>
                  </div>
                )}
              </div>
              <div ref={bulkRef} className="flex-1 overflow-y-auto px-5 py-4 scrollbar-thin">
                <div className="prose prose-sm dark:prose-invert max-w-none text-[13px] leading-relaxed">
                  <ReactMarkdown>{bulkAnalysis}</ReactMarkdown>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Slide-in Detail Panel */}
        <AnimatePresence>
          {selectedRisk && (
            <RiskDetailPanel
              risk={selectedRisk}
              onClose={() => { setSelectedRisk(null); setAnalysis(""); }}
              onAnalyze={handleSingleAnalyze}
              analysis={analysis}
              isAnalyzing={isAnalyzing}
            />
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

/* ── Prompt builder ── */
function buildPrompt(targets: RiskItem[]) {
  const riskContext = targets
    .map((r) => `- [${severityMeta[r.severity].label}] ${r.customerCode} ${categoryMeta[r.category].label}: ${r.title}\n  상세: ${r.description}\n  영향: ${r.impact}\n  추세: ${r.trend === "up" ? "악화" : r.trend === "down" ? "개선" : "유지"}`)
    .join("\n\n");

  return `당신은 자동차 강판 마케팅/판매 전문 AI 비서입니다.
다음 리스크 항목들을 분석하고 대응 전략을 제시해주세요.

**리스크 항목:**
${riskContext}

다음 형식으로 분석해주세요:

1. **종합 리스크 평가** - 전체적인 리스크 수준과 긴급도 평가
2. **우선순위 권고** - 가장 먼저 대응해야 할 항목과 이유
3. **항목별 대응 전략** - 각 리스크에 대한 구체적 대응 방안
4. **예방 조치** - 리스크 확대를 방지하기 위한 선제적 조치
5. **모니터링 포인트** - 향후 주시해야 할 지표와 시점

마크다운으로 깔끔하게 작성해주세요.`;
}
