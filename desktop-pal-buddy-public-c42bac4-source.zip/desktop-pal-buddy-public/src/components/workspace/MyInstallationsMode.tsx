import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowLeft, Bot, Zap, Server, GitBranch, Puzzle,
  ToggleLeft, ToggleRight, Trash2, Search,
  Download, CheckCircle2, XCircle,
} from "lucide-react";
import { useInstalledItems, type InstalledItem } from "@/hooks/useInstalledItems";

const TYPE_META: Record<string, { label: string; icon: typeof Bot; color: string }> = {
  agent: { label: "에이전트", icon: Bot, color: "hsl(var(--primary))" },
  skill: { label: "스킬", icon: Zap, color: "hsl(var(--status-review))" },
  mcp: { label: "MCP", icon: Server, color: "hsl(var(--status-completed))" },
  workflow: { label: "자동화", icon: GitBranch, color: "hsl(var(--agent-market))" },
  plugin: { label: "플러그인", icon: Puzzle, color: "hsl(var(--agent-docs))" },
};

const TABS = [
  { id: "all", label: "전체" },
  { id: "agent", label: "에이전트" },
  { id: "skill", label: "스킬" },
  { id: "mcp", label: "MCP" },
  { id: "workflow", label: "자동화" },
  { id: "plugin", label: "플러그인" },
];

interface Props { onBack: () => void; }

export function MyInstallationsMode({ onBack }: Props) {
  const { items, loading, toggleActive, uninstall } = useInstalledItems();
  const [activeTab, setActiveTab] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");

  const filtered = items.filter(i => {
    const matchTab = activeTab === "all" || i.item_type === activeTab;
    const matchSearch = !searchQuery ||
      i.item_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      i.item_description?.toLowerCase().includes(searchQuery.toLowerCase());
    return matchTab && matchSearch;
  });

  const counts = {
    all: items.length,
    agent: items.filter(i => i.item_type === "agent").length,
    skill: items.filter(i => i.item_type === "skill").length,
    mcp: items.filter(i => i.item_type === "mcp").length,
    workflow: items.filter(i => i.item_type === "workflow").length,
    plugin: items.filter(i => i.item_type === "plugin").length,
  };

  return (
    <div className="flex-1 h-full overflow-y-auto p-6 space-y-5 scrollbar-thin">
      <div className="flex items-center gap-3">
        <button onClick={onBack} className="p-1.5 rounded-lg hover:bg-secondary transition-colors">
          <ArrowLeft className="w-4 h-4 text-muted-foreground" />
        </button>
        <div>
          <h1 className="text-lg font-semibold">내 설치 항목</h1>
          <p className="text-[12px] text-muted-foreground">설치한 에이전트, 스킬, MCP, 자동화를 관리합니다</p>
        </div>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-5 gap-3">
        {(["agent", "skill", "mcp", "workflow", "plugin"] as const).map(type => {
          const meta = TYPE_META[type];
          const Icon = meta.icon;
          const count = counts[type];
          const activeCount = items.filter(i => i.item_type === type && i.is_active).length;
          return (
            <motion.div key={type} whileHover={{ y: -1 }}
              className="rounded-xl border border-border/50 p-3 bg-card/50 cursor-pointer hover:border-border transition-colors"
              onClick={() => setActiveTab(type)}>
              <div className="flex items-center gap-2 mb-2">
                <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: `${meta.color}15` }}>
                  <Icon className="w-3.5 h-3.5" style={{ color: meta.color }} />
                </div>
                <span className="text-[11px] font-medium text-muted-foreground">{meta.label}</span>
              </div>
              <p className="text-[18px] font-bold text-foreground">{count}</p>
              <p className="text-[10px] text-muted-foreground">활성 {activeCount}개</p>
            </motion.div>
          );
        })}
      </div>

      {/* Search + Tabs */}
      <div className="flex items-center gap-3">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input type="text" value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
            placeholder="설치 항목 검색..."
            className="w-full pl-9 pr-4 py-2 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none transition-colors" />
        </div>
        <div className="flex gap-1">
          {TABS.map(tab => (
            <button key={tab.id} onClick={() => setActiveTab(tab.id)}
              className={`px-2.5 py-1.5 rounded-lg text-[11px] font-medium transition-colors ${
                activeTab === tab.id ? "bg-primary/15 text-primary" : "text-muted-foreground hover:bg-secondary"
              }`}>
              {tab.label} {counts[tab.id as keyof typeof counts] > 0 && <span className="ml-0.5 opacity-60">({counts[tab.id as keyof typeof counts]})</span>}
            </button>
          ))}
        </div>
      </div>

      {/* Items list */}
      {loading ? (
        <div className="flex items-center justify-center py-20">
          <div className="w-6 h-6 border-2 border-primary/30 border-t-primary rounded-full animate-spin" />
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16">
          <Download className="w-10 h-10 text-muted-foreground/30 mx-auto mb-3" />
          <p className="text-[13px] text-muted-foreground">설치된 항목이 없습니다</p>
          <p className="text-[11px] text-muted-foreground/60 mt-1">연결 센터에서 에이전트, 스킬, MCP를 설치해보세요</p>
        </div>
      ) : (
        <div className="space-y-2">
          <AnimatePresence>
            {filtered.map(item => (
              <InstalledItemCard key={item.id} item={item} onToggle={toggleActive} onRemove={uninstall} />
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
}

function InstalledItemCard({ item, onToggle, onRemove }: {
  item: InstalledItem;
  onToggle: (id: string, active: boolean) => void;
  onRemove: (id: string) => void;
}) {
  const [confirmDelete, setConfirmDelete] = useState(false);
  const meta = TYPE_META[item.item_type] || TYPE_META.agent;
  const Icon = meta.icon;

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 5 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, x: -20 }}
      className={`rounded-xl border p-4 flex items-center gap-4 transition-colors ${
        item.is_active ? "border-border/50 bg-card/50" : "border-border/30 bg-muted/20 opacity-60"
      }`}
    >
      <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
        style={{ background: `${meta.color}15` }}>
        <Icon className="w-5 h-5" style={{ color: meta.color }} />
      </div>

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <h3 className="text-[13px] font-semibold text-foreground truncate">{item.item_name}</h3>
          <span className="text-[9px] px-1.5 py-0.5 rounded-full font-medium"
            style={{ background: `${meta.color}15`, color: meta.color }}>
            {meta.label}
          </span>
          {item.is_active ? (
            <CheckCircle2 className="w-3 h-3 text-emerald-500 flex-shrink-0" />
          ) : (
            <XCircle className="w-3 h-3 text-muted-foreground flex-shrink-0" />
          )}
        </div>
        {item.item_description && (
          <p className="text-[11px] text-muted-foreground mt-0.5 truncate">{item.item_description}</p>
        )}
        <p className="text-[10px] text-muted-foreground/60 mt-1">
          {new Date(item.installed_at).toLocaleDateString("ko-KR")} 설치
        </p>
      </div>

      <div className="flex items-center gap-2 flex-shrink-0">
        <button onClick={() => onToggle(item.id, !item.is_active)}
          className="p-1.5 rounded-lg hover:bg-secondary transition-colors" title={item.is_active ? "비활성화" : "활성화"}>
          {item.is_active ? (
            <ToggleRight className="w-5 h-5 text-primary" />
          ) : (
            <ToggleLeft className="w-5 h-5 text-muted-foreground" />
          )}
        </button>

        {confirmDelete ? (
          <div className="flex items-center gap-1">
            <button onClick={() => { onRemove(item.id); setConfirmDelete(false); }}
              className="px-2 py-1 rounded-lg text-[10px] font-medium bg-destructive/10 text-destructive hover:bg-destructive/20 transition-colors">
              삭제
            </button>
            <button onClick={() => setConfirmDelete(false)}
              className="px-2 py-1 rounded-lg text-[10px] font-medium bg-secondary text-muted-foreground hover:bg-secondary/80 transition-colors">
              취소
            </button>
          </div>
        ) : (
          <button onClick={() => setConfirmDelete(true)}
            className="p-1.5 rounded-lg hover:bg-destructive/10 transition-colors" title="제거">
            <Trash2 className="w-4 h-4 text-muted-foreground hover:text-destructive" />
          </button>
        )}
      </div>
    </motion.div>
  );
}
