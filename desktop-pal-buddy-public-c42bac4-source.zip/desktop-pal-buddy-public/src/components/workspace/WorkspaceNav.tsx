import { motion } from "framer-motion";
import {
  AlertTriangle,
  Bot,
  CheckSquare,
  ChevronLeft,
  FileText,
  GitBranch,
  Home,
  MessagesSquare,
  Package,
  Search,
  Settings,
  ShieldAlert,
  Clock,
  Star,
  Sparkles,
  Store,
  Wand2,
  Users,
  type LucideIcon,
} from "lucide-react";

interface NavItem {
  id: string;
  label: string;
  icon: LucideIcon;
  badge?: number;
  activeModes?: string[];
}

interface NavSection {
  title: string;
  items: NavItem[];
}

const navSections: NavSection[] = [
  {
    title: "업무",
    items: [
      { id: "home", label: "홈", icon: Home },
      { id: "gateway", label: "요청", icon: Wand2 },
      { id: "tasks", label: "작업", icon: CheckSquare },
      { id: "customers", label: "고객", icon: Users, activeModes: ["meeting", "response"] },
      { id: "risk", label: "리스크", icon: ShieldAlert },
      { id: "search", label: "문서", icon: Search },
      { id: "reports", label: "보고서", icon: FileText, activeModes: ["report", "performance"] },
    ],
  },
  {
    title: "운영",
    items: [
      { id: "workflows", label: "자동화", icon: GitBranch, activeModes: ["agents", "agent-meeting"] },
      { id: "marketplace", label: "연결", icon: Store, activeModes: ["my-installations"] },
      { id: "settings", label: "설정", icon: Settings },
    ],
  },
];

const secondaryItems: NavItem[] = [
  { id: "agents", label: "에이전트", icon: Bot },
  { id: "agent-meeting", label: "회의", icon: MessagesSquare },
  { id: "my-installations", label: "설치", icon: Package },
  { id: "alerts", label: "알림", icon: AlertTriangle, badge: 2 },
];

const recentItems = [
  { label: "H사 납기 리스크 분석", time: "10분 전", mode: "risk" },
  { label: "K사 회의 브리핑", time: "1시간 전", mode: "meeting" },
  { label: "T사 가격 협상 초안", time: "어제", mode: "response" },
];

const pinnedCustomers = [
  { label: "현대자동차", status: "active" },
  { label: "기아", status: "active" },
  { label: "GM Korea", status: "idle" },
];

interface WorkspaceNavProps {
  activeMode: string;
  onModeChange: (mode: string, context?: Record<string, string>) => void;
  onClose: () => void;
}

export function WorkspaceNav({ activeMode, onModeChange, onClose }: WorkspaceNavProps) {
  const isItemActive = (item: NavItem) =>
    activeMode === item.id || item.activeModes?.includes(activeMode);

  return (
    <div className="w-44 sm:w-56 h-full flex flex-col bg-sidebar text-sidebar-foreground border-r border-sidebar-border flex-shrink-0">
      {/* Header */}
      <div className="px-4 py-4 flex items-center justify-between border-b border-sidebar-border">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-sidebar-primary/20 ring-1 ring-sidebar-primary/30 flex items-center justify-center">
            <Sparkles className="w-3.5 h-3.5 text-sidebar-primary" />
          </div>
          <span className="text-sm font-semibold tracking-tight text-sidebar-foreground">Prometheus</span>
        </div>
        <motion.button
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
          onClick={onClose}
          aria-label="워크스페이스 닫기"
          className="w-6 h-6 rounded-md hover:bg-sidebar-accent flex items-center justify-center transition-colors"
        >
          <ChevronLeft className="w-4 h-4 text-sidebar-foreground/60" />
        </motion.button>
      </div>

      {/* Main nav */}
      <div className="flex-1 overflow-y-auto py-3 px-2 space-y-0.5 scrollbar-thin">
        {navSections.map((section) => (
          <div key={section.title} className="pb-2">
            <div className="px-3 pb-1.5 pt-2 text-[10px] font-semibold text-sidebar-foreground/45">
              {section.title}
            </div>
            <div className="space-y-0.5">
              {section.items.map((item) => {
                const isActive = isItemActive(item);
                return (
                  <button
                    key={item.id}
                    onClick={() => onModeChange(item.id)}
                    aria-current={isActive ? "page" : undefined}
                    aria-pressed={isActive}
                    className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-[13px] transition-colors ${
                      isActive
                        ? "bg-sidebar-primary/20 text-sidebar-primary font-medium"
                        : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                    }`}
                  >
                    <item.icon className="w-4 h-4 flex-shrink-0" />
                    <span className="flex-1 text-left">{item.label}</span>
                    {item.badge && (
                      <span className="min-w-5 h-5 rounded-full bg-status-alert/20 text-status-alert text-[10px] font-bold flex items-center justify-center">
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}

        <div className="px-1 pt-1">
          <div className="mb-2 px-2 text-[10px] font-semibold text-sidebar-foreground/45">
            세부 도구
          </div>
          <div className="grid grid-cols-2 gap-1.5">
            {secondaryItems.map((item) => {
              const isActive = isItemActive(item);
              return (
                <button
                  key={item.id}
                  onClick={() => onModeChange(item.id)}
                  aria-current={isActive ? "page" : undefined}
                  aria-pressed={isActive}
                  className={`min-h-8 rounded-lg px-2 text-[11px] transition-colors flex items-center justify-center gap-1.5 ${
                    isActive
                      ? "bg-sidebar-primary/15 text-sidebar-primary font-medium"
                      : "bg-sidebar-accent/35 text-sidebar-foreground/60 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                  }`}
                >
                  <item.icon className="w-3.5 h-3.5 flex-shrink-0" />
                  <span>{item.label}</span>
                  {item.badge && (
                    <span className="min-w-4 h-4 rounded-full bg-status-alert/20 text-status-alert text-[9px] font-bold flex items-center justify-center">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Recent work */}
        <div className="pt-4 px-1">
          <div className="flex items-center gap-1.5 mb-2">
            <Clock className="w-3 h-3 text-sidebar-foreground/50" />
            <span className="text-[10px] font-medium text-sidebar-foreground/50 uppercase tracking-wider">
              최근 작업
            </span>
          </div>
          {recentItems.map((item, i) => (
            <button
              key={i}
              onClick={() => onModeChange(item.mode)}
              className="w-full text-left px-2 py-1.5 rounded-lg text-[11px] text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground transition-colors"
            >
              <div className="truncate">{item.label}</div>
              <div className="text-[9px] text-sidebar-foreground/40 mt-0.5">{item.time}</div>
            </button>
          ))}
        </div>

        {/* Pinned customers */}
        <div className="pt-4 px-1">
          <div className="flex items-center gap-1.5 mb-2">
            <Star className="w-3 h-3 text-sidebar-foreground/50" />
            <span className="text-[10px] font-medium text-sidebar-foreground/50 uppercase tracking-wider">
              고정 고객
            </span>
          </div>
          {pinnedCustomers.map((item, i) => (
            <button
              key={i}
              onClick={() => onModeChange("customers", { customer: item.label })}
              className="w-full text-left px-2 py-1.5 rounded-lg text-[11px] text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground transition-colors flex items-center gap-2"
            >
              <div
                className="w-1.5 h-1.5 rounded-full"
                style={{
                  background:
                    item.status === "active"
                      ? "hsl(var(--status-completed))"
                      : "hsl(var(--status-idle))",
                }}
              />
              {item.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
