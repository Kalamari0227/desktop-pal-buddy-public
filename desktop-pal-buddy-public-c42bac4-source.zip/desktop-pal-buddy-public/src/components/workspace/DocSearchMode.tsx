import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import ReactMarkdown from "react-markdown";
import { streamChat, type Msg } from "@/lib/streamChat";
import { toast } from "sonner";
import {
  ArrowLeft,
  Search,
  FileText,
  Loader2,
  Sparkles,
  CheckCircle2,
  RotateCcw,
  Copy,
  Building2,
  Tag,
  Calendar,
  ChevronRight,
  Filter,
} from "lucide-react";

/* ── Mock document data ── */
const mockDocuments = [
  { id: "d1", title: "H사 자동차 강판 납기 조정 회의록", type: "회의록", customer: "현대자동차", date: "2025-03-01", tags: ["납기", "GA강판"], snippet: "H사 측 요청으로 3월 납기 일정을 2주 연장 합의. 4월부터 정상화 목표." },
  { id: "d2", title: "K사 신규 모델 강판 사양서", type: "사양서", customer: "기아", date: "2025-02-28", tags: ["사양", "신규모델", "DP강"], snippet: "EV6 후속 모델용 DP590 강판 사양 확정. 두께 1.2mm, 인장강도 590MPa 이상." },
  { id: "d3", title: "1분기 자동차 강판 시장 동향 보고서", type: "보고서", customer: "내부", date: "2025-02-25", tags: ["시장동향", "1분기", "가격"], snippet: "글로벌 철강 가격 하락세 속 자동차 강판은 수요 증가로 프리미엄 유지." },
  { id: "d4", title: "T사 품질 이슈 분석 보고서", type: "보고서", customer: "도요타", date: "2025-02-20", tags: ["품질", "클레임", "표면결함"], snippet: "표면 결함 발생 원인: 열연 공정 중 스케일 제거 불량. 개선 조치 완료." },
  { id: "d5", title: "H사 가격 협상 전략 메모", type: "메모", customer: "현대자동차", date: "2025-02-18", tags: ["가격", "협상", "전략"], snippet: "2분기 가격 인상 5% 제안 예정. 원자재 가격 상승분 반영 근거 준비." },
  { id: "d6", title: "자동차 강판 품질 인증 현황", type: "보고서", customer: "내부", date: "2025-02-15", tags: ["품질", "인증", "IATF"], snippet: "IATF 16949 재인증 완료. H사, K사 신규 인증 시험 진행 중." },
  { id: "d7", title: "GM Korea DP강 공급 확대 제안서", type: "제안서", customer: "GM Korea", date: "2025-02-10", tags: ["DP강", "공급", "제안"], snippet: "DP780 강판 월 공급량 500톤 → 800톤 확대 제안. 설비 투자 필요." },
  { id: "d8", title: "K사 가격 재협상 회의록", type: "회의록", customer: "기아", date: "2025-02-05", tags: ["가격", "협상"], snippet: "K사 3% 인하 요구. 당사 원가 구조상 1.5% 이상 인하 불가 입장 전달." },
];

const docTypes = ["전체", "회의록", "보고서", "사양서", "제안서", "메모"] as const;

interface DocSearchModeProps {
  onBack: () => void;
}

type Step = "search" | "results" | "summary";

export function DocSearchMode({ onBack }: DocSearchModeProps) {
  const [step, setStep] = useState<Step>("search");
  const [query, setQuery] = useState("");
  const [filterType, setFilterType] = useState<string>("전체");
  const [results, setResults] = useState<typeof mockDocuments>([]);
  const [selectedDocs, setSelectedDocs] = useState<string[]>([]);
  const [summary, setSummary] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const [isSummarizing, setIsSummarizing] = useState(false);
  const resultRef = useRef<HTMLDivElement>(null);

  const handleSearch = () => {
    if (!query.trim()) return;
    setIsSearching(true);
    setSelectedDocs([]);

    // Simulate search with filtering
    setTimeout(() => {
      const q = query.toLowerCase();
      const filtered = mockDocuments.filter((doc) => {
        const matchesQuery =
          doc.title.toLowerCase().includes(q) ||
          doc.snippet.toLowerCase().includes(q) ||
          doc.tags.some((t) => t.toLowerCase().includes(q)) ||
          doc.customer.toLowerCase().includes(q);
        const matchesType = filterType === "전체" || doc.type === filterType;
        return matchesQuery && matchesType;
      });
      setResults(filtered.length > 0 ? filtered : mockDocuments.slice(0, 4));
      setIsSearching(false);
      setStep("results");
    }, 600);
  };

  const toggleDoc = (id: string) => {
    setSelectedDocs((prev) =>
      prev.includes(id) ? prev.filter((d) => d !== id) : [...prev, id]
    );
  };

  const handleSummarize = async () => {
    const docs = results.filter((d) => selectedDocs.includes(d.id));
    if (docs.length === 0) {
      toast.error("요약할 문서를 선택하세요");
      return;
    }

    setStep("summary");
    setIsSummarizing(true);
    setSummary("");

    const docsContext = docs
      .map(
        (d) =>
          `**${d.title}** (${d.type}, ${d.customer}, ${d.date})\n태그: ${d.tags.join(", ")}\n내용: ${d.snippet}`
      )
      .join("\n\n---\n\n");

    const prompt = `당신은 자동차 강판 마케팅/판매 전문 AI 비서입니다.
다음 문서들을 분석하고 종합 요약해주세요.

**검색어:** "${query}"

**선택된 문서들:**
${docsContext}

다음 형식으로 요약을 작성해주세요:

1. **핵심 요약** - 선택된 문서들의 주요 내용을 3-4문장으로 요약
2. **문서별 주요 포인트** - 각 문서의 핵심 사항
3. **연관 이슈** - 문서 간 연관되는 이슈나 시사점
4. **액션 아이템** - 후속 조치가 필요한 사항
5. **참고 사항** - 추가로 확인이 필요한 내용

마크다운으로 깔끔하게 작성해주세요.`;

    const messages: Msg[] = [{ role: "user", content: prompt }];
    let fullText = "";

    try {
      await streamChat({
        messages,
        onDelta: (chunk) => {
          fullText += chunk;
          setSummary(fullText);
        },
        onDone: () => setIsSummarizing(false),
        onError: (e) => {
          toast.error(e);
          setIsSummarizing(false);
          setStep("results");
        },
      });
    } catch {
      toast.error("요약 생성에 실패했습니다.");
      setIsSummarizing(false);
      setStep("results");
    }
  };

  const handleReset = () => {
    setStep("search");
    setQuery("");
    setResults([]);
    setSelectedDocs([]);
    setSummary("");
  };

  useEffect(() => {
    if (resultRef.current && step === "summary") {
      resultRef.current.scrollTop = resultRef.current.scrollHeight;
    }
  }, [summary, step]);

  const typeColor = (type: string) => {
    switch (type) {
      case "회의록": return "bg-blue-500/10 text-blue-400 border-blue-500/20";
      case "보고서": return "bg-emerald-500/10 text-emerald-400 border-emerald-500/20";
      case "사양서": return "bg-violet-500/10 text-violet-400 border-violet-500/20";
      case "제안서": return "bg-amber-500/10 text-amber-400 border-amber-500/20";
      case "메모": return "bg-rose-500/10 text-rose-400 border-rose-500/20";
      default: return "bg-secondary text-muted-foreground border-border/50";
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-3 px-6 py-4 border-b border-border/50">
        <button
          onClick={step === "search" ? onBack : handleReset}
          className="w-8 h-8 rounded-lg hover:bg-secondary flex items-center justify-center transition-colors"
        >
          <ArrowLeft className="w-4 h-4 text-muted-foreground" />
        </button>
        <div className="flex-1">
          <h2 className="text-[14px] font-semibold">문서 검색/요약</h2>
          <p className="text-[11px] text-muted-foreground">
            {step === "search" && "키워드를 입력하여 관련 문서를 검색하세요"}
            {step === "results" && `"${query}" 검색 결과 — ${results.length}건`}
            {step === "summary" && "AI 문서 요약"}
          </p>
        </div>
        <div className="flex items-center gap-1.5">
          {(["search", "results", "summary"] as const).map((s, i) => (
            <div
              key={s}
              className={`h-1.5 rounded-full transition-all ${
                step === s
                  ? "w-6 bg-primary"
                  : i < ["search", "results", "summary"].indexOf(step)
                  ? "w-4 bg-primary/40"
                  : "w-4 bg-secondary"
              }`}
            />
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        <AnimatePresence mode="wait">
          {/* Step 1: Search */}
          {step === "search" && (
            <motion.div
              key="search"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="p-6 space-y-5"
            >
              {/* Search input */}
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <input
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                  placeholder="검색어 입력 (예: 납기, 품질, H사, DP강...)"
                  className="w-full pl-11 pr-4 py-3 rounded-xl border border-border/50 bg-secondary/10 text-[13px] text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:border-primary/50 transition-colors"
                  autoFocus
                />
              </div>

              {/* Filter */}
              <div>
                <div className="flex items-center gap-1.5 mb-2">
                  <Filter className="w-3.5 h-3.5 text-muted-foreground" />
                  <label className="text-[11px] font-medium text-muted-foreground">문서 유형</label>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {docTypes.map((type) => (
                    <button
                      key={type}
                      onClick={() => setFilterType(type)}
                      className={`px-3 py-1.5 rounded-lg border text-[11px] transition-all ${
                        filterType === type
                          ? "border-primary bg-primary/10 text-primary font-medium"
                          : "border-border/50 bg-secondary/20 text-muted-foreground hover:border-border"
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              {/* Quick suggestions */}
              <div>
                <label className="text-[11px] font-medium text-muted-foreground mb-2 block">추천 검색어</label>
                <div className="flex flex-wrap gap-2">
                  {["납기 지연", "품질 이슈", "가격 협상", "DP강", "H사 회의록", "시장 동향"].map((s) => (
                    <button
                      key={s}
                      onClick={() => { setQuery(s); }}
                      className="px-3 py-1.5 rounded-lg bg-secondary/30 border border-border/30 text-[11px] text-muted-foreground hover:bg-secondary/50 hover:text-foreground transition-colors"
                    >
                      {s}
                    </button>
                  ))}
                </div>
              </div>

              {/* Search button */}
              <motion.button
                whileHover={{ scale: 1.01 }}
                whileTap={{ scale: 0.99 }}
                onClick={handleSearch}
                disabled={!query.trim()}
                className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-primary text-primary-foreground font-medium text-[13px] hover:bg-primary/90 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <Search className="w-4 h-4" />
                문서 검색
              </motion.button>

              {/* Recent documents */}
              <div>
                <label className="text-[11px] font-medium text-muted-foreground mb-2 block">최근 문서</label>
                <div className="space-y-1.5">
                  {mockDocuments.slice(0, 3).map((doc) => (
                    <button
                      key={doc.id}
                      onClick={() => { setQuery(doc.title); }}
                      className="w-full flex items-center gap-3 p-2.5 rounded-lg hover:bg-secondary/30 transition-colors text-left"
                    >
                      <FileText className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="text-[11px] text-foreground truncate">{doc.title}</p>
                        <p className="text-[10px] text-muted-foreground">{doc.customer} · {doc.date}</p>
                      </div>
                      <ChevronRight className="w-3 h-3 text-muted-foreground/50" />
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {/* Step 2: Results */}
          {step === "results" && (
            <motion.div
              key="results"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="flex flex-col h-full"
            >
              {isSearching ? (
                <div className="flex-1 flex items-center justify-center">
                  <div className="text-center space-y-3">
                    <Loader2 className="w-8 h-8 text-primary animate-spin mx-auto" />
                    <p className="text-[12px] text-muted-foreground">문서 검색 중...</p>
                  </div>
                </div>
              ) : (
                <>
                  {/* Search bar */}
                  <div className="px-6 py-3 border-b border-border/30">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
                      <input
                        type="text"
                        value={query}
                        onChange={(e) => setQuery(e.target.value)}
                        onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                        className="w-full pl-9 pr-3 py-2 rounded-lg border border-border/50 bg-secondary/10 text-[12px] text-foreground focus:outline-none focus:border-primary/50 transition-colors"
                      />
                    </div>
                  </div>

                  {/* Results list */}
                  <div className="flex-1 overflow-y-auto px-6 py-4 space-y-2 scrollbar-thin">
                    {results.map((doc, i) => (
                      <motion.div
                        key={doc.id}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.05 }}
                        onClick={() => toggleDoc(doc.id)}
                        className={`p-4 rounded-xl border cursor-pointer transition-all ${
                          selectedDocs.includes(doc.id)
                            ? "border-primary bg-primary/5"
                            : "border-border/30 bg-secondary/10 hover:border-border/60"
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          <div className={`w-5 h-5 rounded border-2 flex items-center justify-center flex-shrink-0 mt-0.5 transition-colors ${
                            selectedDocs.includes(doc.id)
                              ? "border-primary bg-primary"
                              : "border-border/60"
                          }`}>
                            {selectedDocs.includes(doc.id) && (
                              <CheckCircle2 className="w-3 h-3 text-primary-foreground" />
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <span className={`text-[9px] px-1.5 py-0.5 rounded border ${typeColor(doc.type)}`}>
                                {doc.type}
                              </span>
                              <span className="text-[10px] text-muted-foreground flex items-center gap-1">
                                <Building2 className="w-3 h-3" />{doc.customer}
                              </span>
                            </div>
                            <h3 className="text-[12px] font-medium text-foreground">{doc.title}</h3>
                            <p className="text-[11px] text-muted-foreground mt-1 line-clamp-2">{doc.snippet}</p>
                            <div className="flex items-center gap-2 mt-2">
                              <span className="text-[10px] text-muted-foreground/70 flex items-center gap-1">
                                <Calendar className="w-3 h-3" />{doc.date}
                              </span>
                              <div className="flex gap-1">
                                {doc.tags.map((tag) => (
                                  <span key={tag} className="text-[9px] px-1.5 py-0.5 rounded bg-secondary/50 text-muted-foreground flex items-center gap-0.5">
                                    <Tag className="w-2.5 h-2.5" />{tag}
                                  </span>
                                ))}
                              </div>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </div>

                  {/* Bottom action */}
                  <div className="px-6 py-3 border-t border-border/50 flex items-center justify-between">
                    <span className="text-[11px] text-muted-foreground">
                      {selectedDocs.length}건 선택됨
                    </span>
                    <motion.button
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                      onClick={handleSummarize}
                      disabled={selectedDocs.length === 0}
                      className="flex items-center gap-1.5 px-5 py-2 rounded-lg bg-primary text-primary-foreground text-[11px] font-medium hover:bg-primary/90 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      AI 요약
                    </motion.button>
                  </div>
                </>
              )}
            </motion.div>
          )}

          {/* Step 3: Summary */}
          {step === "summary" && (
            <motion.div
              key="summary"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex flex-col h-full"
            >
              <div className={`flex items-center gap-2 px-6 py-3 border-b border-border/30 ${isSummarizing ? "bg-primary/5" : "bg-status-completed/5"}`}>
                {isSummarizing ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 text-primary animate-spin" />
                    <span className="text-[11px] text-primary font-medium">AI 요약 생성 중...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5 text-status-completed" />
                    <span className="text-[11px] text-status-completed font-medium">요약 완료 — {selectedDocs.length}건 분석</span>
                  </>
                )}
              </div>

              <div ref={resultRef} className="flex-1 overflow-y-auto px-6 py-4 scrollbar-thin">
                <div className="prose prose-sm dark:prose-invert max-w-none text-[13px] leading-relaxed">
                  <ReactMarkdown>{summary}</ReactMarkdown>
                </div>
              </div>

              {!isSummarizing && (
                <div className="px-6 py-3 border-t border-border/50 flex items-center gap-2">
                  <button
                    onClick={handleReset}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-border/50 text-[11px] text-muted-foreground hover:bg-secondary transition-colors"
                  >
                    <RotateCcw className="w-3 h-3" />
                    새 검색
                  </button>
                  <button
                    onClick={() => setStep("results")}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-border/50 text-[11px] text-muted-foreground hover:bg-secondary transition-colors"
                  >
                    <Search className="w-3 h-3" />
                    결과로 돌아가기
                  </button>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(summary);
                      toast.success("클립보드에 복사되었습니다");
                    }}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-border/50 text-[11px] text-muted-foreground hover:bg-secondary transition-colors"
                  >
                    <Copy className="w-3 h-3" />
                    복사
                  </button>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
