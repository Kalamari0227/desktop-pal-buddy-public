import { fireEvent, render, screen, within } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import type { CompanyRuntimeClient, CompanyRuntimeResponse } from "@/lib/companyRuntimeClient";
import { CompanyLineagePanel } from "./CompanyLineagePanel";

const epoch = "f7091d6f-e310-46f5-ae2f-a761f136f36a";
const strategyVersionId = "f6846f3d-1aa0-487a-88a1-c383ba9076ea";
const taskId = "9e650d6d-9e9f-4a09-b041-e345d16620a8";
const packetTaskId = "27862353-b4b6-43d3-bec2-2e4afe57dc06";

function client(snapshot: unknown): CompanyRuntimeClient {
  const response: CompanyRuntimeResponse = {
    schemaVersion: 1,
    requestId: crypto.randomUUID(),
    epoch,
    actorSessionRevision: 1,
    ok: true,
    payload: {
      status: { epoch, actorId: "management-demo", role: "management", actorSessionRevision: 1, stopped: false },
      snapshot,
    },
  };
  return {
    bootstrap: vi.fn(async () => response),
    read: vi.fn(async () => response),
    submit: vi.fn(), approve: vi.fn(), execute: vi.fn(), role: vi.fn(), stop: vi.fn(), resume: vi.fn(), reset: vi.fn(), cancel: vi.fn(), reconcile: vi.fn(),
    subscribe: vi.fn(() => vi.fn()),
    getContext: vi.fn(() => ({ epoch, actorSessionRevision: 1 })),
  };
}

function snapshot() {
  return {
    currentEpoch: epoch,
    current: {
      activeStrategyRef: { strategy_id: "STRATEGY-DEMO-PRODUCTION", strategy_version_id: strategyVersionId },
      strategyVersions: [{ strategy_id: "STRATEGY-DEMO-PRODUCTION", strategy_version_id: strategyVersionId, version: 1, objective: "준비 상태 확인", review_question: "준비됐는가?", content_hash: "a".repeat(64) }],
    },
    records: {
      tasks: [{
        workboardTaskId: taskId, packetTaskId, epoch, status: "done",
        packet: { strategy_ref: { strategy_id: "STRATEGY-DEMO-PRODUCTION", strategy_version_id: strategyVersionId }, request_summary: "첫 실행 업무" },
        currentProposal: { intentId: "da1b4929-a2ef-45a4-a1cd-acde937da2c5", revision: 4 },
        currentApprovalId: null, executionId: null, businessOutcome: { status: "unobserved" },
      }],
      actionIntents: [], approvals: [], executions: [], readbackEvidence: [], assessmentEvidence: [], experienceDrafts: [], learningAssets: [], learningManagementStrategyReview: [], learningProvenance: [], strategyReviews: [],
    },
    history: [],
  };
}

function adoptedSnapshot() {
  const base = snapshot();
  const v2Id = "4caac17f-90ab-43ae-93a4-c925e3f144af";
  return {
    ...base,
    current: {
      ...base.current,
      activeStrategyRef: { strategy_id: "STRATEGY-DEMO-PRODUCTION", strategy_version_id: v2Id },
      strategyVersions: [
        ...base.current.strategyVersions,
        { strategy_id: "STRATEGY-DEMO-PRODUCTION", strategy_version_id: v2Id, version: 2, objective: "검사 후 판단", review_question: "준비됐는가?", content_hash: "b".repeat(64) },
      ],
    },
    records: {
      ...base.records,
      tasks: [
        ...base.records.tasks,
        {
          workboardTaskId: "3b755c28-eaf0-4417-b7f8-0934b98213df",
          packetTaskId: "7b939a51-85b5-4b42-bf3d-8f9f94c7785d",
          epoch,
          status: "pending",
          packet: { strategy_ref: { strategy_id: "STRATEGY-DEMO-PRODUCTION", strategy_version_id: v2Id }, request_summary: "적용 후 새 업무" },
          currentProposal: null,
          currentApprovalId: null,
          executionId: null,
          businessOutcome: { status: "unobserved" },
        },
      ],
      strategyAdoptions: [{
        id: "e16442fc-1dcf-43c4-925f-9440e5bad77a",
        epoch,
        reviewId: "69df5b83-514b-4afc-bf66-cd80cc24ce5c",
        fromRef: { strategy_id: "STRATEGY-DEMO-PRODUCTION", strategy_version_id: strategyVersionId },
        toRef: { strategy_id: "STRATEGY-DEMO-PRODUCTION", strategy_version_id: v2Id },
        actorId: "management-demo",
        adoptedAt: "2026-09-19T03:00:00.000Z",
      }],
    },
  };
}

describe("CompanyLineagePanel", () => {
  it("navigates exact task relations and returns to the origin without mutation controls", async () => {
    const onOpenTask = vi.fn();
    const runtimeClient = client(snapshot());
    const { rerender } = render(<CompanyLineagePanel client={runtimeClient} originTaskId={taskId} onOpenTask={onOpenTask} />);

    const panel = await screen.findByRole("region", { name: "전략-경험 계보" });
    expect(panel).toHaveTextContent("STRATEGY-DEMO-PRODUCTION · v1");
    expect(panel).toHaveTextContent("가상 데이터 · 읽기 전용");
    expect(panel).toHaveTextContent("사업 결과는 미관찰 상태일 수 있습니다.");
    fireEvent.click(screen.getByRole("button", { name: `업무 ${taskId} 열기` }));
    expect(onOpenTask).toHaveBeenCalledWith(taskId);
    fireEvent.click(screen.getByRole("button", { name: `packet_strategy ${strategyVersionId} v1 available 보기` }));
    expect(screen.getByRole("status")).toHaveTextContent(`packet_strategy/${strategyVersionId} v1`);
    const recordDetail = screen.getByRole("region", { name: "저장 레코드 상세" });
    expect(recordDetail).toHaveTextContent("objective");
    expect(recordDetail).toHaveTextContent("준비 상태 확인");
    expect(recordDetail).toHaveTextContent("content_hash");
    expect(recordDetail).toHaveTextContent("a".repeat(64));
    fireEvent.click(screen.getByRole("button", { name: "계보로 돌아가기" }));
    fireEvent.click(screen.getByRole("button", { name: "proposal da1b4929-a2ef-45a4-a1cd-acde937da2c5 v4 missing 보기" }));
    expect(screen.getByRole("status")).toHaveTextContent("referenced proposal is not stored");
    expect(screen.queryByRole("region", { name: "저장 레코드 상세" })).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: /승인|적용|게시/ })).not.toBeInTheDocument();
    rerender(<CompanyLineagePanel client={runtimeClient} originTaskId="newly-selected-task" onOpenTask={onOpenTask} />);
    fireEvent.click(screen.getByRole("button", { name: "원래 업무로 돌아가기" }));
    expect(onOpenTask).toHaveBeenLastCalledWith(taskId);
  });

  it("shows persisted adoption history while preserving v1 and v2 task pins", async () => {
    render(<CompanyLineagePanel client={client(adoptedSnapshot())} />);

    const panel = await screen.findByRole("region", { name: "전략-경험 계보" });
    const adoption = within(panel).getByRole("region", { name: "전략 적용 이력" });
    expect(adoption).toHaveTextContent("v1 → v2");
    expect(adoption).toHaveTextContent("management-demo");
    expect(within(panel).getByRole("button", { name: `업무 ${taskId} 열기` })).toBeInTheDocument();
    expect(within(panel).getByRole("button", { name: "업무 3b755c28-eaf0-4417-b7f8-0934b98213df 열기" })).toBeInTheDocument();

    fireEvent.click(within(panel).getByRole("button", { name: `업무 ${taskId} 열기` }));
    expect(within(panel).getByRole("button", { name: `packet_strategy ${strategyVersionId} v1 available 보기` })).toBeInTheDocument();
    fireEvent.click(within(panel).getByRole("button", { name: "업무 3b755c28-eaf0-4417-b7f8-0934b98213df 열기" }));
    expect(within(panel).getByRole("button", { name: "packet_strategy 4caac17f-90ab-43ae-93a4-c925e3f144af v2 available 보기" })).toBeInTheDocument();
  });
});
