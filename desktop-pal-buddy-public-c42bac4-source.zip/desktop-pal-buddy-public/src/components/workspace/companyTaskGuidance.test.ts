import { describe, expect, it } from "vitest";
import { selectCompanyTaskGuidance } from "./companyTaskGuidance";

const card = {
  pinnedStrategy: {
    status: "pinned" as const,
    ref: { strategy_id: "STRATEGY-DEMO-PRODUCTION", strategy_version_id: "f6846f3d-1aa0-487a-88a1-c383ba9076ea" },
    strategy_id: "STRATEGY-DEMO-PRODUCTION",
    strategy_version_id: "f6846f3d-1aa0-487a-88a1-c383ba9076ea",
    version: 1,
    objective: "생산 우선순위를 확인합니다.",
    reviewQuestion: "우선순위를 조정할까요?",
  },
  approval: { state: "pending" as const },
  execution: { state: "none" as const },
  readback: { state: "none" as const },
  businessOutcome: { state: "unknown" as const },
  reviewRequired: true,
};

describe("company task guidance", () => {
  it("derives one next action from persisted approval and keeps execution separate from the unknown outcome", () => {
    expect(selectCompanyTaskGuidance(card)).toEqual({
      pinnedStrategy: "고정 전략 v1",
      approval: "승인 대기",
      execution: "실행 전",
      readback: "재조회 전",
      businessOutcome: "사업 결과 미관찰",
      nextAction: "다음 행동: 생산 역할에서 승인을 기록하세요.",
    });
  });
});
