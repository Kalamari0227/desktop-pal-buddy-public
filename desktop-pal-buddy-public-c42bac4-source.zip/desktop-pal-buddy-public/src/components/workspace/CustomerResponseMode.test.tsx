import { fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { createCustomerResponseGatewayDraft } from "@/lib/agentic";
import { CustomerResponseMode } from "./CustomerResponseMode";

const streamChatMock = vi.hoisted(() => vi.fn());
const taskRows: Record<string, unknown>[] = [];
const insertedRows: Record<string, unknown>[] = [];

const createQuery = (table: string) => {
  let rows = table === "tasks" ? taskRows.map((row) => ({ ...row })) : [];
  const query = {
    select: vi.fn(() => query),
    insert: vi.fn((payload: Record<string, unknown>) => {
      insertedRows.push(payload);
      taskRows.push(payload);
      return Promise.resolve({ data: null, error: null });
    }),
    eq: vi.fn((column: string, value: unknown) => {
      rows = rows.filter((row) => row[column] === value);
      return query;
    }),
    limit: vi.fn((count: number) => {
      rows = rows.slice(0, count);
      return query;
    }),
    then: (resolve: (value: { data: unknown[]; error: null }) => void) => Promise.resolve({ data: rows, error: null }).then(resolve),
  };
  return query;
};

const fromMock = vi.fn((table: string) => createQuery(table));

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    from: (table: string) => fromMock(table),
  },
}));

vi.mock("@/lib/streamChat", () => ({
  streamChat: streamChatMock,
}));

describe("CustomerResponseMode Gateway routing", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    taskRows.length = 0;
    insertedRows.length = 0;
    streamChatMock.mockImplementation(async ({ onDelta, onDone }) => {
      onDelta("제목: 납기 일정 회신\n\n3월 셋째 주 출하 가능성을 확인 중입니다.");
      onDone();
    });
  });

  it("shows Gateway reply routing and registers the generated draft as a Workboard task", async () => {
    const onOpenTasks = vi.fn();
    render(<CustomerResponseMode onBack={vi.fn()} onOpenTasks={onOpenTasks} />);

    fireEvent.click(screen.getByText("납기 문의"));

    const route = await screen.findByLabelText("Gateway customer reply route");
    expect(within(route).getByText("customer_reply_draft")).toBeInTheDocument();
    expect(within(route).getByText("reply_draft")).toBeInTheDocument();
    expect(within(route).getByText("manual_review")).toBeInTheDocument();
    expect(within(route).getByText("do not send external message")).toBeInTheDocument();

    fireEvent.click(screen.getByRole("button", { name: /회신 초안 생성/ }));

    expect(await screen.findByText("초안 생성 완료")).toBeInTheDocument();
    expect(screen.getByText("제목: 납기 일정 회신")).toBeInTheDocument();

    fireEvent.click(screen.getByRole("button", { name: "작업 등록" }));

    await waitFor(() => {
      expect(insertedRows).toHaveLength(1);
    });
    expect(insertedRows[0]).toMatchObject({
      title: "현대자동차 납기 문의 회신 초안",
      source: "gateway",
      severity: "medium",
      customer: "현대자동차",
      category: "delivery",
      status: "pending",
    });
    expect(String(insertedRows[0].source_id)).toMatch(/^task-customer_reply_draft-/);
    expect(String(insertedRows[0].description)).toContain("Gateway task type: customer_reply_draft");
    expect(String(insertedRows[0].description)).toContain("do not send external message");

    fireEvent.click(await screen.findByRole("button", { name: "작업에서 계속" }));
    expect(onOpenTasks).toHaveBeenCalledWith(insertedRows[0].id);
  }, 10000);

  it("recognizes an already registered Gateway reply task", async () => {
    const draft = createCustomerResponseGatewayDraft({
      customer_id: "hyundai",
      customer_name: "현대자동차",
      customer_code: "현대자동차",
      inquiry_type: "delivery",
      inquiry_label: "납기 문의",
      inquiry_description: "납기 일정 확인/조정 요청",
      channel: "email",
      channel_label: "이메일",
      tone: "정중/공식",
      context_note: "",
    });
    taskRows.push({
      id: "existing-reply-task",
      source: "gateway",
      source_id: draft.packet?.task_id,
    });

    render(<CustomerResponseMode onBack={vi.fn()} />);

    fireEvent.click(screen.getByText("납기 문의"));
    fireEvent.click(screen.getByRole("button", { name: /회신 초안 생성/ }));
    expect(await screen.findByText("초안 생성 완료")).toBeInTheDocument();

    fireEvent.click(screen.getByRole("button", { name: "작업 등록" }));

    await waitFor(() => {
      expect(screen.getByText("작업 등록됨")).toBeInTheDocument();
    });
    expect(insertedRows).toHaveLength(0);
  }, 10000);
});
