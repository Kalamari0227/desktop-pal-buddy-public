import { fireEvent, render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { WorkspaceLayout } from "./WorkspaceLayout";

vi.mock("./WorkspaceNav", () => ({
  WorkspaceNav: () => <nav aria-label="workspace navigation" />,
}));

vi.mock("@/hooks/useInstalledItems", () => ({
  useInstalledItems: () => ({ activeAgents: [] }),
}));

vi.mock("./GatewayMode", () => ({
  GatewayMode: ({ companyDraft }: { companyDraft?: { id: string; text: string } }) => (
    <output aria-label="company draft">{companyDraft ? `${companyDraft.id}:${companyDraft.text}` : "none"}</output>
  ),
}));

vi.mock("./ContextPanel", () => ({ ContextPanel: () => null }));
vi.mock("./CompanyRuntimeControls", () => ({ CompanyRuntimeControls: () => null }));
vi.mock("./RuntimeConnectionStatus", () => ({ RuntimeConnectionStatus: () => null }));

describe("WorkspaceLayout company-work entry", () => {
  it("moves an ordinary-chat draft into Gateway mode context without an automatic prompt", async () => {
    render(<WorkspaceLayout agents={[]} alerts={[]} onClose={vi.fn()} />);

    fireEvent.change(screen.getByPlaceholderText("무엇이든 물어보세요..."), {
      target: { value: "SO-DEMO-1001 priority 1" },
    });
    fireEvent.click(screen.getByRole("button", { name: "회사 업무 시작" }));

    expect(await screen.findByRole("status", { name: "company draft" })).toHaveTextContent(/SO-DEMO-1001 priority 1$/);
  });
});
