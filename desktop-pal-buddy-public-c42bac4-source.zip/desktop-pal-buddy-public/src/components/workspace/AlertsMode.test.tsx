import { fireEvent, render, screen } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { AlertsMode } from "./AlertsMode";

const dismissAlert = vi.fn();
const restoreAlert = vi.fn();

vi.mock("@/hooks/useAlertsData", () => ({
  useAlertsData: () => ({
    alerts: [
      {
        id: "alert-1",
        title: "현대자동차 납기 리스크",
        description: "긴급 출하 일정 확인 필요",
        severity: "critical",
        customer: "현대자동차",
        category: "delivery",
        source: "risk",
        status: "pending",
        createdAt: new Date().toISOString(),
      },
      {
        id: "alert-2",
        title: "기아 가격 리스크",
        description: "원자재가 반영 기준 확인",
        severity: "high",
        customer: "기아",
        category: "price",
        source: "risk",
        status: "pending",
        createdAt: new Date().toISOString(),
      },
    ],
    dismissedIds: new Set(["alert-2"]),
    isLoading: false,
    dismissAlert,
    restoreAlert,
    isUpdatingDismissal: false,
  }),
}));

describe("AlertsMode", () => {
  beforeEach(() => {
    dismissAlert.mockClear();
    restoreAlert.mockClear();
  });

  it("renders alert counts and filters dismissed alerts", () => {
    render(<AlertsMode onBack={vi.fn()} />);

    expect(screen.getByRole("heading", { name: "알림 센터" })).toBeInTheDocument();
    expect(screen.getByText("활성 1")).toBeInTheDocument();
    expect(screen.getByText("처리됨 1")).toBeInTheDocument();
    expect(screen.getByText("현대자동차 납기 리스크")).toBeInTheDocument();

    fireEvent.click(screen.getByRole("button", { name: "처리됨 1" }));

    expect(screen.queryByText("현대자동차 납기 리스크")).not.toBeInTheDocument();
    expect(screen.getByText("기아 가격 리스크")).toBeInTheDocument();
  });
});
