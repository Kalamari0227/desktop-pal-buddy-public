import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { createGatewayCodexDraft, taskPacketSchema } from "@/lib/agentic";
import { GatewayMode } from "./GatewayMode";

const writeText = vi.fn();
const taskRows: Record<string, unknown>[] = [];
const eventRows: Record<string, unknown>[] = [];

const createQuery = (table: string) => {
  let rows = table === "tasks" ? taskRows.map((row) => ({ ...row })) : [];
  const query = {
    select: vi.fn(() => query),
    insert: vi.fn((payload: Record<string, unknown>) => {
      if (table === "tasks") {
        taskRows.push(payload);
      }
      if (table === "agent_events") {
        eventRows.push(payload);
      }
      return Promise.resolve({ data: null, error: null });
    }),
    eq: vi.fn((column: string, value: unknown) => {
      rows = rows.filter((row) => row[column] === value);
      return query;
    }),
    limit: vi.fn((count: number) => {
      rows = rows.slice(0, count);
      return query;
    }),
    then: (resolve: (value: { data: unknown[]; error: null }) => void) => Promise.resolve({ data: rows, error: null }).then(resolve),
  };
  return query;
};

const fromMock = vi.fn((table: string) => createQuery(table));

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    from: (table: string) => fromMock(table),
  },
}));

vi.mock("./StrategyReviewPanel", () => ({
  StrategyReviewPanel: () => <section aria-label="경영 전략 검토 진입점" />,
}));

vi.mock("./CompanyLineagePanel", () => ({
  CompanyLineagePanel: ({ onOpenTask }: { onOpenTask?: (taskId: string) => void }) => (
    <button type="button" onClick={() => onOpenTask?.("runtime-lineage-task")}>계보 업무 열기</button>
  ),
}));

describe("GatewayMode", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    taskRows.length = 0;
    eventRows.length = 0;
    writeText.mockReset();
    Object.defineProperty(navigator, "clipboard", {
      configurable: true,
      value: { writeText },
    });
  });

  afterEach(() => {
    vi.restoreAllMocks();
    vi.unstubAllEnvs();
  });

  it("includes the management strategy review entry point beside the company request path", () => {
    render(<GatewayMode onBack={vi.fn()} />);

    expect(screen.getByLabelText("경영 전략 검토 진입점")).toBeInTheDocument();
  });

  it("opens a persisted lineage task through the existing Workboard callback", () => {
    const onOpenTasks = vi.fn();
    render(<GatewayMode onBack={vi.fn()} onOpenTasks={onOpenTasks} />);

    fireEvent.click(screen.getByRole("button", { name: "계보 업무 열기" }));

    expect(onOpenTasks).toHaveBeenCalledWith("runtime-lineage-task");
  });

  it("passes a workspace company draft to the explicit company-request field without submitting it", () => {
    render(<GatewayMode onBack={vi.fn()} companyDraft={{ id: "workspace-draft-1", text: "SO-DEMO-1001 priority 1" }} />);

    expect(screen.getByRole("textbox", { name: "회사 요청" })).toHaveValue("SO-DEMO-1001 priority 1");
  });

  it("turns an urgent material request into a visible task packet and handoff", () => {
    render(<GatewayMode onBack={vi.fn()} />);

    expect(screen.getByRole("heading", { name: "요청" })).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "회사 요청" })).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "수동 Gateway" })).toBeInTheDocument();
    expect(screen.getByRole("heading", { name: "요청 정리" })).toBeInTheDocument();
    expect(screen.getByText("말로 남긴 요청을 작업 계획, 위험도, 필요한 증거로 정리합니다")).toBeInTheDocument();
    expect(screen.getByText("작업 준비됨")).toBeInTheDocument();
    expect(screen.getByText("긴급재 리스크 평가")).toBeInTheDocument();
    expect(screen.getByText("위험도 보통")).toBeInTheDocument();
    expect(screen.getByText("승인 불필요")).toBeInTheDocument();
    expect(screen.getByText("재고 예약 금지")).toBeInTheDocument();
    expect(screen.getByText("리스크 평가")).toBeInTheDocument();
    expect(screen.getByLabelText("작업 계획 원본 미리보기")).toHaveTextContent('"task_type": "urgent_material_risk_assessment"');
    expect(screen.getByLabelText("Codex 전달문 미리보기")).toHaveTextContent("# Codex Task Packet");
  });

  it("updates classification for business, Supabase, and document examples", () => {
    render(<GatewayMode onBack={vi.fn()} />);

    fireEvent.click(screen.getByRole("button", { name: "재고 확인" }));
    expect(screen.getAllByText("재고 확인").length).toBeGreaterThan(0);
    expect(screen.getByText("재고 상태")).toBeInTheDocument();
    expect(screen.getByText("ERP 재고 기록 변경 금지")).toBeInTheDocument();
    expect(screen.getByLabelText("작업 계획 원본 미리보기")).toHaveTextContent('"task_type": "inventory_check"');

    fireEvent.click(screen.getByRole("button", { name: "고객 답장" }));
    expect(screen.getByText("고객 답장 초안")).toBeInTheDocument();
    expect(screen.getByText("답장 초안")).toBeInTheDocument();
    expect(screen.getByText("외부 메시지 발송 금지")).toBeInTheDocument();
    expect(screen.getByLabelText("작업 계획 원본 미리보기")).toHaveTextContent('"task_type": "customer_reply_draft"');

    fireEvent.click(screen.getByRole("button", { name: "PR 검증" }));
    expect(screen.getAllByText("PR 검증").length).toBeGreaterThan(0);
    expect(screen.getByText("CI 상태")).toBeInTheDocument();
    expect(screen.getByLabelText("작업 계획 원본 미리보기")).toHaveTextContent('"task_type": "pr_verification"');

    fireEvent.click(screen.getByRole("button", { name: "스테이징 확인" }));
    expect(screen.getByText("스테이징 상태 확인")).toBeInTheDocument();
    expect(screen.getByText("위험도 보통")).toBeInTheDocument();
    expect(screen.getByText("마이그레이션 실행 금지")).toBeInTheDocument();
    expect(screen.getByLabelText("작업 계획 원본 미리보기")).toHaveTextContent('"task_type": "supabase_staging_check"');

    fireEvent.click(screen.getByRole("button", { name: "PRD 초안" }));
    expect(screen.getByText("PRD 초안 작성")).toBeInTheDocument();
    expect(screen.getByText("문서 생성 확인")).toBeInTheDocument();
    expect(screen.getByText("업로드 파일의 민감 정보 노출 금지")).toBeInTheDocument();
    expect(screen.getByLabelText("작업 계획 원본 미리보기")).toHaveTextContent('"task_type": "document_to_prd"');
  });

  it("marks migration execution as approval-required high risk", () => {
    render(<GatewayMode onBack={vi.fn()} />);

    fireEvent.click(screen.getByRole("button", { name: "마이그레이션 승인" }));

    expect(screen.getByText("위험도 높음")).toBeInTheDocument();
    expect(screen.getAllByText("승인 필요").length).toBeGreaterThan(0);
    expect(screen.getAllByText("승인 대기").length).toBeGreaterThan(0);
    expect(screen.getByText("DB 변경 실행")).toBeInTheDocument();
    expect(screen.getByText("승인 필요: DB 변경 실행")).toBeInTheDocument();
    expect(screen.getByText("승인 없는 DB 변경 실행 금지")).toBeInTheDocument();
    expect(screen.getByLabelText("작업 계획 원본 미리보기")).toHaveTextContent('"status": "waiting_for_approval"');
  });

  it("lets the user edit context refs and copy the manual handoff", () => {
    render(<GatewayMode onBack={vi.fn()} />);

    fireEvent.click(screen.getByRole("button", { name: "PR 검증" }));
    fireEvent.change(screen.getByLabelText("참고 값 2"), { target: { value: "42" } });
    expect(screen.getByLabelText("Codex 전달문 미리보기")).toHaveTextContent("[github_pr] PR 번호: 42");

    fireEvent.click(screen.getByRole("button", { name: "전달문 복사" }));
    expect(writeText).toHaveBeenCalledWith(expect.stringContaining("# Codex Task Packet"));
    expect(writeText).toHaveBeenCalledWith(expect.stringContaining("[github_pr] PR 번호: 42"));
  });

  it("copies the task packet JSON preview", () => {
    render(<GatewayMode onBack={vi.fn()} />);

    fireEvent.click(screen.getByRole("button", { name: "작업 계획 복사" }));

    expect(writeText).toHaveBeenCalledWith(expect.stringContaining('"task_type": "urgent_material_risk_assessment"'));
    expect(writeText).toHaveBeenCalledWith(expect.stringContaining('"forbidden_actions"'));
  });

  it("creates a workboard task and accepted event from the Gateway conversation", async () => {
    const onOpenTasks = vi.fn();
    render(<GatewayMode onBack={vi.fn()} onOpenTasks={onOpenTasks} />);

    fireEvent.click(screen.getByRole("button", { name: "작업으로 만들기" }));

    await waitFor(() => {
      expect(taskRows).toHaveLength(1);
      expect(taskRows[0]).toMatchObject({
        title: "현대자동차 GA 강판 긴급재 위험도 따져줘",
        source: "gateway",
        severity: "medium",
        customer: "현대자동차",
        category: "delivery",
        status: "pending",
      });
    });
    await waitFor(() => {
      expect(eventRows).toHaveLength(1);
      expect(eventRows[0]).toMatchObject({
        task_id: taskRows[0].id,
        packet_task_id: taskRows[0].source_id,
        event_type: "accepted",
        message: "Gateway 대화에서 작업이 생성되었습니다.",
      });
    });
    expect(screen.getByText("작업 생성됨")).toBeInTheDocument();
    expect(screen.getByText("작업 화면에서 전달문, Codex 결과, 증거를 이어서 기록하세요.")).toBeInTheDocument();

    fireEvent.click(screen.getByRole("button", { name: "작업에서 계속" }));

    expect(onOpenTasks).toHaveBeenCalledWith(taskRows[0].id);
  });

  it("does not query or insert a task when the packet fails runtime validation", async () => {
    const invalidPacketResult = taskPacketSchema.safeParse({});
    vi.spyOn(taskPacketSchema, "safeParse").mockReturnValue(invalidPacketResult);

    render(<GatewayMode onBack={vi.fn()} />);

    fireEvent.click(screen.getByRole("button", { name: "작업으로 만들기" }));

    await waitFor(() => expect(taskRows).toHaveLength(0));
    expect(fromMock).not.toHaveBeenCalled();
    expect(eventRows).toHaveLength(0);
  });

  it("reuses an existing workboard task for the same Gateway packet", async () => {
    const onOpenTasks = vi.fn();
    const draft = createGatewayCodexDraft({
      raw_user_request: "현대자동차 GA 강판 긴급재 위험도 따져줘",
    });
    taskRows.push({
      id: "existing-gateway-task",
      source: "gateway",
      source_id: draft.packet?.task_id,
    });

    render(<GatewayMode onBack={vi.fn()} onOpenTasks={onOpenTasks} />);

    fireEvent.click(screen.getByRole("button", { name: "작업으로 만들기" }));

    await waitFor(() => {
      expect(screen.getByText("작업 생성됨")).toBeInTheDocument();
    });
    expect(taskRows).toHaveLength(1);
    expect(eventRows).toHaveLength(0);

    fireEvent.click(screen.getByRole("button", { name: "작업에서 계속" }));

    expect(onOpenTasks).toHaveBeenCalledWith("existing-gateway-task");
  });

  it("pins the selected demo strategy version in the created Workboard task", async () => {
    render(<GatewayMode onBack={vi.fn()} />);

    fireEvent.change(screen.getByLabelText("전략 선택"), {
      target: { value: "delivery-risk-early-warning" },
    });
    fireEvent.change(screen.getByLabelText("전략 버전 선택"), {
      target: { value: "delivery-risk-early-warning-v1" },
    });
    fireEvent.click(screen.getByRole("button", { name: "작업으로 만들기" }));

    await waitFor(() => expect(taskRows).toHaveLength(1));
    expect(taskRows[0]).toMatchObject({
      demo_intake_required: true,
      demo_intake_packet: {
        raw_user_request: "현대자동차 GA 강판 긴급재 위험도 따져줘",
        strategy_ref: {
          strategy_id: "delivery-risk-early-warning",
          strategy_version_id: "delivery-risk-early-warning-v1",
        },
      },
    });

    fireEvent.change(screen.getByLabelText("전략 버전 선택"), {
      target: { value: "delivery-risk-early-warning-v2" },
    });
    expect(screen.getByRole("button", { name: "작업으로 만들기" })).toBeEnabled();
  });

  it("blocks creation and handoff while a selected strategy has no version", () => {
    render(<GatewayMode onBack={vi.fn()} />);

    fireEvent.change(screen.getByLabelText("전략 선택"), {
      target: { value: "delivery-risk-early-warning" },
    });

    expect(screen.getByText("전략 버전을 선택해야 작업을 만들 수 있습니다.")).toBeInTheDocument();
    expect(screen.getByText("전략 버전을 선택한 뒤 다시 확인해 주세요.")).toBeInTheDocument();
    expect(screen.queryByText(/invalid strategy reference/i)).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "작업으로 만들기" })).not.toBeInTheDocument();
    expect(screen.queryByLabelText("Codex 전달문 미리보기")).not.toBeInTheDocument();
    expect(taskRows).toHaveLength(0);
  });

  it.each(["staging", "production"])("keeps strategy controls and demo metadata out of %s", async (mode) => {
    vi.stubEnv("VITE_APP_MODE", mode);
    render(<GatewayMode onBack={vi.fn()} />);

    expect(screen.queryByLabelText("전략 선택")).not.toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: "작업으로 만들기" }));

    await waitFor(() => expect(taskRows).toHaveLength(1));
    expect(taskRows[0]).not.toHaveProperty("demo_intake_required");
    expect(taskRows[0]).not.toHaveProperty("demo_intake_packet");
    expect(taskRows[0]).not.toHaveProperty("strategy_ref");
  });

  it("blocks unknown requests for manual review instead of building a packet", () => {
    render(<GatewayMode onBack={vi.fn()} />);

    fireEvent.change(screen.getByLabelText("업무 요청"), { target: { value: "오늘 할 일 알려줘" } });

    expect(screen.getAllByText("검토 필요").length).toBeGreaterThan(0);
    expect(screen.getByText("검토가 필요합니다")).toBeInTheDocument();
    expect(screen.queryByLabelText("작업 계획 원본 미리보기")).not.toBeInTheDocument();
    expect(screen.queryByLabelText("Codex 전달문 미리보기")).not.toBeInTheDocument();
  });
});
