import { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search, Plus, Star, Download, TrendingUp, X, Loader2,
  MessageSquare, Send, Server, Shield, Globe, Wrench,
  CheckCircle2,
} from "lucide-react";
import { toast } from "sonner";
import { useInstalledItems } from "@/hooks/useInstalledItems";
import { createMarketplaceProvider, type MarketplaceReview } from "@/lib/marketplaceProvider";

const marketplaceProvider = createMarketplaceProvider();

type McpTool = {
  name?: string;
  description?: string;
};

interface MarketplaceMcp {
  id: string;
  name: string;
  description: string | null;
  category: string;
  icon: string;
  server_url: string | null;
  auth_type: string;
  tools_count: number;
  tools_schema: unknown[];
  creator_name: string;
  installs: number;
  rating: number;
  tags: string[];
  is_featured: boolean;
  is_verified: boolean;
  created_at: string;
}

const MCP_CATEGORIES = [
  { id: "all", label: "전체" },
  { id: "data", label: "데이터" },
  { id: "communication", label: "커뮤니케이션" },
  { id: "productivity", label: "생산성" },
  { id: "development", label: "개발" },
  { id: "design", label: "디자인" },
  { id: "monitoring", label: "모니터링" },
  { id: "analytics", label: "분석" },
  { id: "integration", label: "통합" },
];

const AUTH_LABELS: Record<string, string> = {
  none: "인증 없음",
  api_key: "API 키",
  oauth: "OAuth 2.0",
  bearer: "Bearer 토큰",
  connection_string: "연결 문자열",
};

export function McpMarketplace() {
  const [mcps, setMcps] = useState<MarketplaceMcp[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");
  const [selectedMcp, setSelectedMcp] = useState<MarketplaceMcp | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const { install: installItem } = useInstalledItems();

  useEffect(() => { fetchMcps(); }, []);

  const fetchMcps = async () => {
    setLoading(true);
    try {
      setMcps(await marketplaceProvider.list<MarketplaceMcp>("mcp"));
    } catch {
      toast.error("MCP 서버 목록을 불러오는데 실패했습니다");
    }
    setLoading(false);
  };

  const handleInstall = async (mcp: MarketplaceMcp) => {
    try {
      await marketplaceProvider.incrementInstalls("mcp", mcp.id, mcp.installs);
      setMcps(prev => prev.map(m => m.id === mcp.id ? { ...m, installs: m.installs + 1 } : m));
      await installItem({
        item_id: mcp.id,
        item_type: "mcp",
        item_name: mcp.name,
        item_icon: mcp.icon || "Server",
        item_description: mcp.description || undefined,
      });
    } catch {
      toast.error("MCP 서버 연결에 실패했습니다");
    }
  };

  const filtered = mcps.filter(m => {
    const matchCat = activeCategory === "all" || m.category === activeCategory;
    const matchSearch = !searchQuery ||
      m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.tags.some(t => t.includes(searchQuery.toLowerCase()));
    return matchCat && matchSearch;
  });

  const featured = mcps.filter(m => m.is_featured);

  return (
    <div className="space-y-6">
      {/* Search + Create */}
      <div className="flex gap-2">
        <div className="flex-1 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="MCP 서버 검색..."
            className="w-full pl-9 pr-4 py-2.5 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none transition-colors"
          />
        </div>
        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-[12px] font-semibold transition-colors"
          style={{ background: "hsl(var(--primary))", color: "hsl(var(--primary-foreground))" }}
        >
          <Plus className="w-3.5 h-3.5" />
          MCP 등록
        </button>
      </div>

      {/* Categories */}
      <div className="flex gap-1.5 overflow-x-auto scrollbar-none">
        {MCP_CATEGORIES.map(cat => (
          <button key={cat.id} onClick={() => setActiveCategory(cat.id)}
            className={`px-3 py-1.5 rounded-lg text-[11px] font-medium whitespace-nowrap transition-colors ${
              activeCategory === cat.id ? "bg-primary/15 text-primary" : "text-muted-foreground hover:bg-secondary"
            }`}>
            {cat.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
        </div>
      ) : (
        <>
          {activeCategory === "all" && featured.length > 0 && !searchQuery && (
            <section>
              <div className="flex items-center gap-2 mb-3">
                <TrendingUp className="w-3.5 h-3.5 text-primary" />
                <h2 className="text-[12px] font-semibold text-foreground">추천 MCP 서버</h2>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {featured.slice(0, 4).map(mcp => (
                  <McpCard key={mcp.id} mcp={mcp} onInstall={handleInstall} onSelect={setSelectedMcp} featured />
                ))}
              </div>
            </section>
          )}

          <section>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-[12px] font-semibold text-foreground">
                {activeCategory === "all" ? "모든 MCP 서버" : MCP_CATEGORIES.find(c => c.id === activeCategory)?.label}
                <span className="text-muted-foreground font-normal ml-1.5">({filtered.length})</span>
              </h2>
            </div>
            {filtered.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-[12px] text-muted-foreground">검색 결과가 없습니다</p>
                <button onClick={() => setShowCreateModal(true)} className="mt-2 text-[11px] text-primary hover:underline">
                  직접 MCP 서버를 등록해보세요
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-3">
                {filtered.map(mcp => (
                  <McpCard key={mcp.id} mcp={mcp} onInstall={handleInstall} onSelect={setSelectedMcp} />
                ))}
              </div>
            )}
          </section>
        </>
      )}

      <AnimatePresence>
        {selectedMcp && (
          <McpDetailModal mcp={selectedMcp} onClose={() => setSelectedMcp(null)} onInstall={handleInstall} />
        )}
      </AnimatePresence>
      <AnimatePresence>
        {showCreateModal && (
          <CreateMcpModal onClose={() => setShowCreateModal(false)} onCreated={() => { setShowCreateModal(false); fetchMcps(); }} />
        )}
      </AnimatePresence>
    </div>
  );
}

/* ─── MCP Card ─── */
function McpCard({ mcp, onInstall, onSelect, featured }: {
  mcp: MarketplaceMcp; onInstall: (m: MarketplaceMcp) => void; onSelect: (m: MarketplaceMcp) => void; featured?: boolean;
}) {
  return (
    <motion.div
      whileHover={{ y: -2 }}
      onClick={() => onSelect(mcp)}
      className={`rounded-2xl p-4 border cursor-pointer transition-colors group ${
        featured ? "border-primary/20 bg-primary/[0.03]" : "border-border/50 bg-card/50 hover:border-border"
      }`}
    >
      <div className="flex items-start justify-between mb-3">
        <div className="w-10 h-10 rounded-xl flex items-center justify-center bg-secondary">
          <Server className="w-5 h-5 text-muted-foreground" />
        </div>
        <div className="flex items-center gap-1.5">
          {mcp.is_verified && (
            <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 flex items-center gap-0.5">
              <CheckCircle2 className="w-2.5 h-2.5" />인증됨
            </span>
          )}
          {featured && (
            <span className="text-[9px] px-2 py-0.5 rounded-full bg-primary/10 text-primary font-semibold">추천</span>
          )}
        </div>
      </div>
      <h3 className="text-[13px] font-semibold text-foreground mb-1 line-clamp-1">{mcp.name}</h3>
      <p className="text-[11px] text-muted-foreground line-clamp-2 mb-3">{mcp.description}</p>

      <div className="flex items-center gap-2 mb-3 text-[9px] text-muted-foreground">
        <span className="flex items-center gap-0.5 px-1.5 py-0.5 rounded-md bg-secondary/60">
          <Wrench className="w-2.5 h-2.5" />{mcp.tools_count} 도구
        </span>
        <span className="flex items-center gap-0.5 px-1.5 py-0.5 rounded-md bg-secondary/60">
          <Shield className="w-2.5 h-2.5" />{AUTH_LABELS[mcp.auth_type] || mcp.auth_type}
        </span>
      </div>

      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3 text-[10px] text-muted-foreground">
          <span className="flex items-center gap-1"><Star className="w-3 h-3 text-amber-500" fill="currentColor" />{mcp.rating}</span>
          <span className="flex items-center gap-1"><Download className="w-3 h-3" />{mcp.installs}</span>
        </div>
        <button onClick={e => { e.stopPropagation(); onInstall(mcp); }}
          className="px-2.5 py-1 rounded-lg text-[10px] font-semibold bg-primary/10 text-primary hover:bg-primary/20 transition-colors">
          연결
        </button>
      </div>
      <div className="flex gap-1 mt-2 flex-wrap">
        {mcp.tags.slice(0, 3).map(tag => (
          <span key={tag} className="text-[9px] px-1.5 py-0.5 rounded-md bg-secondary/60 text-muted-foreground">#{tag}</span>
        ))}
      </div>
    </motion.div>
  );
}

/* ─── MCP Detail Modal ─── */
function McpDetailModal({ mcp, onClose, onInstall }: {
  mcp: MarketplaceMcp; onClose: () => void; onInstall: (m: MarketplaceMcp) => void;
}) {
  const [reviews, setReviews] = useState<MarketplaceReview[]>([]);
  const [loadingReviews, setLoadingReviews] = useState(true);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState("");
  const [reviewerName, setReviewerName] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [hoverRating, setHoverRating] = useState(0);
  const [currentRating, setCurrentRating] = useState(mcp.rating);

  const tools = Array.isArray(mcp.tools_schema) ? (mcp.tools_schema as McpTool[]) : [];

  const fetchReviews = useCallback(async () => {
    setLoadingReviews(true);
    try {
      setReviews(await marketplaceProvider.listReviews("mcp", mcp.id));
    } catch {
      toast.error("리뷰를 불러오지 못했습니다");
    }
    setLoadingReviews(false);
  }, [mcp.id]);

  useEffect(() => { fetchReviews(); }, [fetchReviews]);

  const submitReview = async () => {
    if (!reviewComment.trim()) { toast.error("리뷰 내용을 입력해주세요"); return; }
    setSubmitting(true);
    try {
      await marketplaceProvider.submitReview("mcp", mcp.id, {
        reviewer_name: reviewerName.trim() || "익명",
        rating: reviewRating,
        comment: reviewComment.trim(),
      });
      toast.success("리뷰가 등록되었습니다!");
      setShowReviewForm(false); setReviewComment(""); setReviewRating(5);
      await fetchReviews();
      const rating = await marketplaceProvider.getRating("mcp", mcp.id);
      if (rating !== null) setCurrentRating(rating);
    } catch {
      toast.error("리뷰 등록에 실패했습니다");
    }
    setSubmitting(false);
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-[60] bg-black/40 flex items-center justify-center p-8" onClick={onClose}>
      <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }}
        onClick={e => e.stopPropagation()}
        className="w-full max-w-lg rounded-2xl bg-card border border-border p-6 space-y-4 max-h-[85vh] overflow-y-auto scrollbar-thin"
        style={{ boxShadow: "var(--shadow-3)" }}>

        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl flex items-center justify-center bg-secondary">
              <Server className="w-6 h-6 text-muted-foreground" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-[14px] font-bold text-foreground">{mcp.name}</h2>
                {mcp.is_verified && <CheckCircle2 className="w-4 h-4 text-emerald-500" />}
              </div>
              <p className="text-[11px] text-muted-foreground">by {mcp.creator_name}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-1 rounded-lg hover:bg-secondary transition-colors"><X className="w-4 h-4 text-muted-foreground" /></button>
        </div>

        <p className="text-[12px] text-foreground/80 leading-relaxed">{mcp.description}</p>

        <div className="flex items-center gap-3 text-[11px] text-muted-foreground flex-wrap">
          <span className="flex items-center gap-1"><Star className="w-3.5 h-3.5 text-amber-500" fill="currentColor" />{currentRating}</span>
          <span className="flex items-center gap-1"><Download className="w-3.5 h-3.5" />{mcp.installs}회 연결</span>
          <span className="flex items-center gap-1"><Wrench className="w-3.5 h-3.5" />{mcp.tools_count}개 도구</span>
          <span className="flex items-center gap-1"><Shield className="w-3.5 h-3.5" />{AUTH_LABELS[mcp.auth_type] || mcp.auth_type}</span>
          <span className="flex items-center gap-1"><MessageSquare className="w-3.5 h-3.5" />{reviews.length}개 리뷰</span>
        </div>

        {/* Server URL */}
        {mcp.server_url && (
          <div className="rounded-xl bg-secondary/20 p-3">
            <p className="text-[10px] font-semibold text-muted-foreground mb-1">서버 엔드포인트</p>
            <div className="flex items-center gap-2">
              <Globe className="w-3.5 h-3.5 text-muted-foreground flex-shrink-0" />
              <code className="text-[11px] text-foreground/70 font-mono break-all">{mcp.server_url}</code>
            </div>
          </div>
        )}

        {/* Tools list */}
        {tools.length > 0 && (
          <div className="rounded-xl bg-secondary/20 p-3">
            <p className="text-[10px] font-semibold text-muted-foreground mb-2">제공 도구</p>
            <div className="space-y-1.5">
              {tools.map((tool, i) => (
                <div key={i} className="flex items-center gap-2 p-2 rounded-lg bg-background/50">
                  <Wrench className="w-3 h-3 text-primary flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-[11px] font-medium text-foreground truncate">{tool.name || `도구 ${i + 1}`}</p>
                    {tool.description && <p className="text-[9px] text-muted-foreground truncate">{tool.description}</p>}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="flex gap-1.5 flex-wrap">
          {mcp.tags.map(tag => (
            <span key={tag} className="text-[10px] px-2 py-0.5 rounded-md bg-secondary/60 text-muted-foreground">#{tag}</span>
          ))}
        </div>

        <button onClick={() => { onInstall(mcp); onClose(); }}
          className="w-full py-2.5 rounded-xl text-[12px] font-semibold transition-colors"
          style={{ background: "hsl(var(--primary))", color: "hsl(var(--primary-foreground))" }}>
          MCP 서버 연결하기
        </button>

        {/* Reviews */}
        <div className="border-t border-border/50 pt-4">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-[13px] font-semibold text-foreground">평점 및 리뷰</h3>
            <button onClick={() => setShowReviewForm(!showReviewForm)} className="text-[11px] font-medium text-primary hover:underline flex items-center gap-1">
              <Send className="w-3 h-3" />리뷰 작성
            </button>
          </div>

          <AnimatePresence>
            {showReviewForm && (
              <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden mb-4">
                <div className="rounded-xl border border-border/50 p-3 space-y-3 bg-secondary/20">
                  <div>
                    <label className="text-[10px] font-medium text-muted-foreground block mb-1.5">평점</label>
                    <div className="flex items-center gap-1">
                      {[1,2,3,4,5].map(s => (
                        <button key={s} onMouseEnter={() => setHoverRating(s)} onMouseLeave={() => setHoverRating(0)} onClick={() => setReviewRating(s)} className="p-0.5 transition-transform hover:scale-110">
                          <Star className={`w-5 h-5 ${s <= (hoverRating || reviewRating) ? "text-amber-500" : "text-muted-foreground/30"}`} fill="currentColor" />
                        </button>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="text-[10px] font-medium text-muted-foreground block mb-1">이름</label>
                    <input value={reviewerName} onChange={e => setReviewerName(e.target.value)} placeholder="익명"
                      className="w-full px-3 py-1.5 rounded-lg text-[11px] bg-background border border-border/50 focus:border-primary/30 focus:outline-none" />
                  </div>
                  <div>
                    <label className="text-[10px] font-medium text-muted-foreground block mb-1">리뷰 *</label>
                    <textarea value={reviewComment} onChange={e => setReviewComment(e.target.value)} rows={2} placeholder="이 MCP 서버에 대한 의견을 남겨주세요"
                      className="w-full px-3 py-1.5 rounded-lg text-[11px] bg-background border border-border/50 focus:border-primary/30 focus:outline-none resize-none" />
                  </div>
                  <div className="flex gap-2 justify-end">
                    <button onClick={() => setShowReviewForm(false)} className="px-3 py-1.5 rounded-lg text-[11px] text-muted-foreground hover:bg-secondary transition-colors">취소</button>
                    <button onClick={submitReview} disabled={submitting || !reviewComment.trim()}
                      className="px-3 py-1.5 rounded-lg text-[11px] font-semibold transition-colors disabled:opacity-50"
                      style={{ background: "hsl(var(--primary))", color: "hsl(var(--primary-foreground))" }}>
                      {submitting ? "등록 중..." : "리뷰 등록"}
                    </button>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {loadingReviews ? (
            <div className="flex justify-center py-4"><Loader2 className="w-4 h-4 animate-spin text-muted-foreground" /></div>
          ) : reviews.length === 0 ? (
            <p className="text-[11px] text-muted-foreground text-center py-4">아직 리뷰가 없습니다</p>
          ) : (
            <div className="space-y-3">
              {reviews.map(review => (
                <div key={review.id} className="rounded-xl bg-secondary/20 p-3">
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-2">
                      <span className="text-[11px] font-semibold text-foreground">{review.reviewer_name}</span>
                      <div className="flex items-center gap-0.5">
                        {[1,2,3,4,5].map(s => (
                          <Star key={s} className={`w-2.5 h-2.5 ${s <= review.rating ? "text-amber-500" : "text-muted-foreground/30"}`} fill="currentColor" />
                        ))}
                      </div>
                    </div>
                    <span className="text-[9px] text-muted-foreground">{new Date(review.created_at).toLocaleDateString("ko-KR")}</span>
                  </div>
                  <p className="text-[11px] text-foreground/70 leading-relaxed">{review.comment}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}

/* ─── Create MCP Modal ─── */
function CreateMcpModal({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("general");
  const [serverUrl, setServerUrl] = useState("");
  const [authType, setAuthType] = useState("none");
  const [toolsCount, setToolsCount] = useState(0);
  const [creatorName, setCreatorName] = useState("");
  const [tags, setTags] = useState("");
  const [saving, setSaving] = useState(false);

  const handleSubmit = async () => {
    if (!name.trim()) { toast.error("이름을 입력해주세요"); return; }
    setSaving(true);
    try {
      await marketplaceProvider.create("mcp", {
        name, description: description || null, category,
        server_url: serverUrl || null, auth_type: authType,
        tools_count: toolsCount, creator_name: creatorName || "익명",
        tags: tags.split(",").map(t => t.trim()).filter(Boolean),
      });
      toast.success("MCP 서버가 연결 센터에 등록되었습니다!");
      onCreated();
    } catch {
      toast.error("MCP 서버 등록에 실패했습니다");
    }
    setSaving(false);
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-[60] bg-black/40 flex items-center justify-center p-8" onClick={onClose}>
      <motion.div initial={{ scale: 0.95, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.95, opacity: 0 }}
        onClick={e => e.stopPropagation()}
        className="w-full max-w-md rounded-2xl bg-card border border-border p-6 space-y-4 max-h-[80vh] overflow-y-auto scrollbar-thin"
        style={{ boxShadow: "var(--shadow-3)" }}>

        <div className="flex items-center justify-between">
          <h2 className="text-[14px] font-bold text-foreground">MCP 서버 등록</h2>
          <button onClick={onClose} className="p-1 rounded-lg hover:bg-secondary transition-colors"><X className="w-4 h-4 text-muted-foreground" /></button>
        </div>

        <div className="space-y-3">
          <div>
            <label className="text-[11px] font-medium text-muted-foreground block mb-1">서버 이름 *</label>
            <input value={name} onChange={e => setName(e.target.value)} placeholder="예: Notion MCP Server"
              className="w-full px-3 py-2 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none" />
          </div>
          <div>
            <label className="text-[11px] font-medium text-muted-foreground block mb-1">설명</label>
            <textarea value={description} onChange={e => setDescription(e.target.value)} rows={2} placeholder="MCP 서버가 제공하는 기능을 설명해주세요"
              className="w-full px-3 py-2 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none resize-none" />
          </div>
          <div>
            <label className="text-[11px] font-medium text-muted-foreground block mb-1">서버 URL</label>
            <input value={serverUrl} onChange={e => setServerUrl(e.target.value)} placeholder="https://your-mcp-server.com/mcp"
              className="w-full px-3 py-2 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none font-mono" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-medium text-muted-foreground block mb-1">카테고리</label>
              <select value={category} onChange={e => setCategory(e.target.value)}
                className="w-full px-3 py-2 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none">
                <option value="general">일반</option>
                <option value="data">데이터</option>
                <option value="communication">커뮤니케이션</option>
                <option value="productivity">생산성</option>
                <option value="development">개발</option>
                <option value="analytics">분석</option>
                <option value="integration">통합</option>
              </select>
            </div>
            <div>
              <label className="text-[11px] font-medium text-muted-foreground block mb-1">인증 방식</label>
              <select value={authType} onChange={e => setAuthType(e.target.value)}
                className="w-full px-3 py-2 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none">
                <option value="none">인증 없음</option>
                <option value="api_key">API 키</option>
                <option value="oauth">OAuth 2.0</option>
                <option value="bearer">Bearer 토큰</option>
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-[11px] font-medium text-muted-foreground block mb-1">도구 수</label>
              <input type="number" value={toolsCount} onChange={e => setToolsCount(Number(e.target.value))} min={0}
                className="w-full px-3 py-2 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none" />
            </div>
            <div>
              <label className="text-[11px] font-medium text-muted-foreground block mb-1">만든 사람</label>
              <input value={creatorName} onChange={e => setCreatorName(e.target.value)} placeholder="익명"
                className="w-full px-3 py-2 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none" />
            </div>
          </div>
          <div>
            <label className="text-[11px] font-medium text-muted-foreground block mb-1">태그 (쉼표 구분)</label>
            <input value={tags} onChange={e => setTags(e.target.value)} placeholder="예: notion, 문서, API"
              className="w-full px-3 py-2 rounded-xl text-[12px] bg-secondary/50 border border-border/50 focus:border-primary/30 focus:outline-none" />
          </div>
        </div>

        <button onClick={handleSubmit} disabled={saving || !name.trim()}
          className="w-full py-2.5 rounded-xl text-[12px] font-semibold transition-colors disabled:opacity-50"
          style={{ background: "hsl(var(--primary))", color: "hsl(var(--primary-foreground))" }}>
          {saving ? "등록 중..." : "MCP 서버 등록"}
        </button>
      </motion.div>
    </motion.div>
  );
}
