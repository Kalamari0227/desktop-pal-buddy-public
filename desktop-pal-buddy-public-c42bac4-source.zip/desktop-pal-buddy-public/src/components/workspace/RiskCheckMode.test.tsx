import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";
import { RiskCheckMode } from "./RiskCheckMode";

const taskRows: Record<string, unknown>[] = [];
const insertedRows: Record<string, unknown>[] = [];

const createQuery = (table: string) => {
  let rows = table === "tasks" ? taskRows.map((row) => ({ ...row })) : [];
  const query = {
    select: vi.fn(() => query),
    insert: vi.fn((payload: Record<string, unknown>) => {
      insertedRows.push(payload);
      return Promise.resolve({ error: null });
    }),
    eq: vi.fn((column: string, value: unknown) => {
      rows = rows.filter((row) => row[column] === value);
      return query;
    }),
    then: (resolve: (value: { data: unknown[] }) => void) => Promise.resolve({ data: [] }).then(resolve),
  };
  query.then = (resolve: (value: { data: unknown[] }) => void) => Promise.resolve({ data: rows }).then(resolve);
  return query;
};

const fromMock = vi.fn((table: string) => createQuery(table));

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    from: (table: string) => fromMock(table),
  },
}));

vi.mock("@/lib/streamChat", () => ({
  streamChat: vi.fn(),
}));

describe("RiskCheckMode Gateway routing", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    taskRows.length = 0;
    insertedRows.length = 0;
  });

  it("shows a Gateway Task Packet route for selected delivery risk", async () => {
    render(<RiskCheckMode onBack={vi.fn()} />);

    fireEvent.click(screen.getByText("3월 납기 지연 리스크"));

    expect(await screen.findByLabelText("Gateway Task Packet route")).toBeInTheDocument();
    expect(screen.getByText("delivery_delay_risk_check")).toBeInTheDocument();
    expect(screen.getByText("order_status")).toBeInTheDocument();
    expect(screen.getByText("delivery_status")).toBeInTheDocument();
    expect(screen.getByText("risk_assessment")).toBeInTheDocument();
    expect(screen.getByText("do not change delivery schedule")).toBeInTheDocument();
  });

  it("routes supply shortage risk to urgent material assessment", async () => {
    render(<RiskCheckMode onBack={vi.fn()} />);

    fireEvent.click(screen.getByText("DP강 공급 부족 가능성"));

    expect(await screen.findByLabelText("Gateway Task Packet route")).toBeInTheDocument();
    expect(screen.getByText("urgent_material_risk_assessment")).toBeInTheDocument();
    expect(screen.getByText("inventory_status")).toBeInTheDocument();
    expect(screen.getByText("delivery_status")).toBeInTheDocument();
    expect(screen.getByText("do not reserve inventory")).toBeInTheDocument();
  });

  it("registers risk actions with the Gateway packet id on the workboard task", async () => {
    render(<RiskCheckMode onBack={vi.fn()} />);

    fireEvent.click(screen.getByText("3월 납기 지연 리스크"));
    fireEvent.click(await screen.findByRole("button", { name: "대응 액션 등록" }));

    await waitFor(() => {
      expect(insertedRows).toHaveLength(1);
    });
    expect(insertedRows[0]).toMatchObject({
      title: "3월 납기 지연 리스크 대응",
      source: "gateway",
      severity: "critical",
      customer: "현대자동차",
      category: "delivery",
      status: "pending",
    });
    expect(String(insertedRows[0].source_id)).toMatch(/^task-delivery_delay_risk_check-/);
    expect(String(insertedRows[0].description)).toContain("Gateway task type: delivery_delay_risk_check");
    expect(String(insertedRows[0].description)).toContain("Gateway packet id: task-delivery_delay_risk_check-");
  });

  it("treats previously registered risk-source actions as already registered", async () => {
    taskRows.push({
      id: "task-existing",
      source: "risk",
      source_id: "r1",
    });

    render(<RiskCheckMode onBack={vi.fn()} />);

    fireEvent.click(screen.getByText("3월 납기 지연 리스크"));

    expect(await screen.findByText("이미 등록된 액션입니다")).toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "대응 액션 등록" })).not.toBeInTheDocument();
  });
});
