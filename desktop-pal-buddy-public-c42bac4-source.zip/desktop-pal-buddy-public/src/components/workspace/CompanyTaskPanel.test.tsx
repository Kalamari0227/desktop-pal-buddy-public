import { act, fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import {
  createInitialCompanyState,
  createProductionPriorityChangePacket,
  createProductionReadinessReviewPacket,
  canonicalizeActionIntentDigestInput,
  type ActionIntent,
  type Approval,
  type AssessmentEvidence,
  type BusinessOutcome,
  type Execution,
  type ExperienceDraft,
  type ReadbackEvidence,
  type RuntimeTaskRecord,
} from "@/lib/company-runtime";
import type { CompanyRuntimeTaskView } from "@/lib/company-runtime/projection";
import type { CompanyRuntimeClient, CompanyRuntimeResponse } from "@/lib/companyRuntimeClient";
import { CompanyTaskPanel } from "./CompanyTaskPanel";

const epoch = "f7091d6f-e310-46f5-ae2f-a761f136f36a";
const strategyVersionId = "f6846f3d-1aa0-487a-88a1-c383ba9076ea";
const workboardTaskId = "9e650d6d-9e9f-4a09-b041-e345d16620a8";
const packetTaskId = "27862353-b4b6-43d3-bec2-2e4afe57dc06";
const intentId = "92c3bf1a-0e18-47c6-b572-7d304c92571e";
const approvalId = "7429d646-e37e-4f36-9a9b-e83d12a7de87";
const executionId = "f07c5de4-85a8-4ba4-acd2-b7e85cdfe7bb";

const state = createInitialCompanyState({
  epoch,
  strategyVersionId,
  createdAt: "2026-09-19T00:00:00.000Z",
  strategyContentHash: "b".repeat(64),
});
const packet = createProductionPriorityChangePacket({
  packetTaskId,
  createdAt: "2026-09-19T00:00:00.000Z",
  requesterActorId: "sales-demo",
  strategyRef: state.activeStrategyRef,
});
const unsignedIntent = {
  id: intentId,
  revision: 1,
  workboardTaskId,
  packetTaskId,
  epoch,
  targetPlanId: "PP-DEMO-1001",
  fromPriority: 5,
  toPriority: 1,
  readSet: [
    { kind: "inventory", id: "INV-DEMO-GA-ULSAN", version: 1 },
    { kind: "production_plan", id: "PP-DEMO-1001", version: 1 },
    { kind: "sales_order", id: "SO-DEMO-1001", version: 1 },
  ],
  strategyRef: state.activeStrategyRef,
  skillRef: { id: "change-production-priority", version: 1 },
  policyVersion: "company-policy-v1",
  evidenceRefs: ["evidence:production_plan:PP-DEMO-1001:v1"],
  proposalDigest: "a".repeat(64),
  requesterActorId: "sales-demo",
  createdAt: "2026-09-19T00:01:00.000Z",
} satisfies ActionIntent;
const digest = "5da185c5c3943a9dffafe668dc6cca1a9e2a4244a85c691f8a65806aebf2b8d6";
const intent: ActionIntent = { ...unsignedIntent, proposalDigest: digest };
const approval: Approval = {
  id: approvalId,
  intentId,
  intentRevision: 1,
  proposalDigest: digest,
  epoch,
  readSetDigest: "e4b67a495f870a24c4a9987afaceb0e5c547b42272c5e3366f44b40166435742",
  policyVersion: "company-policy-v1",
  skillRef: intent.skillRef,
  strategyRef: intent.strategyRef,
  requesterActorId: "sales-demo",
  approverActorId: "production-demo",
  decision: "approved",
  decidedAt: "2026-09-19T00:02:00.000Z",
  expiresAt: "2099-09-19T00:17:00.000Z",
  consumedByExecutionId: null,
};
const execution: Execution = {
  id: executionId,
  intentId,
  approvalId,
  idempotencyKey: `${epoch}:${intentId}:${digest}`,
  epoch,
  mode: "apply",
  state: "verified",
  before: { priority: 5, version: 1 },
  expectedAfter: { priority: 1, version: 2 },
  attempt: 1,
  startedAt: "2026-09-19T00:03:00.000Z",
};
const readback: ReadbackEvidence = {
  executionId,
  targetPlanId: "PP-DEMO-1001",
  epoch,
  expectedPriority: 1,
  expectedVersion: 2,
  observedPriority: 1,
  observedVersion: 2,
  readAt: "2026-09-19T00:03:01.000Z",
  matches: true,
};
const unobserved: BusinessOutcome = {
  packetTaskId,
  status: "unobserved",
  recordedByActorId: null,
  evidenceRefs: [],
  observedAt: null,
};

function taskRecord(stage: "proposed" | "approved" | "verified", outcome: BusinessOutcome = unobserved): RuntimeTaskRecord {
  return {
    workboardTaskId,
    packetTaskId,
    epoch,
    packet,
    status: stage === "verified" ? "done" : "pending",
    currentProposal: { intentId, revision: 1, proposalDigest: digest },
    currentApprovalId: stage === "proposed" ? null : approvalId,
    executionId: stage === "verified" ? executionId : null,
    businessOutcome: outcome,
  };
}

function snapshot(
  stage: "proposed" | "approved" | "verified",
  outcome: BusinessOutcome = unobserved,
  experienceDrafts: readonly ExperienceDraft[] = [],
) {
  return {
    formatVersion: 1 as const,
    revision: stage === "verified" ? 4 : stage === "approved" ? 3 : 2,
    currentEpoch: epoch,
    stopped: false,
    current: stage === "verified"
      ? { ...state, revision: 4, productionPlans: state.productionPlans.map((plan) => plan.id === "PP-DEMO-1001" ? { ...plan, priority: 1, version: 2 } : plan) }
      : { ...state, revision: stage === "approved" ? 3 : 2 },
    records: {
      tasks: [taskRecord(stage, outcome)],
      actionIntents: [intent],
      approvals: stage === "proposed" ? [] : [{ ...approval, consumedByExecutionId: stage === "verified" ? executionId : null }],
      executions: stage === "verified" ? [execution] : [],
      readbackEvidence: stage === "verified" ? [readback] : [],
      experienceDrafts,
    },
    projection: { actorId: "production-demo" as const, role: "production" as const },
  };
}

const taskView: CompanyRuntimeTaskView = {
  origin: "company_runtime",
  sourceId: workboardTaskId,
  viewKey: `company_runtime:${workboardTaskId}`,
  id: workboardTaskId,
  title: "가상 ERP 생산 우선순위 변경",
  description: "승인 후 priority 5에서 1로 변경",
  source: "company_runtime",
  source_id: packetTaskId,
  severity: "high",
  customer: null,
  category: "production",
  status: "pending",
  created_at: "2026-09-19T00:00:00.000Z",
  packetTaskId,
  epoch,
  packet,
  strategyRef: state.activeStrategyRef,
};

function runtimeResponse(payload: unknown, revision = 0): CompanyRuntimeResponse {
  return { schemaVersion: 1, requestId: crypto.randomUUID(), epoch, actorSessionRevision: revision, ok: true, payload };
}

async function signedIntent(overrides: Partial<ActionIntent>): Promise<ActionIntent> {
  const candidate = { ...intent, ...overrides };
  const bytes = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(canonicalizeActionIntentDigestInput(candidate)),
  );
  const proposalDigest = Array.from(new Uint8Array(bytes), (byte) => byte.toString(16).padStart(2, "0")).join("");
  return { ...candidate, proposalDigest };
}

function digestBuffer(hex: string): ArrayBuffer {
  return Uint8Array.from(hex.match(/.{2}/g) ?? [], (pair) => Number.parseInt(pair, 16)).buffer;
}

function createClient(options: {
  role?: "sales" | "production";
  initial?: "proposed" | "approved" | "verified";
  stopped?: boolean;
  bootstrapSnapshot?: ReturnType<typeof snapshot>;
  explain?: () => Promise<CompanyRuntimeResponse>;
} = {}) {
  const role = options.role ?? "production";
  let currentStage = options.initial ?? "proposed";
  let listener: ((response: CompanyRuntimeResponse) => void) | null = null;
  const status = () => ({
    epoch,
    actorId: role === "production" ? "production-demo" as const : "sales-demo" as const,
    role,
    actorSessionRevision: 0,
    stopped: options.stopped ?? false,
  });
  const emit = () => listener?.(runtimeResponse({ snapshot: snapshot(currentStage), status: status() }));
  const emitFailure = () => listener?.({
    schemaVersion: 1,
    requestId: crypto.randomUUID(),
    epoch,
    actorSessionRevision: 0,
    ok: false,
    error: { code: "ai_failed", message: "explanation_failed" },
  });
  const approve = vi.fn(async () => {
    currentStage = "approved";
    emit();
    return runtimeResponse({ approval });
  });
  const execute = vi.fn(async () => {
    currentStage = "verified";
    emit();
    return runtimeResponse({ status: "verified", execution, readback });
  });
  const explainResult = vi.fn(options.explain ?? (async () => runtimeResponse({
    runtimeMode: "stub",
    actualAI: false,
    explanation: {
      schemaVersion: 1,
      kind: "explanation",
      summary: "검증된 결과 설명",
      verifiedFactIds: [`verified-readback:${executionId}`],
      citedEvidenceIds: [`readback:${executionId}`],
      uncertainties: ["사업 결과 미확인"],
      authorityClaims: [],
    },
  })));
  const client: CompanyRuntimeClient = {
    bootstrap: async () => runtimeResponse({ snapshot: options.bootstrapSnapshot ?? snapshot(currentStage), status: status() }),
    read: async () => runtimeResponse({ snapshot: snapshot(currentStage), status: status() }),
    submit: async () => runtimeResponse({}),
    approve,
    execute,
    role: async () => runtimeResponse({}),
    stop: async () => runtimeResponse({}),
    resume: async () => runtimeResponse({}),
    reset: async () => runtimeResponse({}),
    cancel: async () => runtimeResponse({}),
    reconcile: async () => runtimeResponse({}),
    reviewReadiness: async () => runtimeResponse({}),
    explainResult,
    saveExperienceDraft: async () => runtimeResponse({}),
    subscribe(callback) { listener = callback; return () => { listener = null; }; },
    getContext: () => ({ epoch, actorSessionRevision: 0 }),
  };
  return { client, approve, execute, explainResult, emitFailure };
}

describe("CompanyTaskPanel", () => {
  it("shows the persisted reused asset and extra readiness sources without approval or execute controls", async () => {
    // Given: a runtime-owned readiness task with version-pinned reuse evidence.
    const readinessPacketTaskId = "94a579c3-0aa4-4212-9090-070edb4281c2";
    const readinessWorkboardTaskId = "f4b98c18-2b0a-42d2-92a7-3be95aa45f25";
    const readinessPacket = createProductionReadinessReviewPacket({
      packetTaskId: readinessPacketTaskId,
      createdAt: "2026-09-19T00:10:00.000Z",
      requesterActorId: "production-demo",
      strategyRef: state.activeStrategyRef,
    });
    const readinessTask: RuntimeTaskRecord = {
      workboardTaskId: readinessWorkboardTaskId,
      packetTaskId: readinessPacketTaskId,
      epoch,
      packet: readinessPacket,
      status: "done",
      currentProposal: null,
      currentApprovalId: null,
      executionId: null,
      businessOutcome: {
        packetTaskId: readinessPacketTaskId,
        status: "unobserved",
        recordedByActorId: null,
        evidenceRefs: [],
        observedAt: null,
      },
    };
    const assessment: AssessmentEvidence = {
      id: "a19651d6-3d8f-43b0-842e-57b46bc1aaf2",
      epoch,
      packetTaskId: readinessPacketTaskId,
      baselineReadSet: [
        { kind: "inventory", id: "INV-DEMO-GA-ULSAN", version: 1 },
        { kind: "production_plan", id: "PP-DEMO-1002", version: 1 },
        { kind: "sales_order", id: "SO-DEMO-1002", version: 1 },
      ],
      additionalReadSet: [
        { kind: "inspection", id: "INSPECTION-DEMO-1002", version: 1 },
        { kind: "shipment", id: "SHIPMENT-DEMO-1002", version: 1 },
      ],
      readSet: [
        { kind: "inspection", id: "INSPECTION-DEMO-1002", version: 1 },
        { kind: "inventory", id: "INV-DEMO-GA-ULSAN", version: 1 },
        { kind: "production_plan", id: "PP-DEMO-1002", version: 1 },
        { kind: "sales_order", id: "SO-DEMO-1002", version: 1 },
        { kind: "shipment", id: "SHIPMENT-DEMO-1002", version: 1 },
      ],
      requiredChecks: ["inspection", "packaging"],
      usedAssetRef: { assetId: "learning-ready", version: 2 },
      reuse: { status: "selected", code: null, lineageStatus: "verified", lineageRefs: [], candidateIds: [] },
      finding: "needs_review",
      reasons: ["inspection_pending_and_packaging_not_ready"],
      mutationCount: 0,
      observedAt: "2026-09-19T00:10:00.000Z",
    };
    const readinessSnapshot = {
      formatVersion: 1,
      revision: 2,
      currentEpoch: epoch,
      stopped: false,
      current: { ...state, revision: 2 },
      records: {
        tasks: [readinessTask],
        actionIntents: [],
        approvals: [],
        executions: [],
        readbackEvidence: [],
        assessmentEvidence: [assessment],
        experienceDrafts: [],
        learningProvenance: [],
      },
      projection: { actorId: "production-demo", role: "production" },
    };
    const readinessView: CompanyRuntimeTaskView = {
      ...taskView,
      sourceId: readinessWorkboardTaskId,
      viewKey: `company_runtime:${readinessWorkboardTaskId}`,
      id: readinessWorkboardTaskId,
      source_id: readinessPacketTaskId,
      packetTaskId: readinessPacketTaskId,
      packet: readinessPacket,
      title: readinessPacket.request_summary,
      description: readinessPacket.desired_outcome,
      status: "done",
    };
    const baseClient = createClient().client;
    const client: CompanyRuntimeClient = {
      ...baseClient,
      bootstrap: async () => runtimeResponse({
        snapshot: readinessSnapshot,
        status: { epoch, actorId: "production-demo", role: "production", actorSessionRevision: 0, stopped: false },
      }),
    };

    // When: production opens the persisted readiness task.
    render(<CompanyTaskPanel task={readinessView} client={client} />);

    // Then: reused evidence and uncertainty are visible, while mutation authority is absent.
    const readiness = await screen.findByLabelText("생산 준비 검토 근거");
    expect(readiness).toHaveTextContent("추가 확인 필요 · needs_review");
    expect(readiness).toHaveTextContent("learning-ready · v2");
    expect(readiness).toHaveTextContent("inspection/INSPECTION-DEMO-1002 · v1");
    expect(readiness).toHaveTextContent("shipment/SHIPMENT-DEMO-1002 · v1");
    expect(readiness).toHaveTextContent("사업 결과 미관찰");
    expect(screen.queryByRole("button", { name: "생산 승인" })).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "승인된 변경 적용" })).not.toBeInTheDocument();
  });

  it("reloads the current actor's private experience draft from the runtime snapshot", async () => {
    const persistedDraft: ExperienceDraft = {
      id: "experience-draft-reopened",
      version: 1,
      authorActorId: "sales-demo",
      workItem: { workboardTaskId, packetTaskId },
      sourceEvidenceIds: ["evidence:production_plan:PP-DEMO-1001:v1", `readback:${executionId}`],
      asset: { id: "PP-DEMO-1001", version: 2 },
      correction: "검사와 출하 준비를 재확인합니다.",
      applicability: ["queued production plan"],
      counterexample: "검사 불합격이면 적용하지 않습니다.",
      outcome: { state: "observed", observedAt: "2026-09-19T00:03:01.000Z" },
      visibility: "private",
      reviewRequest: "none",
      createdAt: "2026-09-19T00:04:00.000Z",
    };
    const { client } = createClient({
      role: "sales",
      initial: "verified",
      bootstrapSnapshot: snapshot("verified", unobserved, [persistedDraft]),
    });

    render(<CompanyTaskPanel task={taskView} client={client} />);

    expect(await screen.findByText("보관된 개인 초안 1개")).toBeInTheDocument();
  });

  it("offers an employee-selected experience draft only from the runtime task identity and evidence", async () => {
    const { client } = createClient({ role: "sales", initial: "verified" });
    render(<CompanyTaskPanel task={taskView} client={client} />);

    fireEvent.click(await screen.findByRole("button", { name: "경험 작성" }));

    expect(screen.getByRole("region", { name: "직원 경험 초안" })).toBeInTheDocument();
    expect(screen.getByLabelText("업무 증거")).toHaveTextContent(`evidence:production_plan:PP-DEMO-1001:v1`);
    expect(screen.getByLabelText("업무 증거")).toHaveTextContent(`readback:${executionId}`);
    expect(screen.getByText("직원 판단 보완")).toBeInTheDocument();
  });

  it("shows exact proposal authority and keeps sales unable to approve or apply", async () => {
    const { client, approve: approveCall, execute: executeCall } = createClient({ role: "sales" });
    render(<CompanyTaskPanel task={taskView} client={client} />);

    const proposal = await screen.findByLabelText("현재 변경 제안");
    expect(proposal).toHaveTextContent("PP-DEMO-1001 · priority 5 → 1");
    expect(proposal).toHaveTextContent("PP-DEMO-1002, PP-DEMO-1003");
    expect(proposal).toHaveTextContent(`v1 · ${strategyVersionId}`);
    expect(proposal).toHaveTextContent("change-production-priority@1");
    expect(proposal).toHaveTextContent("company-policy-v1");
    expect(within(proposal).getByLabelText("제안 readSet").children).toHaveLength(3);
    expect(screen.getByRole("button", { name: "생산 승인" })).toBeDisabled();
    expect(screen.getByRole("button", { name: "승인된 변경 적용" })).toBeDisabled();
    expect(screen.getByLabelText("사업 결과")).toHaveTextContent("사업 결과 미관찰");
    expect(approveCall).not.toHaveBeenCalled();
    expect(executeCall).not.toHaveBeenCalled();
  });

  it("requires separate production approval and apply before showing persisted readback", async () => {
    const { client, approve: approveCall, execute: executeCall } = createClient();
    render(<CompanyTaskPanel task={taskView} client={client} />);

    const approveButton = await screen.findByRole("button", { name: "생산 승인" });
    await waitFor(() => expect(approveButton).toBeEnabled());
    fireEvent.click(approveButton);
    await waitFor(() => expect(approveCall).toHaveBeenCalledWith({ workboardTaskId, decision: "approved" }));
    expect(await screen.findByText(/승인자 production-demo/)).toBeInTheDocument();
    await waitFor(() => expect(screen.getByRole("button", { name: "승인된 변경 적용" })).toBeEnabled());

    fireEvent.click(screen.getByRole("button", { name: "승인된 변경 적용" }));
    await waitFor(() => expect(executeCall).toHaveBeenCalledWith({ workboardTaskId, approvalId }));
    const evidence = await screen.findByLabelText("실행 및 재조회 증거");
    expect(evidence).toHaveTextContent("실행 verified · mode apply");
    expect(evidence).toHaveTextContent("기대 priority/version 1/v2");
    expect(evidence).toHaveTextContent("관찰 priority/version 1/v2 · 일치");
    expect(screen.getByLabelText("사업 결과")).toHaveTextContent("사업 결과 미관찰");
  });

  it("labels a persisted simulated observation with actor, time, and evidence basis", async () => {
    const observed: BusinessOutcome = {
      packetTaskId,
      status: "observed_simulated",
      recordedByActorId: "production-demo",
      evidenceRefs: [`execution:${executionId}`, `readback:${executionId}`],
      observedAt: "2026-09-19T00:10:00.000Z",
    };
    const { client } = createClient({ initial: "verified" });
    const observedClient: CompanyRuntimeClient = {
      ...client,
      bootstrap: async () => runtimeResponse({
        snapshot: snapshot("verified", observed),
        status: { epoch, actorId: "production-demo", role: "production", actorSessionRevision: 0, stopped: false },
      }),
    };
    render(<CompanyTaskPanel task={taskView} client={observedClient} />);

    const outcome = await screen.findByLabelText("사업 결과");
    expect(outcome).toHaveTextContent("시뮬레이션 관찰 · observed_simulated");
    expect(outcome).toHaveTextContent("입력자 production-demo");
    expect(outcome).toHaveTextContent("2026-09-19T00:10:00.000Z");
    expect(outcome).toHaveTextContent(`execution:${executionId}`);
    expect(outcome).not.toHaveTextContent("실제 납품 완료");
  });

  it("fails closed for a stale approval and for a stopped runtime", async () => {
    const staleSnapshot = snapshot("approved");
    staleSnapshot.records.approvals = [{ ...approval, readSetDigest: "d".repeat(64) }];
    const stale = createClient({ bootstrapSnapshot: staleSnapshot });
    const { unmount } = render(<CompanyTaskPanel task={taskView} client={stale.client} />);

    expect(await screen.findByText(/승인자 production-demo/)).toBeInTheDocument();
    expect(screen.getByLabelText("승인 상태")).toHaveTextContent("현재 제안과 승인 범위 불일치");
    expect(screen.getByRole("button", { name: "승인된 변경 적용" })).toBeDisabled();
    expect(stale.execute).not.toHaveBeenCalled();
    unmount();

    const stopped = createClient({ initial: "approved", stopped: true });
    render(<CompanyTaskPanel task={taskView} client={stopped.client} />);
    expect(await screen.findByText("정지됨")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "생산 승인" })).toBeDisabled();
    expect(screen.getByRole("button", { name: "승인된 변경 적용" })).toBeDisabled();
  });

  it.each([
    ["readSet digest", (value: ReturnType<typeof snapshot>) => {
      value.records.approvals = [{ ...approval, readSetDigest: "d".repeat(64) }];
    }],
    ["policy", (value: ReturnType<typeof snapshot>) => {
      value.records.approvals = [{ ...approval, policyVersion: "company-policy-v2" }];
    }],
    ["skill", (value: ReturnType<typeof snapshot>) => {
      value.records.approvals = [{ ...approval, skillRef: { id: "review-production-readiness", version: 1 } }];
    }],
    ["strategy", (value: ReturnType<typeof snapshot>) => {
      value.records.approvals = [{ ...approval, strategyRef: { ...approval.strategyRef, strategy_id: "OTHER" } }];
    }],
    ["requester", (value: ReturnType<typeof snapshot>) => {
      value.records.approvals = [{ ...approval, requesterActorId: "management-demo" }];
    }],
    ["approver", (value: ReturnType<typeof snapshot>) => {
      value.records.approvals = [{ ...approval, approverActorId: "sales-demo" }];
    }],
    ["current read version", (value: ReturnType<typeof snapshot>) => {
      value.current = {
        ...value.current,
        inventory: value.current.inventory.map((item) => item.id === "INV-DEMO-GA-ULSAN" ? { ...item, version: 2 } : item),
      };
    }],
    ["registered skill descriptor", (value: ReturnType<typeof snapshot>) => {
      value.current = {
        ...value.current,
        skills: value.current.skills.map((skill) => skill.id === "change-production-priority"
          ? { ...skill, requiredCapabilities: ["virtual-erp-read"] }
          : skill),
      };
    }],
  ])("keeps apply disabled when exact approval %s differs", async (_name, alter) => {
    const changed = snapshot("approved");
    alter(changed);
    const runtime = createClient({ bootstrapSnapshot: changed });
    render(<CompanyTaskPanel task={taskView} client={runtime.client} />);

    expect(await screen.findByText(/승인자/)).toBeInTheDocument();
    await waitFor(() => expect(screen.getByLabelText("승인 상태")).toHaveTextContent("현재 제안과 승인 범위 불일치"));
    expect(screen.getByRole("button", { name: "승인된 변경 적용" })).toBeDisabled();
    expect(runtime.execute).not.toHaveBeenCalled();
  });

  it.each([
    ["workboard task", { workboardTaskId: "0ec706a4-d449-4be3-b948-da3f01f6bc0c" }],
    ["packet task", { packetTaskId: "e4810288-2c6e-4dcc-8066-aeb427006bf0" }],
    ["epoch", { epoch: "9b759d05-b10c-4d9c-ab2d-f2990ef9ac27" }],
  ])("rejects a current proposal linked to another %s", async (_name, overrides) => {
    const changed = snapshot("proposed");
    const foreignIntent = await signedIntent(overrides);
    changed.records.actionIntents = [foreignIntent];
    changed.records.tasks = [{
      ...changed.records.tasks[0],
      currentProposal: { intentId, revision: 1, proposalDigest: foreignIntent.proposalDigest },
    }];
    const runtime = createClient({ bootstrapSnapshot: changed });
    render(<CompanyTaskPanel task={taskView} client={runtime.client} />);

    expect(await screen.findByText("현재 제안 없음")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "생산 승인" })).toBeDisabled();
    expect(runtime.approve).not.toHaveBeenCalled();
  });

  it.each([
    ["consumed approval", (value: ReturnType<typeof snapshot>) => {
      value.records.approvals = [{ ...value.records.approvals[0], consumedByExecutionId: null }];
    }],
    ["idempotency key", (value: ReturnType<typeof snapshot>) => {
      value.records.executions = [{ ...value.records.executions[0], idempotencyKey: "wrong-key" }];
    }],
    ["execution mode", (value: ReturnType<typeof snapshot>) => {
      value.records.executions = [{ ...value.records.executions[0], mode: "read_only" }];
    }],
    ["before priority", (value: ReturnType<typeof snapshot>) => {
      value.records.executions = [{ ...value.records.executions[0], before: { priority: 4, version: 1 } }];
    }],
    ["before version", (value: ReturnType<typeof snapshot>) => {
      value.records.executions = [{ ...value.records.executions[0], before: { priority: 5, version: 2 } }];
    }],
    ["expected priority", (value: ReturnType<typeof snapshot>) => {
      value.records.executions = [{ ...value.records.executions[0], expectedAfter: { priority: 9, version: 2 } }];
      value.records.readbackEvidence = [{ ...value.records.readbackEvidence[0], expectedPriority: 9, observedPriority: 9 }];
    }],
    ["expected version", (value: ReturnType<typeof snapshot>) => {
      value.records.executions = [{ ...value.records.executions[0], expectedAfter: { priority: 1, version: 99 } }];
      value.records.readbackEvidence = [{ ...value.records.readbackEvidence[0], expectedVersion: 99, observedVersion: 99 }];
    }],
    ["execution state", (value: ReturnType<typeof snapshot>) => {
      value.records.executions = [{ ...value.records.executions[0], state: "prepared" }];
    }],
  ])("does not present forged %s as verified execution", async (_name, alter) => {
    const changed = snapshot("verified");
    alter(changed);
    const runtime = createClient({ bootstrapSnapshot: changed });
    render(<CompanyTaskPanel task={taskView} client={runtime.client} />);

    expect(await screen.findByLabelText("런타임 소유 작업 상세")).toHaveTextContent("verification_required");
    expect(screen.getByLabelText("실행 및 재조회 증거")).toHaveTextContent("실행 기록 없음");
    expect(screen.getByLabelText("실행 및 재조회 증거")).not.toHaveTextContent("관찰 priority/version");
  });

  it("shows verification required when apply exists without trusted readback", async () => {
    const verificationSnapshot = snapshot("verified");
    verificationSnapshot.records.tasks = [{
      ...verificationSnapshot.records.tasks[0],
      status: "verification_required",
    }];
    verificationSnapshot.records.executions = [{ ...execution, state: "verification_required" }];
    verificationSnapshot.records.readbackEvidence = [];
    const { client } = createClient({ bootstrapSnapshot: verificationSnapshot });
    render(<CompanyTaskPanel task={taskView} client={client} />);

    const evidence = await screen.findByLabelText("실행 및 재조회 증거");
    expect(evidence).toHaveTextContent("실행 verification_required");
    expect(evidence).toHaveTextContent("재조회 증거 없음 · 완료 확인 불가");
    expect(screen.getByLabelText("런타임 소유 작업 상세")).toHaveTextContent("verification_required");
    expect(screen.getByLabelText("사업 결과")).toHaveTextContent("사업 결과 미관찰");
  });

  it("keeps verified ledger evidence visible after a later AI explanation failure", async () => {
    const runtime = createClient({ initial: "verified" });
    render(<CompanyTaskPanel task={taskView} client={runtime.client} />);
    expect(await screen.findByText(/실행 verified/)).toBeInTheDocument();

    runtime.emitFailure();

    expect(await screen.findByRole("alert")).toHaveTextContent("런타임 요청 실패");
    expect(screen.getByLabelText("실행 및 재조회 증거")).toHaveTextContent("관찰 priority/version 1/v2 · 일치");
    expect(screen.getByLabelText("사업 결과")).toHaveTextContent("사업 결과 미관찰");
  });

  it("shows a read-only explanation and citations only after verified readback", async () => {
    // Given: the selected task already has a verified execution and matching readback.
    const runtime = createClient({ initial: "verified" });
    render(<CompanyTaskPanel task={taskView} client={runtime.client} />);
    const button = await screen.findByRole("button", { name: "결과 설명" });

    // When: the employee explicitly asks for an explanation.
    fireEvent.click(button);

    // Then: the transient explanation is labelled as stub data and cites only the readback item.
    const explanation = await screen.findByRole("region", { name: "확인된 결과 설명" });
    expect(explanation).toHaveTextContent("결정론적 Stub · 실제 AI 아님");
    expect(explanation).toHaveTextContent("검증된 결과 설명");
    expect(explanation).toHaveTextContent(`readback:${executionId}`);
    expect(explanation).toHaveTextContent("사업 결과 미확인");
    expect(screen.getByLabelText("실행 및 재조회 증거")).toHaveTextContent("관찰 priority/version 1/v2 · 일치");
    expect(screen.getByLabelText("사업 결과")).toHaveTextContent("사업 결과 미관찰");
    expect(runtime.explainResult).toHaveBeenCalledWith({ workboardTaskId });
  });

  it("cancels an in-flight explanation when the selected task changes", async () => {
    // Given: an explanation request that has not completed.
    let release: ((value: CompanyRuntimeResponse) => void) | undefined;
    const runtime = createClient({
      initial: "verified",
      explain: () => new Promise((resolve) => { release = resolve; }),
    });
    const cancel = vi.spyOn(runtime.client, "cancel");
    const { rerender } = render(<CompanyTaskPanel task={taskView} client={runtime.client} />);
    fireEvent.click(await screen.findByRole("button", { name: "결과 설명" }));
    expect(await screen.findByRole("button", { name: "설명 취소" })).toBeInTheDocument();

    // When: selection moves to a different workboard task.
    rerender(<CompanyTaskPanel task={{ ...taskView, sourceId: "6e687243-e1f4-41c7-9141-f8494b450e89", id: "6e687243-e1f4-41c7-9141-f8494b450e89" }} client={runtime.client} />);
    release?.(runtimeResponse({
      runtimeMode: "stub",
      actualAI: false,
      explanation: {
        schemaVersion: 1,
        kind: "explanation",
        summary: "늦은 설명",
        verifiedFactIds: [`verified-readback:${executionId}`],
        citedEvidenceIds: [`readback:${executionId}`],
        uncertainties: [],
        authorityClaims: [],
      },
    }));

    // Then: the old explanation is cancelled and never displayed for the new selection.
    await waitFor(() => expect(cancel).toHaveBeenCalledTimes(1));
    expect(screen.queryByText("늦은 설명")).not.toBeInTheDocument();
  });

  it("does not duplicate approval when the action is clicked repeatedly", async () => {
    const runtime = createClient();
    render(<CompanyTaskPanel task={taskView} client={runtime.client} />);
    const approveButton = await screen.findByRole("button", { name: "생산 승인" });
    await waitFor(() => expect(approveButton).toBeEnabled());

    fireEvent.click(approveButton);
    fireEvent.click(approveButton);

    await waitFor(() => expect(runtime.approve).toHaveBeenCalledTimes(1));
  });

  it("does not allow another approval after the current approval is persisted", async () => {
    const runtime = createClient({ initial: "approved" });
    render(<CompanyTaskPanel task={taskView} client={runtime.client} />);

    expect(await screen.findByText(/승인자 production-demo/)).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "생산 승인" })).toBeDisabled();
    fireEvent.click(screen.getByRole("button", { name: "생산 승인" }));
    expect(runtime.approve).not.toHaveBeenCalled();
  });

  it("does not apply an expired current approval", async () => {
    const expiredSnapshot = snapshot("approved");
    expiredSnapshot.records.approvals = [{ ...approval, expiresAt: "2000-01-01T00:00:00.000Z" }];
    const runtime = createClient({ bootstrapSnapshot: expiredSnapshot });
    render(<CompanyTaskPanel task={taskView} client={runtime.client} />);

    expect(await screen.findByText(/승인자 production-demo/)).toBeInTheDocument();
    await waitFor(() => expect(screen.getByLabelText("승인 상태")).toHaveTextContent("승인 만료"));
    expect(screen.getByRole("button", { name: "승인된 변경 적용" })).toBeDisabled();
    fireEvent.click(screen.getByRole("button", { name: "승인된 변경 적용" }));
    expect(runtime.execute).not.toHaveBeenCalled();
  });

  it("disables apply when the current approval expires while the panel stays mounted", async () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-09-19T00:10:00.000Z"));
    const expiringSnapshot = snapshot("approved");
    expiringSnapshot.records.approvals = [{ ...approval, expiresAt: "2026-09-19T00:10:01.000Z" }];
    const runtime = createClient({ bootstrapSnapshot: expiringSnapshot });
    const digestSpy = vi.spyOn(crypto.subtle, "digest")
      .mockResolvedValueOnce(digestBuffer(digest))
      .mockResolvedValueOnce(digestBuffer(approval.readSetDigest));
    const { unmount } = render(<CompanyTaskPanel task={taskView} client={runtime.client} />);

    try {
      await act(async () => { await vi.advanceTimersByTimeAsync(0); });
      expect(screen.getByRole("button", { name: "승인된 변경 적용" })).toBeEnabled();

      await act(async () => { await vi.advanceTimersByTimeAsync(1_001); });

      expect(screen.getByLabelText("승인 상태")).toHaveTextContent("승인 만료");
      expect(screen.getByRole("button", { name: "승인된 변경 적용" })).toBeDisabled();
      fireEvent.click(screen.getByRole("button", { name: "승인된 변경 적용" }));
      expect(runtime.execute).not.toHaveBeenCalled();
    } finally {
      unmount();
      digestSpy.mockRestore();
      vi.useRealTimers();
    }
  });

  it("rechecks expiry at click time even before the scheduled expiry render runs", async () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-09-19T00:10:00.000Z"));
    const expiringSnapshot = snapshot("approved");
    expiringSnapshot.records.approvals = [{ ...approval, expiresAt: "2026-09-19T00:10:01.000Z" }];
    const runtime = createClient({ bootstrapSnapshot: expiringSnapshot });
    const digestSpy = vi.spyOn(crypto.subtle, "digest")
      .mockResolvedValueOnce(digestBuffer(digest))
      .mockResolvedValueOnce(digestBuffer(approval.readSetDigest));
    const { unmount } = render(<CompanyTaskPanel task={taskView} client={runtime.client} />);

    try {
      await act(async () => { await vi.advanceTimersByTimeAsync(0); });
      const applyButton = screen.getByRole("button", { name: "승인된 변경 적용" });
      expect(applyButton).toBeEnabled();

      vi.setSystemTime(new Date("2026-09-19T00:10:01.001Z"));
      fireEvent.click(applyButton);

      expect(runtime.execute).not.toHaveBeenCalled();
    } finally {
      unmount();
      digestSpy.mockRestore();
      vi.useRealTimers();
    }
  });

  it("keeps the proposal unexecuted when the host rejects approval", async () => {
    const runtime = createClient();
    runtime.approve.mockImplementation(async () => ({
      schemaVersion: 1,
      requestId: crypto.randomUUID(),
      epoch,
      actorSessionRevision: 0,
      ok: false,
      error: { code: "persistence_failed", message: "approval_persistence_failed" },
    }));
    render(<CompanyTaskPanel task={taskView} client={runtime.client} />);

    const approveButton = await screen.findByRole("button", { name: "생산 승인" });
    await waitFor(() => expect(approveButton).toBeEnabled());
    fireEvent.click(approveButton);

    expect(await screen.findByRole("alert")).toHaveTextContent("persistence_failed: approval_persistence_failed");
    expect(screen.getByLabelText("승인 상태")).toHaveTextContent("승인 기록 없음");
    expect(screen.getByRole("button", { name: "승인된 변경 적용" })).toBeDisabled();
    expect(runtime.execute).not.toHaveBeenCalled();
  });
});
