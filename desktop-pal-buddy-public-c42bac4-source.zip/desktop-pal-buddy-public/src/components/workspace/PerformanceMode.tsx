import { useState, useRef, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import ReactMarkdown from "react-markdown";
import { streamChat, type Msg } from "@/lib/streamChat";
import { toast } from "sonner";
import {
  BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend,
} from "recharts";
import {
  ArrowLeft, Sparkles, Loader2, CheckCircle2, Copy, RotateCcw, TrendingUp, TrendingDown, Building2, Package,
} from "lucide-react";

/* ── Mock KPI data ── */
const monthlySales = [
  { month: "10월", hyundai: 3200, kia: 1800, toyota: 1100, gm: 800 },
  { month: "11월", hyundai: 3400, kia: 1900, toyota: 1050, gm: 850 },
  { month: "12월", hyundai: 3100, kia: 2000, toyota: 1200, gm: 900 },
  { month: "1월", hyundai: 3500, kia: 2100, toyota: 1150, gm: 950 },
  { month: "2월", hyundai: 3300, kia: 1950, toyota: 1300, gm: 870 },
  { month: "3월", hyundai: 3600, kia: 2200, toyota: 1250, gm: 1000 },
];

const productMix = [
  { name: "GA강판", value: 35, color: "hsl(210, 70%, 55%)" },
  { name: "DP강", value: 25, color: "hsl(150, 60%, 45%)" },
  { name: "CR강판", value: 20, color: "hsl(40, 70%, 55%)" },
  { name: "HR강판", value: 12, color: "hsl(280, 50%, 55%)" },
  { name: "기타", value: 8, color: "hsl(0, 0%, 50%)" },
];

const profitTrend = [
  { month: "10월", margin: 12.5, target: 13 },
  { month: "11월", margin: 13.1, target: 13 },
  { month: "12월", margin: 11.8, target: 13 },
  { month: "1월", margin: 12.9, target: 13 },
  { month: "2월", margin: 13.4, target: 13 },
  { month: "3월", margin: 13.2, target: 13 },
];

const customerKPI = [
  { customer: "현대자동차", code: "현대자동차", volume: "3,600톤", revenue: "54억", margin: "13.2%", marginTrend: "up" as const, yoy: "+8.5%" },
  { customer: "기아", code: "기아", volume: "2,200톤", revenue: "33억", margin: "12.8%", marginTrend: "up" as const, yoy: "+12.1%" },
  { customer: "도요타", code: "도요타", volume: "1,250톤", revenue: "22억", margin: "14.1%", marginTrend: "down" as const, yoy: "-3.2%" },
  { customer: "GM Korea", code: "GM Korea", volume: "1,000톤", revenue: "15억", margin: "11.5%", marginTrend: "up" as const, yoy: "+18.7%" },
];

const topKPIs = [
  { label: "월 총 수주량", value: "8,050톤", change: "+6.3%", up: true },
  { label: "월 매출", value: "124억", change: "+9.1%", up: true },
  { label: "평균 마진율", value: "13.2%", change: "+0.3%p", up: true },
  { label: "미수금", value: "18억", change: "-2.1억", up: false },
];

interface PerformanceModeProps {
  onBack: () => void;
}

type ViewTab = "overview" | "customer" | "product";

export function PerformanceMode({ onBack }: PerformanceModeProps) {
  const [tab, setTab] = useState<ViewTab>("overview");
  const [analysis, setAnalysis] = useState("");
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const analysisRef = useRef<HTMLDivElement>(null);

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    setAnalysis("");

    const context = `
**주요 KPI:**
${topKPIs.map((k) => `- ${k.label}: ${k.value} (${k.change})`).join("\n")}

**고객별 실적:**
${customerKPI.map((c) => `- ${c.customer}: 수주 ${c.volume}, 매출 ${c.revenue}, 마진 ${c.margin} (YoY ${c.yoy})`).join("\n")}

**제품 구성:** ${productMix.map((p) => `${p.name} ${p.value}%`).join(", ")}

**수익성 추이:** ${profitTrend.map((p) => `${p.month} ${p.margin}%`).join(", ")} (목표 ${profitTrend[0].target}%)
`;

    const prompt = `당신은 자동차 강판 마케팅/판매 전문 AI 비서입니다.
다음 실적 데이터를 분석하고 인사이트를 제공해주세요.

${context}

다음 형식으로 분석해주세요:

1. **실적 종합 평가** - 전반적인 실적 수준과 목표 달성 현황
2. **고객별 인사이트** - 각 고객사 실적의 주요 특징과 시사점
3. **제품 포트폴리오 분석** - 제품 구성의 강점/약점
4. **수익성 분석** - 마진율 추이와 개선/악화 요인
5. **액션 플랜** - 실적 개선을 위한 구체적 제안

마크다운으로 깔끔하게 작성해주세요.`;

    let fullText = "";
    try {
      await streamChat({
        messages: [{ role: "user", content: prompt }] as Msg[],
        onDelta: (chunk) => { fullText += chunk; setAnalysis(fullText); },
        onDone: () => setIsAnalyzing(false),
        onError: (e) => { toast.error(e); setIsAnalyzing(false); },
      });
    } catch {
      toast.error("분석 생성에 실패했습니다.");
      setIsAnalyzing(false);
    }
  };

  useEffect(() => {
    if (analysisRef.current) analysisRef.current.scrollTop = analysisRef.current.scrollHeight;
  }, [analysis]);

  const showAnalysis = analysis || isAnalyzing;

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden">
      {/* Header */}
      <div className="flex items-center gap-3 px-6 py-4 border-b border-border/50">
        <button onClick={onBack} className="w-8 h-8 rounded-lg hover:bg-secondary flex items-center justify-center transition-colors">
          <ArrowLeft className="w-4 h-4 text-muted-foreground" />
        </button>
        <div className="flex-1">
          <h2 className="text-[14px] font-semibold">실적/수익성</h2>
          <p className="text-[11px] text-muted-foreground">고객별·제품별 KPI 대시보드</p>
        </div>
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={handleAnalyze}
          disabled={isAnalyzing}
          className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-primary text-primary-foreground text-[11px] font-medium hover:bg-primary/90 transition-colors disabled:opacity-50"
        >
          {isAnalyzing ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
          AI 인사이트
        </motion.button>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Left: Dashboard */}
        <div className={`flex flex-col overflow-hidden transition-all ${showAnalysis ? "w-1/2 border-r border-border/30" : "flex-1"}`}>
          {/* Tabs */}
          <div className="px-6 py-2 border-b border-border/30 flex items-center gap-1">
            {([["overview", "종합"], ["customer", "고객별"], ["product", "제품별"]] as [ViewTab, string][]).map(([t, label]) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`px-3 py-1.5 rounded-md text-[11px] font-medium transition-all ${
                  tab === t ? "bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <div className="flex-1 overflow-y-auto p-6 space-y-5 scrollbar-thin">
            <AnimatePresence mode="wait">
              {/* Overview */}
              {tab === "overview" && (
                <motion.div key="overview" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-5">
                  {/* Top KPIs */}
                  <div className="grid grid-cols-4 gap-3">
                    {topKPIs.map((kpi, i) => (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.05 }}
                        className="p-3.5 rounded-xl bg-secondary/20 border border-border/30"
                      >
                        <p className="text-[10px] text-muted-foreground">{kpi.label}</p>
                        <p className="text-lg font-semibold mt-1 font-mono">{kpi.value}</p>
                        <div className="flex items-center gap-1 mt-1">
                          {kpi.up ? <TrendingUp className="w-3 h-3 text-status-completed" /> : <TrendingDown className="w-3 h-3 text-status-completed" />}
                          <span className="text-[10px] text-muted-foreground">{kpi.change}</span>
                        </div>
                      </motion.div>
                    ))}
                  </div>

                  {/* Sales chart */}
                  <div className="rounded-xl border border-border/30 bg-secondary/10 p-4">
                    <h3 className="text-[12px] font-medium mb-3">월별 수주량 추이 (톤)</h3>
                    <ResponsiveContainer width="100%" height={200}>
                      <BarChart data={monthlySales} barGap={2}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border)/0.3)" />
                        <XAxis dataKey="month" tick={{ fontSize: 10 }} stroke="hsl(var(--muted-foreground))" />
                        <YAxis tick={{ fontSize: 10 }} stroke="hsl(var(--muted-foreground))" />
                        <Tooltip contentStyle={{ fontSize: 11, background: "hsl(var(--popover))", border: "1px solid hsl(var(--border))", borderRadius: 8 }} />
                        <Bar dataKey="hyundai" name="현대자동차" fill="hsl(210, 70%, 55%)" radius={[3, 3, 0, 0]} />
                        <Bar dataKey="kia" name="기아" fill="hsl(150, 60%, 45%)" radius={[3, 3, 0, 0]} />
                        <Bar dataKey="toyota" name="도요타" fill="hsl(40, 70%, 55%)" radius={[3, 3, 0, 0]} />
                        <Bar dataKey="gm" name="GM Korea" fill="hsl(280, 50%, 55%)" radius={[3, 3, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>

                  {/* Profit trend */}
                  <div className="rounded-xl border border-border/30 bg-secondary/10 p-4">
                    <h3 className="text-[12px] font-medium mb-3">마진율 추이 (%)</h3>
                    <ResponsiveContainer width="100%" height={180}>
                      <LineChart data={profitTrend}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border)/0.3)" />
                        <XAxis dataKey="month" tick={{ fontSize: 10 }} stroke="hsl(var(--muted-foreground))" />
                        <YAxis domain={[10, 15]} tick={{ fontSize: 10 }} stroke="hsl(var(--muted-foreground))" />
                        <Tooltip contentStyle={{ fontSize: 11, background: "hsl(var(--popover))", border: "1px solid hsl(var(--border))", borderRadius: 8 }} />
                        <Line type="monotone" dataKey="margin" name="실적" stroke="hsl(var(--primary))" strokeWidth={2} dot={{ r: 3 }} />
                        <Line type="monotone" dataKey="target" name="목표" stroke="hsl(var(--muted-foreground))" strokeWidth={1} strokeDasharray="5 5" dot={false} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </motion.div>
              )}

              {/* Customer tab */}
              {tab === "customer" && (
                <motion.div key="customer" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-5">
                  {/* Customer KPI cards */}
                  <div className="grid grid-cols-2 gap-3">
                    {customerKPI.map((c, i) => (
                      <motion.div
                        key={c.code}
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: i * 0.05 }}
                        className="p-4 rounded-xl border border-border/30 bg-secondary/10"
                      >
                        <div className="flex items-center gap-2 mb-3">
                          <Building2 className="w-4 h-4 text-muted-foreground" />
                          <span className="text-[12px] font-medium">{c.customer}</span>
                          <span className="text-[10px] text-muted-foreground">{c.customer}</span>
                        </div>
                        <div className="grid grid-cols-3 gap-2">
                          <div>
                            <p className="text-[9px] text-muted-foreground">수주량</p>
                            <p className="text-[13px] font-semibold font-mono">{c.volume}</p>
                          </div>
                          <div>
                            <p className="text-[9px] text-muted-foreground">매출</p>
                            <p className="text-[13px] font-semibold font-mono">{c.revenue}</p>
                          </div>
                          <div>
                            <p className="text-[9px] text-muted-foreground">마진율</p>
                            <div className="flex items-center gap-1">
                              <p className="text-[13px] font-semibold font-mono">{c.margin}</p>
                              {c.marginTrend === "up" ? <TrendingUp className="w-3 h-3 text-status-completed" /> : <TrendingDown className="w-3 h-3 text-status-alert" />}
                            </div>
                          </div>
                        </div>
                        <div className="mt-2 text-[10px] text-muted-foreground">
                          YoY: <span className={c.yoy.startsWith("+") ? "text-status-completed" : "text-status-alert"}>{c.yoy}</span>
                        </div>
                      </motion.div>
                    ))}
                  </div>

                  {/* Sales bar chart */}
                  <div className="rounded-xl border border-border/30 bg-secondary/10 p-4">
                    <h3 className="text-[12px] font-medium mb-3">고객별 월별 수주량 (톤)</h3>
                    <ResponsiveContainer width="100%" height={220}>
                      <BarChart data={monthlySales}>
                        <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border)/0.3)" />
                        <XAxis dataKey="month" tick={{ fontSize: 10 }} stroke="hsl(var(--muted-foreground))" />
                        <YAxis tick={{ fontSize: 10 }} stroke="hsl(var(--muted-foreground))" />
                        <Tooltip contentStyle={{ fontSize: 11, background: "hsl(var(--popover))", border: "1px solid hsl(var(--border))", borderRadius: 8 }} />
                        <Legend wrapperStyle={{ fontSize: 10 }} />
                        <Bar dataKey="hyundai" name="현대자동차" fill="hsl(210, 70%, 55%)" radius={[3, 3, 0, 0]} />
                        <Bar dataKey="kia" name="기아" fill="hsl(150, 60%, 45%)" radius={[3, 3, 0, 0]} />
                        <Bar dataKey="toyota" name="도요타" fill="hsl(40, 70%, 55%)" radius={[3, 3, 0, 0]} />
                        <Bar dataKey="gm" name="GM Korea" fill="hsl(280, 50%, 55%)" radius={[3, 3, 0, 0]} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </motion.div>
              )}

              {/* Product tab */}
              {tab === "product" && (
                <motion.div key="product" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-5">
                  <div className="grid grid-cols-2 gap-4">
                    {/* Pie chart */}
                    <div className="rounded-xl border border-border/30 bg-secondary/10 p-4">
                      <h3 className="text-[12px] font-medium mb-3">제품 구성비</h3>
                      <ResponsiveContainer width="100%" height={220}>
                        <PieChart>
                          <Pie data={productMix} cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={3} dataKey="value" label={({ name, value }) => `${name} ${value}%`} style={{ fontSize: 10 }}>
                            {productMix.map((entry) => (
                              <Cell key={entry.name} fill={entry.color} />
                            ))}
                          </Pie>
                          <Tooltip contentStyle={{ fontSize: 11, background: "hsl(var(--popover))", border: "1px solid hsl(var(--border))", borderRadius: 8 }} />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>

                    {/* Product details */}
                    <div className="space-y-2">
                      {productMix.map((p, i) => (
                        <motion.div
                          key={p.name}
                          initial={{ opacity: 0, x: 10 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: i * 0.05 }}
                          className="p-3 rounded-xl border border-border/30 bg-secondary/10"
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <div className="w-2.5 h-2.5 rounded-full" style={{ background: p.color }} />
                              <span className="text-[12px] font-medium">{p.name}</span>
                            </div>
                            <span className="text-[12px] font-semibold font-mono">{p.value}%</span>
                          </div>
                          <div className="mt-1.5 h-1.5 rounded-full bg-secondary/50 overflow-hidden">
                            <motion.div
                              initial={{ width: 0 }}
                              animate={{ width: `${p.value}%` }}
                              transition={{ delay: 0.3 + i * 0.1, duration: 0.5 }}
                              className="h-full rounded-full"
                              style={{ background: p.color }}
                            />
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  </div>

                  {/* Product monthly trend placeholder */}
                  <div className="rounded-xl border border-border/30 bg-secondary/10 p-4">
                    <h3 className="text-[12px] font-medium mb-1">제품별 수주 추이</h3>
                    <p className="text-[10px] text-muted-foreground mb-3">최근 6개월</p>
                    <div className="grid grid-cols-5 gap-2">
                      {productMix.map((p) => (
                        <div key={p.name} className="text-center p-2 rounded-lg bg-secondary/20">
                          <Package className="w-4 h-4 mx-auto mb-1" style={{ color: p.color }} />
                          <p className="text-[10px] font-medium">{p.name}</p>
                          <p className="text-[13px] font-semibold font-mono mt-0.5">{Math.round(8050 * p.value / 100)}톤</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Right: AI Analysis */}
        <AnimatePresence>
          {showAnalysis && (
            <motion.div
              initial={{ opacity: 0, width: 0 }}
              animate={{ opacity: 1, width: "50%" }}
              exit={{ opacity: 0, width: 0 }}
              className="flex flex-col overflow-hidden"
            >
              <div className={`flex items-center justify-between px-5 py-3 border-b border-border/30 ${isAnalyzing ? "bg-primary/5" : "bg-status-completed/5"}`}>
                <div className="flex items-center gap-2">
                  {isAnalyzing ? (
                    <><Loader2 className="w-3.5 h-3.5 text-primary animate-spin" /><span className="text-[11px] text-primary font-medium">AI 분석 중...</span></>
                  ) : (
                    <><CheckCircle2 className="w-3.5 h-3.5 text-status-completed" /><span className="text-[11px] text-status-completed font-medium">인사이트 완료</span></>
                  )}
                </div>
                {!isAnalyzing && (
                  <div className="flex items-center gap-1">
                    <button onClick={() => { navigator.clipboard.writeText(analysis); toast.success("복사되었습니다"); }} className="w-7 h-7 rounded-md hover:bg-secondary flex items-center justify-center"><Copy className="w-3 h-3 text-muted-foreground" /></button>
                    <button onClick={() => setAnalysis("")} className="w-7 h-7 rounded-md hover:bg-secondary flex items-center justify-center"><RotateCcw className="w-3 h-3 text-muted-foreground" /></button>
                  </div>
                )}
              </div>
              <div ref={analysisRef} className="flex-1 overflow-y-auto px-5 py-4 scrollbar-thin">
                <div className="prose prose-sm dark:prose-invert max-w-none text-[13px] leading-relaxed">
                  <ReactMarkdown>{analysis}</ReactMarkdown>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}
