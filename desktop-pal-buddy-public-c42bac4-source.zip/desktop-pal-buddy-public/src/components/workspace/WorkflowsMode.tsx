import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { DataQueryWorkflow } from "./DataQueryWorkflow";
import {
  ArrowLeft,
  GitBranch,
  Play,
  Pause,
  Clock,
  CheckCircle2,
  Plus,
  ChevronRight,
  ArrowRight,
  RotateCcw,
  Trash2,
  Copy,
  Zap,
  Timer,
  Activity,
  X,
} from "lucide-react";
import { toast } from "sonner";

interface WorkflowsModeProps {
  onBack: () => void;
}

interface Workflow {
  id: string;
  name: string;
  description: string;
  status: "active" | "paused";
  trigger: string;
  steps: WorkflowStep[];
  lastRun: string;
  totalRuns: number;
  successRate: number;
  avgDuration: string;
  history: RunHistory[];
}

interface WorkflowStep {
  name: string;
  type: "trigger" | "action" | "condition" | "output";
  status: "completed" | "running" | "pending" | "error";
  detail?: string;
}

interface RunHistory {
  id: string;
  time: string;
  status: "success" | "failed" | "partial";
  duration: string;
}

const workflows: Workflow[] = [
  {
    id: "risk-monitor",
    name: "리스크 자동 모니터링",
    description: "납기/품질/가격 리스크를 실시간 감지하고 긴급 시 알림을 발송합니다.",
    status: "active",
    trigger: "매 30분",
    steps: [
      { name: "데이터 수집", type: "trigger", status: "completed", detail: "ERP/MES 데이터 연동" },
      { name: "리스크 분석", type: "action", status: "completed", detail: "AI 기반 패턴 분석" },
      { name: "심각도 평가", type: "condition", status: "completed", detail: "임계값 > 0.7 시 경고" },
      { name: "알림 발송", type: "output", status: "completed", detail: "Slack + 이메일 알림" },
    ],
    lastRun: "5분 전",
    totalRuns: 156,
    successRate: 98.7,
    avgDuration: "12초",
    history: [
      { id: "r1", time: "14:30", status: "success", duration: "11초" },
      { id: "r2", time: "14:00", status: "success", duration: "13초" },
      { id: "r3", time: "13:30", status: "failed", duration: "8초" },
      { id: "r4", time: "13:00", status: "success", duration: "12초" },
      { id: "r5", time: "12:30", status: "success", duration: "14초" },
    ],
  },
  {
    id: "daily-briefing",
    name: "일일 브리핑 생성",
    description: "매일 오전 8시에 오늘의 업무 브리핑을 자동 생성합니다.",
    status: "active",
    trigger: "매일 08:00",
    steps: [
      { name: "일정 확인", type: "trigger", status: "completed", detail: "캘린더 API 조회" },
      { name: "미결 항목 조회", type: "action", status: "completed", detail: "작업 DB 검색" },
      { name: "리스크 확인", type: "action", status: "completed", detail: "리스크 에이전트 호출" },
      { name: "브리핑 작성", type: "output", status: "completed", detail: "AI 브리핑 문서 생성" },
    ],
    lastRun: "오늘 08:00",
    totalRuns: 45,
    successRate: 100,
    avgDuration: "45초",
    history: [
      { id: "b1", time: "오늘 08:00", status: "success", duration: "42초" },
      { id: "b2", time: "어제 08:00", status: "success", duration: "48초" },
      { id: "b3", time: "2일 전 08:00", status: "success", duration: "44초" },
    ],
  },
  {
    id: "customer-alert",
    name: "고객 이슈 자동 추적",
    description: "고객 관련 이슈가 등록되면 자동으로 관련 담당자에게 알림을 보냅니다.",
    status: "active",
    trigger: "이벤트 기반",
    steps: [
      { name: "이슈 감지", type: "trigger", status: "completed", detail: "웹훅 이벤트 수신" },
      { name: "담당자 매칭", type: "condition", status: "completed", detail: "고객-담당 매핑 DB" },
      { name: "알림 발송", type: "action", status: "completed", detail: "담당자 알림 전송" },
      { name: "작업 생성", type: "output", status: "completed", detail: "자동 작업 등록" },
    ],
    lastRun: "1시간 전",
    totalRuns: 89,
    successRate: 95.5,
    avgDuration: "8초",
    history: [
      { id: "c1", time: "13:45", status: "success", duration: "7초" },
      { id: "c2", time: "11:20", status: "partial", duration: "12초" },
      { id: "c3", time: "09:15", status: "success", duration: "6초" },
    ],
  },
  {
    id: "weekly-report",
    name: "주간 실적 리포트",
    description: "매주 금요일 오후 5시에 주간 실적 보고서를 자동 생성합니다.",
    status: "paused",
    trigger: "매주 금 17:00",
    steps: [
      { name: "실적 데이터 수집", type: "trigger", status: "pending", detail: "BI 시스템 연동" },
      { name: "KPI 분석", type: "action", status: "pending", detail: "주간 KPI 계산" },
      { name: "리포트 생성", type: "action", status: "pending", detail: "AI 리포트 작성" },
      { name: "메일 발송", type: "output", status: "pending", detail: "관련자 자동 발송" },
    ],
    lastRun: "지난주 금",
    totalRuns: 12,
    successRate: 91.7,
    avgDuration: "2분 30초",
    history: [
      { id: "w1", time: "지난주 금 17:00", status: "success", duration: "2분 28초" },
      { id: "w2", time: "2주 전 금", status: "failed", duration: "1분 12초" },
    ],
  },
  {
    id: "price-watch",
    name: "원자재 가격 모니터링",
    description: "주요 원자재 가격 변동을 추적하고 임계값 초과 시 경고합니다.",
    status: "paused",
    trigger: "매 1시간",
    steps: [
      { name: "가격 데이터 수집", type: "trigger", status: "pending", detail: "시장 데이터 API" },
      { name: "변동률 계산", type: "action", status: "pending", detail: "전일 대비 변동 계산" },
      { name: "임계값 비교", type: "condition", status: "pending", detail: "±3% 초과 시 경고" },
      { name: "경고 생성", type: "output", status: "pending", detail: "대시보드 알림" },
    ],
    lastRun: "3시간 전",
    totalRuns: 234,
    successRate: 99.1,
    avgDuration: "5초",
    history: [
      { id: "p1", time: "11:00", status: "success", duration: "4초" },
      { id: "p2", time: "10:00", status: "success", duration: "5초" },
    ],
  },
];

const stepTypeConfig: Record<string, { color: string; icon: typeof Zap }> = {
  trigger: { color: "--primary", icon: Zap },
  action: { color: "--agent-market", icon: Activity },
  condition: { color: "--status-thinking", icon: GitBranch },
  output: { color: "--status-completed", icon: CheckCircle2 },
};

const statusColors: Record<string, string> = {
  success: "--status-completed",
  failed: "--status-error",
  partial: "--status-review",
  completed: "--status-completed",
  running: "--status-active",
  pending: "--status-idle",
  error: "--status-error",
};

export function WorkflowsMode({ onBack }: WorkflowsModeProps) {
  const [filter, setFilter] = useState<"all" | "active" | "paused">("all");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [workflowStates, setWorkflowStates] = useState<Record<string, "active" | "paused">>(
    Object.fromEntries(workflows.map((w) => [w.id, w.status]))
  );

  const filtered = workflows.filter((w) => filter === "all" || workflowStates[w.id] === filter);
  const selected = workflows.find((w) => w.id === selectedId);

  const toggleStatus = (id: string) => {
    setWorkflowStates((prev) => {
      const next = prev[id] === "active" ? "paused" : "active";
      toast.success(next === "active" ? "자동화가 활성화되었습니다" : "자동화가 일시중지되었습니다");
      return { ...prev, [id]: next as "active" | "paused" };
    });
  };

  const runNow = (_id: string) => {
    toast.success("자동화를 수동 실행합니다...");
  };

  const activeCount = Object.values(workflowStates).filter((s) => s === "active").length;
  const pausedCount = Object.values(workflowStates).filter((s) => s === "paused").length;

  return (
    <div className="flex-1 h-full overflow-hidden flex">
      {/* List panel */}
      <div className={`${selectedId ? "w-[380px] border-r border-border/30" : "flex-1"} h-full overflow-y-auto p-6 space-y-5 scrollbar-thin transition-all duration-300`}>
        {/* Header */}
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="p-1.5 rounded-lg hover:bg-secondary transition-colors">
            <ArrowLeft className="w-4 h-4 text-muted-foreground" />
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-semibold tracking-tight">자동화</h1>
            <p className="text-[13px] text-muted-foreground mt-0.5">자동화된 업무 흐름 관리</p>
          </div>
          <button className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-primary text-primary-foreground text-[11px] font-semibold hover:brightness-110 transition-all shadow-sm">
            <Plus className="w-3.5 h-3.5" />
            새 자동화
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: "활성", value: `${activeCount}`, icon: Play, color: "--status-completed" },
            { label: "오늘 실행", value: `${activeCount * 8}`, icon: RotateCcw, color: "--primary" },
            { label: "전체", value: `${workflows.length}`, icon: GitBranch, color: "--muted-foreground" },
          ].map((stat, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="p-4 rounded-2xl bg-secondary/30 border border-border/30"
            >
              <div className="flex items-center gap-2 mb-2">
                <stat.icon className="w-3.5 h-3.5" style={{ color: `hsl(var(${stat.color}))` }} />
                <p className="text-[10px] text-muted-foreground font-medium">{stat.label}</p>
              </div>
              <p className="text-xl font-bold font-mono" style={{ color: `hsl(var(${stat.color}))` }}>{stat.value}</p>
            </motion.div>
          ))}
        </div>

        {/* Data Query Workflow */}
        <div className="p-4 rounded-2xl bg-secondary/10 border border-border/30">
          <DataQueryWorkflow />
        </div>

        {/* Filter tabs */}
        <div className="flex gap-1.5 p-1 rounded-xl bg-secondary/30">
          {[
            { key: "all" as const, label: `전체 ${workflows.length}` },
            { key: "active" as const, label: `활성 ${activeCount}` },
            { key: "paused" as const, label: `중지 ${pausedCount}` },
          ].map((tab) => (
            <button
              key={tab.key}
              onClick={() => setFilter(tab.key)}
              className={`flex-1 px-3 py-2 rounded-lg text-[11px] font-semibold transition-all ${
                filter === tab.key
                  ? "bg-card text-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Workflow list */}
        <div className="space-y-2.5">
          {filtered.map((w, i) => {
            const isActive = workflowStates[w.id] === "active";
            const isSelected = selectedId === w.id;

            return (
              <motion.button
                key={w.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.05 + i * 0.03 }}
                onClick={() => setSelectedId(isSelected ? null : w.id)}
                className={`w-full text-left p-4 rounded-2xl border transition-all duration-200 group ${
                  isSelected
                    ? "bg-primary/5 border-primary/20 shadow-sm"
                    : "bg-secondary/20 border-border/30 hover:border-border/60 hover:bg-secondary/40"
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 transition-colors"
                    style={{
                      background: isActive
                        ? "hsla(var(--status-completed) / 0.1)"
                        : "hsla(var(--muted-foreground) / 0.08)",
                      border: `1px solid ${isActive ? "hsla(var(--status-completed) / 0.2)" : "hsla(var(--muted-foreground) / 0.1)"}`,
                    }}
                  >
                    <GitBranch className="w-4 h-4" style={{ color: isActive ? "hsl(var(--status-completed))" : "hsl(var(--muted-foreground))" }} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <p className="text-[13px] font-semibold text-foreground truncate">{w.name}</p>
                      <span
                        className="text-[9px] px-1.5 py-0.5 rounded-full font-semibold flex-shrink-0"
                        style={{
                          background: isActive ? "hsla(var(--status-completed) / 0.1)" : "hsla(var(--status-idle) / 0.1)",
                          color: isActive ? "hsl(var(--status-completed))" : "hsl(var(--status-idle))",
                        }}
                      >
                        {isActive ? "활성" : "중지"}
                      </span>
                    </div>
                    <p className="text-[11px] text-muted-foreground mt-0.5 truncate">{w.description}</p>
                  </div>
                  <ChevronRight className={`w-4 h-4 text-muted-foreground/50 transition-transform flex-shrink-0 ${isSelected ? "rotate-90" : "group-hover:translate-x-0.5"}`} />
                </div>

                {/* Mini step indicators */}
                <div className="flex items-center gap-1 mt-3">
                  {w.steps.map((step, si) => (
                    <div key={si} className="flex items-center gap-1">
                      <div
                        className="w-1.5 h-1.5 rounded-full"
                        style={{
                          background: isActive
                            ? `hsl(var(${statusColors[step.status] || "--status-idle"}))`
                            : "hsl(var(--muted-foreground) / 0.3)",
                        }}
                      />
                      {si < w.steps.length - 1 && <div className="w-4 h-px bg-border/40" />}
                    </div>
                  ))}
                  <span className="text-[9px] text-muted-foreground ml-2 flex items-center gap-1">
                    <Clock className="w-2.5 h-2.5" />
                    {w.trigger}
                  </span>
                </div>
              </motion.button>
            );
          })}
        </div>
      </div>

      {/* Detail panel */}
      <AnimatePresence>
        {selected && (
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 30 }}
            transition={{ type: "spring", stiffness: 300, damping: 30 }}
            className="flex-1 h-full overflow-y-auto p-6 space-y-6 scrollbar-thin"
          >
            {/* Detail header */}
            <div className="flex items-start justify-between">
              <div>
                <h2 className="text-lg font-bold tracking-tight">{selected.name}</h2>
                <p className="text-[12px] text-muted-foreground mt-1">{selected.description}</p>
              </div>
              <button
                onClick={() => setSelectedId(null)}
                className="p-1.5 rounded-lg hover:bg-secondary transition-colors"
              >
                <X className="w-4 h-4 text-muted-foreground" />
              </button>
            </div>

            {/* Action buttons */}
            <div className="flex gap-2">
              <button
                onClick={() => toggleStatus(selected.id)}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-[11px] font-semibold transition-all"
                style={{
                  background: workflowStates[selected.id] === "active"
                    ? "hsla(var(--status-idle) / 0.1)"
                    : "hsla(var(--status-completed) / 0.1)",
                  color: workflowStates[selected.id] === "active"
                    ? "hsl(var(--status-idle))"
                    : "hsl(var(--status-completed))",
                  border: `1px solid ${workflowStates[selected.id] === "active" ? "hsla(var(--status-idle) / 0.2)" : "hsla(var(--status-completed) / 0.2)"}`,
                }}
              >
                {workflowStates[selected.id] === "active" ? (
                  <><Pause className="w-3.5 h-3.5" /> 일시중지</>
                ) : (
                  <><Play className="w-3.5 h-3.5" /> 활성화</>
                )}
              </button>
              <button
                onClick={() => runNow(selected.id)}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-[11px] font-semibold bg-primary text-primary-foreground hover:brightness-110 transition-all shadow-sm"
              >
                <RotateCcw className="w-3.5 h-3.5" /> 지금 실행
              </button>
              <button className="flex items-center gap-2 px-3 py-2.5 rounded-xl text-[11px] font-medium text-muted-foreground hover:bg-secondary transition-colors border border-border/30">
                <Copy className="w-3.5 h-3.5" /> 복제
              </button>
              <button className="flex items-center gap-2 px-3 py-2.5 rounded-xl text-[11px] font-medium text-muted-foreground hover:bg-destructive/10 hover:text-destructive transition-colors border border-border/30">
                <Trash2 className="w-3.5 h-3.5" /> 삭제
              </button>
            </div>

            {/* Stats row */}
            <div className="grid grid-cols-4 gap-2.5">
              {[
                { label: "트리거", value: selected.trigger, icon: Clock },
                { label: "총 실행", value: `${selected.totalRuns}회`, icon: RotateCcw },
                { label: "성공률", value: `${selected.successRate}%`, icon: CheckCircle2 },
                { label: "평균 시간", value: selected.avgDuration, icon: Timer },
              ].map((s, i) => (
                <div key={i} className="p-3 rounded-xl bg-secondary/20 border border-border/20">
                  <div className="flex items-center gap-1.5 mb-1">
                    <s.icon className="w-3 h-3 text-muted-foreground" />
                    <span className="text-[9px] text-muted-foreground font-medium">{s.label}</span>
                  </div>
                  <span className="text-[13px] font-bold font-mono text-foreground">{s.value}</span>
                </div>
              ))}
            </div>

            {/* Visual flow */}
            <div>
              <h3 className="text-[12px] font-semibold text-foreground mb-3 flex items-center gap-2">
                <GitBranch className="w-3.5 h-3.5 text-primary" />
                자동화 흐름
              </h3>
              <div className="space-y-0">
                {selected.steps.map((step, si) => {
                  const config = stepTypeConfig[step.type] || stepTypeConfig.action;
                  const StepIcon = config.icon;
                  const isWorkflowActive = workflowStates[selected.id] === "active";
                  const stepColor = isWorkflowActive ? config.color : "--muted-foreground";

                  return (
                    <div key={si}>
                      <motion.div
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: si * 0.08 }}
                        className="flex items-center gap-3 p-3 rounded-xl hover:bg-secondary/30 transition-colors cursor-pointer group"
                      >
                        {/* Step icon */}
                        <div
                          className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0 transition-all group-hover:scale-105"
                          style={{
                            background: `hsla(var(${stepColor}) / 0.1)`,
                            border: `1px solid hsla(var(${stepColor}) / 0.2)`,
                          }}
                        >
                          <StepIcon className="w-4 h-4" style={{ color: `hsl(var(${stepColor}))` }} />
                        </div>

                        {/* Content */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="text-[12px] font-semibold text-foreground">{step.name}</span>
                            <span
                              className="text-[8px] px-1.5 py-0.5 rounded font-semibold uppercase tracking-wider"
                              style={{
                                background: `hsla(var(${stepColor}) / 0.08)`,
                                color: `hsl(var(${stepColor}))`,
                              }}
                            >
                              {step.type}
                            </span>
                          </div>
                          {step.detail && (
                            <p className="text-[10px] text-muted-foreground mt-0.5">{step.detail}</p>
                          )}
                        </div>

                        {/* Status dot */}
                        <div
                          className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                          style={{
                            background: isWorkflowActive
                              ? `hsl(var(${statusColors[step.status] || "--status-idle"}))`
                              : "hsl(var(--muted-foreground) / 0.2)",
                          }}
                        />
                      </motion.div>

                      {/* Connector */}
                      {si < selected.steps.length - 1 && (
                        <div className="flex items-center ml-[26px] h-4">
                          <div className="w-px h-full bg-border/40" />
                          <ArrowRight className="w-2.5 h-2.5 text-border/60 -ml-[5px] rotate-90" />
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Run history */}
            <div>
              <h3 className="text-[12px] font-semibold text-foreground mb-3 flex items-center gap-2">
                <Activity className="w-3.5 h-3.5 text-primary" />
                최근 실행 기록
              </h3>
              <div className="space-y-1.5">
                {selected.history.map((run, i) => (
                  <motion.div
                    key={run.id}
                    initial={{ opacity: 0, y: 5 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.04 }}
                    className="flex items-center gap-3 p-3 rounded-xl bg-secondary/15 border border-border/20 hover:bg-secondary/30 transition-colors cursor-pointer"
                  >
                    <div
                      className="w-2 h-2 rounded-full flex-shrink-0"
                      style={{ background: `hsl(var(${statusColors[run.status] || "--status-idle"}))` }}
                    />
                    <span className="text-[11px] text-foreground font-medium flex-1">{run.time}</span>
                    <span
                      className="text-[9px] px-2 py-0.5 rounded-full font-semibold"
                      style={{
                        background: `hsla(var(${statusColors[run.status]}) / 0.1)`,
                        color: `hsl(var(${statusColors[run.status]}))`,
                      }}
                    >
                      {run.status === "success" ? "성공" : run.status === "failed" ? "실패" : "부분"}
                    </span>
                    <span className="text-[10px] text-muted-foreground font-mono flex items-center gap-1">
                      <Timer className="w-3 h-3" />
                      {run.duration}
                    </span>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
