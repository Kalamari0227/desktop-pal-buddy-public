import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { supabase } from "@/integrations/supabase/client";
import {
  ArrowLeft,
  FileText,
  Plus,
  Download,
  Copy,
  BarChart3,
  ShieldAlert,
  Users,
} from "lucide-react";
import { toast } from "sonner";
import type { TaskRecord } from "@/types/task";

interface ReportsModeProps {
  onBack: () => void;
  onModeSelect: (mode: string) => void;
}

interface Report {
  id: string;
  title: string;
  type: "weekly" | "monthly" | "quarterly" | "custom";
  period: string;
  createdAt: string;
  sections: string[];
  status: "draft" | "final";
  summary: string;
}

const typeLabels: Record<string, string> = {
  weekly: "주간 보고",
  monthly: "월간 보고",
  quarterly: "분기 보고",
  custom: "맞춤 보고",
};

const typeColors: Record<string, string> = {
  weekly: "hsl(var(--agent-market))",
  monthly: "hsl(var(--agent-docs))",
  quarterly: "hsl(var(--agent-risk))",
  custom: "hsl(var(--agent-planner))",
};

const sectionIcons: Record<string, typeof BarChart3> = {
  sales: BarChart3,
  customers: Users,
  risks: ShieldAlert,
  quality: FileText,
  market: BarChart3,
  action: FileText,
};

const sectionLabels: Record<string, string> = {
  sales: "판매 실적",
  customers: "고객 동향",
  risks: "리스크",
  quality: "품질",
  market: "시장",
  action: "액션 플랜",
};

// Generate mock reports based on real task data
function generateReportHistory(tasks: TaskRecord[]): Report[] {
  const reports: Report[] = [];
  const now = new Date();

  // Recent weekly reports
  for (let w = 0; w < 4; w++) {
    const date = new Date(now);
    date.setDate(date.getDate() - w * 7);
    const weekStart = new Date(date);
    weekStart.setDate(weekStart.getDate() - weekStart.getDay() + 1);
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekEnd.getDate() + 4);

    const formatDate = (d: Date) =>
      `${d.getFullYear()}.${String(d.getMonth() + 1).padStart(2, "0")}.${String(d.getDate()).padStart(2, "0")}`;

    const relevantTasks = tasks.filter((t) => {
      const created = new Date(t.created_at);
      return created >= weekStart && created <= weekEnd;
    });

    const riskCount = relevantTasks.filter((t) => t.severity === "critical" || t.severity === "high").length;

    reports.push({
      id: `weekly-${w}`,
      title: `주간 업무 보고 (${formatDate(weekStart)} ~ ${formatDate(weekEnd)})`,
      type: "weekly",
      period: `${formatDate(weekStart)} ~ ${formatDate(weekEnd)}`,
      createdAt: weekEnd.toISOString(),
      sections: ["sales", "customers", "risks"],
      status: w === 0 ? "draft" : "final",
      summary: relevantTasks.length > 0
        ? `${relevantTasks.length}건 작업 처리, 긴급 ${riskCount}건 포함`
        : `정기 주간 보고서 — 주요 고객 동향 및 실적 요약`,
    });
  }

  // Monthly report
  reports.push({
    id: "monthly-1",
    title: `${now.getFullYear()}년 ${now.getMonth() + 1}월 월간 보고`,
    type: "monthly",
    period: `${now.getFullYear()}년 ${now.getMonth() + 1}월`,
    createdAt: new Date(now.getFullYear(), now.getMonth(), 1).toISOString(),
    sections: ["sales", "customers", "risks", "quality", "market"],
    status: "draft",
    summary: "월간 실적 종합 및 주요 이슈 분석",
  });

  // Quarterly report
  const quarter = Math.ceil((now.getMonth() + 1) / 3);
  reports.push({
    id: "quarterly-1",
    title: `${now.getFullYear()}년 ${quarter}분기 실적 보고`,
    type: "quarterly",
    period: `${now.getFullYear()}년 ${quarter}분기`,
    createdAt: new Date(now.getFullYear(), (quarter - 1) * 3, 1).toISOString(),
    sections: ["sales", "customers", "risks", "quality", "market", "action"],
    status: "final",
    summary: "분기 매출 124억원 달성 (목표 대비 103%), 리스크 3건 대응 완료",
  });

  return reports.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
}

export function ReportsMode({ onBack, onModeSelect }: ReportsModeProps) {
  const [reports, setReports] = useState<Report[]>([]);
  const [filter, setFilter] = useState<"all" | "weekly" | "monthly" | "quarterly">("all");
  const [selectedReport, setSelectedReport] = useState<Report | null>(null);

  useEffect(() => {
    supabase
      .from("tasks")
      .select("*")
      .order("created_at", { ascending: false })
      .then(({ data }) => {
        setReports(generateReportHistory(data || []));
      });
  }, []);

  const filtered = reports.filter((r) => filter === "all" || r.type === filter);

  const timeSince = (dateStr: string) => {
    const diff = Date.now() - new Date(dateStr).getTime();
    const days = Math.floor(diff / 86400000);
    if (days === 0) return "오늘";
    if (days === 1) return "어제";
    if (days < 7) return `${days}일 전`;
    if (days < 30) return `${Math.floor(days / 7)}주 전`;
    return `${Math.floor(days / 30)}개월 전`;
  };

  return (
    <div className="flex-1 h-full overflow-y-auto p-6 space-y-6 scrollbar-thin">
      <div className="flex items-center gap-3">
        <button onClick={selectedReport ? () => setSelectedReport(null) : onBack} className="p-1.5 rounded-lg hover:bg-secondary transition-colors">
          <ArrowLeft className="w-4 h-4 text-muted-foreground" />
        </button>
        <div className="flex-1">
          <h1 className="text-xl font-semibold tracking-tight">
            {selectedReport ? selectedReport.title : "보고서 관리"}
          </h1>
          <p className="text-[13px] text-muted-foreground mt-0.5">
            {selectedReport ? selectedReport.period : "생성된 보고서 목록 및 새 보고서 작성"}
          </p>
        </div>
        {!selectedReport && (
          <button
            onClick={() => onModeSelect("report")}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary/10 text-primary text-[11px] font-medium hover:bg-primary/20 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            새 보고서
          </button>
        )}
      </div>

      {!selectedReport ? (
        <>
          {/* Stats */}
          <div className="grid grid-cols-4 gap-3">
            {[
              { label: "전체 보고서", value: `${reports.length}건`, color: "hsl(var(--primary))" },
              { label: "초안", value: `${reports.filter(r => r.status === "draft").length}건`, color: "hsl(var(--status-review))" },
              { label: "완료", value: `${reports.filter(r => r.status === "final").length}건`, color: "hsl(var(--status-completed))" },
              { label: "이번 주", value: `${reports.filter(r => { const d = Date.now() - new Date(r.createdAt).getTime(); return d < 7 * 86400000; }).length}건`, color: "hsl(var(--agent-market))" },
            ].map((stat, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.04 }}
                className="p-3 rounded-2xl bg-secondary/20 border border-border/30"
              >
                <p className="text-[9px] text-muted-foreground">{stat.label}</p>
                <p className="text-base font-semibold mt-0.5 font-mono" style={{ color: stat.color }}>{stat.value}</p>
              </motion.div>
            ))}
          </div>

          {/* Filter tabs */}
          <div className="flex gap-2">
            {(["all", "weekly", "monthly", "quarterly"] as const).map((key) => (
              <button
                key={key}
                onClick={() => setFilter(key)}
                className={`px-3 py-1.5 rounded-lg text-[11px] font-medium transition-colors ${
                  filter === key ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-secondary"
                }`}
              >
                {key === "all" ? `전체 ${reports.length}` : `${typeLabels[key]} ${reports.filter(r => r.type === key).length}`}
              </button>
            ))}
          </div>

          {/* Report list */}
          <div className="space-y-2">
            {filtered.map((report, i) => (
              <motion.button
                key={report.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.05 + i * 0.03 }}
                onClick={() => setSelectedReport(report)}
                className="w-full text-left p-4 rounded-xl bg-secondary/20 border border-border/30 hover:border-border/60 transition-colors"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3">
                    <div className="w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5" style={{ background: `${typeColors[report.type]}15` }}>
                      <FileText className="w-4 h-4" style={{ color: typeColors[report.type] }} />
                    </div>
                    <div>
                      <p className="text-[12px] font-medium text-foreground">{report.title}</p>
                      <p className="text-[11px] text-muted-foreground mt-0.5">{report.summary}</p>
                      <div className="flex items-center gap-2 mt-2">
                        <span className="text-[9px] px-1.5 py-0.5 rounded font-medium" style={{
                          background: `${typeColors[report.type]}15`,
                          color: typeColors[report.type],
                        }}>
                          {typeLabels[report.type]}
                        </span>
                        <span className={`text-[9px] px-1.5 py-0.5 rounded font-medium ${
                          report.status === "draft"
                            ? "bg-status-review/10 text-status-review"
                            : "bg-status-completed/10 text-status-completed"
                        }`}>
                          {report.status === "draft" ? "초안" : "완료"}
                        </span>
                        {report.sections.slice(0, 3).map((s) => (
                          <span key={s} className="text-[8px] px-1 py-0.5 rounded bg-muted/50 text-muted-foreground">
                            {sectionLabels[s] || s}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                  <div className="text-right flex-shrink-0 ml-3">
                    <span className="text-[9px] text-muted-foreground">{timeSince(report.createdAt)}</span>
                  </div>
                </div>
              </motion.button>
            ))}
          </div>
        </>
      ) : (
        /* Report detail view */
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-5">
          {/* Meta */}
          <div className="grid grid-cols-3 gap-3">
            <div className="p-3 rounded-xl bg-secondary/20 border border-border/30">
              <p className="text-[9px] text-muted-foreground">유형</p>
              <p className="text-[12px] font-medium mt-0.5" style={{ color: typeColors[selectedReport.type] }}>
                {typeLabels[selectedReport.type]}
              </p>
            </div>
            <div className="p-3 rounded-xl bg-secondary/20 border border-border/30">
              <p className="text-[9px] text-muted-foreground">상태</p>
              <p className={`text-[12px] font-medium mt-0.5 ${selectedReport.status === "draft" ? "text-status-review" : "text-status-completed"}`}>
                {selectedReport.status === "draft" ? "초안" : "완료"}
              </p>
            </div>
            <div className="p-3 rounded-xl bg-secondary/20 border border-border/30">
              <p className="text-[9px] text-muted-foreground">생성일</p>
              <p className="text-[12px] font-medium mt-0.5">
                {new Date(selectedReport.createdAt).toLocaleDateString("ko-KR")}
              </p>
            </div>
          </div>

          {/* Included sections */}
          <div>
            <h3 className="text-[12px] font-semibold mb-2">포함 섹션</h3>
            <div className="flex flex-wrap gap-2">
              {selectedReport.sections.map((s) => {
                const Icon = sectionIcons[s] || FileText;
                return (
                  <div key={s} className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-secondary/30 border border-border/30">
                    <Icon className="w-3 h-3 text-muted-foreground" />
                    <span className="text-[10px] text-foreground">{sectionLabels[s] || s}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Summary */}
          <div className="p-4 rounded-xl bg-secondary/20 border border-border/30">
            <h3 className="text-[12px] font-semibold mb-2">요약</h3>
            <p className="text-[12px] text-muted-foreground leading-relaxed">{selectedReport.summary}</p>
          </div>

          {/* Actions */}
          <div className="flex items-center gap-2">
            <button
              onClick={() => onModeSelect("report")}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg bg-primary text-primary-foreground text-[11px] font-medium hover:bg-primary/90 transition-colors"
            >
              <FileText className="w-3.5 h-3.5" />
              수정/재생성
            </button>
            <button
              onClick={() => toast.success("보고서가 복사되었습니다")}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-border/50 text-[11px] text-muted-foreground hover:bg-secondary transition-colors"
            >
              <Copy className="w-3 h-3" />복사
            </button>
            <button
              onClick={() => toast.success("보고서가 다운로드되었습니다 (데모)")}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-border/50 text-[11px] text-muted-foreground hover:bg-secondary transition-colors"
            >
              <Download className="w-3 h-3" />다운로드
            </button>
          </div>
        </motion.div>
      )}
    </div>
  );
}
