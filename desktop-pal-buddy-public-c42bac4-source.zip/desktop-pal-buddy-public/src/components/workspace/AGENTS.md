# Workspace Components

This guide adds workspace-specific rules to the root and `src/AGENTS.md` guides.

## File Map

| Concern | Start here |
|---|---|
| Mode rendering, initial context, cross-mode navigation | `WorkspaceLayout.tsx` |
| Menu groups and active parent highlighting | `WorkspaceNav.tsx` |
| Request intake, packet preview, handoff, task creation | `GatewayMode.tsx` |
| Workboard selection, filters, approval, evidence, results | `TasksMode.tsx` |
| Meeting output and action-item conversion | `AgentMeetingMode.tsx` |
| Optional demo strategy/version selection | `StrategySelect.tsx` |
| Pinned strategy version display | `StrategySummary.tsx` |

## Routing and State

- Keep mode names, lazy imports, labels, and navigation groups aligned.
- Preserve grouped navigation highlighting for detail modes such as `response` and `agent-meeting`.
- Route context through `handleModeSelect(mode, context)`; clear unrelated context on a new selection.
- Keep `initialMode` and `initialContext` updates synchronized with the visible mode.
- Preserve `onOpenTasks(taskId)` from Gateway/customer response through `modeContext.taskId` to `TasksMode.initialTaskId`.
- Pass the Workboard row ID for selection; do not substitute the Gateway packet ID.
- When navigating to a created follow-up or its origin, reset filters that would hide that task.
- Reconcile selection after filtering, deletion, and refresh; empty results must not retain stale detail content.
- Keep asynchronous evidence, approval, event, and result responses associated with the selected task's identity.

## Policy and Persistence

- Keep classification, schemas, completion gates, packet conversion, and result interpretation in `src/lib/agentic/`.
- Components present domain decisions and orchestrate reads/writes; avoid duplicating policy in button handlers.
- Preserve intake packet identity and metadata when editing a Workboard title or current status.
- Keep Workboard IDs and packet IDs distinct when reading evidence, approvals, events, and results.
- Invalid intake metadata must remain visible as requiring review; do not silently treat it as unlinked legacy data.
- Base approval and completion decisions on persisted records and the existing domain gates.
- A local preview, optimistic state, or success toast is not proof that all records were persisted.
- Verify saved state by readback where the workflow depends on durable evidence, approval, or result records.
- Report task-save and event-save failures separately when persistence is partial.
- Failure/retry changes must retain the intended action and its identity; avoid silently replacing a retry with a new action.
- For meeting conversion, inspect extraction and persistence together; helper tests alone do not establish end-to-end retry or idempotency guarantees.
- Preserve entered request/context/result text when an operation fails so the user can recover.

## Demo Strategy UI

- Strategy controls currently use `src/data/demoStrategyCatalog.ts` and the demo runtime boundary.
- Keep the fixture/reset notice visible where shown; do not imply persistent strategy editing or service execution.
- Changing the selected strategy clears its version; a selected strategy requires a valid matching version before task creation/handoff.
- Display the packet's pinned strategy version, rather than substituting the catalog's latest version.
- Keep strategy filters and summaries consistent with preserved demo intake metadata.

## Focused Verification

- Navigation: `WorkspaceNav.test.tsx` covers menu grouping and active detail modes.
- Intake/routing: `GatewayMode.test.tsx` covers validation, Workboard creation/reuse, and demo version selection.
- Workboard: `TasksMode.test.tsx` covers selection, filters, lineage, evidence, approvals, and completion gates.
- Meeting conversion: `AgentMeetingMode.test.tsx` exercises extraction-to-persistence and partial-save scenarios; extend coverage for the actual failure being changed.
- Strategy presentation: `StrategySelect.test.tsx` and `StrategySummary.test.tsx` cover version selection and pinned-version content.
- Example component check: `npm test -- src/components/workspace/TasksMode.test.tsx`.
- Demo strategy journey: `npm run test:e2e -- tests/e2e/strategy-loop.spec.ts`.
- Entry/desktop browser smoke: `npm run test:e2e -- tests/e2e/desktop-pal.spec.ts` when workspace entry is affected.
- E2E server/runtime constraints remain in the root guide; browser smoke does not prove native Electron behavior.
