import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowLeft,
  User,
  Bell,
  Bot,
  Shield,
  Palette,
  ChevronRight,
  Check,
  Sun,
  Moon,
  Monitor,
  Save,
  Database,
  Zap,
  Lock,
  Eye,
  EyeOff,
  Info,
  Loader2,
  LogIn,
  LogOut,
} from "lucide-react";
import { toast } from "sonner";
import { useSupabaseSession } from "@/hooks/useSupabaseSession";
import { runtimeConnectionLabel } from "@/lib/runtimeMode";

interface SettingsModeProps {
  onBack: () => void;
}

/* ──────────── Theme management ──────────── */
type ThemeMode = "dark" | "light" | "system";

function getStoredTheme(): ThemeMode {
  return (localStorage.getItem("steel-theme") as ThemeMode) || "light";
}

function applyTheme(mode: ThemeMode) {
  const root = document.documentElement;
  if (mode === "system") {
    const prefersDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
    root.classList.toggle("light", !prefersDark);
  } else {
    root.classList.toggle("light", mode === "light");
  }
  localStorage.setItem("steel-theme", mode);
}

/* ──────────── Select / Dropdown ──────────── */
function SettingsSelect({
  value,
  options,
  onChange,
}: {
  value: string;
  options: { label: string; value: string }[];
  onChange: (v: string) => void;
}) {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-border/50 bg-secondary/30 text-[11px] text-foreground hover:border-border transition-colors min-w-[120px] justify-between"
      >
        {options.find((o) => o.value === value)?.label || value}
        <ChevronRight className={`w-3 h-3 text-muted-foreground transition-transform ${open ? "rotate-90" : ""}`} />
      </button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            className="absolute right-0 top-full mt-1 z-20 min-w-[150px] rounded-xl border border-border/50 bg-popover shadow-lg overflow-hidden"
          >
            {options.map((opt) => (
              <button
                key={opt.value}
                onClick={() => {
                  onChange(opt.value);
                  setOpen(false);
                }}
                className={`w-full text-left px-3 py-2 text-[11px] flex items-center justify-between hover:bg-secondary/50 transition-colors ${
                  value === opt.value ? "text-primary font-medium" : "text-foreground"
                }`}
              >
                {opt.label}
                {value === opt.value && <Check className="w-3 h-3 text-primary" />}
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ──────────── Toggle Switch ──────────── */
function Toggle({ enabled, onToggle }: { enabled: boolean; onToggle: () => void }) {
  return (
    <button
      onClick={onToggle}
      className={`w-10 h-[22px] rounded-full transition-colors relative flex-shrink-0 ${
        enabled ? "bg-primary" : "bg-muted"
      }`}
    >
      <motion.div
        layout
        className="absolute top-[3px] w-4 h-4 rounded-full bg-white shadow-sm"
        style={{ left: enabled ? 20 : 3 }}
        transition={{ type: "spring", stiffness: 500, damping: 30 }}
      />
    </button>
  );
}

/* ──────────── Editable Field ──────────── */
function EditableField({
  label,
  value,
  onSave,
  type = "text",
}: {
  label: string;
  value: string;
  onSave: (v: string) => void;
  type?: string;
}) {
  const [editing, setEditing] = useState(false);
  const [localVal, setLocalVal] = useState(value);
  const [showPassword, setShowPassword] = useState(false);

  return (
    <div className="flex items-center justify-between py-3 px-3 rounded-lg hover:bg-secondary/20 transition-colors group">
      <span className="text-[12px] text-foreground">{label}</span>
      {editing ? (
        <div className="flex items-center gap-1.5">
          <div className="relative">
            <input
              type={type === "password" && !showPassword ? "password" : "text"}
              value={localVal}
              onChange={(e) => setLocalVal(e.target.value)}
              autoFocus
              className="h-7 px-2 pr-7 rounded-md border border-primary/50 bg-secondary/30 text-[11px] text-foreground w-[180px] focus:outline-none focus:border-primary"
            />
            {type === "password" && (
              <button
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-1.5 top-1/2 -translate-y-1/2"
              >
                {showPassword ? (
                  <EyeOff className="w-3 h-3 text-muted-foreground" />
                ) : (
                  <Eye className="w-3 h-3 text-muted-foreground" />
                )}
              </button>
            )}
          </div>
          <button
            onClick={() => {
              onSave(localVal);
              setEditing(false);
              toast.success(`${label}이(가) 업데이트되었습니다`);
            }}
            className="w-6 h-6 rounded-md bg-primary/20 hover:bg-primary/30 flex items-center justify-center transition-colors"
          >
            <Check className="w-3 h-3 text-primary" />
          </button>
        </div>
      ) : (
        <button
          onClick={() => setEditing(true)}
          className="text-[11px] text-muted-foreground hover:text-foreground transition-colors cursor-pointer group-hover:underline"
        >
          {type === "password" ? "••••••••" : value}
        </button>
      )}
    </div>
  );
}

/* ──────────── Section Wrapper ──────────── */
function SettingsSection({
  icon: Icon,
  label,
  description,
  children,
  badge,
}: {
  icon: typeof User;
  label: string;
  description: string;
  children: React.ReactNode;
  badge?: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-2xl bg-secondary/15 border border-border/30 overflow-hidden"
    >
      <div className="flex items-center gap-3 px-5 py-4 border-b border-border/20">
        <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
          <Icon className="w-4 h-4 text-primary" />
        </div>
        <div className="flex-1">
          <div className="flex items-center gap-2">
            <h3 className="text-[13px] font-semibold text-foreground">{label}</h3>
            {badge && (
              <span className="text-[8px] px-1.5 py-0.5 rounded-full bg-primary/15 text-primary font-medium">
                {badge}
              </span>
            )}
          </div>
          <p className="text-[10px] text-muted-foreground mt-0.5">{description}</p>
        </div>
      </div>
      <div className="px-5 py-2 divide-y divide-border/15">{children}</div>
    </motion.div>
  );
}

/* ──────────── Row item ──────────── */
function SettingsRow({
  label,
  description,
  children,
}: {
  label: string;
  description?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-center justify-between py-3 gap-4">
      <div className="flex-1 min-w-0">
        <p className="text-[12px] text-foreground">{label}</p>
        {description && <p className="text-[9px] text-muted-foreground mt-0.5">{description}</p>}
      </div>
      <div className="flex-shrink-0">{children}</div>
    </div>
  );
}

/* ──────────── Confirmation Modal ──────────── */
function ConfirmModal({
  open,
  title,
  description,
  onConfirm,
  onCancel,
}: {
  open: boolean;
  title: string;
  description: string;
  onConfirm: () => void;
  onCancel: () => void;
}) {
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-[360px] rounded-2xl bg-popover border border-border/50 shadow-2xl p-6 space-y-4"
      >
        <h3 className="text-[14px] font-semibold text-foreground">{title}</h3>
        <p className="text-[12px] text-muted-foreground leading-relaxed">{description}</p>
        <div className="flex justify-end gap-2 pt-2">
          <button
            onClick={onCancel}
            className="px-4 py-2 rounded-lg border border-border/50 text-[11px] text-muted-foreground hover:bg-secondary transition-colors"
          >
            취소
          </button>
          <button
            onClick={onConfirm}
            className="px-4 py-2 rounded-lg bg-destructive text-destructive-foreground text-[11px] font-medium hover:bg-destructive/90 transition-colors"
          >
            확인
          </button>
        </div>
      </motion.div>
    </div>
  );
}

/* ──────────── Main Component ──────────── */
export function SettingsMode({ onBack }: SettingsModeProps) {
  const [theme, setTheme] = useState<ThemeMode>(getStoredTheme);
  const [showResetModal, setShowResetModal] = useState(false);
  const [authEmail, setAuthEmail] = useState("cskim@steelai.co.kr");
  const [authPassword, setAuthPassword] = useState("");
  const [authPending, setAuthPending] = useState(false);
  const {
    mode,
    isConfigured,
    isAuthenticated,
    email,
    status,
    connection,
    signIn,
    signOut,
  } = useSupabaseSession();

  // Profile state
  const [profile, setProfile] = useState({
    name: "김철수",
    title: "마케팅 매니저",
    department: "자동차강판 마케팅팀",
    email: "cskim@steelai.co.kr",
  });

  // Notification toggles
  const [notif, setNotif] = useState({
    critical: true,
    high: true,
    medium: true,
    low: false,
    email: true,
    sound: true,
  });

  // Agent toggles
  const [agent, setAgent] = useState({
    autoRisk: true,
    autoBriefing: true,
    autoTask: true,
    language: "ko",
    model: "gemini-flash",
  });

  // Security toggles
  const [security, setSecurity] = useState({
    twoFactor: false,
    sessionTimeout: "30",
    accessLog: true,
  });

  // Appearance
  const [dateFormat, setDateFormat] = useState("yyyy-MM-dd");
  const [timezone, setTimezone] = useState("Asia/Seoul");

  useEffect(() => {
    applyTheme(theme);
  }, [theme]);

  useEffect(() => {
    if (email) setAuthEmail(email);
  }, [email]);

  const handleSignIn = async () => {
    if (!authEmail.trim() || !authPassword) {
      toast.error("이메일과 비밀번호를 입력해주세요");
      return;
    }

    setAuthPending(true);
    try {
      await signIn(authEmail.trim(), authPassword);
      setAuthPassword("");
      toast.success("Supabase에 로그인되었습니다");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "로그인에 실패했습니다");
    } finally {
      setAuthPending(false);
    }
  };

  const handleSignOut = async () => {
    setAuthPending(true);
    try {
      await signOut();
      toast.success("로그아웃되었습니다");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "로그아웃에 실패했습니다");
    } finally {
      setAuthPending(false);
    }
  };

  const themeOptions: { mode: ThemeMode; icon: typeof Sun; label: string }[] = [
    { mode: "light", icon: Sun, label: "라이트" },
    { mode: "dark", icon: Moon, label: "다크" },
    { mode: "system", icon: Monitor, label: "시스템" },
  ];

  return (
    <div className="flex-1 h-full overflow-y-auto p-6 space-y-5 scrollbar-thin">
      {/* Header */}
      <div className="flex items-center gap-3">
        <button onClick={onBack} className="p-1.5 rounded-lg hover:bg-secondary transition-colors">
          <ArrowLeft className="w-4 h-4 text-muted-foreground" />
        </button>
        <div className="flex-1">
          <h1 className="text-xl font-semibold tracking-tight">설정</h1>
          <p className="text-[13px] text-muted-foreground mt-0.5">시스템 및 사용자 환경 설정</p>
        </div>
        <button
          onClick={() => {
            toast.success("모든 설정이 저장되었습니다");
          }}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-primary/10 text-primary text-[11px] font-medium hover:bg-primary/20 transition-colors"
        >
          <Save className="w-3.5 h-3.5" />
          저장
        </button>
      </div>

      {/* ━━ Profile ━━ */}
      <SettingsSection icon={User} label="프로필 설정" description="사용자 이름, 직책, 부서 정보 관리">
        <EditableField
          label="이름"
          value={profile.name}
          onSave={(v) => setProfile((p) => ({ ...p, name: v }))}
        />
        <EditableField
          label="직책"
          value={profile.title}
          onSave={(v) => setProfile((p) => ({ ...p, title: v }))}
        />
        <EditableField
          label="부서"
          value={profile.department}
          onSave={(v) => setProfile((p) => ({ ...p, department: v }))}
        />
        <EditableField
          label="이메일"
          value={profile.email}
          onSave={(v) => setProfile((p) => ({ ...p, email: v }))}
        />
      </SettingsSection>

      {/* ━━ Runtime Connection ━━ */}
      <SettingsSection
        icon={Database}
        label="실서비스 연결"
        description="데모/스테이징/운영 모드와 Supabase 로그인 상태"
        badge={runtimeConnectionLabel(mode)}
      >
        <SettingsRow label="현재 연결 상태" description={connection.detail}>
          <span
            className={`inline-flex items-center gap-1.5 rounded-lg px-2.5 py-1 text-[11px] ${
              connection.tone === "success"
                ? "bg-status-completed/10 text-status-completed"
                : connection.tone === "danger"
                  ? "bg-destructive/10 text-destructive"
                  : connection.tone === "warning"
                    ? "bg-amber-500/10 text-amber-600 dark:text-amber-300"
                    : "bg-secondary/50 text-muted-foreground"
            }`}
          >
            {status === "checking" && <Loader2 className="h-3 w-3 animate-spin" />}
            {connection.label}
          </span>
        </SettingsRow>

        <SettingsRow
          label="Supabase 환경"
          description={
            mode === "demo"
              ? "데모 모드는 실제 인증을 사용하지 않습니다"
              : isConfigured
                ? "Edge Function 호출 준비 완료"
                : "VITE_SUPABASE_URL과 VITE_SUPABASE_PUBLISHABLE_KEY가 필요합니다"
          }
        >
          <span className="text-[11px] text-muted-foreground">{isConfigured ? "설정됨" : "미설정"}</span>
        </SettingsRow>

        {mode !== "demo" && !isAuthenticated && (
          <div className="space-y-2 py-3">
            <div className="grid gap-2 sm:grid-cols-2">
              <input
                type="email"
                value={authEmail}
                onChange={(event) => setAuthEmail(event.target.value)}
                disabled={!isConfigured || authPending}
                className="h-9 rounded-lg border border-border/50 bg-secondary/25 px-3 text-[12px] text-foreground outline-none transition-colors focus:border-primary disabled:opacity-50"
                placeholder="email@company.com"
              />
              <input
                type="password"
                value={authPassword}
                onChange={(event) => setAuthPassword(event.target.value)}
                disabled={!isConfigured || authPending}
                className="h-9 rounded-lg border border-border/50 bg-secondary/25 px-3 text-[12px] text-foreground outline-none transition-colors focus:border-primary disabled:opacity-50"
                placeholder="비밀번호"
              />
            </div>
            <button
              onClick={handleSignIn}
              disabled={!isConfigured || authPending}
              className="inline-flex h-8 items-center gap-1.5 rounded-lg bg-primary/10 px-3 text-[11px] font-medium text-primary transition-colors hover:bg-primary/20 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {authPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <LogIn className="h-3.5 w-3.5" />}
              로그인
            </button>
          </div>
        )}

        {mode !== "demo" && isAuthenticated && (
          <SettingsRow label="인증된 사용자" description={email || "Supabase 세션 활성화됨"}>
            <button
              onClick={handleSignOut}
              disabled={authPending}
              className="inline-flex h-8 items-center gap-1.5 rounded-lg border border-border/50 px-3 text-[11px] text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground disabled:cursor-not-allowed disabled:opacity-50"
            >
              {authPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <LogOut className="h-3.5 w-3.5" />}
              로그아웃
            </button>
          </SettingsRow>
        )}
      </SettingsSection>

      {/* ━━ Appearance ━━ */}
      <SettingsSection icon={Palette} label="화면 설정" description="테마, 언어, 날짜 형식 등 화면 환경 설정">
        {/* Theme selector */}
        <div className="py-3">
          <p className="text-[12px] text-foreground mb-2.5">테마</p>
          <div className="flex gap-2">
            {themeOptions.map(({ mode, icon: ThIcon, label }) => (
              <button
                key={mode}
                onClick={() => setTheme(mode)}
                className={`flex-1 flex flex-col items-center gap-1.5 py-3 rounded-xl border transition-all ${
                  theme === mode
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-border/40 bg-secondary/20 text-muted-foreground hover:border-border"
                }`}
              >
                <ThIcon className="w-5 h-5" />
                <span className="text-[10px] font-medium">{label}</span>
              </button>
            ))}
          </div>
        </div>

        <SettingsRow label="날짜 형식">
          <SettingsSelect
            value={dateFormat}
            options={[
              { label: "YYYY-MM-DD", value: "yyyy-MM-dd" },
              { label: "DD/MM/YYYY", value: "dd/MM/yyyy" },
              { label: "MM/DD/YYYY", value: "MM/dd/yyyy" },
              { label: "YYYY년 M월 D일", value: "yyyy년 M월 d일" },
            ]}
            onChange={(v) => {
              setDateFormat(v);
              toast.success("날짜 형식이 변경되었습니다");
            }}
          />
        </SettingsRow>

        <SettingsRow label="시간대">
          <SettingsSelect
            value={timezone}
            options={[
              { label: "서울 (UTC+9)", value: "Asia/Seoul" },
              { label: "도쿄 (UTC+9)", value: "Asia/Tokyo" },
              { label: "상하이 (UTC+8)", value: "Asia/Shanghai" },
              { label: "런던 (UTC+0)", value: "Europe/London" },
            ]}
            onChange={(v) => {
              setTimezone(v);
              toast.success("시간대가 변경되었습니다");
            }}
          />
        </SettingsRow>

        <SettingsRow label="언어">
          <span className="text-[11px] text-muted-foreground flex items-center gap-1">
            🇰🇷 한국어
          </span>
        </SettingsRow>
      </SettingsSection>

      {/* ━━ Notifications ━━ */}
      <SettingsSection icon={Bell} label="알림 설정" description="알림 채널, 우선순위 및 수신 방법 관리">
        <SettingsRow label="긴급 알림 (Critical)" description="심각한 리스크 발생 시 즉시 알림">
          <Toggle enabled={notif.critical} onToggle={() => setNotif((p) => ({ ...p, critical: !p.critical }))} />
        </SettingsRow>
        <SettingsRow label="높음 알림 (High)" description="15분 내 알림">
          <Toggle enabled={notif.high} onToggle={() => setNotif((p) => ({ ...p, high: !p.high }))} />
        </SettingsRow>
        <SettingsRow label="보통 알림 (Medium)" description="1시간 내 요약 알림">
          <Toggle enabled={notif.medium} onToggle={() => setNotif((p) => ({ ...p, medium: !p.medium }))} />
        </SettingsRow>
        <SettingsRow label="낮음 알림 (Low)" description="일일 요약에 포함">
          <Toggle enabled={notif.low} onToggle={() => setNotif((p) => ({ ...p, low: !p.low }))} />
        </SettingsRow>
        <SettingsRow label="이메일 알림" description="등록된 이메일로 알림 수신">
          <Toggle enabled={notif.email} onToggle={() => setNotif((p) => ({ ...p, email: !p.email }))} />
        </SettingsRow>
        <SettingsRow label="알림 사운드" description="알림 시 소리 재생">
          <Toggle enabled={notif.sound} onToggle={() => setNotif((p) => ({ ...p, sound: !p.sound }))} />
        </SettingsRow>
      </SettingsSection>

      {/* ━━ Agents ━━ */}
      <SettingsSection icon={Bot} label="에이전트 설정" description="AI 에이전트 동작, 모델 및 권한 설정" badge="AI">
        <SettingsRow label="자동 리스크 감지" description="에이전트가 자동으로 리스크를 탐지합니다">
          <Toggle enabled={agent.autoRisk} onToggle={() => setAgent((p) => ({ ...p, autoRisk: !p.autoRisk }))} />
        </SettingsRow>
        <SettingsRow label="자동 브리핑 생성" description="매일 오전 8시 브리핑 자동 생성">
          <Toggle
            enabled={agent.autoBriefing}
            onToggle={() => setAgent((p) => ({ ...p, autoBriefing: !p.autoBriefing }))}
          />
        </SettingsRow>
        <SettingsRow label="자동 작업 생성" description="이메일·일정 기반 작업 자동 생성">
          <Toggle enabled={agent.autoTask} onToggle={() => setAgent((p) => ({ ...p, autoTask: !p.autoTask }))} />
        </SettingsRow>
        <SettingsRow label="AI 모델">
          <SettingsSelect
            value={agent.model}
            options={[
              { label: "Gemini Flash", value: "gemini-flash" },
              { label: "Gemini Pro", value: "gemini-pro" },
              { label: "GPT-5 Mini", value: "gpt-5-mini" },
              { label: "GPT-5", value: "gpt-5" },
            ]}
            onChange={(v) => {
              setAgent((p) => ({ ...p, model: v }));
              toast.success("AI 모델이 변경되었습니다");
            }}
          />
        </SettingsRow>
        <SettingsRow label="응답 언어">
          <SettingsSelect
            value={agent.language}
            options={[
              { label: "한국어", value: "ko" },
              { label: "English", value: "en" },
              { label: "日本語", value: "ja" },
              { label: "中文", value: "zh" },
            ]}
            onChange={(v) => {
              setAgent((p) => ({ ...p, language: v }));
              toast.success("응답 언어가 변경되었습니다");
            }}
          />
        </SettingsRow>
      </SettingsSection>

      {/* ━━ Security ━━ */}
      <SettingsSection icon={Shield} label="보안 설정" description="인증, 세션, 데이터 보안 관리">
        <SettingsRow label="2단계 인증 (2FA)" description="로그인 시 추가 인증 요구">
          <Toggle
            enabled={security.twoFactor}
            onToggle={() => {
              setSecurity((p) => ({ ...p, twoFactor: !p.twoFactor }));
              toast.success(security.twoFactor ? "2FA가 비활성화되었습니다" : "2FA가 활성화되었습니다");
            }}
          />
        </SettingsRow>
        <SettingsRow label="세션 타임아웃">
          <SettingsSelect
            value={security.sessionTimeout}
            options={[
              { label: "15분", value: "15" },
              { label: "30분", value: "30" },
              { label: "1시간", value: "60" },
              { label: "4시간", value: "240" },
            ]}
            onChange={(v) => {
              setSecurity((p) => ({ ...p, sessionTimeout: v }));
              toast.success("세션 타임아웃이 변경되었습니다");
            }}
          />
        </SettingsRow>
        <SettingsRow label="접근 로그 기록" description="사용자 활동 로그 저장">
          <Toggle
            enabled={security.accessLog}
            onToggle={() => setSecurity((p) => ({ ...p, accessLog: !p.accessLog }))}
          />
        </SettingsRow>
        <SettingsRow label="데이터 암호화">
          <span className="flex items-center gap-1 text-[11px] text-status-completed">
            <Lock className="w-3 h-3" />
            AES-256
          </span>
        </SettingsRow>
      </SettingsSection>

      {/* ━━ Data & Storage ━━ */}
      <SettingsSection icon={Database} label="데이터 관리" description="캐시, 저장 공간 및 데이터 초기화">
        <SettingsRow label="캐시 데이터" description="로컬 캐시 용량">
          <button
            onClick={() => toast.success("캐시가 삭제되었습니다")}
            className="px-3 py-1.5 rounded-lg border border-border/50 text-[11px] text-muted-foreground hover:bg-secondary hover:text-foreground transition-colors"
          >
            캐시 삭제
          </button>
        </SettingsRow>
        <SettingsRow label="설정 초기화" description="모든 설정을 기본값으로 복원">
          <button
            onClick={() => setShowResetModal(true)}
            className="px-3 py-1.5 rounded-lg border border-destructive/30 text-[11px] text-destructive hover:bg-destructive/10 transition-colors"
          >
            초기화
          </button>
        </SettingsRow>
      </SettingsSection>

      {/* ━━ About ━━ */}
      <motion.div
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        className="rounded-2xl bg-secondary/15 border border-border/30 p-5"
      >
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center">
            <Zap className="w-4 h-4 text-primary" />
          </div>
          <div>
            <h3 className="text-[13px] font-semibold text-foreground">Steel AI Assistant</h3>
            <p className="text-[10px] text-muted-foreground mt-0.5">버전 1.0.0 · 자동차강판 마케팅/판매 AI 비서</p>
          </div>
        </div>
        <div className="mt-3 pt-3 border-t border-border/20 flex items-center gap-4">
          <span className="text-[10px] text-muted-foreground flex items-center gap-1">
            <Info className="w-3 h-3" /> 최종 업데이트: 2026.03.08
          </span>
        </div>
      </motion.div>

      {/* Bottom spacing for chat bar */}
      <div className="h-4" />

      {/* Confirm Modal */}
      <ConfirmModal
        open={showResetModal}
        title="설정 초기화"
        description="모든 설정이 기본값으로 복원됩니다. 이 작업은 되돌릴 수 없습니다."
        onConfirm={() => {
          setShowResetModal(false);
          setTheme("dark");
          setNotif({ critical: true, high: true, medium: true, low: false, email: true, sound: true });
          setAgent({ autoRisk: true, autoBriefing: true, autoTask: true, language: "ko", model: "gemini-flash" });
          setSecurity({ twoFactor: false, sessionTimeout: "30", accessLog: true });
          setDateFormat("yyyy-MM-dd");
          setTimezone("Asia/Seoul");
          toast.success("모든 설정이 초기화되었습니다");
        }}
        onCancel={() => setShowResetModal(false)}
      />
    </div>
  );
}
