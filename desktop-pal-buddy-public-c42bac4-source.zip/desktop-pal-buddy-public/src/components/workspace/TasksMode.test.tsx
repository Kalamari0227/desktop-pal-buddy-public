import { fireEvent, render, screen, waitFor, within } from "@testing-library/react";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { createDemoStrategyRows } from "@/data/demoStrategyData";
import { createProductionPriorityChangePacket } from "@/lib/company-runtime";
import { TasksMode } from "./TasksMode";

const writeText = vi.fn();
const scrollIntoView = vi.fn();

const initialTaskRows: Record<string, unknown>[] = [
  {
    id: "task-1",
    title: "3월 납기 지연 리스크",
    description: "열연 라인 정비로 인해 GA강판 3월 납기 2주 지연 가능성",
    source: "risk",
    source_id: "risk-1",
    severity: "critical",
    customer: "현대자동차",
    category: "delivery",
    status: "pending",
    created_at: "2026-07-04T00:00:00.000Z",
  },
  {
    id: "task-2",
    title: "고객 납기 문의 답장",
    description: "기아 구매팀에 보낼 답장 초안 필요",
    source: "manual",
    source_id: null,
    severity: "medium",
    customer: "기아",
    category: "delivery",
    status: "pending",
    created_at: "2026-07-03T00:00:00.000Z",
  },
  {
    id: "task-3",
    title: "staging DB migration 실행",
    description: "스테이징 DB 마이그레이션 적용이 필요한지 확인",
    source: "manual",
    source_id: null,
    severity: "high",
    customer: null,
    category: "quality",
    status: "pending",
    created_at: "2026-07-02T00:00:00.000Z",
  },
  {
    id: "task-gateway-1",
    title: "현대자동차 GA 강판 긴급재 위험도 따져줘",
    description: "Gateway 대화에서 생성된 업무",
    source: "gateway",
    source_id: "task-urgent_material_risk_assessment-20260704",
    severity: "medium",
    customer: "현대자동차",
    category: "delivery",
    status: "pending",
    created_at: "2026-07-01T00:00:00.000Z",
  },
];

let taskRows: Record<string, unknown>[] = [];
let runtimeTaskRows: Record<string, unknown>[] = [];
const repositoryMutationKinds: string[] = [];
const repositoryMutationInputs: Array<{
  kind: string;
  origin: string;
  sourceId: string;
  viewKey: string;
}> = [];

const evidenceRows: Record<string, unknown>[] = [];
const approvalRows: Record<string, unknown>[] = [];
const eventRows: Record<string, unknown>[] = [];
const resultRows: Record<string, unknown>[] = [];
const taskUpdatePayloads: Record<string, unknown>[] = [];
let useBarePromiseLikeQueries = false;

function barePromiseLike<T>(promise: Promise<T>): PromiseLike<T> {
  return {
    then<TResult1 = T, TResult2 = never>(
      onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | null,
      onrejected?: ((reason: unknown) => TResult2 | PromiseLike<TResult2>) | null,
    ): PromiseLike<TResult1 | TResult2> {
      return barePromiseLike(promise.then(onfulfilled, onrejected));
    },
  };
}

const createQuery = (table: string) => {
  let rows: Record<string, unknown>[] = table === "agent_evidence"
    ? [...evidenceRows]
      : table === "agent_approvals"
        ? [...approvalRows]
        : table === "agent_events"
          ? [...eventRows]
          : table === "agent_results"
            ? [...resultRows]
            : taskRows.map((row) => ({ ...row }));
  const query = {
    select: vi.fn(() => query),
    order: vi.fn((column: string, options?: { ascending?: boolean }) => {
      rows.sort((a, b) => String(a[column] || "").localeCompare(String(b[column] || "")));
      if (options?.ascending === false) rows.reverse();
      return query;
    }),
    update: vi.fn((payload: Record<string, unknown>) => {
      if (table === "tasks") {
        taskUpdatePayloads.push(payload);
      }
      return query;
    }),
    delete: vi.fn(() => query),
    insert: vi.fn((payload: Record<string, unknown> | Record<string, unknown>[]) => {
      const payloads = Array.isArray(payload) ? payload : [payload];
      const insertedRows: Record<string, unknown>[] = [];
      if (table === "tasks") {
        payloads.forEach((item) => {
          const now = new Date().toISOString();
          const row = {
            id: `task-created-${taskRows.length + insertedRows.length + 1}`,
            owner_id: "user-1",
            description: null,
            source: null,
            source_id: null,
            severity: null,
            customer: null,
            category: null,
            status: "pending",
            created_at: now,
            updated_at: now,
            ...item,
          };
          taskRows.push(row);
          insertedRows.push(row);
        });
      }
      if (table === "agent_evidence") {
        payloads.forEach((item) => {
          evidenceRows.push({
            id: `row-${evidenceRows.length + 1}`,
            owner_id: "user-1",
            ...item,
          });
        });
      }
      if (table === "agent_approvals") {
        payloads.forEach((item) => {
          approvalRows.push({
            id: `approval-${approvalRows.length + 1}`,
            owner_id: "user-1",
            ...item,
          });
        });
      }
      if (table === "agent_events") {
        payloads.forEach((item) => {
          eventRows.push({
            id: `event-${eventRows.length + 1}`,
            owner_id: "user-1",
            ...item,
          });
        });
      }
      if (table === "agent_results") {
        payloads.forEach((item) => {
          resultRows.push({
            id: `result-${resultRows.length + 1}`,
            owner_id: "user-1",
            ...item,
          });
        });
      }
      rows = insertedRows.length > 0 ? insertedRows : rows;
      return query;
    }),
    eq: vi.fn((column: string, value: unknown) => {
      rows = rows.filter((row) => row[column] === value);
      return query;
    }),
    single: vi.fn(() => Promise.resolve({ data: rows[0] ?? null, error: null })),
    then: (resolve: (value: { data: Record<string, unknown>[]; error: null }) => unknown) => {
      const promise = Promise.resolve({ data: rows, error: null }).then(resolve);
      return useBarePromiseLikeQueries ? barePromiseLike(promise) : promise;
    },
  };
  return query;
};

const fromMock = vi.fn((table: string) => createQuery(table));

vi.mock("@/lib/taskRepository", () => ({
  taskRepository: {
    load: vi.fn(async () => ({
      tasks: [
        ...taskRows.map((task) => ({
          ...task,
          origin: "legacy",
          sourceId: task.id,
          viewKey: `legacy:${String(task.id)}`,
        })),
        ...runtimeTaskRows,
      ],
      runtime: runtimeTaskRows.length > 0
        ? { state: "ready", epoch: "f7091d6f-e310-46f5-ae2f-a761f136f36a", tasks: runtimeTaskRows }
        : { state: "unavailable", tasks: [], reason: "invalid_runtime_snapshot" },
    })),
    subscribe: vi.fn(() => vi.fn()),
    mutateLegacy: vi.fn(async ({ kind, origin, sourceId, viewKey, mutate }) => {
      repositoryMutationKinds.push(kind);
      repositoryMutationInputs.push({ kind, origin, sourceId, viewKey });
      if (origin === "company_runtime" && runtimeTaskRows.some((task) => task.sourceId === sourceId)) {
        return { ok: false, reason: "runtime_owned" };
      }
      return { ok: true, value: await mutate() };
    }),
  },
}));

vi.mock("@/integrations/supabase/client", () => ({
  supabase: {
    from: (table: string) => fromMock(table),
  },
}));

vi.mock("./CompanyLineagePanel", () => ({
  CompanyLineagePanel: ({ originTaskId, onOpenTask }: { originTaskId?: string; onOpenTask?: (taskId: string) => void }) => (
    <section aria-label="Workboard 계보" data-origin-task={originTaskId}>
      <button type="button" onClick={() => originTaskId && onOpenTask?.(originTaskId)}>계보 원 업무 열기</button>
    </section>
  ),
}));

describe("TasksMode Gateway workboard", () => {
  beforeEach(() => {
    vi.clearAllMocks();
    taskRows = initialTaskRows.map((row) => ({ ...row }));
    runtimeTaskRows = [];
    repositoryMutationKinds.length = 0;
    repositoryMutationInputs.length = 0;
    evidenceRows.length = 0;
    approvalRows.length = 0;
    eventRows.length = 0;
    resultRows.length = 0;
    taskUpdatePayloads.length = 0;
    useBarePromiseLikeQueries = false;
    writeText.mockReset();
    scrollIntoView.mockReset();
    Element.prototype.scrollIntoView = scrollIntoView;
    window.scrollTo = vi.fn();
    Object.defineProperty(navigator, "clipboard", {
      configurable: true,
      value: { writeText },
    });
  });

  afterEach(() => {
    vi.unstubAllEnvs();
  });

  it("shows Gateway judgment for the selected workboard task", async () => {
    render(<TasksMode onBack={vi.fn()} />);

    const taskTitle = (await screen.findAllByText("3월 납기 지연 리스크"))[0];
    const taskCard = taskTitle.closest<HTMLElement>("[role='button']");
    expect(taskCard).not.toBeNull();
    const cardSignals = within(taskCard!).getByLabelText("3월 납기 지연 리스크 Gateway 판단 신호");
    expect(cardSignals).toHaveTextContent("업무 납기 지연 리스크 확인");
    expect(cardSignals).toHaveTextContent("위험도 보통");
    expect(cardSignals).toHaveTextContent("승인 불필요");

    expect(await screen.findByLabelText("Gateway 작업 판단")).toBeInTheDocument();
    expect(screen.getByText("납기 지연 리스크 확인")).toBeInTheDocument();
    expect(screen.getAllByText("위험도 보통").length).toBeGreaterThan(0);
    expect(screen.getAllByText("납기 상태").length).toBeGreaterThan(0);
    expect(screen.getByText("납기 일정 변경 금지")).toBeInTheDocument();
    expect(screen.getByLabelText("Codex 전달문 미리보기")).toHaveTextContent("# Codex Task Packet");
    expect(screen.getByText("완료 전 증거 필요")).toBeInTheDocument();
    expect(screen.getByLabelText("작업 이벤트 타임라인")).toBeInTheDocument();
  });

  it("renders and selects a runtime-owned task as a read-only origin without querying Supabase detail tables", async () => {
    taskRows.push({
      ...initialTaskRows[1],
      id: "9e650d6d-9e9f-4a09-b041-e345d16620a8",
      title: "동일 UUID의 레거시 작업",
      source_id: "27862353-b4b6-43d3-bec2-2e4afe57dc06",
    });
    runtimeTaskRows = [{
      origin: "company_runtime",
      sourceId: "9e650d6d-9e9f-4a09-b041-e345d16620a8",
      viewKey: "company_runtime:9e650d6d-9e9f-4a09-b041-e345d16620a8",
      id: "9e650d6d-9e9f-4a09-b041-e345d16620a8",
      title: "가상 ERP 생산 우선순위 변경",
      description: "승인 후 priority 5에서 1로 변경",
      source: "company_runtime",
      source_id: "27862353-b4b6-43d3-bec2-2e4afe57dc06",
      severity: "high",
      customer: null,
      category: "production",
      status: "pending",
      created_at: "2026-09-19T00:00:00.000Z",
      packetTaskId: "27862353-b4b6-43d3-bec2-2e4afe57dc06",
      epoch: "f7091d6f-e310-46f5-ae2f-a761f136f36a",
      strategyRef: {
        strategy_id: "STRATEGY-DEMO-PRODUCTION",
        strategy_version_id: "f6846f3d-1aa0-487a-88a1-c383ba9076ea",
      },
      packet: createProductionPriorityChangePacket({
        packetTaskId: "27862353-b4b6-43d3-bec2-2e4afe57dc06",
        createdAt: "2026-09-19T00:00:00.000Z",
        requesterActorId: "sales-demo",
        strategyRef: {
          strategy_id: "STRATEGY-DEMO-PRODUCTION",
          strategy_version_id: "f6846f3d-1aa0-487a-88a1-c383ba9076ea",
        },
      }),
      card: {
        pinnedStrategy: {
          status: "pinned",
          ref: { strategy_id: "STRATEGY-DEMO-PRODUCTION", strategy_version_id: "f6846f3d-1aa0-487a-88a1-c383ba9076ea" },
          strategy_id: "STRATEGY-DEMO-PRODUCTION",
          strategy_version_id: "f6846f3d-1aa0-487a-88a1-c383ba9076ea",
          version: 1,
          objective: "생산 우선순위를 확인합니다.",
          reviewQuestion: "우선순위를 조정할까요?",
        },
        approval: { state: "pending" },
        execution: { state: "none" },
        readback: { state: "none" },
        businessOutcome: { state: "unknown" },
        reviewRequired: true,
      },
    }];
    render(<TasksMode onBack={vi.fn()} />);

    const runtimeTitle = await screen.findByText("가상 ERP 생산 우선순위 변경");
    expect(await screen.findByText("동일 UUID의 레거시 작업")).toBeInTheDocument();
    const strategyFilter = screen.getByLabelText("전략 버전 필터");
    expect(within(strategyFilter).getByRole("option", { name: "STRATEGY-DEMO-PRODUCTION · 고정 버전" })).toHaveValue(
      "f6846f3d-1aa0-487a-88a1-c383ba9076ea",
    );
    const runtimeCard = runtimeTitle.closest<HTMLElement>("[role='button']");
    expect(runtimeCard).not.toBeNull();
    await waitFor(() => {
      expect(fromMock.mock.calls.filter(([table]) => table !== "tasks")).toHaveLength(8);
    });
    const detailQueryCount = fromMock.mock.calls.length;
    fireEvent.click(runtimeCard!);

    const runtimeDetail = await screen.findByLabelText("런타임 소유 작업 상세");
    expect(screen.getByLabelText("Workboard 계보")).toHaveAttribute("data-origin-task", "9e650d6d-9e9f-4a09-b041-e345d16620a8");
    expect(runtimeDetail).toHaveTextContent("읽기 전용");
    expect(runtimeDetail).toHaveTextContent("사업 결과 미관찰");
    expect(within(runtimeCard!).getByText("고정 전략 v1")).toBeInTheDocument();
    expect(within(runtimeCard!).getByText("승인 대기")).toBeInTheDocument();
    expect(within(runtimeCard!).getByText("실행 전")).toBeInTheDocument();
    expect(within(runtimeCard!).getByText("사업 결과 미관찰")).toBeInTheDocument();
    expect(within(runtimeCard!).queryByRole("button", { name: "작업 수정" })).not.toBeInTheDocument();
    expect(within(runtimeCard!).queryByRole("button", { name: "작업 삭제" })).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "승인 기록" })).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "결과 적용" })).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "증거 추가" })).not.toBeInTheDocument();
    expect(fromMock).toHaveBeenCalledTimes(detailQueryCount);

    const legacyTitle = screen.getByText("동일 UUID의 레거시 작업");
    const legacyCard = legacyTitle.closest<HTMLElement>("[role='button']");
    expect(legacyCard).not.toBeNull();
    fireEvent.click(within(legacyCard!).getByRole("button", { name: "작업 수정" }));
    fireEvent.click(screen.getByRole("button", { name: "수정" }));

    await waitFor(() => {
      expect(repositoryMutationInputs).toContainEqual({
        kind: "edit",
        origin: "legacy",
        sourceId: "9e650d6d-9e9f-4a09-b041-e345d16620a8",
        viewKey: "legacy:9e650d6d-9e9f-4a09-b041-e345d16620a8",
      });
    });
  });

  it("clears database loading states when query chains return bare thenables", async () => {
    useBarePromiseLikeQueries = true;

    render(<TasksMode onBack={vi.fn()} />);

    const timeline = await screen.findByLabelText("작업 이벤트 타임라인");
    const evidence = await screen.findByLabelText("결과와 증거");
    const resultIntake = await screen.findByLabelText("Codex 결과 Intake");

    await waitFor(() => {
      expect(within(timeline).getByText("이벤트 0개")).toBeInTheDocument();
      expect(within(evidence).getByText("증거 0개")).toBeInTheDocument();
      expect(within(resultIntake).getByText("붙여넣기 대기")).toBeInTheDocument();
    });

    fireEvent.click(await screen.findByText("staging DB migration 실행"));
    const approvalGate = await screen.findByLabelText("승인 게이트");
    await waitFor(() => {
      expect(within(approvalGate).getByText("승인 필요")).toBeInTheDocument();
    });
  });

  it("updates the Gateway judgment when another task is selected", async () => {
    render(<TasksMode onBack={vi.fn()} />);

    fireEvent.click(await screen.findByText("고객 납기 문의 답장"));

    expect(screen.getByText("고객 답장 초안")).toBeInTheDocument();
    expect(screen.getAllByText("답장 초안").length).toBeGreaterThan(0);
    expect(screen.getByText("외부 메시지 발송 금지")).toBeInTheDocument();
  });

  it("filters demo tasks by pinned strategy version and labels legacy tasks as unlinked", async () => {
    const strategyRows = createDemoStrategyRows();
    taskRows.push(...strategyRows.tasks.map((row) => ({ ...row })));
    evidenceRows.push(...strategyRows.evidence);
    eventRows.push(...strategyRows.events);
    resultRows.push(...strategyRows.results);

    render(<TasksMode onBack={vi.fn()} />);

    expect((await screen.findAllByText("전략 미연결")).length).toBeGreaterThan(0);
    fireEvent.change(screen.getByLabelText("전략 버전 필터"), {
      target: { value: "delivery-risk-early-warning-v1" },
    });
    expect(screen.getByLabelText("전략 버전 필터")).toHaveValue("delivery-risk-early-warning-v1");

    const taskList = screen.getByLabelText("작업 목록");
    expect((await within(taskList).findAllByText("가상한빛모빌리티 주문의 납기 지연 위험을 확인해줘")).length).toBeGreaterThan(0);
    await waitFor(() => {
      expect(within(taskList).queryAllByText("가상새봄부품 주문의 납기 지연 위험을 확인해줘")).toHaveLength(0);
    });

    fireEvent.change(screen.getByLabelText("전략 버전 필터"), {
      target: { value: "delivery-risk-early-warning-v2" },
    });
    expect((await within(taskList).findAllByText("가상새봄부품 주문의 납기 지연 위험을 확인해줘")).length).toBeGreaterThan(0);
    await waitFor(() => {
      expect(within(taskList).queryAllByText("가상한빛모빌리티 주문의 납기 지연 위험을 확인해줘")).toHaveLength(0);
    });
  });

  it("shows and selects a newly created unlinked follow-up from an active strategy filter", async () => {
    const strategyRows = createDemoStrategyRows();
    taskRows.push(...strategyRows.tasks.map((row) => ({ ...row })));
    resultRows.push(...strategyRows.results);

    render(<TasksMode onBack={vi.fn()} initialTaskId="demo-strategy-task-v1-completed" />);

    const strategyFilter = await screen.findByLabelText("전략 버전 필터");
    fireEvent.change(strategyFilter, {
      target: { value: "delivery-risk-early-warning-v1" },
    });
    fireEvent.click(await screen.findByRole("button", { name: "후속 작업 만들기" }));

    const taskList = screen.getByLabelText("작업 목록");
    const followUpTitle = "후속: 현재 납기 일정을 유지하며 다음 가상 신호를 확인합니다.";
    const followUpCard = (await within(taskList).findByText(followUpTitle)).closest<HTMLElement>("[role='button']");
    expect(followUpCard).not.toBeNull();
    expect(followUpCard).toHaveAttribute("aria-pressed", "true");
    expect(within(followUpCard!).getByText("전략 미연결")).toBeInTheDocument();
    expect(strategyFilter).toHaveValue("all");
    expect(await screen.findByText("Gateway 후속 작업")).toBeInTheDocument();
  });

  it("shows and selects an existing unlinked follow-up from an active strategy filter", async () => {
    const strategyRows = createDemoStrategyRows();
    const originTask = strategyRows.tasks[0];
    const followUpTitle = "후속: 현재 납기 일정을 유지하며 다음 가상 신호를 확인합니다.";
    taskRows.push(
      ...strategyRows.tasks.map((row) => ({ ...row })),
      {
        id: "demo-strategy-task-v1-follow-up",
        title: followUpTitle,
        description: [
          `원 작업: ${originTask.title}`,
          "Codex 후속 액션: 현재 납기 일정을 유지하며 다음 가상 신호를 확인합니다.",
        ].join("\n"),
        source: "gateway",
        source_id: `follow-up-${originTask.source_id}`,
        severity: "medium",
        customer: originTask.customer,
        category: originTask.category,
        status: "pending",
        created_at: "2026-09-17T09:40:00.000Z",
      },
    );
    resultRows.push(...strategyRows.results);

    render(<TasksMode onBack={vi.fn()} initialTaskId="demo-strategy-task-v1-completed" />);

    const strategyFilter = await screen.findByLabelText("전략 버전 필터");
    fireEvent.change(strategyFilter, {
      target: { value: "delivery-risk-early-warning-v1" },
    });
    const taskList = screen.getByLabelText("작업 목록");
    await waitFor(() => {
      expect(within(taskList).queryByText(followUpTitle)).not.toBeInTheDocument();
    });

    fireEvent.click(await screen.findByRole("button", { name: "후속 작업 보기" }));

    const followUpCard = (await within(taskList).findByText(followUpTitle)).closest<HTMLElement>("[role='button']");
    expect(followUpCard).not.toBeNull();
    expect(followUpCard).toHaveAttribute("aria-pressed", "true");
    expect(within(followUpCard!).getByText("전략 미연결")).toBeInTheDocument();
    expect(strategyFilter).toHaveValue("all");
    expect(await screen.findByText("Gateway 후속 작업")).toBeInTheDocument();
    expect(taskRows.filter((row) => row.source_id === `follow-up-${originTask.source_id}`)).toHaveLength(1);
  });

  it.each(["staging", "production"])("keeps strategy fixtures out of the %s Workboard UI boundary", async (mode) => {
    vi.stubEnv("VITE_APP_MODE", mode);
    const strategyRows = createDemoStrategyRows();
    taskRows.push(...strategyRows.tasks.map((row) => ({ ...row })));

    render(<TasksMode onBack={vi.fn()} initialTaskId="demo-strategy-task-v1-completed" />);

    await screen.findByLabelText("작업 목록");
    expect(screen.queryByLabelText("전략 버전 필터")).not.toBeInTheDocument();
    expect(screen.queryByLabelText("연결된 전략")).not.toBeInTheDocument();
    expect(screen.queryByText("전략 미연결")).not.toBeInTheDocument();
  });

  it("uses the preserved intake packet after the Workboard title changes", async () => {
    const strategyRows = createDemoStrategyRows();
    taskRows.push({
      ...strategyRows.tasks[0],
      title: "사람이 바꾼 Workboard 제목",
      description: "수정된 설명에서 원 요청을 재구성하면 안 됩니다.",
    });
    evidenceRows.push(...strategyRows.evidence);
    eventRows.push(...strategyRows.events);
    resultRows.push(...strategyRows.results);

    render(<TasksMode onBack={vi.fn()} initialTaskId="demo-strategy-task-v1-completed" />);

    expect(await screen.findByLabelText("연결된 전략")).toHaveTextContent("납기 위험 조기 확인");
    expect(screen.getByLabelText("연결된 전략")).toHaveTextContent("v1");
    expect(screen.getByLabelText("보존된 원 요청")).toHaveTextContent("가상한빛모빌리티 주문의 납기 지연 위험을 확인해줘");
    expect(screen.getByLabelText("보존된 원 요청")).not.toHaveTextContent("사람이 바꾼 Workboard 제목");
  });

  it("distinguishes the preserved intake status from the current Workboard status", async () => {
    const strategyRows = createDemoStrategyRows();
    taskRows.push({ ...strategyRows.tasks[0] });

    render(<TasksMode onBack={vi.fn()} initialTaskId="demo-strategy-task-v1-completed" />);

    const statusSummary = await screen.findByLabelText("전략 작업 상태");
    expect(statusSummary).toHaveTextContent("접수 시 상태접수됨");
    expect(statusSummary).toHaveTextContent("현재 Workboard 상태완료");
  });

  it("fails closed when required demo intake metadata is corrupt", async () => {
    const strategyRows = createDemoStrategyRows();
    taskRows.push({
      ...strategyRows.tasks[1],
      id: "corrupt-strategy-task",
      demo_intake_packet: { task_id: "broken" },
    });

    render(<TasksMode onBack={vi.fn()} initialTaskId="corrupt-strategy-task" />);

    expect(await screen.findByLabelText("Gateway 접수 packet 검토 필요")).toHaveTextContent("검토 필요");
    expect(screen.queryByLabelText("Codex 전달문 미리보기")).not.toBeInTheDocument();
    expect(screen.queryByLabelText("결과와 증거")).not.toBeInTheDocument();
    expect(screen.queryByRole("button", { name: "결과 적용" })).not.toBeInTheDocument();
  });

  it("marks every present but invalid demo intake shape for review and excludes it from unlinked tasks", async () => {
    const strategyRows = createDemoStrategyRows();
    const baseTask = strategyRows.tasks[1];
    const missingMarkerTask: Record<string, unknown> = {
      ...baseTask,
      id: "missing-marker-strategy-task",
      title: "표시가 누락된 전략 작업",
    };
    delete missingMarkerTask.demo_intake_required;
    const invalidTasks = [
      missingMarkerTask,
      {
        ...baseTask,
        id: "false-marker-strategy-task",
        title: "표시가 손상된 전략 작업",
        demo_intake_required: false,
      },
      {
        ...baseTask,
        id: "corrupt-packet-strategy-task",
        title: "packet이 손상된 전략 작업",
        demo_intake_packet: { task_id: "broken" },
      },
    ];
    taskRows.push(...invalidTasks);

    render(<TasksMode onBack={vi.fn()} />);

    const taskList = await screen.findByLabelText("작업 목록");
    for (const task of invalidTasks) {
      const title = String(task.title);
      const card = within(taskList).getByText(title).closest<HTMLElement>("[role='button']");
      expect(card).not.toBeNull();
      expect(within(card!).getByText("검토 필요")).toBeInTheDocument();
      expect(within(card!).queryByText("전략 미연결")).not.toBeInTheDocument();
      expect(within(card!).queryByRole("button", { name: "진행" })).not.toBeInTheDocument();
      expect(within(card!).queryByRole("button", { name: "완료" })).not.toBeInTheDocument();
    }

    fireEvent.change(screen.getByLabelText("전략 버전 필터"), {
      target: { value: "unlinked" },
    });
    await waitFor(() => {
      invalidTasks.forEach((task) => {
        expect(within(taskList).queryByText(String(task.title))).not.toBeInTheDocument();
      });
    });
  });

  it("loads strategy evidence only when both Workboard and packet ids match", async () => {
    const strategyRows = createDemoStrategyRows();
    const v1Task = strategyRows.tasks[0];
    taskRows.push({ ...v1Task });
    evidenceRows.push(...strategyRows.evidence, {
      ...strategyRows.evidence[0],
      id: "cross-packet-evidence",
      evidence_id: "cross-packet-evidence",
      packet_task_id: "another-packet",
      summary: "다른 packet에서 섞이면 안 되는 증거",
    });
    eventRows.push(...strategyRows.events);
    resultRows.push(...strategyRows.results);

    render(<TasksMode onBack={vi.fn()} initialTaskId={v1Task.id} />);

    const evidenceList = await screen.findByLabelText("증거 목록");
    expect(evidenceList).toHaveTextContent("가상 주문 VSO-1001은 출하 준비 상태입니다.");
    expect(evidenceList).toHaveTextContent("가상 출하 계획은 고객 납기 전에 도착하는 일정입니다.");
    expect(evidenceList).toHaveTextContent("가상 주문의 현재 납기 지연 위험은 낮음으로 평가했습니다.");
    expect(screen.queryByText("다른 packet에서 섞이면 안 되는 증거")).not.toBeInTheDocument();
  });

  it("keeps the original Gateway packet id when a Gateway-created task is selected", async () => {
    render(<TasksMode onBack={vi.fn()} />);

    const gatewayTitle = await screen.findByText("현대자동차 GA 강판 긴급재 위험도 따져줘");
    const gatewayCard = gatewayTitle.closest<HTMLElement>("[role='button']");
    expect(gatewayCard).not.toBeNull();
    expect(within(gatewayCard!).getByText("Gateway")).toBeInTheDocument();
    const gatewayCardSignals = within(gatewayCard!).getByLabelText("현대자동차 GA 강판 긴급재 위험도 따져줘 Gateway 판단 신호");
    expect(gatewayCardSignals).toHaveTextContent("업무 긴급재 리스크 평가");
    expect(gatewayCardSignals).toHaveTextContent("위험도 보통");

    fireEvent.click(gatewayCard!);

    expect(await screen.findByText("Gateway에서 생성됨")).toBeInTheDocument();
    expect(screen.getByText("긴급재 리스크 평가")).toBeInTheDocument();
    expect(screen.getByLabelText("Codex 전달문 미리보기")).toHaveTextContent(
      "task-urgent_material_risk_assessment-20260704",
    );
  });

  it("creates manually entered inventory tasks as Gateway workboard packets", async () => {
    const strategyRows = createDemoStrategyRows();
    taskRows.push(...strategyRows.tasks.map((row) => ({ ...row })));
    render(<TasksMode onBack={vi.fn()} initialTaskId="demo-strategy-task-v1-completed" />);

    const strategyFilter = await screen.findByLabelText("전략 버전 필터");
    fireEvent.change(strategyFilter, {
      target: { value: "delivery-risk-early-warning-v1" },
    });
    fireEvent.click(screen.getByRole("button", { name: "새 작업" }));
    fireEvent.change(screen.getByPlaceholderText("제목 *"), {
      target: { value: "GA 강판 재고 확인" },
    });
    fireEvent.change(screen.getByPlaceholderText("설명 (선택)"), {
      target: { value: "울산 창고 가용 재고 확인 필요" },
    });
    fireEvent.change(screen.getByPlaceholderText("고객사"), {
      target: { value: "기아" },
    });
    fireEvent.click(screen.getByRole("button", { name: "생성" }));

    await waitFor(() => {
      expect(taskRows.some((row) => row.title === "GA 강판 재고 확인")).toBe(true);
    });
    const createdTask = taskRows.find((row) => row.title === "GA 강판 재고 확인");
    expect(createdTask).toMatchObject({
      source: "gateway",
      customer: "기아",
      category: "delivery",
      severity: "medium",
      status: "pending",
    });
    expect(String(createdTask?.source_id)).toMatch(/^workboard-/);
    expect(String(createdTask?.description)).toContain("Gateway task type: inventory_check");
    expect(String(createdTask?.description)).toContain("Gateway packet id: workboard-");
    expect(String(createdTask?.description)).toContain("재고 예약 금지");

    const createdCard = (await within(screen.getByLabelText("작업 목록"))
      .findByText("GA 강판 재고 확인")).closest<HTMLElement>("[role='button']");
    expect(createdCard).not.toBeNull();
    expect(createdCard).toHaveAttribute("aria-pressed", "true");
    expect(strategyFilter).toHaveValue("all");

    await waitFor(() => {
      expect(eventRows).toEqual(expect.arrayContaining([
        expect.objectContaining({
          task_id: createdTask?.id,
          packet_task_id: createdTask?.source_id,
          event_type: "accepted",
          message: "작업 메뉴에서 Gateway 작업이 생성되었습니다.",
        }),
      ]));
    });
  });

  it("previews Gateway judgment while creating a manual workboard task", async () => {
    render(<TasksMode onBack={vi.fn()} />);

    fireEvent.click(screen.getByRole("button", { name: "새 작업" }));
    fireEvent.change(screen.getByPlaceholderText("제목 *"), {
      target: { value: "GA 강판 재고 확인" },
    });
    fireEvent.change(screen.getByPlaceholderText("설명 (선택)"), {
      target: { value: "울산 창고 가용 재고 확인 필요" },
    });

    const preview = await screen.findByLabelText("새 작업 Gateway 판단 미리보기");

    expect(within(preview).getByText("재고 확인")).toBeInTheDocument();
    expect(within(preview).getByText("위험도 보통")).toBeInTheDocument();
    expect(within(preview).getByText("승인 불필요")).toBeInTheDocument();
    expect(within(preview).getByText("재고 상태")).toBeInTheDocument();
    expect(within(preview).getByText("수동 검토")).toBeInTheDocument();
    expect(within(preview).getByText("재고 예약 금지")).toBeInTheDocument();
  });

  it("selects the requested task when opened from the Gateway next action", async () => {
    render(<TasksMode onBack={vi.fn()} initialTaskId="task-gateway-1" />);

    expect(await screen.findByText("Gateway에서 생성됨")).toBeInTheDocument();
    expect(screen.getByText("긴급재 리스크 평가")).toBeInTheDocument();
    expect(screen.getByLabelText("Codex 전달문 미리보기")).toHaveTextContent(
      "task-urgent_material_risk_assessment-20260704",
    );
  });

  it("shows and copies the expected Codex result format for the selected task", async () => {
    render(<TasksMode onBack={vi.fn()} />);

    const guide = await screen.findByLabelText("Codex 결과 형식 안내");

    expect(guide).toHaveTextContent("## Conclusion");
    expect(guide).toHaveTextContent("주문/오더 상태와 기준 시스템");
    expect(guide).toHaveTextContent("납기, 출하, ETA 상태");
    expect(guide).toHaveTextContent("리스크 수준과 판단 근거");

    fireEvent.click(screen.getByRole("button", { name: "형식 복사" }));

    expect(writeText).toHaveBeenCalledWith(expect.stringContaining("## Evidence"));
    expect(writeText).toHaveBeenCalledWith(expect.stringContaining("## Next Action"));
  });

  it("surfaces saved Codex follow-up signals on task cards", async () => {
    resultRows.push({
      id: "result-existing",
      owner_id: "user-1",
      task_id: "task-1",
      packet_task_id: "workboard-task-1",
      outcome: "blocked",
      summary: "The task is blocked because the latest warehouse export is missing.",
      details: null,
      changed_paths: [],
      checked_refs: [],
      risks: [],
      blockers: [{
        blocker_id: "workboard-task-1-blocker-1",
        type: "missing_context",
        summary: "Missing latest warehouse export from operations.",
        requires_user_action: true,
      }],
      next_action: "Ask operations for the latest warehouse export.",
      retention_decision: null,
      created_at: "2026-07-04T00:10:00.000Z",
    });

    render(<TasksMode onBack={vi.fn()} />);

    const taskTitle = (await screen.findAllByText("3월 납기 지연 리스크"))[0];
    const taskCard = taskTitle.closest<HTMLElement>("[role='button']");
    expect(taskCard).not.toBeNull();

    const followUp = await within(taskCard!).findByRole("button", { name: "3월 납기 지연 리스크 후속 액션 보기" });
    expect(within(followUp).getByText(/보류: Missing latest warehouse export from operations/)).toBeInTheDocument();
    expect(within(followUp).getByText("확인 필요")).toBeInTheDocument();

    fireEvent.click(followUp);

    await waitFor(() => {
      expect(scrollIntoView).toHaveBeenCalledWith({ behavior: "smooth", block: "start" });
    });
    expect(await screen.findByLabelText("작업 후속 액션")).toHaveClass("ring-primary/25");
  });

  it("creates a pending workboard task from a Codex follow-up action", async () => {
    resultRows.push({
      id: "result-existing",
      owner_id: "user-1",
      task_id: "task-1",
      packet_task_id: "workboard-task-1",
      outcome: "blocked",
      summary: "The task is blocked because the latest warehouse export is missing.",
      details: null,
      changed_paths: [],
      checked_refs: [],
      risks: [],
      blockers: [{
        blocker_id: "workboard-task-1-blocker-1",
        type: "missing_context",
        summary: "Missing latest warehouse export from operations.",
        requires_user_action: true,
      }],
      next_action: "Ask operations for the latest warehouse export.",
      retention_decision: null,
      created_at: "2026-07-04T00:10:00.000Z",
    });

    render(<TasksMode onBack={vi.fn()} />);

    const taskTitle = (await screen.findAllByText("3월 납기 지연 리스크"))[0];
    const taskCard = taskTitle.closest<HTMLElement>("[role='button']");
    expect(taskCard).not.toBeNull();

    fireEvent.click(await within(taskCard!).findByRole("button", { name: "3월 납기 지연 리스크 후속 액션 보기" }));
    const followUp = await screen.findByLabelText("작업 후속 액션");
    fireEvent.click(within(followUp).getByRole("button", { name: "후속 작업 만들기" }));

    await waitFor(() => {
      expect(taskRows).toContainEqual(expect.objectContaining({
        title: "후속: Ask operations for the latest warehouse export.",
        description: expect.stringContaining("Codex 후속 액션: Ask operations for the latest warehouse export."),
        source: "gateway",
        source_id: "follow-up-workboard-task-1",
        status: "pending",
        severity: "critical",
      }));
    });
    expect((await screen.findAllByText("후속: Ask operations for the latest warehouse export.")).length).toBeGreaterThan(0);
    expect(await screen.findByText("Gateway 후속 작업")).toBeInTheDocument();
    const lineage = await screen.findByLabelText("작업 파생 관계");
    expect(within(lineage).getByText("3월 납기 지연 리스크")).toBeInTheDocument();
    expect(within(lineage).getByText("Ask operations for the latest warehouse export.")).toBeInTheDocument();
    await waitFor(() => {
      expect(eventRows.some((row) => (
        row.task_id === "task-1" &&
        row.event_type === "progress" &&
        String(row.message).includes("후속 작업이 생성되었습니다")
      ))).toBe(true);
    });
  });

  it("starts blocker resolution evidence entry from a saved blocked result", async () => {
    resultRows.push({
      id: "result-existing",
      owner_id: "user-1",
      task_id: "task-1",
      packet_task_id: "workboard-task-1",
      outcome: "blocked",
      summary: "The task is blocked because the latest warehouse export is missing.",
      details: null,
      changed_paths: [],
      checked_refs: [],
      risks: [],
      blockers: [{
        blocker_id: "workboard-task-1-blocker-1",
        type: "missing_context",
        summary: "Missing latest warehouse export from operations.",
        suggested_resolution: "Ask operations for the latest warehouse export.",
        requires_user_action: true,
      }],
      next_action: "Ask operations for the latest warehouse export.",
      retention_decision: null,
      created_at: "2026-07-04T00:10:00.000Z",
    });

    render(<TasksMode onBack={vi.fn()} />);

    const followUp = await screen.findByLabelText("작업 후속 액션");
    scrollIntoView.mockClear();
    fireEvent.click(within(followUp).getByRole("button", { name: "해결 증거 추가" }));

    await waitFor(() => {
      expect(scrollIntoView).toHaveBeenCalledWith({ behavior: "smooth", block: "start" });
    });
    expect(screen.getByLabelText("결과와 증거")).toHaveClass("ring-primary/25");
    expect(screen.getByLabelText("증거 출처")).toHaveValue("user");
    expect(screen.getByLabelText("증거 상태")).toHaveValue("passed");
    expect(screen.getByLabelText("증거 요약")).toHaveValue("");
    expect(screen.getByLabelText("짧은 원문")).toHaveValue([
      "Blocker: Missing latest warehouse export from operations.",
      "Suggested resolution: Ask operations for the latest warehouse export.",
    ].join("\n"));

    fireEvent.change(screen.getByLabelText("증거 요약"), {
      target: { value: "운영팀 최신 warehouse export 수령 확인" },
    });
    fireEvent.click(screen.getByRole("button", { name: "증거 추가" }));

    await waitFor(() => {
      expect(evidenceRows).toHaveLength(1);
    });
    expect(evidenceRows[0]).toMatchObject({
      task_id: "task-1",
      packet_task_id: "workboard-task-1",
      source_system: "user",
      status: "passed",
      raw_excerpt: expect.stringContaining("Blocker: Missing latest warehouse export from operations."),
    });
  });

  it("starts reverification after blocker resolution evidence is saved", async () => {
    resultRows.push({
      id: "result-existing",
      owner_id: "user-1",
      task_id: "task-1",
      packet_task_id: "workboard-task-1",
      outcome: "blocked",
      summary: "The task is blocked because the latest warehouse export is missing.",
      details: null,
      changed_paths: [],
      checked_refs: [],
      risks: [],
      blockers: [{
        blocker_id: "workboard-task-1-blocker-1",
        type: "missing_context",
        summary: "Missing latest warehouse export from operations.",
        suggested_resolution: "Ask operations for the latest warehouse export.",
        requires_user_action: true,
      }],
      next_action: "Ask operations for the latest warehouse export.",
      retention_decision: null,
      created_at: "2026-07-04T00:10:00.000Z",
    });

    render(<TasksMode onBack={vi.fn()} />);

    const followUp = await screen.findByLabelText("작업 후속 액션");
    const reverifyButton = within(followUp).getByRole("button", { name: "재검증 시작" });
    expect(reverifyButton).toBeDisabled();

    fireEvent.click(within(followUp).getByRole("button", { name: "해결 증거 추가" }));
    fireEvent.change(screen.getByLabelText("증거 요약"), {
      target: { value: "운영팀 최신 warehouse export 수령 확인" },
    });
    fireEvent.click(screen.getByRole("button", { name: "증거 추가" }));

    await waitFor(() => {
      expect(evidenceRows).toHaveLength(1);
    });
    await waitFor(() => {
      expect(reverifyButton).not.toBeDisabled();
    });

    fireEvent.click(reverifyButton);

    await waitFor(() => {
      expect(taskUpdatePayloads).toEqual([
        expect.objectContaining({ status: "in_progress" }),
      ]);
    });
    await waitFor(() => {
      expect(eventRows.some((row) => (
        row.task_id === "task-1" &&
        row.packet_task_id === "workboard-task-1" &&
        row.event_type === "verification_started" &&
        String(row.message).includes("재검증")
      ))).toBe(true);
    });
    expect(eventRows.some((row) => row.event_type === "completed")).toBe(false);
  });

  it("includes previous blockers and new evidence in the copied reverification handoff", async () => {
    resultRows.push({
      id: "result-existing",
      owner_id: "user-1",
      task_id: "task-1",
      packet_task_id: "workboard-task-1",
      outcome: "blocked",
      summary: "The task is blocked because the latest warehouse export is missing.",
      details: null,
      changed_paths: [],
      checked_refs: [],
      risks: [],
      blockers: [{
        blocker_id: "workboard-task-1-blocker-1",
        type: "missing_context",
        summary: "Missing latest warehouse export from operations.",
        suggested_resolution: "Ask operations for the latest warehouse export.",
        requires_user_action: true,
      }],
      next_action: "Ask operations for the latest warehouse export.",
      retention_decision: null,
      created_at: "2026-07-04T00:10:00.000Z",
    });
    evidenceRows.push({
      id: "evidence-existing",
      owner_id: "user-1",
      task_id: "task-1",
      packet_task_id: "workboard-task-1",
      evidence_id: "workboard-task-1-evidence-1",
      evidence_type: "manual_observation",
      summary: "운영팀 최신 warehouse export 수령 확인",
      source_system: "user",
      source_url: null,
      source_path: null,
      source_command: null,
      source_ref: null,
      status: "passed",
      raw_excerpt: "Blocker: Missing latest warehouse export from operations.",
      artifact_path: null,
      created_at: "2026-07-04T00:20:00.000Z",
    });

    render(<TasksMode onBack={vi.fn()} />);

    const preview = await screen.findByLabelText("Codex 전달문 미리보기");
    await waitFor(() => {
      expect(preview).toHaveTextContent("## Reverification Context");
    });
    expect(preview).toHaveTextContent("Previous worker result was blocked");
    expect(preview).toHaveTextContent("Missing latest warehouse export from operations.");
    expect(preview).toHaveTextContent("운영팀 최신 warehouse export 수령 확인");
    expect(preview).toHaveTextContent("## Result Format");

    fireEvent.click(screen.getByRole("button", { name: "전달문 복사" }));

    await waitFor(() => {
      expect(writeText).toHaveBeenCalled();
    });
    const copied = writeText.mock.calls[writeText.mock.calls.length - 1]?.[0] as string;
    expect(copied).toContain("## Reverification Context");
    expect(copied).toContain("### Previous Blockers");
    expect(copied).toContain("### New Evidence Since Blocked Result");
    expect(copied).toContain("운영팀 최신 warehouse export 수령 확인");
    expect(copied).not.toContain("Blocker: Missing latest warehouse export from operations.");
  });

  it("separates the latest Codex result from previous blocker history", async () => {
    resultRows.push(
      {
        id: "result-blocked",
        owner_id: "user-1",
        task_id: "task-1",
        packet_task_id: "workboard-task-1",
        outcome: "blocked",
        summary: "The task is blocked because the latest warehouse export is missing.",
        details: null,
        changed_paths: [],
        checked_refs: [],
        risks: [],
        blockers: [{
          blocker_id: "workboard-task-1-blocker-1",
          type: "missing_context",
          summary: "Missing latest warehouse export from operations.",
          suggested_resolution: "Ask operations for the latest warehouse export.",
          requires_user_action: true,
        }],
        next_action: "Ask operations for the latest warehouse export.",
        retention_decision: null,
        created_at: "2026-07-04T00:10:00.000Z",
      },
      {
        id: "result-passed",
        owner_id: "user-1",
        task_id: "task-1",
        packet_task_id: "workboard-task-1",
        outcome: "passed",
        summary: "Delivery risk cleared after the latest warehouse export was reviewed.",
        details: null,
        changed_paths: [],
        checked_refs: [],
        risks: [],
        blockers: [],
        next_action: "Monitor the shipment tomorrow.",
        retention_decision: null,
        created_at: "2026-07-04T00:30:00.000Z",
      },
    );

    render(<TasksMode onBack={vi.fn()} />);

    const taskTitle = (await screen.findAllByText("3월 납기 지연 리스크"))[0];
    const taskCard = taskTitle.closest<HTMLElement>("[role='button']");
    expect(taskCard).not.toBeNull();

    await waitFor(() => {
      expect(within(taskCard!).getByText("최신 통과")).toBeInTheDocument();
    });
    expect(within(taskCard!).getByText("이전 blocker 1")).toBeInTheDocument();

    const intake = await screen.findByLabelText("Codex 결과 Intake");
    await waitFor(() => {
      expect(within(intake).getByText("최신 결과")).toBeInTheDocument();
    });
    expect(within(intake).getAllByText("통과").length).toBeGreaterThan(0);
    expect(within(intake).getByText("Delivery risk cleared after the latest warehouse export was reviewed.")).toBeInTheDocument();
    expect(within(intake).getByText("최신 blocker 0개")).toBeInTheDocument();
    expect(within(intake).getByLabelText("이전 blocker 기록")).toBeInTheDocument();
    expect(within(intake).getByText("이전 결과 · 보류")).toBeInTheDocument();
    expect(within(intake).getByText(/Missing latest warehouse export from operations/)).toBeInTheDocument();
  });

  it("shows follow-up lineage and opens the origin task", async () => {
    taskRows.push({
      id: "task-follow-up-1",
      title: "후속: Ask operations for the latest warehouse export.",
      description: [
        "원 작업: 3월 납기 지연 리스크",
        "Codex 후속 액션: Ask operations for the latest warehouse export.",
        "Blocker: Missing latest warehouse export from operations.",
      ].join("\n"),
      source: "gateway",
      source_id: "follow-up-workboard-task-1",
      severity: "critical",
      customer: "현대자동차",
      category: "delivery",
      status: "pending",
      created_at: "2026-07-04T00:20:00.000Z",
    });

    render(<TasksMode onBack={vi.fn()} initialTaskId="task-follow-up-1" />);

    const taskTitle = (await screen.findAllByText("후속: Ask operations for the latest warehouse export."))[0];
    const taskCard = taskTitle.closest<HTMLElement>("[role='button']");
    expect(taskCard).not.toBeNull();
    expect(within(taskCard!).getByText("파생")).toBeInTheDocument();
    expect(within(taskCard!).getByLabelText("후속: Ask operations for the latest warehouse export. 파생 원 작업")).toHaveTextContent(
      "3월 납기 지연 리스크",
    );

    expect(await screen.findByText("Gateway 후속 작업")).toBeInTheDocument();
    const lineage = await screen.findByLabelText("작업 파생 관계");
    expect(within(lineage).getByText("3월 납기 지연 리스크")).toBeInTheDocument();
    expect(within(lineage).getByText("Ask operations for the latest warehouse export.")).toBeInTheDocument();

    fireEvent.click(within(lineage).getByRole("button", { name: "원 작업 보기" }));

    await waitFor(() => {
      expect(screen.queryByLabelText("작업 파생 관계")).not.toBeInTheDocument();
    });
    expect(screen.getByText("납기 지연 리스크 확인")).toBeInTheDocument();
  });

  it("shows and selects a linked origin from the unlinked strategy filter", async () => {
    const strategyRows = createDemoStrategyRows();
    const originTask = strategyRows.tasks[0];
    const followUpTitle = "후속: 현재 납기 일정을 유지하며 다음 가상 신호를 확인합니다.";
    taskRows.push(
      ...strategyRows.tasks.map((row) => ({ ...row })),
      {
        id: "demo-strategy-task-v1-follow-up",
        title: followUpTitle,
        description: [
          `원 작업: ${originTask.title}`,
          "Codex 후속 액션: 현재 납기 일정을 유지하며 다음 가상 신호를 확인합니다.",
        ].join("\n"),
        source: "gateway",
        source_id: `follow-up-${originTask.source_id}`,
        severity: "medium",
        customer: originTask.customer,
        category: originTask.category,
        status: "pending",
        created_at: "2026-09-17T09:40:00.000Z",
      },
    );

    render(<TasksMode onBack={vi.fn()} initialTaskId="demo-strategy-task-v1-follow-up" />);

    const lineage = await screen.findByLabelText("작업 파생 관계");
    const strategyFilter = screen.getByLabelText("전략 버전 필터");
    fireEvent.change(strategyFilter, { target: { value: "unlinked" } });
    expect(await within(screen.getByLabelText("작업 목록")).findByText(followUpTitle)).toBeInTheDocument();

    fireEvent.click(within(lineage).getByRole("button", { name: "원 작업 보기" }));

    const originCard = (await within(screen.getByLabelText("작업 목록"))
      .findByText(String(originTask.title), { selector: "h3" })).closest<HTMLElement>("[role='button']");
    expect(originCard).not.toBeNull();
    expect(originCard).toHaveAttribute("aria-pressed", "true");
    expect(strategyFilter).toHaveValue("all");
    expect(await screen.findByLabelText("연결된 전략")).toHaveTextContent("v1");
  });

  it("filters the workboard to follow-up and blocked tasks", async () => {
    taskRows.push({
      id: "task-follow-up-1",
      title: "후속: Ask operations for the latest warehouse export.",
      description: [
        "원 작업: 3월 납기 지연 리스크",
        "Codex 후속 액션: Ask operations for the latest warehouse export.",
      ].join("\n"),
      source: "gateway",
      source_id: "follow-up-workboard-task-1",
      severity: "critical",
      customer: "현대자동차",
      category: "delivery",
      status: "pending",
      created_at: "2026-07-04T00:20:00.000Z",
    });
    resultRows.push({
      id: "result-existing",
      owner_id: "user-1",
      task_id: "task-1",
      packet_task_id: "workboard-task-1",
      outcome: "blocked",
      summary: "The task is blocked because the latest warehouse export is missing.",
      details: null,
      changed_paths: [],
      checked_refs: [],
      risks: [],
      blockers: [{
        blocker_id: "workboard-task-1-blocker-1",
        type: "missing_context",
        summary: "Missing latest warehouse export from operations.",
        requires_user_action: true,
      }],
      next_action: "Ask operations for the latest warehouse export.",
      retention_decision: null,
      created_at: "2026-07-04T00:10:00.000Z",
    });

    render(<TasksMode onBack={vi.fn()} />);

    const list = await screen.findByLabelText("작업 목록");

    fireEvent.click(await screen.findByRole("button", { name: "후속 1" }));

    expect(within(list).getByText("후속: Ask operations for the latest warehouse export.")).toBeInTheDocument();
    await waitFor(() => {
      expect(within(list).queryByText("고객 납기 문의 답장")).not.toBeInTheDocument();
    });

    fireEvent.click(await screen.findByRole("button", { name: "보류 1" }));

    await waitFor(() => {
      expect(within(list).getByText("3월 납기 지연 리스크")).toBeInTheDocument();
      expect(within(list).queryByText("후속: Ask operations for the latest warehouse export.")).not.toBeInTheDocument();
    });
  });

  it("captures evidence and shows when the selected task can be completed", async () => {
    render(<TasksMode onBack={vi.fn()} />);

    expect(await screen.findByText("완료 전 증거 필요")).toBeInTheDocument();

    fireEvent.change(screen.getByLabelText("증거 요약"), {
      target: { value: "SO-1001은 출하 대기 상태로 확인됨" },
    });
    fireEvent.click(screen.getByRole("button", { name: "증거 추가" }));

    expect(await screen.findByText("SO-1001은 출하 대기 상태로 확인됨")).toBeInTheDocument();
    expect(screen.getByText("증거 1개")).toBeInTheDocument();
    expect(fromMock).toHaveBeenCalledWith("agent_evidence");

    fireEvent.change(screen.getByLabelText("증거 유형"), {
      target: { value: "delivery_schedule" },
    });
    fireEvent.change(screen.getByLabelText("증거 요약"), {
      target: { value: "납기 계획상 이번 주 금요일 ETA 유지" },
    });
    fireEvent.click(screen.getByRole("button", { name: "증거 추가" }));

    expect(await screen.findByText("증거 2개")).toBeInTheDocument();

    fireEvent.change(screen.getByLabelText("증거 유형"), {
      target: { value: "risk_assessment" },
    });
    fireEvent.change(screen.getByLabelText("증거 요약"), {
      target: { value: "잔여 버퍼가 있어 지연 리스크는 보통" },
    });
    fireEvent.click(screen.getByRole("button", { name: "증거 추가" }));

    expect(await screen.findByText("증거 3개")).toBeInTheDocument();
    expect(await screen.findByText("완료 가능")).toBeInTheDocument();
    expect(evidenceRows).toHaveLength(3);
    expect(evidenceRows[0]).toMatchObject({
      task_id: "task-1",
      packet_task_id: "workboard-task-1",
      evidence_type: "order_status",
      source_system: "user",
    });
    await waitFor(() => {
      expect(eventRows[0]).toMatchObject({
        task_id: "task-1",
        packet_task_id: "workboard-task-1",
        event_type: "evidence_added",
      });
    });
  });

  it("previews pasted Codex result evidence before persisting it", async () => {
    render(<TasksMode onBack={vi.fn()} />);

    expect(await screen.findByText("완료 전 증거 필요")).toBeInTheDocument();

    fireEvent.change(screen.getByLabelText("Codex 결과 붙여넣기"), {
      target: {
        value: [
          "## Conclusion",
          "Delivery risk is medium and can be monitored.",
          "",
          "## Evidence",
          "- [passed] Order SO-1001 is allocated and waiting for shipment.",
          "- [passed] Delivery ETA remains Friday.",
          "- [passed] Risk assessment: remaining buffer is acceptable.",
          "",
          "## Next Action",
          "Monitor the shipment tomorrow.",
        ].join("\n"),
      },
    });
    fireEvent.click(screen.getByRole("button", { name: "미리보기" }));

    const preview = await screen.findByLabelText("Codex 결과 적용 미리보기");
    expect(within(preview).getByText("적용 전 미리보기")).toBeInTheDocument();
    expect(within(preview).getByText("저장될 증거 3개")).toBeInTheDocument();
    expect(within(preview).getByText("blocker 0개")).toBeInTheDocument();
    expect(within(preview).getByText(/Order SO-1001 is allocated and waiting for shipment/)).toBeInTheDocument();
    expect(within(preview).getByText(/Delivery ETA remains Friday/)).toBeInTheDocument();
    expect(within(preview).getByText(/Risk assessment: remaining buffer is acceptable/)).toBeInTheDocument();
    expect(screen.getByText("다음: Monitor the shipment tomorrow.")).toBeInTheDocument();
    expect(resultRows).toHaveLength(0);
    expect(evidenceRows).toHaveLength(0);
    expect(eventRows).toHaveLength(0);
  });

  it("ingests a pasted Codex result into result, evidence, and event records", async () => {
    render(<TasksMode onBack={vi.fn()} />);

    expect(await screen.findByText("완료 전 증거 필요")).toBeInTheDocument();

    fireEvent.change(screen.getByLabelText("Codex 결과 붙여넣기"), {
      target: {
        value: [
          "## Conclusion",
          "Delivery risk is medium and can be monitored.",
          "",
          "## Evidence",
          "- [passed] Order SO-1001 is allocated and waiting for shipment.",
          "- [passed] Delivery ETA remains Friday.",
          "- [passed] Risk assessment: remaining buffer is acceptable.",
          "",
          "## Next Action",
          "Monitor the shipment tomorrow.",
        ].join("\n"),
      },
    });
    fireEvent.click(screen.getByRole("button", { name: "결과 적용" }));

    await waitFor(() => {
      expect(resultRows).toHaveLength(1);
      expect(resultRows[0]).toMatchObject({
        task_id: "task-1",
        packet_task_id: "workboard-task-1",
        outcome: "passed",
        summary: "Delivery risk is medium and can be monitored.",
        next_action: "Monitor the shipment tomorrow.",
      });
    });
    expect(evidenceRows.map((row) => row.evidence_type)).toEqual([
      "order_status",
      "delivery_schedule",
      "risk_assessment",
    ]);
    await waitFor(() => {
      expect(taskUpdatePayloads).toEqual([
        expect.objectContaining({ status: "done" }),
      ]);
    });
    const followUp = await screen.findByLabelText("작업 후속 액션");
    expect(within(followUp).getByText("다음 행동 대기")).toBeInTheDocument();
    expect(within(followUp).getByText("Monitor the shipment tomorrow.")).toBeInTheDocument();
    expect(await screen.findByText("완료 가능")).toBeInTheDocument();
    expect(screen.getAllByText("Delivery risk is medium and can be monitored.").length).toBeGreaterThan(0);
    await waitFor(() => {
      expect(eventRows.some((row) => row.event_type === "verification_passed")).toBe(true);
      expect(eventRows.some((row) => row.event_type === "evidence_added")).toBe(true);
      expect(eventRows.some((row) => row.event_type === "completed")).toBe(true);
    });
  });

  it("keeps blocked pasted Codex results in progress instead of completing", async () => {
    render(<TasksMode onBack={vi.fn()} />);

    expect(await screen.findByText("완료 전 증거 필요")).toBeInTheDocument();

    fireEvent.change(screen.getByLabelText("Codex 결과 붙여넣기"), {
      target: {
        value: [
          "## Conclusion",
          "The task is blocked because the latest warehouse export is missing.",
          "",
          "## Evidence",
          "- [passed] Order SO-1001 is allocated and waiting for shipment.",
          "- [passed] Delivery ETA remains Friday.",
          "- [warning] Risk assessment is blocked by stale export.",
          "",
          "## Blockers",
          "- Missing latest warehouse export from operations.",
          "",
          "## Next Action",
          "Ask operations for the latest warehouse export.",
        ].join("\n"),
      },
    });
    fireEvent.click(screen.getByRole("button", { name: "결과 적용" }));

    await waitFor(() => {
      expect(resultRows).toHaveLength(1);
      expect(resultRows[0]).toMatchObject({
        outcome: "blocked",
        summary: "The task is blocked because the latest warehouse export is missing.",
      });
    });
    await waitFor(() => {
      expect(taskUpdatePayloads).toEqual([
        expect.objectContaining({ status: "in_progress" }),
      ]);
    });
    const followUp = await screen.findByLabelText("작업 후속 액션");
    expect(within(followUp).getByText("보류 항목 확인")).toBeInTheDocument();
    expect(within(followUp).getByText("Missing latest warehouse export from operations.")).toBeInTheDocument();
    expect(within(followUp).getByText("Ask operations for the latest warehouse export.")).toBeInTheDocument();
    expect(within(followUp).getByText("사용자 확인 필요")).toBeInTheDocument();
    expect(taskUpdatePayloads.some((payload) => payload.status === "done")).toBe(false);
    await waitFor(() => {
      expect(eventRows.some((row) => row.event_type === "blocked")).toBe(true);
    });
    expect(eventRows.some((row) => row.event_type === "completed")).toBe(false);
  });

  it("blocks completion until the Gateway evidence gate passes", async () => {
    render(<TasksMode onBack={vi.fn()} />);

    expect(await screen.findByText("완료 전 증거 필요")).toBeInTheDocument();

    fireEvent.click(screen.getAllByRole("button", { name: "완료" })[0]);

    await waitFor(() => {
      expect(taskUpdatePayloads).toEqual([]);
    });
  });

  it("updates the workboard task to done after completion evidence is present", async () => {
    render(<TasksMode onBack={vi.fn()} />);

    expect(await screen.findByText("완료 전 증거 필요")).toBeInTheDocument();

    fireEvent.change(screen.getByLabelText("증거 요약"), {
      target: { value: "SO-1001은 출하 대기 상태로 확인됨" },
    });
    fireEvent.click(screen.getByRole("button", { name: "증거 추가" }));
    expect(await screen.findByText("증거 1개")).toBeInTheDocument();

    fireEvent.change(screen.getByLabelText("증거 유형"), {
      target: { value: "delivery_schedule" },
    });
    fireEvent.change(screen.getByLabelText("증거 요약"), {
      target: { value: "납기 계획상 이번 주 금요일 ETA 유지" },
    });
    fireEvent.click(screen.getByRole("button", { name: "증거 추가" }));
    expect(await screen.findByText("증거 2개")).toBeInTheDocument();

    fireEvent.change(screen.getByLabelText("증거 유형"), {
      target: { value: "risk_assessment" },
    });
    fireEvent.change(screen.getByLabelText("증거 요약"), {
      target: { value: "잔여 버퍼가 있어 지연 리스크는 보통" },
    });
    fireEvent.click(screen.getByRole("button", { name: "증거 추가" }));
    expect(await screen.findByText("증거 3개")).toBeInTheDocument();

    expect(await screen.findByText("완료 가능")).toBeInTheDocument();

    fireEvent.click(screen.getAllByRole("button", { name: "완료" })[0]);

    await waitFor(() => {
      expect(taskUpdatePayloads).toEqual([
        expect.objectContaining({ status: "done" }),
      ]);
    });
    await waitFor(() => {
      expect(eventRows.some((row) => row.event_type === "completed")).toBe(true);
    });
  });

  it("records approval before allowing an approval-gated task to start", async () => {
    render(<TasksMode onBack={vi.fn()} />);

    const approvalTitle = await screen.findByText("staging DB migration 실행");
    const approvalCard = approvalTitle.closest<HTMLElement>("[role='button']");
    expect(approvalCard).not.toBeNull();

    fireEvent.click(approvalCard!);

    expect(await screen.findByLabelText("승인 게이트")).toBeInTheDocument();
    expect(screen.getAllByText("승인 필요").length).toBeGreaterThan(0);

    fireEvent.click(within(approvalCard!).getByRole("button", { name: "진행" }));

    await waitFor(() => {
      expect(taskUpdatePayloads).toEqual([]);
    });

    fireEvent.click(screen.getByRole("button", { name: "승인 기록" }));

    await waitFor(() => {
      expect(approvalRows).toHaveLength(1);
      expect(approvalRows[0]).toMatchObject({
        task_id: "task-3",
        packet_task_id: "workboard-task-3",
        decision: "approved",
        action_type: "database_migration",
      });
    });
    await waitFor(() => {
      expect(eventRows.some((row) => row.event_type === "progress" && row.task_id === "task-3")).toBe(true);
    });

    fireEvent.click(within(approvalCard!).getByRole("button", { name: "진행" }));

    await waitFor(() => {
      expect(taskUpdatePayloads).toEqual([
        expect.objectContaining({ status: "in_progress" }),
      ]);
    });
    await waitFor(() => {
      expect(eventRows.some((row) => row.event_type === "started" && row.task_id === "task-3")).toBe(true);
    });
  });
});
