import { useMemo, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { demoStrategies, demoStrategyVersions } from "@/data/demoStrategyCatalog";
import {
  ArrowLeft,
  ArrowRight,
  Bot,
  CheckCircle2,
  Copy,
  FileJson,
  GitPullRequest,
  Plus,
  RotateCcw,
  ShieldAlert,
  Trash2,
  Wand2,
} from "lucide-react";
import {
  CONTEXT_REF_TYPES,
  createGatewayCodexDraft,
  createStrategyGatewayDraft,
  createWorkerEvent,
  classifyRiskAndApproval,
  gatewayPacketToWorkboardTaskInsert,
  taskPacketSchema,
  withDemoTaskPacket,
  workerEventToAgentEventInsert,
  type ContextRef,
  type ContextRefType,
} from "@/lib/agentic";
import { resolveAppRuntimeMode } from "@/lib/runtimeMode";
import { StrategySelect } from "./StrategySelect";
import { StrategySummary } from "./StrategySummary";
import { CompanyRequestPanel } from "./CompanyRequestPanel";
import { StrategyReviewPanel } from "./StrategyReviewPanel";
import { CompanyLineagePanel } from "./CompanyLineagePanel";

interface GatewayModeProps {
  onBack: () => void;
  onOpenTasks?: (taskId?: string) => void;
  companyDraft?: { id: string; text: string };
  onCompanyDraftChange?: (draft: { id: string; text: string }) => void;
}

interface GatewayExample {
  label: string;
  request: string;
  contextRefs: ContextRef[];
}

const examples: GatewayExample[] = [
  {
    label: "긴급재 리스크",
    request: "현대자동차 GA 강판 긴급재 위험도 따져줘",
    contextRefs: [
      { type: "customer_account", label: "고객", value: "현대자동차" },
      { type: "material_item", label: "자재", value: "GA 강판" },
      { type: "due_date", label: "필요 날짜", value: "이번 주 금요일" },
    ],
  },
  {
    label: "재고 확인",
    request: "GA 강판 재고 확인해줘",
    contextRefs: [
      { type: "material_item", label: "자재", value: "GA 강판" },
      { type: "warehouse", label: "창고", value: "울산 창고" },
    ],
  },
  {
    label: "고객 답장",
    request: "기아 납기 지연 문의 답장 초안 만들어줘",
    contextRefs: [
      { type: "customer_account", label: "고객", value: "기아" },
      { type: "user_note", label: "답장 톤", value: "정중하고 대안 중심" },
    ],
  },
  {
    label: "PR 검증",
    request: "PR #2 검증해줘",
    contextRefs: [
      { type: "github_repo", label: "저장소", value: "Kalamari0227/desktop-pal-buddy" },
      { type: "github_pr", label: "PR 번호", value: "2" },
    ],
  },
  {
    label: "스테이징 확인",
    request: "Supabase staging 상태 확인해줘",
    contextRefs: [{ type: "supabase_project", label: "스테이징", value: "staging-project-ref" }],
  },
  {
    label: "PRD 초안",
    request: "이 자료 기반으로 PRD 초안 만들어줘",
    contextRefs: [{ type: "uploaded_file", label: "첨부 자료", value: "pasted-text.txt" }],
  },
  {
    label: "마이그레이션 승인",
    request: "staging DB migration 실행해줘",
    contextRefs: [{ type: "supabase_project", label: "스테이징", value: "staging-project-ref" }],
  },
];

const riskTone: Record<string, string> = {
  low: "border-emerald-500/20 bg-emerald-500/10 text-emerald-300",
  medium: "border-amber-500/20 bg-amber-500/10 text-amber-300",
  high: "border-red-500/20 bg-red-500/10 text-red-300",
  blocked: "border-muted-foreground/20 bg-secondary text-muted-foreground",
};

function Pill({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <span className={`inline-flex h-6 items-center rounded-md border px-2 text-[11px] font-medium ${className}`}>
      {children}
    </span>
  );
}

const taskTypeLabels: Record<string, string> = {
  pr_verification: "PR 검증",
  supabase_staging_check: "스테이징 상태 확인",
  document_to_prd: "PRD 초안 작성",
  inventory_check: "재고 확인",
  urgent_material_risk_assessment: "긴급재 리스크 평가",
  delivery_delay_risk_check: "납기 지연 리스크 확인",
  customer_reply_draft: "고객 답장 초안",
  order_status_check: "주문 상태 확인",
  material_substitution_review: "대체 자재 검토",
  repo_doc_update: "문서 업데이트",
  general_research: "자료 조사",
  unknown: "검토 필요",
};

const taskSummaryLabels: Record<string, { summary: string; outcome: string }> = {
  pr_verification: {
    summary: "요청한 PR의 상태와 변경 범위를 검증합니다.",
    outcome: "병합 준비 여부, 증거, 막힌 항목, 리스크와 다음 행동을 정리합니다.",
  },
  supabase_staging_check: {
    summary: "스테이징 상태를 변경 없이 확인합니다.",
    outcome: "프로젝트 상태, 마이그레이션 상태, 경고, 막힌 항목과 다음 행동을 정리합니다.",
  },
  document_to_prd: {
    summary: "제공된 자료를 바탕으로 PRD 초안을 만듭니다.",
    outcome: "PRD 초안, 열린 질문, 저장 위치 제안과 검토 증거를 정리합니다.",
  },
  inventory_check: {
    summary: "요청한 자재와 기준 위치의 사용 가능한 재고를 확인합니다.",
    outcome: "사용 가능 수량, 정보 신뢰도, 막힌 항목, 리스크와 다음 행동을 정리합니다.",
  },
  urgent_material_risk_assessment: {
    summary: "고객과 자재 기준으로 긴급재 리스크를 평가합니다.",
    outcome: "공급 제약, 일정 리스크, 확인 증거, 막힌 항목과 안전한 다음 행동을 정리합니다.",
  },
  delivery_delay_risk_check: {
    summary: "고객, 주문, 자재 기준으로 납기 지연 리스크를 확인합니다.",
    outcome: "지연 가능성, 일정 근거, 영향도, 막힌 항목과 다음 행동을 정리합니다.",
  },
  customer_reply_draft: {
    summary: "고객에게 보낼 답장 초안을 작성하되 자동 발송하지 않습니다.",
    outcome: "검토 가능한 답장 초안, 전제 조건, 승인 민감 문구와 다음 행동을 정리합니다.",
  },
  order_status_check: {
    summary: "주문 기록을 변경하지 않고 현재 주문 상태를 확인합니다.",
    outcome: "현재 주문 상태, 확인 근거, 막힌 항목, 리스크와 다음 행동을 정리합니다.",
  },
  material_substitution_review: {
    summary: "요청 맥락에 맞는 대체 자재 후보를 검토합니다.",
    outcome: "후보 적합성, 공급 영향, 리스크, 증거와 다음 행동을 정리합니다.",
  },
};

const statusLabels: Record<string, string> = {
  queued: "접수됨",
  triaging: "정리 중",
  waiting_for_approval: "승인 대기",
  running: "실행 중",
  blocked: "보류",
  verifying: "검증 중",
  completed: "완료",
  failed: "실패",
  archived: "보관됨",
};

const riskLabels: Record<string, string> = {
  low: "낮음",
  medium: "보통",
  high: "높음",
  blocked: "보류",
};

const bridgeStatusLabels: Record<string, string> = {
  manual_only: "수동 전달 준비",
  needs_manual_review: "검토 필요",
};

const approvalActionLabels: Record<string, string> = {
  external_message: "외부 메시지 발송",
  file_delete_or_move: "파일 삭제/이동",
  production_deploy: "운영 배포",
  database_migration: "DB 변경 실행",
  service_restart: "서비스 재시작",
  oauth_or_gateway_config_change: "인증/설정 변경",
  paid_resource_creation: "유료 리소스 생성",
  secret_create_or_store: "시크릿 생성/저장",
  permission_change: "권한 변경",
};

const forbiddenActionLabels: Record<string, string> = {
  "do not merge PR": "PR 병합 금지",
  "do not push commits": "커밋 푸시 금지",
  "do not deploy": "배포 금지",
  "do not run migration": "마이그레이션 실행 금지",
  "do not change secrets": "시크릿 변경 금지",
  "do not deploy functions": "함수 배포 금지",
  "do not modify production systems": "운영 시스템 변경 금지",
  "do not overwrite existing docs without approval": "승인 없는 기존 문서 덮어쓰기 금지",
  "do not expose secrets from uploaded files": "업로드 파일의 민감 정보 노출 금지",
  "do not reserve inventory": "재고 예약 금지",
  "do not update ERP stock records": "ERP 재고 기록 변경 금지",
  "do not create sales or purchase orders": "판매/구매 주문 생성 금지",
  "do not expedite shipment": "출하 가속 지시 금지",
  "do not send customer commitment": "고객 확약 발송 금지",
  "do not change delivery schedule": "납기 일정 변경 금지",
  "do not create compensation offer": "보상 제안 생성 금지",
  "do not send external message": "외부 메시지 발송 금지",
  "do not make binding price or delivery commitment": "가격/납기 확약 금지",
  "do not expose internal-only context": "내부 전용 정보 노출 금지",
  "do not change order status": "주문 상태 변경 금지",
  "do not update ERP order records": "ERP 주문 기록 변경 금지",
  "do not approve material substitution": "대체 자재 승인 금지",
  "do not change customer specification": "고객 사양 변경 금지",
};

const verificationLabels: Record<string, string> = {
  test: "테스트",
  lint: "린트",
  typecheck: "타입 확인",
  build: "빌드",
  ci_status: "CI 상태",
  diff_review: "변경 내용 검토",
  supabase_status: "Supabase 상태",
  manual_review: "수동 검토",
  document_created: "문서 생성 확인",
  inventory_status: "재고 상태",
  order_status: "주문 상태",
  delivery_status: "납기 상태",
  risk_assessment: "리스크 평가",
  reply_draft: "답장 초안",
  substitution_review: "대체 자재 검토",
};

const policyNoteLabels: Record<string, string> = {
  "Gateway Codex can propose intake fields, but unsupported requests require manual review.":
    "지원하지 않거나 모호한 요청은 바로 실행하지 않고 사람이 검토합니다.",
  "No worker handoff is generated for unknown task types.":
    "지원되지 않는 요청은 실행 전달문을 만들지 않습니다.",
  "Gateway Codex is intake-only; worker execution remains manual in v0.":
    "현재는 요청을 정리하고, 실제 실행은 수동으로 전달합니다.",
  "Domain Core policy sets risk, approval, forbidden actions, status, and evidence requirements.":
    "정책 기준으로 위험도, 승인 필요 여부, 금지 작업, 상태와 필요한 증거를 정합니다.",
  "Approval-required work is locked to read-only preflight until explicit approval is scoped.":
    "승인이 필요한 작업은 승인 전까지 읽기 전용 확인만 허용됩니다.",
  "The suggested task type was normalized by the policy engine.":
    "정책 기준에 맞춰 작업 종류를 다시 정리했습니다.",
};

function displayTaskType(value: string): string {
  return taskTypeLabels[value] ?? value;
}

function displayTaskSummary(taskType: string, fallback: string): string {
  return taskSummaryLabels[taskType]?.summary ?? fallback;
}

function displayDesiredOutcome(taskType: string, fallback: string): string {
  return taskSummaryLabels[taskType]?.outcome ?? fallback;
}

function displayStatus(value: string): string {
  return statusLabels[value] ?? value;
}

function displayRisk(value: string): string {
  return riskLabels[value] ?? value;
}

function displayApprovalAction(value: string): string {
  return approvalActionLabels[value] ?? value;
}

function displayForbiddenAction(value: string): string {
  const approvalMatch = value.match(/^do not perform (.+) without explicit approval$/);
  if (approvalMatch) {
    return `승인 없는 ${displayApprovalAction(approvalMatch[1])} 금지`;
  }
  return forbiddenActionLabels[value] ?? value;
}

function displayApprovalReason(value?: string): string {
  const approvalMatch = value?.match(/^Approval required for: (.+)$/);
  if (approvalMatch) {
    return `승인 필요: ${approvalMatch[1].split(", ").map(displayApprovalAction).join(", ")}`;
  }
  return value ?? "변경 작업 전 명시적 승인이 필요합니다.";
}

function displayBlockedReason(value?: string): string {
  if (value === "Unsupported or ambiguous task type.") {
    return "지원하지 않거나 모호한 요청입니다. 필요한 참고 정보를 더 확인해야 합니다.";
  }
  return value ?? "아직 실행 가능한 작업 계획을 만들 수 없습니다.";
}

export function GatewayMode({ onBack, onOpenTasks, companyDraft, onCompanyDraftChange }: GatewayModeProps) {
  const [request, setRequest] = useState(examples[0].request);
  const [contextRefs, setContextRefs] = useState<ContextRef[]>(examples[0].contextRefs);
  const [savingTask, setSavingTask] = useState(false);
  const [createdWorkboardTaskId, setCreatedWorkboardTaskId] = useState<string | null>(null);
  const [strategyId, setStrategyId] = useState("");
  const [strategyVersionId, setStrategyVersionId] = useState("");
  const isDemoMode = resolveAppRuntimeMode() === "demo";
  const selectedStrategy = demoStrategies.find((strategy) => strategy.strategy_id === strategyId);
  const selectedStrategyVersion = demoStrategyVersions.find((version) => version.strategy_version_id === strategyVersionId);
  const strategyVersionRequired = isDemoMode && Boolean(selectedStrategy) && !selectedStrategyVersion;
  const strategyRef = isDemoMode && selectedStrategy && selectedStrategyVersion
    ? { strategy_id: selectedStrategy.strategy_id, strategy_version_id: selectedStrategyVersion.strategy_version_id }
    : undefined;

  const gatewayDraft = useMemo(() => {
    const input = { raw_user_request: request, context_refs: contextRefs };
    const requestedStrategyRef = isDemoMode && selectedStrategy
      ? { strategy_id: selectedStrategy.strategy_id, strategy_version_id: strategyVersionId }
      : undefined;
    return isDemoMode
      ? createStrategyGatewayDraft(input, requestedStrategyRef, demoStrategyVersions)
      : createGatewayCodexDraft(input);
  }, [contextRefs, isDemoMode, request, selectedStrategy, strategyVersionId]);
  const taskType = gatewayDraft.suggestion.task_type;
  const classification = useMemo(() => classifyRiskAndApproval({ request, task_type: taskType }), [request, taskType]);
  const packet = gatewayDraft.packet;
  const packetValidation = useMemo(() => (packet ? taskPacketSchema.safeParse(packet) : null), [packet]);
  const packetJson = useMemo(() => (packet ? JSON.stringify(packet, null, 2) : ""), [packet]);
  const handoffMarkdown = gatewayDraft.handoff_markdown;
  const riskLevel = packet?.risk_level ?? classification.risk_level;
  const approvalRequired = packet?.required_approval ?? classification.required_approval;
  const approvalActions = classification.approval_actions;

  const applyExample = (example: GatewayExample) => {
    setRequest(example.request);
    setContextRefs(example.contextRefs);
    setCreatedWorkboardTaskId(null);
  };

  const updateStrategySelection = (selection: { strategyId: string; versionId: string }) => {
    setStrategyId(selection.strategyId);
    setStrategyVersionId(selection.versionId);
    setCreatedWorkboardTaskId(null);
  };

  const updateContextRef = (index: number, patch: Partial<ContextRef>) => {
    setContextRefs((refs) => refs.map((ref, i) => (i === index ? { ...ref, ...patch } : ref)));
    setCreatedWorkboardTaskId(null);
  };

  const addContextRef = () => {
    setContextRefs((refs) => [...refs, { type: "user_note", label: "note", value: "" }]);
    setCreatedWorkboardTaskId(null);
  };

  const removeContextRef = (index: number) => {
    setContextRefs((refs) => refs.filter((_, i) => i !== index));
    setCreatedWorkboardTaskId(null);
  };

  const copyText = async (value: string, label: string) => {
    if (!value) {
      return;
    }
    if (!navigator.clipboard?.writeText) {
      toast.error("클립보드를 사용할 수 없습니다");
      return;
    }

    try {
      await navigator.clipboard.writeText(value);
      toast.success(`${label} 복사됨`);
    } catch {
      toast.error("복사에 실패했습니다");
    }
  };

  const createWorkboardTask = async () => {
    if (!packetValidation?.success) {
      toast.error("작업으로 만들 수 있는 요청이 아닙니다");
      return;
    }
    const validatedPacket = packetValidation.data;

    setSavingTask(true);

    const { data: existingTasks, error: existingError } = await supabase
      .from("tasks")
      .select("id")
      .eq("source", "gateway")
      .eq("source_id", validatedPacket.task_id)
      .limit(1);

    if (existingError) {
      setSavingTask(false);
      toast.error("기존 작업 확인에 실패했습니다");
      return;
    }

    const existingTaskId = (existingTasks?.[0] as { id?: string } | undefined)?.id;
    if (existingTaskId) {
      setSavingTask(false);
      setCreatedWorkboardTaskId(existingTaskId);
      toast.info("이미 Workboard에 등록된 요청입니다");
      return;
    }

    const workboardTaskId = globalThis.crypto?.randomUUID?.() ?? `gateway-${Date.now()}`;
    const createdAt = new Date().toISOString();
    const basePayload = gatewayPacketToWorkboardTaskInsert({
      packet: validatedPacket,
      workboard_task_id: workboardTaskId,
      created_at: createdAt,
    });
    const payload = isDemoMode && strategyRef
      ? withDemoTaskPacket({
          ...basePayload,
          id: workboardTaskId,
          title: basePayload.title,
        }, validatedPacket)
      : basePayload;

    const { error } = await supabase.from("tasks").insert(payload);

    if (error) {
      setSavingTask(false);
      toast.error("작업 생성에 실패했습니다");
      return;
    }

    const event = createWorkerEvent({
      packet_task_id: validatedPacket.task_id,
      event_type: "accepted",
      message: "Gateway 대화에서 작업이 생성되었습니다.",
      severity: "info",
      created_at: createdAt,
    });
    const { error: eventError } = await supabase
      .from("agent_events")
      .insert(workerEventToAgentEventInsert({
        workboard_task_id: workboardTaskId,
        event,
      }));

    setSavingTask(false);
    setCreatedWorkboardTaskId(workboardTaskId);

    if (eventError) {
      toast.warning("작업은 생성됐지만 이벤트 기록에 실패했습니다");
      return;
    }

    toast.success("작업 메뉴에 추가되었습니다");
  };

  return (
    <div className="flex h-full flex-col overflow-hidden">
      <div className="flex items-center gap-3 border-b border-border/50 px-6 py-4">
        <button
          onClick={onBack}
          className="flex h-8 w-8 items-center justify-center rounded-lg transition-colors hover:bg-secondary"
          aria-label="홈으로 돌아가기"
        >
          <ArrowLeft className="h-4 w-4 text-muted-foreground" />
        </button>
        <div className="min-w-0 flex-1">
          <h1 className="text-[15px] font-semibold">요청</h1>
          <p className="mt-0.5 text-[11px] text-muted-foreground">말로 남긴 요청을 작업 계획, 위험도, 필요한 증거로 정리합니다</p>
        </div>
        <Pill className={packetValidation?.success ? "border-emerald-500/20 bg-emerald-500/10 text-emerald-300" : "border-muted-foreground/20 bg-secondary text-muted-foreground"}>
          {packetValidation?.success ? "검증됨" : "검토 필요"}
        </Pill>
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto lg:overflow-hidden">
        <div className="grid min-h-full grid-cols-1 lg:h-full lg:grid-cols-[minmax(360px,0.9fr)_minmax(520px,1.35fr)]">
        <div className="border-r border-border/50 p-5 lg:min-h-0 lg:overflow-y-auto lg:scrollbar-thin">
          <CompanyRequestPanel
            onOpenTasks={onOpenTasks}
            companyDraft={companyDraft}
            onCompanyDraftChange={onCompanyDraftChange}
          />
          <StrategyReviewPanel />
          <CompanyLineagePanel onOpenTask={(taskId) => onOpenTasks?.(taskId)} />
          <div className="mb-3 mt-6 flex items-center justify-between gap-3">
            <h2 className="text-[12px] font-semibold text-foreground">수동 Gateway</h2>
            <span className="rounded-md border border-border/40 bg-background px-2 py-1 text-[10px] text-muted-foreground">기존 전달문 경로</span>
          </div>
          <section className="space-y-3">
            <div className="flex items-center gap-2">
              <Wand2 className="h-4 w-4 text-primary" />
              <h2 className="text-[13px] font-semibold">요청 내용</h2>
            </div>
            <textarea
              value={request}
              onChange={(event) => {
                setRequest(event.target.value);
                setCreatedWorkboardTaskId(null);
              }}
              className="min-h-[112px] w-full resize-none rounded-xl border border-border/50 bg-secondary/20 px-3 py-2.5 text-[12px] leading-relaxed outline-none transition-colors placeholder:text-muted-foreground focus:border-primary/40"
              placeholder="PR #2 검증해줘"
              aria-label="업무 요청"
            />
            {isDemoMode && (
              <StrategySelect
                strategies={demoStrategies}
                versions={demoStrategyVersions}
                strategyId={strategyId}
                versionId={strategyVersionId}
                onSelectionChange={updateStrategySelection}
              />
            )}
            {isDemoMode && selectedStrategy && selectedStrategyVersion && (
              <StrategySummary strategy={selectedStrategy} version={selectedStrategyVersion} />
            )}
            <div className="grid grid-cols-2 gap-2">
              {examples.map((example) => (
                <button
                  key={example.label}
                  onClick={() => applyExample(example)}
                  className="rounded-lg border border-border/40 bg-secondary/20 px-3 py-2 text-left text-[11px] font-medium text-muted-foreground transition-colors hover:border-border hover:text-foreground"
                >
                  {example.label}
                </button>
              ))}
            </div>
          </section>

          <section className="mt-6 space-y-3">
            <div className="flex items-center gap-2">
              <Bot className="h-4 w-4 text-primary" />
              <h2 className="text-[13px] font-semibold">요청 정리</h2>
            </div>
            <div className="rounded-xl border border-border/40 bg-secondary/10 p-3">
              <div className="flex flex-wrap gap-2">
                <Pill className="border-border/40 bg-background text-foreground">{bridgeStatusLabels[gatewayDraft.bridge_status]}</Pill>
                <Pill className={packet ? "border-emerald-500/20 bg-emerald-500/10 text-emerald-300" : "border-muted-foreground/20 bg-secondary text-muted-foreground"}>
                  {packet ? "작업 준비됨" : "검토 필요"}
                </Pill>
              </div>
              <p className="mt-3 text-[10px] text-muted-foreground">요청 요약</p>
              <p className="mt-1 text-[12px] leading-relaxed text-foreground">
                {displayTaskSummary(taskType, gatewayDraft.suggestion.request_summary)}
              </p>
              <p className="mt-3 text-[10px] text-muted-foreground">완료 기준</p>
              <p className="mt-1 text-[12px] leading-relaxed text-muted-foreground">
                {displayDesiredOutcome(taskType, gatewayDraft.suggestion.desired_outcome)}
              </p>
            </div>
            <div className="space-y-1">
              {gatewayDraft.policy_notes.map((note) => (
                <p key={note} className="rounded-lg border border-border/40 bg-background/50 px-2.5 py-2 text-[11px] leading-relaxed text-muted-foreground">
                  {policyNoteLabels[note] ?? note}
                </p>
              ))}
            </div>
          </section>

          <section className="mt-6 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <GitPullRequest className="h-4 w-4 text-primary" />
                <h2 className="text-[13px] font-semibold">참고 정보</h2>
              </div>
              <button
                onClick={addContextRef}
                className="flex h-7 w-7 items-center justify-center rounded-lg border border-border/40 bg-secondary/20 transition-colors hover:bg-secondary"
                aria-label="참고 정보 추가"
              >
                <Plus className="h-3.5 w-3.5" />
              </button>
            </div>
            <div className="space-y-2">
              {contextRefs.map((ref, index) => (
                <div key={`${ref.type}-${index}`} className="grid grid-cols-1 gap-2 sm:grid-cols-[118px_1fr_1fr_32px]">
                  <select
                    value={ref.type}
                    onChange={(event) => updateContextRef(index, { type: event.target.value as ContextRefType })}
                    className="h-9 rounded-lg border border-border/40 bg-background px-2 text-[11px] outline-none"
                    aria-label={`참고 유형 ${index + 1}`}
                  >
                    {CONTEXT_REF_TYPES.map((type) => (
                      <option key={type} value={type}>
                        {type}
                      </option>
                    ))}
                  </select>
                  <input
                    value={ref.label}
                    onChange={(event) => updateContextRef(index, { label: event.target.value })}
                    className="h-9 rounded-lg border border-border/40 bg-background px-2 text-[11px] outline-none"
                    aria-label={`참고 이름 ${index + 1}`}
                  />
                  <input
                    value={ref.value}
                    onChange={(event) => updateContextRef(index, { value: event.target.value })}
                    className="h-9 rounded-lg border border-border/40 bg-background px-2 text-[11px] outline-none"
                    aria-label={`참고 값 ${index + 1}`}
                  />
                  <button
                    onClick={() => removeContextRef(index)}
                    className="flex h-9 w-8 items-center justify-center rounded-lg border border-border/40 bg-secondary/20 transition-colors hover:bg-secondary"
                    aria-label={`참고 정보 제거 ${index + 1}`}
                  >
                    <Trash2 className="h-3.5 w-3.5 text-muted-foreground" />
                  </button>
                </div>
              ))}
            </div>
          </section>

          <section className="mt-6 space-y-3">
            <div className="flex items-center gap-2">
              <ShieldAlert className="h-4 w-4 text-primary" />
              <h2 className="text-[13px] font-semibold">판단 결과</h2>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div className="rounded-xl border border-border/40 bg-secondary/20 p-3">
                <p className="text-[10px] text-muted-foreground">작업 종류</p>
                <p className="mt-1 text-[12px] font-semibold text-foreground">{displayTaskType(taskType)}</p>
              </div>
              <div className="rounded-xl border border-border/40 bg-secondary/20 p-3">
                <p className="text-[10px] text-muted-foreground">현재 상태</p>
                <p className="mt-1 text-[12px] font-semibold text-foreground">{displayStatus(packet?.status ?? "blocked")}</p>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              <Pill className={riskTone[riskLevel] ?? riskTone.blocked}>위험도 {displayRisk(riskLevel)}</Pill>
              <Pill className={approvalRequired ? "border-red-500/20 bg-red-500/10 text-red-300" : "border-emerald-500/20 bg-emerald-500/10 text-emerald-300"}>
                {approvalRequired ? "승인 필요" : "승인 불필요"}
              </Pill>
              {approvalActions.map((action) => (
                <Pill key={action} className="border-red-500/20 bg-red-500/10 text-red-300">
                  {displayApprovalAction(action)}
                </Pill>
              ))}
            </div>
          </section>
        </div>

        <div className="p-5 lg:min-h-0 lg:overflow-y-auto lg:scrollbar-thin">
          {packet ? (
            <div className="space-y-4">
              <section className="grid gap-3 md:grid-cols-2 xl:grid-cols-5">
                <div className="rounded-xl border border-border/40 bg-secondary/10 p-3">
                  <p className="text-[10px] text-muted-foreground">진행 상태</p>
                  <p className="mt-1 text-[12px] font-semibold text-foreground">{displayStatus(packet.status)}</p>
                </div>
                <div className="rounded-xl border border-border/40 bg-secondary/10 p-3">
                  <p className="text-[10px] text-muted-foreground">결과 요약</p>
                  <p className="mt-1 text-[12px] font-semibold text-muted-foreground">아직 시작 전</p>
                </div>
                <div className="rounded-xl border border-border/40 bg-secondary/10 p-3">
                  <p className="text-[10px] text-muted-foreground">증거</p>
                  <p className="mt-1 text-[12px] font-semibold text-muted-foreground">아직 없음</p>
                </div>
                <div className="rounded-xl border border-border/40 bg-secondary/10 p-3">
                  <p className="text-[10px] text-muted-foreground">막힌 항목</p>
                  <p className="mt-1 text-[12px] font-semibold text-foreground">
                    {packet.required_approval ? "승인 필요" : "없음"}
                  </p>
                </div>
                <div className="rounded-xl border border-border/40 bg-secondary/10 p-3">
                  <p className="text-[10px] text-muted-foreground">저장 제안</p>
                  <p className="mt-1 text-[12px] font-semibold text-muted-foreground">완료 후 제안</p>
                </div>
              </section>

              {packet.required_approval && (
                <section className="rounded-xl border border-red-500/20 bg-red-500/10 p-3">
                  <p className="text-[10px] text-red-300">승인 필요</p>
                  <p className="mt-1 text-[12px] font-semibold text-foreground">
                    {displayApprovalReason(packet.approval_reason)}
                  </p>
                  <p className="mt-1 text-[11px] text-muted-foreground">
                    승인 전에는 읽기 전용 확인만 진행할 수 있습니다. 실제 변경은 범위를 확인하고 승인한 뒤에만 진행합니다.
                  </p>
                </section>
              )}

              <section className="rounded-xl border border-border/40 bg-secondary/10 p-3">
                <p className="text-[10px] text-muted-foreground">다음 행동</p>
                <p className="mt-1 text-[12px] text-foreground">
                  {packet.required_approval
                    ? "먼저 승인 범위를 확인하세요. 승인 전에는 읽기 전용 확인용 전달문만 사용할 수 있습니다."
                    : createdWorkboardTaskId
                      ? "작업 화면에서 전달문, Codex 결과, 증거를 이어서 기록하세요."
                    : "아래 전달문을 복사해 Codex에 전달하고, 결과와 증거를 다시 확인하세요."}
                </p>
                <div className="mt-3 flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => void createWorkboardTask()}
                    disabled={savingTask || Boolean(createdWorkboardTaskId)}
                    className="flex h-8 items-center gap-1.5 rounded-lg border border-primary/20 bg-primary/10 px-3 text-[11px] font-semibold text-primary transition-colors hover:bg-primary/15 disabled:cursor-not-allowed disabled:opacity-60"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    {savingTask ? "생성 중" : "작업으로 만들기"}
                  </button>
                  {createdWorkboardTaskId && (
                    <Pill className="border-emerald-500/20 bg-emerald-500/10 text-emerald-300">
                      작업 생성됨
                    </Pill>
                  )}
                  {createdWorkboardTaskId && onOpenTasks && (
                    <button
                      onClick={() => onOpenTasks(createdWorkboardTaskId)}
                      className="flex h-8 items-center gap-1.5 rounded-lg border border-border/40 bg-secondary/20 px-3 text-[11px] font-semibold text-foreground transition-colors hover:bg-secondary"
                    >
                      작업에서 계속
                      <ArrowRight className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>
              </section>

              <div className="grid gap-4 xl:grid-cols-2">
              <section className="space-y-3">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <FileJson className="h-4 w-4 text-primary" />
                    <h2 className="text-[13px] font-semibold">작업 계획 미리보기</h2>
                  </div>
                  <button
                    onClick={() => void copyText(packetJson, "작업 계획")}
                    className="flex items-center gap-1.5 rounded-lg border border-border/40 bg-secondary/20 px-2.5 py-1.5 text-[11px] font-medium transition-colors hover:bg-secondary"
                    aria-label="작업 계획 복사"
                  >
                    <Copy className="h-3.5 w-3.5" />
                    복사
                  </button>
                </div>
                <div className="rounded-xl border border-border/40 bg-secondary/10 p-3">
                  <p className="mb-2 text-[10px] font-medium text-muted-foreground">금지 작업</p>
                  <div className="flex flex-wrap gap-1.5">
                    {packet.forbidden_actions.map((action) => (
                      <Pill key={action} className="border-border/40 bg-background text-foreground">
                        {displayForbiddenAction(action)}
                      </Pill>
                    ))}
                  </div>
                </div>
                <div className="rounded-xl border border-border/40 bg-secondary/10 p-3">
                  <p className="mb-2 text-[10px] font-medium text-muted-foreground">필요한 증거</p>
                  <div className="flex flex-wrap gap-1.5">
                    {packet.verification_requirements.map((requirement) => (
                      <Pill key={`${requirement.type}-${requirement.command_or_source}`} className="border-border/40 bg-background text-foreground">
                        {verificationLabels[requirement.type] ?? requirement.type}
                      </Pill>
                    ))}
                  </div>
                </div>
                <div className="rounded-xl border border-border/40 bg-secondary/10 p-3">
                  <p className="mb-2 text-[10px] font-medium text-muted-foreground">참고 정보</p>
                  <div className="space-y-1">
                    {packet.context_refs.map((ref) => (
                      <p key={`${ref.type}-${ref.label}-${ref.value}`} className="text-[11px] text-foreground">
                        [{ref.type}] {ref.label}: {ref.value}
                      </p>
                    ))}
                  </div>
                </div>
                <pre
                  aria-label="작업 계획 원본 미리보기"
                  className="max-h-[420px] overflow-auto rounded-xl border border-border/40 bg-background/80 p-3 text-[11px] leading-relaxed text-muted-foreground scrollbar-thin"
                >
                  {packetJson}
                </pre>
              </section>

              <section className="space-y-3">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-2">
                    <CheckCircle2 className="h-4 w-4 text-primary" />
                    <h2 className="text-[13px] font-semibold">Codex 전달문</h2>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => applyExample(examples[0])}
                      className="flex items-center gap-1.5 rounded-lg border border-border/40 bg-secondary/20 px-2.5 py-1.5 text-[11px] font-medium transition-colors hover:bg-secondary"
                      aria-label="예시 초기화"
                    >
                      <RotateCcw className="h-3.5 w-3.5" />
                      초기화
                    </button>
                    <button
                      onClick={() => void copyText(handoffMarkdown, "전달문")}
                      className="flex items-center gap-1.5 rounded-lg bg-primary px-2.5 py-1.5 text-[11px] font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
                      aria-label="전달문 복사"
                    >
                      <Copy className="h-3.5 w-3.5" />
                      복사
                    </button>
                  </div>
                </div>
                <pre
                  aria-label="Codex 전달문 미리보기"
                  className="min-h-[520px] overflow-auto rounded-xl border border-border/40 bg-background/80 p-4 text-[12px] leading-relaxed text-foreground scrollbar-thin"
                >
                  {handoffMarkdown}
                </pre>
              </section>
              </div>
            </div>
          ) : (
            <div className="flex h-full min-h-[420px] items-center justify-center rounded-xl border border-dashed border-border/50 bg-secondary/10">
              <div className="max-w-sm text-center">
                <ShieldAlert className="mx-auto h-8 w-8 text-muted-foreground" />
                <p className="mt-3 text-[13px] font-medium text-foreground">검토가 필요합니다</p>
                <p className="mt-1 text-[11px] leading-relaxed text-muted-foreground">
                  {strategyVersionRequired
                    ? "전략 버전을 선택한 뒤 다시 확인해 주세요."
                    : displayBlockedReason(gatewayDraft.blocked_reason)}
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
    </div>
  );
}
