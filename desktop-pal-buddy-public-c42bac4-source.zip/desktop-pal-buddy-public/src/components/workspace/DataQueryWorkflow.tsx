import { useMemo, useState, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Database,
  Send,
  Loader2,
  Table2,
  Lightbulb,
  Code2,
  ChevronDown,
  ChevronUp,
  Sparkles,
} from "lucide-react";
import ReactMarkdown from "react-markdown";
import { createDataQueryProvider, type QueryResult } from "@/lib/dataQueryProvider";
import { runtimeConnectionLabel, runtimeConnectionTone } from "@/lib/runtimeMode";

const exampleQuestions = [
  "긴급 상태인 작업을 모두 보여줘",
  "고객별 미결 작업 수를 알려줘",
  "이번 주 생성 작업은?",
  "카테고리별 작업 현황을 요약해줘",
  "현대자동차 관련 이슈를 보여줘",
];

export function DataQueryWorkflow() {
  const [question, setQuestion] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<QueryResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showSql, setShowSql] = useState(false);
  const [showTable, setShowTable] = useState(true);
  const inputRef = useRef<HTMLInputElement>(null);
  const provider = useMemo(() => createDataQueryProvider(), []);
  const runtimeTone = runtimeConnectionTone(provider.mode);

  const handleQuery = async (q?: string) => {
    const queryText = q || question;
    if (!queryText.trim() || loading) return;

    setLoading(true);
    setResult(null);
    setError(null);
    setQuestion(queryText);

    try {
      if (provider.mode === "demo") {
        await new Promise((resolve) => setTimeout(resolve, 450));
      }
      setResult(await provider.query(queryText));
    } catch (err) {
      setError(err instanceof Error ? err.message : "데이터 질의에 실패했습니다.");
    } finally {
      setLoading(false);
    }
  };

  const columns = result?.data?.length
    ? Object.keys(result.data[0])
    : [];

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center gap-3 mb-2">
        <div
          className="w-10 h-10 rounded-xl flex items-center justify-center"
          style={{
            background: "hsla(var(--primary) / 0.1)",
            border: "1px solid hsla(var(--primary) / 0.2)",
          }}
        >
          <Database className="w-4.5 h-4.5 text-primary" />
        </div>
        <div className="min-w-0 flex-1">
          <h3 className="text-[14px] font-semibold">자연어 데이터 조회</h3>
          <p className="text-[11px] text-muted-foreground">
            궁금한 것을 자연어로 물어보면 데이터를 분석해드립니다
          </p>
        </div>
        <span
          className={
            "shrink-0 rounded-full border px-2 py-0.5 text-[10px] font-medium " +
            (runtimeTone === "success"
              ? "border-emerald-500/30 bg-emerald-500/10 text-emerald-600"
              : runtimeTone === "warning"
                ? "border-amber-500/30 bg-amber-500/10 text-amber-600"
                : "border-border/50 bg-secondary/40 text-muted-foreground")
          }
        >
          {runtimeConnectionLabel(provider.mode)}
        </span>
      </div>

      {/* Input */}
      <div className="relative">
        <input
          ref={inputRef}
          type="text"
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleQuery()}
          placeholder="예: 고객별 긴급 작업 현황을 보여줘"
          className="w-full px-4 py-3 pr-12 rounded-xl bg-secondary/30 border border-border/40 text-[13px] text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary/40 transition-all"
          disabled={loading}
        />
        <button
          onClick={() => handleQuery()}
          disabled={loading || !question.trim()}
          className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-lg flex items-center justify-center bg-primary text-primary-foreground disabled:opacity-40 hover:brightness-110 transition-all"
        >
          {loading ? (
            <Loader2 className="w-3.5 h-3.5 animate-spin" />
          ) : (
            <Send className="w-3.5 h-3.5" />
          )}
        </button>
      </div>

      {/* Example chips */}
      {!result && !loading && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="flex flex-wrap gap-1.5"
        >
          {exampleQuestions.map((eq, i) => (
            <button
              key={i}
              onClick={() => {
                setQuestion(eq);
                handleQuery(eq);
              }}
              className="px-3 py-1.5 rounded-lg bg-secondary/40 border border-border/30 text-[10px] text-muted-foreground hover:bg-secondary/60 hover:text-foreground transition-colors"
            >
              <Sparkles className="w-2.5 h-2.5 inline mr-1 opacity-50" />
              {eq}
            </button>
          ))}
        </motion.div>
      )}

      {/* Loading state */}
      {loading && !result && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-3 p-4 rounded-xl bg-secondary/20 border border-border/30"
        >
          <Loader2 className="w-4 h-4 animate-spin text-primary" />
          <div>
            <p className="text-[12px] font-medium">쿼리 생성 중...</p>
            <p className="text-[10px] text-muted-foreground">
              AI가 질문을 분석하고 데이터를 조회하고 있습니다
            </p>
          </div>
        </motion.div>
      )}

      {error && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-xl border border-destructive/30 bg-destructive/10 p-4 text-[12px] text-destructive"
        >
          {error}
        </motion.div>
      )}

      {/* Results */}
      <AnimatePresence>
        {result && (
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="space-y-3"
          >
            {/* SQL section */}
            {result.sql && (
              <div className="rounded-xl bg-secondary/20 border border-border/30 overflow-hidden">
                <button
                  onClick={() => setShowSql(!showSql)}
                  className="w-full flex items-center justify-between px-4 py-2.5 hover:bg-secondary/30 transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <Code2
                      className="w-3.5 h-3.5"
                      style={{ color: "hsl(var(--primary))" }}
                    />
                    <span className="text-[11px] font-medium">
                      생성된 쿼리
                    </span>
                    {result.explanation && (
                      <span className="text-[10px] text-muted-foreground">
                        — {result.explanation}
                      </span>
                    )}
                  </div>
                  {showSql ? (
                    <ChevronUp className="w-3.5 h-3.5 text-muted-foreground" />
                  ) : (
                    <ChevronDown className="w-3.5 h-3.5 text-muted-foreground" />
                  )}
                </button>
                <AnimatePresence>
                  {showSql && (
                    <motion.div
                      initial={{ height: 0 }}
                      animate={{ height: "auto" }}
                      exit={{ height: 0 }}
                      className="overflow-hidden"
                    >
                      <pre className="px-4 py-3 text-[11px] font-mono text-foreground/80 bg-secondary/30 border-t border-border/20 overflow-x-auto">
                        {result.sql}
                      </pre>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            )}

            {/* Data table */}
            {result.data.length > 0 && (
              <div className="rounded-xl bg-secondary/20 border border-border/30 overflow-hidden">
                <button
                  onClick={() => setShowTable(!showTable)}
                  className="w-full flex items-center justify-between px-4 py-2.5 hover:bg-secondary/30 transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <Table2
                      className="w-3.5 h-3.5"
                      style={{ color: "hsl(var(--status-completed))" }}
                    />
                    <span className="text-[11px] font-medium">
                      조회 결과
                    </span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-primary/10 text-primary font-semibold">
                      {result.data.length}건
                    </span>
                  </div>
                  {showTable ? (
                    <ChevronUp className="w-3.5 h-3.5 text-muted-foreground" />
                  ) : (
                    <ChevronDown className="w-3.5 h-3.5 text-muted-foreground" />
                  )}
                </button>
                <AnimatePresence>
                  {showTable && (
                    <motion.div
                      initial={{ height: 0 }}
                      animate={{ height: "auto" }}
                      exit={{ height: 0 }}
                      className="overflow-hidden"
                    >
                      <div className="max-h-64 overflow-auto border-t border-border/20">
                        <table className="w-full text-[11px]">
                          <thead>
                            <tr className="bg-secondary/40 sticky top-0">
                              {columns.map((col) => (
                                <th
                                  key={col}
                                  className="px-3 py-2 text-left font-semibold text-muted-foreground whitespace-nowrap"
                                >
                                  {col}
                                </th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {result.data.slice(0, 50).map((row, ri) => (
                              <tr
                                key={ri}
                                className="border-t border-border/10 hover:bg-secondary/20 transition-colors"
                              >
                                {columns.map((col) => (
                                  <td
                                    key={col}
                                    className="px-3 py-2 text-foreground/80 whitespace-nowrap max-w-48 truncate"
                                  >
                                    {String(
                                      (row as Record<string, unknown>)[col] ?? "—"
                                    )}
                                  </td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            )}

            {/* Insight */}
            {result.insight && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="rounded-xl bg-primary/5 border border-primary/15 p-4"
              >
                <div className="flex items-center gap-2 mb-2">
                  <Lightbulb
                    className="w-3.5 h-3.5"
                    style={{ color: "hsl(var(--primary))" }}
                  />
                  <span className="text-[12px] font-semibold text-primary">
                    AI 인사이트
                  </span>
                </div>
                <div className="prose prose-sm max-w-none text-[12px] text-foreground/80 leading-relaxed [&_ul]:list-disc [&_ul]:pl-4 [&_ol]:list-decimal [&_ol]:pl-4 [&_h3]:text-[13px] [&_h3]:font-semibold [&_h3]:mt-3 [&_h3]:mb-1 [&_p]:my-1 [&_li]:my-0.5 [&_strong]:text-foreground">
                  <ReactMarkdown>{result.insight}</ReactMarkdown>
                </div>
              </motion.div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
