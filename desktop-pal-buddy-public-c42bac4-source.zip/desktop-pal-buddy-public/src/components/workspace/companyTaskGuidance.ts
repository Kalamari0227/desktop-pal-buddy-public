import type { CompanyRuntimeTaskCardProjection } from "@/lib/company-runtime/projection";

export type CompanyTaskGuidance = {
  readonly pinnedStrategy: string;
  readonly approval: string;
  readonly execution: string;
  readonly readback: string;
  readonly businessOutcome: string;
  readonly nextAction: string;
};

function approvalLabel(card: CompanyRuntimeTaskCardProjection): string {
  switch (card.approval.state) {
    case "not_required": return "승인 불필요";
    case "pending": return "승인 대기";
    case "approved": return "승인됨";
    case "consumed": return "승인 사용됨";
    case "expired": return "승인 만료";
    case "rejected": return "승인 거절";
    case "revoked": return "승인 철회";
    case "review_required": return "승인 기록 검토 필요";
  }
}

function executionLabel(card: CompanyRuntimeTaskCardProjection): string {
  switch (card.execution.state) {
    case "none": return "실행 전";
    case "applied_pending_readback": return "실행됨 · 재조회 대기";
    case "verified": return "실행 및 재조회 확인됨";
    case "verification_required": return "실행 확인 필요";
    case "review_required": return "실행 기록 검토 필요";
  }
  return "실행 기록 검토 필요";
}

function readbackLabel(card: CompanyRuntimeTaskCardProjection): string {
  switch (card.readback.state) {
    case "none": return "재조회 전";
    case "verified": return "원장 재조회 일치";
    case "verification_required": return "원장 재조회 확인 필요";
  }
}

function nextAction(card: CompanyRuntimeTaskCardProjection): string {
  if (card.pinnedStrategy.status === "review_required") return "다음 행동: 저장된 전략 참조를 검토하세요.";
  if (card.approval.state === "review_required") return "다음 행동: 저장된 승인 기록을 검토하세요.";
  if (card.execution.state === "review_required") return "다음 행동: 저장된 실행 기록을 검토하세요.";
  if (card.execution.state === "verification_required" || card.readback.state === "verification_required") return "다음 행동: 원장 재조회를 확인하세요.";
  if (card.approval.state === "pending") return "다음 행동: 생산 역할에서 승인을 기록하세요.";
  if (card.approval.state === "approved") return "다음 행동: 승인된 변경을 적용하세요.";
  if (card.approval.state === "expired" || card.approval.state === "rejected" || card.approval.state === "revoked") return "다음 행동: 새 제안을 검토하세요.";
  if (card.execution.state === "none") return "다음 행동: 실행 조건을 검토하세요.";
  if (card.businessOutcome.state === "unknown") return "다음 행동: 사업 결과를 별도로 확인하세요.";
  return "다음 행동: 저장된 업무 기록을 확인하세요.";
}

export function selectCompanyTaskGuidance(card: CompanyRuntimeTaskCardProjection): CompanyTaskGuidance {
  return {
    pinnedStrategy: card.pinnedStrategy.status === "pinned" ? `고정 전략 v${card.pinnedStrategy.version}` : "전략 참조 검토 필요",
    approval: approvalLabel(card),
    execution: executionLabel(card),
    readback: readbackLabel(card),
    businessOutcome: card.businessOutcome.state === "unknown" ? "사업 결과 미관찰" : "사업 결과 시뮬레이션 관찰",
    nextAction: nextAction(card),
  };
}
