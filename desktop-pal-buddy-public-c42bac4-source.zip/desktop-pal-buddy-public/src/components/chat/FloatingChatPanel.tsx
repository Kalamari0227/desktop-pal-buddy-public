import { motion } from "framer-motion";
import { Minus, Sparkles, X } from "lucide-react";
import type { RefObject } from "react";
import { ChatInput } from "@/components/ChatInput";
import { ChatMessage } from "@/components/ChatMessage";
import { RuntimeConnectionStatus } from "@/components/workspace/RuntimeConnectionStatus";
import type { Msg } from "@/lib/streamChat";

interface FloatingChatPanelProps {
  className: string;
  messages: Msg[];
  isLoading: boolean;
  scrollRef: RefObject<HTMLDivElement>;
  onSend: (input: string) => void;
  onMinimize: () => void;
  onClose: () => void;
  onInputChange: (value: string) => void;
}

export function FloatingChatPanel({
  className,
  messages,
  isLoading,
  scrollRef,
  onSend,
  onMinimize,
  onClose,
  onInputChange,
}: FloatingChatPanelProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 24, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 24, scale: 0.98 }}
      transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
      className={className}
    >
      <header className="flex items-center justify-between px-5 py-3 border-b border-border/50">
        <div className="flex items-center gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-primary/10 ring-1 ring-primary/20 flex items-center justify-center">
            <Sparkles className="w-3.5 h-3.5 text-primary" />
          </div>
          <div>
            <h2 className="text-sm font-semibold tracking-tight">Prometheus</h2>
            <p className="text-[10px] text-muted-foreground">Agentic OS</p>
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          <RuntimeConnectionStatus />
          <button
            onClick={onMinimize}
            className="w-7 h-7 rounded-lg hover:bg-secondary flex items-center justify-center transition-colors"
          >
            <Minus className="w-3.5 h-3.5 text-muted-foreground" />
          </button>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-lg hover:bg-destructive/20 flex items-center justify-center transition-colors"
          >
            <X className="w-3.5 h-3.5 text-muted-foreground" />
          </button>
        </div>
      </header>
      <div ref={scrollRef} className="flex-1 overflow-y-auto px-5 py-4 space-y-5 scrollbar-thin">
        {messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full gap-4">
            <div className="w-12 h-12 rounded-2xl bg-primary/5 ring-1 ring-primary/10 flex items-center justify-center">
              <Sparkles className="w-6 h-6 text-primary/40" />
            </div>
            <p className="text-sm text-muted-foreground text-center max-w-xs">독에서 빠른 액션을 선택하거나 직접 질문을 입력하세요</p>
          </div>
        ) : (
          messages.map((msg, index) => (
            <ChatMessage
              key={index}
              message={msg}
              isStreaming={isLoading && index === messages.length - 1 && msg.role === "assistant"}
            />
          ))
        )}
      </div>
      <div className="px-5 pb-4 pt-2">
        <ChatInput onSend={onSend} isLoading={isLoading} onChange={onInputChange} />
      </div>
    </motion.div>
  );
}
