import { Suspense, useEffect, useMemo, useRef, useState } from "react";
import { Canvas, useFrame } from "@react-three/fiber";
import { ContactShadows, Float, Line } from "@react-three/drei";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { ArrowRight, ChevronDown, Command, Play, ShieldCheck } from "lucide-react";
import * as THREE from "three";
import { cn } from "@/lib/utils";

type Point = [number, number, number];

const integrations = ["Notion", "Slack", "GitHub", "Linear", "Calendar", "Files"];

const features = [
  {
    title: "AI agent orchestration",
    description: "Route a task to the right desktop agent with shared context, owners, and review states.",
    detail: "Agent routing",
    className: "md:col-span-7",
  },
  {
    title: "Desktop-aware automation",
    description: "Connect app windows, local files, and active work without moving the team into another tab.",
    detail: "Local context",
    className: "md:col-span-5",
  },
  {
    title: "App and file context",
    description: "Attach the live materials an agent needs, then keep each handoff traceable.",
    detail: "Files linked",
    className: "md:col-span-4",
  },
  {
    title: "Secure local-first workflows",
    description: "Keep sensitive desktop sessions controlled with explicit review before actions run.",
    detail: "Review gate",
    className: "md:col-span-4",
  },
  {
    title: "Human-in-the-loop approvals",
    description: "Pause high-impact steps for review, comments, or manual changes before execution.",
    detail: "Approval queue",
    className: "md:col-span-4",
  },
  {
    title: "Multi-agent task routing",
    description: "Split research, drafting, checks, and scheduling across agents built for each job.",
    detail: "Parallel lanes",
    className: "md:col-span-12",
  },
];

const workflow = [
  {
    title: "Capture context",
    body: "Agentic OS reads the active workspace, open files, and task intent.",
  },
  {
    title: "Route agents",
    body: "Work is assigned to the agents that can act with the right permissions.",
  },
  {
    title: "Execute workflows",
    body: "Agents draft, search, compare, and prepare actions inside reviewable lanes.",
  },
  {
    title: "Review outcomes",
    body: "Humans approve results, edit outputs, or send the workflow back with notes.",
  },
];

const stats = [
  {
    value: "42%",
    label: "faster task completion",
    body: "Routine handoffs move from chat requests into assigned agent lanes.",
  },
  {
    value: "18h",
    label: "saved weekly",
    body: "Teams spend less time copying context between tools and files.",
  },
  {
    value: "120+",
    label: "app actions",
    body: "Desktop tasks can be prepared across calendars, docs, repos, and chat.",
  },
  {
    value: "99.9%",
    label: "local session reliability",
    body: "The active desktop session stays visible and reviewable.",
  },
];

const plans = [
  {
    name: "Starter",
    price: "$19",
    note: "For a focused personal desktop.",
    features: ["One local workspace", "Three active agents", "Manual approvals", "Basic app context"],
  },
  {
    name: "Pro",
    price: "$49",
    note: "For builders running daily agent workflows.",
    features: ["Unlimited local projects", "Ten active agents", "Workflow templates", "File and app memory"],
    featured: true,
  },
  {
    name: "Team",
    price: "$129",
    note: "For shared approvals and team routing.",
    features: ["Shared agent registry", "Role-based approvals", "Audit history", "Priority desktop support"],
  },
];

const faqs = [
  {
    question: "What is Agentic OS?",
    answer:
      "Agentic OS is a desktop layer for routing work across AI agents. It keeps context, actions, and review steps in one product surface.",
  },
  {
    question: "How does this connect to desktop-pal-buddy?",
    answer:
      "desktop-pal-buddy already has an ambient assistant and workspace shell. This landing page presents that product idea as a premium SaaS front page.",
  },
  {
    question: "Is local data safe?",
    answer:
      "The page describes a local-first workflow model where sensitive actions pause for approval and desktop context stays visible to the user.",
  },
  {
    question: "Which apps can it work with?",
    answer:
      "The product story covers common work surfaces like docs, chat, repos, calendars, local files, and internal tools.",
  },
  {
    question: "Can a team use it?",
    answer:
      "Yes. The Team plan frames shared agent registries, role-based approvals, and audit history for group workflows.",
  },
];

const sectionReveal = {
  hidden: { opacity: 0, y: 28 },
  visible: { opacity: 1, y: 0 },
};

function MotionSection({
  id,
  className,
  children,
}: {
  id?: string;
  className?: string;
  children: React.ReactNode;
}) {
  const reducedMotion = useReducedMotion();

  if (reducedMotion) {
    return (
      <section id={id} className={className}>
        {children}
      </section>
    );
  }

  return (
    <motion.section
      id={id}
      className={className}
      variants={sectionReveal}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, amount: 0.18 }}
      transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.section>
  );
}

function AgentNode({ position, color, scale = 1 }: { position: Point; color: string; scale?: number }) {
  return (
    <Float speed={1.1} rotationIntensity={0.18} floatIntensity={0.18}>
      <group position={position} scale={scale}>
        <mesh>
          <sphereGeometry args={[0.08, 24, 24]} />
          <meshStandardMaterial color={color} metalness={0.2} roughness={0.16} />
        </mesh>
        <mesh>
          <sphereGeometry args={[0.145, 24, 24]} />
          <meshBasicMaterial color={color} transparent opacity={0.11} depthWrite={false} />
        </mesh>
      </group>
    </Float>
  );
}

function AppWindow({
  position,
  rotation,
  scale,
  accent,
}: {
  position: Point;
  rotation: Point;
  scale: number;
  accent: string;
}) {
  return (
    <Float speed={1.2} rotationIntensity={0.12} floatIntensity={0.2}>
      <group position={position} rotation={rotation} scale={scale}>
        <mesh>
          <boxGeometry args={[1.45, 0.86, 0.035]} />
          <meshStandardMaterial color="#ffffff" metalness={0.04} roughness={0.2} />
        </mesh>
        <mesh position={[0, 0.34, 0.026]}>
          <boxGeometry args={[1.28, 0.075, 0.012]} />
          <meshStandardMaterial color="#dbeafe" metalness={0.1} roughness={0.22} />
        </mesh>
        <mesh position={[-0.48, 0.12, 0.03]}>
          <boxGeometry args={[0.28, 0.38, 0.012]} />
          <meshStandardMaterial color={accent} metalness={0.16} roughness={0.18} />
        </mesh>
        <mesh position={[0.2, 0.18, 0.03]}>
          <boxGeometry args={[0.56, 0.055, 0.012]} />
          <meshStandardMaterial color="#1f3a5f" metalness={0.05} roughness={0.24} />
        </mesh>
        <mesh position={[0.26, 0.02, 0.03]}>
          <boxGeometry args={[0.68, 0.045, 0.012]} />
          <meshStandardMaterial color="#90a4bd" metalness={0.05} roughness={0.28} />
        </mesh>
        <mesh position={[0.12, -0.13, 0.03]}>
          <boxGeometry args={[0.4, 0.045, 0.012]} />
          <meshStandardMaterial color="#b8c7d8" metalness={0.05} roughness={0.28} />
        </mesh>
      </group>
    </Float>
  );
}

function OSCoreScene({ reduceMotion }: { reduceMotion: boolean }) {
  const coreRef = useRef<THREE.Group>(null);
  const orbitRef = useRef<THREE.Group>(null);
  const routes = useMemo<Point[][]>(
    () => [
      [
        [-2.55, 0.82, -0.35],
        [-1.28, 0.42, -0.16],
        [-0.45, 0.14, 0.02],
      ],
      [
        [2.45, 0.9, -0.28],
        [1.2, 0.42, -0.12],
        [0.42, 0.12, 0.02],
      ],
      [
        [-2.2, -1.05, -0.2],
        [-1.1, -0.5, -0.08],
        [-0.34, -0.15, 0.02],
      ],
      [
        [2.1, -1.08, -0.18],
        [1.02, -0.52, -0.08],
        [0.34, -0.15, 0.02],
      ],
    ],
    [],
  );

  useFrame(({ clock }, delta) => {
    if (reduceMotion) return;
    const elapsed = clock.getElapsedTime();

    if (coreRef.current) {
      coreRef.current.rotation.y += delta * 0.18;
      coreRef.current.rotation.x = Math.sin(elapsed * 0.45) * 0.05;
    }

    if (orbitRef.current) {
      orbitRef.current.rotation.z += delta * 0.08;
      orbitRef.current.rotation.y = Math.sin(elapsed * 0.35) * 0.12;
    }
  });

  return (
    <>
      <ambientLight intensity={1.2} />
      <directionalLight position={[4, 5, 6]} intensity={2.1} color="#ffffff" />
      <pointLight position={[-3, 2.5, 3]} intensity={1.4} color="#15c6a3" />
      <pointLight position={[3, -1.5, 3]} intensity={1.2} color="#1558d6" />

      <group position={[0, 0.05, 0]}>
        <group ref={coreRef}>
          <mesh>
            <sphereGeometry args={[0.72, 64, 64]} />
            <meshPhysicalMaterial
              color="#f8fcff"
              metalness={0.12}
              roughness={0.035}
              clearcoat={1}
              clearcoatRoughness={0.04}
              transmission={0.34}
              thickness={0.72}
              transparent
              opacity={0.88}
            />
          </mesh>
          <mesh scale={0.64}>
            <sphereGeometry args={[0.72, 48, 48]} />
            <meshStandardMaterial color="#1558d6" metalness={0.35} roughness={0.12} transparent opacity={0.58} />
          </mesh>
          <mesh scale={0.32}>
            <sphereGeometry args={[0.72, 36, 36]} />
            <meshStandardMaterial color="#15c6a3" metalness={0.2} roughness={0.1} transparent opacity={0.82} />
          </mesh>
        </group>

        <group ref={orbitRef}>
          <mesh rotation={[Math.PI / 2, 0, 0]}>
            <torusGeometry args={[1.08, 0.01, 12, 96]} />
            <meshStandardMaterial color="#1558d6" metalness={0.55} roughness={0.16} />
          </mesh>
          <mesh rotation={[0.84, 0.42, 0.2]}>
            <torusGeometry args={[1.28, 0.008, 12, 96]} />
            <meshStandardMaterial color="#15c6a3" metalness={0.45} roughness={0.16} />
          </mesh>
          <mesh rotation={[1.14, -0.52, 0.8]}>
            <torusGeometry args={[1.52, 0.006, 12, 96]} />
            <meshStandardMaterial color="#7aa8ff" metalness={0.38} roughness={0.2} />
          </mesh>
        </group>

        {routes.map((route, index) => (
          <Line
            key={index}
            points={route}
            color={index % 2 === 0 ? "#1558d6" : "#15c6a3"}
            lineWidth={1.35}
            transparent
            opacity={0.54}
          />
        ))}

        <AppWindow position={[-2.55, 0.82, -0.35]} rotation={[0.1, 0.35, 0.08]} scale={0.74} accent="#1558d6" />
        <AppWindow position={[2.45, 0.9, -0.28]} rotation={[0.08, -0.38, -0.08]} scale={0.7} accent="#15c6a3" />
        <AppWindow position={[-2.2, -1.05, -0.2]} rotation={[-0.12, 0.28, -0.05]} scale={0.62} accent="#6da6ff" />
        <AppWindow position={[2.1, -1.08, -0.18]} rotation={[-0.08, -0.3, 0.07]} scale={0.62} accent="#38d3b6" />

        <AgentNode position={[-1.28, 0.42, -0.16]} color="#1558d6" />
        <AgentNode position={[1.2, 0.42, -0.12]} color="#15c6a3" />
        <AgentNode position={[-1.1, -0.5, -0.08]} color="#1558d6" scale={0.88} />
        <AgentNode position={[1.02, -0.52, -0.08]} color="#15c6a3" scale={0.88} />
      </group>

      <ContactShadows position={[0, -1.72, 0]} opacity={0.18} scale={5.2} blur={2.6} far={3.2} color="#2f5f8f" />
    </>
  );
}

function HeroCanvas() {
  const reducedMotion = Boolean(useReducedMotion());

  return (
    <div className="relative h-[420px] min-h-[360px] w-full sm:h-[520px] lg:h-[620px]" aria-hidden="true">
      <Canvas
        camera={{ position: [0, 0.18, 5.5], fov: 42, near: 0.1, far: 100 }}
        gl={{ antialias: true, alpha: true, powerPreference: "high-performance", preserveDrawingBuffer: true }}
        dpr={[1, 1.65]}
        style={{ background: "transparent" }}
      >
        <Suspense fallback={null}>
          <OSCoreScene reduceMotion={reducedMotion} />
        </Suspense>
      </Canvas>
      <div className="pointer-events-none absolute inset-x-4 bottom-8 grid gap-3 sm:grid-cols-2">
        <motion.div
          initial={reducedMotion ? false : { opacity: 0, y: 16 }}
          animate={reducedMotion ? undefined : { opacity: 1, y: 0 }}
          transition={{ duration: 0.55, delay: 0.35 }}
          className="rounded-[8px] border border-[#c7dcf3] bg-white/92 p-4 shadow-[0_18px_50px_rgba(17,57,105,0.12)] backdrop-blur"
        >
          <p className="text-xs font-medium text-[#48627f]">Workflow lane</p>
          <p className="mt-1 text-sm font-semibold text-[#13233a]">Research agent routed to local files</p>
        </motion.div>
        <motion.div
          initial={reducedMotion ? false : { opacity: 0, y: 16 }}
          animate={reducedMotion ? undefined : { opacity: 1, y: 0 }}
          transition={{ duration: 0.55, delay: 0.5 }}
          className="rounded-[8px] border border-[#c3eee6] bg-white/92 p-4 shadow-[0_18px_50px_rgba(12,117,97,0.1)] backdrop-blur"
        >
          <p className="text-xs font-medium text-[#48627f]">Approval loop</p>
          <p className="mt-1 text-sm font-semibold text-[#13233a]">Human review required before send</p>
        </motion.div>
      </div>
    </div>
  );
}

function ProductDiagram() {
  return (
    <div className="relative min-h-[360px] overflow-hidden rounded-[8px] border border-[#c9d9ea] bg-[#f9fcff] p-5 shadow-[0_20px_70px_rgba(21,88,214,0.08)]">
      <div className="absolute inset-x-0 top-0 h-12 border-b border-[#d8e4f0] bg-white" />
      <div className="relative z-10 flex items-center gap-2">
        <span className="h-2.5 w-2.5 rounded-full bg-[#1558d6]" />
        <span className="h-2.5 w-2.5 rounded-full bg-[#15c6a3]" />
        <span className="h-2.5 w-2.5 rounded-full bg-[#9eb2c8]" />
      </div>
      <div className="relative z-10 mt-10 grid gap-4 md:grid-cols-[1fr_1.2fr]">
        <div className="space-y-3">
          {["Context packet", "Agent route", "Review state"].map((item, index) => (
            <div key={item} className="rounded-[8px] border border-[#d4e2f0] bg-white p-4">
              <div className="flex items-center justify-between">
                <p className="text-sm font-semibold text-[#172842]">{item}</p>
                <span className={cn("h-2 w-10 rounded-full", index === 1 ? "bg-[#15c6a3]" : "bg-[#1558d6]")} />
              </div>
              <div className="mt-4 space-y-2">
                <span className="block h-2 rounded-full bg-[#e5edf6]" />
                <span className="block h-2 w-2/3 rounded-full bg-[#eef4fa]" />
              </div>
            </div>
          ))}
        </div>
        <div className="rounded-[8px] border border-[#c7dcf3] bg-white p-5">
          <div className="flex items-center justify-between border-b border-[#e3ebf5] pb-4">
            <div>
              <p className="text-sm font-semibold text-[#172842]">Agent dispatch</p>
              <p className="mt-1 text-xs text-[#62728a]">Live desktop context</p>
            </div>
            <span className="rounded-full bg-[#e8fbf7] px-3 py-1 text-xs font-semibold text-[#087865]">Ready</span>
          </div>
          <div className="mt-5 space-y-4">
            {[
              ["Files", "Research agent"],
              ["Calendar", "Planner agent"],
              ["GitHub", "Review agent"],
            ].map(([source, agent]) => (
              <div key={source} className="grid grid-cols-[90px_1fr] items-center gap-3">
                <span className="text-xs font-medium text-[#62728a]">{source}</span>
                <span className="rounded-[8px] border border-[#dce8f4] bg-[#f7fbff] px-3 py-2 text-sm font-semibold text-[#172842]">
                  {agent}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

function AgenticLandingPage() {
  const [openFaq, setOpenFaq] = useState(0);
  const reducedMotion = useReducedMotion();

  useEffect(() => {
    const html = document.documentElement;
    const body = document.body;
    const root = document.getElementById("root");
    const hadLight = html.classList.contains("light");
    const previous = {
      html: html.style.backgroundColor,
      body: body.style.backgroundColor,
      root: root?.style.backgroundColor || "",
    };

    html.classList.add("light");
    html.style.backgroundColor = "#f7fbff";
    body.style.backgroundColor = "#f7fbff";
    if (root) root.style.backgroundColor = "#f7fbff";

    return () => {
      if (!hadLight) html.classList.remove("light");
      html.style.backgroundColor = previous.html;
      body.style.backgroundColor = previous.body;
      if (root) root.style.backgroundColor = previous.root;
    };
  }, []);

  return (
    <main className="min-h-screen overflow-hidden bg-[#f7fbff] text-[#172033]">
      <header className="sticky top-0 z-50 border-b border-[#d9e6f3] bg-[#f7fbff]/88 backdrop-blur-xl">
        <nav className="mx-auto flex max-w-7xl items-center justify-between px-5 py-3 sm:px-8" aria-label="Main navigation">
          <a href="#top" className="flex items-center gap-3" aria-label="Agentic OS home">
            <span className="flex h-9 w-9 items-center justify-center rounded-[8px] border border-[#bdd2ea] bg-white text-[#1558d6] shadow-[0_8px_24px_rgba(21,88,214,0.1)]">
              <Command className="h-4 w-4" aria-hidden="true" />
            </span>
            <span className="text-sm font-semibold tracking-[0.01em] text-[#172033]">Agentic OS</span>
          </a>
          <div className="hidden items-center gap-7 text-sm font-medium text-[#53677f] md:flex">
            <a className="transition-colors hover:text-[#1558d6]" href="#features">
              Features
            </a>
            <a className="transition-colors hover:text-[#1558d6]" href="#workflow">
              Workflow
            </a>
            <a className="transition-colors hover:text-[#1558d6]" href="#pricing">
              Pricing
            </a>
            <a className="transition-colors hover:text-[#1558d6]" href="#faq">
              FAQ
            </a>
          </div>
          <div className="flex items-center gap-2">
            <a
              href="?demo=1"
              className="hidden h-10 items-center gap-2 rounded-[8px] border border-[#c9d9ea] bg-white px-4 text-sm font-semibold text-[#172033] shadow-sm transition hover:border-[#1558d6] hover:text-[#1558d6] sm:inline-flex"
            >
              <Play className="h-3.5 w-3.5" aria-hidden="true" />
              View Demo
            </a>
            <a
              href="#pricing"
              className="inline-flex h-10 items-center gap-2 rounded-[8px] bg-[#1558d6] px-4 text-sm font-semibold text-white shadow-[0_12px_30px_rgba(21,88,214,0.2)] transition hover:bg-[#0f49b8]"
            >
              Start Building
              <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
            </a>
          </div>
        </nav>
      </header>

      <section id="top" className="relative border-b border-[#dbe7f4]">
        <div className="absolute inset-0 bg-[linear-gradient(180deg,#f7fbff_0%,#ffffff_72%,#f5faff_100%)]" />
        <div className="relative mx-auto grid max-w-7xl items-center gap-8 px-5 py-16 sm:px-8 sm:py-20 lg:grid-cols-[0.86fr_1.14fr] lg:py-24">
          <motion.div
            initial={reducedMotion ? false : { opacity: 0, x: -28 }}
            animate={reducedMotion ? undefined : { opacity: 1, x: 0 }}
            transition={{ duration: 0.75, ease: [0.22, 1, 0.36, 1] }}
            className="max-w-2xl"
          >
            <p className="text-sm font-semibold text-[#1558d6]">Desktop agents with reviewable handoffs</p>
            <h1 className="mt-5 text-5xl font-semibold leading-[0.95] tracking-[-0.02em] text-[#111b2e] sm:text-6xl lg:text-7xl">
              Agentic OS
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-8 text-[#53677f] sm:text-xl">
              Coordinate AI agents across your desktop, files, apps, and approvals from one product surface.
            </p>
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <a
                href="#pricing"
                className="inline-flex h-12 items-center justify-center gap-2 rounded-[8px] bg-[#1558d6] px-5 text-sm font-semibold text-white shadow-[0_16px_42px_rgba(21,88,214,0.22)] transition hover:bg-[#0f49b8]"
              >
                Start Building
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </a>
              <a
                href="?demo=1"
                className="inline-flex h-12 items-center justify-center gap-2 rounded-[8px] border border-[#bfd2e6] bg-white px-5 text-sm font-semibold text-[#172033] shadow-sm transition hover:border-[#1558d6] hover:text-[#1558d6]"
              >
                <Play className="h-4 w-4" aria-hidden="true" />
                View Demo
              </a>
            </div>
            <div className="mt-10 grid max-w-lg grid-cols-2 gap-4 border-t border-[#d8e4f0] pt-6">
              <div>
                <p className="text-2xl font-semibold text-[#172033]">6</p>
                <p className="mt-1 text-sm text-[#62728a]">agent roles ready for routing</p>
              </div>
              <div>
                <p className="text-2xl font-semibold text-[#172033]">1</p>
                <p className="mt-1 text-sm text-[#62728a]">desktop layer for context and review</p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={reducedMotion ? false : { opacity: 0, x: 30, scale: 0.98 }}
            animate={reducedMotion ? undefined : { opacity: 1, x: 0, scale: 1 }}
            transition={{ duration: 0.85, ease: [0.22, 1, 0.36, 1], delay: 0.08 }}
            className="relative"
          >
            <div className="absolute inset-x-8 bottom-8 top-10 rounded-full bg-[#cfe6ff]/35 blur-3xl" aria-hidden="true" />
            <HeroCanvas />
          </motion.div>
        </div>
      </section>

      <MotionSection className="mx-auto max-w-7xl px-5 py-12 sm:px-8">
        <div className="grid gap-4 border-y border-[#dbe7f4] py-6 sm:grid-cols-[220px_1fr] sm:items-center">
          <p className="text-sm font-medium text-[#53677f]">Built for the tools your agents already touch.</p>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-6">
            {integrations.map((integration) => (
              <div
                key={integration}
                className="flex h-12 items-center justify-center rounded-[8px] border border-[#d7e5f2] bg-white text-sm font-semibold text-[#263a55]"
              >
                {integration}
              </div>
            ))}
          </div>
        </div>
      </MotionSection>

      <MotionSection id="features" className="mx-auto max-w-7xl px-5 py-20 sm:px-8">
        <div className="grid gap-10 lg:grid-cols-[0.85fr_1.15fr] lg:items-end">
          <div>
            <p className="text-sm font-semibold text-[#1558d6]">Product surface</p>
            <h2 className="mt-3 text-3xl font-semibold tracking-[-0.015em] text-[#111b2e] sm:text-5xl">
              Designed around desktop work, permissions, and review.
            </h2>
          </div>
          <p className="max-w-2xl text-base leading-7 text-[#53677f] lg:justify-self-end">
            Agentic OS gives each agent the context it needs without hiding the action from the person responsible for the outcome.
          </p>
        </div>

        <div className="mt-12 grid gap-4 md:grid-cols-12">
          {features.map((feature, index) => (
            <motion.article
              key={feature.title}
              className={cn(
                "rounded-[8px] border border-[#d5e3f0] bg-white p-6 shadow-[0_12px_42px_rgba(24,59,97,0.06)]",
                feature.className,
              )}
              initial={reducedMotion ? false : { opacity: 0, y: 18 }}
              whileInView={reducedMotion ? undefined : { opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.35 }}
              transition={{ duration: 0.5, delay: index * 0.04 }}
            >
              <div className="flex items-start justify-between gap-5">
                <div>
                  <p className="text-xs font-semibold text-[#1558d6]">{feature.detail}</p>
                  <h3 className="mt-3 text-xl font-semibold text-[#172033]">{feature.title}</h3>
                </div>
                <span className={cn("mt-1 h-2 w-12 rounded-full", index % 2 === 0 ? "bg-[#1558d6]" : "bg-[#15c6a3]")} />
              </div>
              <p className="mt-5 max-w-2xl text-sm leading-6 text-[#62728a]">{feature.description}</p>
            </motion.article>
          ))}
        </div>
      </MotionSection>

      <MotionSection id="workflow" className="bg-white py-20">
        <div className="mx-auto max-w-7xl px-5 sm:px-8">
          <div className="grid gap-10 lg:grid-cols-[0.92fr_1.08fr] lg:items-center">
            <div>
              <p className="text-sm font-semibold text-[#1558d6]">Workflow model</p>
              <h2 className="mt-3 text-3xl font-semibold tracking-[-0.015em] text-[#111b2e] sm:text-5xl">
                Context moves like a product diagram, not a chat transcript.
              </h2>
              <div className="mt-8 space-y-4">
                {workflow.map((step, index) => (
                  <motion.div
                    key={step.title}
                    className="grid grid-cols-[18px_1fr] gap-4"
                    initial={reducedMotion ? false : { opacity: 0, x: -16 }}
                    whileInView={reducedMotion ? undefined : { opacity: 1, x: 0 }}
                    viewport={{ once: true, amount: 0.45 }}
                    transition={{ duration: 0.45, delay: index * 0.06 }}
                  >
                    <span className={cn("mt-2 h-3 w-3 rounded-full", index === 1 || index === 3 ? "bg-[#15c6a3]" : "bg-[#1558d6]")} />
                    <div className="border-b border-[#e1ebf5] pb-4">
                      <h3 className="text-lg font-semibold text-[#172033]">{step.title}</h3>
                      <p className="mt-2 text-sm leading-6 text-[#62728a]">{step.body}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
            <ProductDiagram />
          </div>
        </div>
      </MotionSection>

      <MotionSection className="mx-auto max-w-7xl px-5 py-20 sm:px-8">
        <div className="grid gap-8 lg:grid-cols-[0.7fr_1.3fr] lg:items-start">
          <div>
            <p className="text-sm font-semibold text-[#1558d6]">Operating metrics</p>
            <h2 className="mt-3 text-3xl font-semibold tracking-[-0.015em] text-[#111b2e] sm:text-5xl">
              Measured by fewer handoffs and clearer approvals.
            </h2>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            {stats.map((stat) => (
              <article key={stat.label} className="rounded-[8px] border border-[#d5e3f0] bg-white p-6">
                <p className="text-4xl font-semibold tracking-[-0.02em] text-[#1558d6]">{stat.value}</p>
                <h3 className="mt-3 text-base font-semibold text-[#172033]">{stat.label}</h3>
                <p className="mt-2 text-sm leading-6 text-[#62728a]">{stat.body}</p>
              </article>
            ))}
          </div>
        </div>
      </MotionSection>

      <MotionSection id="pricing" className="bg-white py-20">
        <div className="mx-auto max-w-7xl px-5 sm:px-8">
          <div className="max-w-3xl">
            <p className="text-sm font-semibold text-[#1558d6]">Pricing</p>
            <h2 className="mt-3 text-3xl font-semibold tracking-[-0.015em] text-[#111b2e] sm:text-5xl">
              Start with one desktop. Scale when agents become shared work.
            </h2>
          </div>
          <div className="mt-12 grid gap-5 lg:grid-cols-3">
            {plans.map((plan) => (
              <article
                key={plan.name}
                className={cn(
                  "rounded-[8px] border bg-white p-6 shadow-[0_12px_42px_rgba(24,59,97,0.06)]",
                  plan.featured ? "border-[#1558d6] shadow-[0_20px_70px_rgba(21,88,214,0.14)]" : "border-[#d5e3f0]",
                )}
              >
                <div className="flex items-center justify-between gap-4">
                  <h3 className="text-xl font-semibold text-[#172033]">{plan.name}</h3>
                  {plan.featured && (
                    <span className="rounded-full bg-[#e8fbf7] px-3 py-1 text-xs font-semibold text-[#087865]">Recommended</span>
                  )}
                </div>
                <p className="mt-5 text-4xl font-semibold tracking-[-0.02em] text-[#111b2e]">
                  {plan.price}
                  <span className="text-base font-medium text-[#62728a]">/mo</span>
                </p>
                <p className="mt-3 min-h-[48px] text-sm leading-6 text-[#62728a]">{plan.note}</p>
                <div className="mt-6 h-px bg-[#dfe9f4]" />
                <ul className="mt-6 space-y-3">
                  {plan.features.map((item, index) => (
                    <li key={item} className="grid grid-cols-[14px_1fr] gap-3 text-sm text-[#344761]">
                      <span className={cn("mt-2 h-1.5 w-1.5 rounded-full", index % 2 === 0 ? "bg-[#1558d6]" : "bg-[#15c6a3]")} />
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
                <a
                  href={plan.featured ? "?demo=1" : "#final-cta"}
                  className={cn(
                    "mt-8 inline-flex h-11 w-full items-center justify-center rounded-[8px] text-sm font-semibold transition",
                    plan.featured
                      ? "bg-[#1558d6] text-white hover:bg-[#0f49b8]"
                      : "border border-[#c9d9ea] bg-white text-[#172033] hover:border-[#1558d6] hover:text-[#1558d6]",
                  )}
                >
                  {plan.featured ? "Open Desktop Demo" : "Talk to Sales"}
                </a>
              </article>
            ))}
          </div>
        </div>
      </MotionSection>

      <MotionSection id="faq" className="mx-auto grid max-w-7xl gap-10 px-5 py-20 sm:px-8 lg:grid-cols-[0.75fr_1.25fr]">
        <div>
          <p className="text-sm font-semibold text-[#1558d6]">FAQ</p>
          <h2 className="mt-3 text-3xl font-semibold tracking-[-0.015em] text-[#111b2e] sm:text-5xl">
            Answers for a desktop agent product.
          </h2>
        </div>
        <div className="space-y-3">
          {faqs.map((faq, index) => {
            const isOpen = openFaq === index;
            return (
              <div key={faq.question} className="rounded-[8px] border border-[#d5e3f0] bg-white">
                <button
                  type="button"
                  className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left"
                  aria-expanded={isOpen}
                  onClick={() => setOpenFaq(isOpen ? -1 : index)}
                >
                  <span className="text-base font-semibold text-[#172033]">{faq.question}</span>
                  <ChevronDown
                    className={cn("h-4 w-4 flex-none text-[#1558d6] transition-transform", isOpen && "rotate-180")}
                    aria-hidden="true"
                  />
                </button>
                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      initial={reducedMotion ? false : { height: 0, opacity: 0 }}
                      animate={reducedMotion ? undefined : { height: "auto", opacity: 1 }}
                      exit={reducedMotion ? undefined : { height: 0, opacity: 0 }}
                      transition={{ duration: 0.24, ease: [0.22, 1, 0.36, 1] }}
                      className="overflow-hidden"
                    >
                      <p className="px-5 pb-5 text-sm leading-6 text-[#62728a]">{faq.answer}</p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>
      </MotionSection>

      <MotionSection id="final-cta" className="border-t border-[#dbe7f4] bg-[#f0f7ff]">
        <div className="mx-auto grid max-w-7xl gap-8 px-5 py-16 sm:px-8 lg:grid-cols-[1fr_auto] lg:items-center">
          <div>
            <div className="mb-5 inline-flex items-center gap-2 rounded-[8px] border border-[#bdd2ea] bg-white px-3 py-2 text-sm font-semibold text-[#1558d6]">
              <ShieldCheck className="h-4 w-4" aria-hidden="true" />
              Reviewable by default
            </div>
            <h2 className="text-3xl font-semibold tracking-[-0.015em] text-[#111b2e] sm:text-5xl">
              Bring agentic workflows to your desktop.
            </h2>
            <p className="mt-4 max-w-2xl text-base leading-7 text-[#53677f]">
              Give agents context from the workspace, route tasks to the right lane, and keep every action ready for human review.
            </p>
          </div>
          <div className="flex flex-col gap-3 sm:flex-row lg:flex-col">
            <a
              href="?demo=1"
              className="inline-flex h-12 items-center justify-center gap-2 rounded-[8px] bg-[#1558d6] px-5 text-sm font-semibold text-white shadow-[0_16px_42px_rgba(21,88,214,0.2)] transition hover:bg-[#0f49b8]"
            >
              Open Desktop Demo
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </a>
            <a
              href="#pricing"
              className="inline-flex h-12 items-center justify-center rounded-[8px] border border-[#bfd2e6] bg-white px-5 text-sm font-semibold text-[#172033] transition hover:border-[#1558d6] hover:text-[#1558d6]"
            >
              Compare Plans
            </a>
          </div>
        </div>
      </MotionSection>
    </main>
  );
}

export default AgenticLandingPage;
