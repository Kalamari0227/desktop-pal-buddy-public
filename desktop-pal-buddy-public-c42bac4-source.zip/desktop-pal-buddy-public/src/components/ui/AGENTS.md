# Shared UI Primitives

This guide adds rules for `src/components/ui/`; inherit the root and `src/AGENTS.md` contracts.
These are reusable shadcn-style primitives and adapters, not workspace feature implementations.
Keep business workflows, database access, and approval decisions in their consuming feature layers.

## Configuration and Entry Points

- Root `components.json` selects the default shadcn style, TSX, and client React (`rsc: false`).
- Its `ui`, `utils`, and `hooks` aliases point to this directory, `@/lib/utils`, and `@/hooks`.
- `button.tsx` owns `Button`, `ButtonProps`, and the exported `buttonVariants` CVA contract.
- `pagination.tsx` consumes `buttonVariants`; changing button variants also affects link styling.
- `toggle-group.tsx` consumes `toggleVariants` from `toggle.tsx` through group context.
- `form.tsx` adapts React Hook Form; `sidebar.tsx` is a stateful composition of existing primitives.

## Wrapper Contracts

- Follow each file's underlying Radix primitive API instead of replacing it with custom interaction state.
- For Radix wrappers, derive refs with `React.ElementRef` and props with `React.ComponentPropsWithoutRef`.
- Preserve `React.forwardRef`, forwarded `...props`, and the wrapper's public named exports.
- Keep `displayName` assignments, using the wrapped primitive's name where the file already does so.
- Preserve `asChild`/`Slot` composition and pass the ref through to the rendered child.
- Do not introduce nested interactive elements when a consumer uses `asChild` for a link or trigger.
- Preserve `className` merging through `cn` and the existing CVA variant/default-variant interfaces.
- Forward controlled values and callbacks alongside default-value props; do not mirror them into independent state.
- In `SidebarProvider`, preserve `open`/`onOpenChange` control, `defaultOpen`, and separate mobile-open state.

## Accessibility and Overlays

- Preserve Radix portals, trigger/content relationships, dismissal behavior, and focus restoration.
- Keep `data-state`, `data-side`, disabled, and focus styles connected to the underlying primitive state.
- Keep dialog title/description wrappers and the accessible close-button text when changing dialog content.
- In `select.tsx`, preserve the viewport, item text/indicator, and scroll-button structure.
- In `form.tsx`, preserve generated control IDs, label association, error text, `aria-invalid`, and `aria-describedby`.

## Toast Paths

- `use-toast.ts` is a re-export shim for `@/hooks/use-toast`; toast state belongs in that hook.
- `toaster.tsx` renders that hook's queue with the Radix components in `toast.tsx`.
- `sonner.tsx` exports a separate Sonner `Toaster` and `toast`; do not mix its API with the hook-backed queue.

## Verification

- Check affected consumers when changing exported props, variants, refs, or composition behavior.
- For interaction changes, exercise the affected control with keyboard input, disabled state, and controlled props.
- For overlay changes, check open/close, Escape, focus return, and positioning in a real consuming view.
- Use relevant existing tests and typechecking for API changes; a primitive-only change does not require every suite.
