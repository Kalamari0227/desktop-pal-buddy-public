import { useRef, useMemo, useEffect } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
import { useCanvasStore } from "@/stores/canvasStore";

/**
 * AmbientCanvas — Level 1 background canvas
 * Persists NeuralScene after boot with dimmed nodes (40% opacity),
 * flattened camera (ortho-like wide FOV), and gentle ambient motion.
 */

const NODE_COUNT = 120;
const MAX_CONNECTIONS = 300;

const COL_NODE = new THREE.Color("#E6F1FF");
const COL_CONNECTION = new THREE.Color("#4DA3FF");

interface NetworkData {
  positions: Float32Array;
  connections: [number, number][];
}

function generateNetwork(): NetworkData {
  const positions = new Float32Array(NODE_COUNT * 3);
  positions[0] = 0;
  positions[1] = 0;
  positions[2] = 0;

  for (let i = 1; i < NODE_COUNT; i++) {
    const r = 1.5 + Math.random() * 4.5;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(2 * Math.random() - 1);
    positions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
    positions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
    positions[i * 3 + 2] = r * Math.cos(phi);
  }

  const connections: [number, number][] = [];
  const maxDist = 3.2;
  for (let i = 0; i < NODE_COUNT && connections.length < MAX_CONNECTIONS; i++) {
    for (let j = i + 1; j < NODE_COUNT && connections.length < MAX_CONNECTIONS; j++) {
      const dx = positions[i * 3] - positions[j * 3];
      const dy = positions[i * 3 + 1] - positions[j * 3 + 1];
      const dz = positions[i * 3 + 2] - positions[j * 3 + 2];
      if (Math.sqrt(dx * dx + dy * dy + dz * dz) < maxDist) {
        connections.push([i, j]);
      }
    }
  }
  return { positions, connections };
}

/* ── Dimmed Particles ── */
function DimmedParticles({ network }: { network: NetworkData }) {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  const baseScales = useMemo(
    () => Array.from({ length: NODE_COUNT }, () => 0.02 + Math.random() * 0.025),
    []
  );

  // Flatten z over time
  const flattenProgress = useRef(0);

  useFrame((_, delta) => {
    if (!meshRef.current) return;
    flattenProgress.current = Math.min(1, flattenProgress.current + delta * 0.3);
    const fp = flattenProgress.current;

    for (let i = 0; i < NODE_COUNT; i++) {
      const s = baseScales[i];
      const origZ = network.positions[i * 3 + 2];
      const z = origZ * (1 - fp * 0.85); // flatten z to ~15% of original

      dummy.position.set(
        network.positions[i * 3],
        network.positions[i * 3 + 1],
        z
      );
      dummy.scale.set(s, s, s);
      dummy.updateMatrix();
      meshRef.current.setMatrixAt(i, dummy.matrix);
      meshRef.current.setColorAt(i, COL_NODE);
    }
    meshRef.current.instanceMatrix.needsUpdate = true;
    if (meshRef.current.instanceColor) meshRef.current.instanceColor.needsUpdate = true;
  });

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, NODE_COUNT]}>
      <sphereGeometry args={[1, 8, 8]} />
      <meshBasicMaterial transparent opacity={0.4} toneMapped={false} />
    </instancedMesh>
  );
}

/* ── Dimmed Connections ── */
function DimmedConnections({ network }: { network: NetworkData }) {
  const linesRef = useRef<THREE.LineSegments>(null);
  const flattenProgress = useRef(0);

  const geometry = useMemo(() => {
    const geo = new THREE.BufferGeometry();
    const verts = new Float32Array(network.connections.length * 6);
    const colors = new Float32Array(network.connections.length * 6);

    network.connections.forEach(([a, b], idx) => {
      verts[idx * 6] = network.positions[a * 3];
      verts[idx * 6 + 1] = network.positions[a * 3 + 1];
      verts[idx * 6 + 2] = network.positions[a * 3 + 2];
      verts[idx * 6 + 3] = network.positions[b * 3];
      verts[idx * 6 + 4] = network.positions[b * 3 + 1];
      verts[idx * 6 + 5] = network.positions[b * 3 + 2];
    });

    geo.setAttribute("position", new THREE.BufferAttribute(verts, 3));
    geo.setAttribute("color", new THREE.BufferAttribute(colors, 3));
    return geo;
  }, [network]);

  useFrame((_, delta) => {
    if (!linesRef.current) return;
    flattenProgress.current = Math.min(1, flattenProgress.current + delta * 0.3);
    const fp = flattenProgress.current;

    const posAttr = geometry.getAttribute("position") as THREE.BufferAttribute;
    const posArray = posAttr.array as Float32Array;
    const colAttr = geometry.getAttribute("color") as THREE.BufferAttribute;
    const colArray = colAttr.array as Float32Array;

    network.connections.forEach(([a, b], idx) => {
      // Flatten z
      posArray[idx * 6 + 2] = network.positions[a * 3 + 2] * (1 - fp * 0.85);
      posArray[idx * 6 + 5] = network.positions[b * 3 + 2] * (1 - fp * 0.85);

      // Dimmed color
      colArray[idx * 6] = COL_CONNECTION.r * 0.3;
      colArray[idx * 6 + 1] = COL_CONNECTION.g * 0.3;
      colArray[idx * 6 + 2] = COL_CONNECTION.b * 0.3;
      colArray[idx * 6 + 3] = COL_CONNECTION.r * 0.3;
      colArray[idx * 6 + 4] = COL_CONNECTION.g * 0.3;
      colArray[idx * 6 + 5] = COL_CONNECTION.b * 0.3;
    });

    posAttr.needsUpdate = true;
    colAttr.needsUpdate = true;
  });

  return (
    <lineSegments ref={linesRef} geometry={geometry}>
      <lineBasicMaterial vertexColors transparent opacity={0.2} toneMapped={false} />
    </lineSegments>
  );
}

/* ── Flattened Camera ── */
function FlatCamera() {
  const { camera } = useThree();

  useFrame(() => {
    // Wide, nearly top-down view — "flattened" perspective
    const targetZ = 14;
    camera.position.z += (targetZ - camera.position.z) * 0.02;
    camera.position.x *= 0.98; // center
    camera.position.y *= 0.98;
    camera.lookAt(0, 0, 0);
  });

  return null;
}

/* ── Ambient Glow ── */
function AmbientGlow() {
  const meshRef = useRef<THREE.Mesh>(null);

  useFrame(() => {
    if (!meshRef.current) return;
    meshRef.current.scale.set(8, 8, 8);
    const mat = meshRef.current.material as THREE.MeshBasicMaterial;
    mat.opacity = 0.02;
  });

  return (
    <mesh ref={meshRef} renderOrder={-1}>
      <sphereGeometry args={[1, 16, 16]} />
      <meshBasicMaterial
        color={COL_CONNECTION}
        transparent
        opacity={0.02}
        toneMapped={false}
        depthWrite={false}
        side={THREE.BackSide}
      />
    </mesh>
  );
}

/* ── Scene ── */
function AmbientScene() {
  const network = useMemo(() => generateNetwork(), []);
  const setTransitionState = useCanvasStore((s) => s.setTransitionState);

  useEffect(() => {
    setTransitionState("flatten");
    const t = setTimeout(() => setTransitionState("canvas_init"), 3000);
    return () => clearTimeout(t);
  }, [setTransitionState]);

  return (
    <>
      <FlatCamera />
      <AmbientGlow />
      <DimmedParticles network={network} />
      <DimmedConnections network={network} />
    </>
  );
}

/* ── Exported Component ── */
export function AmbientCanvas() {
  return (
    <div className="absolute inset-0 pointer-events-none">
      <Canvas
        camera={{ position: [0, 0, 10], fov: 60, near: 0.1, far: 100 }}
        gl={{ antialias: true, alpha: true }}
        style={{ background: "transparent" }}
        dpr={[1, 1.5]}
      >
        <AmbientScene />
      </Canvas>
    </div>
  );
}
