import { useRef, useMemo, useEffect } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { useReducedMotion } from "framer-motion";
import * as THREE from "three";
import { useCanvasStore } from "@/stores/canvasStore";
import { useCanvasData } from "@/hooks/useCanvasData";
import { KnowledgeNodes, KnowledgeEdges } from "./KnowledgeLayer";
import { getCanvasQuality } from "./canvasQuality";

/**
 * UnifiedCanvas — Single R3F canvas shared between Boot and Ambient modes.
 * 
 * Boot phase: full brightness, 3D camera zoom, animated connections
 * Post-boot: smoothly flattens z, dims to 40%, camera pulls to wide top-down
 */

export interface DebugToggles {
  bootNetwork: boolean;
  seedNode: boolean;
  knowledge: boolean;
  debugStamp: boolean;
  freeze: boolean;
}

const COL_NODE = new THREE.Color("#E6F1FF");
const COL_CONNECTION = new THREE.Color("#4DA3FF");
const COL_PULSE = new THREE.Color("#00E5FF");
const COL_HIGHLIGHT = new THREE.Color("#9A7DFF");

interface NetworkData {
  positions: Float32Array;
  connections: [number, number][];
  nodeCount: number;
}

function generateNetwork(nodeCount: number, maxConnections: number): NetworkData {
  const positions = new Float32Array(nodeCount * 3);
  positions[0] = 0;
  positions[1] = 0;
  positions[2] = 0;

  for (let i = 1; i < nodeCount; i++) {
    const r = 1.5 + Math.random() * 4.5;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(2 * Math.random() - 1);
    positions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
    positions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
    positions[i * 3 + 2] = r * Math.cos(phi);
  }

  const connections: [number, number][] = [];
  const maxDist = 3.2;
  for (let i = 0; i < nodeCount && connections.length < maxConnections; i++) {
    for (let j = i + 1; j < nodeCount && connections.length < maxConnections; j++) {
      const dx = positions[i * 3] - positions[j * 3];
      const dy = positions[i * 3 + 1] - positions[j * 3 + 1];
      const dz = positions[i * 3 + 2] - positions[j * 3 + 2];
      if (Math.sqrt(dx * dx + dy * dy + dz * dz) < maxDist) {
        connections.push([i, j]);
      }
    }
  }
  return { positions, connections, nodeCount };
}

function publishCanvasMetrics(sample: {
  fps: number;
  nodeCount: number;
  connectionCount: number;
  reduceMotion: boolean;
  loadTimeMs: number;
}) {
  if (typeof window === "undefined") return;
  window.__prometheusCanvasMetrics = {
    ...sample,
    sampledAt: new Date().toISOString(),
  };
}

/* ─────────────────────── Particles ─────────────────────── */
function Particles({
  network,
  elapsed,
  ambientProgress,
  hideSeedNode,
  debugStamp,
}: {
  network: NetworkData;
  elapsed: React.MutableRefObject<number>;
  ambientProgress: React.MutableRefObject<number>;
  hideSeedNode?: boolean;
  debugStamp?: boolean;
}) {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  const baseScales = useMemo(
    () => Array.from({ length: network.nodeCount }, () => 0.02 + Math.random() * 0.03),
    [network.nodeCount]
  );
  const spawnTime = useMemo(
    () => Array.from({ length: network.nodeCount }, (_, i) => (i === 0 ? 0 : 1.5 + Math.random() * 2)),
    [network.nodeCount]
  );

  useFrame(() => {
    if (!meshRef.current) return;
    const t = elapsed.current;
    const ap = ambientProgress.current; // 0 = boot, 1 = fully ambient

    // Target opacity: 0.9 in boot → 0.25 in ambient (more subtle)
    const mat = meshRef.current.material as THREE.MeshBasicMaterial;
    mat.opacity = 0.9 - ap * 0.65;

    for (let i = 0; i < network.nodeCount; i++) {
      const alive = Math.max(0, Math.min(1, (t - spawnTime[i]) * 1.2));
      const shouldHideNode = alive <= 0 || (i === 0 && hideSeedNode);

      if (shouldHideNode) {
        dummy.scale.set(0, 0, 0);
      } else {
        const breathe = i === 0 ? 1 + 0.2 * Math.sin(t * 2.5) * (1 - ap) : 1;
        const s = baseScales[i] * alive * breathe * (i === 0 ? 3 - ap * 2 : 1);

        // Flatten z during ambient transition
        const flatZ = network.positions[i * 3 + 2] * (1 - ap * 0.85);

        dummy.position.set(
          network.positions[i * 3],
          network.positions[i * 3 + 1],
          flatZ
        );
        dummy.scale.set(s, s, s);
      }
      dummy.updateMatrix();
      meshRef.current.setMatrixAt(i, dummy.matrix);

      // Color: highlight center in boot, uniform dimmed in ambient
      // Debug stamp: seed node = hot pink
      const color =
        i === 0 && debugStamp
          ? new THREE.Color("#FF00FF")
          : i === 0 && ap < 0.5
            ? COL_HIGHLIGHT.clone().lerp(COL_PULSE, 0.3 + 0.3 * Math.sin(t * 3))
            : COL_NODE;
      meshRef.current.setColorAt(i, color);
    }
    meshRef.current.instanceMatrix.needsUpdate = true;
    if (meshRef.current.instanceColor) meshRef.current.instanceColor.needsUpdate = true;
  });

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, network.nodeCount]}>
      <sphereGeometry args={[1, 12, 12]} />
      <meshBasicMaterial transparent opacity={0.9} toneMapped={false} />
    </instancedMesh>
  );
}

/* ─────────────────────── Connections ─────────────────────── */
function Connections({
  network,
  elapsed,
  ambientProgress,
  hideSeedNode,
}: {
  network: NetworkData;
  elapsed: React.MutableRefObject<number>;
  ambientProgress: React.MutableRefObject<number>;
  hideSeedNode?: boolean;
}) {
  const linesRef = useRef<THREE.LineSegments>(null);

  const { geometry, colorArray } = useMemo(() => {
    const geo = new THREE.BufferGeometry();
    const verts = new Float32Array(network.connections.length * 6);
    const colors = new Float32Array(network.connections.length * 6);

    network.connections.forEach(([a, b], idx) => {
      verts[idx * 6] = network.positions[a * 3];
      verts[idx * 6 + 1] = network.positions[a * 3 + 1];
      verts[idx * 6 + 2] = network.positions[a * 3 + 2];
      verts[idx * 6 + 3] = network.positions[b * 3];
      verts[idx * 6 + 4] = network.positions[b * 3 + 1];
      verts[idx * 6 + 5] = network.positions[b * 3 + 2];
    });

    geo.setAttribute("position", new THREE.BufferAttribute(verts, 3));
    geo.setAttribute("color", new THREE.BufferAttribute(colors, 3));
    return { geometry: geo, colorArray: colors };
  }, [network]);

  useFrame(() => {
    if (!linesRef.current) return;
    const t = elapsed.current;
    const ap = ambientProgress.current;

    // Boot: connections form from 3.5s–7s. Ambient: all visible, dimmed.
    const connectionProgress = Math.max(0, Math.min(1, (t - 3.5) / 3.5));
    const visibleCount = Math.floor(connectionProgress * network.connections.length);

    const posAttr = geometry.getAttribute("position") as THREE.BufferAttribute;
    const posArray = posAttr.array as Float32Array;
    const colAttr = geometry.getAttribute("color") as THREE.BufferAttribute;

    for (let i = 0; i < network.connections.length; i++) {
      const visible = i < visibleCount;
      const [a, b] = network.connections[i];
      const touchesSeedNode = a === 0 || b === 0;

      // Flatten z
      posArray[idx6(i, 2)] = network.positions[a * 3 + 2] * (1 - ap * 0.85);
      posArray[idx6(i, 5)] = network.positions[b * 3 + 2] * (1 - ap * 0.85);

      if (visible && !(hideSeedNode && touchesSeedNode)) {
        const pulsePhase = (t * 1.5 + i * 0.3) % 1;
        const pulseIntensity = Math.exp(-((pulsePhase - 0.5) ** 2) * 20) * (1 - ap);
        const color = COL_CONNECTION.clone().lerp(COL_PULSE, pulseIntensity * 0.6);
        const fadeIn = Math.min(1, (connectionProgress * network.connections.length - i) * 0.3);
        const dim = 1 - ap * 0.8; // dim to 20% in ambient
        colorArray[i * 6] = color.r * fadeIn * dim;
        colorArray[i * 6 + 1] = color.g * fadeIn * dim;
        colorArray[i * 6 + 2] = color.b * fadeIn * dim;
        colorArray[i * 6 + 3] = color.r * fadeIn * dim;
        colorArray[i * 6 + 4] = color.g * fadeIn * dim;
        colorArray[i * 6 + 5] = color.b * fadeIn * dim;
      } else {
        for (let j = 0; j < 6; j++) colorArray[i * 6 + j] = 0;
      }
    }

    posAttr.needsUpdate = true;
    colAttr.needsUpdate = true;

    // Line opacity: boot=0.5, ambient=0.08
    const mat = linesRef.current.material as THREE.LineBasicMaterial;
    mat.opacity = 0.5 - ap * 0.42;
  });

  return (
    <lineSegments ref={linesRef} geometry={geometry}>
      <lineBasicMaterial vertexColors transparent opacity={0.5} toneMapped={false} />
    </lineSegments>
  );
}

function idx6(i: number, offset: number) {
  return i * 6 + offset;
}

/* ─────────────────────── Signal Pulses ─────────────────────── */
function SignalPulses({
  network,
  elapsed,
  ambientProgress,
  hideSeedNode,
  pulseCount,
}: {
  network: NetworkData;
  elapsed: React.MutableRefObject<number>;
  ambientProgress: React.MutableRefObject<number>;
  hideSeedNode?: boolean;
  pulseCount: number;
}) {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);

  const pulseData = useMemo(
    () =>
      Array.from({ length: pulseCount }, () => ({
        connIdx: Math.floor(Math.random() * network.connections.length),
        speed: 0.4 + Math.random() * 1.0,
        offset: Math.random() * 10,
      })),
    [network, pulseCount]
  );

  useFrame(() => {
    if (!meshRef.current) return;
    const t = elapsed.current;
    const ap = ambientProgress.current;

    // Pulses fade out during ambient transition
    const pulseAlpha = Math.max(0, Math.min(1, (t - 4) / 2)) * (1 - ap);

    for (let i = 0; i < pulseCount; i++) {
      if (pulseAlpha <= 0.01) {
        dummy.scale.set(0, 0, 0);
        dummy.updateMatrix();
        meshRef.current.setMatrixAt(i, dummy.matrix);
        continue;
      }

      const { connIdx, speed, offset } = pulseData[i];
      if (connIdx >= network.connections.length) {
        dummy.scale.set(0, 0, 0);
        dummy.updateMatrix();
        meshRef.current.setMatrixAt(i, dummy.matrix);
        continue;
      }

      const [a, b] = network.connections[connIdx];
      if (hideSeedNode && (a === 0 || b === 0)) {
        dummy.scale.set(0, 0, 0);
        dummy.updateMatrix();
        meshRef.current.setMatrixAt(i, dummy.matrix);
        continue;
      }

      const progress = ((t * speed + offset) % 1);

      const px = network.positions[a * 3] + (network.positions[b * 3] - network.positions[a * 3]) * progress;
      const py = network.positions[a * 3 + 1] + (network.positions[b * 3 + 1] - network.positions[a * 3 + 1]) * progress;
      const origPz = network.positions[a * 3 + 2] + (network.positions[b * 3 + 2] - network.positions[a * 3 + 2]) * progress;
      const pz = origPz * (1 - ap * 0.85);

      dummy.position.set(px, py, pz);
      const s = 0.035 * pulseAlpha;
      dummy.scale.set(s, s, s);
      dummy.updateMatrix();
      meshRef.current.setMatrixAt(i, dummy.matrix);
      meshRef.current.setColorAt(i, COL_PULSE);
    }
    meshRef.current.instanceMatrix.needsUpdate = true;
    if (meshRef.current.instanceColor) meshRef.current.instanceColor.needsUpdate = true;
  });

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, pulseCount]}>
      <sphereGeometry args={[1, 8, 8]} />
      <meshBasicMaterial transparent opacity={0.8} toneMapped={false} />
    </instancedMesh>
  );
}

/* ─────────────────────── Camera ─────────────────────── */
function UnifiedCamera({
  elapsed,
  ambientProgress,
  reduceMotion,
}: {
  elapsed: React.MutableRefObject<number>;
  ambientProgress: React.MutableRefObject<number>;
  reduceMotion: boolean;
}) {
  const { camera } = useThree();

  useFrame(() => {
    const t = elapsed.current;
    const ap = ambientProgress.current;

    // Boot camera: progressive zoom out
    let bootZ: number;
    if (t < 2) bootZ = 3.5;
    else if (t < 4) bootZ = 3.5 + (t - 2) * 0.75;
    else if (t < 7) bootZ = 5 + (t - 4) * 1.2;
    else bootZ = 8.6 + (t - 7) * 0.8;

    // Ambient camera: wide top-down
    const ambientZ = 16;

    const targetZ = bootZ + (ambientZ - bootZ) * ap;
    camera.position.z += (targetZ - camera.position.z) * (reduceMotion ? 0.2 : 0.03);

    // Boot: gentle orbit. Ambient: center.
    const orbitStrength = reduceMotion ? 0 : 1 - ap;
    const angle = t * 0.06;
    camera.position.x += (Math.sin(angle) * 0.4 * orbitStrength - camera.position.x) * 0.03;
    camera.position.y += (Math.cos(angle * 0.7) * 0.25 * orbitStrength - camera.position.y) * 0.03;

    camera.lookAt(0, 0, 0);
  });

  return null;
}

/* ─────────────────────── Ambient Glow ─────────────────────── */
function AmbientGlow({
  elapsed,
  ambientProgress,
}: {
  elapsed: React.MutableRefObject<number>;
  ambientProgress: React.MutableRefObject<number>;
}) {
  const meshRef = useRef<THREE.Mesh>(null);

  useFrame(() => {
    if (!meshRef.current) return;
    const t = elapsed.current;
    const ap = ambientProgress.current;
    const scale = 3 + t * 0.6;
    meshRef.current.scale.set(scale, scale, scale);
    const mat = meshRef.current.material as THREE.MeshBasicMaterial;
    // Reduce glow in ambient
    mat.opacity = (0.03 + 0.015 * Math.sin(t * 1.5)) * (1 - ap * 0.5);
  });

  return (
    <mesh ref={meshRef} renderOrder={-1}>
      <sphereGeometry args={[1, 16, 16]} />
      <meshBasicMaterial
        color={COL_CONNECTION}
        transparent
        opacity={0.03}
        toneMapped={false}
        depthWrite={false}
        side={THREE.BackSide}
      />
    </mesh>
  );
}

/* ─────────────────────── Scene ─────────────────────── */
function UnifiedScene({
  bootComplete,
  onElapsedRef,
  debugToggles,
  reduceMotion,
}: {
  bootComplete: boolean;
  onElapsedRef?: (ref: React.MutableRefObject<number>) => void;
  debugToggles?: DebugToggles;
  reduceMotion: boolean;
}) {
  const elapsed = useRef(0);
  const ambientProgress = useRef(0);
  const quality = useMemo(() => getCanvasQuality(reduceMotion), [reduceMotion]);
  const network = useMemo(() => generateNetwork(quality.nodeCount, quality.maxConnections), [quality]);
  const cbCalled = useRef(false);
  const metrics = useRef({ frames: 0, seconds: 0 });
  const loadStartedAt = useRef(typeof performance === "undefined" ? Date.now() : performance.now());
  const setTransitionState = useCanvasStore((s) => s.setTransitionState);

  useEffect(() => {
    if (bootComplete) {
      setTransitionState("flatten");
    }
  }, [bootComplete, setTransitionState]);

  useFrame((_, delta) => {
    metrics.current.frames += 1;
    metrics.current.seconds += delta;
    if (metrics.current.seconds >= 1) {
      publishCanvasMetrics({
        fps: Math.round(metrics.current.frames / metrics.current.seconds),
        nodeCount: network.nodeCount,
        connectionCount: network.connections.length,
        reduceMotion,
        loadTimeMs: Math.round((typeof performance === "undefined" ? Date.now() : performance.now()) - loadStartedAt.current),
      });
      metrics.current = { frames: 0, seconds: 0 };
    }

    // Freeze frame support: stop time progression
    if (reduceMotion) {
      elapsed.current = bootComplete ? 10 : Math.min(elapsed.current + Math.min(delta, 0.016), 2);
      ambientProgress.current = bootComplete ? 1 : 0;
    } else if (!debugToggles?.freeze) {
      elapsed.current += delta;

      // Smoothly ramp ambientProgress from 0→1 over ~5s after boot completes
      if (bootComplete) {
        ambientProgress.current = Math.min(1, ambientProgress.current + delta * 0.2);
      }
    }

    if (!cbCalled.current && onElapsedRef) {
      cbCalled.current = true;
      onElapsedRef(elapsed);
    }
  });

  const showBoot = debugToggles?.bootNetwork !== false;
  const showKnowledge = debugToggles?.knowledge !== false;
  const hideSeedNode = debugToggles?.seedNode === false;

  return (
    <>
      <UnifiedCamera elapsed={elapsed} ambientProgress={ambientProgress} reduceMotion={reduceMotion} />
      {showBoot && <AmbientGlow elapsed={elapsed} ambientProgress={ambientProgress} />}
      {showBoot && (
        <Particles
          network={network}
          elapsed={elapsed}
          ambientProgress={ambientProgress}
          hideSeedNode={hideSeedNode}
          debugStamp={debugToggles?.debugStamp}
        />
      )}
      {showBoot && (
        <Connections
          network={network}
          elapsed={elapsed}
          ambientProgress={ambientProgress}
          hideSeedNode={hideSeedNode}
        />
      )}
      {showBoot && quality.pulseCount > 0 && (
        <SignalPulses
          network={network}
          elapsed={elapsed}
          ambientProgress={ambientProgress}
          hideSeedNode={hideSeedNode}
          pulseCount={quality.pulseCount}
        />
      )}
      {/* Knowledge graph layer — fades in during ambient */}
      {showKnowledge && <KnowledgeEdges ambientProgress={ambientProgress} debugStamp={debugToggles?.debugStamp} />}
      {showKnowledge && <KnowledgeNodes ambientProgress={ambientProgress} debugStamp={debugToggles?.debugStamp} />}
    </>
  );
}

/* ─────────────────────── Exported Canvas ─────────────────────── */
interface UnifiedCanvasProps {
  bootComplete: boolean;
  onElapsedRef?: (ref: React.MutableRefObject<number>) => void;
  debugToggles?: DebugToggles;
}

export function UnifiedCanvas({ bootComplete, onElapsedRef, debugToggles }: UnifiedCanvasProps) {
  // Fetch DB nodes/edges once boot completes
  useCanvasData(bootComplete);
  const reduceMotion = Boolean(useReducedMotion());
  const quality = getCanvasQuality(reduceMotion);

  return (
    <div
      className="absolute inset-0"
      role="img"
      aria-label="Prometheus knowledge network background"
      style={{ pointerEvents: "auto" }}
    >
      <Canvas
        camera={{ position: [0, 0, 3.5], fov: 60, near: 0.1, far: 100 }}
        gl={{ antialias: true, alpha: false }}
        onCreated={({ gl }) => {
          gl.setClearColor(new THREE.Color("hsl(220, 40%, 8%)"), 1);
        }}
        dpr={[1, quality.maxDpr]}
        eventPrefix="client"
      >
        <color attach="background" args={["hsl(220, 40%, 8%)"]} />
        <UnifiedScene
          bootComplete={bootComplete}
          onElapsedRef={onElapsedRef}
          debugToggles={debugToggles}
          reduceMotion={reduceMotion}
        />
      </Canvas>
    </div>
  );
}
