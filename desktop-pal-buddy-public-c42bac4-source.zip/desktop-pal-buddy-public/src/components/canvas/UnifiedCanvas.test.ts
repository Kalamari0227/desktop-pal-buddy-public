import { describe, expect, it } from "vitest";
import { getCanvasQuality } from "./canvasQuality";

describe("UnifiedCanvas quality", () => {
  it("uses a smaller static scene for reduced motion", () => {
    expect(getCanvasQuality(true)).toEqual({
      nodeCount: 48,
      maxConnections: 90,
      pulseCount: 0,
      maxDpr: 1,
    });
  });

  it("keeps the full network when motion is allowed", () => {
    expect(getCanvasQuality(false)).toEqual({
      nodeCount: 120,
      maxConnections: 300,
      pulseCount: 30,
      maxDpr: 2,
    });
  });
});
