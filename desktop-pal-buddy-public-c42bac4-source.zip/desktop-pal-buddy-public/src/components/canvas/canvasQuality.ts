const DEFAULT_NODE_COUNT = 120;
const DEFAULT_MAX_CONNECTIONS = 300;
const REDUCED_NODE_COUNT = 48;
const REDUCED_MAX_CONNECTIONS = 90;

export function getCanvasQuality(reduceMotion: boolean) {
  return reduceMotion
    ? { nodeCount: REDUCED_NODE_COUNT, maxConnections: REDUCED_MAX_CONNECTIONS, pulseCount: 0, maxDpr: 1 }
    : { nodeCount: DEFAULT_NODE_COUNT, maxConnections: DEFAULT_MAX_CONNECTIONS, pulseCount: 30, maxDpr: 2 };
}
