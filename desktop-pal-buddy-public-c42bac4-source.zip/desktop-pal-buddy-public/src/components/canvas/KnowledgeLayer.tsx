import { useRef, useMemo, useState, useCallback, useEffect } from "react";
import { useFrame, ThreeEvent } from "@react-three/fiber";
import { Html } from "@react-three/drei";
import * as THREE from "three";
import { useCanvasStore, type CanvasNodeUI } from "@/stores/canvasStore";

/**
 * Node type → color mapping
 */
const NODE_COLORS: Record<string, string> = {
  customer: "#FFB74D",   // warm amber
  memo: "#81D4FA",       // light blue
  meeting: "#CE93D8",    // purple
  action: "#A5D6A7",     // green
  risk: "#EF9A9A",       // red
  document: "#90CAF9",   // blue
  project: "#FFD54F",    // gold
  issue: "#FFAB91",      // orange
  ai_insight: "#80CBC4", // teal
  product: "#B0BEC5",    // grey-blue
  report: "#9FA8DA",     // indigo
};

const DEFAULT_COLOR = "#B0BEC5";
const KNOWLEDGE_REVEAL_START = 0.3;
const KNOWLEDGE_REVEAL_SPAN = 0.7;

function getNodeColor(type: string): THREE.Color {
  return new THREE.Color(NODE_COLORS[type] || DEFAULT_COLOR);
}

/* ─────────────────── Knowledge Nodes (InstancedMesh) ─────────────────── */
export function KnowledgeNodes({
  ambientProgress,
  debugStamp,
}: {
  ambientProgress: React.MutableRefObject<number>;
  debugStamp?: boolean;
}) {
  const nodes = useCanvasStore((s) => s.graph.nodes);
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);

  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);
  const hoveredRef = useRef<number | null>(null);

  const tmpColor = useMemo(() => new THREE.Color(), []);

  useEffect(() => {
    if (!meshRef.current || nodes.length === 0) return;

    const hiddenDummy = new THREE.Object3D();
    hiddenDummy.scale.set(0, 0, 0);
    hiddenDummy.updateMatrix();

    for (let i = 0; i < nodes.length; i++) {
      meshRef.current.setMatrixAt(i, hiddenDummy.matrix);
    }

    meshRef.current.instanceMatrix.needsUpdate = true;
    if (meshRef.current.instanceColor) meshRef.current.instanceColor.needsUpdate = true;

    const mat = meshRef.current.material as THREE.MeshBasicMaterial;
    mat.opacity = 0;
  }, [nodes.length]);

  const handlePointerOver = useCallback((e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    const id = e.instanceId ?? null;
    if (id !== hoveredRef.current) {
      hoveredRef.current = id;
      setHoveredIndex(id);
    }
  }, []);

  const handlePointerOut = useCallback((e: ThreeEvent<PointerEvent>) => {
    e.stopPropagation();
    hoveredRef.current = null;
    setHoveredIndex(null);
  }, []);

  useFrame(() => {
    if (!meshRef.current || nodes.length === 0) return;
    const ap = ambientProgress.current;
    const mat = meshRef.current.material as THREE.MeshBasicMaterial;

    if (ap < KNOWLEDGE_REVEAL_START) {
      mat.opacity = 0;
      return;
    }

    const fadeIn = Math.min(1, (ap - KNOWLEDGE_REVEAL_START) / KNOWLEDGE_REVEAL_SPAN);
    mat.opacity = 0.85 * fadeIn;

    for (let i = 0; i < nodes.length; i++) {
      const node = nodes[i];
      const isHovered = i === hoveredRef.current;

      const baseSize = 0.08 + node.importance_score * 0.12;
      const hoverScale = isHovered ? 1.6 : 1;
      const s = baseSize * fadeIn * hoverScale;

      dummy.position.set(node.x, node.y, node.z * (1 - ap * 0.85));
      dummy.scale.set(s, s, s);
      dummy.updateMatrix();
      meshRef.current.setMatrixAt(i, dummy.matrix);

      const baseColor = debugStamp ? new THREE.Color("#00FF00") : getNodeColor(node.type);
      if (isHovered) {
        tmpColor.set("#FFFFFF").lerp(baseColor, 0.4);
      } else {
        tmpColor.copy(baseColor);
      }
      meshRef.current.setColorAt(i, tmpColor);
    }

    meshRef.current.instanceMatrix.needsUpdate = true;
    if (meshRef.current.instanceColor) meshRef.current.instanceColor.needsUpdate = true;
  });

  if (nodes.length === 0) return null;

  const hoveredNode = hoveredIndex !== null ? nodes[hoveredIndex] : null;

  return (
    <>
      <instancedMesh
        ref={meshRef}
        args={[undefined, undefined, nodes.length]}
        frustumCulled={false}
        onPointerOver={handlePointerOver}
        onPointerOut={handlePointerOut}
      >
        <sphereGeometry args={[1, 16, 16]} />
        <meshBasicMaterial transparent opacity={0} toneMapped={false} />
      </instancedMesh>

      {hoveredNode && (
        <mesh
          position={[hoveredNode.x, hoveredNode.y, hoveredNode.z * 0.15]}
          scale={[0.35, 0.35, 0.35]}
        >
          <ringGeometry args={[0.8, 1.0, 32]} />
          <meshBasicMaterial
            color={getNodeColor(hoveredNode.type)}
            transparent
            opacity={0.4}
            toneMapped={false}
            side={THREE.DoubleSide}
          />
        </mesh>
      )}

      {hoveredNode && (
        <Html
          position={[hoveredNode.x, hoveredNode.y + 0.4, hoveredNode.z * 0.15]}
          center
          style={{ pointerEvents: "none" }}
        >
          <NodeTooltip node={hoveredNode} />
        </Html>
      )}
    </>
  );
}

/* ─────────────────── Knowledge Edges ─────────────────── */
export function KnowledgeEdges({
  ambientProgress,
  debugStamp,
}: {
  ambientProgress: React.MutableRefObject<number>;
  debugStamp?: boolean;
}) {
  const nodes = useCanvasStore((s) => s.graph.nodes);
  const edges = useCanvasStore((s) => s.graph.edges);
  const linesRef = useRef<THREE.LineSegments>(null);

  const nodeMap = useMemo(() => {
    const m = new Map<string, CanvasNodeUI>();
    nodes.forEach((n) => m.set(n.id, n));
    return m;
  }, [nodes]);

  const { geometry, colorArray } = useMemo(() => {
    if (edges.length === 0)
      return { geometry: new THREE.BufferGeometry(), colorArray: new Float32Array(0) };

    const geo = new THREE.BufferGeometry();
    const verts = new Float32Array(edges.length * 6);
    const colors = new Float32Array(edges.length * 6);
    geo.setAttribute("position", new THREE.BufferAttribute(verts, 3));
    geo.setAttribute("color", new THREE.BufferAttribute(colors, 3));
    return { geometry: geo, colorArray: colors };
  }, [edges.length]);

  useEffect(() => {
    if (!linesRef.current || edges.length === 0) return;

    colorArray.fill(0);
    const colAttr = geometry.getAttribute("color") as THREE.BufferAttribute;
    colAttr.needsUpdate = true;

    const mat = linesRef.current.material as THREE.LineBasicMaterial;
    mat.opacity = 0;
  }, [colorArray, edges.length, geometry]);

  useFrame(() => {
    if (!linesRef.current || edges.length === 0 || nodes.length === 0) return;
    const ap = ambientProgress.current;
    const mat = linesRef.current.material as THREE.LineBasicMaterial;

    if (ap < KNOWLEDGE_REVEAL_START) {
      mat.opacity = 0;
      return;
    }

    const fadeIn = Math.min(1, (ap - KNOWLEDGE_REVEAL_START) / KNOWLEDGE_REVEAL_SPAN);
    const posAttr = geometry.getAttribute("position") as THREE.BufferAttribute;
    const posArray = posAttr.array as Float32Array;
    const colAttr = geometry.getAttribute("color") as THREE.BufferAttribute;

    edges.forEach((edge, i) => {
      const src = nodeMap.get(edge.source_id);
      const tgt = nodeMap.get(edge.target_id);
      if (!src || !tgt) return;
      const flatMul = 1 - ap * 0.85;
      posArray[i * 6] = src.x;
      posArray[i * 6 + 1] = src.y;
      posArray[i * 6 + 2] = src.z * flatMul;
      posArray[i * 6 + 3] = tgt.x;
      posArray[i * 6 + 4] = tgt.y;
      posArray[i * 6 + 5] = tgt.z * flatMul;

      // Color based on status
      const isSuggested = edge.status === "suggested";
      const alpha = fadeIn * (isSuggested ? 0.25 : 0.45) * edge.confidence_score;
      const col = debugStamp
        ? new THREE.Color("#00FF00")
        : isSuggested ? new THREE.Color("#9A7DFF") : new THREE.Color("#4DA3FF");

      colorArray[i * 6] = col.r * alpha;
      colorArray[i * 6 + 1] = col.g * alpha;
      colorArray[i * 6 + 2] = col.b * alpha;
      colorArray[i * 6 + 3] = col.r * alpha;
      colorArray[i * 6 + 4] = col.g * alpha;
      colorArray[i * 6 + 5] = col.b * alpha;
    });

    posAttr.needsUpdate = true;
    colAttr.needsUpdate = true;
    mat.opacity = fadeIn * 0.6;
  });

  if (edges.length === 0) return null;

  return (
    <lineSegments ref={linesRef} geometry={geometry}>
      <lineBasicMaterial vertexColors transparent opacity={0} toneMapped={false} />
    </lineSegments>
  );
}

/* ─────────────────── Tooltip Component ─────────────────── */
const TYPE_LABELS: Record<string, string> = {
  customer: "고객",
  memo: "메모",
  meeting: "회의",
  action: "액션",
  risk: "리스크",
  document: "문서",
  project: "프로젝트",
  issue: "이슈",
  ai_insight: "AI 인사이트",
  product: "제품",
  report: "보고서",
};

function NodeTooltip({ node }: { node: CanvasNodeUI }) {
  const typeLabel = TYPE_LABELS[node.type] || node.type;
  const dotColor = NODE_COLORS[node.type] || DEFAULT_COLOR;

  return (
    <div
      className="whitespace-nowrap rounded-lg px-3 py-2 text-xs shadow-xl backdrop-blur-md"
      style={{
        background: "rgba(11, 15, 26, 0.92)",
        border: `1px solid ${dotColor}33`,
        minWidth: 120,
      }}
    >
      <div className="flex items-center gap-1.5 mb-1">
        <span
          className="inline-block w-2 h-2 rounded-full"
          style={{ backgroundColor: dotColor }}
        />
        <span className="font-medium" style={{ color: dotColor }}>
          {typeLabel}
        </span>
      </div>
      <div className="font-semibold text-white/90 text-[11px] leading-tight">
        {node.title}
      </div>
      <div className="mt-1 text-[10px] text-white/40">
        중요도 {Math.round(node.importance_score * 100)}%
      </div>
    </div>
  );
}
