import { motion } from "framer-motion";
import { Sparkles, Code, Calendar, Lightbulb } from "lucide-react";

const suggestions = [
  { icon: Code, text: "코드 리뷰를 도와줘" },
  { icon: Calendar, text: "오늘 할 일을 정리해줘" },
  { icon: Lightbulb, text: "새로운 프로젝트 아이디어 추천" },
];

interface WelcomeScreenProps {
  onSuggestionClick: (text: string) => void;
}

export function WelcomeScreen({ onSuggestionClick }: WelcomeScreenProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className="flex flex-col items-center justify-center h-full gap-8 px-4"
    >
      <motion.div
        animate={{ rotate: [0, 5, -5, 0] }}
        transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
        className="w-16 h-16 rounded-2xl bg-primary/10 ring-1 ring-primary/20 flex items-center justify-center glow-ring"
      >
        <Sparkles className="w-8 h-8 text-primary" />
      </motion.div>

      <div className="text-center space-y-2">
        <h1 className="text-3xl font-semibold tracking-tight">
          안녕하세요, <span className="text-gradient">아리아</span>입니다
        </h1>
        <p className="text-muted-foreground text-sm max-w-md">
          당신의 개인 AI 비서입니다. 무엇이든 도와드릴게요.
        </p>
      </div>

      <div className="flex flex-wrap gap-3 justify-center max-w-lg">
        {suggestions.map((s, i) => (
          <motion.button
            key={i}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 + i * 0.1 }}
            whileHover={{ scale: 1.03, y: -2 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => onSuggestionClick(s.text)}
            className="glass-panel rounded-xl px-4 py-3 flex items-center gap-2.5 text-sm text-secondary-foreground hover:border-primary/30 transition-colors cursor-pointer"
          >
            <s.icon className="w-4 h-4 text-primary" />
            {s.text}
          </motion.button>
        ))}
      </div>
    </motion.div>
  );
}
