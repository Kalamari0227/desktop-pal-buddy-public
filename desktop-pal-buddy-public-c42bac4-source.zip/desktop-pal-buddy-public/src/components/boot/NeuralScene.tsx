import { useRef, useMemo, useCallback } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";

/* ── Constants ── */
const NODE_COUNT = 120;
const MAX_CONNECTIONS = 300;

// Colors from spec
const COL_NODE = new THREE.Color("#E6F1FF");
const COL_CONNECTION = new THREE.Color("#4DA3FF");
const COL_PULSE = new THREE.Color("#00E5FF");
const COL_HIGHLIGHT = new THREE.Color("#9A7DFF");

/* ── Generate network data ── */
interface NetworkData {
  positions: Float32Array;
  connections: [number, number][];
}

function generateNetwork(): NetworkData {
  const positions = new Float32Array(NODE_COUNT * 3);

  // Center node at origin
  positions[0] = 0;
  positions[1] = 0;
  positions[2] = 0;

  for (let i = 1; i < NODE_COUNT; i++) {
    const r = 1.5 + Math.random() * 4.5;
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(2 * Math.random() - 1);
    positions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
    positions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
    positions[i * 3 + 2] = r * Math.cos(phi);
  }

  const connections: [number, number][] = [];
  const maxDist = 3.2;
  for (let i = 0; i < NODE_COUNT && connections.length < MAX_CONNECTIONS; i++) {
    for (let j = i + 1; j < NODE_COUNT && connections.length < MAX_CONNECTIONS; j++) {
      const dx = positions[i * 3] - positions[j * 3];
      const dy = positions[i * 3 + 1] - positions[j * 3 + 1];
      const dz = positions[i * 3 + 2] - positions[j * 3 + 2];
      const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
      if (dist < maxDist) {
        connections.push([i, j]);
      }
    }
  }

  return { positions, connections };
}

/* ── Particles ── */
function Particles({ network, elapsed }: { network: NetworkData; elapsed: React.MutableRefObject<number> }) {
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  const baseScales = useMemo(
    () => Array.from({ length: NODE_COUNT }, () => 0.02 + Math.random() * 0.03),
    []
  );
  // Stagger spawn: center=0s, others spread across 1.5-3.5s
  const spawnTime = useMemo(
    () => Array.from({ length: NODE_COUNT }, (_, i) => (i === 0 ? 0 : 1.5 + Math.random() * 2)),
    []
  );

  useFrame(() => {
    if (!meshRef.current) return;
    const t = elapsed.current;

    for (let i = 0; i < NODE_COUNT; i++) {
      const alive = Math.max(0, Math.min(1, (t - spawnTime[i]) * 1.2));

      if (alive <= 0) {
        dummy.scale.set(0, 0, 0);
      } else {
        const breathe = i === 0 ? 1 + 0.2 * Math.sin(t * 2.5) : 1;
        const s = baseScales[i] * alive * breathe * (i === 0 ? 3 : 1);
        dummy.position.set(
          network.positions[i * 3],
          network.positions[i * 3 + 1],
          network.positions[i * 3 + 2]
        );
        dummy.scale.set(s, s, s);
      }
      dummy.updateMatrix();
      meshRef.current.setMatrixAt(i, dummy.matrix);

      const color = i === 0
        ? COL_HIGHLIGHT.clone().lerp(COL_PULSE, 0.3 + 0.3 * Math.sin(t * 3))
        : COL_NODE;
      meshRef.current.setColorAt(i, color);
    }
    meshRef.current.instanceMatrix.needsUpdate = true;
    if (meshRef.current.instanceColor) meshRef.current.instanceColor.needsUpdate = true;
  });

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, NODE_COUNT]}>
      <sphereGeometry args={[1, 12, 12]} />
      <meshBasicMaterial transparent opacity={0.9} toneMapped={false} />
    </instancedMesh>
  );
}

/* ── Connections ── */
function Connections({ network, elapsed }: { network: NetworkData; elapsed: React.MutableRefObject<number> }) {
  const linesRef = useRef<THREE.LineSegments>(null);

  const { geometry, colorArray } = useMemo(() => {
    const geo = new THREE.BufferGeometry();
    const verts = new Float32Array(network.connections.length * 6);
    const colors = new Float32Array(network.connections.length * 6);

    network.connections.forEach(([a, b], idx) => {
      verts[idx * 6] = network.positions[a * 3];
      verts[idx * 6 + 1] = network.positions[a * 3 + 1];
      verts[idx * 6 + 2] = network.positions[a * 3 + 2];
      verts[idx * 6 + 3] = network.positions[b * 3];
      verts[idx * 6 + 4] = network.positions[b * 3 + 1];
      verts[idx * 6 + 5] = network.positions[b * 3 + 2];
    });

    geo.setAttribute("position", new THREE.BufferAttribute(verts, 3));
    geo.setAttribute("color", new THREE.BufferAttribute(colors, 3));

    return { geometry: geo, colorArray: colors };
  }, [network]);

  useFrame(() => {
    if (!linesRef.current) return;
    const t = elapsed.current;

    // Connections start forming at 3.5s, fully formed by 7s
    const connectionProgress = Math.max(0, Math.min(1, (t - 3.5) / 3.5));
    const visibleCount = Math.floor(connectionProgress * network.connections.length);

    const attr = geometry.getAttribute("color") as THREE.BufferAttribute;
    for (let i = 0; i < network.connections.length; i++) {
      const visible = i < visibleCount;
      if (visible) {
        const pulsePhase = (t * 1.5 + i * 0.3) % 1;
        const pulseIntensity = Math.exp(-((pulsePhase - 0.5) ** 2) * 20);
        const color = COL_CONNECTION.clone().lerp(COL_PULSE, pulseIntensity * 0.6);
        const fadeIn = Math.min(1, (connectionProgress * network.connections.length - i) * 0.3);
        colorArray[i * 6] = color.r * fadeIn;
        colorArray[i * 6 + 1] = color.g * fadeIn;
        colorArray[i * 6 + 2] = color.b * fadeIn;
        colorArray[i * 6 + 3] = color.r * fadeIn;
        colorArray[i * 6 + 4] = color.g * fadeIn;
        colorArray[i * 6 + 5] = color.b * fadeIn;
      } else {
        for (let j = 0; j < 6; j++) colorArray[i * 6 + j] = 0;
      }
    }
    attr.needsUpdate = true;
  });

  return (
    <lineSegments ref={linesRef} geometry={geometry}>
      <lineBasicMaterial vertexColors transparent opacity={0.5} toneMapped={false} />
    </lineSegments>
  );
}

/* ── Signal pulses ── */
function SignalPulses({ network, elapsed }: { network: NetworkData; elapsed: React.MutableRefObject<number> }) {
  const count = 30;
  const meshRef = useRef<THREE.InstancedMesh>(null);
  const dummy = useMemo(() => new THREE.Object3D(), []);

  const pulseData = useMemo(
    () =>
      Array.from({ length: count }, () => ({
        connIdx: Math.floor(Math.random() * network.connections.length),
        speed: 0.4 + Math.random() * 1.0,
        offset: Math.random() * 10,
      })),
    [network]
  );

  useFrame(() => {
    if (!meshRef.current) return;
    const t = elapsed.current;
    // Pulses appear from 4s onward
    const pulseAlpha = Math.max(0, Math.min(1, (t - 4) / 2));

    for (let i = 0; i < count; i++) {
      if (pulseAlpha <= 0) {
        dummy.scale.set(0, 0, 0);
        dummy.updateMatrix();
        meshRef.current.setMatrixAt(i, dummy.matrix);
        continue;
      }

      const { connIdx, speed, offset } = pulseData[i];
      if (connIdx >= network.connections.length) {
        dummy.scale.set(0, 0, 0);
        dummy.updateMatrix();
        meshRef.current.setMatrixAt(i, dummy.matrix);
        continue;
      }

      const [a, b] = network.connections[connIdx];
      const progress = ((t * speed + offset) % 1);

      const px = network.positions[a * 3] + (network.positions[b * 3] - network.positions[a * 3]) * progress;
      const py = network.positions[a * 3 + 1] + (network.positions[b * 3 + 1] - network.positions[a * 3 + 1]) * progress;
      const pz = network.positions[a * 3 + 2] + (network.positions[b * 3 + 2] - network.positions[a * 3 + 2]) * progress;

      dummy.position.set(px, py, pz);
      const s = 0.035 * pulseAlpha;
      dummy.scale.set(s, s, s);
      dummy.updateMatrix();
      meshRef.current.setMatrixAt(i, dummy.matrix);
      meshRef.current.setColorAt(i, COL_PULSE);
    }
    meshRef.current.instanceMatrix.needsUpdate = true;
    if (meshRef.current.instanceColor) meshRef.current.instanceColor.needsUpdate = true;
  });

  return (
    <instancedMesh ref={meshRef} args={[undefined, undefined, count]}>
      <sphereGeometry args={[1, 8, 8]} />
      <meshBasicMaterial transparent opacity={0.8} toneMapped={false} />
    </instancedMesh>
  );
}

/* ── Camera controller ── */
function CameraController({ elapsed }: { elapsed: React.MutableRefObject<number> }) {
  const { camera } = useThree();

  useFrame(() => {
    const t = elapsed.current;

    // Slow progressive zoom out over 10s
    let targetZ: number;
    if (t < 2) {
      targetZ = 3.5; // close-up on single particle
    } else if (t < 4) {
      targetZ = 3.5 + (t - 2) * 0.75; // slight pull as particles emerge
    } else if (t < 7) {
      targetZ = 5 + (t - 4) * 1.2; // pull back as connections form
    } else {
      targetZ = 8.6 + (t - 7) * 0.8; // final wide view
    }

    camera.position.z += (targetZ - camera.position.z) * 0.03;

    // Very gentle orbit
    const angle = t * 0.06;
    camera.position.x = Math.sin(angle) * 0.4;
    camera.position.y = Math.cos(angle * 0.7) * 0.25;
    camera.lookAt(0, 0, 0);
  });

  return null;
}

/* ── Ambient glow — rendered behind everything, never occludes ── */
function AmbientGlow({ elapsed }: { elapsed: React.MutableRefObject<number> }) {
  const meshRef = useRef<THREE.Mesh>(null);

  useFrame(() => {
    if (!meshRef.current) return;
    const t = elapsed.current;
    const scale = 3 + t * 0.6;
    meshRef.current.scale.set(scale, scale, scale);
    const mat = meshRef.current.material as THREE.MeshBasicMaterial;
    mat.opacity = 0.03 + 0.015 * Math.sin(t * 1.5);
  });

  return (
    <mesh ref={meshRef} renderOrder={-1}>
      <sphereGeometry args={[1, 16, 16]} />
      <meshBasicMaterial
        color={COL_CONNECTION}
        transparent
        opacity={0.03}
        toneMapped={false}
        depthWrite={false}
        side={THREE.BackSide}
      />
    </mesh>
  );
}

/* ── Main scene ── */
function Scene({ onElapsedRef }: { onElapsedRef: (ref: React.MutableRefObject<number>) => void }) {
  const elapsed = useRef(0);
  const network = useMemo(() => generateNetwork(), []);
  const cbCalled = useRef(false);

  useFrame((_, delta) => {
    elapsed.current += delta;
    if (!cbCalled.current) {
      cbCalled.current = true;
      onElapsedRef(elapsed);
    }
  });

  return (
    <>
      <CameraController elapsed={elapsed} />
      <AmbientGlow elapsed={elapsed} />
      <Particles network={network} elapsed={elapsed} />
      <Connections network={network} elapsed={elapsed} />
      <SignalPulses network={network} elapsed={elapsed} />
    </>
  );
}

/* ── Exported Canvas wrapper ── */
interface NeuralSceneProps {
  opacity: number;
  onElapsedRef?: (ref: React.MutableRefObject<number>) => void;
}

export function NeuralScene({ opacity, onElapsedRef }: NeuralSceneProps) {
  const handleElapsedRef = useCallback(
    (ref: React.MutableRefObject<number>) => {
      onElapsedRef?.(ref);
    },
    [onElapsedRef]
  );

  return (
    <div
      className="absolute inset-0"
      style={{ opacity, transition: "opacity 0.8s ease-out" }}
    >
      <Canvas
        camera={{ position: [0, 0, 3.5], fov: 60, near: 0.1, far: 100 }}
        gl={{ antialias: true, alpha: true }}
        style={{ background: "#0B0F1A" }}
        dpr={[1, 2]}
      >
        <Scene onElapsedRef={handleElapsedRef} />
      </Canvas>
    </div>
  );
}
