import { useState, useEffect } from "react";
import { motion } from "framer-motion";

/* ── Semantic hint words ── */
const HINTS = ["Customer", "Meeting", "Order", "Quality", "Risk", "Insight", "Market", "Report"];

function SemanticHints({ visible }: { visible: boolean }) {
  if (!visible) return null;

  return (
    <>
      {HINTS.map((word, i) => {
        const angle = (i / HINTS.length) * Math.PI * 2;
        const r = 32 + Math.random() * 8;
        const x = 50 + Math.cos(angle) * r;
        const y = 50 + Math.sin(angle) * r;

        return (
          <motion.span
            key={word}
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 0.12, 0.06, 0] }}
            transition={{ duration: 4, delay: i * 0.2, ease: "easeInOut" }}
            className="absolute font-mono text-[10px] tracking-widest pointer-events-none"
            style={{
              left: `${x}%`,
              top: `${y}%`,
              color: "#E6F1FF",
              transform: "translate(-50%, -50%)",
            }}
          >
            {word}
          </motion.span>
        );
      })}
    </>
  );
}

/* ── Typewriter hook ── */
function useTypewriter(text: string, active: boolean, charSpeed = 60) {
  const [displayed, setDisplayed] = useState("");
  useEffect(() => {
    if (!active) {
      setDisplayed("");
      return;
    }
    let i = 0;
    let timer: ReturnType<typeof setTimeout>;
    const tick = () => {
      if (i < text.length) {
        setDisplayed(text.slice(0, i + 1));
        i++;
        timer = setTimeout(tick, charSpeed);
      }
    };
    tick();
    return () => clearTimeout(timer);
  }, [text, active, charSpeed]);
  return displayed;
}

/* ── Boot status lines — appear during "reveal" phase ── */
const BOOT_LINES = [
  { text: "Neural substrate initialized", relDelay: 0 },
  { text: "Knowledge graph connected", relDelay: 400 },
  { text: "Synapse network active", relDelay: 800 },
  { text: "Assistant ready", relDelay: 1200, highlight: true },
];

/* ── Main overlay ── */
interface BootOverlayProps {
  phase: "init" | "emerge" | "connect" | "expand" | "reveal" | "fadeout";
}

export function BootOverlay({ phase }: BootOverlayProps) {
  const [visibleLines, setVisibleLines] = useState(0);

  // Title appears during "expand" phase (6s mark)
  const showTitle = phase === "expand" || phase === "reveal" || phase === "fadeout";
  const title1 = useTypewriter("AGENTIC OS", showTitle, 70);
  const title2 = useTypewriter("P R O M E T H E U S", showTitle, 45);

  // Boot lines appear during "reveal" phase (8s mark)
  useEffect(() => {
    if (phase !== "reveal" && phase !== "fadeout") {
      setVisibleLines(0);
      return;
    }
    const timers = BOOT_LINES.map((line, i) =>
      setTimeout(() => setVisibleLines(i + 1), line.relDelay)
    );
    return () => timers.forEach(clearTimeout);
  }, [phase]);

  // Semantic hints during connect + expand
  const showHints = phase === "connect" || phase === "expand";

  return (
    <div className="absolute inset-0 pointer-events-none z-10 flex flex-col items-center justify-end pb-32">
      {/* Title — bottom-center, only after network has formed */}
      <div className="text-center mb-6 h-14">
        {showTitle && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1
              className="font-mono text-sm font-medium tracking-[0.3em] uppercase h-5"
              style={{ color: "#E6F1FF" }}
            >
              {title1}
              <motion.span
                animate={{ opacity: [1, 0] }}
                transition={{ duration: 0.6, repeat: Infinity }}
                className="inline-block w-[2px] h-3.5 ml-0.5 align-middle"
                style={{ backgroundColor: "rgba(77, 163, 255, 0.5)" }}
              />
            </h1>
            <p
              className="font-mono text-[10px] tracking-[0.25em] mt-2 h-4"
              style={{ color: "rgba(154, 125, 255, 0.5)" }}
            >
              {title2}
            </p>
          </motion.div>
        )}
      </div>

      {/* Boot status lines — appear at reveal */}
      <div className="w-full max-w-xs px-8 space-y-1.5 font-mono text-[10px]">
        {BOOT_LINES.slice(0, visibleLines).map((line, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, x: -8 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.4, ease: "easeOut" }}
            style={{
              color: line.highlight ? "#00E5FF" : "rgba(230, 241, 255, 0.35)",
            }}
          >
            {line.text}
          </motion.div>
        ))}
      </div>

      {/* Semantic hints — float around during connect/expand */}
      <SemanticHints visible={showHints} />

      {/* Progress bar */}
      <div className="absolute bottom-12 left-1/2 -translate-x-1/2 w-24">
        <div
          className="h-[0.5px] rounded-full overflow-hidden"
          style={{ backgroundColor: "rgba(77, 163, 255, 0.15)" }}
        >
          <motion.div
            initial={{ width: "0%" }}
            animate={{ width: "100%" }}
            transition={{ duration: 9, ease: "easeOut" }}
            className="h-full"
            style={{ backgroundColor: "rgba(77, 163, 255, 0.4)" }}
          />
        </div>
      </div>
    </div>
  );
}
