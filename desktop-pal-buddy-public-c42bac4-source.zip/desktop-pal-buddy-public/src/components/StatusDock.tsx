import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Sparkles,
  Clock,
  Cpu,
  Wifi,
  MessageSquare,
} from "lucide-react";

interface StatusDockProps {
  onOpenChat: () => void;
  isChatOpen: boolean;
  isAiActive: boolean;
  messageCount: number;
}

function useCurrentTime() {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const timer = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);
  return now;
}

export function StatusDock({
  onOpenChat,
  isChatOpen,
  isAiActive,
  messageCount,
}: StatusDockProps) {
  const now = useCurrentTime();

  const timeStr = now.toLocaleTimeString("ko-KR", {
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  });

  const dateStr = now.toLocaleDateString("ko-KR", {
    month: "short",
    day: "numeric",
    weekday: "short",
  });

  return (
    <AnimatePresence>
      {!isChatOpen && (
        <motion.div
          initial={{ opacity: 0, y: 20, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 20, scale: 0.95 }}
          transition={{ duration: 0.3, ease: "easeOut" }}
          className="fixed bottom-6 right-6 z-50"
        >
          <div className="glass-panel rounded-2xl p-1 flex items-center gap-1">
            {/* Status items */}
            <div className="flex items-center gap-3 px-4 py-2.5">
              {/* Time */}
              <div className="flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-muted-foreground" />
                <span className="text-sm font-mono font-medium text-foreground tabular-nums">
                  {timeStr}
                </span>
              </div>

              <div className="w-px h-4 bg-border" />

              {/* Date */}
              <span className="text-xs text-muted-foreground">{dateStr}</span>

              <div className="w-px h-4 bg-border" />

              {/* AI Status */}
              <div className="flex items-center gap-1.5">
                <div className="relative">
                  <Cpu className="w-3.5 h-3.5 text-muted-foreground" />
                  <motion.div
                    className={`absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full ${
                      isAiActive ? "bg-primary" : "bg-status-online"
                    }`}
                    animate={
                      isAiActive
                        ? { scale: [1, 1.3, 1], opacity: [1, 0.7, 1] }
                        : {}
                    }
                    transition={{ duration: 1, repeat: Infinity }}
                  />
                </div>
                <span className="text-xs text-muted-foreground">
                  {isAiActive ? "처리중" : "대기"}
                </span>
              </div>

              <div className="w-px h-4 bg-border" />

              {/* Connection */}
              <Wifi className="w-3.5 h-3.5 text-status-online" />

              {messageCount > 0 && (
                <>
                  <div className="w-px h-4 bg-border" />
                  <div className="flex items-center gap-1">
                    <MessageSquare className="w-3.5 h-3.5 text-muted-foreground" />
                    <span className="text-xs text-muted-foreground">
                      {messageCount}
                    </span>
                  </div>
                </>
              )}
            </div>

            {/* Open chat button */}
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={onOpenChat}
              className="h-10 w-10 rounded-xl bg-primary text-primary-foreground flex items-center justify-center flex-shrink-0"
            >
              <Sparkles className="w-4 h-4" />
            </motion.button>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
