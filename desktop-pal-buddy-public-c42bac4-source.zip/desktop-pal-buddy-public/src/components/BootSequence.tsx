import { useState, useEffect, useRef, useCallback } from "react";
import { motion } from "framer-motion";
import { NeuralScene } from "./boot/NeuralScene";
import { BootOverlay } from "./boot/BootOverlay";

/* ── Warm ambient sound ── */
function createBootAudio() {
  let ctx: AudioContext | null = null;
  const getCtx = () => {
    if (!ctx) ctx = new AudioContext();
    return ctx;
  };
  return {
    warmPad() {
      try {
        const c = getCtx();
        const t = c.currentTime;
        const osc1 = c.createOscillator();
        const osc2 = c.createOscillator();
        const gain = c.createGain();
        osc1.type = "sine";
        osc2.type = "sine";
        osc1.frequency.value = 220;
        osc2.frequency.value = 330;
        gain.gain.setValueAtTime(0, t);
        gain.gain.linearRampToValueAtTime(0.025, t + 2);
        gain.gain.linearRampToValueAtTime(0.018, t + 8);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 10);
        osc1.connect(gain);
        osc2.connect(gain);
        gain.connect(c.destination);
        osc1.start(t);
        osc2.start(t);
        osc1.stop(t + 10);
        osc2.stop(t + 10);
      } catch {}
    },
    chime() {
      try {
        const c = getCtx();
        const t = c.currentTime;
        [523, 659, 784].forEach((freq, i) => {
          const osc = c.createOscillator();
          const gain = c.createGain();
          osc.type = "sine";
          osc.frequency.value = freq;
          const offset = i * 0.15;
          gain.gain.setValueAtTime(0, t + offset);
          gain.gain.linearRampToValueAtTime(0.02, t + offset + 0.06);
          gain.gain.exponentialRampToValueAtTime(0.001, t + offset + 0.6);
          osc.connect(gain).connect(c.destination);
          osc.start(t + offset);
          osc.stop(t + offset + 0.6);
        });
      } catch {}
    },
  };
}

/* ── Phase timeline (10s total) ── */
type Phase = "init" | "emerge" | "connect" | "expand" | "reveal" | "fadeout";

const TOTAL_DURATION = 10000;

/* ── Component ── */
interface BootSequenceProps {
  onComplete: () => void;
}

export function BootSequence({ onComplete }: BootSequenceProps) {
  const [phase, setPhase] = useState<Phase>("init");
  const audioRef = useRef(createBootAudio());
  const onCompleteRef = useRef(onComplete);
  onCompleteRef.current = onComplete;

  const handleElapsedRef = useCallback(() => {}, []);

  useEffect(() => {
    const audio = audioRef.current;
    const timers: ReturnType<typeof setTimeout>[] = [];

    audio.warmPad();

    // Phase schedule (stretched for 10s):
    // 0-2s    init     — single particle, dark background
    // 2-4s    emerge   — particles float in
    // 4-6s    connect  — connections form
    // 6-8s    expand   — network expands, title appears
    // 8-9s    reveal   — full structure, boot lines
    // 9-10s   fadeout  — transition to main
    timers.push(setTimeout(() => setPhase("emerge"), 2000));
    timers.push(setTimeout(() => setPhase("connect"), 4000));
    timers.push(setTimeout(() => setPhase("expand"), 6000));
    timers.push(setTimeout(() => setPhase("reveal"), 8000));
    timers.push(setTimeout(() => audio.chime(), 8000));
    timers.push(setTimeout(() => setPhase("fadeout"), TOTAL_DURATION - 1000));
    timers.push(setTimeout(() => onCompleteRef.current(), TOTAL_DURATION));

    return () => timers.forEach(clearTimeout);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 1 }}
      animate={{ opacity: phase === "fadeout" ? 0 : 1 }}
      transition={{ duration: 1, ease: "easeInOut" }}
      className="fixed inset-0 z-[9999] overflow-hidden"
      style={{ backgroundColor: "#0B0F1A" }}
    >
      <NeuralScene opacity={1} onElapsedRef={handleElapsedRef} />
      <BootOverlay phase={phase} />
    </motion.div>
  );
}
