/// <reference types="vite/client" />

type DesktopDockState =
  | "idle"
  | "hovered"
  | "expanded"
  | "listening"
  | "thinking"
  | "dispatching"
  | "working"
  | "needs_review"
  | "alert"
  | "completed"
  | "error";

type DesktopWorkspaceMode =
  | "home"
  | "gateway"
  | "meeting"
  | "response"
  | "search"
  | "risk"
  | "performance"
  | "report"
  | "tasks"
  | "customers"
  | "agents"
  | "marketplace"
  | "my-installations"
  | "workflows"
  | "agent-meeting"
  | "alerts"
  | "reports"
  | "settings";

interface DesktopBridge {
  platform: string;
  isElectron: boolean;
  getShellMode: () => Promise<"dock" | "workspace">;
  showCommandCenter: (initialMode?: DesktopWorkspaceMode) => void;
  showDock: () => void;
  syncDockState: (dockState: DesktopDockState) => void;
  syncDockSurface: (surface: "ambient" | "chat") => void;
  onUpdateDownloaded: (callback: () => void) => () => void;
  onShellModeChange: (callback: (mode: "dock" | "workspace") => void) => () => void;
}

interface CompanyRuntimeBridge {
  bootstrap: (request: unknown) => Promise<unknown>;
  read: (request: unknown) => Promise<unknown>;
  submit: (request: unknown) => Promise<unknown>;
  approve: (request: unknown) => Promise<unknown>;
  execute: (request: unknown) => Promise<unknown>;
  role: (request: unknown) => Promise<unknown>;
  stop: (request: unknown) => Promise<unknown>;
  resume: (request: unknown) => Promise<unknown>;
  reset: (request: unknown) => Promise<unknown>;
  cancel: (request: unknown) => Promise<unknown>;
  reconcile: (request: unknown) => Promise<unknown>;
  experience: (request: unknown) => Promise<unknown>;
  learning: (request: unknown) => Promise<unknown>;
  reviewReadiness: (request: unknown) => Promise<unknown>;
  reviewStrategy: (request: unknown) => Promise<unknown>;
  refreshAiConnection: (request: unknown) => Promise<unknown>;
  onUpdate: (callback: (response: unknown) => void) => () => void;
}

interface ImportMetaEnv {
  readonly VITE_APP_MODE?: "demo" | "staging" | "production";
  readonly VITE_RUNTIME_MODE?: "demo" | "staging" | "production";
  readonly VITE_DEMO_MODE?: string;
  readonly VITE_SUPABASE_URL?: string;
  readonly VITE_SUPABASE_PUBLISHABLE_KEY?: string;
}

interface Window {
  desktop?: DesktopBridge;
  companyRuntime?: CompanyRuntimeBridge;
  __deferredTheme?: "dark" | "light" | "system";
  __applyDeferredTheme?: () => void;
  __prometheusCanvasMetrics?: {
    fps: number;
    nodeCount: number;
    connectionCount: number;
    reduceMotion: boolean;
    loadTimeMs: number;
    sampledAt: string;
  };
}
