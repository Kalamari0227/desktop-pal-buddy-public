import { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { AmbientDock } from "@/components/dock/AmbientDock";
import { WorkspaceLayout } from "@/components/workspace/WorkspaceLayout";
import { BootOverlay } from "@/components/boot/BootOverlay";
import { FloatingChatPanel } from "@/components/chat/FloatingChatPanel";
import { streamChat, type Msg } from "@/lib/streamChat";
import { toast } from "sonner";
import type { DockAlert } from "@/types/dock";
import { UnifiedCanvas, type DebugToggles } from "@/components/canvas/UnifiedCanvas";
import AgenticLandingPage from "@/components/landing/AgenticLandingPage";
import { useAlertsData } from "@/hooks/useAlertsData";
import { useBootSequence } from "@/hooks/useBootSequence";
import { useCurrentTime } from "@/hooks/useCurrentTime";
import { useDockSimulation } from "@/hooks/useDockSimulation";
import { useElectronShellSync } from "@/hooks/useElectronShellSync";
import { useShellController } from "@/hooks/useShellController";
import {
  DOCK_ENTRY_LABELS,
  QUICK_ACTION_PROMPTS,
  getDockPrompt,
  resolveWorkspaceMode,
} from "@/config/dockActions";

type CanvasMetrics = NonNullable<Window["__prometheusCanvasMetrics"]>;

/* ── Typewriter hook ── */
function useTypewriter(text: string, active: boolean, charSpeed = 80) {
  const [displayed, setDisplayed] = useState("");
  useEffect(() => {
    if (!active) { setDisplayed(""); return; }
    let i = 0;
    let timer: ReturnType<typeof setTimeout>;
    const tick = () => {
      if (i < text.length) {
        setDisplayed(text.slice(0, i + 1));
        i++;
        timer = setTimeout(tick, charSpeed);
      }
    };
    tick();
    return () => clearTimeout(timer);
  }, [text, active, charSpeed]);
  return displayed;
}

function getInitialCanvasToggles(): DebugToggles {
  if (typeof window === "undefined") {
    return {
      bootNetwork: true,
      seedNode: true,
      knowledge: true,
      debugStamp: false,
      freeze: false,
    };
  }

  const params = new URLSearchParams(window.location.search);
  const readFlag = (key: string, fallback: boolean) => {
    const value = params.get(key);
    if (value === null) return fallback;
    return value !== "0" && value !== "false";
  };

  return {
    bootNetwork: readFlag("bootNetwork", true),
    seedNode: readFlag("seedNode", true),
    knowledge: readFlag("knowledge", true),
    debugStamp: readFlag("debugStamp", false),
    freeze: readFlag("freeze", false),
  };
}

/* ── Ambient Overlay with improved readability + typing + loading bar ── */
function AmbientOverlay({ timeStr, dateStr }: { timeStr: string; dateStr: string }) {
  const title = useTypewriter("Agentic OS Prometheus", true, 90);
  const subtitle = useTypewriter("자동차 강판 마케팅/판매 AI 비서", true, 60);
  const [loadingDone, setLoadingDone] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setLoadingDone(true), 5500);
    return () => clearTimeout(t);
  }, []);

  const textShadow = "0 0 24px rgba(0,0,0,0.8), 0 0 48px rgba(0,0,0,0.5), 0 2px 8px rgba(0,0,0,0.9)";

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 1.2, ease: "easeInOut" }}
      className="absolute inset-0 flex flex-col items-center justify-center z-10 pointer-events-none"
    >
      <div className="text-center space-y-5">
        {/* Clock */}
        <div>
          <div
            className="font-mono text-6xl font-light tabular-nums tracking-tight"
            style={{
              color: "rgba(230, 241, 255, 0.85)",
              textShadow,
            }}
          >
            {timeStr}
          </div>
          <div
            className="text-sm mt-2 flex items-center justify-center gap-2"
            style={{
              color: "rgba(200, 215, 235, 0.55)",
              textShadow: "0 0 16px rgba(0,0,0,0.7), 0 1px 4px rgba(0,0,0,0.8)",
            }}
          >
            {dateStr}
          </div>
        </div>

        {/* Title with typewriter */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8, duration: 0.6 }}
          className="space-y-1.5"
        >
          <h1
            className="text-lg font-semibold tracking-tight font-mono"
            style={{
              color: "rgba(200, 215, 240, 0.5)",
              textShadow,
            }}
          >
            {title}
            <motion.span
              animate={{ opacity: [1, 0] }}
              transition={{ duration: 0.6, repeat: Infinity }}
              className="inline-block w-[2px] h-4 ml-0.5 align-middle"
              style={{ backgroundColor: "rgba(77, 163, 255, 0.4)" }}
            />
          </h1>
          <p
            className="text-xs"
            style={{
              color: "rgba(180, 195, 220, 0.35)",
              textShadow: "0 0 12px rgba(0,0,0,0.6)",
            }}
          >
            {subtitle}
          </p>
        </motion.div>

        {/* Loading bar */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.2, duration: 0.5 }}
          className="flex justify-center pt-2"
        >
          <div
            className="w-32 h-[1.5px] rounded-full overflow-hidden"
            style={{ backgroundColor: "hsla(var(--primary) / 0.08)" }}
          >
            <motion.div
              initial={{ width: "0%" }}
              animate={{ width: "100%" }}
              transition={{ duration: 5, ease: [0.25, 0.1, 0.25, 1] }}
              className="h-full rounded-full"
              style={{
                background: "linear-gradient(90deg, hsla(var(--primary) / 0.4), hsla(43 65% 47% / 0.6), hsla(var(--primary) / 0.5))",
              }}
            />
          </div>
        </motion.div>

        {/* Status text after loading */}
        <AnimatePresence>
          {loadingDone && (
            <motion.p
              initial={{ opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-[10px] font-mono"
              style={{
                color: "rgba(0, 229, 255, 0.35)",
                textShadow: "0 0 8px rgba(0,0,0,0.5)",
              }}
            >
              System ready
            </motion.p>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}

function DesktopShell({ isElectronShell }: { isElectronShell: boolean }) {
  // ── Artifact Debug Mode ──
  const searchParams = typeof window !== "undefined" ? new URLSearchParams(window.location.search) : new URLSearchParams();
  const isDebugMode = searchParams.has("debug");
  const previewWorkspaceMode = resolveWorkspaceMode(searchParams.get("workspace") ?? undefined);
  const [debugToggles, setDebugToggles] = useState<DebugToggles>(() => getInitialCanvasToggles());
  const [debugOverlay, setDebugOverlay] = useState(true);
  const [debugClockIcon, setDebugClockIcon] = useState(true);
  const [canvasMetrics, setCanvasMetrics] = useState<CanvasMetrics | null>(null);

  const {
    bootComplete,
    bootPhase,
    dockEntering,
    dockVisibleAfterBoot,
  } = useBootSequence(isElectronShell);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [isUserTyping, setIsUserTyping] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const {
    viewMode,
    setViewMode,
    shellMode,
    setShellMode,
    workspaceLaunch,
    openChatWithPrompt,
    openWorkspace,
    clearWorkspaceLaunch,
    returnToAmbient,
  } = useShellController(isElectronShell);
  const {
    dockState,
    agents,
    setDockState,
    resetDock,
    flagRiskAlert,
    simulate,
  } = useDockSimulation(isElectronShell ? "idle" : "expanded");
  const [alerts, setAlerts] = useState<DockAlert[]>([]);
  const [allAlertCandidates, setAllAlertCandidates] = useState<DockAlert[]>([]);
  const { activeDockAlerts, allDockAlerts, dismissAlert } = useAlertsData();
  const scrollRef = useRef<HTMLDivElement>(null);
  const lastDockPromptIdRef = useRef(0);
  const openedPreviewWorkspaceRef = useRef(false);
  const now = useCurrentTime();
  const {
    initialMode: workspaceInitialMode,
    initialContext: workspaceInitialContext,
    initialPrompt: workspaceInitialPrompt,
    initialPromptId: workspaceInitialPromptId,
  } = workspaceLaunch;
  const isDockWidget = isElectronShell && shellMode === "dock" && viewMode === "ambient";
  const isDockChatShell = isElectronShell && shellMode === "dock" && viewMode === "chat";

  useEffect(() => {
    if (!isDebugMode) return;
    const timer = window.setInterval(() => {
      setCanvasMetrics(window.__prometheusCanvasMetrics ?? null);
    }, 500);
    return () => window.clearInterval(timer);
  }, [isDebugMode]);

  // Apply deferred theme after boot fade settles (prevents transition-frame flash)
  useEffect(() => {
    if (!bootComplete || !window.__applyDeferredTheme) return;

    const ensureDarkBackground = () => {
      document.documentElement.style.backgroundColor = "#0B0F1A";
      document.body.style.backgroundColor = "#0B0F1A";
      const root = document.getElementById("root");
      if (root) root.style.backgroundColor = "#0B0F1A";
    };

    ensureDarkBackground();
    const timer = window.setTimeout(() => {
      ensureDarkBackground();
      window.__applyDeferredTheme?.();
      ensureDarkBackground();
      requestAnimationFrame(ensureDarkBackground);
    }, 900);

    return () => window.clearTimeout(timer);
  }, [bootComplete]);

  useElectronShellSync({
    isElectronShell,
    shellMode,
    viewMode,
    dockState,
    isDockWidget,
    isDockChatShell,
    setShellMode,
    setViewMode,
    clearWorkspaceLaunch,
  });

  useEffect(() => {
    if (!previewWorkspaceMode || openedPreviewWorkspaceRef.current) return;
    openedPreviewWorkspaceRef.current = true;
    openWorkspace({ initialMode: previewWorkspaceMode });
  }, [openWorkspace, previewWorkspaceMode]);

  useEffect(() => {
    setAllAlertCandidates(allDockAlerts);
    setAlerts(activeDockAlerts);
  }, [activeDockAlerts, allDockAlerts]);

  // Public browser demo should not force the dock into an alert-only panel.
  // Keep alert cards available inside the workspace while leaving the dock menu usable.
  useEffect(() => {
    if (!isElectronShell) return;
    if (viewMode !== "ambient" || dockState !== "idle" || alerts.length === 0) return;
    const timer = setTimeout(() => {
      flagRiskAlert();
    }, 3000);
    return () => clearTimeout(timer);
  }, [viewMode, dockState, alerts.length, flagRiskAlert, isElectronShell]);

  const scrollToBottom = useCallback(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, []);

  useEffect(() => { scrollToBottom(); }, [messages, scrollToBottom]);

  const send = useCallback(async (input: string) => {
    const userMsg: Msg = { role: "user", content: input };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setIsUserTyping(false);
    setIsLoading(true);
    let assistantSoFar = "";
    const upsert = (chunk: string) => {
      assistantSoFar += chunk;
      setMessages((prev) => {
        const last = prev[prev.length - 1];
        if (last?.role === "assistant") return prev.map((m, i) => i === prev.length - 1 ? { ...m, content: assistantSoFar } : m);
        return [...prev, { role: "assistant", content: assistantSoFar }];
      });
    };
    try {
      await streamChat({ messages: newMessages, onDelta: upsert, onDone: () => setIsLoading(false), onError: (e) => { toast.error(e); setIsLoading(false); } });
    } catch { toast.error("연결에 실패했습니다."); setIsLoading(false); }
  }, [messages]);

  useEffect(() => {
    if (!isDockChatShell || !workspaceInitialPrompt || workspaceInitialPromptId === 0) return;
    if (lastDockPromptIdRef.current === workspaceInitialPromptId) return;
    lastDockPromptIdRef.current = workspaceInitialPromptId;
    void send(workspaceInitialPrompt);
  }, [isDockChatShell, send, workspaceInitialPrompt, workspaceInitialPromptId]);

  const handleQuickAction = (actionId: string) => {
    if (isElectronShell) {
      simulate(actionId);
      setMessages([]);
      openChatWithPrompt(getDockPrompt(actionId));
      return;
    }

    if (actionId === "workspace") {
      openWorkspace({});
      return;
    }

    simulate(actionId);
    if (QUICK_ACTION_PROMPTS[actionId] || DOCK_ENTRY_LABELS[actionId]) {
      openChatWithPrompt();
      window.setTimeout(() => send(getDockPrompt(actionId)), 500);
    }
  };

  const handleAgentClick = (agentId: string) => {
    if (isElectronShell) {
      simulate(agentId);
      setMessages([]);
      openChatWithPrompt(getDockPrompt(agentId));
      return;
    }

    simulate(agentId);
    setMessages([]);
    openChatWithPrompt();
    const prompt = getDockPrompt(agentId);
    window.setTimeout(() => send(prompt), 350);
  };

  const handleOpenWorkspace = (
    initialMode?: string,
    initialContext: Record<string, string> = {},
    initialPrompt?: string,
  ) => {
    const resolvedInitialMode = resolveWorkspaceMode(initialMode);
    openWorkspace({
      initialMode: resolvedInitialMode,
      initialContext,
      initialPrompt,
    });
    resetDock();
    if (isElectronShell) {
      window.desktop?.showCommandCenter(resolvedInitialMode as DesktopWorkspaceMode | undefined);
      return;
    }
  };

  const handleCloseWorkspace = () => {
    resetDock();
    if (window.desktop?.isElectron) {
      window.desktop.showDock();
      return;
    }

    returnToAmbient(true);
    setShellMode("browser");
  };

  const handleDismissAlert = async (alertId: string) => {
    await dismissAlert(alertId);
    setAlerts((prev) => prev.filter((a) => a.id !== alertId));
  };

  const handleAlertDismissChange = (newDismissedIds: Set<string>) => {
    setAlerts(allAlertCandidates.filter((a) => !newDismissedIds.has(a.id)));
  };

  const timeStr = now.toLocaleTimeString("ko-KR", { hour: "2-digit", minute: "2-digit", hour12: false });
  const dateStr = now.toLocaleDateString("ko-KR", { year: "numeric", month: "long", day: "numeric", weekday: "long" });

  const renderFloatingChatPanel = (className: string) => (
    <FloatingChatPanel
      className={className}
      messages={messages}
      isLoading={isLoading}
      scrollRef={scrollRef}
      onSend={send}
      onInputChange={(value) => setIsUserTyping(value.length > 0)}
      onMinimize={() => {
        returnToAmbient();
        setIsUserTyping(false);
      }}
      onClose={() => {
        returnToAmbient(true);
        setMessages([]);
        setIsUserTyping(false);
      }}
    />
  );

  // Boot overlay is shown inline below, no early return needed

  if (isDockWidget) {
    return (
      <div className="relative h-screen w-screen overflow-hidden bg-transparent">
        <AmbientDock
          state={dockState}
          agents={agents}
          alerts={alerts}
          onStateChange={setDockState}
          onQuickAction={handleQuickAction}
          onAgentClick={handleAgentClick}
          onOpenWorkspace={handleOpenWorkspace}
          onDismissAlert={handleDismissAlert}
          isUserTyping={isUserTyping}
          layoutMode="widget"
        />
      </div>
    );
  }

  if (isDockChatShell) {
    return (
      <div className="relative h-screen w-screen overflow-hidden bg-transparent">
        <AnimatePresence>{renderFloatingChatPanel("absolute inset-x-4 bottom-32 top-4 z-40 glass-elevated rounded-[28px] flex flex-col overflow-hidden")}</AnimatePresence>
        <AmbientDock
          state={dockState}
          agents={agents}
          alerts={alerts}
          onStateChange={setDockState}
          onQuickAction={handleQuickAction}
          onAgentClick={handleAgentClick}
          onOpenWorkspace={handleOpenWorkspace}
          onDismissAlert={handleDismissAlert}
          isUserTyping={isUserTyping}
          layoutMode="widget"
        />
      </div>
    );
  }

  return (
    <div className="h-screen relative overflow-hidden" style={{ backgroundColor: "#0B0F1A" }}>
      {/* Unified R3F Canvas — persists from boot through ambient */}
      <UnifiedCanvas bootComplete={bootComplete} debugToggles={debugToggles} />

      {/* Boot Overlay — fades out after boot */}
      <AnimatePresence>
        {!bootComplete && (
          <motion.div
            initial={{ opacity: 1 }}
            animate={{ opacity: bootPhase === "fadeout" ? 0 : 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1, ease: "easeInOut" }}
            className="absolute inset-0 z-50 pointer-events-none"
          >
            <BootOverlay phase={bootPhase} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* Ambient desktop (idle view) — appears after boot */}
      <AnimatePresence>
        {bootComplete && viewMode === "ambient" && (!isDebugMode || debugOverlay) && (
          <AmbientOverlay timeStr={timeStr} dateStr={dateStr} />
        )}
      </AnimatePresence>

      {/* Floating Chat Panel */}
      <AnimatePresence>
        {viewMode === "chat" && renderFloatingChatPanel("fixed bottom-24 right-6 z-40 w-[480px] h-[560px] max-h-[75vh] glass-elevated rounded-2xl flex flex-col overflow-hidden")}
      </AnimatePresence>

      {/* Full Workspace */}
      <AnimatePresence>
        {viewMode === "workspace" && (
          <WorkspaceLayout
            agents={agents}
            alerts={alerts}
            onClose={handleCloseWorkspace}
            initialMode={workspaceInitialMode}
            initialContext={workspaceInitialContext}
            initialPrompt={workspaceInitialPrompt}
            initialPromptId={workspaceInitialPromptId}
            isElectronShell={isElectronShell}
            chatMessages={messages}
            onAlertDismissChange={handleAlertDismissChange}
          />
        )}
      </AnimatePresence>

      {/* Ambient Dock - visible after boot, except in workspace */}
      {bootComplete && dockVisibleAfterBoot && viewMode !== "workspace" && (
        <AmbientDock
          state={dockState}
          agents={agents}
          alerts={alerts}
          onStateChange={setDockState}
          onQuickAction={handleQuickAction}
          onAgentClick={handleAgentClick}
          onOpenWorkspace={handleOpenWorkspace}
          onDismissAlert={handleDismissAlert}
          isUserTyping={isUserTyping}
          enterAnimation={dockEntering}
        />
      )}

      {/* ── Artifact Debug HUD ── */}
      {isDebugMode && (
        <div
          className="fixed top-3 left-3 z-[9999] rounded-lg p-3 text-[11px] font-mono space-y-2 select-none"
          style={{
            background: "rgba(0,0,0,0.85)",
            border: "1px solid rgba(255,0,255,0.4)",
            color: "#fff",
            minWidth: 200,
            pointerEvents: "auto",
          }}
        >
          <div className="font-bold text-[13px]" style={{ color: "#FF00FF" }}>
            🔬 Artifact Debug
          </div>
          {[
            { key: "bootNetwork" as const, label: "Boot Network" },
            { key: "seedNode" as const, label: "Seed Node (0)" },
            { key: "knowledge" as const, label: "Knowledge Layer" },
          ].map(({ key, label }) => (
            <label key={key} className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={debugToggles[key]}
                onChange={() => setDebugToggles((p) => ({ ...p, [key]: !p[key] }))}
                className="accent-pink-500"
              />
              {label}
            </label>
          ))}
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={debugOverlay}
              onChange={() => setDebugOverlay((p) => !p)}
              className="accent-pink-500"
            />
            Overlay (전체)
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={debugClockIcon}
              onChange={() => setDebugClockIcon((p) => !p)}
              className="accent-pink-500"
            />
            Clock Icon
          </label>
          <hr style={{ borderColor: "rgba(255,255,255,0.15)" }} />
          <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-[10px]" style={{ color: "#BFE8FF" }}>
            <span>FPS</span>
            <span className="text-right">{canvasMetrics?.fps ?? "..."}</span>
            <span>Nodes</span>
            <span className="text-right">{canvasMetrics?.nodeCount ?? "..."}</span>
            <span>Edges</span>
            <span className="text-right">{canvasMetrics?.connectionCount ?? "..."}</span>
            <span>Load</span>
            <span className="text-right">{canvasMetrics ? `${canvasMetrics.loadTimeMs}ms` : "..."}</span>
          </div>
          <hr style={{ borderColor: "rgba(255,255,255,0.15)" }} />
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={debugToggles.debugStamp}
              onChange={() => setDebugToggles((p) => ({ ...p, debugStamp: !p.debugStamp }))}
              className="accent-lime-400"
            />
            <span style={{ color: "#0F0" }}>Visual Stamp</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={debugToggles.freeze}
              onChange={() => setDebugToggles((p) => ({ ...p, freeze: !p.freeze }))}
              className="accent-cyan-400"
            />
            <span style={{ color: "#0FF" }}>⏸ Freeze Frame</span>
          </label>
        </div>
      )}
    </div>
  );
}

const Index = () => {
  const isElectronShell = typeof window !== "undefined" && Boolean(window.desktop?.isElectron);
  const params = typeof window !== "undefined" ? new URLSearchParams(window.location.search) : new URLSearchParams();
  const showDesktopDemo = params.has("demo") || params.has("debug");

  if (!isElectronShell && !showDesktopDemo) {
    return <AgenticLandingPage />;
  }

  return <DesktopShell isElectronShell={isElectronShell} />;
};

export default Index;
