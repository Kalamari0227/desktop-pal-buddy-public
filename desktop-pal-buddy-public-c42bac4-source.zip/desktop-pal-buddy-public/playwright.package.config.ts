import { defineConfig } from "@playwright/test";

export default defineConfig({
  testDir: "./tests/electron",
  testMatch: /packaged-live\.spec\.ts/,
  timeout: 260_000,
  expect: { timeout: 20_000 },
  fullyParallel: false,
  workers: 1,
  retries: 0,
  forbidOnly: true,
  reporter: [["list"], ["json", { outputFile: ".omo/evidence/brave-new-company-future-erp/task-24/package-playwright.json" }]],
  outputDir: ".omo/evidence/brave-new-company-future-erp/task-24/playwright",
  projects: [
    { name: "package-ci", grep: /@package-ci/ },
    { name: "package-live", grep: /@package-live/ },
  ],
  use: { trace: "on", screenshot: "on", video: "off" },
});
