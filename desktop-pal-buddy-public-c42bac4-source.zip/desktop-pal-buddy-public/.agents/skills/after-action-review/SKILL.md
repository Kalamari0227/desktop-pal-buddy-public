---
name: after-action-review
description: Use after meaningful work, failed work, repeated confusion, or verified fixes to decide what should be preserved.
---

# After Action Review

Use this skill after meaningful work, failed work, repeated confusion, or a verified fix.

## Goal

Convert useful experience into future execution quality without creating memory clutter.

## Checklist

1. What actually happened?
2. What was verified?
3. Was there a mistake, delay, repeated issue, or useful pattern?
4. Should anything be preserved?
5. If yes, route it:
   - stable preference -> memory
   - repeatable procedure -> skill
   - architecture or decision -> knowledge docs
   - active follow-up -> workboard
   - evidence -> artifact or log
6. If it will not improve future execution, do not save it.

## Output Format

Return:

- Lesson:
- Evidence:
- Routing decision:
- Proposed update:
- No-save reason, if applicable:
