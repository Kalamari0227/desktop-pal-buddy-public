---
name: gateway-task-packet
description: "Use for Agentic OS Gateway, task intake, Task Packet schema, Worker Event schema, Manual Codex handoff, Workboard status, Evidence Ledger, Approval Gate, Retention Router, PR verification packets, Supabase staging check packets, and document-to-PRD flows. Use this before implementing Gateway UI or persistence."
---

# Gateway Task Packet

Design and review Agentic OS Gateway contracts.

## Source Contracts

Read the relevant files before acting:

- `docs/prd/agentic-os-prd.md`
- `docs/agent-os/task-packet-schema.md`
- `docs/agent-os/evidence-ledger-schema.md`
- `docs/agent-os/approval-gate-policy.md`
- `docs/agent-os/COMPLETION_POLICY.md`
- `docs/agent-os/MEMORY_ROUTING_POLICY.md`

## Core Rule

Gateway is a work intake desk, not a loose chat surface.

Every supported request should become a Task Packet with:

- requested outcome
- context refs
- risk level
- approval status
- forbidden actions
- execution plan
- verification requirements
- report format
- status
- evidence
- blockers
- next action
- retention decision

## Intake Workflow

1. Preserve the raw user request.
2. Summarize the desired outcome in one sentence.
3. Identify context refs: repo, PR, file, Supabase project, link, upload, note.
4. Classify task type.
5. Classify risk and approval need.
6. Add forbidden actions.
7. Add verification requirements.
8. Choose report detail level.
9. Produce the packet.

## Default Task Types

- `pr_verification`
- `supabase_staging_check`
- `document_to_prd`
- `repo_doc_update`
- `general_research`
- `unknown`

Unknown tasks need manual review before execution.

## Approval Preflight

If the request includes a high-risk action, split it:

1. read-only preflight without approval;
2. explicit user approval;
3. scoped mutation after approval;
4. evidence capture.

Never treat implied intent as approval.

## Manual Codex Handoff

When the worker bridge is not automated, render the Task Packet as Markdown:

```md
# Codex Task Packet

## Request
...

## Desired Outcome
...

## Context Refs
- [type] label: value

## Forbidden Actions
- ...

## Execution Plan
1. ...

## Verification Requirements
- [required] type: command/source

## Report Back With
- conclusion
- evidence
- blockers
- next action
```

The returned result should be parsed into:

- `WorkerResult`
- `EvidenceItem[]`
- `Blocker[]`
- `next_action`
- `RetentionDecision`

## Flow Defaults

### PR Verification

Forbidden:

- do not merge PR
- do not push commits
- do not deploy

Required evidence:

- PR status
- diff review
- CI status when available
- readiness/risk assessment

### Supabase Staging Check

Forbidden:

- do not run migration
- do not change secrets
- do not deploy functions
- do not modify production systems

Required evidence:

- project health
- migration status
- Edge Function status when relevant
- advisor warning classification

### Document-to-PRD

Forbidden:

- do not overwrite existing docs without approval
- do not expose secrets from uploaded files

Required evidence:

- source document read-through
- generated draft path or draft content
- open questions
- proposed save location

## Output Standard

Report:

- conclusion
- packet fields changed or created
- evidence required
- approval gates
- risks
- next action

If evidence is unavailable, report the task as advisory-only, blocked, or failed.
