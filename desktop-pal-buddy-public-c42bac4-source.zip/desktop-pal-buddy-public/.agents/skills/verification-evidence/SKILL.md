---
name: verification-evidence
description: "Use before claiming Prometheus work is complete. Verifies diffs, tests, lint/typecheck/build, UI/backend/Electron/Supabase cross-boundary contracts, Evidence Ledger quality, blockers, next actions, and residual risks. Use for QA audits, PR readiness, completion checks, and regression risk reports."
---

# Verification Evidence

Verify work before completion.

## Read First

- `AGENTS.md`
- `docs/agent-os/COMPLETION_POLICY.md`
- `docs/agent-os/evidence-ledger-schema.md`
- relevant changed files and tests

## Core Rule

Do not report completion without evidence.

Evidence can include:

- tests passed
- typecheck/lint/build passed
- generated artifact path
- file diff inspected
- read-back from GitHub, Supabase, or local output
- manual review when machine evidence is not possible

## Verification Workflow

1. Inspect `git status --short`.
2. Inspect the diff for changed files.
3. Identify risk areas:
   - user-facing UI
   - shared business logic
   - Supabase security/data behavior
   - Electron runtime boundary
   - docs-only change
4. Pick the smallest useful verification command.
5. Broaden only when risk requires it.
6. Record pass/fail/blocked evidence.
7. Report unverified parts and residual risks.

## Cross-Boundary QA

Always read both sides of a contract:

- API or Edge Function response and frontend parser
- Task Packet schema and Gateway UI state
- EvidenceItem schema and evidence rendering
- Electron preload API and renderer caller
- DB/RLS behavior and client assumptions

## Recommended Commands

- docs-only: `git diff --check`
- unit behavior: `npm test`
- shared TypeScript contracts: `npm run typecheck`
- style/static checks: `npm run lint`
- production bundle risk: `npm run build`
- Electron boundary: `npm run check:electron`
- Supabase migrations: `npm run verify:supabase:postgres`
- E2E flow: `npm run test:e2e`

## Evidence Quality

Good evidence is:

- specific
- current
- tied to the changed state
- safe to share
- enough for the user to decide next action

Never store or quote secrets, tokens, private keys, or `.env` contents.

## Output Format

Return:

- conclusion
- verification run
- evidence
- failed or skipped checks
- risks
- next action
