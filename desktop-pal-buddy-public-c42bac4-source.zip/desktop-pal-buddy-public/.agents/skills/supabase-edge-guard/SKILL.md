---
name: supabase-edge-guard
description: "Use for all Supabase work in Prometheus: migrations, RLS, owner policies, Edge Functions, request guards, rate limits, SQL safety, generated types, staging checks, advisor findings, and auth boundaries. Use before touching supabase/, Supabase clients, or data-query/chat provider behavior."
---

# Supabase Edge Guard

Protect Supabase data, auth, and Edge Function boundaries.

## Read First

- `AGENTS.md`
- `docs/supabase_hardening_rollout.md`
- `docs/agent-os/approval-gate-policy.md`
- relevant files under `supabase/functions`, `supabase/migrations`, and `src/integrations/supabase`

## Safety Rules

- Keep service-role keys out of browser bundles.
- Preserve owner-based RLS.
- Preserve request payload validation.
- Preserve Origin/CORS checks.
- Preserve rate limits.
- Preserve SQL allowlists and safe RPC paths.
- Do not modify production systems without explicit approval.
- Do not run DB migrations without explicit approval.
- Do not expose `.env` contents, keys, or tokens.

## Edge Function Workflow

1. Inspect shared guards before changing function behavior.
2. Validate auth and origin behavior.
3. Validate payload schema.
4. Check rate limit behavior.
5. Check provider independence and demo/real service separation.
6. Add or update tests for security or contract behavior.

## Migration Workflow

1. Read existing migrations and rollout docs.
2. Determine whether the migration may have shipped.
3. Prefer additive, reversible changes.
4. Preserve RLS and grants.
5. Add smoke or migration verification when practical.
6. Require approval before applying remote migrations.

## Staging Check Workflow

Read-only staging checks can run without approval.

Collect evidence for:

- project health
- migration list
- Edge Function status
- JWT verification status
- advisor results
- known intended warnings

Classify each finding:

- normal
- intended warning
- action required
- blocked

## Verification

Use targeted checks first:

- function unit tests
- shared guard tests
- SQL safety tests
- migration smoke tests
- `npm run verify:supabase:postgres`
- `npm run verify:supabase` when local Supabase is available

Report whether checks are local, staging, or advisory-only.
