---
name: electron-safety
description: "Use for Electron desktop boundary work in Prometheus: main process, preload, IPC validation, shell URL allowlists, context isolation, sandboxing, CSP, desktop package smoke, and renderer-to-desktop integrations. Use before editing electron/ or shell-related src hooks/types."
---

# Electron Safety

Protect Prometheus desktop runtime boundaries.

## Read First

- `AGENTS.md`
- `electron/main.mjs`
- `electron/preload.cjs`
- `electron/shellValidation.mjs`
- `electron/shellValidation.test.ts`
- related renderer hooks and types

## Safety Rules

- Keep context isolation intact.
- Keep sandboxing and CSP assumptions intact.
- Validate all IPC payloads.
- Allowlist external URLs before opening them.
- Keep preload APIs narrow and explicit.
- Do not expose Node primitives to the renderer.
- Do not add shell actions without validation and tests.

## Workflow

1. Identify the desktop boundary touched by the request.
2. Read both producer and consumer sides:
   - main/preload API
   - renderer hook/component/type
3. Check allowlists and validation.
4. Update tests when IPC, shell validation, or preload contracts change.
5. Run the smallest relevant check first.

## Common Verification

- `npm run check:electron`
- `npm test -- electron/shellValidation.test.ts`
- `npm run typecheck`
- `npm run electron:package -- --linux --x64` for package smoke when release risk is relevant

## Report

Include:

- boundary touched
- validation path
- tests run
- remaining desktop/runtime risk
- any approval needed for external-facing behavior
