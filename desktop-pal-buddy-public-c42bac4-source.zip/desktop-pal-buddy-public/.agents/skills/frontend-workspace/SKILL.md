---
name: frontend-workspace
description: "Use for Prometheus React/Vite workspace UI work: Gateway Command Center, task intake forms, risk badges, approval panels, task status timelines, evidence ledger panels, workspace modes, hooks, stores, and user-facing operational workflows. Use when editing src/components, src/hooks, src/lib, src/types, or workspace navigation."
---

# Frontend Workspace

Build Prometheus workspace UI with operational clarity.

## Read First

- `AGENTS.md`
- `docs/prd/agentic-os-prd.md` when Gateway is involved
- `docs/agent-os/task-packet-schema.md` when task state is involved
- existing nearby components and tests

## Design Posture

This app is an operational desktop assistant. Prefer quiet, dense, scannable UI over marketing layouts.

Use:

- existing `src/components/ui/*` primitives
- existing workspace modes as patterns
- stable dimensions for boards, panels, counters, timelines, and fixed controls
- icons for tool actions when an icon exists
- clear empty, loading, blocked, failed, and completed states

Avoid:

- landing pages for app workflows
- nested cards
- decorative gradients/orbs
- oversized hero typography inside tool surfaces
- text that explains obvious UI mechanics

## Implementation Workflow

1. Find the closest existing workspace mode.
2. Reuse local component, hook, and data patterns.
3. Define data contracts in `src/types` or existing type files when shared.
4. Keep feature state close unless several components need it.
5. Add tests when behavior, data mapping, or user-facing state changes.
6. Verify with the smallest useful command first.

## Gateway UI Contract

Gateway Command Center should expose:

- request input
- context refs
- task type preview
- risk badge
- approval requirement
- Task Packet preview
- status timeline
- result summary
- evidence list
- blockers
- next action
- retention suggestion

Do not show completed if evidence is missing.

## Cross-Boundary Checks

When UI consumes backend or worker data, compare both sides:

- Task Packet schema vs UI state
- EvidenceItem schema vs Evidence panel
- Edge Function response vs client parser
- Electron preload API vs renderer caller

## Verification

Use one or more:

- `npm test`
- `npm run lint`
- `npm run typecheck`
- `npm run build`
- focused component tests
- Playwright only when the flow is visual or end-to-end

Report skipped checks with a reason.
