---
name: prometheus-harness-orchestrator
description: "Use this skill for Prometheus harness work: Agentic OS Gateway, Task Packet, Codex Worker handoff, Workboard, Evidence Ledger, approval gates, retention routing, PR verification, Supabase staging checks, Electron safety, frontend workspace changes, multi-agent coordination, follow-up updates, re-runs, and harness audits."
---

# Prometheus Harness Orchestrator

Coordinate the Prometheus agent harness for verified project work.

This skill adapts the `revfactory/harness` team-architecture pattern to this Codex/ECC repository. The upstream harness generates `.claude/agents` and `.claude/skills`; Prometheus uses `.codex/agents`, `.agents/skills`, `AGENTS.md`, and `docs/agent-os`.

## Execution Mode

Use a hybrid Codex mode:

1. Main operator remains accountable.
2. Use configured Codex agents when a task has independent slices that can run in parallel.
3. Use direct local work for urgent blocking edits, tightly coupled changes, or small tasks.
4. Capture evidence before reporting completion.

Default architecture: fan-out/fan-in with producer-reviewer gates.

## Agent Roster

| Agent | Use For | Primary Skill |
|---|---|---|
| `prometheus-context-scout` | Read-only repo map, patterns, tests, risks | `prometheus-harness-orchestrator` |
| `prometheus-gateway-architect` | Gateway, Task Packet, Workboard, Evidence, Approval, Retention contracts | `gateway-task-packet` |
| `prometheus-frontend-builder` | React/Vite workspace UI and Gateway Command Center | `frontend-workspace` |
| `prometheus-supabase-guardian` | Supabase RLS, Edge Functions, migrations, staging safety | `supabase-edge-guard` |
| `prometheus-electron-guardian` | Electron IPC, preload, shell allowlist, sandbox, CSP | `electron-safety` |
| `prometheus-qa-auditor` | Cross-boundary QA and verification evidence | `verification-evidence` |

## Workflow

### Phase 0: Context Check

1. Inspect `git status --short`.
2. Read `AGENTS.md`.
3. Read the relevant `docs/agent-os/*` contract files.
4. Decide whether this is:
   - a small local task;
   - a multi-slice implementation;
   - a read-only audit;
   - a harness maintenance/update task.

If the task is tiny, do it locally and avoid agent overhead.

### Phase 1: Task Classification

Classify the request into one or more owner slices:

- Gateway/task contract
- Frontend workspace UI
- Supabase/Edge Function/data safety
- Electron/desktop boundary
- Documentation/PRD synthesis
- Verification/evidence

Route owner slices to agents only when their work can proceed independently.

### Phase 2: Safety Gate

Before any mutation, check for approval-required actions:

- external messages
- file delete/move/bulk reorganization
- production deploy
- database migration
- service restart
- OAuth/model/gateway config change
- paid resource creation
- secret/API key creation or storage
- permission change

If present, do read-only preflight and ask for explicit user approval before mutation.

### Phase 3: Execution

For implementation:

1. Context scout maps files and tests when the slice is not obvious.
2. Owner agent implements or reviews its bounded area.
3. QA auditor verifies producer/consumer boundaries and commands.
4. Main operator integrates, inspects diffs, and resolves conflicts.

For documentation:

1. Read source material and current docs.
2. Generate or update durable docs.
3. Ensure links, scope, non-goals, and next actions are clear.
4. Treat generated docs as evidence when relevant.

### Phase 4: Evidence

Use `verification-evidence` before completion.

Every completed task needs evidence such as:

- tests passed
- typecheck/lint/build output
- diff inspected
- generated document path
- GitHub/CI/Supabase state read-back
- manual review note when machine evidence is not possible

### Phase 5: Retention

Use `after-action-review` after meaningful work.

Route durable outputs:

- stable preference -> memory
- repeated procedure -> skill
- architecture or decision -> docs/wiki
- active follow-up -> workboard
- evidence -> artifact/log
- one-time result -> no save

## Data Handoff

Use `_workspace/prometheus-harness/` for optional intermediate artifacts. Do not store secrets there.

Recommended filenames:

- `context-scout.md`
- `gateway-contract-review.md`
- `frontend-report.md`
- `supabase-safety-report.md`
- `electron-safety-report.md`
- `qa-report.md`

## Error Handling

- One agent blocked: continue with local work if safe, but report the missing slice.
- Conflicting findings: preserve both claims with sources; do not erase uncertainty.
- Verification failure: fix if in scope; otherwise report blocked or failed.
- Missing credentials: do not guess or request secrets inline; ask for the safe action needed.

## Dry-Run Checklist

- The owner agent is clear.
- The write scope is bounded.
- Risk and approval status are known.
- Verification command is known or intentionally not applicable.
- Evidence path or evidence type is known.
- No secrets will be exposed.

## Test Scenarios

### Normal Flow

User asks: "Implement Gateway Task Packet UI."

Expected:

1. `prometheus-gateway-architect` confirms packet/status/evidence contract.
2. `prometheus-frontend-builder` implements UI.
3. `prometheus-qa-auditor` checks UI state against the schema and runs relevant tests.
4. Main operator reports changed files, evidence, risks, and next action.

### Error Flow

User asks: "Run the staging migration."

Expected:

1. `prometheus-supabase-guardian` performs read-only preflight only.
2. Task enters approval-required path.
3. Main operator requests explicit approval before migration.
4. Without approval, the task is reported as blocked, not completed.
