import { defineConfig } from "@playwright/test";
import path from "node:path";
import { resolveEvidenceRoot } from "./tests/electron/fixtures";

const repoRoot = path.resolve(import.meta.dirname);
const legacyEvidenceRoot = path.resolve(repoRoot, ".omo/evidence/brave-new-company-future-erp");
const configuredEvidenceRoot = process.env.BNC_QA_EVIDENCE_DIR ? resolveEvidenceRoot() : null;

export default defineConfig({
  testDir: "./tests/electron",
  testMatch: /.*\.spec\.ts/,
  grepInvert: /@live|@package-live|@package-ci/,
  timeout: 60_000,
  expect: { timeout: 10_000 },
  fullyParallel: false,
  workers: 1,
  retries: 0,
  forbidOnly: true,
  reporter: [["list"], ["json", { outputFile: configuredEvidenceRoot ? path.join(configuredEvidenceRoot, "playwright-results.json") : path.join(legacyEvidenceRoot, "task-15-electron-results.json") }]],
  outputDir: configuredEvidenceRoot ? path.join(configuredEvidenceRoot, "playwright") : path.join(legacyEvidenceRoot, "task-15-playwright"),
  use: {
    trace: "on",
    screenshot: "on",
    video: "off",
  },
});
