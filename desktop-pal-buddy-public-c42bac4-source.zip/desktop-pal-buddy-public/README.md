# Public source snapshot

이 저장소는 최신 개발 브랜치의 소스 반입용 사본입니다. 원본 Git 이력과 로컬 검증 산출물은 포함하지 않으며, 운영 연결값은 제거했습니다.
기본 demo 실행 방법, 출처 및 검증 범위는 [EXPORT_NOTES.md](EXPORT_NOTES.md)를 먼저 확인하세요. AI/DB 연결, 회사 보안 적용, Windows 실행·패키징 검증은 반입 후 별도 작업입니다.

# desktop-pal-buddy

자동차 강판 마케팅/판매 업무를 위한 데스크톱 AI 비서 프로토타입입니다. Ambient Dock, Workspace, Knowledge Canvas, Marketplace, 자연어 데이터 조회 흐름을 통해 회의 준비, 고객 대응 초안, 문서 탐색, 리스크 확인을 한 화면 흐름으로 묶습니다.

## 주요 흐름

- Ambient Dock: 브리핑, 문서 찾기, 회신 초안, 리스크 확인 진입점
- Workspace: 고객, 작업, 알림, 연결 센터, 보고서, 데이터 조회 모드
- Demo Chat: 자동차 강판 영업 맥락에 맞춘 하드코딩 데모 응답
- Data Query: 데모 모드에서는 fixture, staging/production에서는 Supabase Edge Function 사용
- 연결 센터: demo provider와 Supabase provider를 분리해 에이전트/자동화/스킬/MCP 조회, 리뷰, 설치 카운트를 관리
- Electron Shell: Dock/Workspace 창 전환, IPC 검증, 외부 URL allowlist 적용

## 실행

```sh
npm ci
npm run dev
```

데스크톱 셸로 실행:

```sh
npm run desktop
```

검증:

```sh
npm run lint
npm test
npm run test:e2e
npm run typecheck
npm run build
npm run electron:package -- --linux --x64
npm run verify:supabase:postgres
npm run verify:supabase
```

`verify:supabase:postgres`는 일반 Postgres 컨테이너에 모든 마이그레이션을 적용하고, legacy public write 정책 제거, `owner_id` 정책, review 컬럼 권한, readonly query RPC 제한을 확인하는 빠른 smoke test입니다. `verify:supabase`는 Docker와 `npx supabase`를 사용해 Supabase 로컬 DB migration reset과 DB lint까지 확인합니다. 첫 실행은 Supabase Docker 이미지를 내려받기 때문에 오래 걸릴 수 있습니다. 전체 Supabase 스택까지 확인하려면 `SUPABASE_VERIFY_FULL_STACK=1 npm run verify:supabase`를 사용하세요.

## 런타임 모드

| 모드 | 설정 | 동작 |
| --- | --- | --- |
| demo | 기본값 또는 `VITE_APP_MODE=demo` | Supabase 대신 로컬 데모 adapter와 하드코딩 응답 사용 |
| staging | `VITE_APP_MODE=staging` | 로그인 세션 기반 Edge Function/Supabase 연결 |
| production | `VITE_APP_MODE=production` 또는 `VITE_DEMO_MODE=false` | 실서비스 연결 경로 사용 |

staging/production에서는 Workspace 상단의 연결 상태 배지와 `설정 > 실서비스 연결`에서 Supabase 로그인 상태를 확인하고 로그인/로그아웃할 수 있습니다.

필수 환경 변수:

```sh
VITE_APP_MODE=demo
VITE_SUPABASE_URL=
VITE_SUPABASE_PUBLISHABLE_KEY=
```

Supabase Edge Function 환경 변수:

```sh
ALLOWED_ORIGINS=https://your-app.example.com,null
SUPABASE_URL=
SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
CHAT_RATE_LIMIT_PER_MINUTE=30
DATA_QUERY_RATE_LIMIT_PER_MINUTE=10
```

`null` origin은 패키징된 Electron 앱이 `file://`에서 Edge Function을 호출할 때 필요합니다. 웹 배포만 운영한다면 실제 도메인만 남기세요.
실서비스 비서 실행은 Hermes/Codex 운영 브리지에서 다루며, 이 앱은 브라우저나 Edge Function에 모델 provider 키를 직접 넣지 않습니다.

Electron 외부 링크 allowlist:

```sh
ELECTRON_EXTERNAL_HOSTS=github.com,supabase.com,electronjs.org,vite.dev
ELECTRON_UPDATE_FEED_URL=https://updates.example.com/prometheus-desktop-pal
ELECTRON_UPDATE_CHANNEL=latest
```

## 보안 메모

- service role key는 클라이언트 번들에 넣지 않습니다.
- staging/production Edge Function은 CORS allowlist, Supabase Auth 토큰, 입력 크기 검증, 사용자별 rate limit을 통과해야 합니다.
- Edge Function rate limit은 `edge_rate_limit_events`에 사용자/기능별 요청을 기록해 인스턴스 재시작이나 스케일아웃에도 같은 제한을 공유합니다.
- 자연어 SQL은 `tasks` 테이블 SELECT만 허용하고, row limit/audit log를 적용합니다.
- 운영 데이터 테이블은 public read/write RLS 정책 대신 `owner_id = auth.uid()` 기반 정책으로 전환합니다.
- 데모 데이터는 `src/data`, provider, fixture 경로에 격리하고 실제 API 상태와 구분합니다.
- Electron 자동 업데이트는 `ELECTRON_UPDATE_FEED_URL`이 HTTPS로 설정된 패키지 앱에서만 동작합니다.

## 문서

- `docs/knowledge_canvas_graph_architecture.md`
- `docs/knowledge_canvas_data_schema.md`
- `docs/desktop_ai_assistant_user_flows_and_demo_script.txt`
- `docs/ambient_and_frontend_state_transition_spec.txt`
- `docs/electron_release.md`
- `docs/supabase_hardening_rollout.md`

## CI

GitHub Actions는 PR과 `main` push에서 `npm ci`, `npm audit --audit-level=moderate`, `npm run lint`, `npm test`, Supabase migration smoke, Playwright E2E, `npm run typecheck`, `npm run build`, Electron 패키징 스모크 체크를 실행합니다. Playwright E2E는 랜딩/데스크톱 데모 smoke와 Knowledge Canvas 픽셀 렌더링, reduced motion 품질 설정을 확인합니다.
