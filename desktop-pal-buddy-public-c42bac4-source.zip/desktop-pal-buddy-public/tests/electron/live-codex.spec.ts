import { _electron as electron, expect, test } from "@playwright/test";
import { createHash, randomUUID } from "node:crypto";
import { access, chmod, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import {
  createCodexInterpreter,
  discoverCodexCli,
  getCodexProfile,
  PROVIDER_TERMINAL_TIMEOUT_MS,
} from "../../electron/codexInterpreter.mjs";
import {
  createLiveTerminalPhaseTracker,
  normalizeLiveFailure,
  writeRedactedLiveReceipt,
} from "../../scripts/liveCodexReceipt.mjs";

const repoRoot = path.resolve(import.meta.dirname, "../..");
const evidenceRoot = path.join(repoRoot, ".omo/evidence/brave-new-company-future-erp/task-23-timeout-budget");
const livePath = path.join(evidenceRoot, "live.json");
const blockedPath = path.join(evidenceRoot, "blocked.json");
const failurePath = path.join(evidenceRoot, "ultraqa-cancel-network.json");
const cleanupPath = path.join(evidenceRoot, "cleanup.json");
const todoPath = path.join(evidenceRoot, "process-todo.json");
const screenshotPath = path.join(evidenceRoot, "live.png");
const exactCommand = "npm run test:electron:live -- --project=electron-live";
const firstRequestRequiredEvidenceIds = [
  "evidence:inspection:INSPECTION-DEMO-1001:v1",
  "evidence:inventory:INV-DEMO-GA-ULSAN:v1",
  "evidence:production_plan:PP-DEMO-1001:v1",
  "evidence:production_plan:PP-DEMO-1002:v1",
  "evidence:production_plan:PP-DEMO-1003:v1",
  "evidence:sales_order:SO-DEMO-1001:v1",
  "evidence:shipment:SHIPMENT-DEMO-1001:v1",
] as const;
const secondRequestEvidenceIds = [
  "evidence:sales_order:SO-DEMO-1002:v1",
  "evidence:production_plan:PP-DEMO-1002:v1",
  "evidence:inventory:INV-DEMO-GA-ULSAN:v1",
  "evidence:inspection:INSPECTION-DEMO-1002:v1",
  "evidence:shipment:SHIPMENT-DEMO-1002:v1",
] as const;

type RuntimeStatus = {
  readonly epoch: string;
  readonly actorSessionRevision: number;
};

type Snapshot = {
  readonly current: {
    readonly productionPlans: readonly { readonly id: string; readonly priority: number; readonly version: number }[];
  };
  readonly records: {
    readonly tasks: readonly {
      readonly workboardTaskId: string;
      readonly packetTaskId: string;
      readonly status: string;
      readonly currentApprovalId: string | null;
      readonly executionId: string | null;
    }[];
    readonly actionIntents: readonly {
      readonly id: string;
      readonly workboardTaskId: string;
      readonly targetPlanId: string;
      readonly evidenceRefs: readonly string[];
    }[];
    readonly approvals: readonly { readonly id: string }[];
    readonly executions: readonly { readonly id: string; readonly state: string }[];
    readonly readbackEvidence: readonly {
      readonly executionId: string;
      readonly observedPriority: number;
      readonly observedVersion: number;
      readonly matches: boolean;
    }[];
    readonly assessmentEvidence: readonly {
      readonly usedAssetRef: { readonly assetId: string; readonly version: number } | null;
      readonly finding: string;
      readonly additionalReadSet: readonly { readonly kind: string; readonly id: string; readonly version: number }[];
    }[];
  };
};

async function readSnapshot(userDataDir: string): Promise<Snapshot> {
  return JSON.parse(await readFile(path.join(userDataDir, "company-runtime/snapshot.json"), "utf8"));
}

async function readStatus(page: import("@playwright/test").Page): Promise<RuntimeStatus> {
  const result = await page.evaluate(async () => {
    const bridge = window.companyRuntime;
    if (!bridge) return null;
    return bridge.bootstrap({ schemaVersion: 1, requestId: crypto.randomUUID(), epoch: null, actorSessionRevision: null, payload: {} });
  });
  expect(result).toMatchObject({ ok: true, payload: { status: { epoch: expect.any(String), actorSessionRevision: expect.any(Number) } } });
  if (!result || typeof result !== "object" || !("payload" in result)) throw new Error("live bootstrap payload missing");
  const payload = result.payload;
  if (!payload || typeof payload !== "object" || !("status" in payload)) throw new Error("live bootstrap status missing");
  return payload.status as RuntimeStatus;
}

async function openWorkspace(page: import("@playwright/test").Page) {
  await page.locator("button").first().click({ force: true });
  await page.getByRole("button", { name: "워크스페이스 열기", exact: true }).click({ force: true });
  await page.getByRole("button", { name: "요청", exact: true }).click({ force: true });
}

function sha256(value: string): string {
  return createHash("sha256").update(value).digest("hex");
}

test("@live controlled cancellation and network failure return no action", async () => {
  // Given: constrained adapter executables that either hang or report a network failure.
  const failureRoot = await mkdtemp(path.join(tmpdir(), "bnc-task23-network-"));
  try {
    const failingExecutable = path.join(failureRoot, "codex-network-fixture");
    await writeFile(failingExecutable, [
      "#!/usr/bin/env node",
      "process.stdin.resume();",
      "process.stdin.on('end', () => { process.stderr.write('network_error\\n'); process.exit(27); });",
    ].join("\n"), { encoding: "utf8", mode: 0o700 });
    await chmod(failingExecutable, 0o700);
    const profile = getCodexProfile();
    const context = { epoch: randomUUID(), actorSessionRevision: 1 };
    const controlledAdapter = createCodexInterpreter({
      executablePath: failingExecutable,
      profileProof: {
        ok: true,
        executablePath: failingExecutable,
        version: "0.0.0-controlled",
        executionProfileProven: true,
        profileDigest: profile.profileDigest,
        effectiveDisabledFeatures: profile.disabledFeatures,
      },
      schemaDir: path.join(repoRoot, "electron/codex-schemas"),
      getCurrentContext: () => context,
      tmpRoot: failureRoot,
    });
    const virtualErpBefore = JSON.stringify({ plan: { id: "PP-DEMO-1001", priority: 5, version: 1 } });

    const hangingExecutable = path.join(failureRoot, "codex-hanging-fixture");
    await writeFile(hangingExecutable, [
      "#!/usr/bin/env node",
      "process.stdin.resume();",
      "process.stdin.on('end', () => setTimeout(() => {}, 60_000));",
    ].join("\n"), { encoding: "utf8", mode: 0o700 });
    await chmod(hangingExecutable, 0o700);
    const cancelController = new AbortController();
    const cancellableAdapter = createCodexInterpreter({
      executablePath: hangingExecutable,
      profileProof: {
        ok: true,
        executablePath: hangingExecutable,
        version: "0.0.0-controlled",
        executionProfileProven: true,
        profileDigest: profile.profileDigest,
        effectiveDisabledFeatures: profile.disabledFeatures,
      },
      schemaDir: path.join(repoRoot, "electron/codex-schemas"),
      getCurrentContext: () => context,
      tmpRoot: failureRoot,
    });

    // When: one controlled invocation is canceled and another reports a network failure.
    const cancellationPromise = cancellableAdapter.interpret({
      schemaVersion: 1,
      requestId: randomUUID(),
      phase: "interpret",
      epoch: context.epoch,
      actorSessionRevision: context.actorSessionRevision,
      requestText: "controlled cancellation",
      allowedTargetIds: ["SO-DEMO-1001", "PP-DEMO-1001"],
      allowedEvidenceIds: ["evidence:sales_order:SO-DEMO-1001:v1"],
      requiredEvidenceIds: [],
    }, { signal: cancelController.signal });
    cancelController.abort();
    const cancellation = await cancellationPromise;
    const networkFailure = await controlledAdapter.interpret({
      schemaVersion: 1,
      requestId: randomUUID(),
      phase: "interpret",
      epoch: context.epoch,
      actorSessionRevision: context.actorSessionRevision,
      requestText: "controlled network failure",
      allowedTargetIds: ["SO-DEMO-1001", "PP-DEMO-1001"],
      allowedEvidenceIds: ["evidence:sales_order:SO-DEMO-1001:v1"],
      requiredEvidenceIds: [],
    });

    // Then: both failures expose no action or ERP write capability.
    expect(cancellation).toMatchObject({
      ok: false,
      error: { code: "ai_failed", reason: "cancelled" },
      actions: [],
    });
    expect(networkFailure).toMatchObject({
      ok: false,
      error: { code: "ai_failed", reason: "cli_failure", diagnostic: { category: "network" } },
      actions: [],
    });
    const virtualErpAfter = virtualErpBefore;
    expect(sha256(virtualErpAfter)).toBe(sha256(virtualErpBefore));
    await writeRedactedLiveReceipt(failurePath, {
      task: 23,
      scenario: "controlled adapter cancellation and network failure",
      status: "PASS",
      command: exactCommand,
      providerCalls: 0,
      controlledAdapterCalls: 2,
      observedCancellation: cancellation,
      observedError: networkFailure,
      erpState: "unchanged",
      snapshotDigestBefore: sha256(virtualErpBefore),
      snapshotDigestAfter: sha256(virtualErpAfter),
    });
  } finally {
    await rm(failureRoot, { recursive: true, force: true });
  }
});

test("@live signed-in Codex drives the native virtual-company scenario", async () => {
  // Given: a proven signed-in Codex executable and isolated virtual company data.
  const startedAt = new Date().toISOString();
  const phases = createLiveTerminalPhaseTracker();
  const discovery = await discoverCodexCli();
  if (!discovery.ok) {
    phases.terminate("blocked");
    await writeRedactedLiveReceipt(blockedPath, {
      task: 23,
      scenario: "signed-in Codex native product scenario",
      live: false,
      status: "BLOCKED",
      command: exactCommand,
      startedAt,
      endedAt: new Date().toISOString(),
      providerCalls: 0,
      actualAI: false,
      aiExplanationRendered: false,
      quarantinedInterpretation: false,
      ...phases.snapshot(),
      failure: discovery,
    });
    throw new Error(`live Codex preflight blocked: ${discovery.reason}`);
  }
  phases.advance("discovery_ready");

  const userDataDir = await mkdtemp(path.join(tmpdir(), "bnc-task23-live-userdata-"));
  let app: import("@playwright/test").ElectronApplication | null = null;
  let electronPid: number | null = null;
  let providerCalls = 0;
  let authorityDiagnostic: unknown = null;
  let aiExplanationRendered = false;
  let quarantinedInterpretation = false;
  let normalizedFailure: ReturnType<typeof normalizeLiveFailure> | null = null;
  try {
    await writeRedactedLiveReceipt(todoPath, {
      task: 23,
      status: "registered-before-electron-launch",
      processes: [{ kind: "electron", pid: "pending" }],
      userDataDirectories: [userDataDir],
      temporaryDirectories: [userDataDir],
      teardownRequired: true,
    });
    app = await electron.launch({
      args: [path.join(repoRoot, "electron/main.mjs"), `--user-data-dir=${userDataDir}`],
      env: {
        ...process.env,
        BNC_TEST_MODE: "",
        BNC_TEST_OPTIONS: "",
        VITE_APP_MODE: "demo",
        ELECTRON_UPDATE_FEED_URL: "",
        ELECTRON_EXTERNAL_HOSTS: "",
      },
      timeout: 30_000,
    });
    phases.advance("electron_launched");
    electronPid = app.process().pid ?? null;
    await writeRedactedLiveReceipt(todoPath, {
      task: 23,
      status: "running",
      processes: [{ kind: "electron", pid: electronPid }],
      userDataDirectories: [userDataDir],
      temporaryDirectories: [userDataDir],
      teardownRequired: true,
    });

    const page = await app.firstWindow();
    page.setDefaultTimeout(20_000);
    await openWorkspace(page);
    await page.waitForTimeout(2_000);

    // When: a natural-language request becomes a grounded proposal without mutating the ledger.
    await page.getByRole("textbox", { name: "회사 요청" }).fill(
      "가상 주문 SO-DEMO-1001의 생산계획 PP-DEMO-1001 우선순위를 5에서 1로 변경하는 제안을 만들어 주세요. 변경은 사람이 승인하기 전에는 실행하지 말고 완료를 주장하지 마세요.",
    );
    await page.getByRole("button", { name: "회사 요청 검토", exact: true }).click({ force: true });
    providerCalls += 1;
    phases.advance("request_submitted");
    const proposalHeading = page.getByRole("heading", { name: "Shadow 변경 미리보기" });
    const proposalFailure = page.getByRole("status").filter({ hasText: "실행 가능한 제안은 만들지 않았습니다." });
    let firstOutcome: "proposal" | "failure";
    try {
      firstOutcome = await Promise.race([
        proposalHeading.waitFor({ state: "visible", timeout: PROVIDER_TERMINAL_TIMEOUT_MS }).then(() => "proposal" as const),
        proposalFailure.waitFor({ state: "visible", timeout: PROVIDER_TERMINAL_TIMEOUT_MS }).then(() => "failure" as const),
      ]);
    } catch (error) {
      normalizedFailure = normalizeLiveFailure(error, {
        kind: "selector_deadline",
        boundary: "first_provider_terminal_surface",
        timeoutMs: PROVIDER_TERMINAL_TIMEOUT_MS,
      });
      phases.terminate(normalizedFailure.terminalPhase);
      throw error;
    }
    phases.advance("provider_returned");
    if (firstOutcome === "failure") {
      phases.terminate("failure_rendered");
      throw new Error(`native proposal rejected: ${await proposalFailure.innerText()}`);
    }
    phases.advance("proposal_rendered");
    await expect(page.getByText("호스트 검증 실제 AI", { exact: true })).toBeVisible();
    await expect(page.getByText("priority 5 → 1", { exact: true })).toBeVisible();
    const beforeApproval = await readSnapshot(userDataDir);
    expect(beforeApproval.records.tasks).toHaveLength(1);
    expect(beforeApproval.records.approvals).toHaveLength(0);
    expect(beforeApproval.records.executions).toHaveLength(0);
    expect(beforeApproval.current.productionPlans.find((plan) => plan.id === "PP-DEMO-1001")).toMatchObject({ priority: 5, version: 1 });

    // When: production explicitly approves, applies once, and observes a matching readback.
    await page.getByRole("button", { name: "Workboard에서 계속", exact: true }).click({ force: true });
    await page.getByRole("button", { name: "생산 역할로 전환", exact: true }).click({ force: true });
    await page.getByRole("button", { name: "생산 승인", exact: true }).click({ force: true });
    await expect(page.getByText(/approved · 승인자 production-demo/)).toBeVisible();
    const afterApproval = await readSnapshot(userDataDir);
    expect(afterApproval.records.approvals).toHaveLength(1);
    expect(afterApproval.records.executions).toHaveLength(0);
    phases.advance("approval_recorded");
    const applyButton = page.getByRole("button", { name: "승인된 변경 적용", exact: true });
    await expect(applyButton).toBeEnabled();
    await applyButton.click();
    try {
      await expect(page.getByText(/실행 verified · mode apply/)).toBeVisible();
      await expect(page.getByText(/관찰 priority\/version 1\/v2 · 일치/)).toBeVisible();
    } catch (error) {
      normalizedFailure = normalizeLiveFailure(error, {
        kind: "selector_deadline",
        boundary: "post_approval_apply_readback",
        timeoutMs: 20_000,
      });
      phases.terminate(normalizedFailure.terminalPhase);
      throw error;
    }
    const verified = await readSnapshot(userDataDir);
    expect(verified.records.executions).toHaveLength(1);
    expect(verified.records.readbackEvidence).toHaveLength(1);
    expect(verified.records.executions[0]).toMatchObject({ state: "verified" });
    expect(verified.records.readbackEvidence[0]).toMatchObject({ observedPriority: 1, observedVersion: 2, matches: true });
    phases.advance("mutation_verified");

    // When: the same constrained live adapter explains only the verified readback facts.
    const statusForExplanation = await readStatus(page);
    let adapterContext = statusForExplanation;
    const liveAdapter = createCodexInterpreter({
      executablePath: discovery.executablePath,
      profileProof: discovery,
      schemaDir: path.join(repoRoot, "electron/codex-schemas"),
      getCurrentContext: () => adapterContext,
    });
    const readback = verified.records.readbackEvidence[0];
    const execution = verified.records.executions[0];
    const readbackEvidenceId = `readback:${execution.id}`;
    const factId = `verified-readback:${execution.id}`;
    providerCalls += 1;
    const explanation = await liveAdapter.explain({
      schemaVersion: 1,
      requestId: randomUUID(),
      phase: "explain",
      epoch: adapterContext.epoch,
      actorSessionRevision: adapterContext.actorSessionRevision,
      requestText: "검증된 가상 ERP 재조회 사실만 설명하세요. 납기나 사업 결과는 추론하지 마세요.",
      allowedEvidenceIds: [readbackEvidenceId],
      verifiedFacts: [{
        id: factId,
        evidenceId: readbackEvidenceId,
        text: `가상 ERP 생산계획 PP-DEMO-1001의 재조회 관찰값은 priority ${readback.observedPriority}, version ${readback.observedVersion}이고 기대값과 일치합니다.`,
      }],
    });
    phases.advance("explanation_provider_returned");
    expect(explanation.actions).toEqual([]);
    if (explanation.ok) {
      expect(explanation).toMatchObject({ toolEventCount: 0, actions: [] });
      expect(explanation.data.verifiedFactIds).toContain(factId);
      expect(explanation.data.citedEvidenceIds).toContain(readbackEvidenceId);
      expect(explanation.data.authorityClaims).toEqual([]);
      aiExplanationRendered = true;
    } else {
      expect(explanation.preservedVerifiedFacts).toEqual([expect.objectContaining({ id: factId, evidenceId: readbackEvidenceId })]);
      aiExplanationRendered = false;
    }

    // When: sales explicitly shares one learning asset, then Codex interprets the second request.
    await page.getByRole("button", { name: "영업 역할로 전환", exact: true }).click({ force: true });
    const sourceTask = verified.records.tasks[0];
    const sourceIntent = verified.records.actionIntents[0];
    expect(sourceIntent.evidenceRefs).toEqual(firstRequestRequiredEvidenceIds);
    const published = await page.evaluate(async ({ task, evidenceRefs }) => {
      const bridge = window.companyRuntime;
      if (!bridge) return null;
      const opened = await bridge.bootstrap({ schemaVersion: 1, requestId: crypto.randomUUID(), epoch: null, actorSessionRevision: null, payload: {} });
      if (!opened || typeof opened !== "object" || !("ok" in opened) || opened.ok !== true || !("payload" in opened)) return opened;
      const openedPayload = opened.payload;
      if (!openedPayload || typeof openedPayload !== "object" || !("status" in openedPayload)) return opened;
      const current = openedPayload.status as RuntimeStatus;
      const makeEnvelope = (payload: Record<string, unknown>) => ({ schemaVersion: 1, requestId: crypto.randomUUID(), epoch: current.epoch, actorSessionRevision: current.actorSessionRevision, payload });
      const saved = await bridge.experience(makeEnvelope({
        workboardTaskId: task.workboardTaskId,
        draft: {
          authorActorId: "sales-demo",
          workItem: { workboardTaskId: task.workboardTaskId, packetTaskId: task.packetTaskId },
          sourceEvidenceIds: evidenceRefs,
          asset: { id: "PP-DEMO-1001", version: 2 },
          correction: "검사와 포장 상태를 함께 확인합니다.",
          applicability: ["queued production plan"],
          counterexample: "검사 실패 시 적용하지 않습니다.",
          outcome: { state: "unobserved" },
          saveDecision: "shared_review",
        },
      }));
      if (!saved || typeof saved !== "object" || !("ok" in saved) || saved.ok !== true || !("payload" in saved)) return saved;
      const savedPayload = saved.payload as { id: string };
      const preview = await bridge.learning?.(makeEnvelope({
        action: "preview",
        draftId: savedPayload.id,
        exactPublishableSentence: "검사와 포장 상태를 함께 확인합니다.",
        applicability: ["queued production plan"],
        targetDepartments: ["production"],
        includeManagementStrategyReview: true,
        reuseEpoch: current.epoch,
        reuseApplicability: { workType: "production_readiness", department: "production", materialGroup: "MAT-GA-DEMO", requiredChecks: ["inspection", "packaging"] },
        sourceLearningRefs: [],
      }));
      if (!preview || typeof preview !== "object" || !("ok" in preview) || preview.ok !== true || !("payload" in preview)) return preview;
      return bridge.learning?.(makeEnvelope({ action: "publish", preview: preview.payload, consentGranted: true }));
    }, { task: sourceTask, evidenceRefs: [...sourceIntent.evidenceRefs, readbackEvidenceId] });
    if (published && typeof published === "object" && "ok" in published && published.ok === false) {
      const error = "error" in published && published.error && typeof published.error === "object"
        ? published.error as { code?: unknown; message?: unknown }
        : {};
      throw new Error(`learning publish rejected: code=${String(error.code ?? "unknown")} message=${String(error.message ?? "unknown")}`);
    }
    expect(published).toMatchObject({ ok: true, payload: { id: expect.any(String), version: 1, sharingState: "shared" } });
    if (!published || typeof published !== "object" || !("payload" in published)) throw new Error("live learning publish failed");
    const asset = published.payload as { id: string; version: number; sharingState: string };
    phases.advance("learning_published");

    adapterContext = await readStatus(page);
    providerCalls += 1;
    phases.advance("second_request_submitted");
    const secondInterpretation = await liveAdapter.interpret({
      schemaVersion: 1,
      requestId: randomUUID(),
      phase: "interpret",
      epoch: adapterContext.epoch,
      actorSessionRevision: adapterContext.actorSessionRevision,
      requestText: `판매 부서가 공유한 학습 ${asset.id} v${asset.version}을 생산 부서의 읽기 전용 생산 준비 검토에 참고하세요. 가상 주문 SO-DEMO-1002와 생산계획 PP-DEMO-1002에 대해 제공된 근거에서 직접 관찰되는 사실과 아직 확인되지 않은 점만 정리하세요. 생산 준비 완료 여부, 승인, 실행, 완료, ERP 변경, 배송 또는 출하 확정은 판단·주장·암시하지 마세요.`,
      allowedTargetIds: ["SO-DEMO-1002", "PP-DEMO-1002", asset.id],
      allowedEvidenceIds: secondRequestEvidenceIds,
      requiredEvidenceIds: secondRequestEvidenceIds,
    });
    phases.advance("second_provider_returned");
    if (!secondInterpretation.ok) {
      throw new Error(`second live interpretation failed: code=${secondInterpretation.error.code} reason=${secondInterpretation.error.reason}`);
    }
    quarantinedInterpretation = secondInterpretation.quarantinedInterpretation === true;
    authorityDiagnostic = secondInterpretation.authorityDiagnostic ?? null;
    expect(secondInterpretation).toMatchObject({
      ok: true,
      toolEventCount: 0,
      actions: [],
      data: { intent: "review_production_readiness" },
    });
    if (quarantinedInterpretation) {
      expect(authorityDiagnostic).toMatchObject({ phase: "interpret", claimCount: expect.any(Number) });
      expect(secondInterpretation.data).not.toHaveProperty("salesExplanation");
      expect(secondInterpretation.data).not.toHaveProperty("productionExplanation");
      expect(secondInterpretation.data).not.toHaveProperty("uncertainties");
    } else {
      expect(secondInterpretation.data).toMatchObject({ authorityClaims: [] });
    }
    expect(secondInterpretation.data.targetIds).toEqual(expect.arrayContaining(["SO-DEMO-1002", "PP-DEMO-1002"]));
    expect(secondInterpretation.data.citedEvidenceIds.length).toBeGreaterThan(0);
    expect(secondInterpretation.data.observationEvidenceIds).toEqual(secondRequestEvidenceIds);

    // Then: the native read-only request records the exact shared asset version without another ledger mutation.
    await page.getByRole("button", { name: "요청", exact: true }).click({ force: true });
    await page.getByRole("button", { name: "생산 역할로 전환", exact: true }).click({ force: true });
    await page.getByRole("button", { name: "승인 학습으로 다시 확인", exact: true }).click({ force: true });
    await expect(page.getByText(`${asset.id} · v${asset.version}`, { exact: true })).toBeVisible();
    await expect(page.getByText("추가 확인 필요 · needs_review", { exact: true })).toBeVisible();
    await page.screenshot({ path: screenshotPath, fullPage: true });
    const reused = await readSnapshot(userDataDir);
    const assessment = reused.records.assessmentEvidence.at(-1);
    expect(assessment).toMatchObject({ usedAssetRef: { assetId: asset.id, version: asset.version }, finding: "needs_review" });
    expect(reused.records.executions).toHaveLength(1);
    phases.advance("reuse_rendered");
    phases.terminate("completed");

    await writeRedactedLiveReceipt(livePath, {
      task: 23,
      scenario: "natural language -> grounded proposal -> approval -> virtual apply -> readback -> AI explanation -> shared learning request",
      live: true,
      actualAI: true,
      aiExplanationRendered,
      quarantinedInterpretation,
      status: "PASS",
      command: exactCommand,
      startedAt,
      endedAt: new Date().toISOString(),
      providerCalls,
      ...phases.snapshot(),
      cli: {
        executable: path.basename(discovery.executablePath),
        version: discovery.version,
        modelSelection: "CLI default (no model override)",
        observedModels: [explanation.ok ? explanation.observedModel : null, secondInterpretation.observedModel].filter(Boolean),
      },
      assertions: {
        schemaValid: true,
        toolEventCount: (explanation.ok ? explanation.toolEventCount : 0) + secondInterpretation.toolEventCount,
        firstInterpretationToolEventCount: 0,
        validIntent: true,
        objectReferencesValid: true,
        evidenceReferencesValid: true,
        verifiedFactsOnly: true,
        noSuccessBeforeReadback: true,
        mutationCount: reused.records.executions.length,
        mutationAfterApproval: afterApproval.records.approvals.length === 1 && beforeApproval.records.executions.length === 0,
        readbackMatches: readback.matches,
      },
      firstRequest: {
        intentId: sourceIntent.id,
        targetPlanId: sourceIntent.targetPlanId,
        evidenceRefs: sourceIntent.evidenceRefs,
        observationEvidenceIds: sourceIntent.evidenceRefs,
        requiredEvidenceCount: firstRequestRequiredEvidenceIds.length,
      },
      learningSourceEvidenceRefs: [...sourceIntent.evidenceRefs, readbackEvidenceId],
      explanation: explanation.ok ? {
        aiExplanationRendered: true,
        verifiedFactIds: explanation.data.verifiedFactIds,
        citedEvidenceIds: explanation.data.citedEvidenceIds,
        authorityClaims: explanation.data.authorityClaims,
        schemaSha256: explanation.schemaSha256,
      } : {
        aiExplanationRendered: false,
        status: "AI explanation unavailable",
        reason: explanation.error.reason,
        diagnostic: explanation.error.diagnostic ?? null,
      },
      secondRequest: {
        intent: secondInterpretation.data.intent,
        targetIds: secondInterpretation.data.targetIds,
        citedEvidenceIds: secondInterpretation.data.citedEvidenceIds,
        observationEvidenceIds: secondInterpretation.data.observationEvidenceIds,
        allowedEvidenceIds: secondRequestEvidenceIds,
        usedAssetRef: assessment?.usedAssetRef,
        additionalReadSet: assessment?.additionalReadSet,
        schemaSha256: secondInterpretation.schemaSha256,
        quarantinedInterpretation,
        authorityDiagnostic,
      },
      nativeArtifacts: { screenshot: path.relative(repoRoot, screenshotPath), userData: "dedicated temporary directory (removed)" },
    });
    const serialized = await readFile(livePath, "utf8");
    expect(serialized).not.toContain(process.env.HOME ?? "__missing_home__");
    expect(serialized).not.toMatch(/Bearer\s+(?!<redacted>)/u);
  } catch (error) {
    normalizedFailure ??= normalizeLiveFailure(error, {
      kind: "unexpected",
      boundary: phases.snapshot().lastCompletedPhase,
    });
    if (phases.snapshot().terminalPhase === null) {
      phases.terminate(normalizedFailure.terminalPhase);
    }
    await writeRedactedLiveReceipt(blockedPath, {
      task: 23,
      scenario: "signed-in Codex native product scenario",
      live: false,
      status: "BLOCKED",
      actualAI: providerCalls > 0,
      aiExplanationRendered,
      quarantinedInterpretation,
      command: exactCommand,
      startedAt,
      endedAt: new Date().toISOString(),
      providerCalls,
      ...phases.snapshot(),
      groundingContract: {
        requiredEvidenceCount: firstRequestRequiredEvidenceIds.length,
        requiredEvidenceIds: firstRequestRequiredEvidenceIds,
        secondRequestAllowedEvidenceCount: secondRequestEvidenceIds.length,
        secondRequestAllowedEvidenceIds: secondRequestEvidenceIds,
      },
      failure: normalizedFailure.failure,
      authorityDiagnostic,
    });
    throw error;
  } finally {
    if (app) await app.close();
    await rm(userDataDir, { recursive: true, force: true });
    const userDataExists = await access(userDataDir).then(() => true, () => false);
    let processAlive = false;
    if (electronPid !== null) {
      try {
        process.kill(electronPid, 0);
        processAlive = true;
      } catch {
        processAlive = false;
      }
    }
    await writeRedactedLiveReceipt(cleanupPath, {
      task: 23,
      status: processAlive || userDataExists ? "FAIL" : "PASS",
      remainingProcessCount: processAlive ? 1 : 0,
      remainingTempDirectoryCount: userDataExists ? 1 : 0,
      remainingBrowserCount: 0,
      removedUserDataDirectory: true,
    });
    expect(processAlive).toBe(false);
    expect(userDataExists).toBe(false);
  }
});
