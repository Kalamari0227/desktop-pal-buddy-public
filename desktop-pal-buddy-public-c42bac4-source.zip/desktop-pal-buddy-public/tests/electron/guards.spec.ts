import { expect } from "@playwright/test";
import { readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { createProposal, launchNative, selectProductionAndApprove, taskRecord, test, writeNamedEvidence } from "./fixtures";

type Snapshot = {
  revision: number;
  current: { productionPlans: Array<{ id: string; priority: number; version: number }> };
  records: { tasks: Array<Record<string, unknown>>; approvals: Array<Record<string, unknown>>; executions: Array<{ id: string }>; readbackEvidence: Array<Record<string, unknown>> };
};

test("@task22 guard concurrent duplicate execute produces one execution", async ({ page, readSnapshot }) => {
  await createProposal(page);
  await selectProductionAndApprove(page);
  const approved = await taskRecord(readSnapshot);
  const task = approved.task as { workboardTaskId: string; currentApprovalId: string };
  const responses = await page.evaluate(async ({ workboardTaskId, approvalId }) => {
    const bridge = window.companyRuntime;
    if (!bridge) throw new Error("runtime bridge missing");
    const opened = await bridge.bootstrap({ schemaVersion: 1, requestId: crypto.randomUUID(), epoch: null, actorSessionRevision: null, payload: {} }) as {
      ok: boolean;
      payload?: { status: { epoch: string; actorSessionRevision: number } };
    };
    if (!opened.ok || !opened.payload) throw new Error("runtime bootstrap failed");
    const request = () => bridge.execute({
      schemaVersion: 1,
      requestId: crypto.randomUUID(),
      epoch: opened.payload?.status.epoch,
      actorSessionRevision: opened.payload?.status.actorSessionRevision,
      payload: { workboardTaskId, approvalId },
    });
    return Promise.all([request(), request()]);
  }, { workboardTaskId: task.workboardTaskId, approvalId: task.currentApprovalId });
  expect(responses).toEqual([
    expect.objectContaining({ ok: true, payload: expect.objectContaining({ status: "verified" }) }),
    expect.objectContaining({ ok: true, payload: expect.objectContaining({ status: "verified" }) }),
  ]);
  const after = await readSnapshot() as Snapshot;
  expect(after.records.executions).toHaveLength(1);
  expect(after.records.readbackEvidence).toHaveLength(1);
  expect(after.current.productionPlans.find((item) => item.id === "PP-DEMO-1001")).toMatchObject({ priority: 1, version: 2 });
});

test("@task22 guard cancel invalidates delayed interpretation without a late write", async ({ userDataDir, readSnapshot }) => {
  const delayed = await launchNative(userDataDir, { delayMs: 1_500 });
  try {
    const page = await delayed.firstWindow();
    const result = await page.evaluate(async () => {
      const bridge = window.companyRuntime;
      if (!bridge) throw new Error("runtime bridge missing");
      const opened = await bridge.bootstrap({ schemaVersion: 1, requestId: crypto.randomUUID(), epoch: null, actorSessionRevision: null, payload: {} }) as {
        ok: boolean;
        payload?: { status: { epoch: string; actorSessionRevision: number } };
      };
      if (!opened.ok || !opened.payload) throw new Error("runtime bootstrap failed");
      const status = opened.payload.status;
      const envelope = (payload: Record<string, unknown>) => ({
        schemaVersion: 1,
        requestId: crypto.randomUUID(),
        epoch: status.epoch,
        actorSessionRevision: status.actorSessionRevision,
        payload,
      });
      const pending = bridge.submit(envelope({ requestText: "SO-DEMO-1001 priority 1" }));
      await new Promise((resolve) => setTimeout(resolve, 50));
      const cancelled = await bridge.cancel(envelope({}));
      return { cancelled, submitted: await pending };
    });
    expect(result).toMatchObject({
      cancelled: { ok: true, payload: { cancelled: true } },
      submitted: { ok: false, error: { code: "stale_context" } },
    });
    const snapshot = await readSnapshot() as Snapshot;
    expect(snapshot.records.tasks).toHaveLength(0);
    expect(snapshot.records.executions).toHaveLength(0);
  } finally {
    await delayed.close();
  }
});

test("@task22 guard role spoof and stop fail closed without mutation", async ({ page, readSnapshot }) => {
  await createProposal(page);
  const pending = await taskRecord(readSnapshot);
  const task = pending.task as { workboardTaskId: string };
  const spoofed = await page.evaluate(async (workboardTaskId) => {
    const bridge = window.companyRuntime;
    if (!bridge) throw new Error("runtime bridge missing");
    const opened = await bridge.bootstrap({ schemaVersion: 1, requestId: crypto.randomUUID(), epoch: null, actorSessionRevision: null, payload: {} }) as {
      ok: boolean;
      payload?: { status: { epoch: string; actorSessionRevision: number } };
    };
    if (!opened.ok || !opened.payload) throw new Error("runtime bootstrap failed");
    const status = opened.payload.status;
    return bridge.approve({
      schemaVersion: 1,
      requestId: crypto.randomUUID(),
      epoch: status.epoch,
      actorSessionRevision: status.actorSessionRevision,
      payload: { workboardTaskId, decision: "approved" },
    });
  }, task.workboardTaskId);
  expect(spoofed).toMatchObject({ ok: false, error: { code: "unauthorized_role", message: "production_role_required" } });
  let snapshot = await readSnapshot() as Snapshot;
  expect(snapshot.records.approvals).toHaveLength(0);
  expect(snapshot.records.executions).toHaveLength(0);

  await selectProductionAndApprove(page);
  const approved = await taskRecord(readSnapshot);
  const approvedTask = approved.task as { workboardTaskId: string; currentApprovalId: string };
  const stopped = await page.evaluate(async ({ workboardTaskId, approvalId }) => {
    const bridge = window.companyRuntime;
    if (!bridge) throw new Error("runtime bridge missing");
    const opened = await bridge.bootstrap({ schemaVersion: 1, requestId: crypto.randomUUID(), epoch: null, actorSessionRevision: null, payload: {} }) as {
      ok: boolean;
      payload?: { status: { epoch: string; actorSessionRevision: number } };
    };
    if (!opened.ok || !opened.payload) throw new Error("runtime bootstrap failed");
    const status = opened.payload.status;
    const envelope = (payload: Record<string, unknown>) => ({ schemaVersion: 1, requestId: crypto.randomUUID(), epoch: status.epoch, actorSessionRevision: status.actorSessionRevision, payload });
    const stop = await bridge.stop(envelope({}));
    const execute = await bridge.execute(envelope({ workboardTaskId, approvalId }));
    return { stop, execute };
  }, { workboardTaskId: approvedTask.workboardTaskId, approvalId: approvedTask.currentApprovalId });
  expect(stopped.stop).toMatchObject({ ok: true, payload: { stopped: true } });
  expect(stopped.execute).toMatchObject({ ok: false, error: { code: "stopped", message: "runtime_stopped" } });
  snapshot = await readSnapshot() as Snapshot;
  expect(snapshot.records.executions).toHaveLength(0);
  expect(snapshot.current.productionPlans.find((item) => item.id === "PP-DEMO-1001")).toMatchObject({ priority: 5, version: 1 });
});

test("@task22 guard corrupt snapshot is preserved and bootstrap fails closed", async ({ userDataDir }) => {
  const seeded = await launchNative(userDataDir);
  await seeded.firstWindow();
  await seeded.close();
  const snapshotPath = path.join(userDataDir, "company-runtime/snapshot.json");
  const corrupt = "{not-json\n";
  await writeFile(snapshotPath, corrupt, "utf8");
  const reopened = await launchNative(userDataDir);
  try {
    const page = await reopened.firstWindow();
    const response = await page.evaluate(async () => window.companyRuntime?.bootstrap({
      schemaVersion: 1,
      requestId: crypto.randomUUID(),
      epoch: null,
      actorSessionRevision: null,
      payload: {},
    }));
    expect(response).toMatchObject({ ok: false, error: { code: "unavailable", message: "runtime_not_open" } });
    expect(await readFile(snapshotPath, "utf8")).toBe(corrupt);
  } finally {
    await reopened.close();
  }
});

test("@task22 guard runtime workboard exposes no legacy mutation surface", async ({ page, readSnapshot, evidencePath }) => {
  await createProposal(page);
  const current = await taskRecord(readSnapshot);
  const runtimeTask = current.task as { workboardTaskId: string };
  await page.getByRole("button", { name: "작업", exact: true }).click({ force: true });
  await page.waitForTimeout(500);
  const detail = page.getByRole("region", { name: "런타임 소유 작업 상세" });
  await expect(detail).toBeVisible();
  const legacyMutations = [
    "작업 수정",
    "진행",
    "작업 삭제",
    "승인 기록",
    "이벤트 추가",
    "증거 추가",
    "결과 적용",
    "후속 작업 만들기",
    "재검증 시작",
  ];
  for (const label of legacyMutations) {
    await expect(detail.getByRole("button", { name: label, exact: true })).toHaveCount(0);
  }
  await expect(detail.getByRole("button", { name: "생산 승인", exact: true })).toBeVisible();
  await page.screenshot({ path: evidencePath("legacy-guards.png"), fullPage: true });
  await writeNamedEvidence("task-22-guards.json", {
    scenario: "runtime Workboard authority boundary",
    result: "passed",
    runtimeTaskId: runtimeTask.workboardTaskId,
    blockedLegacyMutationKinds: ["edit", "status", "delete", "approval", "event", "manual_evidence", "manual_result", "follow_up", "reverification"],
  });
  await writeNamedEvidence("task-22-failure.json", {
    scenario: "native persistence/cancel/stop/corruption/role/legacy/consent boundary matrix",
    result: "passed",
    exactFailures: {
      persistence: "persistence_failed/temp_write",
      lostReply: "verification_required/test_after_apply_commit",
      cancel: "stale_context/request_context_is_stale",
      stoppedExecute: "stopped/runtime_stopped",
      corruptSnapshot: "unavailable/runtime_not_open",
      roleSpoof: "unauthorized_role/production_role_required",
      consentDenied: "invalid_input/consent_required",
      wrongAuthor: "unauthorized_role/author_required",
    },
    unchangedContracts: ["failed writes preserve snapshot", "late callback creates no task", "stopped execute creates no execution", "corrupt bytes remain unchanged", "private and withdrawn bodies absent from projected responses"],
    blockedLegacyMutationKinds: ["edit", "status", "delete", "approval", "event", "manual_evidence", "manual_result", "follow_up", "reverification"],
  });
});
