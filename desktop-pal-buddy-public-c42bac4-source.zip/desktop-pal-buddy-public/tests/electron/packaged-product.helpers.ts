import { _electron as electron, type ElectronApplication } from "@playwright/test";
import { chmod, lstat, realpath, writeFile } from "node:fs/promises";
import path from "node:path";

type LaunchResult = {
  readonly app: ElectronApplication;
  readonly appIsPackaged: boolean;
  readonly userDataRealpath: string;
};

const cleanEnvironment = (): NodeJS.ProcessEnv => Object.fromEntries(
  Object.entries(process.env).filter(([key, value]) => value !== undefined
    && !/^(?:BNC_TEST|BNC_QA|ELECTRON_UPDATE|ELECTRON_EXTERNAL|SUPABASE|VITE_SUPABASE|OPENAI|ANTHROPIC|ERP)|API_KEY/i.test(key)),
);

export async function assertFreshProfile(profilePath: string): Promise<string> {
  if (!path.isAbsolute(profilePath)) throw new Error("QA profile must be absolute");
  const metadata = await lstat(profilePath);
  if (metadata.isSymbolicLink() || !metadata.isDirectory()) throw new Error("QA profile must be a real directory");
  if ((metadata.mode & 0o777) !== 0o700) throw new Error("QA profile must use mode 0700");
  return realpath(profilePath);
}

export async function launchPackagedNormal(executablePath: string, profilePath: string): Promise<LaunchResult> {
  const expectedProfile = await assertFreshProfile(profilePath);
  const app = await electron.launch({
    executablePath,
    args: [`--user-data-dir=${expectedProfile}`],
    env: { ...cleanEnvironment(), PATH: "/usr/bin:/bin:/usr/sbin:/sbin" },
    timeout: 45_000,
  });
  const appIsPackaged = await app.evaluate(({ app: packagedApp }) => packagedApp.isPackaged);
  const reported = await app.evaluate(({ app: packagedApp }) => packagedApp.getPath("userData"));
  const userDataRealpath = await realpath(reported);
  if (userDataRealpath !== expectedProfile) {
    await app.close();
    throw new Error("packaged app reported an unexpected userData path");
  }
  return { app, appIsPackaged, userDataRealpath };
}

export async function createScopedNetworkLauncher(options: {
  readonly appPath: string;
  readonly executablePath: string;
  readonly evidenceDirectory: string;
}): Promise<{ readonly executablePath: string; readonly profilePath: string }> {
  const appRoot = await realpath(options.appPath);
  const executable = await realpath(options.executablePath);
  const relative = path.relative(appRoot, executable);
  if (relative.startsWith("..") || path.isAbsolute(relative)) throw new Error("packaged executable must resolve inside the selected app");
  const profilePath = path.join(options.evidenceDirectory, "network.sb");
  const launcherPath = path.join(options.evidenceDirectory, "sandboxed-app-launcher.sh");
  await writeFile(profilePath, `(version 1)\n(allow default)\n(deny network-outbound)\n(allow network-outbound (remote ip "localhost:*"))\n`, { mode: 0o600 });
  const quotedExecutable = executable.replaceAll("'", "'\\''");
  const quotedProfile = profilePath.replaceAll("'", "'\\''");
  await writeFile(launcherPath, `#!/bin/sh\nexec /usr/bin/sandbox-exec -f '${quotedProfile}' '${quotedExecutable}' "$@"\n`, { mode: 0o700 });
  await chmod(launcherPath, 0o700);
  return { executablePath: launcherPath, profilePath };
}
