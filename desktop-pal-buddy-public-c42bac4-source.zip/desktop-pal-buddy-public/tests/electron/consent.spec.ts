import { expect } from "@playwright/test";
import { applyApprovedChange, createProposal, selectProductionAndApprove, taskRecord, test, writeNamedEvidence } from "./fixtures";

type RuntimeStatus = { epoch: string; actorSessionRevision: number };
type SnapshotProjection = {
  records: {
    experienceDrafts: Array<Record<string, unknown>>;
    learningAssets: Array<Record<string, unknown>>;
    learningWithdrawals: Array<Record<string, unknown>>;
    learningSearch: Array<Record<string, unknown>>;
    learningRecommendations: Array<Record<string, unknown>>;
    learningAiContext: Array<Record<string, unknown>>;
    learningProvenance: Array<{ id: string; version: number; withdrawn: boolean }>;
  };
};

test("@task22 consent private draft, explicit consent, author withdrawal, and response redaction", async ({ page, readSnapshot, readStubDiagnostics }) => {
  await createProposal(page);
  await selectProductionAndApprove(page);
  await applyApprovedChange(page);
  await expect(page.getByText(/실행 verified · mode apply/)).toBeVisible();
  const completed = await taskRecord(readSnapshot);
  const task = completed.task as { workboardTaskId: string; packetTaskId: string };
  const intent = completed.records.actionIntents[0] as { evidenceRefs: string[] };

  const outcome = await page.evaluate(async ({ task, evidenceRefs }) => {
    const bridge = window.companyRuntime;
    if (!bridge) throw new Error("runtime bridge missing");
    const bootstrap = async () => bridge.bootstrap({ schemaVersion: 1, requestId: crypto.randomUUID(), epoch: null, actorSessionRevision: null, payload: {} }) as Promise<{
      ok: boolean;
      payload?: { status: RuntimeStatus };
    }>;
    const opened = await bootstrap();
    if (!opened.ok || !opened.payload) throw new Error("runtime bootstrap failed");
    const envelope = (status: RuntimeStatus, payload: Record<string, unknown>) => ({
      schemaVersion: 1,
      requestId: crypto.randomUUID(),
      epoch: status.epoch,
      actorSessionRevision: status.actorSessionRevision,
      payload,
    });
    const switchActor = async (status: RuntimeStatus, actorId: string) => {
      const response = await bridge.role(envelope(status, { actorId })) as { ok: boolean; epoch: string; actorSessionRevision: number };
      if (!response.ok) throw new Error(`role switch failed: ${actorId}`);
      return { epoch: response.epoch, actorSessionRevision: response.actorSessionRevision };
    };
    let status = await switchActor(opened.payload.status, "sales-demo");
    const saved = await bridge.experience(envelope(status, {
      workboardTaskId: task.workboardTaskId,
      draft: {
        authorActorId: "sales-demo",
        workItem: { workboardTaskId: task.workboardTaskId, packetTaskId: task.packetTaskId },
        sourceEvidenceIds: evidenceRefs,
        asset: { id: "PP-DEMO-1001", version: 1 },
        correction: "검사와 출하 준비를 확인한 뒤 납기를 검토합니다.",
        applicability: ["queued production plan"],
        counterexample: "검사 불합격이면 적용하지 않습니다.",
        outcome: { state: "unobserved" },
        saveDecision: "private",
      },
    })) as { ok: boolean; payload?: { id: string } };
    if (!saved.ok || !saved.payload) throw new Error("private draft save failed");
    const previewRequest = {
      action: "preview",
      draftId: saved.payload.id,
      exactPublishableSentence: "검사와 출하 준비를 확인한 뒤 납기를 검토합니다.",
      applicability: ["queued production plan"],
      targetDepartments: ["production"],
      includeManagementStrategyReview: false,
      reuseEpoch: status.epoch,
      reuseApplicability: {
        workType: "production_readiness",
        department: "production",
        materialGroup: "MAT-GA-DEMO",
        requiredChecks: ["inspection", "packaging"],
      },
      sourceLearningRefs: [],
    };
    let preview = await bridge.learning(envelope(status, previewRequest)) as { ok: boolean; payload?: Record<string, unknown> };
    if (!preview.ok || !preview.payload) throw new Error("learning preview failed");
    const denied = await bridge.learning(envelope(status, { action: "publish", preview: preview.payload, consentGranted: false }));

    status = await switchActor(status, "production-demo");
    const privateProjection = await bridge.read(envelope(status, {})) as { ok: boolean; payload?: { snapshot: SnapshotProjection } };
    const wrongAuthor = await bridge.learning(envelope(status, { action: "publish", preview: preview.payload, consentGranted: true }));

    status = await switchActor(status, "sales-demo");
    preview = await bridge.learning(envelope(status, previewRequest)) as { ok: boolean; payload?: Record<string, unknown> };
    if (!preview.ok || !preview.payload) throw new Error("second learning preview failed");
    const published = await bridge.learning(envelope(status, { action: "publish", preview: preview.payload, consentGranted: true })) as {
      ok: boolean;
      payload?: { id: string; version: number };
    };
    if (!published.ok || !published.payload) throw new Error("learning publish failed");
    const asset = { id: published.payload.id, version: published.payload.version };

    status = await switchActor(status, "production-demo");
    const sharedProjection = await bridge.read(envelope(status, {})) as { ok: boolean; payload?: { snapshot: SnapshotProjection } };
    const wrongWithdrawal = await bridge.learning(envelope(status, { action: "withdraw", assetId: asset.id, version: asset.version }));

    status = await switchActor(status, "sales-demo");
    const withdrawal = await bridge.learning(envelope(status, { action: "withdraw", assetId: asset.id, version: asset.version }));
    const authorAfter = await bridge.read(envelope(status, {})) as { ok: boolean; payload?: { snapshot: SnapshotProjection } };
    status = await switchActor(status, "production-demo");
    const productionAfter = await bridge.read(envelope(status, {})) as { ok: boolean; payload?: { snapshot: SnapshotProjection } };
    return { denied, privateProjection, wrongAuthor, published, sharedProjection, wrongWithdrawal, withdrawal, authorAfter, productionAfter, asset };
  }, { task, evidenceRefs: intent.evidenceRefs });

  expect(outcome.denied).toMatchObject({ ok: false, error: { code: "invalid_input", message: "consent_required" } });
  expect(outcome.privateProjection).toMatchObject({
    ok: true,
    payload: { snapshot: { records: { experienceDrafts: [], learningAssets: [], learningWithdrawals: [] } } },
  });
  expect(outcome.wrongAuthor).toMatchObject({ ok: false, error: { code: "unauthorized_role", message: "author_required" } });
  expect(outcome.sharedProjection.payload?.snapshot.records.learningAssets).toEqual([
    expect.objectContaining({ id: outcome.asset.id, version: outcome.asset.version }),
  ]);
  expect(outcome.wrongWithdrawal).toMatchObject({ ok: false, error: { code: "unauthorized_role", message: "author_required" } });
  expect(outcome.withdrawal).toMatchObject({ ok: true, payload: { assetId: outcome.asset.id, version: outcome.asset.version } });
  expect(outcome.productionAfter.payload?.snapshot.records).toMatchObject({
    experienceDrafts: [],
    learningAssets: [],
    learningWithdrawals: [],
    learningSearch: [],
    learningRecommendations: [],
    learningAiContext: [],
  });
  expect(outcome.authorAfter.payload?.snapshot.records.learningAssets).toEqual([]);
  expect(outcome.authorAfter.payload?.snapshot.records.learningProvenance).toEqual([
    expect.objectContaining({ id: outcome.asset.id, version: outcome.asset.version, withdrawn: true }),
  ]);
  const persisted = await readSnapshot() as {
    records: { experienceDrafts: Array<Record<string, unknown>>; learningAssets: Array<Record<string, unknown>>; learningWithdrawals: Array<Record<string, unknown>> };
  };
  expect(persisted.records.experienceDrafts).toHaveLength(1);
  expect(persisted.records.learningAssets).toEqual([expect.objectContaining({ id: outcome.asset.id, version: outcome.asset.version })]);
  expect(persisted.records.learningWithdrawals).toEqual([expect.objectContaining({ assetId: outcome.asset.id, version: outcome.asset.version })]);
  const diagnostics = await readStubDiagnostics();
  expect(diagnostics).toMatchObject({ runtimeMode: "stub", actualAI: false, providerCalls: 0 });
  await writeNamedEvidence("task-22-consent.json", {
    scenario: "private draft -> denied consent -> explicit author consent -> wrong-author withdrawal denied -> author withdrawal",
    result: "passed",
    asset: outcome.asset,
    providerCalls: 0,
    privateDraftsVisibleToProductionBeforeShare: outcome.privateProjection.payload?.snapshot.records.experienceDrafts.length,
    activeAssetsVisibleToProductionAfterWithdrawal: outcome.productionAfter.payload?.snapshot.records.learningAssets.length,
  });
});
