import { expect, test } from "@playwright/test";
import { readFile, rm, writeFile } from "node:fs/promises";
import path from "node:path";
import { createScopedNetworkLauncher, launchPackagedNormal } from "./packaged-product.helpers";

const appPath = process.env.BNC_PRODUCT_APP;
const executablePath = process.env.BNC_PRODUCT_EXECUTABLE;
const profilePath = process.env.BNC_PRODUCT_PROFILE;
const evidenceDirectory = process.env.BNC_PRODUCT_EVIDENCE;
const networkSupported = process.env.BNC_PRODUCT_NETWORK_SUPPORTED === "1";

test("packaged product uses one isolated normal profile across restart and boots inside the scoped network wrapper", async () => {
  expect(appPath).toBeTruthy();
  expect(executablePath).toBeTruthy();
  expect(profilePath).toBeTruthy();
  expect(evidenceDirectory).toBeTruthy();
  if (!appPath || !executablePath || !profilePath || !evidenceDirectory) throw new Error("packaged product environment is incomplete");

  const launches: Array<{ appIsPackaged: boolean; userDataRealpath: string }> = [];
  for (let iteration = 0; iteration < 2; iteration += 1) {
    const launch = await launchPackagedNormal(executablePath, profilePath);
    const page = await launch.app.firstWindow();
    await expect(page.locator("body")).toBeVisible();
    launches.push({ appIsPackaged: launch.appIsPackaged, userDataRealpath: launch.userDataRealpath });
    if (iteration === 0) await page.screenshot({ path: path.join(evidenceDirectory, "boot.png") });
    await launch.app.close();
  }
  expect(launches).toEqual([
    { appIsPackaged: true, userDataRealpath: profilePath },
    { appIsPackaged: true, userDataRealpath: profilePath },
  ]);

  let scopedBoot: boolean | null = null;
  if (networkSupported) {
    const scoped = await createScopedNetworkLauncher({ appPath, executablePath, evidenceDirectory });
    try {
      const launch = await launchPackagedNormal(scoped.executablePath, profilePath);
      scopedBoot = launch.appIsPackaged;
      await expect(await launch.app.firstWindow()).toBeTruthy();
      await launch.app.close();
    } finally {
      await rm(scoped.executablePath, { force: true });
      await rm(scoped.profilePath, { force: true });
    }
    expect(scopedBoot).toBe(true);
  }

  const snapshotPath = path.join(profilePath, "company-runtime", "snapshot.json");
  const snapshot = JSON.parse(await readFile(snapshotPath, "utf8"));
  await writeFile(path.join(evidenceDirectory, "isolation.json"), `${JSON.stringify({ status: "PASS", appIsPackaged: true, normalLaunches: 2, cleanExits: 2, smokeArgumentUsed: false, sameProfile: true, userDataRealpath: profilePath, scopedNetworkBoot: scopedBoot, networkStatus: networkSupported ? "PASS" : "BLOCKED", providerInferenceCalls: 0, snapshotReadback: { parsed: true, epoch: snapshot.epoch ?? null, revision: snapshot.revision ?? null, recordKeys: Object.keys(snapshot.records ?? {}).sort() } }, null, 2)}\n`);
  await writeFile(path.join(evidenceDirectory, "cleanup.json"), `${JSON.stringify({ status: "pending_launcher_cleanup", appProcessesClosed: true, wrapperRemoved: true, profileRemovalOwner: "verify-company-product.mjs" }, null, 2)}\n`);
});
