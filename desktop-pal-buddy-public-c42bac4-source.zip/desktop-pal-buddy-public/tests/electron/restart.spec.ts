import { expect } from "@playwright/test";
import { applyApprovedChange, createProposal, launchNative, openWorkspace, selectProductionAndApprove, taskRecord, test, writeNamedEvidence } from "./fixtures";

test("@task15 native relaunch persists priority, version, execution, approval, evidence, and strategy identity", async ({ app, page, userDataDir, readSnapshot }) => {
  await createProposal(page);
  await selectProductionAndApprove(page);
  await applyApprovedChange(page);
  await expect(page.getByText(/관찰 priority\/version 1\/v2 · 일치/)).toBeVisible();
  const first = await taskRecord(readSnapshot);
  const taskId = first.task.workboardTaskId;
  const executionId = first.records.executions[0].id;
  const approvalId = first.records.approvals[0].id;
  const strategyRef = (first.snapshot.current as { activeStrategyRef: { strategy_id: string; strategy_version_id: string } }).activeStrategyRef;
  const readbackEvidence = structuredClone(first.records.readbackEvidence[0]);
  await app.close();

  const reopened = await launchNative(userDataDir);
  const reopenedPage = await reopened.firstWindow();
  reopenedPage.setDefaultTimeout(10_000);
  await openWorkspace(reopenedPage, "tasks");
  await reopenedPage.getByRole("button", { name: /PP-DEMO-1001/ }).first().click({ force: true });
  await reopenedPage.waitForTimeout(500);
  const body = await reopenedPage.locator("body").innerText();
  expect(body).toContain("PP-DEMO-1001");
  expect(body).toContain("priority 5 → 1");
  expect(body).toContain("실행 verified · mode apply");
  expect(body).toContain("사업 결과 미관찰");
  const persisted = await taskRecord(readSnapshot);
  expect(persisted.task.workboardTaskId).toBe(taskId);
  expect(persisted.records.executions[0].id).toBe(executionId);
  expect(persisted.records.approvals[0].id).toBe(approvalId);
  expect(persisted.task.status).toBe("done");
  expect((persisted.snapshot.current as { productionPlans: Array<{ id: string; priority: number; version: number }>; activeStrategyRef: { strategy_id: string; version: number } }).productionPlans.find((candidate) => candidate.id === "PP-DEMO-1001")).toMatchObject({ priority: 1, version: 2 });
  expect(persisted.snapshot.current).toMatchObject({ activeStrategyRef: strategyRef });
  const persistedCurrent = persisted.snapshot.current as { activeStrategyRef: { strategy_id: string; strategy_version_id: string } };
  expect(persistedCurrent.activeStrategyRef).toEqual(strategyRef);
  expect(persisted.records.readbackEvidence[0]).toEqual(readbackEvidence);
  await writeNamedEvidence("task-15-verification.json", {
    commit: process.env.TASK15_COMMIT ?? "pending",
    planSha: "d502b297fd05a7de5a00893ae4114968b46441ec94b3438e5c7160d392d0f95d",
    scenario: "native close -> relaunch same userData",
    result: "passed",
    ids: { workboardTaskId: taskId, executionId, approvalId },
    persistedReadbackEvidence: persisted.records.readbackEvidence[0],
    pinnedStrategyRefBefore: strategyRef,
    pinnedStrategyRefAfter: persistedCurrent.activeStrategyRef,
    commands: ["npm run test:electron", "npm run typecheck", "npm run lint"],
  });
  await reopened.close();
});
