import { createHash } from "node:crypto";
import path from "node:path";
import { expect } from "@playwright/test";
import { openWorkspace, test, writeNamedEvidence } from "./fixtures";

type RuntimeSnapshot = {
  readonly records: {
    readonly tasks: readonly { readonly workboardTaskId: string }[];
    readonly executions: readonly { readonly id: string }[];
    readonly readbackEvidence: readonly { readonly executionId: string }[];
  };
};

function snapshotHash(snapshot: RuntimeSnapshot): string {
  return createHash("sha256").update(JSON.stringify(snapshot)).digest("hex");
}

async function createVerifiedTaskThroughBridge(page: Parameters<typeof openWorkspace>[0]): Promise<string> {
  return page.evaluate(async () => {
    const bridge = window.companyRuntime;
    if (!bridge) throw new Error("company runtime bridge missing");
    const field = (value: unknown, key: string): unknown => value !== null && typeof value === "object"
      ? Reflect.get(value, key)
      : undefined;
    const requireString = (value: unknown, label: string): string => {
      if (typeof value !== "string") throw new Error(`${label} missing`);
      return value;
    };
    const requireNumber = (value: unknown, label: string): number => {
      if (typeof value !== "number") throw new Error(`${label} missing`);
      return value;
    };
    const envelope = (status: unknown, payload: unknown) => ({
      schemaVersion: 1,
      requestId: crypto.randomUUID(),
      epoch: requireString(field(status, "epoch"), "epoch"),
      actorSessionRevision: requireNumber(field(status, "actorSessionRevision"), "actor session revision"),
      payload,
    });
    const boot = await bridge.bootstrap({
      schemaVersion: 1,
      requestId: crypto.randomUUID(),
      epoch: null,
      actorSessionRevision: null,
      payload: {},
    });
    const sales = field(field(boot, "payload"), "status");
    const submitted = await bridge.submit(envelope(sales, { requestText: "SO-DEMO-1001 priority 1" }));
    const workboardTaskId = requireString(field(field(field(submitted, "payload"), "task"), "workboardTaskId"), "task id");
    const role = await bridge.role(envelope(sales, { actorId: "production-demo" }));
    const production = {
      epoch: requireString(field(role, "epoch"), "production epoch"),
      actorSessionRevision: requireNumber(field(role, "actorSessionRevision"), "production revision"),
    };
    const approved = await bridge.approve(envelope(production, { workboardTaskId, decision: "approved" }));
    const approvalId = requireString(field(field(field(approved, "payload"), "approval"), "id"), "approval id");
    await bridge.execute(envelope(production, { workboardTaskId, approvalId }));
    return workboardTaskId;
  });
}

test("@task9 explains a selected verified result without mutating the stored company snapshot", async ({ page, readSnapshot, readStubDiagnostics }) => {
  // Given: the real Electron surface has one explicitly approved, applied, and verified task.
  await openWorkspace(page, "gateway");
  const workboardTaskId = await createVerifiedTaskThroughBridge(page);
  await page.getByRole("button", { name: "작업", exact: true }).click();
  await page.getByText(/가상 ERP 생산계획 PP-DEMO-1001의 우선순위를 검토/).first().click();
  await expect(page.getByText(/관찰 priority\/version 1\/v2 · 일치/)).toBeVisible();
  const before = await readSnapshot() as RuntimeSnapshot;
  const beforeHash = snapshotHash(before);

  // When: the employee asks for the selected task's result explanation through the public UI.
  await page.getByRole("button", { name: "결과 설명", exact: true }).click();

  // Then: the stub-labelled explanation cites the selected task's readback and leaves stored bytes unchanged.
  const explanation = page.getByRole("region", { name: "확인된 결과 설명" });
  await expect(explanation).toContainText("결정론적 Stub · 실제 AI 아님");
  await expect(explanation).toContainText("사업 결과");
  const after = await readSnapshot() as RuntimeSnapshot;
  const afterHash = snapshotHash(after);
  expect(afterHash).toBe(beforeHash);
  const executionId = after.records.executions[0]?.id;
  expect(executionId).toBeTruthy();
  const allowedCitation = `readback:${executionId}`;
  await expect(explanation).toContainText(allowedCitation);
  expect(after.records.readbackEvidence).toEqual([expect.objectContaining({ executionId })]);
  const diagnostics = await readStubDiagnostics();
  expect(diagnostics).toMatchObject({ runtimeMode: "stub", actualAI: false, providerCalls: 0 });
  expect(diagnostics.calls).toEqual(expect.arrayContaining([expect.objectContaining({ operation: "explain" })]));
  const evidenceDir = process.env.BNC_QA_EVIDENCE_DIR;
  if (!evidenceDir) throw new Error("BNC_QA_EVIDENCE_DIR is required for Task 9 evidence");
  await explanation.scrollIntoViewIfNeeded();
  await page.screenshot({ path: path.join(evidenceDir, "explanation.png"), fullPage: true });
  await writeNamedEvidence("before-after.json", {
    scenario: "selected verified task -> explicit result explanation",
    workboardTaskId,
    allowedCitations: [allowedCitation],
    renderedCitations: [allowedCitation],
    beforeHash,
    afterHash,
    unchanged: beforeHash === afterHash,
    actualAI: diagnostics.actualAI,
    providerCalls: diagnostics.providerCalls,
  });
});
