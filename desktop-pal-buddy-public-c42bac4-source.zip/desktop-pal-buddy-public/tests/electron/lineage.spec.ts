import { expect, type Locator } from "@playwright/test";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { applyApprovedChange, createProposal, selectProductionAndApprove, test } from "./fixtures";

const evidenceDir = path.resolve(import.meta.dirname, "../../.omo/evidence/brave-new-company-future-erp/task-21");

type RuntimeSnapshot = {
  current: {
    activeStrategyRef: { strategy_id: string; strategy_version_id: string };
    strategyVersions: Array<{ strategy_id: string; strategy_version_id: string; version: number; objective: string; review_question: string; content_hash: string }>;
  };
  records: {
    tasks: Array<{ workboardTaskId: string; packetTaskId: string; epoch: string; status: string; packet: { request_summary: string }; currentProposal: { intentId: string; revision: number } | null; executionId: string | null }>;
    actionIntents: Array<{ id: string; revision: number; workboardTaskId: string; packetTaskId: string; epoch: string; evidenceRefs: string[] }>;
    approvals: Array<{ id: string; intentId: string; intentRevision: number; epoch: string; decision: string }>;
    executions: Array<{ id: string; intentId: string; approvalId: string | null; epoch: string; state: string }>;
    readbackEvidence: Array<{ executionId: string; observedVersion: number; epoch: string; targetPlanId: string; matches: boolean }>;
    assessmentEvidence: Array<{ id: string; packetTaskId: string; epoch: string; finding: string; usedAssetRef: { assetId: string; version: number } | null }>;
    experienceDrafts: Array<{ id: string; version: number }>;
    learningAssets: Array<{ id: string; version: number; sourceDraft: { id: string; version: number }; sourceWorkItem: { workboardTaskId: string; packetTaskId: string }; sharingState: string }>;
    strategyReviews: Array<{ id: string; evidenceSnapshot: Array<{ kind: string; id: string; version: number }>; resultingStrategyRef: { strategy_id: string; strategy_version_id: string } | null }>;
  };
};

type ExpectedRelation = {
  kind: string;
  id: string;
  version: number;
  status: "available" | "missing" | "unobserved";
  reason?: string;
  fields?: Array<{ label: string; value: string }>;
};

test("@task21 lineage navigates strategy work evidence experience reuse and review with exact persisted refs", async ({ page, readSnapshot, readStubDiagnostics }) => {
  // Given: v1 produces one approved, executed, and read-back task.
  await mkdir(evidenceDir, { recursive: true });
  await createProposal(page);
  await selectProductionAndApprove(page);
  await applyApprovedChange(page);
  await expect(page.getByText(/실행 verified · mode apply/)).toBeVisible();
  const executed = await readSnapshot() as RuntimeSnapshot;
  const sourceTask = executed.records.tasks[0];
  const sourceIntent = executed.records.actionIntents.find((item) => item.workboardTaskId === sourceTask?.workboardTaskId);
  expect(sourceTask).toBeDefined();
  expect(sourceIntent).toBeDefined();
  if (!sourceTask || !sourceIntent) throw new Error("lineage source task missing");

  // When: the employee explicitly shares learning, production reuses it, and management records v2.
  await page.getByRole("button", { name: "영업 역할로 전환", exact: true }).click({ force: true });
  const published = await page.evaluate(async ({ task, evidenceRefs }) => {
    const bridge = window.companyRuntime;
    if (!bridge) return null;
    const bootstrap = await bridge.bootstrap({ schemaVersion: 1, requestId: crypto.randomUUID(), epoch: null, actorSessionRevision: null, payload: {} }) as { ok: boolean; payload: { status: { epoch: string; actorSessionRevision: number } } };
    if (!bootstrap.ok) throw new Error("bootstrap failed");
    const envelope = (payload: Record<string, unknown>) => ({ schemaVersion: 1, requestId: crypto.randomUUID(), epoch: bootstrap.payload.status.epoch, actorSessionRevision: bootstrap.payload.status.actorSessionRevision, payload });
    const saved = await bridge.experience(envelope({
      workboardTaskId: task.workboardTaskId,
      draft: {
        authorActorId: "sales-demo",
        workItem: { workboardTaskId: task.workboardTaskId, packetTaskId: task.packetTaskId },
        sourceEvidenceIds: evidenceRefs,
        asset: { id: "PP-DEMO-1001", version: 1 },
        correction: "검사와 포장 상태를 함께 확인합니다.",
        applicability: ["queued production plan"],
        counterexample: "검사 실패 시 적용하지 않습니다.",
        outcome: { state: "unobserved" },
        saveDecision: "shared_review",
      },
    })) as { ok: boolean; payload: { id: string } };
    if (!saved.ok) throw new Error("experience save failed");
    const preview = await bridge.learning(envelope({
      action: "preview",
      draftId: saved.payload.id,
      exactPublishableSentence: "검사와 포장 상태를 함께 확인합니다.",
      applicability: ["queued production plan"],
      targetDepartments: ["production"],
      includeManagementStrategyReview: true,
      reuseEpoch: bootstrap.payload.status.epoch,
      reuseApplicability: { workType: "production_readiness", department: "production", materialGroup: "MAT-GA-DEMO", requiredChecks: ["inspection", "packaging"] },
      sourceLearningRefs: [],
    })) as { ok: boolean; payload: Record<string, unknown> };
    if (!preview.ok) throw new Error("learning preview failed");
    return bridge.learning(envelope({ action: "publish", preview: preview.payload, consentGranted: true })) as Promise<{ ok: boolean; payload: { id: string; version: number; sourceDraft: { id: string; version: number } } }>;
  }, { task: sourceTask, evidenceRefs: sourceIntent.evidenceRefs });
  expect(published).toMatchObject({ ok: true, payload: { version: 1 } });
  if (!published?.ok) throw new Error("learning publish failed");

  await page.getByRole("button", { name: "요청", exact: true }).click({ force: true });
  await page.getByRole("button", { name: "생산 역할로 전환", exact: true }).click({ force: true });
  await expect(page.getByRole("button", { name: "생산 역할로 전환", exact: true })).toHaveAttribute("aria-pressed", "true");
  const reused = await page.evaluate(async () => {
    const bridge = window.companyRuntime;
    if (!bridge) return null;
    const bootstrap = await bridge.bootstrap({ schemaVersion: 1, requestId: crypto.randomUUID(), epoch: null, actorSessionRevision: null, payload: {} }) as { ok: boolean; payload: { status: { epoch: string; actorSessionRevision: number } } };
    if (!bootstrap.ok) throw new Error("bootstrap failed");
    return bridge.reviewReadiness({
      schemaVersion: 1,
      requestId: crypto.randomUUID(),
      epoch: bootstrap.payload.status.epoch,
      actorSessionRevision: bootstrap.payload.status.actorSessionRevision,
      payload: { orderId: "SO-DEMO-1002", targetPlanId: "PP-DEMO-1002", useLatestLearning: true },
    }) as Promise<{ ok: boolean; payload: { assessment: { usedAssetRef: { assetId: string; version: number } | null } } }>;
  });
  expect(reused).toMatchObject({
    ok: true,
    payload: {
      assessment: {
        usedAssetRef: { assetId: published.payload.id, version: published.payload.version },
      },
    },
  });
  await page.getByRole("button", { name: "경영 역할로 전환", exact: true }).click({ force: true });
  const reviewPanel = page.getByRole("region", { name: "경영 전략 검토" });
  await expect(reviewPanel).toBeVisible();
  await reviewPanel.getByRole("button", { name: "새 전략 버전 만들기", exact: true }).click({ force: true });
  await expect(reviewPanel).toContainText("전략 v2를 만들었습니다.");

  // Then: the read-only lineage opens exact task relations and returns to the originating task.
  const persisted = await readSnapshot() as RuntimeSnapshot;
  expect(persisted.records.tasks).toHaveLength(2);
  expect(persisted.records.strategyReviews).toHaveLength(1);
  expect(persisted.current.strategyVersions).toEqual(expect.arrayContaining([expect.objectContaining({ version: 2 })]));
  const firstTask = persisted.records.tasks[0];
  const reuseTask = persisted.records.tasks[1];
  const review = persisted.records.strategyReviews[0];
  const panel = page.getByRole("region", { name: "전략-경험 계보" });
  await expect(panel).toContainText(`${persisted.current.activeStrategyRef.strategy_id} · v1`);
  await expect(panel).toContainText("가상 데이터 · 읽기 전용");
  await expect(panel).toContainText(`${review?.resultingStrategyRef?.strategy_version_id}`);
  await page.screenshot({ path: path.join(evidenceDir, "lineage-gateway.png"), fullPage: true });

  await panel.getByRole("button", { name: `업무 ${firstTask?.workboardTaskId} 열기` }).click({ force: true });
  const workboardPanel = page.getByRole("region", { name: "전략-경험 계보" });
  await expect(workboardPanel).toContainText("unobserved");
  const navigatedRelations: ExpectedRelation[] = [];
  const openExactRelation = async (scope: Locator, relation: ExpectedRelation) => {
    const button = scope.getByRole("button", { name: `${relation.kind} ${relation.id} v${relation.version} ${relation.status} 보기` }).first();
    await expect(button).toBeVisible();
    await button.click();
    await expect(workboardPanel).toContainText(`${relation.kind} · ${relation.id} · v${relation.version}`);
    await expect(workboardPanel.getByRole("status")).toContainText(relation.reason ?? `${relation.kind}/${relation.id} v${relation.version}`);
    if (relation.status === "available") {
      expect(relation.fields?.length).toBeGreaterThan(0);
      const detail = workboardPanel.getByRole("region", { name: "저장 레코드 상세" });
      for (const field of relation.fields ?? []) {
        await expect(detail).toContainText(field.label);
        await expect(detail).toContainText(field.value);
      }
      if (relation.kind === "resulting_strategy") await page.screenshot({ path: path.join(evidenceDir, "lineage-record-detail.png"), fullPage: true });
    } else {
      await expect(workboardPanel.getByRole("region", { name: "저장 레코드 상세" })).toHaveCount(0);
    }
    await workboardPanel.getByRole("button", { name: "계보로 돌아가기" }).click({ force: true });
    await expect(workboardPanel.getByRole("status")).toHaveCount(0);
    navigatedRelations.push(relation);
  };
  const expectedRelations: ExpectedRelation[] = [
    { kind: "packet_strategy", id: persisted.current.activeStrategyRef.strategy_version_id, version: 1, status: "available", fields: [{ label: "objective", value: persisted.current.strategyVersions[0]?.objective ?? "" }, { label: "content_hash", value: persisted.current.strategyVersions[0]?.content_hash ?? "" }] },
    { kind: "proposal", id: sourceIntent.id, version: sourceIntent.revision, status: "available", fields: [{ label: "workboardTaskId", value: sourceIntent.workboardTaskId }, { label: "epoch", value: sourceIntent.epoch }] },
    { kind: "approval", id: persisted.records.approvals[0]?.id, version: 1, status: "available", fields: [{ label: "intentId", value: persisted.records.approvals[0]?.intentId ?? "" }, { label: "decision", value: persisted.records.approvals[0]?.decision ?? "" }] },
    { kind: "execution", id: persisted.records.executions[0]?.id, version: 1, status: "available", fields: [{ label: "approvalId", value: persisted.records.executions[0]?.approvalId ?? "" }, { label: "state", value: persisted.records.executions[0]?.state ?? "" }] },
    { kind: "readback", id: persisted.records.readbackEvidence[0]?.executionId, version: persisted.records.readbackEvidence[0]?.observedVersion, status: "available", fields: [{ label: "targetPlanId", value: persisted.records.readbackEvidence[0]?.targetPlanId ?? "" }, { label: "matches", value: String(persisted.records.readbackEvidence[0]?.matches) }] },
    { kind: "outcome", id: firstTask?.packetTaskId, version: 1, status: "unobserved", reason: "business outcome has not been observed" },
    { kind: "experience", id: published.payload.sourceDraft.id, version: published.payload.sourceDraft.version, status: "missing", reason: "referenced experience draft is not stored in this projection" },
    { kind: "learning", id: published.payload.id, version: published.payload.version, status: "available", fields: [{ label: "sourceDraft", value: `${published.payload.sourceDraft.id} v${published.payload.sourceDraft.version}` }, { label: "sharingState", value: "shared" }] },
  ];
  for (const relation of expectedRelations) await openExactRelation(workboardPanel, relation);

  await workboardPanel.getByRole("button", { name: `업무 ${reuseTask?.workboardTaskId} 열기` }).click({ force: true });
  const reuseAssessment = persisted.records.assessmentEvidence.find((item) => item.packetTaskId === reuseTask?.packetTaskId);
  expect(reuseAssessment).toBeDefined();
  if (!reuseAssessment) throw new Error("reuse assessment missing");
  await openExactRelation(workboardPanel, { kind: "assessment", id: reuseAssessment.id, version: 1, status: "available", fields: [{ label: "packetTaskId", value: reuseAssessment.packetTaskId }, { label: "finding", value: reuseAssessment.finding }] });
  await openExactRelation(workboardPanel, { kind: "reuse", id: published.payload.id, version: published.payload.version, status: "available", fields: [{ label: "sourceDraft", value: `${published.payload.sourceDraft.id} v${published.payload.sourceDraft.version}` }, { label: "sharingState", value: "shared" }] });

  expect(review).toBeDefined();
  if (!review) throw new Error("strategy review missing");
  const reviewRegion = workboardPanel.getByRole("region", { name: `전략 검토 ${review.id}` });
  for (const evidence of review.evidenceSnapshot) {
    const field = evidence.kind === "assessment"
      ? { label: "finding", value: persisted.records.assessmentEvidence.find((item) => item.id === evidence.id)?.finding ?? "" }
      : evidence.kind === "readback"
        ? { label: "targetPlanId", value: persisted.records.readbackEvidence.find((item) => item.executionId === evidence.id && item.observedVersion === evidence.version)?.targetPlanId ?? "" }
        : evidence.kind === "task"
          ? { label: "request_summary", value: persisted.records.tasks.find((item) => item.workboardTaskId === evidence.id)?.packet.request_summary ?? "" }
          : { label: "sharingState", value: persisted.records.learningAssets.find((item) => item.id === evidence.id && item.version === evidence.version)?.sharingState ?? "" };
    expect(field.value).not.toBe("");
    await openExactRelation(reviewRegion, { kind: evidence.kind, id: evidence.id, version: evidence.version, status: "available", fields: [field] });
  }
  const resultingStrategy = persisted.current.strategyVersions.find((item) => item.strategy_version_id === review.resultingStrategyRef?.strategy_version_id);
  expect(resultingStrategy).toBeDefined();
  if (!resultingStrategy) throw new Error("resulting strategy version missing");
  await openExactRelation(reviewRegion, {
    kind: "resulting_strategy",
    id: resultingStrategy.strategy_version_id,
    version: resultingStrategy.version,
    status: "available",
    fields: [{ label: "objective", value: resultingStrategy.objective }, { label: "content_hash", value: resultingStrategy.content_hash }],
  });

  await workboardPanel.getByRole("button", { name: "원래 업무로 돌아가기" }).click({ force: true });
  await expect(page.getByRole("region", { name: "런타임 소유 작업 상세" })).toContainText(firstTask?.packet.request_summary ?? "missing");
  await page.screenshot({ path: path.join(evidenceDir, "lineage-workboard.png"), fullPage: true });

  const diagnostics = await readStubDiagnostics();
  expect(diagnostics).toMatchObject({ runtimeMode: "stub", actualAI: false, providerCalls: 0 });
  const nativeEvidence = {
    scenario: "v1 -> approved execution/readback -> shared learning -> production reuse -> strategy review/v2 -> lineage navigation/back",
    strategy: persisted.current.strategyVersions.map((item) => ({ id: item.strategy_version_id, version: item.version, hash: item.content_hash })),
    taskIds: persisted.records.tasks.map((item) => ({ workboardTaskId: item.workboardTaskId, packetTaskId: item.packetTaskId })),
    navigatedRelations,
    learningAsset: published.payload,
    assessmentId: persisted.records.assessmentEvidence.at(-1)?.id,
    reviewId: review?.id,
    providerCalls: diagnostics.providerCalls,
    result: "passed",
  };
  const serializedEvidence = `${JSON.stringify(nativeEvidence, null, 2)}\n`;
  await Promise.all([
    writeFile(path.join(evidenceDir, "native.json"), serializedEvidence, "utf8"),
    writeFile(path.join(evidenceDir, "task-21-happy.json"), serializedEvidence, "utf8"),
  ]);
});
