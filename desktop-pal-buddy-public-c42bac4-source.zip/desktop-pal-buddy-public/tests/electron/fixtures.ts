/* eslint-disable no-empty-pattern, react-hooks/rules-of-hooks */
import { _electron as electron, expect, test as base, type ElectronApplication, type Page, type TestInfo } from "@playwright/test";
import { existsSync, realpathSync } from "node:fs";
import { mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";

const repoRoot = path.resolve(import.meta.dirname, "../..");
const legacyEvidenceRoot = path.resolve(repoRoot, ".omo/evidence/brave-new-company-future-erp");
const nextEvidenceContainer = path.resolve(repoRoot, ".omo/evidence/brave-new-company-next-product");

function realpathWithMissingSegments(candidate: string): string {
  let cursor = candidate;
  const missingSegments: string[] = [];
  while (!existsSync(cursor)) {
    const parent = path.dirname(cursor);
    if (parent === cursor) return candidate;
    missingSegments.unshift(path.basename(cursor));
    cursor = parent;
  }
  return path.resolve(realpathSync(cursor), ...missingSegments);
}

function isWithin(root: string, candidate: string): boolean {
  return candidate === root || candidate.startsWith(`${root}${path.sep}`);
}

export function resolveEvidenceRoot(configuredPath = process.env.BNC_QA_EVIDENCE_DIR): string {
  if (!configuredPath) return legacyEvidenceRoot;
  if (!path.isAbsolute(configuredPath)) {
    throw new Error("BNC_QA_EVIDENCE_DIR must be an absolute path inside the next-product evidence root");
  }

  const allowedRoot = realpathSync(nextEvidenceContainer);
  const resolvedRoot = realpathWithMissingSegments(path.resolve(configuredPath));
  if (!isWithin(allowedRoot, resolvedRoot)) {
    throw new Error("BNC_QA_EVIDENCE_DIR must resolve inside the next-product evidence root");
  }
  return resolvedRoot;
}

const evidenceRoot = resolveEvidenceRoot();

type Fixtures = {
  app: ElectronApplication;
  page: Page;
  userDataDir: string;
  evidencePath: (name: string) => string;
  readSnapshot: () => Promise<Record<string, unknown>>;
  readStubDiagnostics: () => Promise<Record<string, unknown>>;
};

export const test = base.extend<Fixtures>({
  userDataDir: async ({}, use) => {
    const dir = await mkdtemp(path.join(tmpdir(), "bnc-task15-electron-"));
    await use(dir);
    await rm(dir, { recursive: true, force: true });
  },
  app: async ({ userDataDir }, use, testInfo: TestInfo) => {
    const app = await launchNative(userDataDir);
    await use(app);
    await app.close();
    testInfo.attach("electron-user-data-dir", { body: userDataDir, contentType: "text/plain" });
  },
  page: async ({ app }, use) => {
    const page = await app.firstWindow();
    page.setDefaultTimeout(10_000);
    await use(page);
  },
  evidencePath: async ({}, use, testInfo: TestInfo) => {
    await use((name) => path.join(evidenceRoot, `${testInfo.title.replace(/[^a-z0-9]+/gi, "-").toLowerCase()}-${name}`));
  },
  readSnapshot: async ({ userDataDir }, use) => {
    await use(async () => JSON.parse(await readFile(path.join(userDataDir, "company-runtime/snapshot.json"), "utf8")) as Record<string, unknown>);
  },
  readStubDiagnostics: async ({ userDataDir }, use) => {
    await use(async () => JSON.parse(await readFile(path.join(userDataDir, "company-runtime/stub-diagnostics.json"), "utf8")) as Record<string, unknown>);
  },
});

type NativeLaunchOptions = {
  delayMs?: number;
  faults?: Record<string, boolean>;
};

export async function launchNative(userDataDir: string, delayOrOptions: number | NativeLaunchOptions = 120) {
  const options = typeof delayOrOptions === "number" ? { delayMs: delayOrOptions } : delayOrOptions;
  const delayMs = options.delayMs ?? 120;
  const { BNC_QA_EVIDENCE_DIR: _qaEvidenceDir, ...inheritedEnv } = process.env;
  return electron.launch({
    args: [path.join(repoRoot, "electron/main.mjs"), `--user-data-dir=${userDataDir}`],
    env: {
      ...inheritedEnv,
      BNC_TEST_MODE: "1",
      BNC_TEST_OPTIONS: JSON.stringify({
        dataDir: userDataDir,
        modelStub: { enabled: true, delayMs, diagnosticsPath: path.join(userDataDir, "company-runtime/stub-diagnostics.json") },
        localReadinessProbe: true,
        faults: options.faults ?? {},
      }),
      VITE_APP_MODE: "demo",
      ELECTRON_UPDATE_FEED_URL: "",
      ELECTRON_EXTERNAL_HOSTS: "",
    },
    timeout: 30_000,
  });
}

export async function writeNamedEvidence(name: string, value: Record<string, unknown>) {
  await mkdir(evidenceRoot, { recursive: true });
  await writeFile(path.join(evidenceRoot, name), `${JSON.stringify(value, null, 2)}\n`, "utf8");
}

export async function openWorkspace(page: Page, mode: "gateway" | "tasks" = "gateway") {
  await page.waitForTimeout(700);
  await page.locator("button").first().click({ force: true });
  await page.getByRole("button", { name: "워크스페이스 열기", exact: true }).click({ force: true });
  await page.waitForTimeout(600);
  if (mode === "gateway") await page.getByRole("button", { name: "요청", exact: true }).click({ force: true });
  if (mode === "tasks") await page.getByRole("button", { name: "작업", exact: true }).click({ force: true });
  await page.waitForTimeout(500);
}

export async function establishAiReadiness(page: Page) {
  const readinessButton = page.getByRole("button", { name: "AI 연결 다시 확인", exact: true });
  await expect(readinessButton).toBeVisible();
  await page.screenshot({ path: path.join(evidenceRoot, "task-1-readiness-before-refresh.png"), fullPage: true });
  await writeNamedEvidence("task-1-readiness-before-request.json", {
    scenario: "native first flow establishes app AI readiness before deterministic stub request",
    control: "AI 연결 다시 확인",
    controlVisible: await readinessButton.isVisible(),
    unavailableIndicatorVisible: await page.getByText("AI 연결을 확인할 수 없음 · AI 해석을 시작하지 않습니다", { exact: true }).isVisible(),
  });
  await readinessButton.click();
  await expect(page.getByText("AI 연결 준비됨 · 실제 AI 해석 전", { exact: true }).first()).toBeVisible();
}

export async function createProposal(page: Page) {
  await openWorkspace(page, "gateway");
  await establishAiReadiness(page);
  await submitCompanyRequest(page, "SO-DEMO-1001 priority 1");
  await expect(page.getByRole("heading", { name: "Shadow 변경 미리보기" })).toBeVisible();
  await expect(page.getByText("priority 5 → 1", { exact: true })).toBeVisible();
  await expect(page.locator('section[aria-labelledby="company-request-heading"]').getByText("결정론적 Stub · 실제 AI 아님", { exact: true })).toBeVisible();
  await page.screenshot({ path: path.join(evidenceRoot, "task-15-first-flow-proposal.png"), fullPage: true });
  await page.getByRole("button", { name: "Workboard에서 계속", exact: true }).click({ force: true });
  await page.waitForTimeout(700);
}

export async function submitCompanyRequest(page: Page, requestText: string) {
  await page.getByRole("textbox", { name: "회사 요청" }).fill(requestText);
  const reviewRequest = page.getByRole("button", { name: "회사 요청 검토", exact: true });
  await expect(reviewRequest).toBeEnabled();
  await reviewRequest.click();
}

export async function selectProductionAndApprove(page: Page) {
  await page.getByRole("button", { name: "생산 역할로 전환", exact: true }).click({ force: true });
  await page.waitForTimeout(500);
  await page.getByRole("button", { name: "생산 승인", exact: true }).click({ force: true });
  await page.waitForTimeout(500);
  await expect(page.getByText(/approved · 승인자 production-demo/)).toBeVisible();
  await expect(page.getByRole("button", { name: "승인된 변경 적용", exact: true })).toBeEnabled();
}

export async function applyApprovedChange(page: Page) {
  const applyButton = page.getByRole("button", { name: "승인된 변경 적용", exact: true });
  await expect(applyButton).toBeEnabled();
  await applyButton.click();
}

export async function taskRecord(readSnapshot: () => Promise<Record<string, unknown>>) {
  const snapshot = await readSnapshot();
  const records = snapshot.records as { tasks: Array<Record<string, unknown>>; actionIntents: Array<Record<string, unknown>>; approvals: Array<Record<string, unknown>>; executions: Array<Record<string, unknown>>; readbackEvidence: Array<Record<string, unknown>> };
  expect(records.tasks).toHaveLength(1);
  return { snapshot, records, task: records.tasks[0] };
}
