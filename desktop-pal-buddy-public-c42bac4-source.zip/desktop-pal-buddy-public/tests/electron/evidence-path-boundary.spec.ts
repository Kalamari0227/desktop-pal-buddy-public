import { expect } from "@playwright/test";
import { mkdtemp, rm, symlink } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { resolveEvidenceRoot, test } from "./fixtures";

const expectsRejection = process.env.BNC_EXPECT_EVIDENCE_PATH_REJECTION === "1";

test("host evidence path rejects an escaping configured root before artifact creation", async ({ evidencePath }) => {
  if (expectsRejection) {
    expect(() => evidencePath("boundary-probe.txt")).toThrow(/BNC_QA_EVIDENCE_DIR/);
    return;
  }

  expect(evidencePath("boundary-probe.txt")).toContain("brave-new-company-future-erp");
});

test("explicit relative and symlink escapes are rejected before artifact creation", async () => {
  expect(() => resolveEvidenceRoot("../../outside")).toThrow(/BNC_QA_EVIDENCE_DIR/);

  const outsideRoot = await mkdtemp(path.join(tmpdir(), "bnc-evidence-outside-"));
  const linkPath = path.resolve(".omo/evidence/brave-new-company-next-product", `.boundary-link-${process.pid}`);
  try {
    await symlink(outsideRoot, linkPath);
    expect(() => resolveEvidenceRoot(linkPath)).toThrow(/BNC_QA_EVIDENCE_DIR/);
  } finally {
    await rm(linkPath, { force: true });
    await rm(outsideRoot, { recursive: true, force: true });
  }
});
