import { _electron as electron, expect, test, type ElectronApplication, type Page } from "@playwright/test";
import { spawn } from "node:child_process";
import { randomUUID } from "node:crypto";
import { access, mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import path from "node:path";
import { extractFile } from "@electron/asar";
import { createCodexInterpreter, discoverCodexCli, PROVIDER_TERMINAL_TIMEOUT_MS } from "../../electron/codexInterpreter.mjs";

const repoRoot = path.resolve(import.meta.dirname, "../..");
const evidenceRoot = path.join(repoRoot, ".omo/evidence/brave-new-company-future-erp/task-24");
const restrictedPath = "/usr/bin:/bin:/usr/sbin:/sbin";

type Receipt = {
  readonly platform: "darwin" | "linux";
  readonly appRealpath: string;
  readonly codeTreeDigest: string;
  readonly bundleSha256: string;
  readonly schemas: readonly { readonly path: string; readonly sha256: string }[];
};

type Snapshot = {
  readonly current: { readonly productionPlans: readonly { readonly id: string; readonly priority: number; readonly version: number }[] };
  readonly records: {
    readonly approvals: readonly unknown[];
    readonly executions: readonly { readonly id: string; readonly state: string }[];
    readonly readbackEvidence: readonly { readonly observedPriority: number; readonly observedVersion: number; readonly matches: boolean }[];
  };
};

function appEnvironment() {
  const environment: Record<string, string> = {};
  for (const [key, value] of Object.entries(process.env)) {
    if (value !== undefined) environment[key] = value;
  }
  environment.PATH = restrictedPath;
  environment.VITE_APP_MODE = "demo";
  for (const key of Object.keys(environment)) {
    if (/^(?:BNC_|ELECTRON_UPDATE|ELECTRON_EXTERNAL|SUPABASE|VITE_SUPABASE|OPENAI|ANTHROPIC|ERP)|API_KEY/i.test(key)) delete environment[key];
  }
  return environment;
}

function providerEnvironment() {
  return {
    PATH: restrictedPath,
    HOME: process.env.HOME,
    TMPDIR: process.env.TMPDIR,
    CODEX_HOME: process.env.CODEX_HOME,
  };
}

async function writeEvidence(name: string, value: Record<string, unknown>) {
  await mkdir(evidenceRoot, { recursive: true });
  await writeFile(path.join(evidenceRoot, name), `${JSON.stringify(value, null, 2)}\n`, { mode: 0o600 });
}

async function launchPackaged(): Promise<ElectronApplication> {
  const executablePath = process.env.BNC_PACKAGE_EXECUTABLE;
  if (!executablePath || !path.isAbsolute(executablePath)) throw new Error("verified package executable is missing");
  return electron.launch({ executablePath, args: ["--company-smoke"], env: appEnvironment(), timeout: 30_000 });
}

async function openWorkspace(page: Page) {
  await page.locator("button").first().click({ force: true });
  await page.getByRole("button", { name: "워크스페이스 열기", exact: true }).click({ force: true });
  await page.getByRole("button", { name: "요청", exact: true }).click({ force: true });
}

async function readSnapshot(userDataDir: string): Promise<Snapshot> {
  return JSON.parse(await readFile(path.join(userDataDir, "company-runtime/snapshot.json"), "utf8"));
}

async function extractSchemas(receipt: Receipt, destination: string) {
  const resources = receipt.platform === "darwin"
    ? path.join(receipt.appRealpath, "Contents", "Resources")
    : path.join(receipt.appRealpath, "resources");
  for (const item of receipt.schemas) {
    const filename = path.basename(item.path);
    const unpacked = path.join(resources, "app", item.path);
    const contents = await readFile(unpacked).catch(() => extractFile(path.join(resources, "app.asar"), item.path));
    await writeFile(path.join(destination, filename), contents, { mode: 0o600 });
  }
}

async function expectInjectedLaunchRejected(executablePath: string) {
  await new Promise<void>((resolve, reject) => {
    const child = spawn(executablePath, ["--company-smoke"], {
      env: { ...appEnvironment(), BNC_TEST_MODE: "1", BNC_TEST_OPTIONS: JSON.stringify({ dataDir: "/tmp/rejected", modelStub: { enabled: true } }) },
      stdio: "ignore",
    });
    const timer = setTimeout(() => { child.kill("SIGKILL"); reject(new Error("injected package launch did not terminate")); }, 15_000);
    child.on("error", reject);
    child.on("exit", (code) => {
      clearTimeout(timer);
      if (code === 0) reject(new Error("injected package launch succeeded"));
      else resolve();
    });
  });
}

test("@package-ci packaged native smoke is provider-free and rejects test injection", async () => {
  const executablePath = process.env.BNC_PACKAGE_EXECUTABLE;
  if (!executablePath) throw new Error("verified package executable is missing");
  await expectInjectedLaunchRejected(executablePath);
  const app = await launchPackaged();
  let userDataDir = "";
  try {
    expect(await app.evaluate(({ app: electronApp }) => electronApp.isPackaged)).toBe(true);
    userDataDir = await app.evaluate(({ app: electronApp }) => electronApp.getPath("userData"));
    expect(path.basename(userDataDir)).toMatch(/^bnc-package-smoke-/);
    const page = await app.firstWindow();
    const bootstrap = await page.evaluate(() => window.companyRuntime?.bootstrap({
      schemaVersion: 1, requestId: crypto.randomUUID(), epoch: null, actorSessionRevision: null, payload: {},
    }));
    expect(bootstrap).toMatchObject({ ok: true });
    await writeEvidence("task-24-ci-smoke.json", { status: "PASS", appIsPackaged: true, providerCalls: 0, injectionRejected: true });
  } finally {
    await app.close();
    if (userDataDir) await rm(userDataDir, { recursive: true, force: true });
    if (userDataDir) expect(await access(userDataDir).then(() => true, () => false)).toBe(false);
  }
});

test("@package-live signed-in Codex drives the packaged approval and readback", async () => {
  const receiptPath = process.env.BNC_PACKAGE_RECEIPT;
  if (!receiptPath) throw new Error("package receipt is missing");
  const receipt = JSON.parse(await readFile(receiptPath, "utf8")) as Receipt;
  const discovery = await discoverCodexCli({ pathValue: restrictedPath, environment: providerEnvironment() });
  if (!discovery.ok) {
    await writeEvidence("task-24-package-live.json", { status: "BLOCKED", live: false, actualAI: false, failure: { code: discovery.error.code, reason: discovery.error.reason } });
    throw new Error(`live Codex preflight blocked: ${discovery.error.reason}`);
  }
  const schemaDir = await mkdtemp(path.join(tmpdir(), "bnc-package-schemas-"));
  await extractSchemas(receipt, schemaDir);
  let app: ElectronApplication | null = null;
  let userDataDir = "";
  let electronPid: number | undefined;
  try {
    app = await launchPackaged();
    electronPid = app.process().pid;
    const appIsPackaged = await app.evaluate(({ app: electronApp }) => electronApp.isPackaged);
    expect(appIsPackaged).toBe(true);
    userDataDir = await app.evaluate(({ app: electronApp }) => electronApp.getPath("userData"));
    const page = await app.firstWindow();
    page.setDefaultTimeout(20_000);
    await openWorkspace(page);
    await page.waitForTimeout(2_000);
    await page.getByRole("textbox", { name: "회사 요청" }).fill(
      "가상 주문 SO-DEMO-1001의 생산계획 PP-DEMO-1001 우선순위를 5에서 1로 변경하는 제안을 만들어 주세요. 사람 승인 전에는 실행이나 완료를 주장하지 마세요.",
    );
    await page.getByRole("button", { name: "회사 요청 검토", exact: true }).click({ force: true });
    await expect(page.getByRole("heading", { name: "Shadow 변경 미리보기" })).toBeVisible({ timeout: PROVIDER_TERMINAL_TIMEOUT_MS });
    await expect(page.getByText("호스트 검증 실제 AI", { exact: true })).toBeVisible();
    const before = await readSnapshot(userDataDir);
    expect(before.records.approvals).toHaveLength(0);
    expect(before.records.executions).toHaveLength(0);
    await page.getByRole("button", { name: "Workboard에서 계속", exact: true }).click({ force: true });
    await page.getByRole("button", { name: "생산 역할로 전환", exact: true }).click({ force: true });
    await page.getByRole("button", { name: "생산 승인", exact: true }).click({ force: true });
    await page.getByRole("button", { name: "승인된 변경 적용", exact: true }).click();
    await expect(page.getByText(/실행 verified · mode apply/)).toBeVisible();
    await expect(page.getByText(/관찰 priority\/version 1\/v2 · 일치/)).toBeVisible();
    const verified = await readSnapshot(userDataDir);
    expect(verified.records.executions).toHaveLength(1);
    expect(verified.records.readbackEvidence).toEqual([expect.objectContaining({ observedPriority: 1, observedVersion: 2, matches: true })]);
    const status = await page.evaluate(async () => window.companyRuntime?.bootstrap({
      schemaVersion: 1, requestId: crypto.randomUUID(), epoch: null, actorSessionRevision: null, payload: {},
    }));
    if (!status || typeof status !== "object" || !("payload" in status)) throw new Error("runtime status missing");
    const payload = status.payload;
    if (!payload || typeof payload !== "object" || !("status" in payload)) throw new Error("runtime payload status missing");
    const rawStatus = payload.status;
    if (!rawStatus || typeof rawStatus !== "object" || !("epoch" in rawStatus) || !("actorSessionRevision" in rawStatus)
      || typeof rawStatus.epoch !== "string" || typeof rawStatus.actorSessionRevision !== "number") {
      throw new Error("runtime context missing");
    }
    const runtimeStatus = { epoch: rawStatus.epoch, actorSessionRevision: rawStatus.actorSessionRevision };
    const execution = verified.records.executions[0];
    const evidenceId = `readback:${execution.id}`;
    const factId = `verified-readback:${execution.id}`;
    const adapter = createCodexInterpreter({
      executablePath: discovery.executablePath,
      profileProof: discovery,
      schemaDir,
      getCurrentContext: () => runtimeStatus,
      environment: providerEnvironment(),
    });
    const explanation = await adapter.explain({
      schemaVersion: 1, requestId: randomUUID(), phase: "explain", epoch: runtimeStatus.epoch,
      actorSessionRevision: runtimeStatus.actorSessionRevision, requestText: "검증된 가상 ERP 재조회 사실만 설명하세요.",
      allowedEvidenceIds: [evidenceId], verifiedFacts: [{ id: factId, evidenceId, text: "PP-DEMO-1001은 재조회에서 priority 1, version 2로 기대값과 일치했습니다." }],
    });
    if (!explanation.ok) throw new Error(`packaged explanation failed: ${explanation.error.reason}`);
    expect(explanation).toMatchObject({ ok: true, toolEventCount: 0, actions: [], data: { verifiedFactIds: expect.arrayContaining([factId]), citedEvidenceIds: expect.arrayContaining([evidenceId]), authorityClaims: [] } });
    await page.screenshot({ path: path.join(evidenceRoot, "task-24-package-live.png"), fullPage: true });
    await writeEvidence("task-24-package-live.json", {
      status: "PASS", live: true, actualAI: true, appIsPackaged, providerCalls: 2, mutationCount: 1,
      codex: { executableRealpath: discovery.executablePath, version: discovery.version, childPath: restrictedPath },
      package: { codeTreeDigest: receipt.codeTreeDigest, bundleSha256: receipt.bundleSha256, schemaSource: "verified package payload" },
      readback: verified.records.readbackEvidence[0], explanation: { schemaSha256: explanation.schemaSha256, evidenceBacked: true, toolEventCount: explanation.toolEventCount },
    });
  } catch (error) {
    await writeEvidence("task-24-package-live.json", { status: "BLOCKED", live: false, actualAI: Boolean(app), failure: { name: error instanceof Error ? error.name : "Error", boundary: "packaged_live_scenario" } });
    throw error;
  } finally {
    if (app) await app.close();
    await rm(schemaDir, { recursive: true, force: true });
    if (userDataDir) await rm(userDataDir, { recursive: true, force: true });
    const userDataExists = userDataDir ? await access(userDataDir).then(() => true, () => false) : false;
    let processAlive = false;
    if (electronPid) try { process.kill(electronPid, 0); processAlive = true; } catch { processAlive = false; }
    await writeEvidence("task-24-cleanup.json", { status: userDataExists || processAlive ? "FAIL" : "PASS", remainingProcessCount: processAlive ? 1 : 0, remainingTempDirectoryCount: userDataExists ? 1 : 0 });
    expect(userDataExists).toBe(false);
    expect(processAlive).toBe(false);
  }
});
