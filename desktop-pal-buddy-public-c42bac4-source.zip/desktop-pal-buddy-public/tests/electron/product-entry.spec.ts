import { expect } from "@playwright/test";
import path from "node:path";
import { test, writeNamedEvidence } from "./fixtures";

type RuntimeSnapshot = {
  records: {
    tasks: Array<Record<string, unknown>>;
    actionIntents: Array<Record<string, unknown>>;
  };
};

test("@task4 explicit company-work entry transfers no work until the employee reviews it", async ({ page, readSnapshot, readStubDiagnostics }) => {
  await page.waitForTimeout(700);
  await page.locator("button").first().click({ force: true });
  await page.getByRole("button", { name: "워크스페이스 열기", exact: true }).click({ force: true });
  await page.waitForTimeout(600);

  const beforeTransfer = await readSnapshot() as RuntimeSnapshot;
  const beforeDiagnostics = await readStubDiagnostics();
  expect(beforeTransfer.records.tasks).toHaveLength(0);
  expect(beforeTransfer.records.actionIntents).toHaveLength(0);
  expect(beforeDiagnostics).toMatchObject({ providerCalls: 0, calls: [] });

  await page.getByRole("button", { name: "회사 업무 시작", exact: true }).click();
  const request = page.getByRole("textbox", { name: "회사 요청" });
  await expect(request).toBeVisible();

  const afterTransfer = await readSnapshot() as RuntimeSnapshot;
  const afterTransferDiagnostics = await readStubDiagnostics();
  expect(afterTransfer.records.tasks).toHaveLength(0);
  expect(afterTransfer.records.actionIntents).toHaveLength(0);
  expect(afterTransferDiagnostics).toMatchObject({ providerCalls: 0, calls: [] });

  await request.fill("SO-DEMO-1001 priority 1");
  await page.getByRole("button", { name: "회사 요청 검토", exact: true }).click();
  await expect(page.getByRole("heading", { name: "Shadow 변경 미리보기" })).toBeVisible();

  const reviewed = await readSnapshot() as RuntimeSnapshot;
  const diagnostics = await readStubDiagnostics();
  expect(reviewed.records.tasks).toHaveLength(1);
  expect(reviewed.records.actionIntents).toHaveLength(1);
  expect(diagnostics).toMatchObject({ runtimeMode: "stub", actualAI: false, providerCalls: 0 });
  expect(diagnostics.calls).toEqual([expect.objectContaining({ operation: "interpret" })]);

  const evidenceDir = process.env.BNC_QA_EVIDENCE_DIR;
  if (!evidenceDir) throw new Error("BNC_QA_EVIDENCE_DIR is required for Task 4 evidence");
  await page.screenshot({ path: path.join(evidenceDir, "entry.png"), fullPage: true });
  await writeNamedEvidence("snapshot.json", {
    scenario: "workspace company-work entry -> no transfer side effects -> explicit company review",
    result: "passed",
    beforeTransfer: {
      tasks: beforeTransfer.records.tasks.length,
      reviews: beforeTransfer.records.actionIntents.length,
      providerCalls: beforeDiagnostics.providerCalls,
    },
    afterTransfer: {
      tasks: afterTransfer.records.tasks.length,
      reviews: afterTransfer.records.actionIntents.length,
      providerCalls: afterTransferDiagnostics.providerCalls,
    },
    afterExplicitReview: {
      tasks: reviewed.records.tasks.length,
      reviews: reviewed.records.actionIntents.length,
      providerCalls: diagnostics.providerCalls,
      interpreterOperations: diagnostics.calls,
    },
  });
});
