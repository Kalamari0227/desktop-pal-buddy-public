import { expect } from "@playwright/test";
import path from "node:path";
import { test, writeNamedEvidence } from "./fixtures";

type RuntimeSnapshot = {
  records: {
    tasks: Array<Record<string, unknown>>;
    actionIntents: Array<Record<string, unknown>>;
    approvals: Array<Record<string, unknown>>;
    executions: Array<Record<string, unknown>>;
  };
};

test("@task10 company status labels preserve the explicit entry boundary and rendered task lifecycle", async ({ page, readSnapshot, readStubDiagnostics }) => {
  await page.waitForTimeout(700);
  await page.locator("button").first().click({ force: true });
  await page.getByRole("button", { name: "워크스페이스 열기", exact: true }).click({ force: true });
  await page.waitForTimeout(600);

  const entrySnapshot = await readSnapshot() as RuntimeSnapshot;
  const entryDiagnostics = await readStubDiagnostics();
  expect(entrySnapshot.records.tasks).toHaveLength(0);
  expect(entrySnapshot.records.actionIntents).toHaveLength(0);
  expect(entryDiagnostics).toMatchObject({ actualAI: false, providerCalls: 0 });

  await page.getByRole("button", { name: "회사 업무 시작", exact: true }).click();
  await expect(page.getByText("AI 연결을 확인할 수 없음 · AI 해석을 시작하지 않습니다")).toBeVisible();
  await expect(page.getByText("다음 행동: AI 연결을 다시 확인한 뒤 직접 검토하세요.")).toBeVisible();

  await page.setViewportSize({ width: 1024, height: 900 });
  const evidenceDir = process.env.BNC_QA_EVIDENCE_DIR;
  if (!evidenceDir) throw new Error("BNC_QA_EVIDENCE_DIR is required for Task 10 evidence");
  await page.getByText("다음 행동: AI 연결을 다시 확인한 뒤 직접 검토하세요.").scrollIntoViewIfNeeded();
  await page.getByRole("button", { name: "작업으로 만들기", exact: true }).evaluate((element) => {
    element.scrollIntoView({ block: "center" });
  });
  await page.screenshot({ path: path.join(evidenceDir, "failed-1024.png"), fullPage: true });
  const refreshConnection = page.getByRole("button", { name: "AI 연결 다시 확인", exact: true });
  await refreshConnection.focus();
  await page.keyboard.press("Tab");
  await page.keyboard.press("Shift+Tab");
  await expect(refreshConnection).toBeFocused();
  await page.screenshot({ path: path.join(evidenceDir, "focus-1024.png"), fullPage: true });

  const afterGuidance = await readSnapshot() as RuntimeSnapshot;
  const afterGuidanceDiagnostics = await readStubDiagnostics();
  expect(afterGuidance.records.tasks).toHaveLength(0);
  expect(afterGuidance.records.actionIntents).toHaveLength(0);
  expect(afterGuidanceDiagnostics).toMatchObject({ actualAI: false, providerCalls: 0 });

  const request = page.getByRole("textbox", { name: "회사 요청" });
  await request.fill("SO-DEMO-1001 priority 1");
  await page.getByRole("button", { name: "회사 요청 검토", exact: true }).click();
  await expect(page.getByRole("heading", { name: "Shadow 변경 미리보기" })).toBeVisible();
  await page.getByRole("button", { name: "Workboard에서 계속", exact: true }).click();
  await page.getByRole("button", { name: "생산 역할로 전환", exact: true }).click();
  await page.getByRole("button", { name: "생산 승인", exact: true }).click();
  await expect(page.getByText("승인됨").first()).toBeVisible();
  await page.getByRole("button", { name: "승인된 변경 적용", exact: true }).click();
  await expect(page.getByText("실행 및 재조회 확인됨").first()).toBeVisible();

  await page.setViewportSize({ width: 1440, height: 960 });
  await page.screenshot({ path: path.join(evidenceDir, "verified-1440.png"), fullPage: true });
  const verified = await readSnapshot() as RuntimeSnapshot;
  const diagnostics = await readStubDiagnostics();
  expect(verified.records.tasks).toHaveLength(1);
  expect(verified.records.approvals).toHaveLength(1);
  expect(verified.records.executions).toHaveLength(1);
  expect(diagnostics).toMatchObject({ actualAI: false, providerCalls: 0 });

  await writeNamedEvidence("ui-state-matrix.json", {
    scenario: "explicit company entry -> unavailable connection preflight -> explicit review -> approval -> verified readback",
    result: "passed",
    preflight: {
      label: "AI 연결을 확인할 수 없음 · AI 해석을 시작하지 않습니다",
      actualAI: entryDiagnostics.actualAI,
      providerCalls: entryDiagnostics.providerCalls,
      tasks: entrySnapshot.records.tasks.length,
      actionIntents: entrySnapshot.records.actionIntents.length,
    },
    guidanceOnly: {
      actualAI: afterGuidanceDiagnostics.actualAI,
      providerCalls: afterGuidanceDiagnostics.providerCalls,
      tasks: afterGuidance.records.tasks.length,
      actionIntents: afterGuidance.records.actionIntents.length,
    },
    verified: {
      tasks: verified.records.tasks.length,
      approvals: verified.records.approvals.length,
      executions: verified.records.executions.length,
      actualAI: diagnostics.actualAI,
      providerCalls: diagnostics.providerCalls,
    },
  });
});
