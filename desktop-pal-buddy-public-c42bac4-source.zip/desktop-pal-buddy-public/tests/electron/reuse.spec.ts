import { expect } from "@playwright/test";
import { launchNative, openWorkspace, test, writeNamedEvidence } from "./fixtures";

type RuntimeSnapshot = {
  current: {
    productionPlans: Array<{ id: string; priority: number; version: number }>;
    inspections: Array<Record<string, unknown>>;
    shipments: Array<Record<string, unknown>>;
  };
  records: {
    tasks: Array<Record<string, unknown>>;
    actionIntents: Array<Record<string, unknown>>;
    approvals: Array<Record<string, unknown>>;
    executions: Array<Record<string, unknown>>;
    assessmentEvidence: Array<Record<string, unknown>>;
    learningAssets: Array<Record<string, unknown>>;
  };
};

test("@task19 cross-department-reuse keeps the production review read-only and persists exact learning evidence", async ({ app, page, userDataDir, readSnapshot, readStubDiagnostics, evidencePath }) => {
  // Given: production records a baseline readiness review for the fixed second demo order.
  await openWorkspace(page, "gateway");
  await page.getByRole("button", { name: "생산 역할로 전환", exact: true }).click({ force: true });
  await expect(page.getByRole("button", { name: "생산 역할로 전환", exact: true })).toHaveAttribute("aria-pressed", "true");
  const baselineButton = page.getByRole("button", { name: "기준선 준비 상태 읽기", exact: true });
  await expect(baselineButton).toBeEnabled();
  await page.waitForTimeout(500);
  const before = await readSnapshot() as RuntimeSnapshot;
  await baselineButton.click();
  await expect(page.getByText("사용 학습 없음", { exact: true })).toBeVisible();
  await expect(page.getByText("추가 조회 없음", { exact: true })).toBeVisible();
  const afterBaseline = await readSnapshot() as RuntimeSnapshot;
  const baseline = afterBaseline.records.assessmentEvidence.at(-1);
  expect(baseline).toMatchObject({
    finding: "needs_review",
    usedAssetRef: null,
    requiredChecks: [],
    additionalReadSet: [],
    reuse: { status: "baseline" },
  });

  // When: sales creates a real source task and explicitly publishes its learning for production reuse.
  await page.getByRole("button", { name: "영업 역할로 전환", exact: true }).click({ force: true });
  await expect(page.getByRole("button", { name: "영업 역할로 전환", exact: true })).toHaveAttribute("aria-pressed", "true");
  await page.waitForTimeout(500);
  await page.getByRole("textbox", { name: "회사 요청" }).fill("SO-DEMO-1001 priority 1");
  await page.getByRole("button", { name: "회사 요청 검토", exact: true }).click({ force: true });
  await expect(page.getByRole("heading", { name: "Shadow 변경 미리보기" })).toBeVisible();
  const withProposal = await readSnapshot() as RuntimeSnapshot;
  const proposalTask = withProposal.records.tasks.find((candidate) => candidate.currentProposal !== null) as {
    workboardTaskId: string;
    packetTaskId: string;
  } | undefined;
  const proposal = withProposal.records.actionIntents.find((candidate) => candidate.workboardTaskId === proposalTask?.workboardTaskId) as {
    evidenceRefs: string[];
  } | undefined;
  expect(proposalTask).toBeDefined();
  expect(proposal).toBeDefined();
  if (!proposalTask || !proposal) throw new Error("source proposal missing");
  const published = await page.evaluate(async ({ task, intent }) => {
    const bridge = window.companyRuntime;
    if (!bridge) return null;
    const bootstrap = await bridge.bootstrap({ schemaVersion: 1, requestId: crypto.randomUUID(), epoch: null, actorSessionRevision: null, payload: {} }) as {
      ok: boolean;
      payload: { status: { epoch: string; actorSessionRevision: number } };
    };
    if (!bootstrap.ok) throw new Error("bootstrap failed");
    const { epoch, actorSessionRevision } = bootstrap.payload.status;
    const envelope = (payload: Record<string, unknown>) => ({
      schemaVersion: 1,
      requestId: crypto.randomUUID(),
      epoch,
      actorSessionRevision,
      payload,
    });
    const saved = await bridge.experience(envelope({
      workboardTaskId: task.workboardTaskId,
      draft: {
        authorActorId: "sales-demo",
        workItem: { workboardTaskId: task.workboardTaskId, packetTaskId: task.packetTaskId },
        sourceEvidenceIds: intent.evidenceRefs,
        asset: { id: "PP-DEMO-1001", version: 1 },
        correction: "검사와 출하 준비를 확인한 뒤 납기를 검토합니다.",
        applicability: ["queued production plan"],
        counterexample: "검사 불합격이면 적용하지 않습니다.",
        outcome: { state: "unobserved" },
        saveDecision: "private",
      },
    })) as { ok: boolean; payload: { id: string } };
    if (!saved.ok) throw new Error("experience save failed");
    const previewed = await bridge.learning(envelope({
      action: "preview",
      draftId: saved.payload.id,
      exactPublishableSentence: "검사와 출하 준비를 확인한 뒤 납기를 검토합니다.",
      applicability: ["queued production plan"],
      targetDepartments: ["production"],
      includeManagementStrategyReview: false,
      reuseEpoch: epoch,
      reuseApplicability: {
        workType: "production_readiness",
        department: "production",
        materialGroup: "MAT-GA-DEMO",
        requiredChecks: ["inspection", "packaging"],
      },
      sourceLearningRefs: [],
    })) as { ok: boolean; payload: Record<string, unknown> };
    if (!previewed.ok) throw new Error("learning preview failed");
    return bridge.learning(envelope({ action: "publish", preview: previewed.payload, consentGranted: true })) as Promise<{
      ok: boolean;
      payload: { id: string; version: number; authorActorId: string; reuseApplicability: { requiredChecks: string[] } };
    }>;
  }, { task: proposalTask, intent: proposal });
  expect(published).toMatchObject({
    ok: true,
    payload: { version: 1, authorActorId: "sales-demo", reuseApplicability: { requiredChecks: ["inspection", "packaging"] } },
  });
  if (!published || !published.ok) throw new Error("learning publish failed");
  const assetRef = { assetId: published.payload.id, version: published.payload.version };

  await page.getByRole("button", { name: "생산 역할로 전환", exact: true }).click({ force: true });
  await expect(page.getByRole("button", { name: "생산 역할로 전환", exact: true })).toHaveAttribute("aria-pressed", "true");
  const reuseButton = page.getByRole("button", { name: "승인 학습으로 다시 확인", exact: true });
  await expect(reuseButton).toBeEnabled();
  await page.waitForTimeout(500);
  await reuseButton.click();
  const readinessPanel = page.getByRole("region", { name: "생산 준비 상태 읽기" });
  await expect(readinessPanel).toContainText("추가 확인 필요 · needs_review");
  await expect(readinessPanel).toContainText(`${assetRef.assetId} · v${assetRef.version}`);
  await expect(readinessPanel).toContainText("inspection · INSPECTION-DEMO-1002 · v1");
  await expect(readinessPanel).toContainText("shipment · SHIPMENT-DEMO-1002 · v1");
  await expect(readinessPanel).toContainText("사업 결과 미관찰");

  for (const viewport of [{ width: 375, height: 800 }, { width: 768, height: 900 }, { width: 1280, height: 900 }]) {
    await page.setViewportSize(viewport);
    await page.screenshot({ path: evidencePath(`request-${viewport.width}.png`), fullPage: true });
  }

  // Then: Workboard shows the same immutable evidence and no approval or apply authority.
  await page.getByRole("button", { name: "Workboard에서 근거 보기", exact: true }).click({ force: true });
  const evidencePanel = page.locator('[aria-label="생산 준비 검토 근거"]');
  await expect(evidencePanel).toContainText(`${assetRef.assetId} · v${assetRef.version}`);
  await expect(evidencePanel).toContainText("inspection/INSPECTION-DEMO-1002 · v1");
  await expect(evidencePanel).toContainText("shipment/SHIPMENT-DEMO-1002 · v1");
  await expect(page.getByRole("button", { name: "생산 승인", exact: true })).toHaveCount(0);
  await expect(page.getByRole("button", { name: "승인된 변경 적용", exact: true })).toHaveCount(0);
  for (const viewport of [{ width: 375, height: 800 }, { width: 768, height: 900 }, { width: 1280, height: 900 }]) {
    await page.setViewportSize(viewport);
    await page.screenshot({ path: evidencePath(`workboard-${viewport.width}.png`), fullPage: true });
  }

  const persisted = await readSnapshot() as RuntimeSnapshot;
  const reused = persisted.records.assessmentEvidence.at(-1);
  expect(reused).toMatchObject({
    finding: "needs_review",
    usedAssetRef: assetRef,
    requiredChecks: ["inspection", "packaging"],
    additionalReadSet: [
      { kind: "inspection", id: "INSPECTION-DEMO-1002", version: 1 },
      { kind: "shipment", id: "SHIPMENT-DEMO-1002", version: 1 },
    ],
    reuse: { status: "selected", lineageStatus: "verified" },
    mutationCount: 0,
  });
  expect(reused?.baselineReadSet).toEqual(baseline?.readSet);
  expect(persisted.records.approvals).toHaveLength(0);
  expect(persisted.records.executions).toHaveLength(0);
  expect(persisted.current.productionPlans).toEqual(before.current.productionPlans);
  expect(persisted.current.inspections).toEqual(before.current.inspections);
  expect(persisted.current.shipments).toEqual(before.current.shipments);

  await app.close();
  const reopened = await launchNative(userDataDir);
  try {
    const reopenedPage = await reopened.firstWindow();
    reopenedPage.setDefaultTimeout(10_000);
    await openWorkspace(reopenedPage, "tasks");
    await reopenedPage.getByRole("button", { name: /생산 완료 안내 전 검사·포장 준비 상태를 읽기 전용으로 검토/ }).first().click({ force: true });
    const reopenedEvidence = reopenedPage.locator('[aria-label="생산 준비 검토 근거"]');
    await expect(reopenedEvidence).toContainText(`${assetRef.assetId} · v${assetRef.version}`);
    await expect(reopenedEvidence).toContainText("inspection/INSPECTION-DEMO-1002 · v1");
    await expect(reopenedEvidence).toContainText("shipment/SHIPMENT-DEMO-1002 · v1");
  } finally {
    await reopened.close();
  }

  const diagnostics = await readStubDiagnostics();
  expect(diagnostics).toMatchObject({ runtimeMode: "stub", actualAI: false, providerCalls: 0 });
  await writeNamedEvidence("task-19-native.json", {
    scenario: "SO-DEMO-1002 baseline -> approved sales learning -> production reuse -> restart",
    result: "passed",
    usedAssetRef: assetRef,
    baselineReadSet: baseline?.readSet,
    additionalReadSet: reused?.additionalReadSet,
    finding: reused?.finding,
    businessOutcome: "unobserved",
    mutation: {
      approvalCount: persisted.records.approvals.length,
      executionCount: persisted.records.executions.length,
      productionPlansUnchanged: true,
      inspectionsUnchanged: true,
      shipmentsUnchanged: true,
    },
    runtimeObserved: diagnostics,
  });
});
