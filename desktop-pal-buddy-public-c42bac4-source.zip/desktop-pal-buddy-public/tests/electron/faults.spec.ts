import { expect } from "@playwright/test";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { launchNative, test, writeNamedEvidence } from "./fixtures";

type RuntimeStatus = { epoch: string; actorSessionRevision: number };
type RuntimeSnapshot = {
  revision: number;
  current: { productionPlans: Array<{ id: string; priority: number; version: number }> };
  records: {
    tasks: Array<{ workboardTaskId: string; status: string; currentApprovalId: string | null; executionId: string | null }>;
    approvals: Array<{ id: string }>;
    executions: Array<{ id: string; state: string }>;
    readbackEvidence: Array<{ executionId: string; observedVersion: number }>;
  };
};

async function bootstrap(page: import("@playwright/test").Page) {
  return page.evaluate(async () => window.companyRuntime?.bootstrap({
    schemaVersion: 1,
    requestId: crypto.randomUUID(),
    epoch: null,
    actorSessionRevision: null,
    payload: {},
  })) as Promise<{ ok: boolean; payload?: { status: RuntimeStatus } }>;
}

async function prepareApprovedTask(page: import("@playwright/test").Page) {
  const opened = await bootstrap(page);
  if (!opened.ok || !opened.payload) throw new Error("runtime bootstrap failed");
  return page.evaluate(async ({ status }) => {
    const bridge = window.companyRuntime;
    if (!bridge) throw new Error("runtime bridge missing");
    const envelope = (current: RuntimeStatus, payload: Record<string, unknown>) => ({
      schemaVersion: 1,
      requestId: crypto.randomUUID(),
      epoch: current.epoch,
      actorSessionRevision: current.actorSessionRevision,
      payload,
    });
    const submitted = await bridge.submit(envelope(status, { requestText: "SO-DEMO-1001 priority 1" })) as {
      ok: boolean;
      payload?: { task: { workboardTaskId: string } };
    };
    if (!submitted.ok || !submitted.payload) throw new Error("task submit failed");
    const role = await bridge.role(envelope(status, { actorId: "production-demo" })) as {
      ok: boolean;
      epoch: string;
      actorSessionRevision: number;
      payload?: RuntimeStatus;
    };
    if (!role.ok) throw new Error("role switch failed");
    const production = { epoch: role.epoch, actorSessionRevision: role.actorSessionRevision };
    const approved = await bridge.approve(envelope(production, {
      workboardTaskId: submitted.payload.task.workboardTaskId,
      decision: "approved",
    })) as { ok: boolean; payload?: { approval: { id: string } } };
    if (!approved.ok || !approved.payload) throw new Error("approval failed");
    return {
      status: production,
      workboardTaskId: submitted.payload.task.workboardTaskId,
      approvalId: approved.payload.approval.id,
    };
  }, { status: opened.payload.status });
}

test("@task22 fault persistence write failure preserves the original snapshot", async ({ userDataDir }) => {
  const seeded = await launchNative(userDataDir);
  await seeded.firstWindow();
  await seeded.close();
  const snapshotPath = path.join(userDataDir, "company-runtime/snapshot.json");
  const before = await readFile(snapshotPath, "utf8");

  const faulted = await launchNative(userDataDir, { faults: { temp_write: true } });
  try {
    const page = await faulted.firstWindow();
    const opened = await bootstrap(page);
    if (!opened.ok || !opened.payload) throw new Error("runtime bootstrap failed");
    const result = await page.evaluate(async (status) => window.companyRuntime?.submit({
      schemaVersion: 1,
      requestId: crypto.randomUUID(),
      epoch: status.epoch,
      actorSessionRevision: status.actorSessionRevision,
      payload: { requestText: "SO-DEMO-1001 priority 1" },
    }), opened.payload.status);
    expect(result).toMatchObject({ ok: false, error: { code: "persistence_failed", message: "temp_write" } });
  } finally {
    await faulted.close();
  }

  expect(await readFile(snapshotPath, "utf8")).toBe(before);
});

test("@task22 fault lost reply after apply recovers one execution and one version after restart", async ({ userDataDir, readSnapshot, readStubDiagnostics }) => {
  const preparedApp = await launchNative(userDataDir);
  const preparedPage = await preparedApp.firstWindow();
  const prepared = await prepareApprovedTask(preparedPage);
  await preparedApp.close();

  const interruptedApp = await launchNative(userDataDir, { faults: { after_apply_commit: true } });
  let executionId = "";
  try {
    const interruptedPage = await interruptedApp.firstWindow();
    const opened = await bootstrap(interruptedPage);
    if (!opened.ok || !opened.payload) throw new Error("runtime bootstrap failed");
    const production = await interruptedPage.evaluate(async (status) => window.companyRuntime?.role({
      schemaVersion: 1,
      requestId: crypto.randomUUID(),
      epoch: status.epoch,
      actorSessionRevision: status.actorSessionRevision,
      payload: { actorId: "production-demo" },
    }), opened.payload.status) as { ok: boolean; epoch: string; actorSessionRevision: number };
    expect(production.ok).toBe(true);
    const result = await interruptedPage.evaluate(async ({ status, workboardTaskId, approvalId }) => window.companyRuntime?.execute({
      schemaVersion: 1,
      requestId: crypto.randomUUID(),
      epoch: status.epoch,
      actorSessionRevision: status.actorSessionRevision,
      payload: { workboardTaskId, approvalId },
    }), {
      status: { epoch: production.epoch, actorSessionRevision: production.actorSessionRevision },
      workboardTaskId: prepared.workboardTaskId,
      approvalId: prepared.approvalId,
    });
    expect(result).toMatchObject({ ok: false, error: { code: "verification_required", message: "test_after_apply_commit" } });
    const interrupted = await readSnapshot() as RuntimeSnapshot;
    expect(interrupted.records.executions).toHaveLength(1);
    expect(interrupted.records.readbackEvidence).toHaveLength(0);
    expect(interrupted.records.tasks[0]).toMatchObject({ status: "in_progress" });
    expect(interrupted.current.productionPlans.find((item) => item.id === "PP-DEMO-1001")).toMatchObject({ priority: 1, version: 2 });
    executionId = interrupted.records.executions[0].id;
  } finally {
    await interruptedApp.close();
  }

  const recoveredApp = await launchNative(userDataDir);
  try {
    await recoveredApp.firstWindow();
    const recovered = await readSnapshot() as RuntimeSnapshot;
    expect(recovered.records.executions).toEqual([expect.objectContaining({ id: executionId, state: "verified" })]);
    expect(recovered.records.readbackEvidence).toEqual([expect.objectContaining({ executionId, observedVersion: 2 })]);
    expect(recovered.records.tasks[0]).toMatchObject({ status: "done", executionId });
    expect(recovered.current.productionPlans.find((item) => item.id === "PP-DEMO-1001")).toMatchObject({ priority: 1, version: 2 });
    const diagnostics = await readStubDiagnostics();
    expect(diagnostics).toMatchObject({ runtimeMode: "stub", actualAI: false, providerCalls: 0 });
    await writeNamedEvidence("task-22-happy.json", {
      scenario: "apply commit -> lost reply -> close -> restart reconciliation",
      result: "passed",
      executionId,
      persistedVersion: 2,
      executionCount: recovered.records.executions.length,
      readbackCount: recovered.records.readbackEvidence.length,
      runtimeObserved: diagnostics,
    });
  } finally {
    await recoveredApp.close();
  }
});
