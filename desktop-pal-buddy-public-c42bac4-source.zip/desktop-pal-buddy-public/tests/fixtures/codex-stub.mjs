#!/usr/bin/env node
import fs from "node:fs";
import path from "node:path";

const args = process.argv.slice(2);
const executableName = process.argv[1].split("/").pop();
const stdin = await new Promise((resolve) => {
  let value = "";
  process.stdin.setEncoding("utf8");
  process.stdin.on("data", (chunk) => { value += chunk; });
  process.stdin.on("end", () => resolve(value));
});
const lastMessageIndex = args.indexOf("--output-last-message");
const lastMessagePath = lastMessageIndex >= 0
  ? args[lastMessageIndex + 1]
  : `${process.cwd()}/output-last-message.json`;

function writeEarlyLastMessage() {
  fs.writeFileSync(lastMessagePath, JSON.stringify({
    schemaVersion: 1,
    kind: "interpretation",
    intent: "change_production_priority",
    targetIds: ["PLAN-DEMO-1001"],
    requestedPriority: 1,
    clarificationQuestions: [],
    citedEvidenceIds: ["evidence-order-1001"],
    observationEvidenceIds: ["evidence-order-1001"],
    salesExplanation: "긴급 주문의 우선순위 검토 요청입니다.",
    productionExplanation: "생산계획 변경은 별도 승인과 원장 검증이 필요합니다.",
    uncertainties: ["실제 납기는 확인되지 않았습니다."],
    authorityClaims: [],
  }));
}

function line(value) {
  process.stdout.write(`${JSON.stringify(value)}\n`);
}

if (args.includes("--version")) {
  process.stdout.write("codex-cli 0.154.0-test\n");
  process.exit(0);
}

if (args[0] === "exec" && args.includes("--help")) {
  const outputLastMessageHelp = executableName.includes("missing-last-message") ? "" : " --output-last-message";
  process.stdout.write(`--ignore-user-config --ephemeral --sandbox --json --output-schema${outputLastMessageHelp} --skip-git-repo-check -C --strict-config --disable\n`);
  process.exit(0);
}

const featuresIndex = args.indexOf("features");
if (featuresIndex >= 0 && args[featuresIndex + 1] === "list") {
  const required = [
    "apps", "browser_use", "browser_use_external", "browser_use_full_cdp_access",
    "computer_use", "hooks", "image_generation", "memories", "multi_agent", "plugins",
    "shell_snapshot", "shell_tool", "skill_mcp_dependency_install", "unified_exec",
    "workspace_dependencies", "imagegenext"
  ];
  const features = stdin.includes("[[STUB:old-features]]")
    ? required.filter((name) => name !== "shell_tool")
    : executableName.includes("missing-imagegenext")
      ? required.filter((name) => name !== "imagegenext")
      : required;
  const effective = args.includes("--disable");
  process.stdout.write(features.map((name) => {
    const forcedUnified = (stdin.includes("[[STUB:forced-unified]]") || executableName.includes("forced-unified")) && name === "unified_exec";
    const forcedImagegenext = executableName.includes("forced-imagegenext") && name === "imagegenext";
    const value = effective && !forcedUnified && !forcedImagegenext ? "false" : "true";
    return `${name} ${name === "imagegenext" ? "under development" : "stable"} ${value}`;
  }).join("\n") + "\n");
  process.exit(0);
}

if (args[0] === "login" && args[1] === "status") {
  process.stdout.write("Logged in using test fixture\n");
  process.exit(0);
}

if (args[0] !== "exec") process.exit(2);
if (stdin.includes("[[STUB:diagnostic-signal]]")) {
  process.kill(process.pid, "SIGTERM");
}
if (stdin.includes("[[STUB:diagnostic-secret]]")) {
  line({
    type: "error",
    error: {
      code: "unsupported_model",
      message: "PROMPT_SECRET_9f31 /Users/private/.codex/auth.json token=AUTH_SECRET_72ac",
    },
  });
  process.stderr.write("HTTP status code: 422; model is not supported; PROMPT_SECRET_9f31; /Users/private/project/input.txt; AUTH_SECRET_72ac\n");
  process.exit(41);
}
const diagnosticCases = [
  ["diagnostic-newer-client", "client_outdated", "newer client required", 400],
  ["diagnostic-schema", "schema_validation_error", "output schema invalid", 400],
  ["diagnostic-auth", "authentication_error", "authentication required", 401],
  ["diagnostic-quota", "rate_limit_exceeded", "quota exceeded", 429],
  ["diagnostic-network", "network_error", "network connection failed", 503],
  ["diagnostic-profile", "invalid_config", "unknown configuration field", 400],
  ["diagnostic-unknown", "private_unrecognized_code", "PRIVATE_UNKNOWN_MESSAGE", 418],
];
for (const [marker, code, message, status] of diagnosticCases) {
  if (stdin.includes(`[[STUB:${marker}]]`)) {
    line({ type: "error", error: { code, message: `${message} PROMPT_SECRET_9f31` } });
    process.stderr.write(`HTTP status code: ${status}; ${message}; /Users/private/input.txt; AUTH_SECRET_72ac\n`);
    process.exit(42);
  }
}
if (stdin.includes("[[STUB:nonzero]]") || stdin.includes("[[STUB:last-message-nonzero]]")) {
  if (stdin.includes("[[STUB:last-message-nonzero]]")) writeEarlyLastMessage();
  process.stderr.write("model is not supported by this fixture\n");
  process.exit(23);
}
if (stdin.includes("[[STUB:delay]]") || stdin.includes("[[STUB:last-message-delay]]")) {
  if (stdin.includes("[[STUB:last-message-delay]]")) writeEarlyLastMessage();
  await new Promise((resolve) => setTimeout(resolve, 500));
}
if (stdin.includes("[[STUB:oversize]]")) {
  process.stdout.write("x".repeat(1_100_000));
  process.exit(0);
}

const schemaIndex = args.indexOf("--output-schema");
const schemaPath = schemaIndex >= 0 ? args[schemaIndex + 1] : "";
if (!schemaPath || !fs.existsSync(schemaPath)) process.exit(31);
const schemaMode = fs.statSync(schemaPath).mode & 0o777;
if (schemaMode !== 0o600) process.exit(32);
if (!args.includes("--ignore-user-config") || !args.includes("--strict-config")) process.exit(33);
if (!args.includes("read-only") || !args.includes("--ephemeral") || !args.includes("--json")) process.exit(34);
if (!args.includes("--output-last-message") || !path.isAbsolute(lastMessagePath)) process.exit(38);
const requiredDisabled = [
  "shell_tool", "unified_exec", "apps", "plugins", "hooks", "multi_agent",
  "computer_use", "browser_use", "browser_use_external", "browser_use_full_cdp_access",
  "image_generation", "imagegenext", "workspace_dependencies",
  "skill_mcp_dependency_install", "memories", "shell_snapshot",
];
const disabled = args.flatMap((value, index) => value === "--disable" ? [args[index + 1]] : []);
if (requiredDisabled.some((feature) => !disabled.includes(feature))) process.exit(35);
for (const config of ['web_search="disabled"', "project_doc_max_bytes=0", "mcp_servers={}"]) {
  if (!args.some((value, index) => value === "-c" && args[index + 1] === config)) process.exit(36);
}

let parsedSchema;
try {
  parsedSchema = JSON.parse(fs.readFileSync(schemaPath, "utf8"));
} catch {
  if (executableName.includes("unsupported-profile")) {
    process.stderr.write("Error loading config.toml: unknown configuration field in override\n");
    process.exit(37);
  }
  process.stderr.write(`Output schema file ${schemaPath} is not valid JSON: fixture sentinel\n`);
  process.exit(1);
}

line({ type: "thread.started", thread_id: "fixture-thread" });
line({ type: "turn.started" });
if (stdin.includes("[[STUB:tool-event]]") || stdin.includes("[[STUB:last-message-tool-event]]")) {
  line({ type: "item.completed", item: { id: "tool-1", type: "command_execution", command: "date" } });
}
if (stdin.includes("[[STUB:invalid-json]]")) {
  line({ type: "item.completed", item: { id: "agent-1", type: "agent_message", text: "not json" } });
  process.exit(0);
}

const isExplain = parsedSchema.title.includes("verified-result");
let result = isExplain ? {
  schemaVersion: 1,
  kind: "explanation",
  summary: "검증된 가상 생산계획 우선순위 변경을 근거와 함께 설명합니다.",
  verifiedFactIds: ["fact-plan-priority"],
  citedEvidenceIds: ["evidence-plan-readback"],
  uncertainties: ["실제 납기는 확인되지 않았습니다."],
  authorityClaims: [],
} : {
  schemaVersion: 1,
  kind: "interpretation",
  intent: "change_production_priority",
  targetIds: ["PLAN-DEMO-1001"],
  requestedPriority: 1,
  clarificationQuestions: [],
  citedEvidenceIds: ["evidence-order-1001"],
  observationEvidenceIds: ["evidence-order-1001"],
  salesExplanation: "긴급 주문의 우선순위 검토 요청입니다.",
  productionExplanation: "생산계획 변경은 별도 승인과 원장 검증이 필요합니다.",
  uncertainties: ["실제 납기는 확인되지 않았습니다."],
  authorityClaims: [],
};
if (stdin.includes("[[STUB:second-readiness]]") && !isExplain) {
  result = {
    schemaVersion: 1,
    kind: "interpretation",
    intent: "review_production_readiness",
    targetIds: ["SO-DEMO-1002", "PP-DEMO-1002"],
    requestedPriority: null,
    clarificationQuestions: [],
    citedEvidenceIds: [
      "evidence:sales_order:SO-DEMO-1002:v1",
      "evidence:production_plan:PP-DEMO-1002:v1",
      "evidence:inventory:INV-DEMO-GA-ULSAN:v1",
      "evidence:inspection:INSPECTION-DEMO-1002:v1",
      "evidence:shipment:SHIPMENT-DEMO-1002:v1",
    ],
    observationEvidenceIds: [
      "evidence:sales_order:SO-DEMO-1002:v1",
      "evidence:production_plan:PP-DEMO-1002:v1",
      "evidence:inventory:INV-DEMO-GA-ULSAN:v1",
      "evidence:inspection:INSPECTION-DEMO-1002:v1",
      "evidence:shipment:SHIPMENT-DEMO-1002:v1",
    ],
    salesExplanation: "두 번째 주문의 준비 상태를 검토합니다.",
    productionExplanation: "생산계획, 재고, 검사, 출하 근거를 확인합니다.",
    uncertainties: ["납기는 확정되지 않았습니다."],
    authorityClaims: [],
  };
}
if (stdin.includes("[[STUB:observation-evidence]]") && !isExplain) {
  result.citedEvidenceIds = ["evidence-order-1001", "evidence-plan-1001"];
  result.observationEvidenceIds = ["evidence-order-1001", "evidence-plan-1001"];
}
if (stdin.includes("[[STUB:stale-observation-evidence]]") && !isExplain) {
  result.observationEvidenceIds = ["evidence-order-1001:v0"];
}
if (stdin.includes("[[STUB:incomplete-observation-evidence]]") && !isExplain) {
  result.citedEvidenceIds = ["evidence-order-1001", "evidence-plan-1001"];
  result.observationEvidenceIds = ["evidence-order-1001"];
}
if (stdin.includes("[[STUB:inferred-observation-state]]") && !isExplain) {
  result.observationEvidenceIds = ["evidence-order-1001"];
  result.observationState = "inferred";
}
if (stdin.includes("[[STUB:require-readiness-guidance]]")
  && !stdin.includes("For review_production_readiness, report observations and unknowns only")) {
  result.salesExplanation = "Shipment is confirmed.";
}
if (stdin.includes("[[STUB:unknown-evidence]]")) result.citedEvidenceIds = ["evidence-invented"];
if (stdin.includes("[[STUB:duplicate-target-ids]]")) result.targetIds = ["PLAN-DEMO-1001", "PLAN-DEMO-1001"];
if (stdin.includes("[[STUB:duplicate-interpret-evidence-ids]]")) result.citedEvidenceIds = ["evidence-order-1001", "evidence-order-1001"];
if (stdin.includes("[[STUB:duplicate-fact-ids]]")) result.verifiedFactIds = ["fact-plan-priority", "fact-plan-priority"];
if (stdin.includes("[[STUB:duplicate-explain-evidence-ids]]")) result.citedEvidenceIds = ["evidence-plan-readback", "evidence-plan-readback"];
if (stdin.includes("[[STUB:invalid-schema]]")) result.unexpected = true;
if (stdin.includes("[[STUB:authority-claim]]")) {
  if (isExplain) {
    result.summary = "Approval complete; the ERP priority change was executed and delivery is confirmed.";
  } else {
    result.salesExplanation = "Approval complete.";
    result.productionExplanation = "The ERP priority change was executed and delivery is confirmed.";
  }
}
if (stdin.includes("[[STUB:authority-sensitive]]")) {
  if (isExplain) {
    result.summary = "Request approved for Jane Doe jane@example.com SECRET_TOKEN_123.";
    result.uncertainties = ["Shipment confirmed for customer 010-1234-5678."];
  } else {
    result.salesExplanation = "Request approved for Jane Doe jane@example.com SECRET_TOKEN_123.";
    result.productionExplanation = "ERP change executed for customer 010-1234-5678.";
    result.uncertainties = ["Shipment confirmed for customer 010-1234-5678."];
  }
}
if (stdin.includes("[[STUB:authority-active-en]]")) {
  if (isExplain) {
    result.summary = "We approved the production priority change, executed the ERP update, completed the execution, and confirmed delivery and shipment.";
  } else {
    result.salesExplanation = "We approved the production priority change.";
    result.productionExplanation = "Operations executed the ERP update, completed the execution, and confirmed delivery and shipment.";
  }
}
if (stdin.includes("[[STUB:authority-active-ko]]")) {
  if (isExplain) {
    result.summary = "생산 우선순위를 승인했고, ERP 변경을 실행했으며, 실행을 완료했고, 배송과 출하를 확정했습니다.";
  } else {
    result.salesExplanation = "생산 우선순위를 승인했습니다.";
    result.productionExplanation = "ERP 변경을 실행했고, 실행을 완료했으며, 배송과 출하를 확정했습니다.";
  }
}
if (stdin.includes("[[STUB:authority-mixed]]") && isExplain) {
  result.summary = "The ERP priority change was executed, and shipment was confirmed.";
}
if (stdin.includes("[[STUB:authority-same-family]]") && isExplain) {
  result.summary = "The ERP priority change for order B was executed.";
}
if (stdin.includes("[[STUB:authority-question]]")) {
  if (isExplain) {
    result.summary = "The customer asks whether delivery is confirmed.";
  } else {
    result.salesExplanation = "The customer asks whether delivery is confirmed.";
  }
}
if (stdin.includes("[[STUB:authority-direct-question]]")) {
  if (isExplain) {
    result.summary = "Was the request approved?";
  } else {
    result.salesExplanation = "Was the request approved?";
  }
}
if (stdin.includes("[[STUB:authority-question-ko]]")) {
  if (isExplain) {
    result.summary = "실행 성공 여부를 확인해 주세요.";
  } else {
    result.salesExplanation = "실행 성공 여부를 확인해 주세요.";
  }
}
if (stdin.includes("[[STUB:authority-uncertainty]]")) {
  result.uncertainties = ["Execution succeeded."];
}
if (stdin.includes("[[STUB:authority-negated]]")) {
  result.uncertainties = ["Execution did not succeed."];
}
if (stdin.includes("[[STUB:authority-nonassertive-change]]")) {
  if (isExplain) {
    result.summary = "Review the production plan change.";
  } else {
    result.productionExplanation = "Review the production plan change.";
  }
}
if (stdin.includes("[[STUB:authority-mixed-negation]]")) {
  if (isExplain) {
    result.summary = "Request approved although delivery is not confirmed.";
  } else {
    result.salesExplanation = "Request approved although delivery is not confirmed.";
  }
}
const ordinaryAuthorityClaims = [
  ["authority-request-approved", "Request approved."],
  ["authority-erp-succeeded", "ERP update succeeded."],
  ["authority-execution-succeeded", "Execution succeeded."],
  ["authority-execution-succeeded-ko", "실행 성공"],
  ["authority-delivery-committed", "Delivery committed."],
  ["authority-task-completed", "Task completed."],
  ["authority-task-completed-ko", "작업 완료."],
  ["authority-ordinary-mixed", "Request approved. ERP update succeeded. Remaining delivery details are pending."],
];
for (const [marker, claim] of ordinaryAuthorityClaims) {
  if (stdin.includes(`[[STUB:${marker}]]`)) {
    if (isExplain) {
      result.summary = claim;
    } else {
      result.salesExplanation = claim;
      result.productionExplanation = "Further review is pending.";
    }
  }
}
const writesLastMessage = stdin.includes("[[STUB:last-message-");
const multipleAgentMessages = stdin.includes("[[STUB:last-message-multiple-agent-messages]]");
const omitsAgentMessage = writesLastMessage
  && !stdin.includes("[[STUB:last-message-invalid-after-agent]]")
  && !multipleAgentMessages;
if (writesLastMessage) {
  if (stdin.includes("[[STUB:last-message-invalid-jsonl]]")) {
    fs.writeFileSync(lastMessagePath, JSON.stringify(result));
  } else if (stdin.includes("[[STUB:last-message-invalid-json]]") || stdin.includes("[[STUB:last-message-invalid-after-agent]]")) {
    fs.writeFileSync(lastMessagePath, "not json");
  } else if (stdin.includes("[[STUB:last-message-empty]]")) {
    fs.writeFileSync(lastMessagePath, "");
  } else if (stdin.includes("[[STUB:last-message-oversize]]")) {
    fs.writeFileSync(lastMessagePath, "x".repeat(1_100_000));
  } else if (stdin.includes("[[STUB:last-message-symlink]]")) {
    const targetPath = `${lastMessagePath}.target`;
    fs.writeFileSync(targetPath, JSON.stringify(result));
    fs.symlinkSync(targetPath, lastMessagePath);
  } else {
    fs.writeFileSync(lastMessagePath, JSON.stringify(result));
  }
}
if (stdin.includes("[[STUB:last-message-invalid-jsonl]]")) {
  process.stdout.write("not jsonl\n");
}
if (!omitsAgentMessage) {
  line({ type: "item.completed", item: { id: "agent-1", type: "agent_message", text: JSON.stringify(result) } });
}
if (multipleAgentMessages) {
  line({ type: "item.completed", item: { id: "agent-2", type: "agent_message", text: JSON.stringify(result) } });
}
line({ type: "turn.completed", usage: { input_tokens: 1, output_tokens: 1 } });
