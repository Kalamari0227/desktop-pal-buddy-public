import { expect, test } from "@playwright/test";

const evidenceDir = ".superpowers/sdd/2026-09-18-strategy-loop";

test("demo strategy version stays pinned from Gateway through Workboard evidence", async ({ page }) => {
  const realServiceRequests: string[] = [];
  await page.route("**/*", async (route) => {
    const url = route.request().url();
    if (/supabase\.(co|in)|\/rest\/v1\/|\/functions\/v1\/|\berp\b/i.test(url)) {
      realServiceRequests.push(url);
      await route.abort();
      return;
    }
    await route.continue();
  });

  await page.goto("/?demo&freeze=1");
  await expect(page.getByRole("button", { name: /오늘 브리핑/ })).toBeVisible({ timeout: 15_000 });

  const openWorkspace = page.getByText("워크스페이스 열기", { exact: true });
  if (!(await openWorkspace.isVisible())) {
    await page.locator("button").filter({ has: page.locator("video") }).click();
  }
  await openWorkspace.click();
  await page.getByRole("button", { name: "요청", exact: true }).click();

  await expect(page.getByText("가상 데이터 · 새로고침 시 초기화")).toBeVisible();
  await page.getByLabel("전략 선택").selectOption("delivery-risk-early-warning");
  await expect(page.getByText("전략 버전을 선택해야 작업을 만들 수 있습니다.")).toBeVisible();
  await page.getByLabel("전략 버전 선택").selectOption("delivery-risk-early-warning-v1");

  const newRequest = "가상푸른모터스 주문 VSO-3001의 납기 지연 위험을 확인해줘";
  await page.getByLabel("업무 요청").fill(newRequest);
  await page.getByLabel("참고 값 1").fill("가상푸른모터스");
  await page.getByRole("button", { name: "작업으로 만들기" }).click();
  await page.getByRole("button", { name: "작업에서 계속" }).click();

  await expect(page.getByLabel("연결된 전략")).toContainText("v1");
  await expect(page.getByLabel("보존된 원 요청")).toContainText(newRequest);
  await page.screenshot({ path: `${evidenceDir}/task-3-workboard-new-v1.png`, fullPage: true });

  await page.getByRole("button", { name: "요청", exact: true }).click();
  await page.getByRole("button", { name: "작업", exact: true }).click();
  await expect(page.getByLabel("보존된 원 요청")).toContainText(newRequest);

  const taskList = page.getByLabel("작업 목록");
  await page.getByLabel("전략 버전 필터").selectOption("delivery-risk-early-warning-v2");
  await expect(taskList.getByText("가상새봄부품 주문의 납기 지연 위험을 확인해줘", { exact: true })).toBeVisible();
  await expect(taskList.getByText("가상한빛모빌리티 주문의 납기 지연 위험을 확인해줘", { exact: true })).toHaveCount(0);

  await page.getByLabel("전략 버전 필터").selectOption("delivery-risk-early-warning-v1");
  await taskList.getByText("가상한빛모빌리티 주문의 납기 지연 위험을 확인해줘", { exact: true }).click();
  await expect(page.getByLabel("Codex 결과 Intake").getByText("가상 주문의 필수 납기 증거를 확인했으며 현재 지연 위험은 낮습니다.")).toBeVisible();
  await expect(page.getByText("가상 주문 VSO-1001은 출하 준비 상태입니다.")).toBeVisible();
  await expect(page.getByLabel("전략 작업 상태")).toContainText("접수 시 상태");
  await expect(page.getByLabel("전략 작업 상태")).toContainText(/현재 Workboard 상태\s*완료/);
  await page.screenshot({ path: `${evidenceDir}/task-3-workboard-seeded-v1-evidence.png`, fullPage: true });
  const evidenceList = page.getByLabel("증거 목록");
  await expect(evidenceList).toContainText("가상 출하 계획은 고객 납기 전에 도착하는 일정입니다.");
  await expect(evidenceList).toContainText("가상 주문의 현재 납기 지연 위험은 낮음으로 평가했습니다.");
  await evidenceList.scrollIntoViewIfNeeded();
  await evidenceList.screenshot({ path: `${evidenceDir}/task-3-workboard-v1-evidence-list.png` });

  await page.getByLabel("전략 버전 필터").selectOption("all");
  const newTaskCard = taskList.getByText(newRequest, { exact: true })
    .locator("xpath=ancestor::*[@role='button'][1]");
  await newTaskCard.click();
  await expect(page.getByLabel("결과와 증거")).toContainText("완료 전 증거 필요");
  await expect(page.getByLabel("결과와 증거")).toContainText("증거 0개");
  await newTaskCard.getByRole("button", { name: "완료", exact: true }).click();
  await expect(page.getByLabel("결과와 증거").getByText(/완료하려면/)).toBeVisible();

  await expect(taskList.getByText("전략 미연결").first()).toBeVisible();
  expect(realServiceRequests).toEqual([]);
});
