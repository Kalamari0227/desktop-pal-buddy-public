import { expect, test } from "@playwright/test";
import { inflateSync } from "node:zlib";

function readPngPixels(buffer: Buffer) {
  const signature = buffer.subarray(0, 8).toString("hex");
  if (signature !== "89504e470d0a1a0a") throw new Error("Expected a PNG screenshot");

  let offset = 8;
  let width = 0;
  let height = 0;
  let colorType = 6;
  const idatChunks: Buffer[] = [];

  while (offset < buffer.length) {
    const length = buffer.readUInt32BE(offset);
    const type = buffer.subarray(offset + 4, offset + 8).toString("ascii");
    const data = buffer.subarray(offset + 8, offset + 8 + length);
    if (type === "IHDR") {
      width = data.readUInt32BE(0);
      height = data.readUInt32BE(4);
      colorType = data[9];
    }
    if (type === "IDAT") idatChunks.push(data);
    if (type === "IEND") break;
    offset += 12 + length;
  }

  const channels = colorType === 2 ? 3 : 4;
  const stride = width * channels;
  const inflated = inflateSync(Buffer.concat(idatChunks));
  const pixels = Buffer.alloc(height * stride);
  let input = 0;

  for (let y = 0; y < height; y += 1) {
    const filter = inflated[input++];
    const rowStart = y * stride;
    for (let x = 0; x < stride; x += 1) {
      const raw = inflated[input++];
      const left = x >= channels ? pixels[rowStart + x - channels] : 0;
      const up = y > 0 ? pixels[rowStart + x - stride] : 0;
      const upLeft = y > 0 && x >= channels ? pixels[rowStart + x - stride - channels] : 0;
      const predictor = (() => {
        if (filter === 0) return 0;
        if (filter === 1) return left;
        if (filter === 2) return up;
        if (filter === 3) return Math.floor((left + up) / 2);
        const p = left + up - upLeft;
        const pa = Math.abs(p - left);
        const pb = Math.abs(p - up);
        const pc = Math.abs(p - upLeft);
        return pa <= pb && pa <= pc ? left : pb <= pc ? up : upLeft;
      })();
      pixels[rowStart + x] = (raw + predictor) & 0xff;
    }
  }

  return { width, height, channels, pixels };
}

function summarizeScreenshot(buffer: Buffer) {
  const { channels, pixels } = readPngPixels(buffer);
  const colors = new Set<string>();
  let minLuma = Number.POSITIVE_INFINITY;
  let maxLuma = 0;

  for (let index = 0; index < pixels.length; index += channels * 128) {
    const r = pixels[index];
    const g = pixels[index + 1];
    const b = pixels[index + 2];
    const luma = 0.2126 * r + 0.7152 * g + 0.0722 * b;
    minLuma = Math.min(minLuma, luma);
    maxLuma = Math.max(maxLuma, luma);
    colors.add(`${r},${g},${b}`);
  }

  return { uniqueColors: colors.size, lumaRange: maxLuma - minLuma };
}

test("landing page renders the public product entry", async ({ page }) => {
  await page.goto("/");

  await expect(page.getByRole("navigation", { name: "Main navigation" })).toBeVisible();
  await expect(page.getByRole("heading", { name: "Agentic OS" })).toBeVisible();
  await expect(page.getByRole("link", { name: "Start Building" }).first()).toBeVisible();
});

test("desktop demo completes boot and exposes dock actions", async ({ page }) => {
  await page.goto("/?demo");

  await expect(page.getByRole("img", { name: "Prometheus knowledge network background" })).toBeVisible();
  await expect(page.getByRole("button", { name: /오늘 브리핑/ })).toBeVisible({ timeout: 15_000 });
  await expect(page.getByRole("button", { name: /워크스페이스/ })).toBeVisible();
});

test("desktop canvas renders nonblank pixels and publishes metrics", async ({ page }) => {
  await page.goto("/?demo&freeze=1");

  await expect(page.locator("canvas")).toBeVisible();
  await page.waitForFunction(() => Boolean(window.__prometheusCanvasMetrics?.nodeCount));
  const metrics = await page.evaluate(() => window.__prometheusCanvasMetrics);

  const sample = summarizeScreenshot(await page.screenshot());

  expect(metrics?.loadTimeMs).toBeGreaterThan(0);
  expect(sample.uniqueColors).toBeGreaterThan(5);
  expect(sample.lumaRange).toBeGreaterThan(8);
});

test("desktop canvas honors reduced motion quality settings", async ({ page }) => {
  await page.emulateMedia({ reducedMotion: "reduce" });
  await page.goto("/?demo");

  await page.waitForFunction(() => Boolean(window.__prometheusCanvasMetrics?.nodeCount));
  const metrics = await page.evaluate(() => window.__prometheusCanvasMetrics);

  expect(metrics?.reduceMotion).toBe(true);
  expect(metrics?.nodeCount).toBeLessThanOrEqual(48);
});
