import { defineConfig } from "@playwright/test";
import path from "node:path";
import { resolveEvidenceRoot } from "./tests/electron/fixtures";

const repoRoot = path.resolve(import.meta.dirname);
const legacyEvidenceRoot = path.resolve(repoRoot, ".omo/evidence/brave-new-company-future-erp");
const configuredEvidenceRoot = process.env.BNC_QA_EVIDENCE_DIR ? resolveEvidenceRoot() : null;

export default defineConfig({
  testDir: "./tests/electron",
  testMatch: /live-codex\.spec\.ts/,
  timeout: 240_000,
  expect: { timeout: 20_000 },
  fullyParallel: false,
  workers: 1,
  retries: 0,
  forbidOnly: true,
  reporter: [["list"]],
  outputDir: configuredEvidenceRoot ? path.join(configuredEvidenceRoot, "playwright-live") : path.join(legacyEvidenceRoot, "task-23-timeout-budget/playwright"),
  projects: [{ name: "electron-live" }],
  use: {
    trace: "on",
    screenshot: "on",
    video: "off",
  },
});
