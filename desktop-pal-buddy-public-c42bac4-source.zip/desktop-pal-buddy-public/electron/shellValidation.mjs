import path from "node:path";
import { fileURLToPath } from "node:url";

const DOCK_STATES = new Set([
  "idle",
  "hovered",
  "expanded",
  "listening",
  "thinking",
  "dispatching",
  "working",
  "needs_review",
  "alert",
  "completed",
  "error",
]);

const DOCK_SURFACES = new Set(["ambient", "chat"]);

const WORKSPACE_MODES = new Set([
  "home",
  "gateway",
  "meeting",
  "response",
  "search",
  "risk",
  "performance",
  "report",
  "tasks",
  "customers",
  "agents",
  "marketplace",
  "my-installations",
  "workflows",
  "agent-meeting",
  "alerts",
  "reports",
  "settings",
]);

const DEFAULT_EXTERNAL_HOSTS = [
  "github.com",
  "supabase.com",
  "electronjs.org",
  "vite.dev",
];

export function parseAllowedExternalHosts(raw) {
  return (raw || DEFAULT_EXTERNAL_HOSTS.join(","))
    .split(",")
    .map((host) => host.trim().toLowerCase())
    .filter(Boolean);
}

export function isAllowedDockState(value) {
  return typeof value === "string" && DOCK_STATES.has(value);
}

export function isAllowedDockSurface(value) {
  return typeof value === "string" && DOCK_SURFACES.has(value);
}

export function isAllowedWorkspaceMode(value) {
  return typeof value === "string" && WORKSPACE_MODES.has(value);
}

export function isAllowedExternalUrl(url, allowedHosts = DEFAULT_EXTERNAL_HOSTS) {
  try {
    const parsed = new URL(url);
    if (parsed.protocol !== "https:") return false;
    const hostname = parsed.hostname.toLowerCase();
    return allowedHosts.some((host) => hostname === host || hostname.endsWith(`.${host}`));
  } catch {
    return false;
  }
}

export function isAllowedNavigationUrl(url, { isDev, devOrigin, appEntryPath }) {
  try {
    const parsed = new URL(url);
    if (isDev) {
      return parsed.origin === devOrigin;
    }
    if (parsed.protocol !== "file:") return false;
    return path.normalize(fileURLToPath(parsed)) === path.normalize(appEntryPath);
  } catch {
    return false;
  }
}

export function normalizeUpdateFeedUrl(rawUrl) {
  if (!rawUrl) return null;

  try {
    const parsed = new URL(rawUrl);
    if (parsed.protocol !== "https:") return null;
    if (parsed.username || parsed.password) return null;
    parsed.hash = "";
    parsed.search = "";
    return parsed.toString().replace(/\/$/, "");
  } catch {
    return null;
  }
}

export function getContentSecurityPolicy({ isDev, devOrigin }) {
  const connectSrc = ["'self'", "https:"];
  const scriptSrc = ["'self'"];
  if (isDev && devOrigin) {
    connectSrc.push(devOrigin, devOrigin.replace("http://", "ws://").replace("https://", "wss://"));
    scriptSrc.push("'unsafe-inline'");
  }

  return [
    "default-src 'self'",
    `script-src ${scriptSrc.join(" ")}`,
    "style-src 'self' 'unsafe-inline'",
    "img-src 'self' data: blob:",
    "font-src 'self' data:",
    `connect-src ${connectSrc.join(" ")}`,
    "media-src 'self' data: blob:",
    "worker-src 'self' blob:",
    "frame-src 'none'",
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'self'",
  ].join("; ");
}
