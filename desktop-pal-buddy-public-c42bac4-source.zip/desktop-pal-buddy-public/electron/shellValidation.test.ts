import { describe, expect, it } from "vitest";
import {
  getContentSecurityPolicy,
  isAllowedDockState,
  isAllowedDockSurface,
  isAllowedExternalUrl,
  isAllowedNavigationUrl,
  isAllowedWorkspaceMode,
  normalizeUpdateFeedUrl,
} from "./shellValidation.mjs";

describe("Electron shell validation", () => {
  it("accepts only known dock states and surfaces", () => {
    expect(isAllowedDockState("working")).toBe(true);
    expect(isAllowedDockState("../../../bad")).toBe(false);
    expect(isAllowedDockSurface("chat")).toBe(true);
    expect(isAllowedDockSurface("file")).toBe(false);
  });

  it("accepts only known workspace modes", () => {
    expect(isAllowedWorkspaceMode("tasks")).toBe(true);
    expect(isAllowedWorkspaceMode("gateway")).toBe(true);
    expect(isAllowedWorkspaceMode("marketplace")).toBe(true);
    expect(isAllowedWorkspaceMode("search")).toBe(true);
    expect(isAllowedWorkspaceMode("my-installations")).toBe(true);
    expect(isAllowedWorkspaceMode("javascript:alert(1)")).toBe(false);
  });

  it("allows only https URLs on allowlisted hosts", () => {
    expect(isAllowedExternalUrl("https://github.com/Kalamari0227/desktop-pal-buddy", ["github.com"])).toBe(true);
    expect(isAllowedExternalUrl("http://github.com/Kalamari0227/desktop-pal-buddy", ["github.com"])).toBe(false);
    expect(isAllowedExternalUrl("https://evil.example.com", ["github.com"])).toBe(false);
  });

  it("allows navigation only to the exact dev origin or packaged entry file", () => {
    expect(
      isAllowedNavigationUrl("http://127.0.0.1:8080/workspace", {
        isDev: true,
        devOrigin: "http://127.0.0.1:8080",
        appEntryPath: "/app/dist/index.html",
      })
    ).toBe(true);
    expect(
      isAllowedNavigationUrl("http://127.0.0.1:80800/workspace", {
        isDev: true,
        devOrigin: "http://127.0.0.1:8080",
        appEntryPath: "/app/dist/index.html",
      })
    ).toBe(false);
    expect(
      isAllowedNavigationUrl("file:///app/dist/index.html", {
        isDev: false,
        devOrigin: "http://127.0.0.1:8080",
        appEntryPath: "/app/dist/index.html",
      })
    ).toBe(true);
    expect(
      isAllowedNavigationUrl("file:///etc/passwd", {
        isDev: false,
        devOrigin: "http://127.0.0.1:8080",
        appEntryPath: "/app/dist/index.html",
      })
    ).toBe(false);
  });

  it("builds a restrictive CSP with dev websocket access only in dev mode", () => {
    const devCsp = getContentSecurityPolicy({
      isDev: true,
      devOrigin: "http://127.0.0.1:8080",
    });
    const prodCsp = getContentSecurityPolicy({
      isDev: false,
      devOrigin: "http://127.0.0.1:8080",
    });

    expect(devCsp).toContain("default-src 'self'");
    expect(devCsp).toContain("frame-src 'none'");
    expect(devCsp).toContain("script-src 'self' 'unsafe-inline'");
    expect(devCsp).toContain("ws://127.0.0.1:8080");
    expect(devCsp).not.toContain("'unsafe-eval'");
    expect(prodCsp).toContain("script-src 'self'");
    expect(prodCsp).not.toContain("script-src 'self' 'unsafe-inline'");
    expect(prodCsp).not.toContain("ws://127.0.0.1:8080");
  });

  it("accepts only https update feed URLs without embedded credentials", () => {
    expect(normalizeUpdateFeedUrl("https://updates.example.com/app/")).toBe("https://updates.example.com/app");
    expect(normalizeUpdateFeedUrl("http://updates.example.com/app")).toBeNull();
    expect(normalizeUpdateFeedUrl("https://user:pass@updates.example.com/app")).toBeNull();
    expect(normalizeUpdateFeedUrl("not a url")).toBeNull();
  });
});
