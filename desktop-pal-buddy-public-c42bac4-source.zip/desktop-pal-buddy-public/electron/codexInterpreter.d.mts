export type CodexContext = {
  readonly epoch: string;
  readonly actorSessionRevision: number;
};

export const PROVIDER_TERMINAL_TIMEOUT_MS: 180000;

export type CodexProfileProof = {
  readonly ok: true;
  readonly executablePath: string;
  readonly version: string;
  readonly executionProfileProven: true;
  readonly profileDigest: string;
  readonly effectiveDisabledFeatures: readonly string[];
  readonly [key: string]: unknown;
};

export type CodexFailure = {
  readonly ok: false;
  readonly error: { readonly code: string; readonly reason: string; readonly [key: string]: unknown };
  readonly actions: readonly unknown[];
  readonly preservedVerifiedFacts?: readonly Record<string, unknown>[];
};

export type CodexSuccess = {
  readonly ok: true;
  readonly data: {
    readonly intent: string;
    readonly targetIds: readonly string[];
    readonly citedEvidenceIds: readonly string[];
    readonly observationEvidenceIds?: readonly string[];
    readonly verifiedFactIds: readonly string[];
    readonly authorityClaims: readonly string[];
  };
  readonly actions: readonly unknown[];
  readonly toolEventCount: number;
  readonly outputBytes: number;
  readonly schemaSha256: string;
  readonly observedModel: string | null;
  readonly quarantinedInterpretation?: boolean;
  readonly authorityDiagnostic?: {
    readonly phase: "interpret";
    readonly offendingFields: readonly string[];
    readonly authorityCategories: readonly string[];
    readonly claimCount: number;
  } | null;
};

export type CodexResult = CodexSuccess | CodexFailure;

export function discoverCodexCli(options?: {
  readonly candidatePaths?: readonly string[];
  readonly pathValue?: string;
  readonly allowedRoots?: readonly string[];
  readonly featureListInput?: string;
  readonly tmpRoot?: string;
  readonly environment?: Readonly<Record<string, string | undefined>>;
}): Promise<CodexProfileProof | {
  readonly ok: false;
  readonly error: { readonly code: string; readonly reason: string };
  readonly actions: readonly unknown[];
  readonly [key: string]: unknown;
}>;

export function getCodexProfile(): {
  readonly profileDigest: string;
  readonly disabledFeatures: readonly string[];
  readonly [key: string]: unknown;
};

export function createCodexInterpreter(options: {
  readonly executablePath: string;
  readonly profileProof: CodexProfileProof;
  readonly schemaDir: string;
  readonly getCurrentContext: () => CodexContext;
  readonly timeoutMs?: number;
  readonly tmpRoot?: string;
  readonly environment?: Readonly<Record<string, string | undefined>>;
}): {
  readonly interpret: (input: Record<string, unknown>, options?: { readonly signal?: AbortSignal }) => Promise<CodexResult>;
  readonly explain: (input: Record<string, unknown>, options?: { readonly signal?: AbortSignal }) => Promise<CodexResult>;
  readonly cancel: () => void;
};
