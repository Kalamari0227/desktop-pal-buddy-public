import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { afterEach, describe, expect, it } from "vitest";
import { configureCompanyStartup, removeCompanySmokeData } from "./companyStartup.mjs";

const created = [];

afterEach(() => {
  for (const directory of created.splice(0)) fs.rmSync(directory, { recursive: true, force: true });
});

describe("packaged company startup", () => {
  it("sets isolated userData before the caller can request the singleton lock and disables updates", () => {
    const events = [];
    const tempRoot = fs.mkdtempSync(path.join(os.tmpdir(), "bnc-startup-test-"));
    created.push(tempRoot);
    const startup = configureCompanyStartup({
      app: { setPath: (name, value) => events.push({ name, value }) },
      isPackaged: true,
      argv: ["app", "--company-smoke"],
      environment: {},
      tempRoot,
    });
    events.push({ name: "requestSingleInstanceLock", value: "called" });
    expect(events[0]).toEqual({ name: "userData", value: startup.userDataPath });
    expect(events[1].name).toBe("requestSingleInstanceLock");
    expect(startup).toMatchObject({ smoke: true, updatesEnabled: false });
    expect(fs.statSync(startup.userDataPath).isDirectory()).toBe(true);
    removeCompanySmokeData(startup);
    expect(fs.existsSync(startup.userDataPath)).toBe(false);
  });

  it.each([
    { environment: { BNC_TEST_MODE: "1" }, argv: ["app", "--company-smoke"], code: "packaged_injection_rejected" },
    { environment: { BNC_TEST_OPTIONS: "{}" }, argv: ["app", "--company-smoke"], code: "packaged_injection_rejected" },
    { environment: {}, argv: ["app", "--company-smoke", "--user-data-dir=/tmp/untrusted"], code: "packaged_data_dir_rejected" },
  ])("rejects packaged injection before creating userData: $code", ({ environment, argv, code }) => {
    expect(() => configureCompanyStartup({ app: { setPath() {} }, isPackaged: true, argv, environment })).toThrowError(
      expect.objectContaining({ code }),
    );
  });
});
