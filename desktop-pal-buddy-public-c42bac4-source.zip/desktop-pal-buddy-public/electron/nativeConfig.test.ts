import { describe, expect, it } from "vitest";
import viteConfig from "../vite.config";
import { readCompanyTestOptions } from "./companyTestOptions.mjs";

describe("native Electron test configuration", () => {
  it("uses relative asset URLs for packaged file entry and root URLs for dev", () => {
    const buildConfig = typeof viteConfig === "function"
      ? viteConfig({ command: "build", mode: "production" })
      : viteConfig;
    const devConfig = typeof viteConfig === "function"
      ? viteConfig({ command: "serve", mode: "development" })
      : viteConfig;
    expect(buildConfig.base).toBe("./");
    expect(devConfig.base).toBe("/");
  });

  it("accepts test-only host options and never accepts them for packaged mode", () => {
    expect(readCompanyTestOptions({
      isPackaged: false,
      testMode: "1",
      raw: JSON.stringify({ dataDir: "/tmp/company-test", modelStub: { delayMs: 10 }, faults: {} }),
    })).toEqual({ dataDir: "/tmp/company-test", modelStub: { delayMs: 10 }, faults: {} });
    expect(readCompanyTestOptions({ isPackaged: true, testMode: "1", raw: JSON.stringify({ modelStub: {} }) }))
      .toBeUndefined();
    expect(() => readCompanyTestOptions({ isPackaged: false, testMode: "1", raw: "[]" }))
      .toThrow(/invalid company test options/i);
  });

  it("maps runtime fault controls only inside the nonpackaged test host", () => {
    const options = readCompanyTestOptions({
      isPackaged: false,
      testMode: "1",
      raw: JSON.stringify({ faults: { after_apply_commit: true } }),
    });
    expect(options?.faults).toEqual({});
    expect(options?.runtimeTestHooks).toEqual({ afterApplyCommit: expect.any(Function) });
    expect(() => options?.runtimeTestHooks.afterApplyCommit()).toThrow(expect.objectContaining({
      code: "verification_required",
      reason: "test_after_apply_commit",
      committed: true,
    }));
    expect(readCompanyTestOptions({
      isPackaged: true,
      testMode: "1",
      raw: JSON.stringify({ faults: { after_apply_commit: true } }),
    })).toBeUndefined();
    expect(() => readCompanyTestOptions({
      isPackaged: false,
      testMode: "1",
      raw: JSON.stringify({ faults: { arbitrary_hook: true } }),
    })).toThrow(/invalid test fault/i);
  });
});
