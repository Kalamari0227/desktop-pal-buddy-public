import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { createHash, randomUUID } from "node:crypto";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { canonicalSerialize, createInitialCompanyState } from "../dist-runtime/domain.mjs";
import { createCompanyPersistence } from "./companyPersistence.mjs";
import { createCompanyRuntime } from "./companyRuntime.mjs";

const tempDirs: string[] = [];
const previousTestMode = process.env.BNC_TEST_MODE;

function tempRoot(): string {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), "company-runtime-"));
  tempDirs.push(root);
  return root;
}

function uuidFactory(): () => string {
  return () => randomUUID();
}

function clockFactory(start = Date.parse("2026-09-19T00:00:00.000Z")) {
  let now = start;
  return {
    now: () => new Date(now).toISOString(),
    advance: (milliseconds: number) => { now += milliseconds; },
  };
}

function bootstrap(epoch = randomUUID()) {
  return createInitialCompanyState({
    epoch,
    strategyVersionId: randomUUID(),
    createdAt: "2026-09-19T00:00:00.000Z",
    strategyContentHash: "a".repeat(64),
  });
}

async function makeRuntime(options: { root?: string; hooks?: Record<string, () => void> } = {}) {
  const root = options.root ?? tempRoot();
  const clock = clockFactory();
  const repository = createCompanyPersistence({ rootDir: root, bootstrap, isPackaged: false });
  const runtime = createCompanyRuntime({
    repository,
    clock: clock.now,
    uuid: uuidFactory(),
    isPackaged: false,
    testHooks: options.hooks,
  });
  const opened = await runtime.open();
  return { root, clock, repository, runtime, opened };
}

function context(status: { epoch: string; actorSessionRevision: number }) {
  return { epoch: status.epoch, actorSessionRevision: status.actorSessionRevision };
}

async function approvedPriorityChange(runtime: Awaited<ReturnType<typeof makeRuntime>>["runtime"], opened: Awaited<ReturnType<typeof makeRuntime>>["opened"]) {
  const strategyRef = (await runtime.readSnapshot()).current.activeStrategyRef;
  const task = await runtime.createPriorityTask({
    context: context(opened),
    orderId: "SO-DEMO-1001",
    targetPlanId: "PP-DEMO-1001",
    toPriority: 1,
    strategyRef,
  });
  const proposed = await runtime.storeProposal({
    context: context(opened),
    workboardTaskId: task.workboardTaskId,
    orderId: "SO-DEMO-1001",
    targetPlanId: "PP-DEMO-1001",
    toPriority: 1,
  });
  const production = await runtime.switchActor({ context: context(opened), actorId: "production-demo" });
  const approval = await runtime.decideApproval({
    context: context(production),
    workboardTaskId: task.workboardTaskId,
    decision: "approved",
  });
  return { task, proposed, production, approval };
}

function experienceDraftInput(flow: Awaited<ReturnType<typeof approvedPriorityChange>>, executionId: string) {
  return {
    authorActorId: "sales-demo",
    workItem: { workboardTaskId: flow.task.workboardTaskId, packetTaskId: flow.task.packetTaskId },
    sourceEvidenceIds: [...flow.proposed.intent.evidenceRefs, `readback:${executionId}`],
    asset: { id: "PP-DEMO-1001", version: 2 },
    correction: "검사와 출하 준비를 재확인한 뒤 납기 약속을 검토해야 합니다.",
    applicability: ["queued production plan"],
    counterexample: "검사 불합격이면 적용하지 않습니다.",
    outcome: { state: "observed", observedAt: "2026-09-19T00:00:00.000Z" },
    saveDecision: "private",
  };
}

async function publishReusableLearning(
  runtime: Awaited<ReturnType<typeof makeRuntime>>["runtime"],
  salesStatus: { epoch: string; actorSessionRevision: number },
  requiredChecks: Array<"inspection" | "packaging"> = ["inspection", "packaging"],
  includeManagementStrategyReview = false,
) {
  const snapshot = await runtime.readSnapshot();
  const task = await runtime.createPriorityTask({
    context: context(salesStatus),
    orderId: "SO-DEMO-1001",
    targetPlanId: "PP-DEMO-1001",
    toPriority: 1,
    strategyRef: snapshot.current.activeStrategyRef,
  });
  const proposal = await runtime.storeProposal({
    context: context(salesStatus),
    workboardTaskId: task.workboardTaskId,
    orderId: "SO-DEMO-1001",
    targetPlanId: "PP-DEMO-1001",
    toPriority: 1,
  });
  const saved = await runtime.storeExperienceDraft({
    context: context(salesStatus),
    workboardTaskId: task.workboardTaskId,
    draft: {
      authorActorId: "sales-demo",
      workItem: { workboardTaskId: task.workboardTaskId, packetTaskId: task.packetTaskId },
      sourceEvidenceIds: proposal.intent.evidenceRefs,
      asset: { id: "PP-DEMO-1001", version: 1 },
      correction: "검사와 출하 준비를 확인한 뒤 납기를 검토합니다.",
      applicability: ["queued production plan"],
      counterexample: "검사 불합격이면 적용하지 않습니다.",
      outcome: { state: "unobserved" },
      saveDecision: "private",
    },
  });
  const preview = await runtime.previewLearning({
    context: context(salesStatus),
    request: {
      draftId: saved.id,
      exactPublishableSentence: "검사와 출하 준비를 확인한 뒤 납기를 검토합니다.",
      applicability: ["queued production plan"],
      targetDepartments: ["production"],
      includeManagementStrategyReview,
      reuseEpoch: salesStatus.epoch,
      reuseApplicability: {
        workType: "production_readiness",
        department: "production",
        materialGroup: "MAT-GA-DEMO",
        requiredChecks,
      },
    },
  });
  return runtime.publishLearning({ context: context(salesStatus), preview, consentGranted: true });
}

beforeAll(() => { process.env.BNC_TEST_MODE = "1"; });
afterAll(() => {
  if (previousTestMode === undefined) delete process.env.BNC_TEST_MODE;
  else process.env.BNC_TEST_MODE = previousTestMode;
  for (const directory of tempDirs) fs.rmSync(directory, { recursive: true, force: true });
});

describe("durable company runtime", () => {

  it("persists a private experience draft through a runtime restart", async () => {
    const setup = await makeRuntime();
    const flow = await approvedPriorityChange(setup.runtime, setup.opened);
    const execution = await setup.runtime.execute({ context: context(flow.production), workboardTaskId: flow.task.workboardTaskId });
    const sales = await setup.runtime.switchActor({ context: context(flow.production), actorId: "sales-demo" });

    const saved = await setup.runtime.storeExperienceDraft({
      context: context(sales),
      workboardTaskId: flow.task.workboardTaskId,
      draft: experienceDraftInput(flow, execution.execution.id),
    });

    expect(saved).toMatchObject({ authorActorId: "sales-demo", visibility: "private" });
    const preview = await setup.runtime.previewLearning({
      context: context(sales),
      request: {
        draftId: saved.id,
        exactPublishableSentence: "검사와 출하 준비를 확인한 뒤 납기를 검토합니다.",
        applicability: ["queued production plan"],
        targetDepartments: ["production"],
        includeManagementStrategyReview: false,
      },
    });
    const production = await setup.runtime.switchActor({ context: context(sales), actorId: "production-demo" });
    const authorAgain = await setup.runtime.switchActor({ context: context(production), actorId: "sales-demo" });
    await expect(setup.runtime.publishLearning({ context: context(authorAgain), preview, consentGranted: true }))
      .rejects.toMatchObject({ code: "invalid_input", reason: "preview_required" });
    await setup.runtime.close();

    const restarted = await makeRuntime({ root: setup.root });
    const snapshot = await restarted.runtime.readSnapshot();
    expect(snapshot.records.experienceDrafts).toEqual([expect.objectContaining({ id: saved.id, authorActorId: "sales-demo" })]);
  });

	it("pins a task to the explicitly supplied active strategy version", async () => {
		const setup = await makeRuntime();
		const snapshot = await setup.runtime.readSnapshot();
		const strategyRef = snapshot.current.activeStrategyRef;
		const task = await setup.runtime.createPriorityTask({
			context: context(setup.opened),
			orderId: "SO-DEMO-1001",
			targetPlanId: "PP-DEMO-1001",
			toPriority: 1,
			strategyRef,
		});

		expect(task.packet.strategy_ref).toEqual(strategyRef);
		await expect(setup.runtime.createPriorityTask({
			context: context(setup.opened),
			orderId: "SO-DEMO-1001",
			targetPlanId: "PP-DEMO-1001",
			toPriority: 1,
			strategyRef: { ...strategyRef, strategy_version_id: randomUUID() },
		})).rejects.toMatchObject({ code: "stale_context", reason: "strategy_context_is_stale" });
	});

  it("commits once, rereads the file, records trusted evidence, and returns one execution for ten retries", async () => {
    const { root, runtime, opened } = await makeRuntime();
    const flow = await approvedPriorityChange(runtime, opened);

    const results = await Promise.all(Array.from({ length: 10 }, () => runtime.execute({
      context: context(flow.production),
      workboardTaskId: flow.task.workboardTaskId,
    })));

    expect(new Set(results.map((result) => result.execution.id)).size).toBe(1);
    expect(new Set(results.map((result) => result.task.packet.evidence[0].evidence_id)).size).toBe(1);
    expect(results.every((result) => result.status === "verified" && result.task.status === "done")).toBe(true);
    const file = JSON.parse(fs.readFileSync(path.join(root, "company-runtime", "snapshot.json"), "utf8"));
    expect(file.current.productionPlans.find((plan: { id: string }) => plan.id === "PP-DEMO-1001")).toMatchObject({ priority: 1, version: 2 });
    expect(file.records.executions).toHaveLength(1);
    expect(file.records.readbackEvidence).toHaveLength(1);
    expect(file.records.tasks[0].packet.evidence).toHaveLength(1);
    expect(file.records.tasks[0]).toMatchObject({ status: "done", executionId: results[0].execution.id });

    await runtime.close();
    const reopened = await makeRuntime({ root });
    const replay = await reopened.runtime.execute({
      context: context(reopened.opened),
      workboardTaskId: flow.task.workboardTaskId,
    });
    expect(replay.execution.id).toBe(results[0].execution.id);
    expect(replay.task.packet.evidence[0].evidence_id).toBe(results[0].task.packet.evidence[0].evidence_id);
    expect((await reopened.runtime.readSnapshot()).current.productionPlans[0]).toMatchObject({ priority: 1, version: 2 });
  });

  it("rejects a different approval selector on verified replay without changing persisted facts", async () => {
    const setup = await makeRuntime();
    const flow = await approvedPriorityChange(setup.runtime, setup.opened);
    const first = await setup.runtime.execute({
      context: context(flow.production),
      workboardTaskId: flow.task.workboardTaskId,
      approvalId: flow.approval.approval.id,
    });
    const beforeBytes = fs.readFileSync(setup.repository.snapshotPath);
    const beforeHash = createHash("sha256").update(beforeBytes).digest("hex");

    await expect(setup.runtime.execute({
      context: context(flow.production),
      workboardTaskId: flow.task.workboardTaskId,
      approvalId: randomUUID(),
    })).rejects.toMatchObject({ code: "conflict", reason: "approval_selector_mismatch" });

    const afterBytes = fs.readFileSync(setup.repository.snapshotPath);
    expect(createHash("sha256").update(afterBytes).digest("hex")).toBe(beforeHash);
    const unchanged = JSON.parse(afterBytes.toString("utf8"));
    expect(unchanged.current.productionPlans[0]).toMatchObject({ priority: 1, version: 2 });
    expect(unchanged.records.executions).toHaveLength(1);
    expect(unchanged.records.readbackEvidence).toHaveLength(1);
    expect(unchanged.records.tasks[0].packet.evidence).toHaveLength(1);

    const absentSelector = await setup.runtime.execute({
      context: context(flow.production), workboardTaskId: flow.task.workboardTaskId,
    });
    const matchingSelector = await setup.runtime.execute({
      context: context(flow.production), workboardTaskId: flow.task.workboardTaskId,
      approvalId: flow.approval.approval.id,
    });
    expect(absentSelector.execution.id).toBe(first.execution.id);
    expect(matchingSelector.execution.id).toBe(first.execution.id);
    expect(matchingSelector.task.packet.evidence[0].evidence_id).toBe(first.task.packet.evidence[0].evidence_id);
  });

  it("preserves proposal revisions but only the authoritative latest proposal and decision can execute", async () => {
    const { runtime, opened } = await makeRuntime();
    const flow = await approvedPriorityChange(runtime, opened);
    const sales = await runtime.switchActor({ context: context(flow.production), actorId: "sales-demo" });
    const revised = await runtime.storeProposal({
      context: context(sales),
      workboardTaskId: flow.task.workboardTaskId,
      orderId: "SO-DEMO-1001",
      targetPlanId: "PP-DEMO-1001",
      toPriority: 2,
    });
    expect(revised.intent.revision).toBe(2);
    const production = await runtime.switchActor({ context: context(sales), actorId: "production-demo" });

    await expect(runtime.execute({
      context: context(production),
      workboardTaskId: flow.task.workboardTaskId,
      approvalId: flow.approval.approval.id,
    })).rejects.toMatchObject({ code: "approval_required", reason: "current_approval_unavailable" });
    const snapshot = await runtime.readSnapshot();
    expect(snapshot.records.actionIntents.map((intent: { revision: number }) => intent.revision)).toEqual([1, 2]);
    expect(snapshot.current.productionPlans[0]).toMatchObject({ priority: 5, version: 1 });
    await runtime.decideApproval({ context: context(production), workboardTaskId: flow.task.workboardTaskId, decision: "approved" });
    const applied = await runtime.execute({ context: context(production), workboardTaskId: flow.task.workboardTaskId });
    expect(applied.execution.before).toEqual({ priority: 5, version: 1 });
    expect(applied.execution.expectedAfter).toEqual({ priority: 2, version: 2 });
  });

  it("accepts only an interpretation candidate grounded in the authoritative read set", async () => {
    const setup = await makeRuntime();
    const strategyRef = (await setup.runtime.readSnapshot()).current.activeStrategyRef;
    const task = await setup.runtime.createPriorityTask({
      context: context(setup.opened), orderId: "SO-DEMO-1001", targetPlanId: "PP-DEMO-1001", toPriority: 1,
      strategyRef,
    });
    const proposed = await setup.runtime.storeProposal({
      context: context(setup.opened), workboardTaskId: task.workboardTaskId,
      orderId: "SO-DEMO-1001", targetPlanId: "PP-DEMO-1001", toPriority: 1,
      interpretationCandidate: {
        orderId: "SO-DEMO-1001", planId: "PP-DEMO-1001", proposedPriority: 1,
        citations: [
          { kind: "inspection", id: "INSPECTION-DEMO-1001", version: 1, evidenceId: "evidence:inspection:INSPECTION-DEMO-1001:v1" },
          { kind: "inventory", id: "INV-DEMO-GA-ULSAN", version: 1, evidenceId: "evidence:inventory:INV-DEMO-GA-ULSAN:v1" },
          { kind: "production_plan", id: "PP-DEMO-1001", version: 1, evidenceId: "evidence:production_plan:PP-DEMO-1001:v1" },
          { kind: "production_plan", id: "PP-DEMO-1002", version: 1, evidenceId: "evidence:production_plan:PP-DEMO-1002:v1" },
          { kind: "production_plan", id: "PP-DEMO-1003", version: 1, evidenceId: "evidence:production_plan:PP-DEMO-1003:v1" },
          { kind: "sales_order", id: "SO-DEMO-1001", version: 1, evidenceId: "evidence:sales_order:SO-DEMO-1001:v1" },
          { kind: "shipment", id: "SHIPMENT-DEMO-1001", version: 1, evidenceId: "evidence:shipment:SHIPMENT-DEMO-1001:v1" },
        ],
      },
    });
    expect(proposed.intent.targetPlanId).toBe("PP-DEMO-1001");
  });

  it("a rejected or revoked current decision cannot be bypassed with an older approved row", async () => {
    const rejected = await makeRuntime();
    const strategyRef = (await rejected.runtime.readSnapshot()).current.activeStrategyRef;
    const task = await rejected.runtime.createPriorityTask({
      context: context(rejected.opened), orderId: "SO-DEMO-1001", targetPlanId: "PP-DEMO-1001", toPriority: 1,
      strategyRef,
    });
    await rejected.runtime.storeProposal({
      context: context(rejected.opened), workboardTaskId: task.workboardTaskId, orderId: "SO-DEMO-1001", targetPlanId: "PP-DEMO-1001", toPriority: 1,
    });
    const production = await rejected.runtime.switchActor({ context: context(rejected.opened), actorId: "production-demo" });
    await rejected.runtime.decideApproval({ context: context(production), workboardTaskId: task.workboardTaskId, decision: "rejected" });
    await expect(rejected.runtime.execute({ context: context(production), workboardTaskId: task.workboardTaskId }))
      .rejects.toMatchObject({ code: "approval_required", reason: "approval_rejected" });

    const revoked = await makeRuntime();
    const flow = await approvedPriorityChange(revoked.runtime, revoked.opened);
    await revoked.runtime.revokeApproval({ context: context(flow.production), workboardTaskId: flow.task.workboardTaskId });
    await expect(revoked.runtime.execute({ context: context(flow.production), workboardTaskId: flow.task.workboardTaskId }))
      .rejects.toMatchObject({ code: "approval_required", reason: "approval_revoked" });
    const revokedSnapshot = await revoked.runtime.readSnapshot();
    expect(revokedSnapshot.records.approvalHistory).toEqual([
      expect.objectContaining({ id: flow.approval.approval.id, decision: "approved" }),
    ]);
  });

  it("stops synchronously before rename and resumes only by an explicit production command", async () => {
    const runtimeRef: { current?: Awaited<ReturnType<typeof makeRuntime>>["runtime"] } = {};
    const setup = await makeRuntime({ hooks: { beforeApplyCommit: () => {
      if (!runtimeRef.current) throw new Error("runtime not initialized");
      void runtimeRef.current.stopLocalForTest();
    } } });
    runtimeRef.current = setup.runtime;
    const flow = await approvedPriorityChange(setup.runtime, setup.opened);

    await expect(setup.runtime.execute({ context: context(flow.production), workboardTaskId: flow.task.workboardTaskId }))
      .rejects.toMatchObject({ code: "stopped", committed: false });
    expect((await setup.runtime.readSnapshot()).current.productionPlans[0]).toMatchObject({ priority: 5, version: 1 });
    const stopped = await setup.runtime.getStatus();
    await setup.runtime.resume({ context: context(stopped) });
  });

  it("keeps a committed apply pending when evidence persistence fails and reconciles by readback without reapply", async () => {
    let failEvidence = true;
    const setup = await makeRuntime({ hooks: { beforeEvidencePersist: () => {
      if (failEvidence) throw new Error("evidence unavailable");
    } } });
    const flow = await approvedPriorityChange(setup.runtime, setup.opened);

    await expect(setup.runtime.execute({ context: context(flow.production), workboardTaskId: flow.task.workboardTaskId }))
      .rejects.toMatchObject({ code: "verification_required", committed: true });
    const pending = await setup.runtime.readSnapshot();
    expect(pending.current.productionPlans[0]).toMatchObject({ priority: 1, version: 2 });
    expect(pending.records.executions).toHaveLength(1);
    expect(pending.records.tasks[0].status).not.toBe("done");

    failEvidence = false;
    const reconciled = await setup.runtime.reconcile({ context: context(flow.production), workboardTaskId: flow.task.workboardTaskId });
    expect(reconciled.status).toBe("verified");
    const final = await setup.runtime.readSnapshot();
    expect(final.current.productionPlans[0]).toMatchObject({ priority: 1, version: 2 });
    expect(final.records.executions).toHaveLength(1);
    expect(final.records.tasks[0].status).toBe("done");
  });

  it("does not allow a committed pending execution to lose its exact proposal tuple", async () => {
    let failEvidence = true;
    const setup = await makeRuntime({ hooks: { beforeEvidencePersist: () => {
      if (failEvidence) throw new Error("evidence unavailable");
    } } });
    const flow = await approvedPriorityChange(setup.runtime, setup.opened);
    await expect(setup.runtime.execute({ context: context(flow.production), workboardTaskId: flow.task.workboardTaskId }))
      .rejects.toMatchObject({ code: "verification_required", committed: true });
    const sales = await setup.runtime.switchActor({ context: context(flow.production), actorId: "sales-demo" });
    await expect(setup.runtime.storeProposal({
      context: context(sales), workboardTaskId: flow.task.workboardTaskId,
      orderId: "SO-DEMO-1001", targetPlanId: "PP-DEMO-1001", toPriority: 2,
    })).rejects.toMatchObject({ code: "conflict", reason: "task_execution_started" });
    failEvidence = false;
    const production = await setup.runtime.switchActor({ context: context(sales), actorId: "production-demo" });
    expect((await setup.runtime.reconcile({ context: context(production), workboardTaskId: flow.task.workboardTaskId })).status).toBe("verified");
  });

  it("reset starts a stopped new epoch and preserves old records as read-only history", async () => {
    const setup = await makeRuntime();
    const flow = await approvedPriorityChange(setup.runtime, setup.opened);
    const applied = await setup.runtime.execute({ context: context(flow.production), workboardTaskId: flow.task.workboardTaskId });
    const oldEpoch = flow.production.epoch;
    const reset = await setup.runtime.reset({ context: context(flow.production), confirmation: "RESET" });

    expect(reset.epoch).not.toBe(oldEpoch);
    expect(reset.stopped).toBe(true);
    await expect(setup.runtime.execute({ context: context(flow.production), workboardTaskId: flow.task.workboardTaskId }))
      .rejects.toMatchObject({ code: "stale_context" });
    const snapshot = await setup.runtime.readSnapshot({ epoch: oldEpoch });
    expect(snapshot.readOnly).toBe(true);
    expect(snapshot.records.executions[0].id).toBe(applied.execution.id);
    const current = await setup.runtime.readSnapshot();
    const strategy = current.current.strategyVersions[0];
    const { content_hash: contentHash, ...strategyContent } = strategy;
    expect(contentHash).toBe(createHash("sha256").update(canonicalSerialize(strategyContent)).digest("hex"));
  });

  it("role changes invalidate stale sessions without revoking a current approval", async () => {
    const setup = await makeRuntime();
    const flow = await approvedPriorityChange(setup.runtime, setup.opened);
    const sales = await setup.runtime.switchActor({ context: context(flow.production), actorId: "sales-demo" });
    await expect(setup.runtime.execute({ context: context(flow.production), workboardTaskId: flow.task.workboardTaskId }))
      .rejects.toMatchObject({ code: "stale_context" });
    const production = await setup.runtime.switchActor({ context: context(sales), actorId: "production-demo" });
    const applied = await setup.runtime.execute({ context: context(production), workboardTaskId: flow.task.workboardTaskId });
    expect(applied.status).toBe("verified");
  });

  it("blocks expired approvals, wrong roles, and stale read references without mutating ERP", async () => {
    const expired = await makeRuntime();
    const flow = await approvedPriorityChange(expired.runtime, expired.opened);
    expired.clock.advance(15 * 60 * 1_000 + 1);
    await expect(expired.runtime.execute({ context: context(flow.production), workboardTaskId: flow.task.workboardTaskId }))
      .rejects.toMatchObject({ code: "approval_required", reason: "approval_expired" });
    expect((await expired.runtime.readSnapshot()).current.productionPlans[0]).toMatchObject({ priority: 5, version: 1 });

    const wrongRole = await makeRuntime();
    const wrongRoleStrategyRef = (await wrongRole.runtime.readSnapshot()).current.activeStrategyRef;
    const task = await wrongRole.runtime.createPriorityTask({
      context: context(wrongRole.opened), orderId: "SO-DEMO-1001", targetPlanId: "PP-DEMO-1001", toPriority: 1,
      strategyRef: wrongRoleStrategyRef,
    });
    await wrongRole.runtime.storeProposal({
      context: context(wrongRole.opened), workboardTaskId: task.workboardTaskId, orderId: "SO-DEMO-1001", targetPlanId: "PP-DEMO-1001", toPriority: 1,
    });
    await expect(wrongRole.runtime.execute({ context: context(wrongRole.opened), workboardTaskId: task.workboardTaskId }))
      .rejects.toMatchObject({ code: "unauthorized_role" });

    const stale = await makeRuntime();
    const staleFlow = await approvedPriorityChange(stale.runtime, stale.opened);
    const sales = await stale.runtime.switchActor({ context: context(staleFlow.production), actorId: "sales-demo" });
    const staleStrategyRef = (await stale.runtime.readSnapshot()).current.activeStrategyRef;
    const competingTask = await stale.runtime.createPriorityTask({
      context: context(sales), orderId: "SO-DEMO-1001", targetPlanId: "PP-DEMO-1001", toPriority: 2,
      strategyRef: staleStrategyRef,
    });
    await stale.runtime.storeProposal({
      context: context(sales), workboardTaskId: competingTask.workboardTaskId,
      orderId: "SO-DEMO-1001", targetPlanId: "PP-DEMO-1001", toPriority: 2,
    });
    const productionAgain = await stale.runtime.switchActor({ context: context(sales), actorId: "production-demo" });
    await stale.runtime.decideApproval({ context: context(productionAgain), workboardTaskId: competingTask.workboardTaskId, decision: "approved" });
    await stale.runtime.execute({ context: context(productionAgain), workboardTaskId: competingTask.workboardTaskId });
    await expect(stale.runtime.execute({ context: context(productionAgain), workboardTaskId: staleFlow.task.workboardTaskId }))
      .rejects.toMatchObject({ code: "approval_required", reason: "stale_state" });
  });

  it("turns readback faults into verification_required and later reconciles the committed fact", async () => {
    let failReadback = true;
    const setup = await makeRuntime({ hooks: { beforeReadback: () => {
      if (failReadback) throw new Error("readback unavailable");
    } } });
    const flow = await approvedPriorityChange(setup.runtime, setup.opened);
    await expect(setup.runtime.execute({ context: context(flow.production), workboardTaskId: flow.task.workboardTaskId }))
      .rejects.toMatchObject({ code: "verification_required", committed: true });
    failReadback = false;
    const result = await setup.runtime.reconcile({ context: context(flow.production), workboardTaskId: flow.task.workboardTaskId });
    expect(result.status).toBe("verified");
    expect((await setup.runtime.readSnapshot()).records.executions).toHaveLength(1);
  });

  it("restarts from a committed pending execution and performs readback only", async () => {
    let failEvidence = true;
    const setup = await makeRuntime({ hooks: { beforeEvidencePersist: () => {
      if (failEvidence) throw new Error("evidence unavailable");
    } } });
    const flow = await approvedPriorityChange(setup.runtime, setup.opened);
    await expect(setup.runtime.execute({ context: context(flow.production), workboardTaskId: flow.task.workboardTaskId }))
      .rejects.toMatchObject({ code: "verification_required", committed: true });
    await setup.runtime.close();
    failEvidence = false;
    const restarted = await makeRuntime({ root: setup.root });
    const result = await restarted.runtime.execute({
      context: context(restarted.opened), workboardTaskId: flow.task.workboardTaskId,
    });
    expect(result.status).toBe("verified");
    const snapshot = await restarted.runtime.readSnapshot();
    expect(snapshot.records.executions).toHaveLength(1);
    expect(snapshot.current.productionPlans[0]).toMatchObject({ priority: 1, version: 2 });
  });

  it("blocks a sales actor from completing pending readback while startup recovery is stopped", async () => {
    // Given: startup recovery persisted a stopped runtime with a committed execution awaiting readback.
    const setup = await makeRuntime({ hooks: { beforeEvidencePersist: () => {
      throw new Error("evidence unavailable");
    } } });
    const pending = await approvedPriorityChange(setup.runtime, setup.opened);
    await expect(setup.runtime.execute({ context: context(pending.production), workboardTaskId: pending.task.workboardTaskId }))
      .rejects.toMatchObject({ code: "verification_required", committed: true });
    await setup.runtime.close();

    const recovery = await makeRuntime({ root: setup.root, hooks: { beforeReadback: () => {
      throw new Error("readback unavailable during startup");
    } } });
    await recovery.runtime.close();
    const restarted = await makeRuntime({ root: setup.root });
    const beforeExecute = await restarted.runtime.readSnapshot();
    expect(restarted.opened).toMatchObject({ actorId: "sales-demo", role: "sales", stopped: true });
    expect(beforeExecute).toMatchObject({ stopped: true });
    expect(beforeExecute.records.executions).toEqual([
      expect.objectContaining({ state: "applied_pending_readback" }),
    ]);
    expect(beforeExecute.records.readbackEvidence).toEqual([]);

    // When: the default sales actor invokes the pending execution path after restart.
    const execution = restarted.runtime.execute({
      context: context(restarted.opened), workboardTaskId: pending.task.workboardTaskId,
    });

    // Then: verification remains blocked and no task, execution, or readback state is mutated.
    await expect(execution).rejects.toMatchObject({ code: "verification_required", committed: true });
    const afterExecute = await restarted.runtime.readSnapshot();
    expect(afterExecute.records.executions).toEqual([
      expect.objectContaining({ state: "applied_pending_readback" }),
    ]);
    expect(afterExecute.records.tasks[0]).toMatchObject({ status: "in_progress" });
    expect(afterExecute.records.readbackEvidence).toEqual([]);
  });

  it("persists startup readback failure as stopped until production resumes with a fresh approval", async () => {
    const failEvidence = true;
    const setup = await makeRuntime({ hooks: { beforeEvidencePersist: () => {
      if (failEvidence) throw new Error("evidence unavailable");
    } } });
    const pending = await approvedPriorityChange(setup.runtime, setup.opened);
    await expect(setup.runtime.execute({ context: context(pending.production), workboardTaskId: pending.task.workboardTaskId }))
      .rejects.toMatchObject({ code: "verification_required", committed: true });
    await setup.runtime.close();

    const recovery = await makeRuntime({ root: setup.root, hooks: { beforeReadback: () => {
      throw new Error("readback unavailable during startup");
    } } });

    // Given: startup found a committed apply that cannot be read back.
    const stoppedSnapshot = await recovery.runtime.readSnapshot();
    expect(recovery.opened.stopped).toBe(true);
    expect(stoppedSnapshot.stopped).toBe(true);
    expect(stoppedSnapshot.records.executions).toEqual([
      expect.objectContaining({ id: expect.any(String), state: "applied_pending_readback" }),
    ]);
    expect(stoppedSnapshot.records.tasks[0]).toMatchObject({ status: "in_progress", executionId: expect.any(String) });

    // When: a fresh mutation is attempted without an explicit production resume.
    await expect(recovery.runtime.execute({
      context: context(recovery.opened), workboardTaskId: pending.task.workboardTaskId,
    })).rejects.toMatchObject({ code: "verification_required", committed: true });
    await expect(recovery.runtime.createPriorityTask({
      context: context(recovery.opened),
      orderId: "SO-DEMO-1002",
      targetPlanId: "PP-DEMO-1002",
      toPriority: 1,
      strategyRef: stoppedSnapshot.current.activeStrategyRef,
    })).rejects.toMatchObject({ code: "stopped", reason: "runtime_stopped" });
    const rejectedSnapshot = await recovery.runtime.readSnapshot();
    expect(rejectedSnapshot.records.tasks).toHaveLength(1);
    expect(rejectedSnapshot.records.executions).toHaveLength(1);
    expect(rejectedSnapshot.current.productionPlans[0]).toMatchObject({ priority: 1, version: 2 });
    await recovery.runtime.close();

    const restarted = await makeRuntime({ root: setup.root });
    expect(restarted.opened.stopped).toBe(true);
    const beforeResume = await restarted.runtime.readSnapshot();
    expect(beforeResume.records.executions).toEqual([
      expect.objectContaining({ state: "applied_pending_readback" }),
    ]);
    expect(beforeResume.records.tasks[0]).toMatchObject({ status: "in_progress" });
    await expect(restarted.runtime.createPriorityTask({
      context: context(restarted.opened),
      orderId: "SO-DEMO-1002",
      targetPlanId: "PP-DEMO-1002",
      toPriority: 1,
      strategyRef: (await restarted.runtime.readSnapshot()).current.activeStrategyRef,
    })).rejects.toMatchObject({ code: "stopped", reason: "runtime_stopped" });

    // Then: only a production resume plus a new approval can apply another mutation.
    const production = await restarted.runtime.switchActor({ context: context(restarted.opened), actorId: "production-demo" });
    await restarted.runtime.resume({ context: context(production) });
    await expect(restarted.runtime.reconcile({ context: context(production), workboardTaskId: pending.task.workboardTaskId }))
      .resolves.toMatchObject({ status: "verified" });
    const sales = await restarted.runtime.switchActor({ context: context(production), actorId: "sales-demo" });
    const strategyRef = (await restarted.runtime.readSnapshot()).current.activeStrategyRef;
    const newTask = await restarted.runtime.createPriorityTask({
      context: context(sales),
      orderId: "SO-DEMO-1002",
      targetPlanId: "PP-DEMO-1002",
      toPriority: 1,
      strategyRef,
    });
    await restarted.runtime.storeProposal({
      context: context(sales),
      workboardTaskId: newTask.workboardTaskId,
      orderId: "SO-DEMO-1002",
      targetPlanId: "PP-DEMO-1002",
      toPriority: 1,
    });
    const freshProduction = await restarted.runtime.switchActor({ context: context(sales), actorId: "production-demo" });
    const freshApproval = await restarted.runtime.decideApproval({
      context: context(freshProduction), workboardTaskId: newTask.workboardTaskId, decision: "approved",
    });
    expect(freshApproval.approval.id).not.toBe(pending.approval.approval.id);
    await expect(restarted.runtime.execute({ context: context(freshProduction), workboardTaskId: newTask.workboardTaskId }))
      .resolves.toMatchObject({ status: "verified" });
    expect((await restarted.runtime.readSnapshot()).current.productionPlans[1]).toMatchObject({ id: "PP-DEMO-1002", priority: 1, version: 2 });
  });

  it("allows fact readback after a stop arrives beyond the commit boundary", async () => {
    const runtimeRef: { current?: Awaited<ReturnType<typeof makeRuntime>>["runtime"] } = {};
    const setup = await makeRuntime({ hooks: { afterApplyCommit: () => {
      if (!runtimeRef.current) throw new Error("runtime not initialized");
      runtimeRef.current.stopLocalForTest();
    } } });
    runtimeRef.current = setup.runtime;
    const flow = await approvedPriorityChange(setup.runtime, setup.opened);
    const result = await setup.runtime.execute({ context: context(flow.production), workboardTaskId: flow.task.workboardTaskId });
    expect(result.status).toBe("verified");
    expect((await setup.runtime.getStatus()).stopped).toBe(true);
    expect((await setup.runtime.readSnapshot()).current.productionPlans[0]).toMatchObject({ priority: 1, version: 2 });
  });

  it("recovers an after-rename lost reply from persisted facts without a second apply", async () => {
    const root = tempRoot();
    const seedRepository = createCompanyPersistence({ rootDir: root, bootstrap, isPackaged: false });
    await seedRepository.open();
    await seedRepository.close();
    let replacements = 0;
    const repository = createCompanyPersistence({
      rootDir: root,
      bootstrap,
      isPackaged: false,
      faults: { after_rename: () => { replacements += 1; if (replacements === 4) throw new Error("reply lost"); } },
    });
    const clock = clockFactory();
    const runtime = createCompanyRuntime({ repository, clock: clock.now, uuid: uuidFactory(), isPackaged: false });
    const opened = await runtime.open();
    const flow = await approvedPriorityChange(runtime, opened);
    const result = await runtime.execute({ context: context(flow.production), workboardTaskId: flow.task.workboardTaskId });
    expect(result.status).toBe("verified");
    const persisted = await runtime.readSnapshot();
    expect(persisted.current.productionPlans[0]).toMatchObject({ priority: 1, version: 2 });
    expect(persisted.records.executions).toHaveLength(1);
    expect((await runtime.getStatus()).stopped).toBe(true);
    expect(persisted.stopped).toBe(true);
  });

  it("records a read-only readiness result without approval, apply execution, or ERP mutation", async () => {
    const setup = await makeRuntime();
    const production = await setup.runtime.switchActor({ context: context(setup.opened), actorId: "production-demo" });
    const result = await setup.runtime.reviewReadiness({
      context: context(production), orderId: "SO-DEMO-1002", targetPlanId: "PP-DEMO-1002",
    });
    expect(result.task.status).toBe("done");
    expect(result.assessment).toMatchObject({ finding: "needs_review", mutationCount: 0 });
    const snapshot = await setup.runtime.readSnapshot();
    expect(snapshot.records.executions).toHaveLength(0);
    expect(snapshot.records.approvals).toHaveLength(0);
    expect(snapshot.current.productionPlans[1]).toMatchObject({ priority: 2, version: 1 });
  });

  it("persists the baseline and selected learning read-set expansion without approval, execution, or ERP mutation", async () => {
    // Given: the untouched second order and no reusable learning asset.
    const setup = await makeRuntime();
    const production = await setup.runtime.switchActor({ context: context(setup.opened), actorId: "production-demo" });
    const before = await setup.runtime.readSnapshot();

    // When: production reviews once before and once after sales explicitly publishes bounded learning.
    const baseline = await setup.runtime.reviewReadiness({
      context: context(production), orderId: "SO-DEMO-1002", targetPlanId: "PP-DEMO-1002", useLatestLearning: false,
    });
    const sales = await setup.runtime.switchActor({ context: context(production), actorId: "sales-demo" });
    const asset = await publishReusableLearning(setup.runtime, sales);
    const productionAgain = await setup.runtime.switchActor({ context: context(sales), actorId: "production-demo" });
    const reused = await setup.runtime.reviewReadiness({
      context: context(productionAgain), orderId: "SO-DEMO-1002", targetPlanId: "PP-DEMO-1002", useLatestLearning: true,
    });

    // Then: the exact asset version and additional ledger reads persist while authority and ERP state stay unchanged.
    expect(baseline.assessment).toMatchObject({
      finding: "needs_review",
      usedAssetRef: null,
      requiredChecks: [],
      additionalReadSet: [],
      reuse: { status: "baseline" },
    });
    expect(reused.assessment).toMatchObject({
      finding: "needs_review",
      usedAssetRef: { assetId: asset.id, version: asset.version },
      requiredChecks: ["inspection", "packaging"],
      reuse: { status: "selected", lineageStatus: "verified" },
    });
    expect(reused.assessment.baselineReadSet).toEqual(baseline.assessment.readSet);
    expect(reused.assessment.additionalReadSet).toEqual([
      { kind: "inspection", id: "INSPECTION-DEMO-1002", version: 1 },
      { kind: "shipment", id: "SHIPMENT-DEMO-1002", version: 1 },
    ]);
    const persisted = await setup.runtime.readSnapshot();
    expect(persisted.records.approvals).toHaveLength(0);
    expect(persisted.records.executions).toHaveLength(0);
    expect(persisted.current.productionPlans).toEqual(before.current.productionPlans);
    expect(persisted.current.inspections).toEqual(before.current.inspections);
    expect(persisted.current.shipments).toEqual(before.current.shipments);
    await setup.runtime.close();
    const reopened = await makeRuntime({ root: setup.root });
    expect((await reopened.runtime.readSnapshot()).records.assessmentEvidence).toEqual([
      expect.objectContaining({ id: baseline.assessment.id, usedAssetRef: null }),
      expect.objectContaining({ id: reused.assessment.id, usedAssetRef: { assetId: asset.id, version: asset.version } }),
    ]);
  });

  it("fails closed for withdrawn, private, and conflicting learning while preserving prior assessment facts", async () => {
    // Given: a selected reusable asset and its already-persisted assessment.
    const setup = await makeRuntime();
    const firstAsset = await publishReusableLearning(setup.runtime, setup.opened, ["inspection"]);
    const production = await setup.runtime.switchActor({ context: context(setup.opened), actorId: "production-demo" });
    const selected = await setup.runtime.reviewReadiness({
      context: context(production), orderId: "SO-DEMO-1002", targetPlanId: "PP-DEMO-1002", useLatestLearning: true,
    });
    const sales = await setup.runtime.switchActor({ context: context(production), actorId: "sales-demo" });

    // When: the author withdraws it, a private fixture is persisted, and two conflicting shared candidates are added.
    await setup.runtime.withdrawLearning({ context: context(sales), assetId: firstAsset.id, version: firstAsset.version });
    let productionAgain = await setup.runtime.switchActor({ context: context(sales), actorId: "production-demo" });
    const afterWithdrawal = await setup.runtime.reviewReadiness({
      context: context(productionAgain), orderId: "SO-DEMO-1002", targetPlanId: "PP-DEMO-1002", useLatestLearning: true,
    });
    const salesAgain = await setup.runtime.switchActor({ context: context(productionAgain), actorId: "sales-demo" });
    const privateAsset = await publishReusableLearning(setup.runtime, salesAgain, ["inspection"]);
    const privateSnapshot = await setup.runtime.readSnapshot();
    await setup.repository.transact({
      expectedRevision: privateSnapshot.revision,
      event: { id: randomUUID(), type: "test_private_learning_fixture", actorId: "sales-demo", occurredAt: setup.clock.now(), refs: [{ kind: "learning_asset", id: privateAsset.id }] },
      mutate(candidate: { records: { learningAssets: Array<{ id: string; version: number; sharingState: string }> } }) {
        const asset = candidate.records.learningAssets.find((item) => item.id === privateAsset.id && item.version === privateAsset.version);
        if (!asset) throw new TypeError("private learning fixture missing");
        asset.sharingState = "private";
      },
    });
    productionAgain = await setup.runtime.switchActor({ context: context(salesAgain), actorId: "production-demo" });
    const afterPrivate = await setup.runtime.reviewReadiness({
      context: context(productionAgain), orderId: "SO-DEMO-1002", targetPlanId: "PP-DEMO-1002", useLatestLearning: true,
    });
    const salesForConflict = await setup.runtime.switchActor({ context: context(productionAgain), actorId: "sales-demo" });
    await publishReusableLearning(setup.runtime, salesForConflict, ["inspection"]);
    await publishReusableLearning(setup.runtime, salesForConflict, ["packaging"]);
    productionAgain = await setup.runtime.switchActor({ context: context(salesForConflict), actorId: "production-demo" });
    const rejected = await setup.runtime.reviewReadiness({
      context: context(productionAgain), orderId: "SO-DEMO-1002", targetPlanId: "PP-DEMO-1002", useLatestLearning: true,
    });

    // Then: no candidate gains authority or extra reads and the earlier selected fact remains immutable.
    expect(afterWithdrawal.assessment).toMatchObject({
      usedAssetRef: null,
      additionalReadSet: [],
      reuse: { status: "no_candidate", code: "no_matching_candidate" },
    });
    expect(afterPrivate.assessment).toMatchObject({
      usedAssetRef: null,
      additionalReadSet: [],
      reuse: { status: "no_candidate", code: "no_matching_candidate" },
    });
    expect(rejected.assessment).toMatchObject({
      finding: "needs_review",
      usedAssetRef: null,
      requiredChecks: [],
      additionalReadSet: [],
      reuse: { status: "needs_review", code: "conflicting_required_checks" },
    });
    const persisted = await setup.runtime.readSnapshot();
    expect(persisted.records.assessmentEvidence.find((item) => item.id === selected.assessment.id)).toEqual(selected.assessment);
    expect(persisted.records.approvals).toHaveLength(0);
    expect(persisted.records.executions).toHaveLength(0);
    expect(persisted.current.productionPlans[1]).toMatchObject({ id: "PP-DEMO-1002", priority: 2, version: 1 });
  });

  it("creates one persisted v2 from bounded evidence and preserves v1 work through restart and retry", async () => {
    // Given: a v1-pinned sales task and one official readiness assessment.
    const setup = await makeRuntime();
    const before = await setup.runtime.readSnapshot();
    const v1 = before.current.activeStrategyRef;
    const oldFlow = await approvedPriorityChange(setup.runtime, setup.opened);
    const oldTask = oldFlow.task;
    const production = oldFlow.production;
    const readiness = await setup.runtime.reviewReadiness({
      context: context(production), orderId: "SO-DEMO-1002", targetPlanId: "PP-DEMO-1002",
    });
    const management = await setup.runtime.switchActor({ context: context(production), actorId: "management-demo" });
    const requestId = randomUUID();
    const request = {
      context: context(management),
      requestId,
      decision: "create_new_version",
      baseStrategyRef: v1,
      expectedBaseVersion: 1,
      evidenceRefs: [{ kind: "assessment", id: readiness.assessment.id, version: 1 }],
      uncertainties: ["검사 완료 시점은 아직 확인되지 않았습니다."],
      proposedChanges: {
        objective: "준비 상태를 확인한 뒤 납기를 판단",
        review_question: "검사와 포장 상태가 확인되었는가?",
        execution_criteria: ["검사와 포장 상태를 함께 확인"],
        constraints: ["미확인 상태에서 납기를 확약하지 않음"],
      },
    };

    // When: concurrent duplicates race to create v2, the app restarts, and the same request is retried.
    const [created, concurrentRetry] = await Promise.all([
      setup.runtime.reviewStrategy(request),
      setup.runtime.reviewStrategy(request),
    ]);
    await setup.runtime.close();
    const reopened = await makeRuntime({ root: setup.root });
    const reopenedManagement = await reopened.runtime.switchActor({ context: context(reopened.opened), actorId: "management-demo" });
    const retried = await reopened.runtime.reviewStrategy({ ...request, context: context(reopenedManagement) });

    // Then: v2 and its redacted evidence persist once, while old work and ERP facts remain unchanged.
    expect(created).toMatchObject({
      idempotent: false,
      review: { id: requestId, decision: "create_new_version", baseStrategyRef: v1 },
      version: { version: 2, parent_version_id: v1.strategy_version_id, created_by: "management-demo" },
    });
    expect(concurrentRetry).toEqual({ ...created, idempotent: true });
    expect(retried).toEqual({ ...created, idempotent: true });
    const persisted = await reopened.runtime.readSnapshot();
    expect(persisted.records.strategyReviews).toHaveLength(1);
    expect(persisted.current.strategyVersions).toHaveLength(2);
    expect(persisted.current.activeStrategyRef).toEqual(v1);
    expect(persisted.records.tasks.find((task) => task.workboardTaskId === oldTask.workboardTaskId)?.packet.strategy_ref).toEqual(v1);
    expect(persisted.current.productionPlans).toEqual(before.current.productionPlans);
    expect(persisted.current.inspections).toEqual(before.current.inspections);
    expect(persisted.current.shipments).toEqual(before.current.shipments);
    expect(persisted.records.approvals).toHaveLength(1);
    expect(persisted.records.approvals[0]).toMatchObject({
      id: oldFlow.approval.approval.id,
      strategyRef: v1,
      consumedByExecutionId: null,
    });
    expect(persisted.records.executions).toHaveLength(0);
    expect(persisted.records.strategyReviews[0].evidenceSnapshot[0]).toEqual({
      kind: "assessment",
      id: readiness.assessment.id,
      version: 1,
      contentHash: expect.stringMatching(/^[a-f0-9]{64}$/),
      visibilityScope: "official",
    });

    // When: management explicitly adopts v2 and a new sales task selects it.
    const adopted = await reopened.runtime.adoptStrategy({
      context: context(reopenedManagement),
      requestId: randomUUID(),
      reviewId: created.review.id,
      expectedActiveRef: v1,
    });
    const sales = await reopened.runtime.switchActor({ context: context(reopenedManagement), actorId: "sales-demo" });
    const newTask = await reopened.runtime.createPriorityTask({
      context: context(sales),
      orderId: "SO-DEMO-1002",
      targetPlanId: "PP-DEMO-1002",
      toPriority: 1,
      strategyRef: created.review.resultingStrategyRef,
    });

    // Then: active/adoption/audit persist once and only new work selects v2.
    expect(adopted).toMatchObject({ idempotent: false, adoption: { reviewId: created.review.id, fromRef: v1 } });
    expect(newTask.packet.strategy_ref).toEqual(created.review.resultingStrategyRef);
    const afterNewTask = await reopened.runtime.readSnapshot();
    expect(afterNewTask.current.activeStrategyRef).toEqual(created.review.resultingStrategyRef);
    expect(afterNewTask.records.strategyAdoptions).toHaveLength(1);
    expect(afterNewTask.records.events.filter((item) => item.type === "strategy_adopted")).toHaveLength(1);
    expect(afterNewTask.records.tasks.find((task) => task.workboardTaskId === oldTask.workboardTaskId)?.packet.strategy_ref).toEqual(v1);

    // When: the original adoption request is replayed after a restart.
    await reopened.runtime.close();
    const replayRuntime = await makeRuntime({ root: setup.root });
    const replayManagement = await replayRuntime.runtime.switchActor({ context: context(replayRuntime.opened), actorId: "management-demo" });
    const replayed = await replayRuntime.runtime.adoptStrategy({
      context: context(replayManagement), requestId: adopted.adoption.id,
      reviewId: created.review.id, expectedActiveRef: v1,
    });

    // Then: replay returns stored facts and adds no revision, adoption, or event.
    expect(replayed).toEqual({ ...adopted, activeStrategyRef: created.review.resultingStrategyRef, idempotent: true });
    const replaySnapshot = await replayRuntime.runtime.readSnapshot();
    expect(replaySnapshot.records.strategyAdoptions).toHaveLength(1);
    expect(replaySnapshot.records.events.filter((item) => item.type === "strategy_adopted")).toHaveLength(1);

    // When: the request id is reused with changed content and a non-management actor replays it.
    await expect(replayRuntime.runtime.adoptStrategy({
      context: context(replayManagement), requestId: adopted.adoption.id,
      reviewId: randomUUID(), expectedActiveRef: v1,
    })).rejects.toMatchObject({ code: "conflict", reason: "duplicate_strategy_adoption_request" });
    const replaySales = await replayRuntime.runtime.switchActor({ context: context(replayManagement), actorId: "sales-demo" });
    await expect(replayRuntime.runtime.adoptStrategy({
      context: context(replaySales), requestId: adopted.adoption.id,
      reviewId: created.review.id, expectedActiveRef: v1,
    })).rejects.toMatchObject({ code: "unauthorized_role", reason: "management_role_required" });

    // Then: the v1-pinned approved task still completes under active v2.
    const replayProduction = await replayRuntime.runtime.switchActor({ context: context(replaySales), actorId: "production-demo" });
    const completed = await replayRuntime.runtime.execute({
      context: context(replayProduction), workboardTaskId: oldTask.workboardTaskId,
      approvalId: oldFlow.approval.approval.id,
    });
    expect(completed).toMatchObject({ status: "verified", task: { packet: { strategy_ref: v1 } } });
  });

  it("rejects cross-task strategy spoofing without adding approval or execution writes", async () => {
    // Given: a task proposal whose persisted intent is forged away from its packet strategy.
    const setup = await makeRuntime();
    const strategyRef = (await setup.runtime.readSnapshot()).current.activeStrategyRef;
    const task = await setup.runtime.createPriorityTask({
      context: context(setup.opened), orderId: "SO-DEMO-1001", targetPlanId: "PP-DEMO-1001", toPriority: 1, strategyRef,
    });
    await setup.runtime.storeProposal({
      context: context(setup.opened), workboardTaskId: task.workboardTaskId,
      orderId: "SO-DEMO-1001", targetPlanId: "PP-DEMO-1001", toPriority: 1,
    });
    const stored = await setup.runtime.readSnapshot();
    await setup.repository.transact({
      expectedRevision: stored.revision,
      event: { id: randomUUID(), type: "test_cross_task_strategy_spoof", actorId: "sales-demo", occurredAt: setup.clock.now(), refs: [] },
      mutate(candidate: { records: { actionIntents: Array<{ strategyRef: { strategy_id: string; strategy_version_id: string } }> } }) {
        candidate.records.actionIntents[0].strategyRef = {
          strategy_id: strategyRef.strategy_id,
          strategy_version_id: randomUUID(),
        };
      },
    });
    const production = await setup.runtime.switchActor({ context: context(setup.opened), actorId: "production-demo" });
    const before = await setup.runtime.readSnapshot();

    // When: production tries to approve the forged tuple.
    await expect(setup.runtime.decideApproval({
      context: context(production), workboardTaskId: task.workboardTaskId, decision: "approved",
    })).rejects.toMatchObject({ code: "stale_context", reason: "current_proposal_unavailable" });

    // Then: the rejected lifecycle call writes nothing.
    const after = await setup.runtime.readSnapshot();
    expect(after.revision).toBe(before.revision);
    expect(after.records.approvals).toEqual([]);
    expect(after.records.executions).toEqual([]);
  });

  it("replays the stored strategy result after its shared learning source is withdrawn", async () => {
    // Given: management creates v2 from an approved shared learning source.
    const setup = await makeRuntime();
    const learning = await publishReusableLearning(setup.runtime, setup.opened, ["inspection"], true);
    const management = await setup.runtime.switchActor({ context: context(setup.opened), actorId: "management-demo" });
    const snapshot = await setup.runtime.readSnapshot();
    const base = snapshot.current.strategyVersions[0];
    const request = {
      context: context(management), requestId: randomUUID(), decision: "create_new_version",
      baseStrategyRef: { strategy_id: base.strategy_id, strategy_version_id: base.strategy_version_id },
      expectedBaseVersion: base.version,
      evidenceRefs: [{ kind: "learning", id: learning.id, version: learning.version }],
      uncertainties: ["성과 확인 전입니다."],
      proposedChanges: {
        objective: "검사 근거를 확인한 뒤 납기를 판단",
        review_question: "검사 근거가 확인되었는가?",
        execution_criteria: ["검사 근거 확인"],
        constraints: ["미확인 상태에서 확약하지 않음"],
      },
    };
    const created = await setup.runtime.reviewStrategy(request);
    const sales = await setup.runtime.switchActor({ context: context(management), actorId: "sales-demo" });
    await setup.runtime.withdrawLearning({ context: context(sales), assetId: learning.id, version: learning.version });
    const managementAgain = await setup.runtime.switchActor({ context: context(sales), actorId: "management-demo" });

    // When: the exact request is retried after withdrawal, then reused with a changed objective.
    const replayed = await setup.runtime.reviewStrategy({ ...request, context: context(managementAgain) });
    const mismatched = setup.runtime.reviewStrategy({
      ...request,
      context: context(managementAgain),
      proposedChanges: { ...request.proposedChanges, objective: "다른 목표" },
    });

    // Then: lifecycle changes do not break exact replay, but request-id reuse still fails closed.
    expect(replayed).toEqual({ ...created, idempotent: true });
    await expect(mismatched).rejects.toMatchObject({ code: "conflict", reason: "duplicate_strategy_review_request" });
    await expect(setup.runtime.adoptStrategy({
      context: context(managementAgain), requestId: randomUUID(), reviewId: created.review.id,
      expectedActiveRef: request.baseStrategyRef,
    })).rejects.toMatchObject({ code: "invalid_input", reason: "withdrawn_strategy_review_evidence" });
    const persisted = await setup.runtime.readSnapshot();
    expect(persisted.current.activeStrategyRef).toEqual(request.baseStrategyRef);
    expect(persisted.current.strategyVersions).toHaveLength(2);
    expect(persisted.records.strategyReviews).toHaveLength(1);
  });

  it("records maintain without a version and rejects stale, missing, private, or non-management review authority", async () => {
    // Given: one management-visible shared learning asset and a private persisted asset.
    const setup = await makeRuntime();
    const shared = await publishReusableLearning(setup.runtime, setup.opened, ["inspection"], true);
    const privateAsset = await publishReusableLearning(setup.runtime, setup.opened, ["packaging"], true);
    const privateSnapshot = await setup.runtime.readSnapshot();
    await setup.repository.transact({
      expectedRevision: privateSnapshot.revision,
      event: { id: randomUUID(), type: "test_private_strategy_review_fixture", actorId: "sales-demo", occurredAt: setup.clock.now(), refs: [{ kind: "learning_asset", id: privateAsset.id }] },
      mutate(candidate: { records: { learningAssets: Array<{ id: string; version: number; sharingState: string }> } }) {
        const asset = candidate.records.learningAssets.find((item) => item.id === privateAsset.id && item.version === privateAsset.version);
        if (!asset) throw new TypeError("private learning fixture missing");
        asset.sharingState = "private";
      },
    });
    const management = await setup.runtime.switchActor({ context: context(setup.opened), actorId: "management-demo" });
    const active = (await setup.runtime.readSnapshot()).current.strategyVersions[0];
    const changes = {
      objective: active.objective,
      review_question: active.review_question,
      execution_criteria: active.execution_criteria,
      constraints: active.constraints,
    };

    // When: management maintains v1 from shared evidence and invalid authorities attempt reviews.
    const maintained = await setup.runtime.reviewStrategy({
      context: context(management), requestId: randomUUID(), decision: "maintain",
      baseStrategyRef: { strategy_id: active.strategy_id, strategy_version_id: active.strategy_version_id },
      expectedBaseVersion: 1,
      evidenceRefs: [{ kind: "learning", id: shared.id, version: shared.version }],
      uncertainties: ["성과 확인 전입니다."], proposedChanges: changes,
    });
    const sales = await setup.runtime.switchActor({ context: context(management), actorId: "sales-demo" });

    // Then: maintain persists no version and all invalid authority paths fail closed.
    expect(maintained).toMatchObject({ review: { decision: "maintain", resultingStrategyRef: null }, version: null });
    await expect(setup.runtime.reviewStrategy({
      context: context(sales), requestId: randomUUID(), decision: "maintain",
      baseStrategyRef: { strategy_id: active.strategy_id, strategy_version_id: active.strategy_version_id },
      expectedBaseVersion: 1, evidenceRefs: [{ kind: "learning", id: shared.id, version: shared.version }],
      uncertainties: ["성과 확인 전입니다."], proposedChanges: changes,
    })).rejects.toMatchObject({ code: "unauthorized_role" });
    const managementAgain = await setup.runtime.switchActor({ context: context(sales), actorId: "management-demo" });
    for (const evidenceRefs of [
      [{ kind: "learning", id: privateAsset.id, version: privateAsset.version }],
      [{ kind: "assessment", id: randomUUID(), version: 1 }],
    ]) {
      await expect(setup.runtime.reviewStrategy({
        context: context(managementAgain), requestId: randomUUID(), decision: "maintain",
        baseStrategyRef: { strategy_id: active.strategy_id, strategy_version_id: active.strategy_version_id },
        expectedBaseVersion: 1, evidenceRefs,
        uncertainties: ["성과 확인 전입니다."], proposedChanges: changes,
      })).rejects.toMatchObject({ code: "invalid_input", reason: "strategy_review_evidence_unavailable" });
    }
    await expect(setup.runtime.reviewStrategy({
      context: context(managementAgain), requestId: randomUUID(), decision: "create_new_version",
      baseStrategyRef: { strategy_id: active.strategy_id, strategy_version_id: active.strategy_version_id },
      expectedBaseVersion: 2, evidenceRefs: [{ kind: "learning", id: shared.id, version: shared.version }],
      uncertainties: ["성과 확인 전입니다."], proposedChanges: changes,
    })).rejects.toMatchObject({ code: "stale_context", reason: "stale_strategy_base" });
  });
});
