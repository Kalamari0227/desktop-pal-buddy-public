import { pathToFileURL } from "node:url";
import { createHash, randomUUID } from "node:crypto";
import {
  ACTOR_IDS,
  RUNTIME_ERROR_CODES,
  assessOrderPriority,
  canonicalSerialize,
  createLearningAssetStore,
  createInitialCompanyState,
  runtimeRequestEnvelopeSchema,
} from "../dist-runtime/domain.mjs";

const MAX_ENVELOPE_BYTES = 64 * 1024;
const MAX_REQUEST_TEXT_LENGTH = 16 * 1024;
const ERROR_CODES = new Set(RUNTIME_ERROR_CODES);
const ACTORS = new Set(ACTOR_IDS);

export const COMPANY_IPC_CHANNELS = Object.freeze({
  bootstrap: "company:bootstrap",
  read: "company:read",
  submit: "company:submit",
  approve: "company:approve",
  execute: "company:execute",
  explainResult: "company:explain-result",
  role: "company:role",
  stop: "company:stop",
  resume: "company:resume",
  reset: "company:reset",
  cancel: "company:cancel",
  reconcile: "company:reconcile",
  experience: "company:experience",
  learning: "company:learning",
  reviewReadiness: "company:review-readiness",
  reviewStrategy: "company:review-strategy",
  adoptStrategy: "company:adopt-strategy",
  refreshAiConnection: "company:refresh-ai-connection",
  updated: "company:updated",
});

const AI_CONNECTION_CHECKING = Object.freeze({ state: "checking", reasonCode: "checking" });
const AI_CONNECTION_READY = Object.freeze({ state: "ready", reasonCode: "local_profile_ready" });
const AI_CONNECTION_UNAVAILABLE = Object.freeze({ state: "unavailable", reasonCode: "profile_unavailable" });

function unavailableReason(result) {
  return result?.error?.reason === "codex_not_found" ? "codex_not_found" : "profile_unavailable";
}

export function createAiConnectionController({ discover, onReady, onUnavailable } = {}) {
  if (typeof discover !== "function") throw new TypeError("AI discovery is required");
  let state = AI_CONNECTION_CHECKING;
  let inFlight = null;
  return {
    get: () => state,
    refresh() {
      if (inFlight) return inFlight;
      state = AI_CONNECTION_CHECKING;
      inFlight = (async () => {
        try {
          const result = await discover();
          if (!result?.ok) {
            await onUnavailable?.();
            state = Object.freeze({ state: "unavailable", reasonCode: unavailableReason(result) });
            return state;
          }
          await onReady?.(result);
          state = AI_CONNECTION_READY;
          return state;
        } catch {
          await onUnavailable?.();
          state = Object.freeze({ state: "unavailable", reasonCode: "discovery_failed" });
          return state;
        } finally {
          inFlight = null;
        }
      })();
      return inFlight;
    },
  };
}

function exactObject(value, keys) {
  return value !== null
    && typeof value === "object"
    && !Array.isArray(value)
    && Object.keys(value).length === keys.length
    && keys.every((key) => Object.hasOwn(value, key));
}

function uuid(value) {
  return typeof value === "string"
    && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
}

function parseBootstrapEnvelope(value) {
  if (!exactObject(value, ["schemaVersion", "requestId", "epoch", "actorSessionRevision", "payload"])
    || value.schemaVersion !== 1
    || !uuid(value.requestId)
    || value.epoch !== null
    || value.actorSessionRevision !== null
    || !exactObject(value.payload, [])) return null;
  return value;
}

function serializedBytes(value) {
  try {
    return Buffer.byteLength(JSON.stringify(value));
  } catch {
    return Number.POSITIVE_INFINITY;
  }
}

function safeError(error) {
  const code = ERROR_CODES.has(error?.code) ? error.code : "unavailable";
  const reason = typeof error?.reason === "string" && error.reason.length <= 200
    ? error.reason
    : code === "unavailable" ? "company_runtime_unavailable" : code;
  return { code, message: reason };
}

function response(requestId, status, payload) {
  return {
    schemaVersion: 1,
    requestId,
    epoch: status.epoch,
    actorSessionRevision: status.actorSessionRevision,
    ok: true,
    payload,
  };
}

function failure(requestId, status, error) {
  return {
    schemaVersion: 1,
    requestId,
    epoch: status?.epoch ?? null,
    actorSessionRevision: status?.actorSessionRevision ?? null,
    ok: false,
    error: safeError(error),
  };
}

function invalid(reason = "invalid_envelope") {
  return Object.assign(new Error(reason), { code: "invalid_input", reason });
}

function stale() {
  return Object.assign(new Error("request_context_is_stale"), {
    code: "stale_context",
    reason: "request_context_is_stale",
  });
}

function senderAllowed(event, getMainWindow, { isDev, devOrigin, packagedEntryPath }) {
  const mainWindow = getMainWindow();
  if (!mainWindow || mainWindow.isDestroyed?.()) return false;
  const webContents = mainWindow.webContents;
  if (!webContents || webContents.isDestroyed?.()) return false;
  if (event?.sender !== webContents || event?.senderFrame !== webContents.mainFrame) return false;
  const frameUrl = event.senderFrame?.url;
  if (typeof frameUrl !== "string") return false;
  if (isDev) return frameUrl === devOrigin || frameUrl === `${devOrigin}/`;
  return frameUrl === pathToFileURL(packagedEntryPath).href;
}

function validatePayload(operation, payload) {
  const empty = () => {
    if (!exactObject(payload, [])) throw invalid("invalid_payload");
    return payload;
  };
  if (operation === "read") {
    if (!exactObject(payload, []) && !(exactObject(payload, ["epoch"]) && uuid(payload.epoch))) throw invalid("invalid_read_payload");
    return payload;
  }
  if (["stop", "resume", "cancel", "refreshAiConnection"].includes(operation)) return empty();
  if (operation === "submit") {
    if (!exactObject(payload, ["requestText"])
      || typeof payload.requestText !== "string"
      || payload.requestText.trim().length === 0
      || payload.requestText.length > MAX_REQUEST_TEXT_LENGTH) throw invalid("invalid_submit_payload");
    return payload;
  }
  if (operation === "role") {
    if (!exactObject(payload, ["actorId"]) || !ACTORS.has(payload.actorId)) throw invalid("invalid_role_payload");
    return payload;
  }
  if (operation === "approve") {
    if (!exactObject(payload, ["workboardTaskId", "decision"])
      || !uuid(payload.workboardTaskId)
      || !["approved", "rejected", "revoked"].includes(payload.decision)) throw invalid("invalid_approval_payload");
    return payload;
  }
  if (operation === "execute") {
    const keys = payload?.approvalId === undefined ? ["workboardTaskId"] : ["workboardTaskId", "approvalId"];
    if (!exactObject(payload, keys) || !uuid(payload.workboardTaskId)
      || (payload.approvalId !== undefined && !uuid(payload.approvalId))) throw invalid("invalid_execute_payload");
    return payload;
  }
  if (operation === "explainResult") {
    if (!exactObject(payload, ["workboardTaskId"]) || !uuid(payload.workboardTaskId)) {
      throw invalid("invalid_result_explanation_payload");
    }
    return payload;
  }
  if (operation === "reconcile") {
    if (!exactObject(payload, ["workboardTaskId"]) || !uuid(payload.workboardTaskId)) throw invalid("invalid_reconcile_payload");
    return payload;
  }
  if (operation === "experience") {
    if (!exactObject(payload, ["workboardTaskId", "draft"]) || !uuid(payload.workboardTaskId)
      || payload.draft === null || typeof payload.draft !== "object" || Array.isArray(payload.draft)) {
      throw invalid("invalid_experience_payload");
    }
    return payload;
  }
  if (operation === "reviewReadiness") {
    if (!exactObject(payload, ["orderId", "targetPlanId", "useLatestLearning"])
      || payload.orderId !== "SO-DEMO-1002"
      || payload.targetPlanId !== "PP-DEMO-1002"
      || typeof payload.useLatestLearning !== "boolean") throw invalid("invalid_readiness_payload");
    return payload;
  }
  if (operation === "reviewStrategy") {
    const keys = ["decision", "baseStrategyRef", "expectedBaseVersion", "evidenceRefs", "uncertainties", "proposedChanges"];
    const boundedText = (value) => typeof value === "string" && value.trim().length > 0 && value.length <= 500;
    const textArray = (value) => Array.isArray(value) && value.length >= 1 && value.length <= 12 && value.every(boundedText);
    const reference = (value) => exactObject(value, ["kind", "id", "version"])
      && ["task", "assessment", "readback", "learning"].includes(value.kind)
      && boundedText(value.id)
      && Number.isInteger(value.version) && value.version > 0;
    if (!exactObject(payload, keys)
      || !["maintain", "create_new_version"].includes(payload.decision)
      || !exactObject(payload.baseStrategyRef, ["strategy_id", "strategy_version_id"])
      || !boundedText(payload.baseStrategyRef.strategy_id)
      || !uuid(payload.baseStrategyRef.strategy_version_id)
      || !Number.isInteger(payload.expectedBaseVersion) || payload.expectedBaseVersion < 1
      || !Array.isArray(payload.evidenceRefs) || payload.evidenceRefs.length < 1 || payload.evidenceRefs.length > 12
      || !payload.evidenceRefs.every(reference)
      || !textArray(payload.uncertainties)
      || !exactObject(payload.proposedChanges, ["objective", "review_question", "execution_criteria", "constraints"])
      || !boundedText(payload.proposedChanges.objective)
      || !boundedText(payload.proposedChanges.review_question)
      || !textArray(payload.proposedChanges.execution_criteria)
      || !textArray(payload.proposedChanges.constraints)) throw invalid("invalid_strategy_review_payload");
    return payload;
  }
  if (operation === "adoptStrategy") {
    if (!exactObject(payload, ["requestId", "reviewId", "expectedActiveRef"])
      || !uuid(payload.requestId)
      || !uuid(payload.reviewId)
      || !exactObject(payload.expectedActiveRef, ["strategy_id", "strategy_version_id"])
      || typeof payload.expectedActiveRef.strategy_id !== "string"
      || payload.expectedActiveRef.strategy_id.trim().length === 0
      || !uuid(payload.expectedActiveRef.strategy_version_id)) {
      throw invalid("invalid_strategy_adoption_payload");
    }
    return payload;
  }
  if (operation === "learning") {
    if (!payload || typeof payload !== "object" || Array.isArray(payload) || !["preview", "publish", "withdraw"].includes(payload.action)) {
      throw invalid("invalid_learning_payload");
    }
    if (payload.action === "preview") {
      const requiredKeys = ["action", "draftId", "exactPublishableSentence", "applicability", "targetDepartments", "includeManagementStrategyReview"];
      const allowedKeys = [...requiredKeys, "assetId", "reuseEpoch", "reuseApplicability", "sourceLearningRefs"];
      if (!requiredKeys.every((key) => Object.hasOwn(payload, key))
        || Object.keys(payload).some((key) => !allowedKeys.includes(key))) throw invalid("invalid_learning_preview_payload");
    }
    if (payload.action === "publish" && (!exactObject(payload, ["action", "preview", "consentGranted"])
      || payload.preview === null || typeof payload.preview !== "object" || Array.isArray(payload.preview)
      || typeof payload.consentGranted !== "boolean")) throw invalid("invalid_learning_publish_payload");
    if (payload.action === "withdraw" && (!exactObject(payload, ["action", "assetId", "version"])
      || typeof payload.assetId !== "string" || !Number.isInteger(payload.version) || payload.version < 1)) {
      throw invalid("invalid_learning_withdraw_payload");
    }
    return payload;
  }
  if (operation === "reset") {
    if (!exactObject(payload, ["confirmation"]) || payload.confirmation !== "RESET") throw invalid("invalid_reset_payload");
    return payload;
  }
  throw invalid("unknown_operation");
}

function allSources(current) {
  const collections = [
    ["customer", current.customers],
    ["sales_opportunity", current.salesOpportunities],
    ["quote", current.quotes],
    ["sales_order", current.salesOrders],
    ["inventory", current.inventory],
    ["production_plan", current.productionPlans],
    ["inspection", current.inspections],
    ["shipment", current.shipments],
  ];
  return collections.flatMap(([kind, records]) => records.map((record) => ({
    kind,
    id: record.id,
    version: record.version,
    evidenceId: `evidence:${kind}:${record.id}:v${record.version}`,
  })));
}

function requiredEvidenceIdsForRequest(current, requestText) {
  const mentionedOrders = current.salesOrders.filter((order) => requestText.includes(order.id));
  const mentionedPlans = current.productionPlans.filter((plan) => requestText.includes(plan.id));
  if (mentionedOrders.length !== 1 || mentionedPlans.length !== 1) return [];
  const order = mentionedOrders[0];
  const plan = mentionedPlans[0];
  if (plan.orderId !== order.id) return [];
  const proposedPriority = plan.priority === 1 ? 2 : 1;
  return assessOrderPriority({
    state: current,
    orderId: order.id,
    planId: plan.id,
    proposedPriority,
  }).sources.map((item) => item.evidenceId);
}

function strategyContextFromSnapshot(snapshot) {
  const ref = snapshot.current.activeStrategyRef;
  const version = snapshot.current.strategyVersions.find((candidate) =>
    candidate.strategy_id === ref.strategy_id
    && candidate.strategy_version_id === ref.strategy_version_id);
  if (!version) throw invalid("active_strategy_context_missing");
  const { content_hash: _contentHash, ...content } = version;
  const computedHash = createHash("sha256").update(canonicalSerialize(content)).digest("hex");
  if (computedHash !== version.content_hash) throw invalid("strategy_context_hash_mismatch");
  return {
    ref: { ...ref },
    version: version.version,
    contentHash: version.content_hash,
    objective: version.objective,
    reviewQuestion: version.review_question,
    executionCriteria: [...version.execution_criteria],
    constraints: [...version.constraints],
  };
}

function sameStrategyContext(left, right) {
  return left.ref.strategy_id === right.ref.strategy_id
    && left.ref.strategy_version_id === right.ref.strategy_version_id
    && left.contentHash === right.contentHash;
}

function verifiedResultContext(snapshot, status, workboardTaskId) {
  const task = snapshot.records.tasks.find((candidate) => candidate.workboardTaskId === workboardTaskId);
  if (!task || task.epoch !== status.epoch || task.status !== "done" || !task.executionId) {
    throw invalid("verified_result_required");
  }
  const proposal = task.currentProposal;
  const intent = proposal && snapshot.records.actionIntents.find((candidate) =>
    candidate.id === proposal.intentId
    && candidate.revision === proposal.revision
    && candidate.proposalDigest === proposal.proposalDigest
    && candidate.workboardTaskId === task.workboardTaskId
    && candidate.packetTaskId === task.packetTaskId
    && candidate.epoch === task.epoch);
  const execution = snapshot.records.executions.find((candidate) => candidate.id === task.executionId);
  const approval = execution && snapshot.records.approvals.find((candidate) => candidate.id === execution.approvalId);
  const readback = execution && snapshot.records.readbackEvidence.find((candidate) => candidate.executionId === execution.id);
  const currentPlan = intent && snapshot.current.productionPlans.find((candidate) => candidate.id === intent.targetPlanId);
  const verified = intent
    && execution?.intentId === intent.id
    && execution.epoch === status.epoch
    && execution.mode === "apply"
    && execution.state === "verified"
    && execution.before.priority === intent.fromPriority
    && execution.expectedAfter.priority === intent.toPriority
    && approval?.id === task.currentApprovalId
    && approval.intentId === intent.id
    && approval.intentRevision === intent.revision
    && approval.proposalDigest === intent.proposalDigest
    && approval.consumedByExecutionId === execution.id
    && readback?.epoch === status.epoch
    && readback.targetPlanId === intent.targetPlanId
    && readback.matches === true
    && readback.expectedPriority === execution.expectedAfter.priority
    && readback.expectedVersion === execution.expectedAfter.version
    && readback.observedPriority === readback.expectedPriority
    && readback.observedVersion === readback.expectedVersion
    && currentPlan?.priority === readback.observedPriority
    && currentPlan.version === readback.observedVersion;
  if (!verified) throw invalid("verified_result_required");
  const evidenceId = `readback:${execution.id}`;
  const factId = `verified-readback:${execution.id}`;
  return {
    snapshotRevision: snapshot.revision,
    requestText: JSON.stringify({
      storedTaskObjective: task.packet.desired_outcome,
      instruction: "저장된 검증 사실만 설명하고 사업 결과는 확인되지 않았다고 유지하세요.",
    }),
    allowedEvidenceIds: [evidenceId],
    verifiedFacts: [{
      id: factId,
      evidenceId,
      text: `가상 ERP 생산계획 ${readback.targetPlanId}은 priority ${execution.before.priority}/v${execution.before.version}에서 ${readback.observedPriority}/v${readback.observedVersion}로 재조회되었고 기대값과 일치했습니다. 사업 결과는 확인되지 않았습니다.`,
    }],
  };
}

function validExplanationResult(result, context) {
  const data = result?.data;
  if (!result?.ok || !Array.isArray(result.actions) || result.actions.length !== 0
    || !exactObject(data, ["schemaVersion", "kind", "summary", "verifiedFactIds", "citedEvidenceIds", "uncertainties", "authorityClaims"])
    || data.schemaVersion !== 1 || data.kind !== "explanation"
    || typeof data.summary !== "string" || data.summary.length === 0
    || !Array.isArray(data.verifiedFactIds) || data.verifiedFactIds.length === 0
    || !Array.isArray(data.citedEvidenceIds) || data.citedEvidenceIds.length === 0
    || !Array.isArray(data.uncertainties)
    || !Array.isArray(data.authorityClaims) || data.authorityClaims.length !== 0) return false;
  const factIds = new Set(context.verifiedFacts.map((fact) => fact.id));
  const evidenceIds = new Set(context.allowedEvidenceIds);
  return data.verifiedFactIds.every((id) => typeof id === "string" && factIds.has(id))
    && data.citedEvidenceIds.every((id) => typeof id === "string" && evidenceIds.has(id))
    && data.uncertainties.every((item) => typeof item === "string");
}

function projectSnapshot(snapshot, status) {
  const experienceDrafts = snapshot.records.experienceDrafts
    .filter((draft) => draft.authorActorId === status.actorId);
  const learning = createLearningAssetStore({
    drafts: snapshot.records.experienceDrafts,
    assets: snapshot.records.learningAssets,
    withdrawals: snapshot.records.learningWithdrawals,
    suggestions: snapshot.records.learningSuggestions,
  }).projectForActor(status.actorId);
  return {
    formatVersion: snapshot.formatVersion,
    revision: snapshot.revision,
    currentEpoch: snapshot.currentEpoch,
    stopped: snapshot.stopped,
    current: snapshot.current,
    records: {
      ...snapshot.records,
      experienceDrafts,
      learningAssets: learning.active,
      learningWithdrawals: [],
      learningSuggestions: learning.suggestions,
      learningProvenance: learning.provenance,
      learningSearch: learning.active,
      learningRecommendations: learning.active,
      learningAiContext: learning.active,
      learningManagementStrategyReview: learning.managementStrategyReview,
    },
    ...(snapshot.history ? { history: snapshot.history } : {}),
    ...(snapshot.readOnly ? { readOnly: true } : {}),
    projection: { actorId: status.actorId, role: status.role },
  };
}

export function createCompanyContextView() {
  let current = null;
  let generation = 0;
  return {
    get() {
      if (!current) throw Object.assign(new Error("runtime_not_open"), { code: "unavailable", reason: "runtime_not_open" });
      return { ...current };
    },
    peek: () => current ? { ...current } : null,
    set(status) {
      const next = {
        epoch: status.epoch,
        actorId: status.actorId,
        role: status.role,
        actorSessionRevision: status.actorSessionRevision,
        stopped: status.stopped,
      };
      if (!current
        || current.epoch !== next.epoch
        || current.actorId !== next.actorId
        || current.role !== next.role
        || current.actorSessionRevision !== next.actorSessionRevision
        || current.stopped !== next.stopped) generation += 1;
      current = next;
      return { ...current };
    },
    invalidate() { generation += 1; },
    generation: () => generation,
  };
}

export function assertCompanyTestOptions({ isPackaged, testMode, options }) {
  if (options === undefined) return undefined;
  if (isPackaged || testMode !== "1") throw new TypeError("company test options require BNC_TEST_MODE=1 in a nonpackaged process");
  if (options === null || typeof options !== "object" || Array.isArray(options)) {
    throw new TypeError("invalid company test options");
  }
  const keys = Object.keys(options);
  const objectValue = (value) => value !== null && typeof value === "object" && !Array.isArray(value);
  if (keys.some((key) => !["dataDir", "faults", "modelStub", "localReadinessProbe"].includes(key))
    || (options.dataDir !== undefined && (typeof options.dataDir !== "string" || options.dataDir.length === 0))
    || (options.faults !== undefined && !objectValue(options.faults))
    || (options.modelStub !== undefined && !objectValue(options.modelStub))
    || (options.localReadinessProbe !== undefined && options.localReadinessProbe !== true)) {
    throw new TypeError("invalid company test options");
  }
  return options;
}

export function createCompanyBootstrapState({
  clock = () => new Date().toISOString(),
  uuidFactory = randomUUID,
} = {}) {
  const epoch = uuidFactory();
  const strategyVersionId = uuidFactory();
  const createdAt = clock();
  const strategyContent = {
    strategy_version_id: strategyVersionId,
    strategy_id: "STRATEGY-DEMO-PRODUCTION",
    version: 1,
    objective: "우선순위 변경 전 영향 주문을 확인",
    review_question: "우선순위 변경이 다른 주문과 검사·출하 준비에 미치는 영향은 무엇인가?",
    parent_version_id: null,
    execution_criteria: ["대상 주문·재고·생산계획 버전을 확인"],
    constraints: ["검사·출하 준비 미확인 상태에서 납기를 확약하지 않음"],
    created_by: "management-demo",
    created_at: createdAt,
    origin: "seed",
  };
  return createInitialCompanyState({
    epoch,
    strategyVersionId,
    createdAt,
    strategyContentHash: createHash("sha256").update(canonicalSerialize(strategyContent)).digest("hex"),
  });
}

export function registerCompanyIpcHandlers({
  ipcMain,
  runtime,
  interpreter,
  contextView = createCompanyContextView(),
  getMainWindow,
  isDev,
  devOrigin,
  packagedEntryPath,
  runtimeMode,
  actualAI,
  aiConnection,
}) {
  if (!ipcMain?.handle || !ipcMain?.removeHandler || !runtime || !getMainWindow) throw new TypeError("company IPC dependencies are required");
  const registered = [];
  const connection = aiConnection ?? {
    get: () => AI_CONNECTION_UNAVAILABLE,
    refresh: async () => AI_CONNECTION_UNAVAILABLE,
  };
  let aiRefreshInFlight = null;
  let aiOperationInFlight = false;

  const readAiConnection = () => {
    const current = connection.get?.();
    if (current?.state === "checking") return AI_CONNECTION_CHECKING;
    if (current?.state === "ready") return AI_CONNECTION_READY;
    if (current?.state === "unavailable") {
      const reasonCode = ["codex_not_found", "profile_unavailable", "discovery_failed"].includes(current.reasonCode)
        ? current.reasonCode
        : "profile_unavailable";
      return { state: "unavailable", reasonCode };
    }
    return AI_CONNECTION_UNAVAILABLE;
  };

  const refreshConnection = () => {
    if (aiRefreshInFlight) return aiRefreshInFlight;
    aiRefreshInFlight = Promise.resolve()
      .then(() => connection.refresh())
      .finally(() => { aiRefreshInFlight = null; });
    return aiRefreshInFlight;
  };

  const refresh = async () => contextView.set(await runtime.getStatus());
  const publish = async () => {
    const status = await refresh();
    const snapshot = await runtime.readSnapshot();
    const mainWindow = getMainWindow();
    if (mainWindow && !mainWindow.isDestroyed?.() && !mainWindow.webContents?.isDestroyed?.()) {
      mainWindow.webContents.send(COMPANY_IPC_CHANNELS.updated, response(
        randomUUID(),
        status,
        { snapshot: projectSnapshot(snapshot, status), status, aiConnection: readAiConnection() },
      ));
    }
  };

  async function invokeInterpreter(method, input) {
    if (aiOperationInFlight) {
      throw Object.assign(new Error("ai_operation_in_flight"), { code: "conflict", reason: "ai_operation_in_flight" });
    }
    if (typeof interpreter?.[method] !== "function") {
      throw Object.assign(new Error("interpreter_unavailable"), { code: "unavailable", reason: "interpreter_unavailable" });
    }
    aiOperationInFlight = true;
    try {
      return await interpreter[method](input);
    } finally {
      aiOperationInFlight = false;
    }
  }

  async function submit(envelope, status) {
    const startGeneration = contextView.generation();
    const snapshot = await runtime.readSnapshot();
    const sources = allSources(snapshot.current);
    const allowedTargetIds = sources.map((source) => source.id);
    const allowedEvidenceIds = sources.map((source) => source.evidenceId);
    const requiredEvidenceIds = requiredEvidenceIdsForRequest(snapshot.current, envelope.payload.requestText);
    const strategyContext = strategyContextFromSnapshot(snapshot);
    const interpreted = await invokeInterpreter("interpret", {
      schemaVersion: 1,
      requestId: envelope.requestId,
      phase: "interpret",
      epoch: status.epoch,
      actorSessionRevision: status.actorSessionRevision,
      requestText: envelope.payload.requestText,
      allowedTargetIds,
      allowedEvidenceIds,
      requiredEvidenceIds,
      strategyContext,
    });
    const latest = await runtime.getStatus();
    if (contextView.generation() !== startGeneration
      || latest.epoch !== status.epoch
      || latest.actorSessionRevision !== status.actorSessionRevision) throw stale();
    if (!interpreted?.ok) throw Object.assign(new Error(interpreted?.error?.reason ?? "interpretation_failed"), {
      code: ERROR_CODES.has(interpreted?.error?.code) ? interpreted.error.code : "ai_failed",
      reason: interpreted?.error?.reason ?? "interpretation_failed",
    });
    const candidate = interpreted.data;
    if (candidate.intent === "clarification" || candidate.clarificationQuestions?.length > 0) {
      return {
        interpretation: candidate,
        clarificationRequired: true,
        runtimeMode: runtimeMode ?? interpreter?.runtimeMode ?? "unavailable",
        actualAI: actualAI ?? interpreter?.actualAI === true,
      };
    }
    if (candidate.intent !== "change_production_priority" || !Number.isInteger(candidate.requestedPriority)) {
      throw invalid("unsupported_interpretation");
    }
    const orderId = candidate.targetIds.find((id) => snapshot.current.salesOrders.some((item) => item.id === id));
    const targetPlanId = candidate.targetIds.find((id) => snapshot.current.productionPlans.some((item) => item.id === id));
    if (!orderId || !targetPlanId) throw invalid("interpretation_target_missing");
    const cited = new Set(candidate.citedEvidenceIds);
    const interpretationCandidate = {
      orderId,
      planId: targetPlanId,
      proposedPriority: candidate.requestedPriority,
      citations: sources.filter((source) => cited.has(source.evidenceId)),
    };
    const grounded = assessOrderPriority({
      state: snapshot.current,
      orderId,
      planId: targetPlanId,
      proposedPriority: candidate.requestedPriority,
      aiCandidate: interpretationCandidate,
    });
    if (grounded.status !== "proposed") throw invalid(grounded.reason ?? grounded.status);
    const latestStrategyContext = strategyContextFromSnapshot(await runtime.readSnapshot());
    if (!sameStrategyContext(latestStrategyContext, strategyContext)) throw stale();
    const context = { epoch: status.epoch, actorSessionRevision: status.actorSessionRevision };
    const task = await runtime.createPriorityTask({
      context,
      orderId,
      targetPlanId,
      toPriority: candidate.requestedPriority,
      strategyRef: strategyContext.ref,
    });
    const proposal = await runtime.storeProposal({
      context,
      workboardTaskId: task.workboardTaskId,
      orderId,
      targetPlanId,
      toPriority: candidate.requestedPriority,
      interpretationCandidate,
    });
    return {
      interpretation: candidate,
      task,
      proposal,
      runtimeMode: runtimeMode ?? interpreter?.runtimeMode ?? "unavailable",
      actualAI: actualAI ?? interpreter?.actualAI === true,
    };
  }

  async function explainResult(envelope, status) {
    const startGeneration = contextView.generation();
    const snapshot = await runtime.readSnapshot();
    const context = verifiedResultContext(snapshot, status, envelope.payload.workboardTaskId);
    const explained = await invokeInterpreter("explain", {
      schemaVersion: 1,
      requestId: envelope.requestId,
      phase: "explain",
      epoch: status.epoch,
      actorSessionRevision: status.actorSessionRevision,
      requestText: context.requestText,
      allowedEvidenceIds: context.allowedEvidenceIds,
      verifiedFacts: context.verifiedFacts,
    });
    const latestStatus = await runtime.getStatus();
    const latestSnapshot = await runtime.readSnapshot();
    if (contextView.generation() !== startGeneration
      || latestStatus.epoch !== status.epoch
      || latestStatus.actorSessionRevision !== status.actorSessionRevision
      || latestSnapshot.revision !== context.snapshotRevision) throw stale();
    if (!validExplanationResult(explained, context)) {
      throw Object.assign(new Error(explained?.error?.reason ?? "explanation_failed"), {
        code: ERROR_CODES.has(explained?.error?.code) ? explained.error.code : "ai_failed",
        reason: explained?.error?.reason ?? "explanation_failed",
      });
    }
    return {
      explanation: explained.data,
      runtimeMode: runtimeMode ?? interpreter?.runtimeMode ?? "unavailable",
      actualAI: actualAI ?? interpreter?.actualAI === true,
    };
  }

  const operations = {
    read: async (envelope, status) => ({
      snapshot: projectSnapshot(await runtime.readSnapshot(envelope.payload), status),
      status,
      aiConnection: readAiConnection(),
    }),
    submit,
    explainResult,
    approve: async (envelope) => envelope.payload.decision === "revoked"
      ? runtime.revokeApproval({ context: envelope, workboardTaskId: envelope.payload.workboardTaskId })
      : runtime.decideApproval({ context: envelope, workboardTaskId: envelope.payload.workboardTaskId, decision: envelope.payload.decision }),
    execute: async (envelope) => runtime.execute({ context: envelope, ...envelope.payload }),
    role: async (envelope) => {
      interpreter?.cancel?.();
      contextView.invalidate();
      return runtime.switchActor({ context: envelope, actorId: envelope.payload.actorId });
    },
    stop: async (envelope) => {
      interpreter?.cancel?.();
      contextView.invalidate();
      return runtime.stop({ context: envelope });
    },
    resume: async (envelope) => runtime.resume({ context: envelope }),
    reset: async (envelope) => {
      interpreter?.cancel?.();
      contextView.invalidate();
      return runtime.reset({ context: envelope, confirmation: envelope.payload.confirmation });
    },
    cancel: async () => {
      interpreter?.cancel?.();
      contextView.invalidate();
      return { cancelled: true };
    },
    reconcile: async (envelope) => runtime.reconcile({ context: envelope, workboardTaskId: envelope.payload.workboardTaskId }),
    experience: async (envelope) => runtime.storeExperienceDraft({
      context: envelope,
      workboardTaskId: envelope.payload.workboardTaskId,
      draft: envelope.payload.draft,
    }),
    learning: async (envelope) => {
      if (envelope.payload.action === "preview") {
        const { action: _action, ...request } = envelope.payload;
        return runtime.previewLearning({ context: envelope, request });
      }
      if (envelope.payload.action === "publish") {
        return runtime.publishLearning({
          context: envelope,
          preview: envelope.payload.preview,
          consentGranted: envelope.payload.consentGranted,
        });
      }
      return runtime.withdrawLearning({
        context: envelope,
        assetId: envelope.payload.assetId,
        version: envelope.payload.version,
      });
    },
    reviewReadiness: async (envelope) => runtime.reviewReadiness({
      context: envelope,
      orderId: envelope.payload.orderId,
      targetPlanId: envelope.payload.targetPlanId,
      useLatestLearning: envelope.payload.useLatestLearning,
    }),
    reviewStrategy: async (envelope) => runtime.reviewStrategy({
      context: envelope,
      requestId: envelope.requestId,
      ...envelope.payload,
    }),
    adoptStrategy: async (envelope) => runtime.adoptStrategy({
      context: envelope,
      ...envelope.payload,
    }),
    refreshAiConnection: async () => {
      const pending = refreshConnection();
      await publish();
      await pending;
      return { aiConnection: readAiConnection() };
    },
  };

  function install(operation, channel) {
    ipcMain.handle(channel, async (event, input) => {
      const requestId = uuid(input?.requestId) ? input.requestId : randomUUID();
      let status = contextView.peek();
      try {
        if (!senderAllowed(event, getMainWindow, { isDev, devOrigin, packagedEntryPath })) {
          throw Object.assign(new Error("ipc_sender_rejected"), { code: "unauthorized_role", reason: "ipc_sender_rejected" });
        }
        if (serializedBytes(input) > MAX_ENVELOPE_BYTES) throw invalid("envelope_too_large");
        if (operation === "bootstrap") {
          const envelope = parseBootstrapEnvelope(input);
          if (!envelope) throw invalid("invalid_bootstrap_envelope");
          status = await refresh();
          const snapshot = await runtime.readSnapshot();
          return response(envelope.requestId, status, {
            snapshot: projectSnapshot(snapshot, status),
            status,
            aiConnection: readAiConnection(),
          });
        }
        status ??= await refresh();
        const parsed = runtimeRequestEnvelopeSchema.safeParse(input);
        if (!parsed.success) throw invalid("invalid_envelope");
        const envelope = parsed.data;
        if (envelope.epoch !== status.epoch || envelope.actorSessionRevision !== status.actorSessionRevision) throw stale();
        validatePayload(operation, envelope.payload);
        const operationStatus = status;
        const payload = await operations[operation](envelope, status);
        status = await refresh();
        if (operation === "refreshAiConnection"
          && (status.epoch !== operationStatus.epoch
            || status.actorSessionRevision !== operationStatus.actorSessionRevision)) throw stale();
        if (!["read", "cancel", "explainResult"].includes(operation)) await publish();
        return response(envelope.requestId, status, payload);
      } catch (error) {
        status = contextView.peek() ?? status;
        return failure(requestId, status, error);
      }
    });
    registered.push(channel);
  }

  install("bootstrap", COMPANY_IPC_CHANNELS.bootstrap);
  for (const operation of Object.keys(operations)) install(operation, COMPANY_IPC_CHANNELS[operation]);

  return {
    contextView,
    publish,
    dispose() {
      for (const channel of registered) ipcMain.removeHandler(channel);
    },
  };
}
