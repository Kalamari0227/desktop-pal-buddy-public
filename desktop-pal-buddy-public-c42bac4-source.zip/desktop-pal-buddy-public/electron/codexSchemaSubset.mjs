const UNSUPPORTED_KEYWORDS = new Set(["const", "uniqueItems", "minLength", "maxLength"]);

function collectUnsupportedKeywords(value, path = "$") {
  if (Array.isArray(value)) {
    return value.flatMap((item, index) => collectUnsupportedKeywords(item, `${path}[${index}]`));
  }
  if (!value || typeof value !== "object") return [];

  return Object.entries(value).flatMap(([key, child]) => [
    ...(UNSUPPORTED_KEYWORDS.has(key) ? [{ path: `${path}.${key}`, keyword: key }] : []),
    ...collectUnsupportedKeywords(child, `${path}.${key}`),
  ]);
}

export function validateCodexStructuredOutputSchema(schema) {
  const issues = collectUnsupportedKeywords(schema);
  const properties = schema?.properties;
  if (!schema || typeof schema !== "object" || Array.isArray(schema) || schema.type !== "object") {
    issues.push({ path: "$", keyword: "root_type" });
  }
  if (schema?.additionalProperties !== false) issues.push({ path: "$.additionalProperties", keyword: "additionalProperties" });
  if (!Array.isArray(schema?.required) || !properties || typeof properties !== "object" || Array.isArray(properties)) {
    issues.push({ path: "$.required", keyword: "required" });
  } else {
    for (const key of Object.keys(properties)) {
      if (!schema.required.includes(key)) issues.push({ path: `$.properties.${key}`, keyword: "required" });
    }
  }
  return issues;
}
