import { createHash, randomUUID } from "node:crypto";
import {
  canonicalizeReadSetDigestInput,
  canonicalSerialize,
  assessOrderPriority,
  createActionProposal,
  createExperienceDraftStore,
  createLearningAssetStore,
  createInitialCompanyState,
  createProductionPriorityChangePacket,
  createProductionReadinessReviewPacket,
  createTaskCompletionPreview,
  decideStrategyReview,
  decideStrategyAdoption,
  replayStrategyReview,
  decideApproval as decideApprovalRecord,
  evaluateApprovalAuthorization,
  reviseActionProposal,
  reviewProductionReadiness,
  selectLearningReuse,
  revokeApproval as revokeApprovalRecord,
  runtimeTaskRecordSchema,
  validateWorkboardStatusGate,
} from "../dist-runtime/domain.mjs";

const ACTOR_ROLES = {
  "sales-demo": "sales",
  "production-demo": "production",
  "management-demo": "management",
};

export class CompanyRuntimeError extends Error {
  constructor(code, reason, details = {}) {
    super(`${code}: ${reason}`, details.cause ? { cause: details.cause } : undefined);
    this.name = "CompanyRuntimeError";
    this.code = code;
    this.reason = reason;
    Object.assign(this, details);
  }
}

function sha256(value) {
  return createHash("sha256").update(value).digest("hex");
}

function clone(value) {
  return structuredClone(value);
}

function runtimeError(code, reason, details) {
  return new CompanyRuntimeError(code, reason, details);
}

function event(uuid, clock, type, actorId, refs = []) {
  return { id: uuid(), type, actorId, occurredAt: clock(), refs };
}

export function createCompanyRuntime({
  repository,
  clock = () => new Date().toISOString(),
  uuid = randomUUID,
  isPackaged = true,
  testHooks,
}) {
  if (!repository || typeof repository.open !== "function") throw new TypeError("repository is required");
  if (typeof clock !== "function" || typeof uuid !== "function") throw new TypeError("clock and uuid must be functions");
  if (testHooks !== undefined && (isPackaged || process.env.BNC_TEST_MODE !== "1")) {
    throw new TypeError("test hooks require BNC_TEST_MODE=1 in a nonpackaged process");
  }

  let actorId = "sales-demo";
  let actorSessionRevision = 0;
  let epoch = null;
  let stopped = true;
  let opened = false;
  let queue = Promise.resolve();
  const learningPreviews = new Map();

  function resolveStrategyEvidence(snapshot, evidenceRefs) {
    if (!Array.isArray(evidenceRefs) || evidenceRefs.length < 1 || evidenceRefs.length > 12) {
      throw runtimeError("invalid_input", "invalid_strategy_review_evidence");
    }
    const keys = new Set();
    const learning = createLearningAssetStore({
      drafts: snapshot.records.experienceDrafts,
      assets: snapshot.records.learningAssets,
      withdrawals: snapshot.records.learningWithdrawals,
      suggestions: snapshot.records.learningSuggestions,
    }).managementStrategyReview(actorId);
    return evidenceRefs.map((reference) => {
      if (!reference || typeof reference !== "object" || Array.isArray(reference)
        || Object.keys(reference).length !== 3
        || !["task", "assessment", "readback", "learning"].includes(reference.kind)
        || typeof reference.id !== "string" || reference.id.length === 0
        || !Number.isInteger(reference.version) || reference.version < 1) {
        throw runtimeError("invalid_input", "invalid_strategy_review_evidence");
      }
      const key = `${reference.kind}:${reference.id}:${reference.version}`;
      if (keys.has(key)) throw runtimeError("invalid_input", "duplicate_strategy_review_evidence");
      keys.add(key);
      let source = null;
      let visibilityScope = "official";
      if (reference.kind === "task" && reference.version === 1) {
        source = snapshot.records.tasks.find((candidate) =>
          candidate.workboardTaskId === reference.id && candidate.epoch === snapshot.currentEpoch) ?? null;
      } else if (reference.kind === "assessment" && reference.version === 1) {
        source = snapshot.records.assessmentEvidence.find((candidate) =>
          candidate.id === reference.id && candidate.epoch === snapshot.currentEpoch) ?? null;
      } else if (reference.kind === "readback") {
        source = snapshot.records.readbackEvidence.find((candidate) =>
          candidate.executionId === reference.id
          && candidate.epoch === snapshot.currentEpoch
          && candidate.observedVersion === reference.version) ?? null;
      } else if (reference.kind === "learning") {
        source = learning.find((candidate) => candidate.id === reference.id && candidate.version === reference.version) ?? null;
        visibilityScope = "management_shared";
      }
      if (!source) throw runtimeError("invalid_input", "strategy_review_evidence_unavailable");
      return {
        kind: reference.kind,
        id: reference.id,
        version: reference.version,
        contentHash: sha256(canonicalSerialize(source)),
        visibilityScope,
      };
    });
  }

  function enqueue(operation) {
    const result = queue.then(operation);
    queue = result.catch(() => undefined);
    return result;
  }

  function status() {
    if (!opened || !epoch) throw runtimeError("unavailable", "runtime_not_open");
    return { epoch, actorId, role: ACTOR_ROLES[actorId], actorSessionRevision, stopped };
  }

  function assertContext(context) {
    const current = status();
    if (!context || context.epoch !== current.epoch || context.actorSessionRevision !== current.actorSessionRevision) {
      throw runtimeError("stale_context", "request_context_is_stale");
    }
    return current;
  }

  function assertRole(role) {
    if (ACTOR_ROLES[actorId] !== role) throw runtimeError("unauthorized_role", `${role}_role_required`);
  }

  function experienceSources(snapshot, task) {
    if (!task.currentProposal) throw runtimeError("invalid_input", "experience_proposal_unavailable");
    const intent = snapshot.records.actionIntents.find((candidate) =>
      candidate.id === task.currentProposal.intentId
      && candidate.revision === task.currentProposal.revision
      && candidate.proposalDigest === task.currentProposal.proposalDigest
      && candidate.workboardTaskId === task.workboardTaskId
      && candidate.packetTaskId === task.packetTaskId);
    if (!intent) throw runtimeError("stale_context", "experience_proposal_unavailable");
    const target = intent.readSet.find((reference) =>
      reference.kind === "production_plan" && reference.id === intent.targetPlanId);
    if (!target) throw runtimeError("invalid_input", "experience_target_read_missing");
    const workItem = { workboardTaskId: task.workboardTaskId, packetTaskId: task.packetTaskId };
    const asset = { id: target.id, version: target.version };
    const sources = intent.evidenceRefs.map((evidenceId) => ({ evidenceId, kind: "work_fact", workItem, asset }));
    if (task.executionId) {
      const readback = snapshot.records.readbackEvidence.find((candidate) => candidate.executionId === task.executionId);
      if (readback) {
        sources.push({
          evidenceId: `readback:${task.executionId}`,
          kind: "readback",
          workItem,
          asset: { id: readback.targetPlanId, version: readback.observedVersion },
        });
      }
    }
    return sources;
  }

  function findTask(snapshot, workboardTaskId) {
    const task = snapshot.records.tasks.find((candidate) => candidate.workboardTaskId === workboardTaskId);
    if (!task) throw runtimeError("invalid_input", "unknown_runtime_task");
    return task;
  }

  function currentTuple(snapshot, workboardTaskId) {
    const task = findTask(snapshot, workboardTaskId);
    if (!task.currentProposal) throw runtimeError("approval_required", "current_proposal_unavailable");
    const intent = snapshot.records.actionIntents.find((candidate) =>
      candidate.id === task.currentProposal.intentId
      && candidate.revision === task.currentProposal.revision
      && candidate.proposalDigest === task.currentProposal.proposalDigest);
    const strategyStored = snapshot.current.strategyVersions.some((version) =>
      version.strategy_id === task.packet.strategy_ref?.strategy_id
      && version.strategy_version_id === task.packet.strategy_ref?.strategy_version_id);
    if (!intent || intent.workboardTaskId !== task.workboardTaskId || intent.packetTaskId !== task.packetTaskId
      || !strategyStored
      || !sameStrategyRef(intent.strategyRef, task.packet.strategy_ref)) {
      throw runtimeError("stale_context", "current_proposal_unavailable");
    }
    const approval = task.currentApprovalId
      ? snapshot.records.approvals.find((candidate) => candidate.id === task.currentApprovalId)
      : null;
    if (approval && (approval.intentId !== intent.id
      || approval.intentRevision !== intent.revision
      || approval.proposalDigest !== intent.proposalDigest
      || approval.epoch !== intent.epoch
      || approval.policyVersion !== intent.policyVersion
      || !sameStrategyRef(approval.strategyRef, intent.strategyRef)
      || approval.skillRef.id !== intent.skillRef.id
      || approval.skillRef.version !== intent.skillRef.version
      || approval.requesterActorId !== intent.requesterActorId)) {
      throw runtimeError("stale_context", "current_approval_unavailable");
    }
    return { task, intent, approval };
  }

  function sameStrategyRef(left, right) {
    return left?.strategy_id === right?.strategy_id
      && left?.strategy_version_id === right?.strategy_version_id;
  }

  async function verifyAndComplete(workboardTaskId, expectedExecutionId) {
    try {
      testHooks?.beforeReadback?.();
    } catch (error) {
      throw runtimeError("verification_required", "readback_failed", { cause: error, committed: true });
    }
    const fresh = await repository.loadFresh();
    const { task, intent, approval } = currentTuple(fresh, workboardTaskId);
    const execution = fresh.records.executions.find((candidate) => candidate.id === expectedExecutionId);
    if (!execution || !approval || task.executionId !== execution.id || approval.consumedByExecutionId !== execution.id) {
      throw runtimeError("verification_required", "persisted_execution_mismatch", { committed: true });
    }
    if (execution.state === "verified" && task.status === "done") {
      const persistedReadback = fresh.records.readbackEvidence.find((candidate) => candidate.executionId === execution.id);
      if (!persistedReadback) throw runtimeError("verification_required", "verified_readback_missing", { committed: true });
      return { status: "verified", execution: clone(execution), task: clone(task), readback: clone(persistedReadback) };
    }
    const plan = fresh.current.productionPlans.find((candidate) => candidate.id === intent.targetPlanId);
    const readback = {
      executionId: execution.id,
      targetPlanId: intent.targetPlanId,
      epoch: execution.epoch,
      expectedPriority: execution.expectedAfter.priority,
      expectedVersion: execution.expectedAfter.version,
      observedPriority: plan?.priority ?? execution.before.priority,
      observedVersion: plan?.version ?? execution.before.version,
      readAt: clock(),
      matches: Boolean(plan
        && plan.priority === execution.expectedAfter.priority
        && plan.version === execution.expectedAfter.version
        && fresh.currentEpoch === execution.epoch),
    };
    if (!readback.matches) throw runtimeError("verification_required", "readback_mismatch", { committed: true });
    const evidenceId = uuid();
    const evidence = {
      evidence_id: evidenceId,
      task_id: task.packetTaskId,
      created_at: readback.readAt,
      evidence_type: "production_state",
      summary: `Persisted production plan ${intent.targetPlanId} priority/version matched the committed execution.`,
      source: { system: "erp", ref: `company-runtime/${execution.epoch}/execution/${execution.id}` },
      status: "passed",
    };
    const trustedContext = {
      evidence_id: evidenceId,
      packet_task_id: task.packetTaskId,
      epoch: execution.epoch,
      execution_id: execution.id,
      read_set_digest: approval.readSetDigest,
      expected_priority: readback.expectedPriority,
      expected_version: readback.expectedVersion,
      observed_priority: readback.observedPriority,
      observed_version: readback.observedVersion,
      matches: true,
    };
    const completion = createTaskCompletionPreview({
      packet: task.packet,
      evidence: [evidence],
      result_summary: "Virtual ERP priority change verified by fresh persisted readback.",
      result_details: "Business outcome remains unobserved.",
      outcome: "passed",
      trusted_production_state_contexts: [trustedContext],
    });
    const gate = validateWorkboardStatusGate({
      packet: task.packet,
      current_status: "in_progress",
      target_status: "done",
      evidence: [evidence],
      result_summary: completion.packet.result?.summary,
      result_details: completion.packet.result?.details,
      outcome: "passed",
      approval_recorded: true,
      trusted_production_state_contexts: [trustedContext],
    });
    if (!completion.can_complete || !gate.allowed) {
      throw runtimeError("verification_required", "completion_gate_rejected", { committed: true, issues: gate.issues });
    }
    try {
      testHooks?.beforeEvidencePersist?.();
      const completed = await repository.transact({
        expectedRevision: fresh.revision,
        event: event(uuid, clock, "production_priority_verified", actorId, [
          { kind: "task", id: task.workboardTaskId },
          { kind: "execution", id: execution.id },
          { kind: "evidence", id: evidenceId },
        ]),
        mutate(snapshot) {
          const persistedTask = findTask(snapshot, workboardTaskId);
          const persistedExecution = snapshot.records.executions.find((candidate) => candidate.id === execution.id);
          if (!persistedExecution || persistedTask.executionId !== execution.id) {
            throw runtimeError("conflict", "execution_changed_during_readback");
          }
          if (!snapshot.records.readbackEvidence.some((candidate) => candidate.executionId === execution.id)) {
            snapshot.records.readbackEvidence.push(readback);
          }
          persistedExecution.state = "verified";
          persistedTask.packet = completion.packet;
          persistedTask.status = "done";
        },
      });
      return {
        status: "verified",
        execution: completed.records.executions.find((candidate) => candidate.id === execution.id),
        task: completed.records.tasks.find((candidate) => candidate.workboardTaskId === workboardTaskId),
        readback,
      };
    } catch (error) {
      if (error instanceof CompanyRuntimeError) throw error;
      throw runtimeError("verification_required", "evidence_persistence_failed", { cause: error, committed: true });
    }
  }

  const api = {
    open() {
      return enqueue(async () => {
        const snapshot = await repository.open();
        epoch = snapshot.currentEpoch;
        stopped = snapshot.stopped;
        opened = true;
        for (const task of snapshot.records.tasks) {
          if (stopped) break;
          if (task.executionId && task.status !== "done") {
            try {
              await verifyAndComplete(task.workboardTaskId, task.executionId);
            } catch {
              stopped = true;
              const fresh = await repository.loadFresh();
              if (!fresh.stopped) {
                await repository.transact({
                  expectedRevision: fresh.revision,
                  event: event(uuid, clock, "runtime_stopped_after_startup_verification_failure", actorId, [
                    { kind: "task", id: task.workboardTaskId },
                    { kind: "execution", id: task.executionId },
                  ]),
                  mutate(candidate) { candidate.current.stopped = true; },
                });
              }
            }
          }
        }
        return status();
      });
    },
    getStatus() {
      return Promise.resolve(clone(status()));
    },
    readSnapshot(options = {}) {
      return enqueue(async () => {
        const snapshot = await repository.loadFresh();
        if (!options.epoch || options.epoch === snapshot.currentEpoch) return clone(snapshot);
        const archived = snapshot.history.find((candidate) => candidate.epoch === options.epoch);
        if (!archived) throw runtimeError("invalid_input", "unknown_epoch");
        return { ...clone(archived), readOnly: true };
      });
    },
    createPriorityTask({ context, orderId, targetPlanId, toPriority, strategyRef }) {
      return enqueue(async () => {
        assertContext(context);
        assertRole("sales");
        if (stopped) throw runtimeError("stopped", "runtime_stopped");
        const snapshot = await repository.loadFresh();
        const plan = snapshot.current.productionPlans.find((candidate) => candidate.id === targetPlanId);
        if (!plan || plan.orderId !== orderId || !Number.isInteger(toPriority) || toPriority < 1 || toPriority > 9) {
          throw runtimeError("invalid_input", "invalid_priority_task");
        }
        const selectedStrategy = snapshot.current.strategyVersions.find((candidate) =>
          candidate.strategy_id === strategyRef?.strategy_id
          && candidate.strategy_version_id === strategyRef?.strategy_version_id);
        if (!selectedStrategy || !sameStrategyRef(strategyRef, snapshot.current.activeStrategyRef)) {
          throw runtimeError("stale_context", "strategy_context_is_stale");
        }
        const workboardTaskId = uuid();
        const packetTaskId = uuid();
        const packet = createProductionPriorityChangePacket({
          packetTaskId,
          createdAt: clock(),
          requesterActorId: actorId,
          strategyRef,
        });
        const record = runtimeTaskRecordSchema.parse({
          workboardTaskId,
          packetTaskId,
          epoch: snapshot.currentEpoch,
          packet,
          status: "pending",
          currentProposal: null,
          currentApprovalId: null,
          executionId: null,
          businessOutcome: { packetTaskId, status: "unobserved", recordedByActorId: null, evidenceRefs: [], observedAt: null },
        });
        await repository.transact({
          expectedRevision: snapshot.revision,
          event: event(uuid, clock, "runtime_task_created", actorId, [{ kind: "task", id: workboardTaskId }]),
          mutate(candidate) { candidate.records.tasks.push(record); },
          beforeRename(candidate) {
            const currentStrategy = candidate.current.strategyVersions.find((version) =>
              sameStrategyRef(version, strategyRef));
            if (!sameStrategyRef(candidate.current.activeStrategyRef, strategyRef)
              || currentStrategy?.content_hash !== selectedStrategy.content_hash) {
              throw runtimeError("stale_context", "strategy_context_is_stale", { committed: false });
            }
          },
        });
        return clone(record);
      });
    },
    storeProposal({ context, workboardTaskId, orderId, targetPlanId, toPriority, interpretationCandidate }) {
      return enqueue(async () => {
        assertContext(context);
        assertRole("sales");
        if (stopped) throw runtimeError("stopped", "runtime_stopped");
        const snapshot = await repository.loadFresh();
        const task = findTask(snapshot, workboardTaskId);
        if (task.epoch !== snapshot.currentEpoch || task.status === "done") throw runtimeError("stale_context", "task_not_current");
        if (task.executionId) throw runtimeError("conflict", "task_execution_started");
        if (interpretationCandidate !== undefined) {
          const grounded = assessOrderPriority({
            state: snapshot.current,
            orderId,
            planId: targetPlanId,
            proposedPriority: toPriority,
            aiCandidate: interpretationCandidate,
          });
          if (grounded.status === "blocked") throw runtimeError("invalid_input", grounded.reason ?? "invalid_interpretation_candidate");
        }
        let decision;
        if (task.currentProposal) {
          const prior = snapshot.records.actionIntents.find((candidate) =>
            candidate.id === task.currentProposal.intentId && candidate.revision === task.currentProposal.revision);
          decision = reviseActionProposal({ state: snapshot.current, previousIntent: prior, toPriority, createdAt: clock() }, sha256);
        } else {
          decision = createActionProposal({
            mode: "shadow",
            state: snapshot.current,
            orderId,
            targetPlanId,
            toPriority,
            strategyRef: task.packet.strategy_ref,
            skillRef: { id: "change-production-priority", version: 1 },
            policyVersion: "company-policy-v1",
            trusted: {
              intentId: uuid(), workboardTaskId, packetTaskId: task.packetTaskId,
              epoch: snapshot.currentEpoch, requesterActorId: "sales-demo", createdAt: clock(),
            },
          }, sha256);
        }
        if (decision.status !== "proposed") throw runtimeError("invalid_input", decision.reason ?? decision.status);
        const intent = decision.intent;
        await repository.transact({
          expectedRevision: snapshot.revision,
          event: event(uuid, clock, "production_priority_proposed", actorId, [
            { kind: "task", id: workboardTaskId }, { kind: "intent", id: intent.id },
          ]),
          mutate(candidate) {
            const persistedTask = findTask(candidate, workboardTaskId);
            candidate.records.actionIntents.push(intent);
            persistedTask.currentProposal = { intentId: intent.id, revision: intent.revision, proposalDigest: intent.proposalDigest };
            persistedTask.currentApprovalId = null;
          },
        });
        return { intent: clone(intent), shadow: clone(decision.shadow) };
      });
    },
    switchActor({ context, actorId: nextActorId }) {
      assertContext(context);
      if (!Object.hasOwn(ACTOR_ROLES, nextActorId)) throw runtimeError("invalid_input", "unknown_actor");
      learningPreviews.clear();
      actorId = nextActorId;
      actorSessionRevision += 1;
      return Promise.resolve(clone(status()));
    },
    decideApproval({ context, workboardTaskId, decision }) {
      return enqueue(async () => {
        assertContext(context);
        assertRole("production");
        if (stopped) throw runtimeError("stopped", "runtime_stopped");
        const snapshot = await repository.loadFresh();
        const tuple = currentTuple(snapshot, workboardTaskId);
        const result = decideApprovalRecord({
          state: snapshot.current,
          intent: tuple.intent,
          decision,
          trusted: { approvalId: uuid(), actorId, now: clock() },
        }, sha256);
        if (result.status !== "recorded") throw runtimeError("approval_required", result.reason);
        await repository.transact({
          expectedRevision: snapshot.revision,
          event: event(uuid, clock, `production_priority_${decision}`, actorId, [
            { kind: "task", id: workboardTaskId }, { kind: "approval", id: result.approval.id },
          ]),
          mutate(candidate) {
            const task = findTask(candidate, workboardTaskId);
            candidate.records.approvals.push(result.approval);
            task.currentApprovalId = result.approval.id;
          },
        });
        return { approval: clone(result.approval) };
      });
    },
    revokeApproval({ context, workboardTaskId }) {
      return enqueue(async () => {
        assertContext(context);
        assertRole("production");
        const snapshot = await repository.loadFresh();
        const tuple = currentTuple(snapshot, workboardTaskId);
        if (!tuple.approval) throw runtimeError("approval_required", "current_approval_unavailable");
        const result = revokeApprovalRecord({ approval: tuple.approval, trusted: { actorId, now: clock() } });
        if (result.status !== "recorded") throw runtimeError("approval_required", result.reason);
        await repository.transact({
          expectedRevision: snapshot.revision,
          event: event(uuid, clock, "production_priority_revoked", actorId, [
            { kind: "task", id: workboardTaskId }, { kind: "approval", id: result.approval.id },
          ]),
          mutate(candidate) {
            const index = candidate.records.approvals.findIndex((approval) => approval.id === result.approval.id);
            candidate.records.approvalHistory.push(candidate.records.approvals[index]);
            candidate.records.approvals[index] = result.approval;
          },
        });
        return { approval: clone(result.approval) };
      });
    },
    execute({ context, workboardTaskId, approvalId }) {
      return enqueue(async () => {
        assertContext(context);
        const snapshot = await repository.loadFresh();
        const task = findTask(snapshot, workboardTaskId);
        if (task.executionId) {
          if (stopped || snapshot.stopped) {
            throw runtimeError("verification_required", "runtime_stopped", { committed: true });
          }
          const persistedExecution = snapshot.records.executions.find((candidate) => candidate.id === task.executionId);
          if (approvalId !== undefined && persistedExecution && approvalId !== persistedExecution.approvalId) {
            throw runtimeError("conflict", "approval_selector_mismatch");
          }
          return verifyAndComplete(workboardTaskId, task.executionId);
        }
        const tuple = currentTuple(snapshot, workboardTaskId);
        assertRole("production");
        if (stopped || snapshot.stopped) throw runtimeError("stopped", "runtime_stopped", { committed: false });
        if (!tuple.approval || tuple.task.currentApprovalId !== tuple.approval.id || (approvalId && approvalId !== tuple.approval.id)) {
          throw runtimeError("approval_required", "current_approval_unavailable");
        }
        const authorization = evaluateApprovalAuthorization({
          state: snapshot.current,
          intent: tuple.intent,
          approval: tuple.approval,
          persistedExecution: null,
          trusted: { actorId, now: clock() },
        }, sha256);
        if (authorization.status !== "apply_authorized") throw runtimeError("approval_required", authorization.reason);
        const targetRead = tuple.intent.readSet.find((reference) =>
          reference.kind === "production_plan" && reference.id === tuple.intent.targetPlanId);
        if (!targetRead) throw runtimeError("stale_context", "target_read_reference_missing");
        const execution = {
          id: uuid(), intentId: tuple.intent.id, approvalId: tuple.approval.id,
          idempotencyKey: `${snapshot.currentEpoch}:${tuple.intent.id}:${tuple.intent.proposalDigest}`,
          epoch: snapshot.currentEpoch, mode: "apply", state: "applied_pending_readback",
          before: { priority: tuple.intent.fromPriority, version: targetRead.version },
          expectedAfter: { priority: tuple.intent.toPriority, version: targetRead.version + 1 },
          attempt: 1, startedAt: clock(),
        };
        try {
          await repository.transact({
            expectedRevision: snapshot.revision,
            event: event(uuid, clock, "production_priority_applied", actorId, [
              { kind: "intent", id: tuple.intent.id }, { kind: "approval", id: tuple.approval.id },
              { kind: "execution", id: execution.id }, { kind: "production_plan", id: tuple.intent.targetPlanId },
            ]),
            mutate(candidate) {
              const current = currentTuple(candidate, workboardTaskId);
              if (current.intent.revision !== tuple.intent.revision
                || current.task.currentApprovalId !== tuple.approval.id
                || current.approval.consumedByExecutionId !== null) {
                throw runtimeError("conflict", "authorization_changed");
              }
              const plan = candidate.current.productionPlans.find((item) => item.id === tuple.intent.targetPlanId);
              plan.priority = tuple.intent.toPriority;
              plan.version += 1;
              current.approval.consumedByExecutionId = execution.id;
              candidate.records.executions.push(execution);
              current.task.executionId = execution.id;
              current.task.status = "in_progress";
            },
            beforeRename(candidate) {
              testHooks?.beforeApplyCommit?.();
              if (stopped || candidate.currentEpoch !== epoch) throw runtimeError("stopped", "stopped_before_commit", { committed: false });
            },
          });
        } catch (error) {
          if (error instanceof CompanyRuntimeError) throw error;
          if (error?.cause instanceof CompanyRuntimeError) throw error.cause;
          if (error?.committed) {
            try {
              stopped = true;
              await repository.verifyUncertain(snapshot.revision + 1);
              const recovered = await verifyAndComplete(workboardTaskId, execution.id);
              const verified = await repository.loadFresh();
              if (!verified.stopped) {
                await repository.transact({
                  expectedRevision: verified.revision,
                  event: event(uuid, clock, "runtime_stopped_after_uncertain_commit", actorId, [
                    { kind: "execution", id: execution.id },
                  ]),
                  mutate(candidate) { candidate.current.stopped = true; },
                });
              }
              return recovered;
            } catch (reconcileError) {
              throw runtimeError("verification_required", "commit_status_uncertain", {
                cause: reconcileError,
                committed: true,
              });
            }
          }
          throw error;
        }
        testHooks?.afterApplyCommit?.();
        return verifyAndComplete(workboardTaskId, execution.id);
      });
    },
    reconcile({ context, workboardTaskId }) {
      return enqueue(async () => {
        assertContext(context);
        const snapshot = await repository.loadFresh();
        const task = findTask(snapshot, workboardTaskId);
        if (!task.executionId) throw runtimeError("invalid_input", "no_execution_to_reconcile");
        if (stopped || snapshot.stopped) {
          throw runtimeError("verification_required", "runtime_stopped", { committed: true });
        }
        return verifyAndComplete(workboardTaskId, task.executionId);
      });
    },
    storeExperienceDraft({ context, workboardTaskId, draft }) {
      return enqueue(async () => {
        assertContext(context);
        const snapshot = await repository.loadFresh();
        const task = findTask(snapshot, workboardTaskId);
        if (task.epoch !== snapshot.currentEpoch) throw runtimeError("stale_context", "experience_task_not_current");
        if (draft?.authorActorId !== actorId) throw runtimeError("unauthorized_role", "experience_author_mismatch");
        const store = createExperienceDraftStore({
          sources: experienceSources(snapshot, task),
          initialDrafts: snapshot.records.experienceDrafts,
          now: clock,
          nextId: uuid,
        });
        const result = store.save(draft);
        if (!result.ok) throw runtimeError("invalid_input", result.code);
        await repository.transact({
          expectedRevision: snapshot.revision,
          event: event(uuid, clock, "experience_draft_saved", actorId, [
            { kind: "task", id: task.workboardTaskId }, { kind: "experience_draft", id: result.draft.id },
          ]),
          mutate(candidate) {
            candidate.records.experienceDrafts.push(result.draft);
          },
        });
        return clone(result.draft);
      });
    },
    previewLearning({ context, request }) {
      return enqueue(async () => {
        assertContext(context);
        const snapshot = await repository.loadFresh();
        const store = createLearningAssetStore({
          drafts: snapshot.records.experienceDrafts,
          assets: snapshot.records.learningAssets,
          withdrawals: snapshot.records.learningWithdrawals,
          suggestions: snapshot.records.learningSuggestions,
          now: clock,
          nextId: uuid,
          nextPreviewId: uuid,
        });
        const result = store.preview({ ...request, actorId });
        if (!result.ok) throw runtimeError(result.code === "author_required" ? "unauthorized_role" : "invalid_input", result.code);
        learningPreviews.set(result.preview.previewId, result.preview);
        return clone(result.preview);
      });
    },
    publishLearning({ context, preview, consentGranted }) {
      return enqueue(async () => {
        assertContext(context);
        const snapshot = await repository.loadFresh();
        const storedPreview = learningPreviews.get(preview?.previewId);
        const store = createLearningAssetStore({
          drafts: snapshot.records.experienceDrafts,
          assets: snapshot.records.learningAssets,
          withdrawals: snapshot.records.learningWithdrawals,
          suggestions: snapshot.records.learningSuggestions,
          previews: storedPreview ? [storedPreview] : [],
          now: clock,
          nextId: uuid,
          nextPreviewId: uuid,
        });
        const result = store.publish({ actorId, preview, consentGranted });
        if (!result.ok) throw runtimeError(result.code === "author_required" ? "unauthorized_role" : "invalid_input", result.code);
        await repository.transact({
          expectedRevision: snapshot.revision,
          event: event(uuid, clock, "learning_asset_published", actorId, [
            { kind: "learning_asset", id: result.asset.id }, { kind: "experience_draft", id: result.asset.sourceDraft.id },
          ]),
          mutate(candidate) { candidate.records.learningAssets.push(result.asset); },
        });
        learningPreviews.delete(preview.previewId);
        return clone(result.asset);
      });
    },
    withdrawLearning({ context, assetId, version }) {
      return enqueue(async () => {
        assertContext(context);
        const snapshot = await repository.loadFresh();
        const store = createLearningAssetStore({
          drafts: snapshot.records.experienceDrafts,
          assets: snapshot.records.learningAssets,
          withdrawals: snapshot.records.learningWithdrawals,
          suggestions: snapshot.records.learningSuggestions,
          now: clock,
          nextId: uuid,
          nextPreviewId: uuid,
        });
        const result = store.withdraw({ actorId, assetId, version });
        if (!result.ok) throw runtimeError(result.code === "author_required" ? "unauthorized_role" : "invalid_input", result.code);
        const lifecycle = store.snapshot();
        await repository.transact({
          expectedRevision: snapshot.revision,
          event: event(uuid, clock, "learning_asset_withdrawn", actorId, [{ kind: "learning_asset", id: assetId }]),
          mutate(candidate) {
            candidate.records.learningWithdrawals.push(result.withdrawal);
            candidate.records.learningSuggestions = lifecycle.suggestions;
          },
        });
        return clone(result.withdrawal);
      });
    },
    reviewReadiness({ context, orderId, targetPlanId, useLatestLearning = false }) {
      return enqueue(async () => {
        assertContext(context);
        assertRole("production");
        if (stopped) throw runtimeError("stopped", "runtime_stopped");
        const snapshot = await repository.loadFresh();
        const plan = snapshot.current.productionPlans.find((candidate) => candidate.id === targetPlanId);
        if (!plan || plan.orderId !== orderId) throw runtimeError("invalid_input", "invalid_readiness_target");
        const reuseSelection = useLatestLearning
          ? selectLearningReuse({
            assets: snapshot.records.learningAssets,
            withdrawals: snapshot.records.learningWithdrawals,
            target: {
              epoch: snapshot.currentEpoch,
              workType: "production_readiness",
              department: "production",
              materialGroup: plan.materialId,
            },
            currentRequiredChecks: [],
          })
          : null;
        const requiredChecks = reuseSelection?.kind === "selected" ? reuseSelection.requiredChecksToAdd : [];
        const assessment = reviewProductionReadiness({
          state: snapshot.current,
          orderId,
          planId: targetPlanId,
          requiredChecks,
        });
        if (assessment.status === "blocked") throw runtimeError("invalid_input", assessment.reason ?? "readiness_blocked");
        const workboardTaskId = uuid();
        const packetTaskId = uuid();
        const createdAt = clock();
        const packet = createProductionReadinessReviewPacket({
          packetTaskId,
          createdAt,
          requesterActorId: actorId,
          strategyRef: snapshot.current.activeStrategyRef,
        });
        const assessmentEvidence = {
          id: uuid(),
          epoch: snapshot.currentEpoch,
          packetTaskId,
          readSet: assessment.sources.map(({ kind, id, version }) => ({ kind, id, version })),
          baselineReadSet: assessment.baselineSources.map(({ kind, id, version }) => ({ kind, id, version })),
          additionalReadSet: assessment.additionalSources.map(({ kind, id, version }) => ({ kind, id, version })),
          requiredChecks: assessment.requiredChecks,
          usedAssetRef: reuseSelection?.kind === "selected" ? reuseSelection.candidate : null,
          reuse: reuseSelection === null
            ? { status: "baseline", code: null, lineageStatus: null, lineageRefs: [], candidateIds: [] }
            : reuseSelection.kind === "selected"
              ? {
                status: "selected",
                code: null,
                lineageStatus: reuseSelection.lineage.status,
                lineageRefs: reuseSelection.lineage.refs,
                candidateIds: [],
              }
              : reuseSelection.kind === "no_candidate"
                ? {
                  status: "no_candidate",
                  code: reuseSelection.code,
                  lineageStatus: reuseSelection.lineage.status,
                  lineageRefs: reuseSelection.lineage.refs,
                  candidateIds: [],
                }
                : {
                  status: "needs_review",
                  code: reuseSelection.code,
                  lineageStatus: null,
                  lineageRefs: [],
                  candidateIds: reuseSelection.kind === "needs_review" ? reuseSelection.candidateIds : [],
                },
          finding: assessment.status,
          reasons: [assessment.reason ?? assessment.status],
          mutationCount: 0,
          observedAt: createdAt,
        };
        const evidence = {
          evidence_id: uuid(), task_id: packetTaskId, created_at: createdAt,
          evidence_type: "risk_assessment", summary: `Read-only readiness review: ${assessment.status}.`,
          source: { system: "erp", ref: `company-runtime/${snapshot.currentEpoch}/assessment/${assessmentEvidence.id}` },
          status: "passed",
        };
        const completion = createTaskCompletionPreview({
          packet,
          evidence: [evidence],
          result_summary: "Read-only production readiness review completed.",
          result_details: "This verifies the assessment operation, not shipment readiness.",
          outcome: "passed_with_warnings",
        });
        if (!completion.can_complete) throw runtimeError("verification_required", "readiness_completion_gate_rejected");
        const record = runtimeTaskRecordSchema.parse({
          workboardTaskId, packetTaskId, epoch: snapshot.currentEpoch, packet: completion.packet,
          status: "done", currentProposal: null, currentApprovalId: null, executionId: null,
          businessOutcome: { packetTaskId, status: "unobserved", recordedByActorId: null, evidenceRefs: [], observedAt: null },
        });
        await repository.transact({
          expectedRevision: snapshot.revision,
          event: event(uuid, clock, "production_readiness_reviewed", actorId, [
            { kind: "task", id: workboardTaskId }, { kind: "assessment", id: assessmentEvidence.id },
          ]),
          mutate(candidate) {
            candidate.records.tasks.push(record);
            candidate.records.assessmentEvidence.push(assessmentEvidence);
          },
        });
        return { task: clone(record), assessment: clone(assessmentEvidence) };
      });
    },
    reviewStrategy({
      context,
      requestId,
      decision,
      baseStrategyRef,
      expectedBaseVersion,
      evidenceRefs,
      uncertainties,
      proposedChanges,
    }) {
      return enqueue(async () => {
        assertContext(context);
        assertRole("management");
        if (stopped) throw runtimeError("stopped", "runtime_stopped");
        const snapshot = await repository.loadFresh();
        const replay = replayStrategyReview({
          requestId,
          existingReviews: snapshot.records.strategyReviews,
          strategyVersions: snapshot.current.strategyVersions,
          decision,
          baseStrategyRef,
          expectedBaseVersion,
          evidenceRefs,
          uncertainties,
          proposedChanges,
          reviewerActorId: actorId,
        });
        if (replay.ok) return clone(replay);
        if (replay.code !== "not_found") {
          if (replay.code === "duplicate_request") throw runtimeError("conflict", "duplicate_strategy_review_request");
          if (replay.code === "management_role_required") throw runtimeError("unauthorized_role", "management_role_required");
          throw runtimeError("invalid_input", "invalid_strategy_review");
        }
        const evidenceSnapshot = resolveStrategyEvidence(snapshot, evidenceRefs);
        const result = decideStrategyReview({
          requestId,
          state: snapshot.current,
          existingReviews: snapshot.records.strategyReviews,
          decision,
          baseStrategyRef,
          expectedBaseVersion,
          evidenceSnapshot,
          uncertainties,
          proposedChanges,
          reviewerActorId: actorId,
          reviewedAt: clock(),
          nextStrategyVersionId: decision === "create_new_version" ? uuid() : null,
        }, sha256);
        if (!result.ok) {
          if (result.code === "stale_base") throw runtimeError("stale_context", "stale_strategy_base");
          if (result.code === "duplicate_request") throw runtimeError("conflict", "duplicate_strategy_review_request");
          if (result.code === "management_role_required") throw runtimeError("unauthorized_role", "management_role_required");
          throw runtimeError("invalid_input", "invalid_strategy_review");
        }
        if (result.idempotent) return clone(result);
        await repository.transact({
          expectedRevision: snapshot.revision,
          event: event(uuid, clock, "strategy_review_recorded", actorId, [
            { kind: "strategy_review", id: result.review.id },
            ...(result.version ? [{ kind: "strategy_version", id: result.version.strategy_version_id }] : []),
          ]),
          mutate(candidate) {
            candidate.records.strategyReviews.push(result.review);
            if (result.version) {
              candidate.current.strategyVersions.push(result.version);
            }
          },
        });
        return clone(result);
      });
    },
    adoptStrategy({ context, requestId, reviewId, expectedActiveRef }) {
      return enqueue(async () => {
        assertContext(context);
        assertRole("management");
        if (stopped) throw runtimeError("stopped", "runtime_stopped");
        const snapshot = await repository.loadFresh();
        const result = decideStrategyAdoption({
          state: snapshot.current,
          existingReviews: snapshot.records.strategyReviews,
          existingAdoptions: snapshot.records.strategyAdoptions,
          requestId,
          reviewId,
          expectedActiveRef,
          trusted: { actorId, epoch: snapshot.currentEpoch, adoptedAt: clock() },
        }, sha256);
        if (!result.ok) {
          if (result.code === "management_role_required") throw runtimeError("unauthorized_role", "management_role_required");
          if (["stale_context", "stale_base"].includes(result.code)) throw runtimeError("stale_context", "stale_strategy_base");
          if (result.code === "conflict") throw runtimeError("conflict", "duplicate_strategy_adoption_request");
          throw runtimeError("invalid_input", result.code);
        }
        if (result.idempotent) return clone(result);
        const review = snapshot.records.strategyReviews.find((candidate) => candidate.id === reviewId);
        if (review?.evidenceSnapshot.some((reference) => reference.kind === "learning"
          && snapshot.records.learningWithdrawals.some((withdrawal) =>
            withdrawal.assetId === reference.id && withdrawal.version === reference.version))) {
          throw runtimeError("invalid_input", "withdrawn_strategy_review_evidence");
        }
        await repository.transact({
          expectedRevision: snapshot.revision,
          event: event(uuid, clock, "strategy_adopted", actorId, [
            { kind: "strategy_adoption", id: result.adoption.id },
            { kind: "strategy_review", id: result.adoption.reviewId },
            { kind: "strategy_version", id: result.adoption.toRef.strategy_version_id },
          ]),
          mutate(candidate) {
            candidate.current.activeStrategyRef = result.activeStrategyRef;
            candidate.records.strategyAdoptions.push(result.adoption);
          },
        });
        return clone(result);
      });
    },
    stopLocalForTest() {
      if (isPackaged || process.env.BNC_TEST_MODE !== "1") throw new TypeError("test-only stop unavailable");
      stopped = true;
    },
    stop({ context }) {
      assertContext(context);
      stopped = true;
      return enqueue(async () => {
        const snapshot = await repository.loadFresh();
        if (snapshot.stopped) return status();
        await repository.transact({
          expectedRevision: snapshot.revision,
          event: event(uuid, clock, "runtime_stopped", actorId),
          mutate(candidate) { candidate.current.stopped = true; },
        });
        return status();
      });
    },
    resume({ context }) {
      return enqueue(async () => {
        assertContext(context);
        assertRole("production");
        const snapshot = await repository.loadFresh();
        await repository.transact({
          expectedRevision: snapshot.revision,
          event: event(uuid, clock, "runtime_resumed", actorId),
          mutate(candidate) { candidate.current.stopped = false; },
        });
        stopped = false;
        return status();
      });
    },
    reset({ context, confirmation }) {
      assertContext(context);
      if (!["production", "management"].includes(ACTOR_ROLES[actorId])) throw runtimeError("unauthorized_role", "reset_role_required");
      if (confirmation !== "RESET") throw runtimeError("invalid_input", "reset_confirmation_required");
      stopped = true;
      return enqueue(async () => {
        const snapshot = await repository.loadFresh();
        const nextEpoch = uuid();
        const strategyVersionId = uuid();
        const createdAt = clock();
        const strategyContent = {
          strategy_version_id: strategyVersionId,
          strategy_id: "STRATEGY-DEMO-PRODUCTION",
          version: 1,
          objective: "우선순위 변경 전 영향 주문을 확인",
          review_question: "우선순위 변경이 다른 주문과 검사·출하 준비에 미치는 영향은 무엇인가?",
          parent_version_id: null,
          execution_criteria: ["대상 주문·재고·생산계획 버전을 확인"],
          constraints: ["검사·출하 준비 미확인 상태에서 납기를 확약하지 않음"],
          created_by: "management-demo",
          created_at: createdAt,
          origin: "seed",
        };
        const nextState = createInitialCompanyState({
          epoch: nextEpoch,
          strategyVersionId,
          createdAt,
          strategyContentHash: sha256(canonicalSerialize(strategyContent)),
          stopped: true,
        });
        await repository.reset({
          expectedRevision: snapshot.revision,
          nextState,
          archivedAt: clock(),
          event: event(uuid, clock, "runtime_reset", actorId),
          beforeRename() {
            if (!stopped || epoch !== snapshot.currentEpoch) throw runtimeError("conflict", "reset_context_changed", { committed: false });
          },
        });
        epoch = nextEpoch;
        actorSessionRevision += 1;
        return status();
      });
    },
    close() {
      return enqueue(async () => {
        await repository.close();
        opened = false;
        epoch = null;
        stopped = true;
      });
    },
  };
  return api;
}
