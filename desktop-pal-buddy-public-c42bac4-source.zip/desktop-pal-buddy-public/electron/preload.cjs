const { contextBridge, ipcRenderer } = require("electron");

const dockStates = new Set([
  "idle",
  "hovered",
  "expanded",
  "listening",
  "thinking",
  "dispatching",
  "working",
  "needs_review",
  "alert",
  "completed",
  "error",
]);
const dockSurfaces = new Set(["ambient", "chat"]);
const workspaceModes = new Set([
  "home",
  "gateway",
  "meeting",
  "response",
  "search",
  "risk",
  "performance",
  "report",
  "tasks",
  "customers",
  "agents",
  "marketplace",
  "my-installations",
  "workflows",
  "agent-meeting",
  "alerts",
  "reports",
  "settings",
]);

contextBridge.exposeInMainWorld("desktop", {
  platform: process.platform,
  isElectron: true,
  getShellMode: () => ipcRenderer.invoke("shell:get-mode"),
  showCommandCenter: (initialMode) => {
    if (initialMode !== undefined && !workspaceModes.has(initialMode)) return;
    ipcRenderer.send("shell:show-workspace", { initialMode });
  },
  showDock: () => ipcRenderer.send("shell:show-dock"),
  syncDockState: (dockState) => {
    if (dockStates.has(dockState)) ipcRenderer.send("shell:update-dock-state", dockState);
  },
  syncDockSurface: (surface) => {
    if (dockSurfaces.has(surface)) ipcRenderer.send("shell:update-dock-surface", surface);
  },
  onUpdateDownloaded: (callback) => {
    const listener = () => callback();
    ipcRenderer.on("shell:update-downloaded", listener);
    return () => ipcRenderer.removeListener("shell:update-downloaded", listener);
  },
  onShellModeChange: (callback) => {
    const listener = (_event, mode) => callback(mode);
    ipcRenderer.on("shell:mode-changed", listener);
    return () => ipcRenderer.removeListener("shell:mode-changed", listener);
  },
});

contextBridge.exposeInMainWorld("companyRuntime", {
  bootstrap: (request) => ipcRenderer.invoke("company:bootstrap", request),
  read: (request) => ipcRenderer.invoke("company:read", request),
  submit: (request) => ipcRenderer.invoke("company:submit", request),
  approve: (request) => ipcRenderer.invoke("company:approve", request),
  execute: (request) => ipcRenderer.invoke("company:execute", request),
  explainResult: (request) => ipcRenderer.invoke("company:explain-result", request),
  role: (request) => ipcRenderer.invoke("company:role", request),
  stop: (request) => ipcRenderer.invoke("company:stop", request),
  resume: (request) => ipcRenderer.invoke("company:resume", request),
  reset: (request) => ipcRenderer.invoke("company:reset", request),
  cancel: (request) => ipcRenderer.invoke("company:cancel", request),
  reconcile: (request) => ipcRenderer.invoke("company:reconcile", request),
  experience: (request) => ipcRenderer.invoke("company:experience", request),
  learning: (request) => ipcRenderer.invoke("company:learning", request),
  reviewReadiness: (request) => ipcRenderer.invoke("company:review-readiness", request),
  reviewStrategy: (request) => ipcRenderer.invoke("company:review-strategy", request),
  adoptStrategy: (request) => ipcRenderer.invoke("company:adopt-strategy", request),
  refreshAiConnection: (request) => ipcRenderer.invoke("company:refresh-ai-connection", request),
  onUpdate: (callback) => {
    const listener = (_event, response) => callback(response);
    ipcRenderer.on("company:updated", listener);
    return () => ipcRenderer.removeListener("company:updated", listener);
  },
});
