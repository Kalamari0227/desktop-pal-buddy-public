import fs from "node:fs";
import path from "node:path";
import { randomUUID } from "node:crypto";
import { z } from "zod";
import {
  actionIntentSchema,
  actorIdSchema,
  approvalSchema,
  assessmentEvidenceSchema,
  businessOutcomeSchema,
  companyStateSchema,
  executionSchema,
  experienceDraftSchema,
  learningAssetVersionSchema,
  learningSuggestionSchema,
  learningWithdrawalSchema,
  learningAssetSchema,
  readbackEvidenceSchema,
  runtimeTaskRecordSchema,
  strategyAdoptionSchema,
  strategyReviewSchema,
} from "../dist-runtime/domain.mjs";

const SNAPSHOT_FORMAT_VERSION = 1;

const auditEventSchema = z.object({
  id: z.string().uuid(),
  type: z.string().trim().min(1),
  epoch: z.string().uuid(),
  revision: z.number().int().positive(),
  actorId: actorIdSchema.nullable(),
  occurredAt: z.string().datetime(),
  refs: z.array(z.object({ kind: z.string().trim().min(1), id: z.string().trim().min(1) }).strict()),
}).strict();

const auditEventInputSchema = auditEventSchema.omit({ epoch: true, revision: true });

const runtimeRecordsSchema = z.object({
  tasks: z.array(runtimeTaskRecordSchema),
  actionIntents: z.array(actionIntentSchema),
  approvals: z.array(approvalSchema),
  approvalHistory: z.array(approvalSchema),
  executions: z.array(executionSchema),
  readbackEvidence: z.array(readbackEvidenceSchema),
  assessmentEvidence: z.array(assessmentEvidenceSchema),
  businessOutcomes: z.array(businessOutcomeSchema),
  learningAssets: z.array(z.union([learningAssetSchema, learningAssetVersionSchema])),
  learningWithdrawals: z.array(learningWithdrawalSchema).default([]),
  learningSuggestions: z.array(learningSuggestionSchema).default([]),
  strategyReviews: z.array(strategyReviewSchema),
  strategyAdoptions: z.array(strategyAdoptionSchema).default([]),
  experienceDrafts: z.array(experienceDraftSchema).default([]),
  events: z.array(auditEventSchema),
}).strict().superRefine((records, context) => {
  const intentKeys = records.actionIntents.map((intent) => `${intent.id}:${intent.revision}`);
  if (new Set(intentKeys).size !== intentKeys.length) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "duplicate action intent revision" });
  }
  for (const collection of [records.tasks.map((task) => ({ id: task.workboardTaskId })), records.approvals, records.executions]) {
    if (!hasUniqueIds(collection)) context.addIssue({ code: z.ZodIssueCode.custom, message: "duplicate runtime record identity" });
  }
  if (!hasUniqueIds(records.experienceDrafts)) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "duplicate experience draft identity" });
  }
  const learningVersionKeys = records.learningAssets.map((asset) => `${asset.id}:${asset.version}`);
  if (new Set(learningVersionKeys).size !== learningVersionKeys.length) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "duplicate learning asset version" });
  }
  if (!hasUniqueIds(records.learningWithdrawals) || !hasUniqueIds(records.learningSuggestions)) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "duplicate learning lifecycle identity" });
  }
  if (!hasUniqueIds(records.strategyAdoptions)) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "duplicate strategy adoption identity" });
  }
  for (const task of records.tasks) {
    if (task.currentProposal && !records.actionIntents.some((intent) =>
      intent.id === task.currentProposal.intentId
      && intent.revision === task.currentProposal.revision
      && intent.proposalDigest === task.currentProposal.proposalDigest)) {
      context.addIssue({ code: z.ZodIssueCode.custom, message: "task current proposal is not stored" });
    }
    if (task.currentApprovalId && !records.approvals.some((approval) => approval.id === task.currentApprovalId)) {
      context.addIssue({ code: z.ZodIssueCode.custom, message: "task current approval is not stored" });
    }
    if (task.executionId && !records.executions.some((execution) => execution.id === task.executionId)) {
      context.addIssue({ code: z.ZodIssueCode.custom, message: "task execution is not stored" });
    }
  }
});

const epochArchiveSchema = z.object({
  epoch: z.string().uuid(),
  archivedAt: z.string().datetime(),
  finalRevision: z.number().int().nonnegative(),
  current: companyStateSchema,
  records: runtimeRecordsSchema,
}).strict().superRefine((archive, context) => {
  if (archive.epoch !== archive.current.currentEpoch) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "archive epoch must match its state" });
  }
});

const companySnapshotSchema = z.object({
  formatVersion: z.literal(SNAPSHOT_FORMAT_VERSION),
  revision: z.number().int().nonnegative(),
  currentEpoch: z.string().uuid(),
  stopped: z.boolean(),
  current: companyStateSchema,
  records: runtimeRecordsSchema,
  history: z.array(epochArchiveSchema),
}).strict().superRefine((snapshot, context) => {
  if (snapshot.revision !== snapshot.current.revision) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "snapshot and current revisions must match" });
  }
  if (snapshot.currentEpoch !== snapshot.current.currentEpoch) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "snapshot and current epochs must match" });
  }
  if (snapshot.stopped !== snapshot.current.stopped) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "snapshot and current stopped state must match" });
  }
  const epochs = [snapshot.currentEpoch, ...snapshot.history.map((entry) => entry.epoch)];
  if (new Set(epochs).size !== epochs.length) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "epochs must be unique" });
  }
});

function emptyRecords() {
  return {
    tasks: [],
    actionIntents: [],
    approvals: [],
    approvalHistory: [],
    executions: [],
    readbackEvidence: [],
    assessmentEvidence: [],
    businessOutcomes: [],
    learningAssets: [],
    learningWithdrawals: [],
    learningSuggestions: [],
    strategyReviews: [],
    strategyAdoptions: [],
    experienceDrafts: [],
    events: [],
  };
}

function clone(value) {
  return structuredClone(value);
}

function parseSnapshot(value) {
  return companySnapshotSchema.parse(value);
}

function parseAuditEvent(value) {
  try {
    return auditEventInputSchema.parse(value);
  } catch (error) {
    throw new CompanyPersistenceError("invalid_input", "invalid_audit_event", { cause: error, committed: false });
  }
}

function serialize(snapshot) {
  return `${JSON.stringify(snapshot, null, 2)}\n`;
}

function atomicReplace(snapshotPath, snapshot, { faults = {}, beforeRename } = {}) {
  fs.mkdirSync(path.dirname(snapshotPath), { recursive: true });
  const tempPath = path.join(path.dirname(snapshotPath), `.${path.basename(snapshotPath)}.${process.pid}.${randomUUID()}.tmp`);
  let handle;
  let committed = false;
  let stage = "temp_write";
  try {
    faults.temp_write?.();
    handle = fs.openSync(tempPath, "wx", 0o600);
    fs.writeFileSync(handle, serialize(snapshot), "utf8");
    stage = "file_sync";
    faults.file_sync?.();
    fs.fsyncSync(handle);
    fs.closeSync(handle);
    handle = undefined;
    stage = "before_rename";
    if (beforeRename !== undefined) {
      if (typeof beforeRename !== "function") throw new TypeError("beforeRename must be synchronous function");
      const result = beforeRename(clone(snapshot));
      if (result && typeof result.then === "function") throw new TypeError("beforeRename must be synchronous");
    }
    stage = "rename";
    faults.rename?.();
    fs.renameSync(tempPath, snapshotPath);
    committed = true;
    stage = "after_rename";
    faults.after_rename?.();
    const directory = fs.openSync(path.dirname(snapshotPath), "r");
    try {
      stage = "dir_sync";
      faults.dir_sync?.();
      fs.fsyncSync(directory);
    } finally {
      fs.closeSync(directory);
    }
  } catch (error) {
    if (error instanceof CompanyPersistenceError) throw error;
    throw new CompanyPersistenceError(
      committed ? "verification_required" : "persistence_failed",
      stage,
      { cause: error, committed },
    );
  } finally {
    if (handle !== undefined) fs.closeSync(handle);
    if (fs.existsSync(tempPath)) fs.rmSync(tempPath);
  }
}

function readSnapshot(snapshotPath) {
  let decoded;
  try {
    decoded = JSON.parse(fs.readFileSync(snapshotPath, "utf8"));
  } catch (error) {
    throw new CompanyPersistenceError("persistence_failed", "corrupt_snapshot", { cause: error });
  }
  if (decoded?.formatVersion !== SNAPSHOT_FORMAT_VERSION) {
    throw new CompanyPersistenceError("persistence_failed", "unsupported_format", {
      formatVersion: decoded?.formatVersion,
    });
  }
  try {
    return parseSnapshot(decoded);
  } catch (error) {
    throw new CompanyPersistenceError("persistence_failed", "corrupt_snapshot", { cause: error });
  }
}

export class CompanyPersistenceError extends Error {
  constructor(code, reason, details = {}) {
    super(`${code}: ${reason}`, details.cause ? { cause: details.cause } : undefined);
    this.name = "CompanyPersistenceError";
    this.code = code;
    this.reason = reason;
    Object.assign(this, details);
  }
}

function plansChanged(previous, next) {
  return JSON.stringify(previous.current.productionPlans) !== JSON.stringify(next.current.productionPlans);
}

function sameValue(left, right) {
  return JSON.stringify(left) === JSON.stringify(right);
}

function hasUniqueIds(records) {
  return new Set(records.map((record) => record.id)).size === records.length;
}

function hasUniqueIntentRevisions(records) {
  return new Set(records.map((record) => `${record.id}:${record.revision}`)).size === records.length;
}

function hasExactEventRef(event, kind, id) {
  return event.refs.filter((ref) => ref.kind === kind && ref.id === id).length === 1;
}

function approvalWithoutConsumption(approval) {
  const { consumedByExecutionId: _consumedByExecutionId, ...scope } = approval;
  return scope;
}

const IMMUTABLE_ERP_COLLECTIONS = [
  "customers",
  "salesOpportunities",
  "quotes",
  "salesOrders",
  "inventory",
  "inspections",
  "shipments",
  "skills",
  "bootstrapReadSet",
];

function immutableErpStatePreserved(previous, next) {
  return previous.current.bootstrap === next.current.bootstrap
    && IMMUTABLE_ERP_COLLECTIONS.every((key) => sameValue(previous.current[key], next.current[key]));
}

function assertMutationBoundary(previous, next, event) {
  if (!immutableErpStatePreserved(previous, next)) {
    throw new CompanyPersistenceError("invalid_input", "mutation_boundary_missing", { committed: false });
  }
  const activeChanged = !sameValue(previous.current.activeStrategyRef, next.current.activeStrategyRef);
  const adoptionDelta = next.records.strategyAdoptions.length - previous.records.strategyAdoptions.length;
  const priorAdoptionsPreserved = sameValue(
    next.records.strategyAdoptions.slice(0, previous.records.strategyAdoptions.length),
    previous.records.strategyAdoptions,
  );
  const adoption = next.records.strategyAdoptions.length === previous.records.strategyAdoptions.length + 1
    ? next.records.strategyAdoptions.at(-1)
    : null;
  const strategyVersionsPreserved = sameValue(
    next.current.strategyVersions.slice(0, previous.current.strategyVersions.length),
    previous.current.strategyVersions,
  );
  if (!priorAdoptionsPreserved
    || !strategyVersionsPreserved
    || adoptionDelta !== (activeChanged ? 1 : 0)
    || (activeChanged && (!adoption
      || event.type !== "strategy_adopted"
      || adoption.epoch !== previous.currentEpoch
      || adoption.actorId !== "management-demo"
      || !sameValue(adoption.fromRef, previous.current.activeStrategyRef)
      || !sameValue(adoption.toRef, next.current.activeStrategyRef)
      || !next.current.strategyVersions.some((version) => sameValue({
        strategy_id: version.strategy_id,
        strategy_version_id: version.strategy_version_id,
      }, adoption.toRef))
      || !next.records.strategyReviews.some((review) => review.id === adoption.reviewId
        && review.epoch === adoption.epoch
        && review.decision === "create_new_version"
        && sameValue(review.baseStrategyRef, adoption.fromRef)
        && sameValue(review.resultingStrategyRef, adoption.toRef))
      || !hasExactEventRef(event, "strategy_adoption", adoption.id)
      || !hasExactEventRef(event, "strategy_review", adoption.reviewId)
      || !hasExactEventRef(event, "strategy_version", adoption.toRef.strategy_version_id)))
    || (!activeChanged && adoption)) {
    throw new CompanyPersistenceError("invalid_input", "mutation_boundary_missing", { committed: false });
  }
  if (!plansChanged(previous, next)) return;
  const plansIdentityPreserved = previous.current.productionPlans.length === next.current.productionPlans.length
    && previous.current.productionPlans.every((oldPlan, index) => next.current.productionPlans[index]?.id === oldPlan.id);
  const changedPlans = plansIdentityPreserved
    ? previous.current.productionPlans.filter((oldPlan, index) => !sameValue(oldPlan, next.current.productionPlans[index]))
    : [];
  const recordsHaveUniqueIds = hasUniqueIntentRevisions(next.records.actionIntents)
    && [next.records.approvals, next.records.executions].every(hasUniqueIds);
  const priorExecutionsPreserved = sameValue(
    next.records.executions.slice(0, previous.records.executions.length),
    previous.records.executions,
  );
  const execution = next.records.executions.length === previous.records.executions.length + 1
    ? next.records.executions.at(-1)
    : null;
  const approval = execution && next.records.approvals.find((candidate) => candidate.id === execution.approvalId);
  const intent = execution && approval && next.records.actionIntents.find((candidate) =>
    candidate.id === execution.intentId
    && candidate.revision === approval.intentRevision
    && candidate.epoch === execution.epoch);
  const priorIntent = intent && previous.records.actionIntents.find((candidate) =>
    candidate.id === intent.id && candidate.revision === intent.revision);
  const priorIntentsPreserved = previous.records.actionIntents.every((prior, index) =>
    sameValue(next.records.actionIntents[index], prior));
  const priorApproval = approval && previous.records.approvals.find((candidate) => candidate.id === approval.id);
  const priorApprovalsPreserved = previous.records.approvals.every((prior, index) => {
    const candidate = next.records.approvals[index];
    if (!candidate || candidate.id !== prior.id) return false;
    if (approval && prior.id === approval.id) {
      return prior.consumedByExecutionId === null
        && candidate.consumedByExecutionId === execution.id
        && sameValue(approvalWithoutConsumption(candidate), approvalWithoutConsumption(prior));
    }
    return sameValue(candidate, prior);
  });
  const oldPlan = execution && intent && previous.current.productionPlans.find((candidate) =>
    candidate.id === intent.targetPlanId
    && candidate.priority === execution.before.priority
    && candidate.version === execution.before.version);
  const newPlan = oldPlan && next.current.productionPlans.find((candidate) =>
    candidate.id === oldPlan.id
    && candidate.priority === execution.expectedAfter.priority
    && candidate.version === execution.expectedAfter.version);
  const unchangedPlanFields = oldPlan && newPlan && Object.entries(oldPlan).every(([key, value]) =>
    key === "priority" || key === "version" || JSON.stringify(newPlan[key]) === JSON.stringify(value));
  const targetReadRefs = intent?.readSet.filter((ref) =>
    ref.kind === "production_plan" && ref.id === intent.targetPlanId) ?? [];
  const expectedIdempotencyKey = execution && intent
    ? `${execution.epoch}:${intent.id}:${intent.proposalDigest}`
    : null;
  if (!recordsHaveUniqueIds || !priorExecutionsPreserved || !priorIntentsPreserved || !priorApprovalsPreserved
      || !execution || !approval || !intent
      || (priorIntent && !sameValue(priorIntent, intent))
      || (priorApproval && priorApproval.consumedByExecutionId !== null)
      || approval.intentId !== intent.id || execution.intentId !== intent.id
      || approval.intentRevision !== intent.revision
      || approval.proposalDigest !== intent.proposalDigest
      || approval.policyVersion !== intent.policyVersion
      || !sameValue(approval.skillRef, intent.skillRef)
      || !sameValue(approval.strategyRef, intent.strategyRef)
      || approval.requesterActorId !== intent.requesterActorId
      || intent.epoch !== previous.currentEpoch || approval.epoch !== intent.epoch || execution.epoch !== intent.epoch
      || execution.mode !== "apply" || execution.state !== "applied_pending_readback"
      || execution.idempotencyKey !== expectedIdempotencyKey
      || approval.decision !== "approved" || approval.consumedByExecutionId !== execution.id
      || !oldPlan || !newPlan
      || !plansIdentityPreserved
      || oldPlan.priority === newPlan.priority
      || intent.fromPriority !== oldPlan.priority || intent.toPriority !== newPlan.priority
      || newPlan.version !== oldPlan.version + 1
      || targetReadRefs.length !== 1 || targetReadRefs[0].version !== oldPlan.version
      || changedPlans.length !== 1 || changedPlans[0].id !== intent.targetPlanId
      || !unchangedPlanFields
      || event.type !== "production_priority_applied"
      || !hasExactEventRef(event, "intent", intent.id)
      || !hasExactEventRef(event, "approval", approval.id)
      || !hasExactEventRef(event, "execution", execution.id)
      || !hasExactEventRef(event, "production_plan", intent.targetPlanId)) {
    throw new CompanyPersistenceError("invalid_input", "mutation_boundary_missing", { committed: false });
  }
}

export function createCompanyPersistence({ rootDir, bootstrap, isPackaged = true, faults = undefined }) {
  if (!path.isAbsolute(rootDir)) throw new TypeError("rootDir must be absolute");
  if (typeof bootstrap !== "function") throw new TypeError("bootstrap must be a function");
  if (faults !== undefined) {
    if (isPackaged || process.env.BNC_TEST_MODE !== "1") {
      throw new TypeError("test-only fault injection requires BNC_TEST_MODE=1 in a nonpackaged process");
    }
    const allowedFaults = new Set(["temp_write", "file_sync", "rename", "after_rename", "dir_sync"]);
    for (const [name, fault] of Object.entries(faults)) {
      if (!allowedFaults.has(name) || typeof fault !== "function") throw new TypeError(`invalid fault injection: ${name}`);
    }
  }
  const snapshotPath = path.join(rootDir, "company-runtime", "snapshot.json");
  let current = null;
  let uncertainRevision = null;
  let queue = Promise.resolve();

  function enqueue(operation) {
    const result = queue.then(operation);
    queue = result.catch(() => undefined);
    return result;
  }

  async function ensureOpen() {
    if (current) return current;
    if (fs.existsSync(snapshotPath)) {
      current = readSnapshot(snapshotPath);
    } else {
      const state = companyStateSchema.parse(await bootstrap());
      current = parseSnapshot({
        formatVersion: SNAPSHOT_FORMAT_VERSION,
        revision: state.revision,
        currentEpoch: state.currentEpoch,
        stopped: state.stopped,
        current: state,
        records: emptyRecords(),
        history: [],
      });
      try {
        atomicReplace(snapshotPath, current, { faults });
      } catch (error) {
        current = null;
        throw error;
      }
    }
    return current;
  }

  function assertWritable(expectedRevision) {
    if (uncertainRevision !== null) {
      throw new CompanyPersistenceError("verification_required", "uncertain_commit", {
        committed: true,
        uncertainRevision,
      });
    }
    if (expectedRevision !== undefined && expectedRevision !== current.revision) {
      throw new CompanyPersistenceError("conflict", "stale_revision", {
        committed: false,
        expectedRevision,
        actualRevision: current.revision,
      });
    }
  }

  function persistCandidate(candidate, beforeRename) {
    try {
      atomicReplace(snapshotPath, candidate, { faults, beforeRename });
      current = candidate;
      return clone(current);
    } catch (error) {
      if (error instanceof CompanyPersistenceError && error.committed) {
        let persistedSnapshot = null;
        try {
          persistedSnapshot = readSnapshot(snapshotPath);
          current = persistedSnapshot;
          uncertainRevision = persistedSnapshot.revision;
        } catch {
          uncertainRevision = candidate.revision;
        }
        throw new CompanyPersistenceError("verification_required", error.reason, {
          cause: error,
          committed: true,
          persistedSnapshot: persistedSnapshot ? clone(persistedSnapshot) : null,
        });
      }
      throw error;
    }
  }

  return {
    snapshotPath,
    open() {
      return enqueue(async () => clone(await ensureOpen()));
    },
    loadFresh() {
      return enqueue(async () => {
        await ensureOpen();
        current = readSnapshot(snapshotPath);
        return clone(current);
      });
    },
    transact({ expectedRevision, event, mutate, beforeRename } = {}) {
      return enqueue(async () => {
        await ensureOpen();
        assertWritable(expectedRevision);
        if (!event) throw new CompanyPersistenceError("invalid_input", "audit_event_required", { committed: false });
        if (typeof mutate !== "function") throw new CompanyPersistenceError("invalid_input", "mutation_callback_required", { committed: false });
        const parsedEvent = parseAuditEvent(event);
        const previous = current;
        if (previous.records.events.some((stored) => stored.id === parsedEvent.id)) {
          throw new CompanyPersistenceError("conflict", "duplicate_audit_event", { committed: false });
        }
        const candidate = clone(previous);
        const priorEvents = JSON.stringify(previous.records.events);
        const priorHistory = JSON.stringify(previous.history);
        const result = mutate(candidate);
        if (result && typeof result.then === "function") {
          throw new CompanyPersistenceError("invalid_input", "mutation_callback_must_be_synchronous", { committed: false });
        }
        if (JSON.stringify(candidate.records.events) !== priorEvents || JSON.stringify(candidate.history) !== priorHistory) {
          throw new CompanyPersistenceError("invalid_input", "immutable_snapshot_section_changed", { committed: false });
        }
        if (candidate.current.currentEpoch !== previous.currentEpoch) {
          throw new CompanyPersistenceError("invalid_input", "epoch_change_requires_reset", { committed: false });
        }
        const revision = previous.revision + 1;
        candidate.formatVersion = SNAPSHOT_FORMAT_VERSION;
        candidate.revision = revision;
        candidate.currentEpoch = candidate.current.currentEpoch;
        candidate.stopped = candidate.current.stopped;
        candidate.current.revision = revision;
        const storedEvent = { ...parsedEvent, epoch: candidate.currentEpoch, revision };
        assertMutationBoundary(previous, candidate, storedEvent);
        candidate.records.events.push(storedEvent);
        let validated;
        try {
          validated = parseSnapshot(candidate);
        } catch (error) {
          throw new CompanyPersistenceError("invalid_input", "invalid_snapshot", { cause: error, committed: false });
        }
        return persistCandidate(validated, beforeRename);
      });
    },
    reset({ expectedRevision, nextState, archivedAt, event, beforeRename } = {}) {
      return enqueue(async () => {
        await ensureOpen();
        assertWritable(expectedRevision);
        if (!event) throw new CompanyPersistenceError("invalid_input", "audit_event_required", { committed: false });
        const parsedEvent = parseAuditEvent(event);
        const parsedNextState = companyStateSchema.parse(nextState);
        if (!parsedNextState.stopped) throw new CompanyPersistenceError("invalid_input", "reset_must_start_stopped", { committed: false });
        if (parsedNextState.currentEpoch === current.currentEpoch) {
          throw new CompanyPersistenceError("invalid_input", "reset_requires_new_epoch", { committed: false });
        }
        const archiveTime = z.string().datetime().parse(archivedAt);
        const revision = current.revision + 1;
        parsedNextState.revision = revision;
        const records = emptyRecords();
        records.events.push({ ...parsedEvent, epoch: parsedNextState.currentEpoch, revision });
        const candidate = parseSnapshot({
          formatVersion: SNAPSHOT_FORMAT_VERSION,
          revision,
          currentEpoch: parsedNextState.currentEpoch,
          stopped: true,
          current: parsedNextState,
          records,
          history: [
            ...current.history,
            {
              epoch: current.currentEpoch,
              archivedAt: archiveTime,
              finalRevision: current.revision,
              current: current.current,
              records: current.records,
            },
          ],
        });
        return persistCandidate(candidate, beforeRename);
      });
    },
    verifyUncertain(expectedRevision) {
      return enqueue(async () => {
        if (uncertainRevision === null) {
          throw new CompanyPersistenceError("invalid_input", "no_uncertain_commit", { committed: false });
        }
        const persisted = readSnapshot(snapshotPath);
        if (persisted.revision !== expectedRevision || persisted.revision !== uncertainRevision) {
          throw new CompanyPersistenceError("verification_required", "revision_mismatch", {
            committed: true,
            expectedRevision,
            actualRevision: persisted.revision,
          });
        }
        current = persisted;
        uncertainRevision = null;
        return clone(persisted);
      });
    },
    close() {
      return enqueue(async () => {
        current = null;
      });
    },
  };
}

export { companySnapshotSchema };
