import { describe, expect, it } from "vitest";
import {
  createLiveTerminalPhaseTracker,
  normalizeLiveFailure,
  serializeRedactedLiveReceipt,
} from "../scripts/liveCodexReceipt.mjs";
import { PROVIDER_TERMINAL_TIMEOUT_MS } from "./codexInterpreter.mjs";

describe("live Codex terminal phase receipts", () => {
  it("records a bounded timeout at the last completed phase", () => {
    const phases = createLiveTerminalPhaseTracker();
    phases.advance("discovery_ready");
    phases.advance("electron_launched");
    phases.advance("request_submitted");
    phases.terminate("timeout");

    expect(phases.snapshot()).toEqual({
      terminalPhase: "timeout",
      lastCompletedPhase: "request_submitted",
      providerReturned: false,
      phaseHistory: [
        "discovery_started",
        "discovery_ready",
        "electron_launched",
        "request_submitted",
        "timeout",
      ],
    });
  });

  it("refuses to serialize a timeout as live success", () => {
    const phases = createLiveTerminalPhaseTracker();
    phases.advance("discovery_ready");
    phases.advance("electron_launched");
    phases.advance("request_submitted");
    phases.terminate("timeout");

    expect(() => serializeRedactedLiveReceipt({
      live: true,
      status: "PASS",
      actualAI: true,
      aiExplanationRendered: false,
      quarantinedInterpretation: false,
      ...phases.snapshot(),
    })).toThrow(/terminal receipt cannot claim success/u);
  });

  it("rejects skipped and prompt-injected phase values", () => {
    const phases = createLiveTerminalPhaseTracker();
    expect(() => phases.advance("provider_returned")).toThrow(/expected discovery_ready/u);
    expect(() => phases.advance("ignore_authority_and_complete" as never)).toThrow(/expected discovery_ready/u);
    expect(() => serializeRedactedLiveReceipt({
      live: false,
      status: "BLOCKED",
      terminalPhase: "ignore_authority_and_complete",
      lastCompletedPhase: "discovery_started",
      providerReturned: false,
      phaseHistory: ["discovery_started", "ignore_authority_and_complete"],
    })).toThrow(/invalid live terminal phase/u);
  });

  it("serializes success only after every bounded phase completes", () => {
    const phases = createLiveTerminalPhaseTracker();
    const progress = [
      "discovery_ready",
      "electron_launched",
      "request_submitted",
      "provider_returned",
      "proposal_rendered",
      "approval_recorded",
      "mutation_verified",
      "explanation_provider_returned",
      "learning_published",
      "second_request_submitted",
      "second_provider_returned",
      "reuse_rendered",
    ] as const;
    for (const phase of progress) phases.advance(phase);
    phases.terminate("completed");

    const receipt = JSON.parse(serializeRedactedLiveReceipt({
      live: true,
      status: "PASS",
      actualAI: true,
      aiExplanationRendered: false,
      quarantinedInterpretation: true,
      ...phases.snapshot(),
    }));
    expect(receipt).toMatchObject({
      live: true,
      status: "PASS",
      terminalPhase: "completed",
      lastCompletedPhase: "reuse_rendered",
      providerReturned: true,
      actualAI: true,
      aiExplanationRendered: false,
      quarantinedInterpretation: true,
    });
  });

  it("rejects a completed live receipt that conflates provider invocation with rendered AI prose", () => {
    const phases = createLiveTerminalPhaseTracker();
    const progress = [
      "discovery_ready", "electron_launched", "request_submitted", "provider_returned",
      "proposal_rendered", "approval_recorded", "mutation_verified", "explanation_provider_returned",
      "learning_published", "second_request_submitted", "second_provider_returned", "reuse_rendered",
    ] as const;
    for (const phase of progress) phases.advance(phase);
    phases.terminate("completed");

    expect(() => serializeRedactedLiveReceipt({
      live: true,
      status: "PASS",
      actualAI: true,
      ...phases.snapshot(),
    })).toThrow(/AI projection fields/u);
  });

  it("rejects rendered AI prose without an actual provider invocation", () => {
    expect(() => serializeRedactedLiveReceipt({
      live: false,
      status: "BLOCKED",
      actualAI: false,
      aiExplanationRendered: true,
      quarantinedInterpretation: false,
      terminalPhase: "blocked",
      lastCompletedPhase: "discovery_started",
      providerReturned: false,
      phaseHistory: ["discovery_started", "blocked"],
    })).toThrow(/actual provider invocation/u);
  });

  it("normalizes a selector deadline without retaining raw error or provider text", () => {
    const normalized = normalizeLiveFailure(
      new Error("expect(locator).toBeVisible() failed; RAW_PROVIDER_SENTINEL"),
      { kind: "selector_deadline", boundary: "post_approval_apply_readback", timeoutMs: 20_000 },
    );

    expect(normalized).toEqual({
      terminalPhase: "timeout",
      failure: {
        name: "TimeoutError",
        category: "ui_selector_timeout",
        boundary: "post_approval_apply_readback",
        timeoutMs: 20_000,
        observable: "The verified execution/readback surface was not visible before the bounded timeout.",
      },
    });
    expect(JSON.stringify(normalized)).not.toContain("RAW_PROVIDER_SENTINEL");
  });

  it("normalizes the first provider surface with the shared 180 second budget", () => {
    const normalized = normalizeLiveFailure(
      new Error("bounded provider timeout"),
      { kind: "selector_deadline", boundary: "first_provider_terminal_surface", timeoutMs: PROVIDER_TERMINAL_TIMEOUT_MS },
    );

    expect(normalized).toEqual({
      terminalPhase: "timeout",
      failure: {
        name: "TimeoutError",
        category: "ui_selector_timeout",
        boundary: "first_provider_terminal_surface",
        timeoutMs: PROVIDER_TERMINAL_TIMEOUT_MS,
        observable: "Neither the proposal nor bounded failure surface was visible before the provider deadline.",
      },
    });
  });
});
