import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { createHash, randomUUID } from "node:crypto";
import { afterAll, afterEach, beforeAll, describe, expect, it } from "vitest";
import { createInitialCompanyState } from "../dist-runtime/domain.mjs";
import { createCompanyPersistence } from "./companyPersistence.mjs";

const tempDirs: string[] = [];
const previousTestMode = process.env.BNC_TEST_MODE;

function makeTempRoot() {
  const rootDir = fs.mkdtempSync(path.join(os.tmpdir(), "company-persistence-"));
  tempDirs.push(rootDir);
  return rootDir;
}

function makeState(epoch = randomUUID()) {
  return createInitialCompanyState({
    epoch,
    strategyVersionId: randomUUID(),
    createdAt: "2026-09-19T00:00:00.000Z",
    strategyContentHash: "a".repeat(64),
  });
}

function event(type = "state_changed") {
  return {
    id: randomUUID(),
    type,
    actorId: "production-demo",
    occurredAt: "2026-09-19T00:00:01.000Z",
    refs: [],
  };
}

function sha256(filePath: string) {
  return createHash("sha256").update(fs.readFileSync(filePath)).digest("hex");
}

async function persistApprovedProposal(repository, { consumedByExecutionId = null } = {}) {
  const opened = await repository.open();
  const tuple = {
    intentId: randomUUID(),
    approvalId: randomUUID(),
    executionId: randomUUID(),
    digest: "b".repeat(64),
    readSetDigest: "c".repeat(64),
    strategyRef: opened.current.activeStrategyRef,
  };
  await repository.transact({
    event: event("production_priority_approved"),
    mutate(snapshot) {
      snapshot.records.actionIntents.push({
        id: tuple.intentId,
        revision: 1,
        workboardTaskId: randomUUID(),
        packetTaskId: randomUUID(),
        epoch: snapshot.currentEpoch,
        targetPlanId: "PP-DEMO-1001",
        fromPriority: 5,
        toPriority: 1,
        readSet: [{ kind: "production_plan", id: "PP-DEMO-1001", version: 1 }],
        strategyRef: tuple.strategyRef,
        skillRef: { id: "change-production-priority", version: 1 },
        policyVersion: "company-policy-v1",
        evidenceRefs: [],
        proposalDigest: tuple.digest,
        requesterActorId: "sales-demo",
        createdAt: "2026-09-19T00:00:00.000Z",
      });
      snapshot.records.approvals.push({
        id: tuple.approvalId,
        intentId: tuple.intentId,
        intentRevision: 1,
        proposalDigest: tuple.digest,
        epoch: snapshot.currentEpoch,
        readSetDigest: tuple.readSetDigest,
        policyVersion: "company-policy-v1",
        skillRef: { id: "change-production-priority", version: 1 },
        strategyRef: tuple.strategyRef,
        requesterActorId: "sales-demo",
        approverActorId: "production-demo",
        decision: "approved",
        decidedAt: "2026-09-19T00:00:01.000Z",
        expiresAt: "2026-09-19T00:15:01.000Z",
        consumedByExecutionId,
      });
    },
  });
  return tuple;
}

function applyApprovedPlan(repository, tuple, { mutate, refs } = {}) {
  return repository.transact({
    expectedRevision: 1,
    event: {
      ...event("production_priority_applied"),
      refs: refs ?? [
        { kind: "intent", id: tuple.intentId },
        { kind: "approval", id: tuple.approvalId },
        { kind: "execution", id: tuple.executionId },
        { kind: "production_plan", id: "PP-DEMO-1001" },
      ],
    },
    mutate(snapshot) {
      const approval = snapshot.records.approvals.find((item) => item.id === tuple.approvalId);
      approval.consumedByExecutionId = tuple.executionId;
      snapshot.records.executions.push({
        id: tuple.executionId,
        intentId: tuple.intentId,
        approvalId: tuple.approvalId,
        idempotencyKey: `${snapshot.currentEpoch}:${tuple.intentId}:${tuple.digest}`,
        epoch: snapshot.currentEpoch,
        mode: "apply",
        state: "applied_pending_readback",
        before: { priority: 5, version: 1 },
        expectedAfter: { priority: 1, version: 2 },
        attempt: 1,
        startedAt: "2026-09-19T00:00:02.000Z",
      });
      const plan = snapshot.current.productionPlans.find((item) => item.id === "PP-DEMO-1001");
      plan.priority = 1;
      plan.version = 2;
      mutate?.(snapshot, tuple);
    },
  });
}

beforeAll(() => {
  process.env.BNC_TEST_MODE = "1";
});

afterAll(() => {
  if (previousTestMode === undefined) delete process.env.BNC_TEST_MODE;
  else process.env.BNC_TEST_MODE = previousTestMode;
});

afterEach(() => {
  for (const directory of tempDirs.splice(0)) {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

describe("company snapshot persistence", () => {
  it("opens a format-v1 snapshot without adoption records without rewriting its bytes", async () => {
    // Given: a valid format-v1 snapshot written by the pre-adoption runtime.
    const rootDir = makeTempRoot();
    const first = createCompanyPersistence({ rootDir, bootstrap: () => makeState() });
    await first.open();
    await first.close();
    const before = fs.readFileSync(first.snapshotPath);

    // When: the additive reader opens it read-only.
    const reopened = createCompanyPersistence({ rootDir, bootstrap: () => { throw new Error("unexpected bootstrap"); } });
    const snapshot = await reopened.open();

    // Then: the missing collection defaults in memory and the stored bytes stay exact.
    expect(snapshot.records.strategyAdoptions).toEqual([]);
    expect(fs.readFileSync(first.snapshotPath)).toEqual(before);
  });

  it("bootstraps only an absent snapshot and reopens the exact persisted revision", async () => {
    const rootDir = makeTempRoot();
    const initial = makeState();
    const first = createCompanyPersistence({ rootDir, bootstrap: () => initial });

    const opened = await first.open();
    expect(opened.revision).toBe(0);
    expect(opened.current).toEqual(initial);
    await first.close();

    const reopened = createCompanyPersistence({
      rootDir,
      bootstrap: () => {
        throw new Error("bootstrap must not run for an existing snapshot");
      },
    });
    const restored = await reopened.open();
    expect(restored).toEqual(opened);
    await reopened.close();
  });

  it("serializes 50 concurrent transactions against the latest state without loss", async () => {
    const rootDir = makeTempRoot();
    const repository = createCompanyPersistence({ rootDir, bootstrap: () => makeState() });
    await repository.open();

    await Promise.all(Array.from({ length: 50 }, (_, index) => repository.transact({
      event: event("business_outcome_recorded"),
      mutate(snapshot) {
        snapshot.records.businessOutcomes.push({
          packetTaskId: randomUUID(),
          status: "unobserved",
          recordedByActorId: null,
          evidenceRefs: [`concurrent-${index}`],
          observedAt: null,
        });
      },
    })));
    await repository.close();

    const reopened = createCompanyPersistence({ rootDir, bootstrap: () => { throw new Error("unexpected bootstrap"); } });
    const restored = await reopened.open();
    expect(restored.revision).toBe(50);
    expect(restored.current.revision).toBe(50);
    expect(restored.records.businessOutcomes).toHaveLength(50);
    expect(new Set(restored.records.businessOutcomes.flatMap((item) => item.evidenceRefs)).size).toBe(50);
    expect(restored.records.events).toHaveLength(50);
    await reopened.close();
  });

  it("rejects stale expected revisions and commits without an audit event", async () => {
    const repository = createCompanyPersistence({ rootDir: makeTempRoot(), bootstrap: () => makeState() });
    await repository.open();
    await expect(repository.transact({
      expectedRevision: 4,
      event: event(),
      mutate() {},
    })).rejects.toMatchObject({ code: "conflict", reason: "stale_revision" });
    await expect(repository.transact({ mutate() {} })).rejects.toMatchObject({
      code: "invalid_input",
      reason: "audit_event_required",
    });
  });

  it("cannot commit a production-plan mutation without matching approval consumption and execution", async () => {
    const repository = createCompanyPersistence({ rootDir: makeTempRoot(), bootstrap: () => makeState() });
    await repository.open();
    await expect(repository.transact({
      event: event("production_priority_applied"),
      mutate(snapshot) {
        snapshot.current.productionPlans[0].priority = 1;
        snapshot.current.productionPlans[0].version += 1;
      },
    })).rejects.toMatchObject({ code: "invalid_input", reason: "mutation_boundary_missing" });
    expect((await repository.loadFresh()).revision).toBe(0);
  });

  it("consumes a previously persisted approval exactly once with a fresh execution and plan change", async () => {
    const repository = createCompanyPersistence({ rootDir: makeTempRoot(), bootstrap: () => makeState() });
    const tuple = await persistApprovedProposal(repository);
    const committed = await applyApprovedPlan(repository, tuple);
    expect(committed.current.productionPlans.find((item) => item.id === "PP-DEMO-1001")).toMatchObject({ priority: 1, version: 2 });
    expect(committed.records.approvals).toEqual([expect.objectContaining({ id: tuple.approvalId, consumedByExecutionId: tuple.executionId })]);
    expect(committed.records.executions).toEqual([expect.objectContaining({ id: tuple.executionId })]);
    expect(committed.records.events.at(-1)).toMatchObject({ revision: 2, refs: expect.arrayContaining([{ kind: "execution", id: tuple.executionId }]) });
  });

  it.each([
    ["intent priority transition", {}, (snapshot) => { const intent = snapshot.records.actionIntents[0]; intent.fromPriority = 4; intent.toPriority = 9; }],
    ["approval proposal digest", {}, (snapshot) => { snapshot.records.approvals[0].proposalDigest = "d".repeat(64); }],
    ["approval policy", {}, (snapshot) => { snapshot.records.approvals[0].policyVersion = "other-policy"; }],
    ["approval skill", {}, (snapshot) => { snapshot.records.approvals[0].skillRef = { id: "assess-order-priority", version: 1 }; }],
    ["approval strategy", {}, (snapshot) => { snapshot.records.approvals[0].strategyRef.strategy_version_id = randomUUID(); }],
    ["approval intent revision", {}, (snapshot) => { snapshot.records.approvals[0].intentRevision = 2; }],
    ["approval epoch", {}, (snapshot) => { snapshot.records.approvals[0].epoch = randomUUID(); }],
    ["approval requester", {}, (snapshot) => { snapshot.records.approvals[0].requesterActorId = "management-demo"; }],
    ["approval read-set digest retroactive edit", {}, (snapshot) => { snapshot.records.approvals[0].readSetDigest = "e".repeat(64); }],
    ["target read-set version", {}, (snapshot) => { snapshot.records.actionIntents[0].readSet[0].version = 2; }],
    ["target plan id", {}, (snapshot) => { snapshot.records.actionIntents[0].targetPlanId = "PP-DEMO-1002"; }],
    ["approval intent id", {}, (snapshot) => { snapshot.records.approvals[0].intentId = randomUUID(); }],
    ["execution intent id", {}, (snapshot) => { snapshot.records.executions.at(-1).intentId = randomUUID(); }],
    ["execution approval id", {}, (snapshot) => { snapshot.records.executions.at(-1).approvalId = randomUUID(); }],
    ["shadow execution", {}, (snapshot) => { snapshot.records.executions.at(-1).mode = "shadow"; }],
    ["verified execution", {}, (snapshot) => { snapshot.records.executions.at(-1).state = "verified"; }],
    ["execution before priority", {}, (snapshot) => { snapshot.records.executions.at(-1).before.priority = 4; }],
    ["execution after priority", {}, (snapshot) => { snapshot.records.executions.at(-1).expectedAfter.priority = 9; }],
    ["execution idempotency tuple", {}, (snapshot) => { snapshot.records.executions.at(-1).idempotencyKey = "wrong-tuple"; }],
    ["skipped plan version", {}, (snapshot) => { snapshot.records.executions.at(-1).expectedAfter.version = 3; snapshot.current.productionPlans[0].version = 3; }],
    ["duplicate intent id", {}, (snapshot) => { snapshot.records.actionIntents.push(structuredClone(snapshot.records.actionIntents[0])); }],
    ["duplicate approval id", {}, (snapshot) => { snapshot.records.approvals.push(structuredClone(snapshot.records.approvals[0])); }],
    ["duplicate execution id", {}, (snapshot) => { snapshot.records.executions.push(structuredClone(snapshot.records.executions.at(-1))); }],
    ["previously consumed approval", { consumedByExecutionId: randomUUID() }, undefined],
  ])("rejects a corrupt apply tuple: %s", async (_name, setup, mutate) => {
    const repository = createCompanyPersistence({ rootDir: makeTempRoot(), bootstrap: () => makeState() });
    const tuple = await persistApprovedProposal(repository, setup);
    const beforeHash = sha256(repository.snapshotPath);
    await expect(applyApprovedPlan(repository, tuple, { mutate })).rejects.toMatchObject({
      code: "invalid_input",
      reason: "mutation_boundary_missing",
      committed: false,
    });
    expect(sha256(repository.snapshotPath)).toBe(beforeHash);
    const persisted = await repository.loadFresh();
    expect(persisted).toMatchObject({ revision: 1, current: { productionPlans: expect.arrayContaining([expect.objectContaining({ id: "PP-DEMO-1001", priority: 5, version: 1 })]) } });
  });

  it("rejects event references that do not bind the same intent and target plan", async () => {
    const repository = createCompanyPersistence({ rootDir: makeTempRoot(), bootstrap: () => makeState() });
    const tuple = await persistApprovedProposal(repository);
    const beforeHash = sha256(repository.snapshotPath);
    await expect(applyApprovedPlan(repository, tuple, {
      refs: [{ kind: "approval", id: tuple.approvalId }, { kind: "execution", id: tuple.executionId }],
    })).rejects.toMatchObject({ code: "invalid_input", reason: "mutation_boundary_missing", committed: false });
    expect(sha256(repository.snapshotPath)).toBe(beforeHash);
  });

  it.each([
    ["append plan", (snapshot) => {
      snapshot.current.productionPlans.push({ ...structuredClone(snapshot.current.productionPlans[1]), id: "PP-DEMO-9999" });
    }],
    ["remove plan", (snapshot) => {
      snapshot.current.productionPlans.pop();
    }],
    ["replace plan identity", (snapshot) => {
      snapshot.current.productionPlans[1] = { ...structuredClone(snapshot.current.productionPlans[1]), id: "PP-DEMO-9999" };
    }],
    ["reorder plans", (snapshot) => {
      snapshot.current.productionPlans.reverse();
    }],
    ["duplicate plan", (snapshot) => {
      snapshot.current.productionPlans.push(structuredClone(snapshot.current.productionPlans[1]));
    }],
    ["change target hold", (snapshot) => {
      snapshot.current.productionPlans[0].qualityHold = true;
    }],
    ["change customer", (snapshot) => {
      snapshot.current.customers[0].name = "Unauthorized customer edit";
    }],
    ["change sales opportunity", (snapshot) => {
      snapshot.current.salesOpportunities[0].requestedKg += 1;
    }],
    ["change quote", (snapshot) => {
      snapshot.current.quotes[0].quantityKg += 1;
    }],
    ["change sales order", (snapshot) => {
      snapshot.current.salesOrders[0].status = "completed";
    }],
    ["change inventory", (snapshot) => {
      snapshot.current.inventory[0].availableKg -= 1;
    }],
    ["change inspection", (snapshot) => {
      snapshot.current.inspections[0].status = "passed";
    }],
    ["change shipment", (snapshot) => {
      snapshot.current.shipments[0].packagingStatus = "ready";
    }],
    ["change skill registry", (snapshot) => {
      snapshot.current.skills[0].policyVersion = "unauthorized-policy";
    }],
    ["change bootstrap read set", (snapshot) => {
      snapshot.current.bootstrapReadSet[0].version = 2;
    }],
  ])("rejects an unauthorized ERP delta alongside a valid apply: %s", async (_name, mutate) => {
    const repository = createCompanyPersistence({ rootDir: makeTempRoot(), bootstrap: () => makeState() });
    const tuple = await persistApprovedProposal(repository);
    const beforeHash = sha256(repository.snapshotPath);
    await expect(applyApprovedPlan(repository, tuple, { mutate })).rejects.toMatchObject({
      code: "invalid_input",
      reason: "mutation_boundary_missing",
      committed: false,
    });
    expect(sha256(repository.snapshotPath)).toBe(beforeHash);
    const persisted = await repository.loadFresh();
    expect(persisted.revision).toBe(1);
    expect(persisted.current.productionPlans).toHaveLength(3);
    expect(persisted.current.productionPlans.map((plan) => plan.id)).toEqual(["PP-DEMO-1001", "PP-DEMO-1002", "PP-DEMO-1003"]);
    expect(persisted.current.productionPlans[0]).toMatchObject({ priority: 5, version: 1, qualityHold: false });
  });

  it("allows distinct strategy and learning-record mutations without changing ERP collections", async () => {
    const repository = createCompanyPersistence({ rootDir: makeTempRoot(), bootstrap: () => makeState() });
    const opened = await repository.open();
    const previousPlans = structuredClone(opened.current.productionPlans);
    const priorStrategy = opened.current.strategyVersions[0];
    const strategyVersionId = randomUUID();
    const learningId = randomUUID();
    const committed = await repository.transact({
      event: event("strategy_and_learning_updated"),
      mutate(snapshot) {
        snapshot.current.strategyVersions.push({
          ...structuredClone(priorStrategy),
          strategy_version_id: strategyVersionId,
          version: 2,
          parent_version_id: priorStrategy.strategy_version_id,
          origin: "management",
          created_at: "2026-09-19T01:00:00.000Z",
          content_hash: "f".repeat(64),
        });
        snapshot.records.learningAssets.push({
          id: learningId,
          version: 1,
          authorActorId: "production-demo",
          sourceTaskId: randomUUID(),
          sourceEvidenceRefs: [],
          correctionRef: null,
          content: "검사와 포장을 확인한다",
          applicability: ["production_readiness_review"],
          requiredChecks: ["inspection", "packaging"],
          allowedAudiences: ["production"],
          reviewState: "private",
          consent: { version: 1, decidedAt: "2026-09-19T01:00:00.000Z", audiences: ["production"] },
          provenance: "operator correction",
        });
      },
    });
    expect(committed.current.productionPlans).toEqual(previousPlans);
    expect(committed.current.activeStrategyRef).toEqual(opened.current.activeStrategyRef);
    expect(committed.records.learningAssets).toEqual([expect.objectContaining({ id: learningId })]);
  });

  it("rejects an active strategy change without an exact adoption record and audit refs", async () => {
    // Given: a separately persisted reviewed strategy version.
    const repository = createCompanyPersistence({ rootDir: makeTempRoot(), bootstrap: () => makeState() });
    const opened = await repository.open();
    const prior = opened.current.strategyVersions[0];
    const targetId = randomUUID();

    // When: a generic transaction tries to switch active strategy directly.
    const change = repository.transact({
      event: event("strategy_changed"),
      mutate(snapshot) {
        snapshot.current.strategyVersions.push({
          ...structuredClone(prior), strategy_version_id: targetId, version: 2,
          parent_version_id: prior.strategy_version_id, origin: "management",
          created_at: "2026-09-19T01:00:00.000Z", content_hash: "f".repeat(64),
        });
        snapshot.current.activeStrategyRef = { strategy_id: prior.strategy_id, strategy_version_id: targetId };
      },
    });

    // Then: persistence rejects it before any bytes change.
    await expect(change).rejects.toMatchObject({ code: "invalid_input", reason: "mutation_boundary_missing" });
    expect((await repository.loadFresh()).revision).toBe(0);
  });

  it("rejects an ERP collection edit even without a production-plan apply", async () => {
    const repository = createCompanyPersistence({ rootDir: makeTempRoot(), bootstrap: () => makeState() });
    await repository.open();
    const beforeHash = sha256(repository.snapshotPath);
    await expect(repository.transact({
      event: event("customer_changed"),
      mutate(snapshot) {
        snapshot.current.customers[0].name = "Unauthorized customer edit";
      },
    })).rejects.toMatchObject({ code: "invalid_input", reason: "mutation_boundary_missing", committed: false });
    expect(sha256(repository.snapshotPath)).toBe(beforeHash);
    expect((await repository.loadFresh()).revision).toBe(0);
  });

  it("classifies malformed transaction input before touching disk", async () => {
    const repository = createCompanyPersistence({ rootDir: makeTempRoot(), bootstrap: () => makeState() });
    await repository.open();
    const beforeHash = sha256(repository.snapshotPath);
    await expect(repository.transact({ event: { type: "missing-fields" }, mutate() {} })).rejects.toMatchObject({
      code: "invalid_input",
      reason: "invalid_audit_event",
      committed: false,
    });
    expect(sha256(repository.snapshotPath)).toBe(beforeHash);
  });

  it("treats a synchronous beforeRename rejection as definitively uncommitted", async () => {
    const repository = createCompanyPersistence({ rootDir: makeTempRoot(), bootstrap: () => makeState() });
    await repository.open();
    const beforeHash = sha256(repository.snapshotPath);
    await expect(repository.transact({
      event: event(),
      mutate() {},
      beforeRename() {
        throw new Error("runtime stopped before commit boundary");
      },
    })).rejects.toMatchObject({ code: "persistence_failed", reason: "before_rename", committed: false });
    expect(sha256(repository.snapshotPath)).toBe(beforeHash);
    expect((await repository.loadFresh()).revision).toBe(0);
  });

  it.each(["temp_write", "file_sync", "rename"])("preserves the old snapshot when %s fails before rename completion", async (stage) => {
    const rootDir = makeTempRoot();
    const healthy = createCompanyPersistence({ rootDir, bootstrap: () => makeState() });
    await healthy.open();
    await healthy.close();
    const snapshotPath = healthy.snapshotPath;
    const beforeHash = sha256(snapshotPath);

    const faulty = createCompanyPersistence({
      rootDir,
      bootstrap: () => { throw new Error("unexpected bootstrap"); },
      isPackaged: false,
      faults: { [stage]: () => { throw new Error(`${stage}-fault`); } },
    });
    await faulty.open();
    await expect(faulty.transact({ event: event(), mutate() {} })).rejects.toMatchObject({
      code: "persistence_failed",
      reason: stage,
      committed: false,
    });
    expect(sha256(snapshotPath)).toBe(beforeHash);
    expect((await faulty.loadFresh()).revision).toBe(0);
  });

  it("blocks blind retry after directory sync uncertainty until exact persisted revision is verified", async () => {
    const rootDir = makeTempRoot();
    const healthy = createCompanyPersistence({ rootDir, bootstrap: () => makeState() });
    await healthy.open();
    await healthy.close();
    const beforeHash = sha256(healthy.snapshotPath);
    let inject = true;
    const repository = createCompanyPersistence({
      rootDir,
      bootstrap: () => { throw new Error("unexpected bootstrap"); },
      isPackaged: false,
      faults: { dir_sync: () => { if (inject) throw new Error("dir-sync-fault"); } },
    });
    await repository.open();
    await expect(repository.transact({ event: event(), mutate() {} })).rejects.toMatchObject({
      code: "verification_required",
      reason: "dir_sync",
      committed: true,
      persistedSnapshot: { revision: 1 },
    });
    expect(sha256(repository.snapshotPath)).not.toBe(beforeHash);
    await expect(repository.transact({ event: event(), mutate() {} })).rejects.toMatchObject({
      code: "verification_required",
      reason: "uncertain_commit",
    });
    inject = false;
    expect((await repository.verifyUncertain(1)).revision).toBe(1);
    expect((await repository.loadFresh()).stopped).toBe(false);
  });

  it.each([
    ["corrupt JSON", "{not-json", "corrupt_snapshot"],
    ["unsupported version", JSON.stringify({ formatVersion: 99 }), "unsupported_format"],
  ])("preserves %s and never falls back to bootstrap", async (_label, contents, reason) => {
    const rootDir = makeTempRoot();
    const snapshotPath = path.join(rootDir, "company-runtime", "snapshot.json");
    fs.mkdirSync(path.dirname(snapshotPath), { recursive: true });
    fs.writeFileSync(snapshotPath, contents);
    const beforeHash = sha256(snapshotPath);
    let bootstrapped = false;
    const repository = createCompanyPersistence({
      rootDir,
      bootstrap: () => {
        bootstrapped = true;
        return makeState();
      },
    });
    await expect(repository.open()).rejects.toMatchObject({ code: "persistence_failed", reason });
    expect(bootstrapped).toBe(false);
    expect(sha256(snapshotPath)).toBe(beforeHash);
  });

  it("archives the previous epoch read-only and starts a reset epoch stopped", async () => {
    const rootDir = makeTempRoot();
    const repository = createCompanyPersistence({ rootDir, bootstrap: () => makeState() });
    const first = await repository.open();
    const nextState = makeState();
    nextState.stopped = true;
    const reset = await repository.reset({
      expectedRevision: 0,
      nextState,
      archivedAt: "2026-09-19T00:01:00.000Z",
      event: event("runtime_reset"),
    });
    expect(reset.currentEpoch).toBe(nextState.currentEpoch);
    expect(reset.stopped).toBe(true);
    expect(reset.revision).toBe(1);
    expect(reset.history).toEqual([
      expect.objectContaining({ epoch: first.currentEpoch, finalRevision: 0, current: first.current }),
    ]);
    await repository.close();
    const reopened = createCompanyPersistence({ rootDir, bootstrap: () => { throw new Error("unexpected bootstrap"); } });
    expect(await reopened.open()).toEqual(reset);
  });

  it("rejects packaged or non-test fault injection", () => {
    expect(() => createCompanyPersistence({
      rootDir: makeTempRoot(),
      bootstrap: () => makeState(),
      isPackaged: true,
      faults: { temp_write() {} },
    })).toThrow("test-only fault injection");
  });
});
