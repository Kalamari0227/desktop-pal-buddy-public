import { app, BrowserWindow, ipcMain, screen, shell } from "electron";
import electronUpdater from "electron-updater";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  getContentSecurityPolicy,
  isAllowedDockState,
  isAllowedDockSurface,
  isAllowedExternalUrl,
  isAllowedNavigationUrl,
  normalizeUpdateFeedUrl,
  parseAllowedExternalHosts,
} from "./shellValidation.mjs";
import { createCompanyPersistence } from "./companyPersistence.mjs";
import { createCompanyRuntime } from "./companyRuntime.mjs";
import { createCodexInterpreter, discoverCodexCli } from "./codexInterpreter.mjs";
import {
  createAiConnectionController,
  createCompanyBootstrapState,
  createCompanyContextView,
  registerCompanyIpcHandlers,
} from "./companyIpc.mjs";
import { createDeterministicCompanyInterpreter, readCompanyTestOptions } from "./companyTestOptions.mjs";
import { configureCompanyStartup, removeCompanySmokeData } from "./companyStartup.mjs";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const { autoUpdater } = electronUpdater;
let companyStartup;
try {
  companyStartup = configureCompanyStartup({
    app,
    isPackaged: app.isPackaged,
    argv: process.argv,
    environment: process.env,
  });
} catch (error) {
  process.stderr.write(`Company startup rejected: ${error?.code ?? "invalid_startup"}\n`);
  process.exit(1);
}

const isDev = process.argv.includes("--dev");
const shouldOpenDevTools = process.argv.includes("--devtools");
const allowedExternalHosts = parseAllowedExternalHosts(process.env.ELECTRON_EXTERNAL_HOSTS);
const devServerOrigin = "http://127.0.0.1:8080";
const packagedEntryPath = path.join(__dirname, "..", "dist", "index.html");
const updateFeedUrl = normalizeUpdateFeedUrl(process.env.ELECTRON_UPDATE_FEED_URL);
const wideDockStates = new Set([
  "hovered",
  "expanded",
  "listening",
  "thinking",
  "dispatching",
  "working",
  "needs_review",
  "alert",
  "completed",
]);
const tallDockStates = new Set(["hovered", "expanded", "dispatching", "working", "alert", "completed"]);

let mainWindow = null;
let shellMode = "dock";
let dockSurface = "ambient";
let currentDockState = "idle";
let autoUpdatesConfigured = false;
let companyRuntime = null;
let companyIpc = null;
let companyClosing = false;
const hasSingleInstanceLock = app.requestSingleInstanceLock();
const companyTestOptions = readCompanyTestOptions({
  isPackaged: app.isPackaged,
  testMode: process.env.BNC_TEST_MODE,
});
const hasDeterministicStub = Boolean(companyTestOptions?.modelStub);
const probesLocalReadiness = companyTestOptions?.localReadinessProbe === true;

const companyContextView = createCompanyContextView();
const companyInterpreter = {
  runtimeMode: hasDeterministicStub ? "stub" : "unavailable",
  actualAI: false,
  active: hasDeterministicStub
    ? createDeterministicCompanyInterpreter(companyTestOptions.modelStub)
    : null,
  interpret(input, options) {
    if (!this.active) {
      return Promise.resolve({
        ok: false,
        error: { code: "unavailable", reason: "codex_interpreter_unavailable" },
        actions: [],
      });
    }
    return this.active.interpret(input, options);
  },
  explain(input, options) {
    if (!this.active) {
      return Promise.resolve({
        ok: false,
        error: { code: "unavailable", reason: "codex_interpreter_unavailable" },
        actions: [],
        preservedVerifiedFacts: Array.isArray(input?.verifiedFacts) ? input.verifiedFacts : [],
      });
    }
    return this.active.explain(input, options);
  },
  cancel() {
    this.active?.cancel();
  },
};

const aiConnection = createAiConnectionController({
  discover: () => hasDeterministicStub && !probesLocalReadiness
    ? Promise.resolve({ ok: false, error: { reason: "test_adapter" } })
    : discoverCodexCli(),
  onReady: async (proof) => {
    if (hasDeterministicStub) return;
    if (!companyRuntime) throw new Error("company_runtime_unavailable");
    companyInterpreter.active = createCodexInterpreter({
      executablePath: proof.executablePath,
      profileProof: proof,
      schemaDir: path.join(__dirname, "codex-schemas"),
      getCurrentContext: () => companyContextView.get(),
    });
    companyInterpreter.runtimeMode = "live";
    companyInterpreter.actualAI = true;
  },
  onUnavailable: async () => {
    if (hasDeterministicStub) return;
    companyInterpreter.active = null;
    companyInterpreter.runtimeMode = "unavailable";
    companyInterpreter.actualAI = false;
  },
});

async function initializeCompanyRuntime() {
  const repository = createCompanyPersistence({
    rootDir: companyTestOptions?.dataDir || app.getPath("userData"),
    bootstrap: createCompanyBootstrapState,
    isPackaged: app.isPackaged,
    faults: companyTestOptions?.faults,
  });
  companyRuntime = createCompanyRuntime({
    repository,
    isPackaged: app.isPackaged,
    testHooks: companyTestOptions?.runtimeTestHooks,
  });
  try {
    companyContextView.set(await companyRuntime.open());
  } catch (error) {
    console.error("Company runtime failed to open:", error?.code || "unavailable", error?.reason || "open_failed");
  }
  companyIpc = registerCompanyIpcHandlers({
    ipcMain,
    runtime: companyRuntime,
    interpreter: companyInterpreter,
    contextView: companyContextView,
    getMainWindow: () => mainWindow,
    isDev,
    devOrigin: devServerOrigin,
    packagedEntryPath,
    aiConnection,
  });
  void aiConnection.refresh()
    .then(() => companyIpc?.publish())
    .catch((error) => {
      console.error("Company interpreter preflight publish failed:", error?.code || "unavailable");
    });
}

function getActiveDisplay() {
  if (mainWindow) {
    return screen.getDisplayMatching(mainWindow.getBounds());
  }

  return screen.getPrimaryDisplay();
}

function getDockBounds(dockState = "idle", surface = "ambient") {
  const { x, y, width, height } = getActiveDisplay().workArea;
  if (surface === "chat") {
    const chatWidth = 520;
    const chatHeight = 760;
    const margin = 24;

    return {
      width: chatWidth,
      height: chatHeight,
      x: Math.round(x + width - chatWidth - margin),
      y: Math.round(y + height - chatHeight - margin),
    };
  }

  const dockWidth = wideDockStates.has(dockState) ? 440 : 176;
  const dockHeight = tallDockStates.has(dockState) ? 520 : 148;
  const margin = 24;

  return {
    width: dockWidth,
    height: dockHeight,
    x: Math.round(x + width - dockWidth - margin),
    y: Math.round(y + height - dockHeight - margin),
  };
}

function getWorkspaceBounds() {
  const { x, y, width, height } = getActiveDisplay().workArea;
  const targetWidth = Math.min(1440, Math.max(1080, width - 96));
  const targetHeight = Math.min(960, Math.max(760, height - 96));

  return {
    width: targetWidth,
    height: targetHeight,
    x: Math.round(x + (width - targetWidth) / 2),
    y: Math.round(y + (height - targetHeight) / 2),
  };
}

function applyShellMode(nextMode, options = {}) {
  if (!mainWindow || mainWindow.isDestroyed()) {
    return;
  }

  const previousShellMode = shellMode;
  shellMode = nextMode;
  if (options.dockState) {
    currentDockState = options.dockState;
  }
  if (options.dockSurface) {
    dockSurface = options.dockSurface;
  }

  if (nextMode === "workspace") {
    mainWindow.setMinimumSize(1080, 760);
    mainWindow.setResizable(true);
    mainWindow.setAlwaysOnTop(false);
    mainWindow.setSkipTaskbar(false);
    mainWindow.setVisibleOnAllWorkspaces(false);
    mainWindow.setBounds(getWorkspaceBounds(), false);
  } else {
    mainWindow.setMinimumSize(0, 0);
    mainWindow.setResizable(false);
    mainWindow.setAlwaysOnTop(true, "floating");
    mainWindow.setSkipTaskbar(true);
    mainWindow.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
    mainWindow.setBounds(getDockBounds(currentDockState, dockSurface), false);
  }

  if (previousShellMode !== shellMode) {
    mainWindow.webContents.send("shell:mode-changed", shellMode);
  }
}

function createWindow() {
  mainWindow = new BrowserWindow({
    ...getDockBounds(),
    show: false,
    backgroundColor: "#00000000",
    autoHideMenuBar: true,
    title: "Prometheus Desktop Pal",
    transparent: true,
    frame: false,
    hasShadow: true,
    resizable: false,
    fullscreenable: false,
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });

  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (isAllowedExternalUrl(url, allowedExternalHosts)) {
      shell.openExternal(url);
    }
    return { action: "deny" };
  });

  mainWindow.webContents.on("will-navigate", (event, url) => {
    if (!isAllowedNavigationUrl(url, {
      isDev,
      devOrigin: devServerOrigin,
      appEntryPath: packagedEntryPath,
    })) {
      event.preventDefault();
    }
  });

  mainWindow.webContents.session.setPermissionRequestHandler((_webContents, _permission, callback) => {
    callback(false);
  });

  mainWindow.webContents.session.webRequest.onHeadersReceived((details, callback) => {
    callback({
      responseHeaders: {
        ...details.responseHeaders,
        "Content-Security-Policy": [
          getContentSecurityPolicy({ isDev, devOrigin: devServerOrigin }),
        ],
      },
    });
  });

  if (isDev) {
    mainWindow.loadURL(devServerOrigin);
    if (shouldOpenDevTools) {
      mainWindow.webContents.openDevTools({ mode: "detach" });
    }
  } else {
    mainWindow.loadFile(packagedEntryPath);
  }

  mainWindow.once("ready-to-show", () => {
    applyShellMode("dock", { dockState: "idle" });
    mainWindow.show();
  });
}

function configureAutoUpdates() {
  if (autoUpdatesConfigured || isDev || !companyStartup.updatesEnabled || !updateFeedUrl) {
    return;
  }

  autoUpdatesConfigured = true;
  autoUpdater.autoDownload = false;
  autoUpdater.autoInstallOnAppQuit = true;
  autoUpdater.setFeedURL({
    provider: "generic",
    url: updateFeedUrl,
    channel: process.env.ELECTRON_UPDATE_CHANNEL || "latest",
  });

  autoUpdater.on("error", (error) => {
    console.error("Auto update check failed:", error);
  });

  autoUpdater.on("update-available", () => {
    void autoUpdater.downloadUpdate().catch((error) => {
      console.error("Auto update download failed:", error);
    });
  });

  autoUpdater.on("update-downloaded", () => {
    mainWindow?.webContents.send("shell:update-downloaded");
  });

  setTimeout(() => {
    void autoUpdater.checkForUpdates().catch((error) => {
      console.error("Auto update check failed:", error);
    });
  }, 5000);
}

if (!hasSingleInstanceLock) {
  app.quit();
} else {
  app.on("second-instance", () => {
    if (!mainWindow || mainWindow.isDestroyed()) return;
    if (mainWindow.isMinimized()) mainWindow.restore();
    mainWindow.show();
    mainWindow.focus();
  });

  app.whenReady().then(async () => {
    ipcMain.handle("shell:get-mode", () => shellMode);
    ipcMain.on("shell:show-workspace", () => applyShellMode("workspace"));
    ipcMain.on("shell:show-dock", () => applyShellMode("dock", { dockState: "idle", dockSurface: "ambient" }));
    ipcMain.on("shell:update-dock-state", (_event, dockState) => {
      if (shellMode === "dock" && isAllowedDockState(dockState)) {
        applyShellMode("dock", { dockState });
      }
    });
    ipcMain.on("shell:update-dock-surface", (_event, nextSurface) => {
      if (shellMode === "dock" && isAllowedDockSurface(nextSurface)) {
        applyShellMode("dock", { dockSurface: nextSurface });
      }
    });

    await initializeCompanyRuntime();
    createWindow();
    configureAutoUpdates();

    app.on("activate", () => {
      if (BrowserWindow.getAllWindows().length === 0) {
        createWindow();
      }
    });
  });

  app.on("before-quit", (event) => {
    if (companyClosing || !companyRuntime) return;
    event.preventDefault();
    companyClosing = true;
    companyInterpreter.cancel();
    companyIpc?.dispose();
    void companyRuntime.close().finally(() => app.exit(0));
  });

  app.on("window-all-closed", () => {
    if (process.platform !== "darwin") {
      app.quit();
    }
  });

  app.on("will-quit", () => {
    removeCompanySmokeData(companyStartup);
  });
}
