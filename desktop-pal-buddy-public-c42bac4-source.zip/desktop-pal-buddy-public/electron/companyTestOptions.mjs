import { assertCompanyTestOptions } from "./companyIpc.mjs";
import { mkdirSync, writeFileSync } from "node:fs";
import path from "node:path";

const PERSISTENCE_FAULTS = new Set(["temp_write", "file_sync", "rename", "after_rename", "dir_sync"]);
const RUNTIME_FAULT_HOOKS = new Map([
  ["after_apply_commit", "afterApplyCommit"],
]);

function parseRawOptions(raw) {
  if (raw === undefined || raw === "") return { modelStub: { enabled: true } };
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch {
    throw new TypeError("invalid company test options JSON");
  }
  if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) {
    throw new TypeError("invalid company test options");
  }
  return parsed;
}

function createFaults(options) {
  if (!options?.faults) return { persistence: undefined, runtime: undefined };
  const persistence = {};
  const runtime = {};
  for (const [name, enabled] of Object.entries(options.faults)) {
    if (enabled !== true) continue;
    if (PERSISTENCE_FAULTS.has(name)) {
      persistence[name] = () => { throw new Error(`test fault: ${name}`); };
      continue;
    }
    const hook = RUNTIME_FAULT_HOOKS.get(name);
    if (!hook) throw new TypeError(`invalid test fault: ${name}`);
    runtime[hook] = () => {
      throw Object.assign(new Error(`test fault: ${name}`), {
        code: "verification_required",
        reason: `test_${name}`,
        committed: true,
      });
    };
  }
  return {
    persistence,
    runtime: Object.keys(runtime).length > 0 ? runtime : undefined,
  };
}

export function readCompanyTestOptions({ isPackaged, testMode, raw = process.env.BNC_TEST_OPTIONS } = {}) {
  if (isPackaged || testMode !== "1") return undefined;
  const parsed = parseRawOptions(raw);
  const validated = assertCompanyTestOptions({ isPackaged: false, testMode, options: parsed });
  const faultControls = createFaults(validated);
  return {
    ...validated,
    ...(validated?.faults ? { faults: faultControls.persistence } : {}),
    ...(faultControls.runtime ? { runtimeTestHooks: faultControls.runtime } : {}),
  };
}

function targetIds(input, names) {
  return input.allowedTargetIds.filter((id) => names.includes(id));
}

function priorityEvidenceIds(input) {
  const required = [
    "evidence:sales_order:SO-DEMO-1001:v1",
    "evidence:inventory:INV-DEMO-GA-ULSAN:v1",
    "evidence:production_plan:PP-DEMO-1001:v1",
    "evidence:production_plan:PP-DEMO-1002:v1",
    "evidence:production_plan:PP-DEMO-1003:v1",
    "evidence:inspection:INSPECTION-DEMO-1001:v1",
    "evidence:shipment:SHIPMENT-DEMO-1001:v1",
  ];
  return input.allowedEvidenceIds.filter((id) => required.includes(id));
}

function deterministicInterpretation(input) {
  const priority = /(?:priority|우선순위)\D{0,16}(1|2|3|4|5|6|7|8|9)/i.exec(input.requestText)?.[1];
  const hasOrder = input.requestText.includes("SO-DEMO-1001") || input.requestText.includes("1001");
  if (!hasOrder || priority === undefined) {
    return {
      schemaVersion: 1,
      kind: "interpretation",
      intent: "clarification",
      targetIds: [],
      requestedPriority: null,
      clarificationQuestions: ["대상 주문과 목표 우선순위를 확인해 주세요."],
      citedEvidenceIds: [],
      salesExplanation: "대상 주문과 우선순위가 필요합니다.",
      productionExplanation: "생산 변경 후보를 만들지 않았습니다.",
      uncertainties: ["요청 대상이 명확하지 않습니다."],
      authorityClaims: [],
    };
  }
  return {
    schemaVersion: 1,
    kind: "interpretation",
    intent: "change_production_priority",
    targetIds: targetIds(input, ["SO-DEMO-1001", "PP-DEMO-1001"]),
    requestedPriority: Number(priority),
    clarificationQuestions: [],
    citedEvidenceIds: priorityEvidenceIds(input),
    salesExplanation: "영업 주문과 수량을 확인했습니다.",
    productionExplanation: "생산 계획과 재고를 확인했습니다.",
    uncertainties: ["검사와 출하 준비 상태는 납기를 보장하지 않습니다."],
    authorityClaims: [],
  };
}

function deterministicExplanation(input) {
  return {
    schemaVersion: 1,
    kind: "explanation",
    summary: "검증된 가상 ERP 사실을 설명했습니다.",
    verifiedFactIds: input.verifiedFacts.map((fact) => fact.id),
    citedEvidenceIds: input.verifiedFacts.map((fact) => fact.evidenceId),
    uncertainties: ["사업 결과는 관찰되지 않았습니다."],
    authorityClaims: [],
  };
}

export function createDeterministicCompanyInterpreter(modelStub = {}) {
  const delayMs = Number.isInteger(modelStub.delayMs) && modelStub.delayMs >= 0 ? modelStub.delayMs : 0;
  const diagnosticsPath = typeof modelStub.diagnosticsPath === "string" && modelStub.diagnosticsPath.length > 0
    ? modelStub.diagnosticsPath
    : null;
  const diagnostics = { runtimeMode: "stub", actualAI: false, providerCalls: 0, calls: [] };
  const persistDiagnostics = () => {
    if (!diagnosticsPath) return;
    mkdirSync(path.dirname(diagnosticsPath), { recursive: true });
    writeFileSync(diagnosticsPath, `${JSON.stringify(diagnostics)}\n`, "utf8");
  };
  persistDiagnostics();
  let active = null;
  const invoke = (operation, input, result) => new Promise((resolve) => {
    diagnostics.calls.push({ operation, at: new Date().toISOString() });
    persistDiagnostics();
    const timer = setTimeout(() => {
      active = null;
      persistDiagnostics();
      resolve({ ok: true, actions: [], data: result(input) });
    }, delayMs);
    active = {
      cancel() {
        clearTimeout(timer);
        active = null;
        diagnostics.calls.push({ operation: "cancel", at: new Date().toISOString() });
        persistDiagnostics();
        resolve({ ok: true, actions: [], data: result(input) });
      },
    };
  });
  return {
    runtimeMode: "stub",
    actualAI: false,
    interpret: (input) => invoke("interpret", input, deterministicInterpretation),
    explain: (input) => invoke("explain", input, deterministicExplanation),
    cancel: () => active?.cancel(),
  };
}
