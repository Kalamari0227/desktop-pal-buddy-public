import fs from "node:fs";
import os from "node:os";
import path from "node:path";

function startupError(code, message) {
  return Object.assign(new Error(message), { code });
}

export function configureCompanyStartup({ app, isPackaged, argv = process.argv, environment = process.env, tempRoot = os.tmpdir() }) {
  const smoke = argv.includes("--company-smoke");
  if (isPackaged && (environment.BNC_TEST_MODE || environment.BNC_TEST_OPTIONS)) {
    throw startupError("packaged_injection_rejected", "packaged test injection is forbidden");
  }
  if (!smoke) return { smoke: false, userDataPath: null, updatesEnabled: true };
  if (!isPackaged) throw startupError("packaged_smoke_required", "company smoke requires a packaged application");
  const unsafeArgument = argv.find((argument) => argument.startsWith("--user-data-dir") || argument.startsWith("--company-data-dir"));
  if (unsafeArgument) throw startupError("packaged_data_dir_rejected", "company smoke data directory is fixed by the application");
  const userDataPath = fs.mkdtempSync(path.join(tempRoot, "bnc-package-smoke-"));
  fs.chmodSync(userDataPath, 0o700);
  app.setPath("userData", userDataPath);
  return { smoke: true, userDataPath, updatesEnabled: false };
}

export function removeCompanySmokeData(startup) {
  if (startup.smoke && startup.userDataPath) {
    fs.rmSync(startup.userDataPath, { recursive: true, force: true });
  }
}
