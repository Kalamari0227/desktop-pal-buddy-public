import { spawnSync } from "node:child_process";

const START_TIMEOUT_MS = Number(process.env.SUPABASE_VERIFY_START_TIMEOUT_MS ?? 4 * 60 * 1000);
const COMMAND_TIMEOUT_MS = Number(process.env.SUPABASE_VERIFY_COMMAND_TIMEOUT_MS ?? 2 * 60 * 1000);
const FULL_STACK = process.env.SUPABASE_VERIFY_FULL_STACK === "1";

function describeFailure(command, args, result) {
  if (result.error?.name === "ETIMEDOUT" || result.error?.code === "ETIMEDOUT" || result.status === null) {
    const signal = result.signal ? ` It was stopped with ${result.signal}.` : "";
    return `${command} ${args.join(" ")} did not finish before the timeout.${signal} Docker image pulls or registry credential lookup may be stuck. Check Docker Desktop, registry credentials, and network access, then rerun this command.`;
  }

  return `${command} ${args.join(" ")} exited with ${result.status}`;
}

function run(command, args, options = {}) {
  console.log(`\n$ ${[command, ...args].join(" ")}`);
  const result = spawnSync(command, args, {
    cwd: process.cwd(),
    stdio: "inherit",
    timeout: options.timeout ?? COMMAND_TIMEOUT_MS,
    shell: process.platform === "win32",
  });

  if (result.error) {
    throw new Error(describeFailure(command, args, result));
  }

  if (result.status !== 0) {
    throw new Error(describeFailure(command, args, result));
  }
}

let started = false;

try {
  run("docker", ["info"], { timeout: COMMAND_TIMEOUT_MS });
  run("npx", ["supabase", FULL_STACK ? "start" : "db", FULL_STACK ? "" : "start"].filter(Boolean), {
    timeout: START_TIMEOUT_MS,
  });
  started = true;
  run("npx", ["supabase", "db", "reset", "--local", "--no-seed"], { timeout: START_TIMEOUT_MS });
  run("npx", ["supabase", "db", "lint", "--local", "--fail-on", "error"], { timeout: COMMAND_TIMEOUT_MS });
  if (FULL_STACK) {
    run("npx", ["supabase", "status"], { timeout: COMMAND_TIMEOUT_MS });
  }
  console.log("\nSupabase local database verification completed.");
} finally {
  if (started || process.env.SUPABASE_VERIFY_STOP_ON_FAIL === "1") {
    try {
      run("npx", ["supabase", "stop"], { timeout: COMMAND_TIMEOUT_MS });
    } catch (error) {
      console.error("\nFailed to stop Supabase local services. Run `npx supabase stop` manually.");
      console.error(error instanceof Error ? error.message : error);
    }
  }
}
