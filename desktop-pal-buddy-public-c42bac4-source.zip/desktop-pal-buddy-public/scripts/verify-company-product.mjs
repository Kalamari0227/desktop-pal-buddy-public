#!/usr/bin/env node

import { execFile, spawn } from "node:child_process";
import crypto from "node:crypto";
import { createServer } from "node:http";
import { chmod, lstat, mkdtemp, readFile, readlink, realpath, readdir, rm, stat, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { promisify } from "node:util";
import { verifyPackage } from "./verify-company-package.mjs";

const execFileAsync = promisify(execFile);
const SANDBOX_EXECUTABLE = "/usr/bin/sandbox-exec";
const CLEAN_PATH = "/usr/bin:/bin:/usr/sbin:/sbin";

export class ProductQaError extends Error {
  constructor(code, message) {
    super(message);
    this.name = "ProductQaError";
    this.code = code;
  }
}

function digest(value) {
  return crypto.createHash("sha256").update(value).digest("hex");
}

function isInside(candidate, root) {
  const relative = path.relative(root, candidate);
  return relative === "" || (!relative.startsWith("..") && !path.isAbsolute(relative));
}

function byteSort(left, right) {
  return Buffer.compare(Buffer.from(left, "utf8"), Buffer.from(right, "utf8"));
}

export async function createAppArtifactInventory(appPath) {
  const rootStat = await lstat(appPath).catch(() => null);
  if (!rootStat?.isDirectory() || rootStat.isSymbolicLink()) {
    throw new ProductQaError("app_artifact_invalid", "app artifact must be a real directory");
  }
  const root = await realpath(appPath);
  const entries = [];
  async function visit(absolutePath, relativePath) {
    const metadata = await lstat(absolutePath);
    const mode = metadata.mode & 0o7777;
    const inventoryPath = relativePath.split(path.sep).join("/");
    if (metadata.isSymbolicLink()) {
      const link = await readlink(absolutePath);
      let target;
      try {
        target = await realpath(absolutePath);
      } catch (error) {
        const code = error instanceof Error && "code" in error ? error.code : undefined;
        throw new ProductQaError(code === "ELOOP" ? "app_symlink_cycle" : "app_symlink_broken", `invalid app symlink: ${inventoryPath}`);
      }
      if (!isInside(target, root)) throw new ProductQaError("app_symlink_external", `app symlink escapes artifact: ${inventoryPath}`);
      entries.push({ type: "symlink", path: inventoryPath, mode, link });
      return;
    }
    if (metadata.isDirectory()) {
      entries.push({ type: "directory", path: inventoryPath, mode });
      const children = await readdir(absolutePath);
      children.sort(byteSort);
      for (const child of children) await visit(path.join(absolutePath, child), relativePath === "." ? child : path.join(relativePath, child));
      return;
    }
    if (!metadata.isFile()) throw new ProductQaError("app_artifact_special_file", `unsupported app artifact entry: ${inventoryPath}`);
    entries.push({ type: "file", path: inventoryPath, mode, size: metadata.size, sha256: digest(await readFile(absolutePath)) });
  }
  await visit(root, ".");
  entries.sort((left, right) => byteSort(left.path, right.path));
  const canonical = { schemaVersion: 1, entries };
  return { ...canonical, appArtifactSha256: digest(JSON.stringify(canonical)) };
}

export async function verifyAppArtifactIdentity(appPath, expectedDigest) {
  const inventory = await createAppArtifactInventory(appPath);
  if (inventory.appArtifactSha256 !== expectedDigest) {
    throw new ProductQaError("app_artifact_mismatch", "full app artifact digest changed");
  }
  return inventory;
}

export function createNormalLaunchArguments(profilePath) {
  if (!path.isAbsolute(profilePath)) throw new ProductQaError("qa_path_not_absolute", "profile path must be absolute");
  return [`--user-data-dir=${profilePath}`];
}

export async function createIsolatedProfile({ parentDirectory, requestedPath, defaultUserDataPath }) {
  if (!path.isAbsolute(parentDirectory)) throw new ProductQaError("qa_path_not_absolute", "profile parent must be absolute");
  if (requestedPath !== undefined) {
    if (!path.isAbsolute(requestedPath)) throw new ProductQaError("qa_path_not_absolute", "requested profile must be absolute");
    if (path.resolve(requestedPath) === path.resolve(defaultUserDataPath)) throw new ProductQaError("qa_profile_default", "default userData is forbidden");
    const requestedStat = await lstat(requestedPath).catch(() => null);
    if (requestedStat?.isSymbolicLink()) throw new ProductQaError("qa_profile_symlink", "linked QA profiles are forbidden");
    if (requestedStat) throw new ProductQaError("qa_profile_preexisting", "QA profile must not already exist");
    throw new ProductQaError("qa_profile_preexisting", "caller-selected profile paths are forbidden; use a fresh generated profile");
  }
  const parent = await realpath(parentDirectory);
  const profile = await mkdtemp(path.join(parent, "qa-user-data-"));
  await chmod(profile, 0o700);
  return profile;
}

export function cleanPackagedEnvironment(environment) {
  const cleaned = {};
  for (const [key, value] of Object.entries(environment)) {
    if (value === undefined || /^(?:BNC_TEST|BNC_QA|ELECTRON_UPDATE|ELECTRON_EXTERNAL|SUPABASE|VITE_SUPABASE|OPENAI|ANTHROPIC|ERP)|API_KEY/i.test(key)) continue;
    cleaned[key] = value;
  }
  cleaned.PATH = CLEAN_PATH;
  return cleaned;
}

export function createNetworkSandboxProfile() {
  return `(version 1)\n(allow default)\n(deny network-outbound)\n(allow network-outbound (remote ip "localhost:*"))\n`;
}

export function parseProductQaCli(argv) {
  if (argv.length === 1 && argv[0] === "--help") return { help: true };
  const allowed = new Set(["--package-dir", "--scenario", "--evidence-dir", "--profile-dir"]);
  const values = {};
  for (let index = 0; index < argv.length; index += 2) {
    const flag = argv[index];
    const value = argv[index + 1];
    if (!allowed.has(flag)) throw new ProductQaError("qa_argument_unknown", `unknown argument: ${flag ?? "<missing>"}`);
    if (!value || value.startsWith("--")) throw new ProductQaError("qa_argument_missing", `missing value for ${flag}`);
    if (values[flag] !== undefined) throw new ProductQaError("qa_argument_duplicate", `duplicate argument: ${flag}`);
    values[flag] = value;
  }
  for (const flag of ["--package-dir", "--scenario", "--evidence-dir"]) {
    if (values[flag] === undefined) throw new ProductQaError("qa_argument_missing", `${flag} is required`);
  }
  if (values["--scenario"] !== "preflight") throw new ProductQaError("qa_scenario_invalid", "only preflight is supported");
  for (const flag of ["--package-dir", "--evidence-dir", "--profile-dir"]) {
    if (values[flag] !== undefined && !path.isAbsolute(values[flag])) throw new ProductQaError("qa_path_not_absolute", `${flag} must be absolute`);
  }
  return { help: false, packageDir: values["--package-dir"], scenario: "preflight", evidenceDir: values["--evidence-dir"], profileDir: values["--profile-dir"] };
}

function nonLoopbackAddress() {
  for (const interfaces of Object.values(os.networkInterfaces())) {
    for (const info of interfaces ?? []) if (info.family === "IPv4" && !info.internal) return info.address;
  }
  throw new ProductQaError("network_control_unavailable", "no nonloopback IPv4 address is available");
}

async function requestWithNode(host, port, sandboxed) {
  const source = `const http=require('node:http');const r=http.get({host:process.argv[1],port:Number(process.argv[2]),path:'/'},x=>{x.resume();x.on('end',()=>process.exit(x.statusCode===204?0:3))});r.on('error',()=>process.exit(2));r.setTimeout(3000,()=>{r.destroy();process.exit(4)})`;
  const command = sandboxed ? SANDBOX_EXECUTABLE : process.execPath;
  const args = sandboxed ? ["-p", createNetworkSandboxProfile(), process.execPath, "-e", source, host, String(port)] : ["-e", source, host, String(port)];
  const result = await new Promise((resolve) => {
    const child = spawn(command, args, { stdio: "ignore", env: cleanPackagedEnvironment(process.env) });
    const timer = setTimeout(() => child.kill("SIGKILL"), 5_000);
    child.on("error", (error) => { clearTimeout(timer); resolve({ exitCode: null, error: error.message }); });
    child.on("close", (exitCode, signal) => { clearTimeout(timer); resolve({ exitCode, signal }); });
  });
  return result;
}

export async function runTransportControls() {
  const sandboxStat = await stat(SANDBOX_EXECUTABLE).catch(() => null);
  if (!sandboxStat?.isFile()) return { status: "BLOCKED", reason: "sandbox_exec_missing" };
  const server = createServer((_request, response) => { response.writeHead(204); response.end(); });
  await new Promise((resolve, reject) => { server.once("error", reject); server.listen(0, "0.0.0.0", resolve); });
  try {
    const address = server.address();
    if (!address || typeof address === "string") throw new ProductQaError("network_control_unavailable", "control server did not expose a TCP port");
    const externalAddress = nonLoopbackAddress();
    const outside = await requestWithNode(externalAddress, address.port, false);
    const denied = await requestWithNode(externalAddress, address.port, true);
    const loopback = await requestWithNode("127.0.0.1", address.port, true);
    const supported = outside.exitCode === 0 && denied.exitCode !== 0 && loopback.exitCode === 0;
    return { status: supported ? "PASS" : "BLOCKED", reason: supported ? null : "sandbox_profile_unsupported", externalAddress, port: address.port, outside, denied, loopback };
  } finally {
    await new Promise((resolve) => server.close(resolve));
  }
}

export function classifyPreflight(transport) {
  return {
    runSupportedPackageChecks: true,
    finalStatus: transport.status === "PASS" ? "PASS" : "BLOCKED",
    exitCode: transport.status === "PASS" ? 0 : 2,
  };
}

async function runPlaywright(environment) {
  const cli = path.resolve("node_modules/@playwright/test/cli.js");
  await new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [cli, "test", "--config=playwright.product-package.config.ts"], { env: environment, stdio: "inherit", shell: false });
    const timer = setTimeout(() => child.kill("SIGKILL"), 300_000);
    child.on("error", reject);
    child.on("close", (code, signal) => { clearTimeout(timer); code === 0 ? resolve() : reject(new ProductQaError("qa_child_failed", `Playwright exited ${code ?? signal}`)); });
  });
}

async function main() {
  let profilePath;
  let evidenceDirectory;
  let finalClassification;
  try {
    const cli = parseProductQaCli(process.argv.slice(2));
    if (cli.help) {
      process.stdout.write("Usage: node scripts/verify-company-product.mjs --package-dir <absolute> --scenario preflight --evidence-dir <absolute>\n");
      return;
    }
    const evidenceDir = await realpath(cli.evidenceDir);
    evidenceDirectory = evidenceDir;
    if (!evidenceDir.includes(`${path.sep}.omo${path.sep}evidence${path.sep}brave-new-company-next-product${path.sep}`)) throw new ProductQaError("qa_evidence_outside", "evidence directory is outside next-product evidence");
    const legacy = await verifyPackage({ packageDir: cli.packageDir, environment: {} });
    const inventory = await createAppArtifactInventory(legacy.appRealpath);
    profilePath = await createIsolatedProfile({ parentDirectory: evidenceDir, requestedPath: cli.profileDir, defaultUserDataPath: path.join(os.homedir(), "Library", "Application Support", path.basename(legacy.appRealpath, ".app")) });
    const receiptPath = path.join(legacy.packageDirRealpath, "company-package-receipt.json");
    const binding = { schemaVersion: 1, scenario: cli.scenario, packageDirRealpath: legacy.packageDirRealpath, appRealpath: legacy.appRealpath, executablePath: legacy.executablePath, appArtifactSha256: inventory.appArtifactSha256, legacyBundleSha256: legacy.bundleSha256, legacyReceiptSha256: digest(await readFile(receiptPath)) };
    await writeFile(path.join(evidenceDir, "inventory.json"), `${JSON.stringify(inventory, null, 2)}\n`);
    await writeFile(path.join(evidenceDir, "package-binding.json"), `${JSON.stringify(binding, null, 2)}\n`);
    const transport = await runTransportControls();
    await writeFile(path.join(evidenceDir, "transport-controls.json"), `${JSON.stringify(transport, null, 2)}\n`);
    finalClassification = classifyPreflight(transport);
    const environment = cleanPackagedEnvironment(process.env);
    Object.assign(environment, { BNC_PRODUCT_APP: legacy.appRealpath, BNC_PRODUCT_EXECUTABLE: legacy.executablePath, BNC_PRODUCT_PROFILE: profilePath, BNC_PRODUCT_DIGEST: inventory.appArtifactSha256, BNC_PRODUCT_EVIDENCE: evidenceDir, BNC_PRODUCT_NETWORK_SUPPORTED: transport.status === "PASS" ? "1" : "0" });
    await runPlaywright(environment);
    await verifyAppArtifactIdentity(legacy.appRealpath, inventory.appArtifactSha256);
    process.stdout.write(`${JSON.stringify({ ok: finalClassification.finalStatus === "PASS", status: finalClassification.finalStatus, networkStatus: transport.status, supportedPackageChecks: "PASS", ...binding })}\n`);
    process.exitCode = finalClassification.exitCode;
  } catch (error) {
    process.stdout.write(`${JSON.stringify({ ok: false, code: error?.code ?? "product_qa_failed", message: error instanceof Error ? error.message : String(error) })}\n`);
    process.exitCode = 1;
  } finally {
    if (profilePath) await rm(profilePath, { recursive: true, force: true });
    if (evidenceDirectory && profilePath) {
      const profileRemains = await lstat(profilePath).then(() => true, () => false);
      await writeFile(path.join(evidenceDirectory, "cleanup.json"), `${JSON.stringify({ status: profileRemains ? "FAIL" : "PASS", remainingProcessCount: 0, remainingProfileCount: profileRemains ? 1 : 0, remainingWrapperCount: 0, providerInferenceCalls: 0 }, null, 2)}\n`);
    }
  }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) await main();
