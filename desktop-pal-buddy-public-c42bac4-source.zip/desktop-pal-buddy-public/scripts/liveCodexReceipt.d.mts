export type LiveProgressPhase =
  | "discovery_started"
  | "discovery_ready"
  | "electron_launched"
  | "request_submitted"
  | "provider_returned"
  | "proposal_rendered"
  | "approval_recorded"
  | "mutation_verified"
  | "explanation_provider_returned"
  | "learning_published"
  | "second_request_submitted"
  | "second_provider_returned"
  | "reuse_rendered";
export type LiveTerminalPhase = "completed" | "failure_rendered" | "timeout" | "blocked";
export type LiveTerminalPhaseSnapshot = {
  terminalPhase: LiveTerminalPhase | null;
  lastCompletedPhase: LiveProgressPhase;
  providerReturned: boolean;
  phaseHistory: Array<LiveProgressPhase | LiveTerminalPhase>;
};
export type LiveFailureBoundary = "first_provider_terminal_surface" | "post_approval_apply_readback";
export type NormalizedLiveFailure = {
  terminalPhase: "timeout" | "blocked";
  failure: {
    name: "TimeoutError" | "Error";
    category: "ui_selector_timeout" | "bounded_timeout" | "bounded_failure";
    boundary: LiveFailureBoundary | LiveProgressPhase;
    timeoutMs?: number;
    observable: string;
  };
};
export function createLiveTerminalPhaseTracker(): {
  advance(phase: LiveProgressPhase): void;
  terminate(phase: LiveTerminalPhase): void;
  snapshot(): LiveTerminalPhaseSnapshot;
};
export function normalizeLiveFailure(
  error: unknown,
  context:
    | { kind: "selector_deadline"; boundary: LiveFailureBoundary; timeoutMs: number }
    | { kind: "unexpected"; boundary: LiveProgressPhase },
): NormalizedLiveFailure;
export function serializeRedactedLiveReceipt(receipt: Record<string, unknown>): string;
export function writeRedactedLiveReceipt(filePath: string, receipt: Record<string, unknown>): Promise<void>;
