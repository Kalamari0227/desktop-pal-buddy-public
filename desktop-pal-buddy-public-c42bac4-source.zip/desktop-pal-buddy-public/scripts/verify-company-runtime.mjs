#!/usr/bin/env node

import { existsSync, linkSync, mkdirSync, readFileSync, readdirSync, statSync, unlinkSync, writeFileSync } from "node:fs";
import { dirname, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
import { execFileSync } from "node:child_process";
import { computeCodeTreeDigest, verifyPackage } from "./verify-company-package.mjs";
import { createHash } from "node:crypto";

const APPROVED_SOURCE_CONTRACTS = [
  ["desktop-pal-buddy", "90d0bb2eb120ffade837b73697eca9380ae6319f", ["11", "12", "13", "20", "21"]],
  ["agent-skill-registry-ai-agent-capability-catalog", "a8c39697ec4f42099392dbb17de6c0da71452033", ["3", "6", "18"]],
  ["prism-insight-hub", "01b6ec878096dfb21c303bcce7852d9b1a367ace", ["6", "12", "19"]],
  ["Project_Prism", "800233a6a005cb1a4dbf61f8c80e9d439d259f1e", ["6", "7", "8", "9"]],
  ["posco-marketing-hub", "d5f02cb3b645ee22978fde5be8486845c3a5b478", ["3", "11"]],
  ["steelflow-b2b-sales-pipeline", "55b2342a71e7de4f1ddcbe82724902abc7c8f113", ["3", "6"]],
  ["quoteforge-steel-proposal-workspace", "c6c5477ce10d36f30b622f0986fcb538690a1972", ["3", "6", "12"]],
  ["project-minerva", "161ddd367a72cc81722f725e9a6a5cc2fe4b27ca", ["7", "9", "14", "22"]],
  ["opendart", "6824f75defc9cbc981143c4e23d7b82b9073a1bb", ["5", "9", "23"]],
  ["ex-cortex-knowledge-canvas", "f11e4abc14c93c1ffff2ae02bf3452816db3b902", ["16", "20", "21"]],
  ["our_room", "7afbbc764e29c696b5191bb6d6d27256a83d8a74", ["16", "17", "18"]],
  ["archive-wiki-backup", "506b5c723b52d97aabf5d7a2ef3c4f780b4655d0", ["2", "3", "4", "17", "18", "19", "20"]],
  ["canvas-pathway", "8a9e78171c25874e75bc65cf1340eaa7c8bbe437", ["20", "21"]],
  ["OS_EIDOLON", "bd98e0a27cb0dc6c231893859c1a0ab3df822f33", ["2", "15", "21", "22", "23", "24", "25"]],
  ["proofmark-ai", "f8518e9be5867c71156cbb4d382da0d8663af32b", ["1", "2", "22", "23", "24", "25"]],
  ["finlit-learn-finance-backend", "f30eb5bc575a12dda0d85ce6d90f6d586f13e94b", ["12", "21"]],
  ["naver-property", "93e38991c7aab71d98648100c3135466c297e950", ["12", "13", "21"]],
  ["show-ur-brain", "02d0edcfd9f035975b4e65f51de69b983d1cfea0", ["2", "25"]],
].map(([id, sha, tasks]) => ({ id, sha, tasks }));

const APPROVED_TASK_NUMBERS = new Set(Array.from({ length: 25 }, (_, index) => String(index + 1)));
const ALLOWED_SOURCE_STATUSES = new Set(["planned", "adapted", "verified", "deferred"]);
const REQUIRED_DOCS = ["architecture.md", "source-map.md", "virtual-business-rules.md", "verification.md"];
const EXPECTED_SOURCE_IDS = new Set(APPROVED_SOURCE_CONTRACTS.map((source) => source.id));
const FINAL_REVIEW_IDS = ["F1", "F2", "F3", "F4"];
const COMPONENT_IDS = ["C1", "C2", "C3", "C4", "C5", "C6"];
const COMPONENT_RUNTIME_MODES = new Set(["stub", "live", "not_applicable"]);
const PLAN_RELATIVE_PATH = ".omo/plans/brave-new-company-future-erp.md";
const TASK23_NATIVE_RECEIPT_ROOT = "task-23/native-fallback-7ce405a";
const TASK24_PACKAGE_RECEIPT_ROOT = "task-24/package-fallback-7ce405a";

const COMPONENT_CONTRACTS = [
  {
    id: "C1",
    status: "PASS",
    evidence: [
      [12, "npm test -- src/components/workspace/CompanyRequestPanel.test.tsx src/components/workspace/GatewayMode.test.tsx", 0, ["AI candidate/fact separation and clarification gating passed."], "stub"],
      [15, "npm run test:electron -- --grep 'first-flow|restart'", 0, ["Native stub approval, apply, readback, and restart flow passed."], "stub"],
      [23, "npm run test:electron:live -- --project=electron-live", 0, ["Signed-in native live scenario completed with actual AI, approval-gated virtual apply, matching readback, evidence-backed explanation, and shared-learning reuse."], "live"],
      [24, "npm run test:package:live -- --package-dir <attemptDir>/package", 0, ["Packaged live receipt records actual AI, evidence-backed explanation, matching readback, and two provider calls."], "live"],
    ],
  },
  {
    id: "C2",
    status: "PASS",
    evidence: [
      [3, "npm test -- src/lib/company-runtime/schemas.test.ts src/lib/agentic/contractDocumentation.test.ts", 0, ["Strict runtime contracts and production-state authority probes passed."], "not_applicable"],
      [6, "node .omo/evidence/brave-new-company-future-erp/task-6-library-qa.mjs", 0, ["assess-order-priority@1 returned the proposed order and preserved the input hash."], "not_applicable"],
    ],
  },
  {
    id: "C3",
    status: "PASS",
    evidence: [
      [7, "npm test -- src/lib/company-runtime/policy.test.ts", 0, ["Immutable shadow, canonical bindings, and fail-closed apply controls passed."], "not_applicable"],
      [8, "npm test -- src/lib/company-runtime/approval.test.ts src/lib/company-runtime/policy.test.ts src/lib/company-runtime/schemas.test.ts", 0, ["Approval contract and all 16 failure cases preserved the unchanged ERP state."], "not_applicable"],
      [9, "npm test -- electron/companyRuntime.test.ts electron/companyPersistence.test.ts src/lib/company-runtime src/lib/agentic", 0, ["Persisted approval, execution, readback, stale-state, and recovery tests passed."], "stub"],
      [10, "npm test -- electron/companyIpc.test.ts electron/companyRuntime.test.ts electron/shellValidation.test.ts src/lib/companyRuntimeClient.test.ts src/hooks/useCompanyRuntime.test.ts", 0, ["Validated IPC authority, payload, sender, and stale-response guards passed."], "stub"],
      [13, "npm test -- src/components/workspace/CompanyTaskPanel.test.tsx src/components/workspace/TasksMode.test.tsx", 0, ["Approval expiry, readback, and execution controls remained bounded to the runtime task."], "stub"],
      [14, "npm test -- src/components/workspace/CompanyRuntimeControls.test.tsx", 0, ["Stop, read, resume, reset, role, and late-reply controls passed."], "stub"],
      [15, "npm run test:electron -- --grep 'first-flow|restart'", 0, ["Native stub approval and one bounded virtual apply passed."], "stub"],
    ],
  },
  {
    id: "C4",
    status: "PASS",
    evidence: [
      [4, "npm test -- electron/companyPersistence.test.ts", 0, ["Persistence, restart, stale revision, mandatory event, and corruption guards passed."], "not_applicable"],
      [9, "node .omo/evidence/brave-new-company-future-erp/task-9-qa.mjs", 0, ["Filesystem QA observed durable execution/readback and removed its temporary roots."], "stub"],
      [13, "npm test -- src/components/workspace/CompanyTaskPanel.test.tsx src/components/workspace/TasksMode.test.tsx", 0, ["Confirmed execution and unobserved business outcome remained distinct."], "stub"],
      [15, "npm run test:electron -- --grep 'first-flow|restart'", 0, ["Native restart retained execution, approval, and readback evidence."], "stub"],
      [22, "npm run test:electron -- --grep 'fault|guard|consent'", 0, ["Native fault, guard, consent, and recovery cases preserved the original record."], "stub"],
    ],
  },
  {
    id: "C5",
    status: "PASS",
    evidence: [
      [16, "npm run build:runtime && npm test -- src/lib/company-runtime/experience.test.ts electron/companyRuntime.test.ts electron/companyIpc.test.ts src/lib/companyRuntimeClient.test.ts src/components/workspace/CompanyTaskPanel.test.tsx src/components/workspace/ExperiencePanel.test.tsx", 0, ["Private experience drafts and selected readback asset/version passed."], "not_applicable"],
      [17, "npm test", 0, ["Scoped sharing/withdrawal coverage passed with providerCalls=0 and no ERP mutation."], "stub"],
      [18, "node .omo/evidence/brave-new-company-future-erp/task-18-library-qa.mjs", 0, ["Matching shared learning selected only the missing packaging check."], "not_applicable"],
      [19, "npm run test:electron -- --grep 'cross-department-reuse'", 0, ["Cross-department reuse persisted the added inspection/shipment evidence without mutation."], "stub"],
      [22, "npm run test:electron -- --grep 'fault|guard|consent'", 0, ["Consent and withdrawal guards passed without provider calls."], "stub"],
    ],
  },
  {
    id: "C6",
    status: "PASS",
    evidence: [
      [20, "npm test -- src/lib/company-runtime/strategyReview.test.ts src/components/workspace/StrategyReviewPanel.test.tsx", 0, ["Explicit strategy v2 review persisted while active v1 and prior work remained unchanged."], "stub"],
      [21, "npm run test:electron -- --grep 'lineage'", 0, ["Lineage navigation review and exact-SHA regression evidence were recorded."], "stub"],
    ],
  },
];

const COMPONENT_TASKS = new Map(COMPONENT_CONTRACTS.map((component) => [
  component.id,
  new Set(component.evidence.map(([taskId]) => taskId)),
]));

function parseArgs(argv) {
  let docsOnly = false;
  let docsRoot;
  let packageDir;
  let phase;
  let evidenceDir;
  let writePreFinal;
  let preFinal;
  let reviewDir;
  let writeFinal;

  for (let index = 0; index < argv.length; index += 1) {
    const argument = argv[index];
    if (argument === "--docs-only") {
      docsOnly = true;
      continue;
    }
    if (argument === "--docs-root") {
      const value = argv[index + 1];
      if (!value || value.startsWith("--")) {
        throw new Error("--docs-root requires a directory");
      }
      docsRoot = value;
      index += 1;
      continue;
    }
    if (argument === "--package-dir") {
      const value = argv[index + 1];
      if (!value || value.startsWith("--")) throw new Error("--package-dir requires a directory");
      packageDir = value;
      index += 1;
      continue;
    }
    if (argument === "--phase") {
      const value = argv[index + 1];
      if (!value || value.startsWith("--")) throw new Error("--phase requires a value");
      phase = value;
      index += 1;
      continue;
    }
    if (argument === "--evidence-dir") {
      const value = argv[index + 1];
      if (!value || value.startsWith("--")) throw new Error("--evidence-dir requires a directory");
      evidenceDir = value;
      index += 1;
      continue;
    }
    if (argument === "--write-pre-final") {
      const value = argv[index + 1];
      if (!value || value.startsWith("--")) throw new Error("--write-pre-final requires a file");
      writePreFinal = value;
      index += 1;
      continue;
    }
    if (argument === "--pre-final") {
      const value = argv[index + 1];
      if (!value || value.startsWith("--")) throw new Error("--pre-final requires a file");
      preFinal = value;
      index += 1;
      continue;
    }
    if (argument === "--review-dir") {
      const value = argv[index + 1];
      if (!value || value.startsWith("--")) throw new Error("--review-dir requires a directory");
      reviewDir = value;
      index += 1;
      continue;
    }
    if (argument === "--write-final") {
      const value = argv[index + 1];
      if (!value || value.startsWith("--")) throw new Error("--write-final requires a file");
      writeFinal = value;
      index += 1;
      continue;
    }
    throw new Error(`unknown argument: ${argument}`);
  }

  if (phase && !["implementation", "final"].includes(phase)) throw new Error(`unsupported phase: ${phase}`);
  if (phase === "implementation" && (!evidenceDir || packageDir || docsOnly || preFinal || reviewDir || writeFinal)) {
    throw new Error("implementation phase requires --evidence-dir and cannot be combined with docs-only or package-dir");
  }
  if (phase === "final" && (!preFinal || !reviewDir || !writeFinal || evidenceDir || writePreFinal || packageDir || docsOnly)) {
    throw new Error("final phase requires --pre-final, --review-dir, and --write-final exclusively");
  }
  if (writePreFinal && phase !== "implementation") throw new Error("--write-pre-final requires --phase implementation");
  if ((preFinal || reviewDir || writeFinal) && phase !== "final") {
    throw new Error("--pre-final, --review-dir, and --write-final require --phase final");
  }
  if (!docsOnly && !packageDir) {
    if (!phase) throw new Error("--docs-only is required; runtime phase verification belongs to later tasks");
  }
  if (docsOnly && packageDir) throw new Error("choose exactly one verification mode");
  return { docsOnly, docsRoot, packageDir, phase, evidenceDir, writePreFinal, preFinal, reviewDir, writeFinal };
}

function readRequiredDocuments(docsRoot, errors) {
  const documents = {};
  for (const filename of REQUIRED_DOCS) {
    const filePath = resolve(docsRoot, filename);
    try {
      if (!statSync(filePath).isFile()) {
        errors.push({ code: "missing_document", document: filename });
        continue;
      }
      documents[filename] = readFileSync(filePath, "utf8");
    } catch {
      errors.push({ code: "missing_document", document: filename });
    }
  }
  return documents;
}

function requireText(errors, document, text, required, label) {
  if (!text.includes(required)) {
    errors.push({ code: "missing_contract", document, contract: label, required });
  }
}

function validateDocumentationContracts(documents, errors) {
  const architecture = documents["architecture.md"] ?? "";
  const rules = documents["virtual-business-rules.md"] ?? "";
  const verification = documents["verification.md"] ?? "";

  for (const responsibility of ["C1", "C2", "C3", "C4", "C5", "C6"]) {
    requireText(errors, "architecture.md", architecture, responsibility, `responsibility_${responsibility}`);
  }
  requireText(errors, "architecture.md", architecture, "Electron **main**", "main_authority");
  requireText(errors, "architecture.md", architecture, "## 비목표", "non_goals");
  requireText(errors, "architecture.md", architecture, "명시 reset", "reset_policy");
  requireText(errors, "architecture.md", architecture, "publish/withdraw", "consent_and_withdrawal_policy");

  for (const value of [
    "SO-DEMO-1001",
    "PP-DEMO-1001",
    "20,000kg",
    "25,000kg",
    "5 → 1",
    "PP-DEMO-1002(priority=2)",
    "PP-DEMO-1003(priority=3)",
    "1002 → 1003 → 1001",
    "1001 → 1002 → 1003",
    "qualityHold=true",
    "already_satisfied",
  ]) {
    requireText(errors, "virtual-business-rules.md", rules, value, `business_rule_${value}`);
  }
  requireText(errors, "verification.md", verification, "--docs-only", "docs_only_consumer_api");
  requireText(errors, "verification.md", verification, "exit 1", "failure_exit_contract");
}

function parseVisibleSourceRows(sourceMap, errors) {
  const rows = [];
  for (const line of sourceMap.split("\n")) {
    if (!line.startsWith("|") || line.startsWith("| ID ") || line.startsWith("|---")) {
      continue;
    }
    const cells = line.split("|").slice(1, -1).map((cell) => cell.trim());
    if (cells.length !== 8) {
      errors.push({ code: "invalid_visible_source_row", row: line });
      continue;
    }
    const [id, status, sha, responsibility, modules, tasks, verification, nonGoals] = cells;
    rows.push({ id, sha, status, tasks, responsibility, modules, verification, nonGoals });
  }
  return rows;
}

function normalizeTasks(value) {
  return value.split(",").map((task) => task.trim()).filter(Boolean);
}

function sameTaskSet(actual, expected) {
  return actual.length === expected.length
    && actual.every((task, index) => task === expected[index]);
}

function validateSourceRows(sourceMap, errors) {
  const rows = parseVisibleSourceRows(sourceMap, errors);

  const byId = new Map();
  for (const row of rows) {
    if (byId.has(row.id)) {
      errors.push({ code: "duplicate_source_row", source: row.id });
    }
    byId.set(row.id, row);
  }

  for (const source of APPROVED_SOURCE_CONTRACTS) {
    const row = byId.get(source.id);
    if (!row) {
      errors.push({ code: "missing_source_row", source: source.id });
      continue;
    }
    if (!row.sha) {
      errors.push({ code: "missing_source_sha", source: source.id });
    } else if (!/^[a-f0-9]{40}$/.test(row.sha)) {
      errors.push({ code: "invalid_source_sha", source: source.id, sha: row.sha });
    } else if (row.sha !== source.sha) {
      errors.push({ code: "source_sha_mismatch", source: source.id, expected: source.sha, actual: row.sha });
    }
    if (!row.status || !ALLOWED_SOURCE_STATUSES.has(row.status)) {
      errors.push({ code: "invalid_source_status", source: source.id, status: row.status ?? null });
    }
    for (const [field, value] of Object.entries({
      responsibility: row.responsibility,
      modules: row.modules,
      verification: row.verification,
      non_goals: row.nonGoals,
    })) {
      if (!value) {
        errors.push({ code: "missing_source_field", source: source.id, field });
      }
    }
    if (!row.tasks) {
      errors.push({ code: "missing_source_tasks", source: source.id });
      continue;
    }
    const tasks = normalizeTasks(row.tasks);
    for (const task of tasks) {
      if (!APPROVED_TASK_NUMBERS.has(task)) {
        errors.push({ code: "invalid_source_task", source: source.id, task });
      }
    }
    if (!sameTaskSet(tasks, source.tasks)) {
      errors.push({ code: "source_task_mapping_mismatch", source: source.id, expected: source.tasks, actual: tasks });
    }
  }

  for (const row of rows) {
    if (!EXPECTED_SOURCE_IDS.has(row.id)) {
      errors.push({ code: "unexpected_source_row", source: row.id });
    }
  }

  return rows;
}

function runDocsOnly(docsRoot) {
  const errors = [];
  const documents = readRequiredDocuments(docsRoot, errors);
  validateDocumentationContracts(documents, errors);
  const rows = validateSourceRows(documents["source-map.md"] ?? "", errors);
  return {
    ok: errors.length === 0,
    mode: "docs-only",
    docsRoot,
    sourceRows: rows.length,
    expectedSourceRows: APPROVED_SOURCE_CONTRACTS.length,
    errors,
  };
}

function sha256File(path) {
  return createHash("sha256").update(readFileSync(path)).digest("hex");
}

function validateTaskEvidenceManifest(root, evidenceSearchRoot, errors) {
  const manifestPath = resolve(root, "task-25-task-evidence-manifest.json");
  const manifest = readJson(manifestPath, errors, "task_evidence_manifest");
  if (!manifest) return null;
  if (manifest.schemaVersion !== 1 || manifest.contract !== "task-1-24-exact-sha-known-artifact" || !Array.isArray(manifest.records)) {
    errors.push({ code: "task_evidence_manifest_contract_failed", path: manifestPath });
    return null;
  }
  const records = manifest.records;
  const tasks = records.map((record) => record?.task).sort((left, right) => left - right);
  const expectedTasks = Array.from({ length: 24 }, (_, index) => index + 1);
  if (records.length !== 24 || tasks.some((task, index) => task !== expectedTasks[index])) {
    errors.push({ code: "task_evidence_manifest_tasks_failed", expected: expectedTasks, actual: tasks });
  }
  const shaPattern = /^[0-9a-f]{40}$/i;
  for (const record of records) {
    const artifact = typeof record?.path === "string" ? resolve(evidenceSearchRoot, record.path) : null;
    if (!artifact || !existsSync(artifact) || !statSync(artifact).isFile() || statSync(artifact).size === 0) {
      errors.push({ code: "task_evidence_artifact_missing", task: record?.task ?? null, path: artifact ?? record?.path ?? null });
      continue;
    }
    if (!shaPattern.test(record.exactSha ?? "")) {
      errors.push({ code: "task_evidence_exact_sha_invalid", task: record.task, exactSha: record.exactSha ?? null });
    }
    const contents = readFileSync(artifact, "utf8");
    if (!contents.includes(record.exactSha)) {
      errors.push({ code: "task_evidence_exact_sha_not_in_artifact", task: record.task, path: artifact, exactSha: record.exactSha });
    }
    const actualSha256 = sha256File(artifact);
    if (actualSha256 !== record.sha256) {
      errors.push({ code: "task_evidence_artifact_hash_mismatch", task: record.task, path: artifact, expected: record.sha256, actual: actualSha256 });
    }
  }
  return manifest;
}

function buildComponents(taskEvidenceManifest, liveContractPassed) {
  const records = new Map((taskEvidenceManifest?.records ?? []).map((record) => [record.task, record]));
  return COMPONENT_CONTRACTS.map((component) => ({
    id: component.id,
    // C1 is only complete when the native and package live receipts both
    // validate against this invocation's exact commit.
    status: component.id === "C1" && !liveContractPassed ? "BLOCKED" : component.status,
    evidence: component.evidence.map(([taskId, command, exitCode, assertions, runtimeMode]) => {
      const record = records.get(taskId);
      return {
        taskId,
        path: record?.path ?? null,
        sha256: record?.sha256 ?? null,
        command,
        exitCode,
        assertions,
        runtimeMode,
      };
    }),
  }));
}

function taskEvidenceContract(taskId, evidenceDir) {
  for (const component of COMPONENT_CONTRACTS) {
    const evidence = component.evidence.find(([candidateTaskId]) => candidateTaskId === taskId);
    if (evidence) return evidence;
  }
  return [
    taskId,
    `npm run verify:company -- --phase implementation --evidence-dir ${evidenceDir}`,
    0,
    [`Task ${taskId} evidence artifact passed exact path and SHA-256 validation.`],
    "not_applicable",
  ];
}

function buildTasks(taskEvidenceManifest, root, liveContractPassed) {
  const manifestRecords = new Map((taskEvidenceManifest?.records ?? []).map((record) => [record.task, record]));
  const records = Array.from({ length: 24 }, (_, index) => {
    const taskId = index + 1;
    const manifestRecord = manifestRecords.get(taskId);
    const [, command, exitCode, assertions, runtimeMode] = taskEvidenceContract(taskId, root);
    return {
      taskId,
      // Task23 is the native half of C1.  Do not project a static PASS when
      // any live receipt fails its exact-SHA, provider, readback, or cleanup
      // contract.
      status: taskId === 23 && !liveContractPassed ? "BLOCKED" : "PASS",
      evidence: [{
        taskId,
        path: manifestRecord?.path ?? null,
        sha256: manifestRecord?.sha256 ?? null,
        command,
        exitCode,
        assertions,
        runtimeMode,
      }],
    };
  });
  const task25Artifact = resolve(root, "implementation-report.md");
  records.push({
    taskId: 25,
    status: "PASS",
    evidence: [{
      taskId: 25,
      path: "task-25/implementation-report.md",
      sha256: existsSync(task25Artifact) ? sha256File(task25Artifact) : null,
      command: `npm run verify:company -- --phase implementation --evidence-dir ${root}`,
      exitCode: 0,
      assertions: ["Task 25 implementation handoff exists and is bound to its current SHA-256."],
      runtimeMode: "not_applicable",
    }],
  });
  return { required: 25, evidenceTasks: 24, records };
}

function validateTaskRecords(tasks, taskEvidenceManifest, evidenceSearchRoot, errors) {
  if (!tasks || typeof tasks !== "object" || Array.isArray(tasks) || !Array.isArray(tasks.records)) {
    errors.push({ code: "task_records_missing" });
    return;
  }
  if (tasks.records.length !== 25) {
    errors.push({ code: "task_record_count_mismatch", expected: 25, actual: tasks.records.length });
  }
  const manifestRecords = new Map((taskEvidenceManifest?.records ?? []).map((record) => [record.task, record]));
  const seenTaskIds = new Set();
  for (const record of tasks.records) {
    if (!record || typeof record !== "object" || Array.isArray(record)) {
      errors.push({ code: "task_record_invalid" });
      continue;
    }
    const { taskId } = record;
    if (!Number.isInteger(taskId) || taskId < 1 || taskId > 25) {
      errors.push({ code: "task_id_unexpected", taskId: taskId ?? null });
    } else {
      if (seenTaskIds.has(taskId)) errors.push({ code: "task_id_duplicate", taskId });
      seenTaskIds.add(taskId);
    }
    if (!["PASS", "FAIL", "BLOCKED"].includes(record.status)) {
      errors.push({ code: "task_status_invalid", taskId: taskId ?? null, status: record.status ?? null });
    }
    if (!Array.isArray(record.evidence) || record.evidence.length === 0) {
      errors.push({ code: "task_evidence_missing", taskId: taskId ?? null });
      continue;
    }
    for (const evidence of record.evidence) {
      if (!evidence || typeof evidence !== "object" || Array.isArray(evidence)) {
        errors.push({ code: "task_evidence_invalid", taskId: taskId ?? null });
        continue;
      }
      const { path, sha256, command, exitCode, assertions, runtimeMode } = evidence;
      if (evidence.taskId !== taskId) {
        errors.push({ code: "task_evidence_task_mismatch", taskId: taskId ?? null, evidenceTaskId: evidence.taskId ?? null });
      }
      if (typeof path !== "string" || path.length === 0) {
        errors.push({ code: "task_evidence_path_invalid", taskId: taskId ?? null });
      }
      if (typeof sha256 !== "string" || !/^[0-9a-f]{64}$/i.test(sha256)) {
        errors.push({ code: "task_evidence_hash_invalid", taskId: taskId ?? null, sha256: sha256 ?? null });
      }
      if (typeof command !== "string" || command.trim().length === 0) {
        errors.push({ code: "task_evidence_command_invalid", taskId: taskId ?? null });
      }
      if (!Number.isInteger(exitCode) || exitCode < 0) {
        errors.push({ code: "task_evidence_exit_code_invalid", taskId: taskId ?? null, exitCode: exitCode ?? null });
      }
      if (!Array.isArray(assertions) || assertions.length === 0 || assertions.some((assertion) => typeof assertion !== "string" || assertion.trim().length === 0)) {
        errors.push({ code: "task_evidence_assertions_invalid", taskId: taskId ?? null });
      }
      if (!COMPONENT_RUNTIME_MODES.has(runtimeMode)) {
        errors.push({ code: "task_evidence_runtime_mode_invalid", taskId: taskId ?? null, runtimeMode: runtimeMode ?? null });
      }

      const manifestRecord = manifestRecords.get(taskId);
      const expectedPath = taskId === 25 ? "task-25/implementation-report.md" : manifestRecord?.path;
      let expectedHash = manifestRecord?.sha256;
      if (taskId === 25 && evidenceSearchRoot) {
        const expectedArtifact = resolve(evidenceSearchRoot, expectedPath);
        expectedHash = existsSync(expectedArtifact) ? sha256File(expectedArtifact) : null;
      }
      if (taskId >= 1 && taskId <= 24 && !manifestRecord) {
        errors.push({ code: "task_evidence_manifest_task_missing", taskId });
      }
      if (expectedPath && path !== expectedPath) {
        errors.push({ code: "task_evidence_manifest_path_mismatch", taskId: taskId ?? null, expected: expectedPath, actual: path ?? null });
      }
      if (expectedHash && sha256 !== expectedHash) {
        errors.push({ code: "task_evidence_manifest_hash_mismatch", taskId: taskId ?? null, expected: expectedHash, actual: sha256 ?? null });
      }
      if (typeof path === "string" && path.length > 0 && evidenceSearchRoot) {
        const root = resolve(evidenceSearchRoot);
        const artifact = resolve(root, path);
        if (!artifact.startsWith(`${root}${sep}`)) {
          errors.push({ code: "task_evidence_path_invalid", taskId: taskId ?? null, path });
        } else if (!existsSync(artifact) || !statSync(artifact).isFile() || statSync(artifact).size === 0) {
          errors.push({ code: "task_evidence_artifact_missing", taskId: taskId ?? null, path: artifact });
        } else if (/^[0-9a-f]{64}$/i.test(sha256 ?? "")) {
          const actualSha256 = sha256File(artifact);
          if (sha256 !== actualSha256) {
            errors.push({ code: "task_evidence_artifact_hash_mismatch", taskId: taskId ?? null, path: artifact, expected: sha256, actual: actualSha256 });
          }
        }
      }
    }
  }
  for (let taskId = 1; taskId <= 25; taskId += 1) {
    if (!seenTaskIds.has(taskId)) errors.push({ code: "task_id_missing", taskId });
  }
}

function validateComponentEvidence(components, taskEvidenceManifest, errors) {
  if (!Array.isArray(components)) {
    errors.push({ code: "component_contract_missing" });
    return;
  }
  if (components.length !== COMPONENT_IDS.length) {
    errors.push({ code: "component_count_mismatch", expected: COMPONENT_IDS.length, actual: components.length });
  }

  const records = new Map((taskEvidenceManifest?.records ?? []).map((record) => [record.task, record]));
  const seenIds = new Set();
  for (const component of components) {
    if (!component || typeof component !== "object" || Array.isArray(component)) {
      errors.push({ code: "component_entry_invalid" });
      continue;
    }
    const { id } = component;
    if (!COMPONENT_IDS.includes(id)) {
      errors.push({ code: "component_id_unexpected", component: id ?? null });
      continue;
    }
    if (seenIds.has(id)) errors.push({ code: "component_id_duplicate", component: id });
    seenIds.add(id);
    if (!["PASS", "FAIL", "BLOCKED"].includes(component.status)) {
      errors.push({ code: "component_status_invalid", component: id, status: component.status ?? null });
    }
    if (!Array.isArray(component.evidence) || component.evidence.length === 0) {
      errors.push({ code: "component_evidence_missing", component: id });
      continue;
    }
    const expectedTaskIds = COMPONENT_TASKS.get(id) ?? new Set();
    const actualTaskIds = new Set();
    for (const evidence of component.evidence) {
      if (!evidence || typeof evidence !== "object" || Array.isArray(evidence)) {
        errors.push({ code: "component_evidence_invalid", component: id });
        continue;
      }
      const { taskId, path, sha256, command, exitCode, assertions, runtimeMode } = evidence;
      if (actualTaskIds.has(taskId)) errors.push({ code: "component_evidence_task_duplicate", component: id, taskId: taskId ?? null });
      actualTaskIds.add(taskId);
      if (!Number.isInteger(taskId) || taskId < 1 || taskId > 24) {
        errors.push({ code: "component_evidence_task_invalid", component: id, taskId: taskId ?? null });
      } else if (!COMPONENT_TASKS.get(id)?.has(taskId)) {
        errors.push({ code: "component_evidence_task_unmapped", component: id, taskId });
      }
      if (typeof path !== "string" || path.length === 0) {
        errors.push({ code: "component_evidence_path_invalid", component: id, taskId: taskId ?? null });
      }
      if (typeof sha256 !== "string" || !/^[0-9a-f]{64}$/i.test(sha256)) {
        errors.push({ code: "component_evidence_hash_invalid", component: id, taskId: taskId ?? null, sha256: sha256 ?? null });
      }
      if (typeof command !== "string" || command.trim().length === 0) {
        errors.push({ code: "component_evidence_command_invalid", component: id, taskId: taskId ?? null });
      }
      if (!Number.isInteger(exitCode) || exitCode < 0) {
        errors.push({ code: "component_evidence_exit_code_invalid", component: id, taskId: taskId ?? null, exitCode: exitCode ?? null });
      }
      if (!Array.isArray(assertions) || assertions.length === 0 || assertions.some((assertion) => typeof assertion !== "string" || assertion.trim().length === 0)) {
        errors.push({ code: "component_evidence_assertions_invalid", component: id, taskId: taskId ?? null });
      }
      if (!COMPONENT_RUNTIME_MODES.has(runtimeMode)) {
        errors.push({ code: "component_evidence_runtime_mode_invalid", component: id, taskId: taskId ?? null, runtimeMode: runtimeMode ?? null });
      }
      if (taskEvidenceManifest && Number.isInteger(taskId)) {
        const record = records.get(taskId);
        if (!record) {
          errors.push({ code: "component_evidence_manifest_task_missing", component: id, taskId });
        } else {
          if (path !== record.path) errors.push({ code: "component_evidence_manifest_path_mismatch", component: id, taskId, expected: record.path, actual: path });
          if (sha256 !== record.sha256) errors.push({ code: "component_evidence_manifest_hash_mismatch", component: id, taskId, expected: record.sha256, actual: sha256 });
        }
      }
    }
    if (actualTaskIds.size !== expectedTaskIds.size || [...actualTaskIds].some((taskId) => !expectedTaskIds.has(taskId))) {
      errors.push({ code: "component_evidence_task_set_mismatch", component: id, expected: [...expectedTaskIds], actual: [...actualTaskIds] });
    }
  }
  for (const id of COMPONENT_IDS) {
    if (!seenIds.has(id)) errors.push({ code: "component_id_missing", component: id });
  }
}

function readJson(path, errors, label) {
  try {
    const value = JSON.parse(readFileSync(path, "utf8"));
    return value;
  } catch (error) {
    errors.push({ code: "invalid_evidence_json", label, path, message: error instanceof Error ? error.message : String(error) });
    return null;
  }
}

function receiptValue(receipt, field) {
  return field.split(".").reduce((value, key) => value?.[key], receipt);
}

function validateReceiptFields(receipt, fields, code, label, errors) {
  if (!receipt) return;
  for (const [field, expected] of fields) {
    const actual = receiptValue(receipt, field);
    if (actual !== expected) errors.push({ code, label, field, expected, actual: actual ?? null });
  }
}

function validateExactShaArtifact(path, exactSha, label, errors) {
  try {
    const actual = readFileSync(path, "utf8").trim();
    if (actual !== exactSha) errors.push({ code: "live_receipt_sha_artifact_mismatch", label, path, expected: exactSha, actual });
  } catch (error) {
    errors.push({ code: "live_receipt_sha_artifact_missing", label, path, message: error instanceof Error ? error.message : String(error) });
  }
}

function validateTask23QuarantineConsistency(live, report, errors) {
  const liveValue = live?.quarantinedInterpretation;
  const reportField = report?.liveReceipt ? "liveReceipt.quarantinedInterpretation" : "secondRequest.quarantinedInterpretation";
  const reportValue = receiptValue(report, reportField);
  const code = "task23_native_quarantine_contract_failed";

  if (typeof liveValue !== "boolean") {
    errors.push({ code, label: "task23_native_live", field: "quarantinedInterpretation", expected: "boolean", actual: liveValue ?? null });
  }
  if (typeof reportValue !== "boolean") {
    errors.push({ code, label: "task23_native_report", field: reportField, expected: "boolean", actual: reportValue ?? null });
  }
  if (typeof liveValue === "boolean" && typeof reportValue === "boolean" && liveValue !== reportValue) {
    errors.push({ code, label: "task23_native_report", field: reportField, expected: liveValue, actual: reportValue });
  }
}

function validateTask23Report(report, exactSha, errors) {
  validateReceiptFields(report, [
    ["task", 23], ["commit", exactSha], ["exitCode", 0],
  ], "task23_native_report_contract_failed", "task23_native_report", errors);
  const verdict = report?.verdict ?? report?.status;
  if (verdict !== "PASS") {
    errors.push({ code: "task23_native_report_contract_failed", label: "task23_native_report", field: "verdict|status", expected: "PASS", actual: verdict ?? null });
  }

  if (report?.liveReceipt) {
    validateReceiptFields(report, [
      ["liveReceipt.live", true], ["liveReceipt.actualAI", true], ["liveReceipt.providerCalls", 3], ["liveReceipt.mutationCount", 1],
      ["liveReceipt.mutationAfterApproval", true], ["liveReceipt.readbackMatches", true], ["liveReceipt.toolEventCount", 0],
    ], "task23_native_report_contract_failed", "task23_native_report", errors);
    return;
  }

  validateReceiptFields(report, [
    ["live", true], ["actualAI", true], ["providerCalls", 3], ["terminalPhase", "completed"],
    ["assertions.mutationCount", 1], ["assertions.mutationAfterApproval", true], ["assertions.readbackMatches", true], ["assertions.toolEventCount", 0],
  ], "task23_native_report_contract_failed", "task23_native_report", errors);
}

function validateTask23Cleanup(cleanup, errors) {
  validateReceiptFields(cleanup, [
    ["task", 23], ["status", "PASS"], ["remainingTempDirectoryCount", 0], ["remainingBrowserCount", 0], ["removedUserDataDirectory", true],
  ], "task23_native_cleanup_contract_failed", "task23_native_cleanup", errors);
  if (cleanup?.remainingProcessCount !== undefined) {
    validateReceiptFields(cleanup, [["remainingProcessCount", 0]], "task23_native_cleanup_contract_failed", "task23_native_cleanup", errors);
    return;
  }
  validateReceiptFields(cleanup, [
    ["remainingProviderProcessCount", 0], ["remainingElectronProcessCount", 0], ["remainingPortCount", 0], ["recordedElectronPidAlive", false],
  ], "task23_native_cleanup_contract_failed", "task23_native_cleanup", errors);
}

function receiptSummary(paths, values) {
  return {
    ...paths,
    ...values,
    sha256: Object.fromEntries(Object.entries(paths).map(([name, path]) => [name, existsSync(path) ? sha256File(path) : null])),
  };
}

function validateTask23NativeReceipt(evidenceSearchRoot, exactSha, errors) {
  const root = resolve(evidenceSearchRoot, TASK23_NATIVE_RECEIPT_ROOT);
  const paths = {
    live: resolve(root, "live.json"),
    report: resolve(root, "report.json"),
    cleanup: resolve(root, "cleanup.json"),
    preRunHead: resolve(root, "pre-run-head.txt"),
    postRunHead: resolve(root, "post-run-head.txt"),
    commandExit: resolve(root, "command-exit.txt"),
    exitCode: resolve(root, "exit.code"),
  };
  const live = readJson(paths.live, errors, "task23_native_live");
  const report = readJson(paths.report, errors, "task23_native_report");
  const cleanup = readJson(paths.cleanup, errors, "task23_native_cleanup");
  validateReceiptFields(live, [
    ["task", 23], ["status", "PASS"], ["live", true], ["actualAI", true], ["providerCalls", 3],
    ["terminalPhase", "completed"], ["assertions.schemaValid", true], ["assertions.toolEventCount", 0],
    ["assertions.mutationCount", 1], ["assertions.mutationAfterApproval", true], ["assertions.readbackMatches", true],
    ["aiExplanationRendered", true],
  ], "task23_native_live_contract_failed", "task23_native_live", errors);
  validateTask23Report(report, exactSha, errors);
  validateTask23QuarantineConsistency(live, report, errors);
  validateTask23Cleanup(cleanup, errors);
  validateExactShaArtifact(paths.preRunHead, exactSha, "task23_native_pre_run_head", errors);
  validateExactShaArtifact(paths.postRunHead, exactSha, "task23_native_post_run_head", errors);
  validateExactShaArtifact(paths.commandExit, "0", "task23_native_command_exit", errors);
  if (existsSync(paths.exitCode)) validateExactShaArtifact(paths.exitCode, "0", "task23_native_exit_code", errors);
  return receiptSummary(paths, { live: live?.live === true, actualAI: live?.actualAI === true, providerCalls: live?.providerCalls ?? null });
}

function validateTask24PackageReceipt(evidenceSearchRoot, exactSha, errors) {
  const root = resolve(evidenceSearchRoot, TASK24_PACKAGE_RECEIPT_ROOT);
  const paths = {
    receipt: resolve(root, "package/company-package-receipt.json"),
    live: resolve(root, "task-24-package-live.json"),
    cleanup: resolve(root, "cleanup.json"),
  };
  const receipt = readJson(paths.receipt, errors, "task24_package_receipt");
  const live = readJson(paths.live, errors, "task24_package_live");
  const cleanup = readJson(paths.cleanup, errors, "task24_package_cleanup");
  validateReceiptFields(receipt, [["schemaVersion", 1], ["gitCommit", exactSha]], "task24_package_receipt_contract_failed", "task24_package_receipt", errors);
  if (receipt && !/^[0-9a-f]{64}$/i.test(receipt.codeTreeDigest ?? "")) {
    errors.push({ code: "task24_package_code_tree_invalid", actual: receipt.codeTreeDigest ?? null });
  }
  validateReceiptFields(live, [
    ["status", "PASS"], ["live", true], ["actualAI", true], ["appIsPackaged", true], ["providerCalls", 2], ["mutationCount", 1],
    ["readback.matches", true], ["explanation.evidenceBacked", true], ["explanation.toolEventCount", 0],
  ], "task24_package_live_contract_failed", "task24_package_live", errors);
  validateReceiptFields(cleanup, [["status", "PASS"], ["remainingProcessCount", 0], ["remainingTempDirectoryCount", 0]], "task24_package_cleanup_contract_failed", "task24_package_cleanup", errors);
  if (live?.package?.codeTreeDigest !== receipt?.codeTreeDigest || live?.package?.bundleSha256 !== receipt?.bundleSha256) {
    errors.push({ code: "package_live_identity_mismatch" });
  }
  return receiptSummary(paths, {
    live: live?.live === true,
    actualAI: live?.actualAI === true,
    appIsPackaged: live?.appIsPackaged === true,
    providerCalls: live?.providerCalls ?? null,
    codeTreeDigest: receipt?.codeTreeDigest ?? null,
  });
}

function walkFiles(root) {
  const files = [];
  const visit = (directory) => {
    let entries = [];
    try { entries = readdirSync(directory, { withFileTypes: true }); } catch { return; }
    for (const entry of entries) {
      const path = resolve(directory, entry.name);
      if (entry.isDirectory()) visit(path);
      else if (entry.isFile()) files.push(path);
    }
  };
  visit(root);
  return files;
}

function resolveImplementationEvidenceRoots(evidenceDir) {
  const attemptRoot = resolve(evidenceDir);
  const parent = resolve(attemptRoot, "..");
  const manifestName = "task-25-task-evidence-manifest.json";
  const task25Root = existsSync(resolve(attemptRoot, manifestName))
    ? attemptRoot
    : existsSync(resolve(parent, manifestName))
      ? parent
      : attemptRoot;
  return { attemptRoot, task25Root, evidenceSearchRoot: resolve(task25Root, "..") };
}

async function runImplementation(evidenceDir, docsRoot, repoRoot) {
  const errors = [];
  const docs = runDocsOnly(docsRoot);
  errors.push(...docs.errors);
  const { attemptRoot, task25Root: root, evidenceSearchRoot } = resolveImplementationEvidenceRoots(evidenceDir);
  if (!existsSync(attemptRoot)) errors.push({ code: "missing_evidence_dir", evidenceDir: attemptRoot });

  const files = walkFiles(evidenceSearchRoot);
  const nonEmpty = new Set(files.filter((path) => {
    try { return statSync(path).size > 0; } catch { return false; }
  }));
  for (let task = 1; task <= 24; task += 1) {
    const marker = new RegExp(`(?:^|/)task-${task}(?:[-/.]|$)`);
    if (![...nonEmpty].some((path) => marker.test(path))) {
      errors.push({ code: "missing_task_evidence", task: String(task), evidenceDir: root });
    }
  }
  for (const filename of ["task-25-happy.json", "task-25-failure.json", "implementation-report.md", "cleanup.json", "task-25-task-evidence-manifest.json"]) {
    const path = resolve(root, filename);
    if (!nonEmpty.has(path)) errors.push({ code: "missing_task25_artifact", artifact: filename, path });
  }

  const taskEvidenceManifest = validateTaskEvidenceManifest(root, evidenceSearchRoot, errors);

  const requiredModules = [
    "src/lib/company-runtime/contracts.ts",
    "src/lib/company-runtime/schemas.ts",
    "src/lib/company-runtime/skills.ts",
    "src/lib/company-runtime/assessment.ts",
    "src/lib/company-runtime/learning.ts",
    "src/lib/company-runtime/strategyReview.ts",
    "src/components/workspace/CompanyRequestPanel.tsx",
    "src/components/workspace/StrategyReviewPanel.tsx",
    "electron/companyRuntime.mjs",
    "electron/companyIpc.mjs",
    "electron/codexInterpreter.mjs",
    "electron/main.mjs",
  ];
  for (const module of requiredModules) {
    if (!existsSync(resolve(dirname(fileURLToPath(import.meta.url)), "..", module))) {
      errors.push({ code: "missing_actual_module", module });
    }
  }

  const exactSha = currentGitHead(repoRoot, errors);
  const planPath = resolve(repoRoot, PLAN_RELATIVE_PATH);
  let planSha256 = null;
  try { planSha256 = sha256File(planPath); }
  catch { errors.push({ code: "plan_unavailable", path: planPath }); }
  let codeTreeDigest = null;
  try { codeTreeDigest = await computeCodeTreeDigest(repoRoot); }
  catch (error) { errors.push({ code: "code_tree_unavailable", message: error instanceof Error ? error.message : String(error) }); }
  const receiptErrorCount = errors.length;
  const task23Native = validateTask23NativeReceipt(evidenceSearchRoot, exactSha, errors);
  const task24Package = validateTask24PackageReceipt(evidenceSearchRoot, exactSha, errors);
  // The C1/Task23 projection is controlled by the receipt validators alone:
  // they cover exact SHA, actual AI, provider, readback, and cleanup data.
  const liveContractPassed = errors.length === receiptErrorCount;
  const components = buildComponents(taskEvidenceManifest, liveContractPassed);
  validateComponentEvidence(components, taskEvidenceManifest, errors);
  const tasks = buildTasks(taskEvidenceManifest, root, liveContractPassed);
  validateTaskRecords(tasks, taskEvidenceManifest, evidenceSearchRoot, errors);

  const result = {
    ok: errors.length === 0,
    mode: "implementation",
    phase: "implementation",
    exactSha,
    planSha256,
    codeTreeDigest,
    sourceRows: docs.sourceRows,
    expectedSourceRows: APPROVED_SOURCE_CONTRACTS.length,
    tasks,
    actualAI: liveContractPassed && task23Native.actualAI && task24Package.actualAI,
    task23Live: {
      live: liveContractPassed && task23Native.live,
      actualAI: liveContractPassed && task23Native.actualAI,
      providerCalls: liveContractPassed ? task23Native.providerCalls : null,
    },
    packageLive: {
      live: liveContractPassed && task24Package.live,
      appIsPackaged: liveContractPassed && task24Package.appIsPackaged,
      providerCalls: liveContractPassed ? task24Package.providerCalls : null,
    },
    liveContractPassed,
    receipts: { native: task23Native, package: task24Package },
    evidenceDir: root,
    attemptDir: attemptRoot,
    taskEvidenceManifest: taskEvidenceManifest ? { contract: taskEvidenceManifest.contract, records: taskEvidenceManifest.records.length } : null,
    components,
    errors,
  };
  return result;
}

function readFinalJson(path, errors, label, missingCode) {
  try {
    if (!statSync(path).isFile()) {
      errors.push({ code: missingCode, path });
      return null;
    }
    if (statSync(path).size === 0) {
      errors.push({ code: "empty_evidence_file", label, path });
      return null;
    }
  } catch {
    errors.push({ code: missingCode, path });
    return null;
  }
  return readJson(path, errors, label);
}

function currentGitHead(repoRoot, errors) {
  try {
    return execFileSync("git", ["-C", repoRoot, "rev-parse", "HEAD"], { encoding: "utf8" }).trim();
  } catch (error) {
    errors.push({ code: "git_sha_unavailable", message: error instanceof Error ? error.message : String(error) });
    return null;
  }
}

function validatePreFinal(preFinal, expected, errors, taskEvidenceManifest = null) {
  if (!preFinal) return;
  const fields = [
    ["schemaVersion", 1],
    ["phase", "implementation_verified"],
    ["preFinal", true],
    ["ok", true],
    ["sourceRows", 18],
    ["tasks.required", 25],
    ["tasks.evidenceTasks", 24],
    ["actualAI", true],
    ["packageLive.live", true],
    ["packageLive.appIsPackaged", true],
    ["packageLive.providerCalls", 2],
  ];
  for (const [field, required] of fields) {
    const actual = field.split(".").reduce((value, key) => value?.[key], preFinal);
    if (actual !== required) errors.push({ code: "pre_final_contract_failed", field, expected: required, actual: actual ?? null });
  }
  if (preFinal.exactSha !== expected.exactSha) {
    errors.push({ code: "pre_final_sha_mismatch", expected: expected.exactSha, actual: preFinal.exactSha ?? null });
  }
  if (preFinal.planSha256 !== expected.planSha256) {
    errors.push({ code: "pre_final_plan_mismatch", expected: expected.planSha256, actual: preFinal.planSha256 ?? null });
  }
  if (preFinal.codeTreeDigest !== expected.codeTreeDigest) {
    errors.push({ code: "pre_final_code_tree_mismatch", expected: expected.codeTreeDigest, actual: preFinal.codeTreeDigest ?? null });
  }
  validateTaskRecords(preFinal.tasks, taskEvidenceManifest, expected.evidenceSearchRoot, errors);
  validateComponentEvidence(preFinal.components, taskEvidenceManifest, errors);
}

function readFinalReview(reviewRoot, reviewId, expected, errors) {
  const jsonPath = resolve(reviewRoot, `${reviewId}.json`);
  const reportPath = resolve(reviewRoot, `${reviewId}.md`);
  const review = readFinalJson(jsonPath, errors, reviewId, "missing_review_json");
  let reportSha256 = null;
  try {
    if (!statSync(reportPath).isFile()) errors.push({ code: "missing_review_report", reviewId, path: reportPath });
    else if (statSync(reportPath).size === 0) errors.push({ code: "empty_review_report", reviewId, path: reportPath });
    else reportSha256 = sha256File(reportPath);
  } catch {
    errors.push({ code: "missing_review_report", reviewId, path: reportPath });
  }
  if (!review) return null;

  if (review.schemaVersion !== 1 || review.reviewId !== reviewId) {
    errors.push({ code: "review_contract_failed", reviewId, schemaVersion: review.schemaVersion ?? null, actualReviewId: review.reviewId ?? null });
  }
  if (!["APPROVE", "CONFIRMED"].includes(review.verdict)
    || (review.recommendation !== undefined && review.recommendation !== "APPROVE")
    || (review.confirmed !== undefined && review.confirmed !== true)) {
    errors.push({ code: "review_not_approved", reviewId, verdict: review.verdict ?? null, recommendation: review.recommendation ?? null, confirmed: review.confirmed ?? null });
  }
  const reviewedShas = [review.exactSha, review.reviewedSha, review.reviewedHead, review.expectedHead]
    .filter((value) => value !== undefined);
  if (reviewedShas.length === 0 || reviewedShas.some((value) => value !== expected.exactSha)) {
    errors.push({ code: "review_sha_mismatch", reviewId, expected: expected.exactSha, actual: reviewedShas });
  }
  if (review.planSha256 !== expected.planSha256) {
    errors.push({ code: "review_plan_mismatch", reviewId, expected: expected.planSha256, actual: review.planSha256 ?? null });
  }
  if (review.codeTreeDigest !== expected.codeTreeDigest) {
    errors.push({ code: "review_code_tree_mismatch", reviewId, expected: expected.codeTreeDigest, actual: review.codeTreeDigest ?? null });
  }
  if (review.preFinalSha256 !== expected.preFinalSha256) {
    errors.push({ code: "review_pre_final_mismatch", reviewId, expected: expected.preFinalSha256, actual: review.preFinalSha256 ?? null });
  }
  const declaredReportPath = typeof review.reportPath === "string" ? resolve(expected.repoRoot, review.reportPath) : null;
  if (declaredReportPath !== reportPath) {
    errors.push({ code: "review_report_path_mismatch", reviewId, expected: reportPath, actual: declaredReportPath });
  }
  if (review.reportSha256 !== reportSha256) {
    errors.push({ code: "review_report_hash_mismatch", reviewId, expected: reportSha256, actual: review.reportSha256 ?? null });
  }
  return {
    reviewId,
    verdict: "APPROVE",
    sourceVerdict: review.verdict,
    jsonPath,
    jsonSha256: sha256File(jsonPath),
    reportPath,
    reportSha256,
    exactSha: expected.exactSha,
    planSha256: expected.planSha256,
    codeTreeDigest: expected.codeTreeDigest,
    preFinalSha256: expected.preFinalSha256,
  };
}

function writeNewFileAtomically(path, contents) {
  const temporaryPath = `${path}.tmp-${process.pid}-${Date.now()}`;
  writeFileSync(temporaryPath, contents, { flag: "wx" });
  try {
    linkSync(temporaryPath, path);
  } finally {
    unlinkSync(temporaryPath);
  }
}

async function runFinal(preFinalPath, reviewDir, writeFinalPath, repoRoot) {
  const errors = [];
  const finalPath = resolve(writeFinalPath);
  if (existsSync(finalPath)) errors.push({ code: "final_output_exists", path: finalPath });
  const exactSha = currentGitHead(repoRoot, errors);
  const planPath = resolve(repoRoot, PLAN_RELATIVE_PATH);
  let planSha256 = null;
  try { planSha256 = sha256File(planPath); }
  catch { errors.push({ code: "plan_unavailable", path: planPath }); }
  let codeTreeDigest = null;
  try { codeTreeDigest = await computeCodeTreeDigest(repoRoot); }
  catch (error) { errors.push({ code: "code_tree_unavailable", message: error instanceof Error ? error.message : String(error) }); }

  const resolvedPreFinalPath = resolve(preFinalPath);
  const preFinal = readFinalJson(resolvedPreFinalPath, errors, "pre_final", "missing_pre_final");
  const preFinalSha256 = preFinal ? sha256File(resolvedPreFinalPath) : null;
  const preFinalEvidenceDir = typeof preFinal?.evidenceDir === "string" ? resolve(preFinal.evidenceDir) : null;
  const expected = {
    repoRoot,
    exactSha,
    planSha256,
    codeTreeDigest,
    preFinalSha256,
    evidenceSearchRoot: preFinalEvidenceDir ? resolve(preFinalEvidenceDir, "..") : null,
  };
  const preFinalTaskEvidenceManifest = preFinalEvidenceDir
    ? validateTaskEvidenceManifest(preFinalEvidenceDir, resolve(preFinalEvidenceDir, ".."), errors)
    : null;
  validatePreFinal(preFinal, expected, errors, preFinalTaskEvidenceManifest);
  const resolvedReviewDir = resolve(reviewDir);
  const finalReviews = FINAL_REVIEW_IDS
    .map((reviewId) => readFinalReview(resolvedReviewDir, reviewId, expected, errors))
    .filter(Boolean);

  const result = {
    ok: errors.length === 0,
    mode: "final",
    phase: "final",
    exactSha,
    planSha256,
    codeTreeDigest,
    errors,
  };
  if (errors.length > 0) return result;

  const acceptance = {
    schemaVersion: 1,
    phase: "final_verified",
    ok: true,
    exactSha,
    planSha256,
    codeTreeDigest,
    preFinalRef: { path: resolvedPreFinalPath, sha256: preFinalSha256 },
    finalReviews,
    aggregateVerdict: "APPROVE",
    aggregate: { required: FINAL_REVIEW_IDS.length, approved: finalReviews.length },
  };
  const serialized = `${JSON.stringify(acceptance, null, 2)}\n`;
  try {
    writeNewFileAtomically(finalPath, serialized);
  } catch (error) {
    return {
      ...result,
      ok: false,
      errors: [{
        code: error?.code === "EEXIST" ? "final_output_exists" : "final_write_failed",
        path: finalPath,
        message: error instanceof Error ? error.message : String(error),
      }],
    };
  }
  return { ...result, acceptancePath: finalPath, acceptanceSha256: sha256File(finalPath) };
}

async function main() {
  try {
    const { docsRoot: requestedDocsRoot, packageDir, phase, evidenceDir, writePreFinal, preFinal, reviewDir, writeFinal } = parseArgs(process.argv.slice(2));
    if (packageDir) {
      const result = await verifyPackage({ packageDir, environment: process.env });
      process.stdout.write(`${JSON.stringify({ ok: true, mode: "package", ...result }, null, 2)}\n`);
      return;
    }
    const scriptDirectory = dirname(fileURLToPath(import.meta.url));
    const repoRoot = resolve(scriptDirectory, "..");
    const docsRoot = resolve(requestedDocsRoot ?? resolve(scriptDirectory, "../docs/brave-new-company"));
    if (phase === "implementation") {
      const result = await runImplementation(evidenceDir, docsRoot, repoRoot);
      if (result.ok && writePreFinal) {
        const preFinalPath = resolve(writePreFinal);
        const preFinal = {
          ...result,
          schemaVersion: 1,
          phase: "implementation_verified",
          preFinal: true,
          writtenBy: "verify-company-runtime",
        };
        try {
          mkdirSync(dirname(preFinalPath), { recursive: true });
          writeNewFileAtomically(preFinalPath, `${JSON.stringify(preFinal, null, 2)}\n`);
        } catch (error) {
          const failedResult = {
            ...result,
            ok: false,
            errors: [...result.errors, {
              code: error?.code === "EEXIST" ? "pre_final_output_exists" : "pre_final_write_failed",
              path: preFinalPath,
              message: error instanceof Error ? error.message : String(error),
            }],
          };
          process.stdout.write(`${JSON.stringify(failedResult, null, 2)}\n`);
          process.exitCode = 1;
          return;
        }
      }
      process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
      process.exitCode = result.ok ? 0 : 1;
      return;
    }
    if (phase === "final") {
      const result = await runFinal(preFinal, reviewDir, writeFinal, repoRoot);
      process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
      process.exitCode = result.ok ? 0 : 1;
      return;
    }
    const result = runDocsOnly(docsRoot);
    process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
    process.exitCode = result.ok ? 0 : 1;
  } catch (error) {
    process.stdout.write(`${JSON.stringify({
      ok: false,
      mode: "docs-only",
      errors: [{ code: "invalid_arguments", message: error instanceof Error ? error.message : String(error) }],
    }, null, 2)}\n`);
    process.exitCode = 1;
  }
}

await main();
