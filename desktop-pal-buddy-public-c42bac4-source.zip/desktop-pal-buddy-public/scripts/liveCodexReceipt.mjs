import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { PROVIDER_TERMINAL_TIMEOUT_MS } from "../electron/codexInterpreter.mjs";

const SENSITIVE_KEY = /(?:authorization|cookie|credential|password|secret|token|rawEnvironment|stderr|stdout)/iu;
const USER_PATH = /\/Users\/[^/\s]+/gu;
const BEARER = /Bearer\s+[A-Za-z0-9._~+/=-]+/giu;
const LIVE_PROGRESS_PHASES = [
  "discovery_started",
  "discovery_ready",
  "electron_launched",
  "request_submitted",
  "provider_returned",
  "proposal_rendered",
  "approval_recorded",
  "mutation_verified",
  "explanation_provider_returned",
  "learning_published",
  "second_request_submitted",
  "second_provider_returned",
  "reuse_rendered",
];
const LIVE_TERMINAL_PHASES = ["completed", "failure_rendered", "timeout", "blocked"];
const LIVE_PROGRESS_PHASE_SET = new Set(LIVE_PROGRESS_PHASES);
const LIVE_TERMINAL_PHASE_SET = new Set(LIVE_TERMINAL_PHASES);
const SELECTOR_DEADLINES = {
  first_provider_terminal_surface: {
    timeoutMs: PROVIDER_TERMINAL_TIMEOUT_MS,
    observable: "Neither the proposal nor bounded failure surface was visible before the provider deadline.",
  },
  post_approval_apply_readback: {
    timeoutMs: 20_000,
    observable: "The verified execution/readback surface was not visible before the bounded timeout.",
  },
};

function redact(value, key = "") {
  if (SENSITIVE_KEY.test(key)) return "<redacted>";
  if (typeof value === "string") {
    return value
      .replace(BEARER, "Bearer <redacted>")
      .replace(USER_PATH, "/Users/<redacted>");
  }
  if (Array.isArray(value)) return value.map((item) => redact(item));
  if (value && typeof value === "object") {
    return Object.fromEntries(Object.entries(value).map(([entryKey, entryValue]) => [entryKey, redact(entryValue, entryKey)]));
  }
  return value;
}

function validateTerminalReceipt(receipt) {
  if (!("terminalPhase" in receipt)) return;
  const { terminalPhase, lastCompletedPhase, phaseHistory, providerReturned } = receipt;
  if (!LIVE_TERMINAL_PHASE_SET.has(terminalPhase)) throw new Error("invalid live terminal phase");
  if (!Array.isArray(phaseHistory) || phaseHistory.length < 2 || phaseHistory.length > LIVE_PROGRESS_PHASES.length + 1) {
    throw new Error("invalid live phase history");
  }
  if (phaseHistory[0] !== LIVE_PROGRESS_PHASES[0] || phaseHistory.at(-1) !== terminalPhase) {
    throw new Error("invalid live phase history boundary");
  }
  const progressHistory = phaseHistory.slice(0, -1);
  if (progressHistory.some((phase) => !LIVE_PROGRESS_PHASE_SET.has(phase))) throw new Error("invalid live progress phase");
  const indices = progressHistory.map((phase) => LIVE_PROGRESS_PHASES.indexOf(phase));
  if (indices.some((index, offset) => index !== offset)) throw new Error("invalid live phase transition");
  if (lastCompletedPhase !== progressHistory.at(-1)) throw new Error("invalid live last completed phase");
  if (providerReturned !== progressHistory.includes("provider_returned")) throw new Error("invalid live provider-returned state");

  if (terminalPhase === "completed") {
    if (receipt.live !== true || receipt.status !== "PASS") throw new Error("completed receipt must claim live success");
  } else if (receipt.live === true || receipt.status === "PASS") {
    throw new Error("terminal receipt cannot claim success");
  }
  if (typeof receipt.actualAI !== "boolean"
    || typeof receipt.aiExplanationRendered !== "boolean"
    || typeof receipt.quarantinedInterpretation !== "boolean") {
    throw new Error("terminal receipt requires explicit AI projection fields");
  }
  if (receipt.aiExplanationRendered && !receipt.actualAI) {
    throw new Error("rendered AI explanation requires an actual provider invocation");
  }
  if (terminalPhase === "completed" && !receipt.actualAI) {
    throw new Error("completed live receipt requires an actual provider invocation");
  }
}

export function createLiveTerminalPhaseTracker() {
  const progressHistory = [LIVE_PROGRESS_PHASES[0]];
  let terminalPhase = null;

  return {
    advance(phase) {
      if (terminalPhase !== null) throw new Error("live phase tracker is terminal");
      const expected = LIVE_PROGRESS_PHASES[progressHistory.length];
      if (phase !== expected) throw new Error(`invalid live phase transition: expected ${expected ?? "terminal"}`);
      progressHistory.push(phase);
    },
    terminate(phase) {
      if (!LIVE_TERMINAL_PHASE_SET.has(phase)) throw new Error("invalid live terminal phase");
      if (terminalPhase !== null) throw new Error("live phase tracker is terminal");
      if (phase === "completed" && progressHistory.at(-1) !== LIVE_PROGRESS_PHASES.at(-1)) {
        throw new Error("live scenario cannot complete before every phase");
      }
      terminalPhase = phase;
    },
    snapshot() {
      const lastCompletedPhase = progressHistory.at(-1);
      return {
        terminalPhase,
        lastCompletedPhase,
        providerReturned: progressHistory.includes("provider_returned"),
        phaseHistory: terminalPhase === null ? [...progressHistory] : [...progressHistory, terminalPhase],
      };
    },
  };
}

export function normalizeLiveFailure(error, context) {
  if (context?.kind === "selector_deadline") {
    const deadline = SELECTOR_DEADLINES[context.boundary];
    if (!deadline || context.timeoutMs !== deadline.timeoutMs) throw new Error("invalid live selector deadline");
    return {
      terminalPhase: "timeout",
      failure: {
        name: "TimeoutError",
        category: "ui_selector_timeout",
        boundary: context.boundary,
        timeoutMs: deadline.timeoutMs,
        observable: deadline.observable,
      },
    };
  }

  if (context?.kind !== "unexpected" || !LIVE_PROGRESS_PHASE_SET.has(context.boundary)) {
    throw new Error("invalid live failure context");
  }
  const isTimeout = error instanceof Error && error.name === "TimeoutError";
  return {
    terminalPhase: isTimeout ? "timeout" : "blocked",
    failure: {
      name: isTimeout ? "TimeoutError" : "Error",
      category: isTimeout ? "bounded_timeout" : "bounded_failure",
      boundary: context.boundary,
      observable: "The live scenario stopped at the recorded phase boundary.",
    },
  };
}

export function serializeRedactedLiveReceipt(receipt) {
  validateTerminalReceipt(receipt);
  return `${JSON.stringify(redact(receipt), null, 2)}\n`;
}

export async function writeRedactedLiveReceipt(filePath, receipt) {
  await mkdir(path.dirname(filePath), { recursive: true });
  await writeFile(filePath, serializeRedactedLiveReceipt(receipt), { encoding: "utf8", mode: 0o600 });
}
