import assert from "node:assert/strict";
import { spawnSync } from "node:child_process";
import { chmod, mkdir, mkdtemp, rm, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import test from "node:test";
import {
  computeCodeTreeDigest,
  createPackageReceipt,
  verifyPackage,
} from "./verify-company-package.mjs";

const PRODUCT_NAME = "Prometheus Desktop Pal";
const verifierPath = path.resolve(import.meta.dirname, "verify-company-package.mjs");

async function createFixture() {
  const packageDir = await mkdtemp(path.join(os.tmpdir(), "bnc-package-contract-"));
  const appDir = path.join(packageDir, `${PRODUCT_NAME}.app`);
  const resourcesDir = path.join(appDir, "Contents", "Resources", "app");
  const executablePath = path.join(appDir, "Contents", "MacOS", PRODUCT_NAME);
  await mkdir(path.dirname(executablePath), { recursive: true });
  await mkdir(path.join(resourcesDir, "dist-runtime"), { recursive: true });
  await mkdir(path.join(resourcesDir, "electron", "codex-schemas"), { recursive: true });
  await writeFile(executablePath, "fixture executable\n");
  await chmod(executablePath, 0o700);
  await writeFile(path.join(resourcesDir, "dist-runtime", "domain.mjs"), "export {};\n");
  await writeFile(path.join(resourcesDir, "electron", "codex-schemas", "interpret.json"), "{}\n");
  await writeFile(path.join(resourcesDir, "electron", "codex-schemas", "explain.json"), "{}\n");
  return { packageDir, appDir, resourcesDir, executablePath };
}

async function expectCode(action, code) {
  await assert.rejects(action, (error) => error instanceof Error && error.code === code);
}

function runVerifier(packageDir) {
  const result = spawnSync(process.execPath, [verifierPath, "--package-dir", packageDir], {
    encoding: "utf8",
    env: Object.fromEntries(Object.entries(process.env).filter(([key]) => !key.startsWith("BNC_TEST"))),
  });
  return { ...result, receipt: JSON.parse(result.stdout.trim()) };
}

test("code tree identity ignores untracked files and detects tracked edits", async () => {
  const repoDir = await mkdtemp(path.join(os.tmpdir(), "bnc-package-identity-"));
  try {
    assert.equal(spawnSync("git", ["init", "--quiet"], { cwd: repoDir }).status, 0);
    await mkdir(path.join(repoDir, "src"), { recursive: true });
    await writeFile(path.join(repoDir, "src", "tracked.ts"), "export const value = 1;\n");
    assert.equal(spawnSync("git", ["add", "src/tracked.ts"], { cwd: repoDir }).status, 0);
    const initial = await computeCodeTreeDigest(repoDir);

    await writeFile(path.join(repoDir, "src", "AGENTS.md"), "untracked instructions\n");
    assert.equal(await computeCodeTreeDigest(repoDir), initial);

    await writeFile(path.join(repoDir, "src", "tracked.ts"), "export const value = 2;\n");
    assert.notEqual(await computeCodeTreeDigest(repoDir), initial);
  } finally {
    await rm(repoDir, { recursive: true, force: true });
  }
});

test("CLI rejects a missing receipt with a stable code before launch", async () => {
  const fixture = await createFixture();
  try {
    const result = runVerifier(fixture.packageDir);
    assert.equal(result.status, 1);
    assert.equal(result.receipt.code, "package_receipt_missing");
  } finally {
    await rm(fixture.packageDir, { recursive: true, force: true });
  }
});

test("CLI rejects malformed receipt JSON with a stable code before launch", async () => {
  const fixture = await createFixture();
  try {
    await writeFile(path.join(fixture.packageDir, "company-package-receipt.json"), "{ malformed\n");
    const result = runVerifier(fixture.packageDir);
    assert.equal(result.status, 1);
    assert.equal(result.receipt.code, "package_receipt_malformed");
  } finally {
    await rm(fixture.packageDir, { recursive: true, force: true });
  }
});

test("rejects a package directory with no app before launch", async () => {
  const packageDir = await mkdtemp(path.join(os.tmpdir(), "bnc-package-empty-"));
  try {
    await expectCode(() => verifyPackage({ packageDir, environment: {} }), "package_app_count");
  } finally {
    await rm(packageDir, { recursive: true, force: true });
  }
});

test("rejects multiple apps before launch", async () => {
  const packageDir = await mkdtemp(path.join(os.tmpdir(), "bnc-package-multiple-"));
  try {
    await mkdir(path.join(packageDir, "one", "First.app"), { recursive: true });
    await mkdir(path.join(packageDir, "two", "Second.app"), { recursive: true });
    await expectCode(() => verifyPackage({ packageDir, environment: {} }), "package_app_count");
  } finally {
    await rm(packageDir, { recursive: true, force: true });
  }
});

test("rejects missing runtime bundle and schema before launch", async () => {
  const fixture = await createFixture();
  try {
    await rm(path.join(fixture.resourcesDir, "dist-runtime", "domain.mjs"));
    await expectCode(() => createPackageReceipt(fixture.packageDir), "runtime_bundle_missing");
    await writeFile(path.join(fixture.resourcesDir, "dist-runtime", "domain.mjs"), "export {};\n");
    await rm(path.join(fixture.resourcesDir, "electron", "codex-schemas", "explain.json"));
    await expectCode(() => createPackageReceipt(fixture.packageDir), "runtime_schema_missing");
  } finally {
    await rm(fixture.packageDir, { recursive: true, force: true });
  }
});

test("rejects a stale receipt hash before launch", async () => {
  const fixture = await createFixture();
  try {
    const receipt = await createPackageReceipt(fixture.packageDir);
    await writeFile(path.join(fixture.resourcesDir, "dist-runtime", "domain.mjs"), "export const changed = true;\n");
    await expectCode(
      () => verifyPackage({ packageDir: fixture.packageDir, environment: {}, receipt }),
      "package_hash_mismatch",
    );
  } finally {
    await rm(fixture.packageDir, { recursive: true, force: true });
  }
});

test("rejects packaged test injection before launch", async () => {
  const fixture = await createFixture();
  try {
    const receipt = await createPackageReceipt(fixture.packageDir);
    for (const environment of [
      { BNC_TEST_MODE: "1" },
      { BNC_TEST_OPTIONS: JSON.stringify({ faults: { rename: true } }) },
      { BNC_TEST_OPTIONS: JSON.stringify({ modelStub: { enabled: true } }) },
      { BNC_TEST_OPTIONS: JSON.stringify({ dataDir: "/tmp/injected" }) },
    ]) {
      await expectCode(
        () => verifyPackage({ packageDir: fixture.packageDir, environment, receipt }),
        "packaged_injection_rejected",
      );
    }
  } finally {
    await rm(fixture.packageDir, { recursive: true, force: true });
  }
});

test("rejects an executable path outside the unique app before launch", async () => {
  const fixture = await createFixture();
  try {
    const receipt = await createPackageReceipt(fixture.packageDir);
    const tampered = { ...receipt, executableRelativePath: "../../../../usr/bin/open" };
    await expectCode(
      () => verifyPackage({ packageDir: fixture.packageDir, environment: {}, receipt: tampered }),
      "package_executable_untrusted",
    );
  } finally {
    await rm(fixture.packageDir, { recursive: true, force: true });
  }
});
