import assert from "node:assert/strict";
import { chmod, mkdir, mkdtemp, readFile, rm, stat, symlink, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import test from "node:test";

const qaModule = await import("./verify-company-product.mjs").catch(() => ({}));

async function requireFunction(name) {
  const candidate = qaModule[name];
  assert.equal(typeof candidate, "function", `${name} must be exported by verify-company-product.mjs`);
  return candidate;
}

async function createAppFixture() {
  const packageDir = await mkdtemp(path.join(os.tmpdir(), "bnc-product-package-"));
  const appPath = path.join(packageDir, "Product.app");
  const executablePath = path.join(appPath, "Contents", "MacOS", "Product");
  const resourcesPath = path.join(appPath, "Contents", "Resources");
  const frameworkPath = path.join(appPath, "Contents", "Frameworks", "Engine.framework", "Versions", "A");
  await mkdir(path.dirname(executablePath), { recursive: true });
  await mkdir(resourcesPath, { recursive: true });
  await mkdir(frameworkPath, { recursive: true });
  await writeFile(executablePath, "executable\n", { mode: 0o755 });
  await writeFile(path.join(resourcesPath, "app.asar"), "archive\n", { mode: 0o644 });
  await writeFile(path.join(frameworkPath, "Engine"), "framework\n", { mode: 0o755 });
  await symlink("A", path.join(appPath, "Contents", "Frameworks", "Engine.framework", "Versions", "Current"));
  return { appPath, executablePath, packageDir, resourcesPath };
}

test("PIN: normal packaged launch contract uses a standard user-data argument without smoke", async () => {
  const createNormalLaunchArguments = await requireFunction("createNormalLaunchArguments");
  const profile = path.join(os.tmpdir(), "bnc-normal-profile");
  assert.deepEqual(createNormalLaunchArguments(profile), [`--user-data-dir=${profile}`]);
});

test("RED: full app inventory changes for byte mutation, file addition, deletion, and mode", async () => {
  const createAppArtifactInventory = await requireFunction("createAppArtifactInventory");
  const fixture = await createAppFixture();
  try {
    const initial = await createAppArtifactInventory(fixture.appPath);
    const archive = path.join(fixture.resourcesPath, "app.asar");
    await writeFile(archive, "archivf\n");
    assert.notEqual((await createAppArtifactInventory(fixture.appPath)).appArtifactSha256, initial.appArtifactSha256);
    await writeFile(archive, "archive\n");
    await writeFile(path.join(fixture.resourcesPath, "added.bin"), "added\n");
    assert.notEqual((await createAppArtifactInventory(fixture.appPath)).appArtifactSha256, initial.appArtifactSha256);
    await rm(path.join(fixture.resourcesPath, "added.bin"));
    await rm(archive);
    assert.notEqual((await createAppArtifactInventory(fixture.appPath)).appArtifactSha256, initial.appArtifactSha256);
    await writeFile(archive, "archive\n", { mode: 0o644 });
    await chmod(fixture.executablePath, 0o700);
    assert.notEqual((await createAppArtifactInventory(fixture.appPath)).appArtifactSha256, initial.appArtifactSha256);
  } finally {
    await rm(fixture.packageDir, { recursive: true, force: true });
  }
});

test("RED: inventory rejects external and broken symlinks", async () => {
  const createAppArtifactInventory = await requireFunction("createAppArtifactInventory");
  for (const target of ["/tmp", "missing-target"]) {
    const fixture = await createAppFixture();
    try {
      await symlink(target, path.join(fixture.resourcesPath, "escape"));
      await assert.rejects(() => createAppArtifactInventory(fixture.appPath), (error) => {
        assert.equal(error.code, target === "/tmp" ? "app_symlink_external" : "app_symlink_broken");
        return true;
      });
    } finally {
      await rm(fixture.packageDir, { recursive: true, force: true });
    }
  }
});

test("RED: isolated profile creation is mode 0700 and refuses linked, existing, and default paths", async () => {
  const createIsolatedProfile = await requireFunction("createIsolatedProfile");
  const root = await mkdtemp(path.join(os.tmpdir(), "bnc-profile-test-"));
  try {
    const defaultPath = path.join(root, "personal-default");
    const existingPath = path.join(root, "existing");
    const linkedPath = path.join(root, "linked");
    await mkdir(defaultPath);
    await mkdir(existingPath);
    await symlink(existingPath, linkedPath);
    const profile = await createIsolatedProfile({ parentDirectory: root, defaultUserDataPath: defaultPath });
    assert.equal((await stat(profile)).mode & 0o777, 0o700);
    await assert.rejects(() => createIsolatedProfile({ parentDirectory: root, requestedPath: existingPath, defaultUserDataPath: defaultPath }), { code: "qa_profile_preexisting" });
    await assert.rejects(() => createIsolatedProfile({ parentDirectory: root, requestedPath: linkedPath, defaultUserDataPath: defaultPath }), { code: "qa_profile_symlink" });
    await assert.rejects(() => createIsolatedProfile({ parentDirectory: root, requestedPath: defaultPath, defaultUserDataPath: defaultPath }), { code: "qa_profile_default" });
  } finally {
    await rm(root, { recursive: true, force: true });
  }
});

test("RED: launcher parser rejects extra flags and non-absolute paths", async () => {
  const parseProductQaCli = await requireFunction("parseProductQaCli");
  assert.throws(() => parseProductQaCli(["--package-dir", "relative", "--scenario", "preflight", "--evidence-dir", "/tmp/evidence"]), { code: "qa_path_not_absolute" });
  assert.throws(() => parseProductQaCli(["--package-dir", "/tmp/package", "--scenario", "preflight", "--evidence-dir", "/tmp/evidence", "--exec", "/bin/sh"]), { code: "qa_argument_unknown" });
});

test("RED: clean environment removes production test injection without changing unrelated values", async () => {
  const cleanPackagedEnvironment = await requireFunction("cleanPackagedEnvironment");
  assert.deepEqual(cleanPackagedEnvironment({ BNC_TEST_MODE: "1", BNC_TEST_OPTIONS: "{}", SAFE_VALUE: "kept" }), { SAFE_VALUE: "kept", PATH: "/usr/bin:/bin:/usr/sbin:/sbin" });
});

test("RED: sandbox profile allows loopback and denies other outbound network", async () => {
  const createNetworkSandboxProfile = await requireFunction("createNetworkSandboxProfile");
  const profile = createNetworkSandboxProfile();
  assert.match(profile, /network-outbound.*localhost/);
  assert.match(profile, /deny network-outbound/);
  assert.doesNotMatch(profile, /allow network-outbound\)\s*$/m);
});

test("RED: companion identity verification rejects a stale digest", async () => {
  const createAppArtifactInventory = await requireFunction("createAppArtifactInventory");
  const verifyAppArtifactIdentity = await requireFunction("verifyAppArtifactIdentity");
  const fixture = await createAppFixture();
  try {
    const initial = await createAppArtifactInventory(fixture.appPath);
    await writeFile(path.join(fixture.resourcesPath, "app.asar"), "changed\n");
    await assert.rejects(() => verifyAppArtifactIdentity(fixture.appPath, initial.appArtifactSha256), { code: "app_artifact_mismatch" });
  } finally {
    await rm(fixture.packageDir, { recursive: true, force: true });
  }
});

test("continues independent packaged checks when transport denial is blocked", async () => {
  const classifyPreflight = await requireFunction("classifyPreflight");
  assert.deepEqual(classifyPreflight({ status: "BLOCKED", reason: "sandbox_profile_unsupported" }), {
    runSupportedPackageChecks: true,
    finalStatus: "BLOCKED",
    exitCode: 2,
  });
});

test("fixture itself preserves exact bytes for independent mutation assertions", async () => {
  const fixture = await createAppFixture();
  try {
    assert.equal(await readFile(path.join(fixture.resourcesPath, "app.asar"), "utf8"), "archive\n");
  } finally {
    await rm(fixture.packageDir, { recursive: true, force: true });
  }
});
