#!/usr/bin/env node

import { execFile, spawn } from "node:child_process";
import crypto from "node:crypto";
import { access, chmod, lstat, mkdir, readFile, realpath, readdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { promisify } from "node:util";
import { extractFile } from "@electron/asar";

const RECEIPT_NAME = "company-package-receipt.json";
const REQUIRED_PAYLOADS = [
  "dist-runtime/domain.mjs",
  "electron/codex-schemas/interpret.json",
  "electron/codex-schemas/explain.json",
];
const CODE_TREE_ROOTS = ["src", "electron", "tests", "scripts"];
const CODE_TREE_FILES = [
  "package.json", "package-lock.json", "vite.config.ts", "vite.runtime.config.ts", "vitest.config.ts",
  "playwright.config.ts", "playwright.electron.config.ts", "playwright.electron.live.config.ts",
  "playwright.package.config.ts", "tsconfig.json", "tsconfig.app.json", "tsconfig.node.json", ".github/workflows/ci.yml",
];
const execFileAsync = promisify(execFile);

class PackageContractError extends Error {
  constructor(code, message) {
    super(message);
    this.name = "PackageContractError";
    this.code = code;
  }
}

function sha256(value) {
  return crypto.createHash("sha256").update(value).digest("hex");
}

function isInside(candidate, root) {
  const relative = path.relative(root, candidate);
  return relative === "" || (!relative.startsWith("..") && !path.isAbsolute(relative));
}

async function walk(root, predicate) {
  const found = [];
  async function visit(directory) {
    for (const entry of await readdir(directory, { withFileTypes: true })) {
      const candidate = path.join(directory, entry.name);
      if (entry.isSymbolicLink()) continue;
      if (predicate(candidate, entry)) found.push(candidate);
      if (entry.isDirectory() && !entry.name.endsWith(".app")) await visit(candidate);
    }
  }
  await visit(root);
  return found;
}

async function gitOutput(repoRoot, args) {
  try {
    const { stdout } = await execFileAsync("git", ["-C", repoRoot, ...args], {
      encoding: "utf8",
      maxBuffer: 4 * 1024 * 1024,
    });
    return stdout;
  } catch {
    throw new PackageContractError("code_tree_unavailable", "package identity requires a Git worktree");
  }
}

export async function computeCodeTreeDigest(repoRoot) {
  const output = await gitOutput(repoRoot, ["ls-files", "-z", "--", ...CODE_TREE_ROOTS, ...CODE_TREE_FILES]);
  const files = output.split("\0").filter(Boolean).sort();
  const entries = [];
  for (const file of files) {
    entries.push(`${file}\0${sha256(await readFile(path.join(repoRoot, file)))}`);
  }
  return sha256(`${entries.join("\n")}\n`);
}

async function inspectTarget(packageDir) {
  const packageRoot = await realpath(packageDir).catch(() => {
    throw new PackageContractError("package_directory_missing", "package directory does not exist");
  });
  const apps = await walk(packageRoot, (candidate, entry) => entry.isDirectory() && candidate.endsWith(".app"));
  if (apps.length > 0) {
    if (apps.length !== 1) throw new PackageContractError("package_app_count", `expected one app, found ${apps.length}`);
    const appPath = await realpath(apps[0]);
    if (!isInside(appPath, packageRoot)) throw new PackageContractError("package_app_outside", "app resolves outside package directory");
    const executableName = path.basename(appPath, ".app");
    return {
      platform: "darwin",
      packageRoot,
      appPath,
      executablePath: path.join(appPath, "Contents", "MacOS", executableName),
      resourcesPath: path.join(appPath, "Contents", "Resources"),
    };
  }
  const linuxRoots = await walk(packageRoot, (candidate, entry) => entry.isDirectory() && candidate.endsWith("linux-unpacked"));
  if (linuxRoots.length !== 1) throw new PackageContractError("package_app_count", `expected one app target, found ${linuxRoots.length}`);
  const appPath = await realpath(linuxRoots[0]);
  const executablePath = path.join(appPath, "vite_react_shadcn_ts");
  return { platform: "linux", packageRoot, appPath, executablePath, resourcesPath: path.join(appPath, "resources") };
}

async function readPayload(target, relativePath) {
  const unpacked = path.join(target.resourcesPath, "app", relativePath);
  try {
    return await readFile(unpacked);
  } catch (error) {
    if (error?.code !== "ENOENT") throw error;
  }
  const asarPath = path.join(target.resourcesPath, "app.asar");
  try {
    await access(asarPath);
    return extractFile(asarPath, relativePath);
  } catch (error) {
    const code = relativePath === REQUIRED_PAYLOADS[0] ? "runtime_bundle_missing" : "runtime_schema_missing";
    throw new PackageContractError(code, `${relativePath} is missing from package`);
  }
}

function rejectInjection(environment) {
  if (environment.BNC_TEST_MODE || environment.BNC_TEST_OPTIONS) {
    throw new PackageContractError("packaged_injection_rejected", "packaged test injection is forbidden");
  }
}

export async function createPackageReceipt(packageDir) {
  const target = await inspectTarget(path.resolve(packageDir));
  const executableStat = await lstat(target.executablePath).catch(() => null);
  if (!executableStat?.isFile()) throw new PackageContractError("package_executable_missing", "package executable is missing");
  const payloads = [];
  for (const relativePath of REQUIRED_PAYLOADS) {
    const contents = await readPayload(target, relativePath);
    payloads.push({ path: relativePath, sha256: sha256(contents) });
  }
  const repoRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
  const appRelativePath = path.relative(target.packageRoot, target.appPath);
  const executableRelativePath = path.relative(target.packageRoot, target.executablePath);
  const bundleSha256 = sha256(`${payloads.map((item) => `${item.path}\0${item.sha256}`).join("\n")}\n`);
  return {
    schemaVersion: 1,
    gitCommit: (await gitOutput(repoRoot, ["rev-parse", "HEAD"])).trim(),
    platform: target.platform,
    packageDirRealpath: target.packageRoot,
    appRelativePath,
    appRealpath: target.appPath,
    executableRelativePath,
    codeTreeDigest: await computeCodeTreeDigest(repoRoot),
    runtimeBundle: payloads[0],
    schemas: payloads.slice(1),
    bundleSha256,
  };
}

export async function verifyPackage({ packageDir, environment = process.env, receipt }) {
  rejectInjection(environment);
  const expected = await createPackageReceipt(packageDir);
  let actual = receipt;
  if (!actual) {
    let serialized;
    try {
      serialized = await readFile(path.join(expected.packageDirRealpath, RECEIPT_NAME), "utf8");
    } catch (error) {
      if (error?.code === "ENOENT") throw new PackageContractError("package_receipt_missing", "package receipt is missing");
      throw error;
    }
    try {
      actual = JSON.parse(serialized);
    } catch {
      throw new PackageContractError("package_receipt_malformed", "package receipt is not valid JSON");
    }
  }
  const executablePath = path.resolve(expected.packageDirRealpath, actual.executableRelativePath ?? "");
  if (!isInside(executablePath, expected.appRealpath) || executablePath !== path.resolve(expected.packageDirRealpath, expected.executableRelativePath)) {
    throw new PackageContractError("package_executable_untrusted", "receipt executable is outside the selected app");
  }
  for (const field of ["schemaVersion", "gitCommit", "platform", "packageDirRealpath", "appRelativePath", "appRealpath", "executableRelativePath", "codeTreeDigest", "bundleSha256"]) {
    if (actual[field] !== expected[field]) throw new PackageContractError("package_hash_mismatch", `receipt ${field} mismatch`);
  }
  if (JSON.stringify(actual.runtimeBundle) !== JSON.stringify(expected.runtimeBundle)
    || JSON.stringify(actual.schemas) !== JSON.stringify(expected.schemas)) {
    throw new PackageContractError("package_hash_mismatch", "receipt payload hash mismatch");
  }
  return { ...expected, executablePath };
}

async function run(command, args, options = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { stdio: "inherit", shell: false, ...options });
    const timer = setTimeout(() => child.kill("SIGTERM"), options.timeoutMs ?? 300_000);
    child.on("error", reject);
    child.on("close", (exitCode, signal) => {
      clearTimeout(timer);
      if (exitCode === 0) resolve();
      else reject(new PackageContractError("child_process_failed", `child exited ${exitCode ?? signal}`));
    });
  });
}

function parseCli(argv) {
  const build = argv[0] === "--build";
  const ci = argv[0] === "--ci";
  const args = build || ci ? argv.slice(1) : argv;
  const packageIndex = args.indexOf("--package-dir");
  const output = args.find((value) => value.startsWith("--config.directories.output="))?.split("=").slice(1).join("=");
  const packageDir = packageIndex >= 0 ? args[packageIndex + 1] : output;
  if (!packageDir) throw new PackageContractError("package_directory_missing", "--package-dir or --config.directories.output is required");
  return { build, ci, args, packageDir: path.resolve(packageDir) };
}

async function main() {
  try {
    const cli = parseCli(process.argv.slice(2));
    if (cli.build) {
      await mkdir(cli.packageDir, { recursive: true });
      const existing = await walk(cli.packageDir, (candidate, entry) => entry.isDirectory() && candidate.endsWith(".app"));
      if (existing.length > 0) throw new PackageContractError("package_not_fresh", "package output already contains an app");
      const builder = path.resolve("node_modules/.bin/electron-builder");
      await run(builder, ["--dir", ...cli.args], { timeoutMs: 300_000 });
      const receipt = await createPackageReceipt(cli.packageDir);
      const receiptPath = path.join(cli.packageDir, RECEIPT_NAME);
      await writeFile(receiptPath, `${JSON.stringify(receipt, null, 2)}\n`, { mode: 0o600 });
      await chmod(receiptPath, 0o600);
      process.stdout.write(`${JSON.stringify({ ok: true, receiptPath, ...receipt })}\n`);
      return;
    }
    const verified = await verifyPackage({ packageDir: cli.packageDir, environment: process.env });
    const environment = { ...process.env };
    for (const key of Object.keys(environment)) {
      if (/^(?:BNC_TEST|ELECTRON_UPDATE|ELECTRON_EXTERNAL|SUPABASE|VITE_SUPABASE|OPENAI|ANTHROPIC|ERP)|API_KEY/i.test(key)) delete environment[key];
    }
    environment.BNC_PACKAGE_DIR = verified.packageDirRealpath;
    environment.BNC_PACKAGE_RECEIPT = path.join(verified.packageDirRealpath, RECEIPT_NAME);
    environment.BNC_PACKAGE_EXECUTABLE = verified.executablePath;
    environment.PATH = "/usr/bin:/bin:/usr/sbin:/sbin";
    const playwright = path.resolve("node_modules/@playwright/test/cli.js");
    await run(process.execPath, [playwright, "test", "--config=playwright.package.config.ts", `--project=${cli.ci ? "package-ci" : "package-live"}`], {
      env: environment,
      timeoutMs: cli.ci ? 120_000 : 300_000,
    });
  } catch (error) {
    process.stdout.write(`${JSON.stringify({ ok: false, code: error?.code ?? "package_verification_failed", message: error instanceof Error ? error.message : String(error) })}\n`);
    process.exitCode = 1;
  }
}

if (process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1])) await main();
