import { readdirSync, readFileSync } from "node:fs";
import path from "node:path";
import { spawnSync } from "node:child_process";

const IMAGE = process.env.SUPABASE_VERIFY_POSTGRES_IMAGE ?? "postgres:15-alpine";
const CONTAINER_NAME = `desktop-pal-buddy-pg-verify-${process.pid}`;
const COMMAND_TIMEOUT_MS = Number(process.env.SUPABASE_VERIFY_POSTGRES_TIMEOUT_MS ?? 60_000);
const STARTUP_SETTLE_MS = Number(process.env.SUPABASE_VERIFY_POSTGRES_STARTUP_SETTLE_MS ?? 5_000);
const MIGRATIONS_DIR = path.resolve("supabase/migrations");

function describeFailure(command, args, result) {
  if (result.error?.name === "ETIMEDOUT" || result.error?.code === "ETIMEDOUT" || result.status === null) {
    return `${command} ${args.join(" ")} did not finish before the timeout.`;
  }

  return `${command} ${args.join(" ")} exited with ${result.status}`;
}

function run(command, args, options = {}) {
  console.log(`\n$ ${[command, ...args].join(" ")}`);
  const result = spawnSync(command, args, {
    cwd: process.cwd(),
    encoding: "utf8",
    input: options.input,
    stdio: options.input ? ["pipe", "inherit", "inherit"] : "inherit",
    timeout: options.timeout ?? COMMAND_TIMEOUT_MS,
  });

  if (result.error || result.status !== 0) {
    throw new Error(describeFailure(command, args, result));
  }
}

function runPsql(label, sql) {
  console.log(`\n-- ${label}`);
  run(
    "docker",
    ["exec", "-i", CONTAINER_NAME, "psql", "-v", "ON_ERROR_STOP=1", "-U", "postgres", "-d", "postgres"],
    { input: sql }
  );
}

function waitForPostgres() {
  const deadline = Date.now() + COMMAND_TIMEOUT_MS;
  const earliestReady = Date.now() + STARTUP_SETTLE_MS;
  let lastError = "";

  while (Date.now() < deadline) {
    const result = spawnSync(
      "docker",
      [
        "exec",
        CONTAINER_NAME,
        "psql",
        "-v",
        "ON_ERROR_STOP=1",
        "-U",
        "postgres",
        "-d",
        "postgres",
        "-c",
        "select 1",
      ],
      {
        encoding: "utf8",
        timeout: 5_000,
      }
    );

    if (result.status === 0 && Date.now() >= earliestReady) {
      return;
    }

    if (result.status !== 0) {
      lastError =
        result.stderr?.trim() ||
        result.stdout?.trim() ||
        describeFailure("docker", ["exec", CONTAINER_NAME, "psql"], result);
    }

    Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 1_000);
  }

  throw new Error(
    `Postgres container did not become ready before the timeout. Last probe: ${lastError}`
  );
}

const bootstrapSql = `
CREATE EXTENSION IF NOT EXISTS pgcrypto;

DO $$
BEGIN
  CREATE ROLE anon NOLOGIN;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

DO $$
BEGIN
  CREATE ROLE authenticated NOLOGIN;
EXCEPTION WHEN duplicate_object THEN NULL;
END $$;

CREATE SCHEMA IF NOT EXISTS auth;
CREATE TABLE IF NOT EXISTS auth.users (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid()
);

CREATE OR REPLACE FUNCTION auth.uid()
RETURNS uuid
LANGUAGE sql
STABLE
AS $$
  SELECT nullif(current_setting('request.jwt.claim.sub', true), '')::uuid;
$$;

GRANT USAGE ON SCHEMA public TO anon, authenticated;
ALTER DEFAULT PRIVILEGES IN SCHEMA public
  GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO anon, authenticated;
ALTER DEFAULT PRIVILEGES IN SCHEMA public
  GRANT EXECUTE ON FUNCTIONS TO anon, authenticated;
`;

const assertionSql = `
DO $$
DECLARE
  legacy_policy_count integer;
  public_write_count integer;
  missing_owner_tables text[];
  owner_grant_count integer;
  readonly_is_security_definer boolean;
  rate_limit_table_exists boolean;
  rating_trigger_execute_grant_count integer;
BEGIN
  SELECT count(*)
    INTO legacy_policy_count
    FROM pg_policies
   WHERE schemaname = 'public'
     AND policyname LIKE 'Allow public read/write%';

  IF legacy_policy_count <> 0 THEN
    RAISE EXCEPTION 'Legacy public read/write policies remain: %', legacy_policy_count;
  END IF;

  SELECT count(*)
    INTO public_write_count
    FROM pg_policies
   WHERE schemaname = 'public'
     AND cmd IN ('ALL', 'INSERT', 'UPDATE', 'DELETE')
     AND (qual = 'true' OR with_check = 'true');

  IF public_write_count <> 0 THEN
    RAISE EXCEPTION 'Unbounded public write policies remain: %', public_write_count;
  END IF;

  SELECT array_agg(expected.table_name)
    INTO missing_owner_tables
    FROM (
      VALUES
        ('tasks'),
        ('agent_evidence'),
        ('agent_approvals'),
        ('agent_events'),
        ('agent_results'),
        ('alert_dismissals'),
        ('installed_items'),
        ('debate_history'),
        ('canvas_nodes'),
        ('canvas_edges'),
        ('canvas_evidences'),
        ('canvas_review_decisions'),
        ('canvas_graph_snapshots'),
        ('marketplace_reviews'),
        ('marketplace_workflow_reviews'),
        ('marketplace_skill_reviews'),
        ('marketplace_mcp_reviews')
    ) AS expected(table_name)
   WHERE NOT EXISTS (
      SELECT 1
        FROM information_schema.columns
       WHERE table_schema = 'public'
         AND table_name = expected.table_name
         AND column_name = 'owner_id'
   );

  IF missing_owner_tables IS NOT NULL THEN
    RAISE EXCEPTION 'Missing owner_id columns: %', missing_owner_tables;
  END IF;

  SELECT count(*)
    INTO owner_grant_count
    FROM information_schema.column_privileges
   WHERE table_schema = 'public'
     AND table_name IN (
       'marketplace_reviews',
       'marketplace_workflow_reviews',
       'marketplace_skill_reviews',
       'marketplace_mcp_reviews'
     )
     AND column_name = 'owner_id'
     AND grantee IN ('anon', 'authenticated')
     AND privilege_type = 'SELECT';

  IF owner_grant_count <> 0 THEN
    RAISE EXCEPTION 'Review owner_id columns are publicly selectable: %', owner_grant_count;
  END IF;

  SELECT EXISTS (
    SELECT 1
      FROM information_schema.tables
     WHERE table_schema = 'public'
       AND table_name = 'edge_rate_limit_events'
  ) INTO rate_limit_table_exists;

  IF rate_limit_table_exists IS DISTINCT FROM true THEN
    RAISE EXCEPTION 'edge_rate_limit_events table is missing';
  END IF;

  SELECT prosecdef
    INTO readonly_is_security_definer
    FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
   WHERE n.nspname = 'public'
     AND p.proname = 'execute_readonly_query'
     AND pg_get_function_identity_arguments(p.oid) = 'query_text text, max_rows integer';

  IF readonly_is_security_definer IS DISTINCT FROM false THEN
    RAISE EXCEPTION 'execute_readonly_query must be SECURITY INVOKER';
  END IF;

  SELECT count(*)
    INTO rating_trigger_execute_grant_count
    FROM information_schema.routine_privileges
   WHERE routine_schema = 'public'
     AND routine_name IN (
       'update_agent_rating',
       'update_workflow_rating',
       'update_skill_rating',
       'update_mcp_rating'
     )
     AND privilege_type = 'EXECUTE'
     AND grantee IN ('PUBLIC', 'anon', 'authenticated');

  IF rating_trigger_execute_grant_count <> 0 THEN
    RAISE EXCEPTION 'Rating trigger functions are externally executable: %', rating_trigger_execute_grant_count;
  END IF;
END $$;

INSERT INTO auth.users(id) VALUES ('00000000-0000-0000-0000-000000000001');
INSERT INTO auth.users(id) VALUES ('00000000-0000-0000-0000-000000000002');

SET ROLE authenticated;
SELECT set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-000000000001', false);
INSERT INTO public.tasks(id, title)
VALUES ('10000000-0000-0000-0000-000000000001', 'owned task');

DO $$
DECLARE
  visible_count integer;
BEGIN
  SELECT count(*) INTO visible_count FROM public.tasks;
  IF visible_count <> 1 THEN
    RAISE EXCEPTION 'Owner should see exactly one task, saw %', visible_count;
  END IF;
END $$;

INSERT INTO public.agent_evidence(
  task_id,
  packet_task_id,
  evidence_id,
  evidence_type,
  summary,
  source_system,
  status
) VALUES (
  '10000000-0000-0000-0000-000000000001',
  'workboard-10000000-0000-0000-0000-000000000001',
  'evidence-owned-1',
  'manual_observation',
  'Owner can attach evidence to their own task.',
  'user',
  'passed'
);

DO $$
DECLARE
  visible_count integer;
BEGIN
  SELECT count(*) INTO visible_count FROM public.agent_evidence;
  IF visible_count <> 1 THEN
    RAISE EXCEPTION 'Owner should see exactly one evidence item, saw %', visible_count;
  END IF;
END $$;

INSERT INTO public.agent_approvals(
  task_id,
  packet_task_id,
  decision,
  action_type,
  approval_reason,
  approved_scope
) VALUES (
  '10000000-0000-0000-0000-000000000001',
  'workboard-10000000-0000-0000-0000-000000000001',
  'approved',
  'database_migration',
  'Approval required for: database_migration',
  'Approved only for staging migration dry run.'
);

DO $$
DECLARE
  visible_count integer;
BEGIN
  SELECT count(*) INTO visible_count FROM public.agent_approvals;
  IF visible_count <> 1 THEN
    RAISE EXCEPTION 'Owner should see exactly one approval record, saw %', visible_count;
  END IF;
END $$;

INSERT INTO public.agent_events(
  task_id,
  packet_task_id,
  event_id,
  event_type,
  message,
  severity
) VALUES (
  '10000000-0000-0000-0000-000000000001',
  'workboard-10000000-0000-0000-0000-000000000001',
  'event-owned-1',
  'accepted',
  'Owner can attach events to their own task.',
  'info'
);

DO $$
DECLARE
  visible_count integer;
BEGIN
  SELECT count(*) INTO visible_count FROM public.agent_events;
  IF visible_count <> 1 THEN
    RAISE EXCEPTION 'Owner should see exactly one event record, saw %', visible_count;
  END IF;
END $$;

INSERT INTO public.agent_results(
  task_id,
  packet_task_id,
  outcome,
  summary,
  blockers,
  next_action,
  retention_decision
) VALUES (
  '10000000-0000-0000-0000-000000000001',
  'workboard-10000000-0000-0000-0000-000000000001',
  'passed_with_warnings',
  'Owner can attach worker results to their own task.',
  '[{"blocker_id":"blocker-1","type":"missing_context","summary":"Need latest export.","requires_user_action":true}]'::jsonb,
  'Ask for latest export.',
  '{"task_id":"workboard-10000000-0000-0000-0000-000000000001","save_decision":"workboard","reason":"Follow-up remains active.","requires_user_approval":true}'::jsonb
);

DO $$
DECLARE
  visible_count integer;
BEGIN
  SELECT count(*) INTO visible_count FROM public.agent_results;
  IF visible_count <> 1 THEN
    RAISE EXCEPTION 'Owner should see exactly one result record, saw %', visible_count;
  END IF;
END $$;

SELECT set_config('request.jwt.claim.sub', '00000000-0000-0000-0000-000000000002', false);

DO $$
DECLARE
  visible_count integer;
BEGIN
  SELECT count(*) INTO visible_count FROM public.tasks;
  IF visible_count <> 0 THEN
    RAISE EXCEPTION 'Different user should not see another owner task, saw %', visible_count;
  END IF;
END $$;

DO $$
DECLARE
  visible_count integer;
BEGIN
  SELECT count(*) INTO visible_count FROM public.agent_evidence;
  IF visible_count <> 0 THEN
    RAISE EXCEPTION 'Different user should not see another owner evidence item, saw %', visible_count;
  END IF;
END $$;

DO $$
DECLARE
  visible_count integer;
BEGIN
  SELECT count(*) INTO visible_count FROM public.agent_approvals;
  IF visible_count <> 0 THEN
    RAISE EXCEPTION 'Different user should not see another owner approval record, saw %', visible_count;
  END IF;
END $$;

DO $$
DECLARE
  visible_count integer;
BEGIN
  SELECT count(*) INTO visible_count FROM public.agent_events;
  IF visible_count <> 0 THEN
    RAISE EXCEPTION 'Different user should not see another owner event record, saw %', visible_count;
  END IF;
END $$;

DO $$
DECLARE
  visible_count integer;
BEGIN
  SELECT count(*) INTO visible_count FROM public.agent_results;
  IF visible_count <> 0 THEN
    RAISE EXCEPTION 'Different user should not see another owner result record, saw %', visible_count;
  END IF;
END $$;

DO $$
BEGIN
  INSERT INTO public.agent_evidence(
    task_id,
    packet_task_id,
    evidence_id,
    evidence_type,
    summary,
    source_system,
    status
  ) VALUES (
    '10000000-0000-0000-0000-000000000001',
    'workboard-10000000-0000-0000-0000-000000000001',
    'evidence-cross-owner-1',
    'manual_observation',
    'Cross-owner evidence insert should be blocked.',
    'user',
    'passed'
  );
  RAISE EXCEPTION 'Cross-owner evidence insert was allowed';
EXCEPTION WHEN insufficient_privilege THEN
  NULL;
END $$;

DO $$
BEGIN
  INSERT INTO public.agent_approvals(
    task_id,
    packet_task_id,
    decision,
    action_type,
    approval_reason,
    approved_scope
  ) VALUES (
    '10000000-0000-0000-0000-000000000001',
    'workboard-10000000-0000-0000-0000-000000000001',
    'approved',
    'database_migration',
    'Approval required for: database_migration',
    'Cross-owner approval insert should be blocked.'
  );
  RAISE EXCEPTION 'Cross-owner approval insert was allowed';
EXCEPTION WHEN insufficient_privilege THEN
  NULL;
END $$;

DO $$
BEGIN
  INSERT INTO public.agent_events(
    task_id,
    packet_task_id,
    event_id,
    event_type,
    message,
    severity
  ) VALUES (
    '10000000-0000-0000-0000-000000000001',
    'workboard-10000000-0000-0000-0000-000000000001',
    'event-cross-owner-1',
    'progress',
    'Cross-owner event insert should be blocked.',
    'info'
  );
  RAISE EXCEPTION 'Cross-owner event insert was allowed';
EXCEPTION WHEN insufficient_privilege THEN
  NULL;
END $$;

DO $$
BEGIN
  INSERT INTO public.agent_results(
    task_id,
    packet_task_id,
    outcome,
    summary
  ) VALUES (
    '10000000-0000-0000-0000-000000000001',
    'workboard-10000000-0000-0000-0000-000000000001',
    'passed',
    'Cross-owner result insert should be blocked.'
  );
  RAISE EXCEPTION 'Cross-owner result insert was allowed';
EXCEPTION WHEN insufficient_privilege THEN
  NULL;
END $$;

RESET ROLE;

SELECT public.execute_readonly_query('select id, title from tasks', 10);

DO $$
BEGIN
  PERFORM public.execute_readonly_query('select * from tasks union select * from tasks', 10);
  RAISE EXCEPTION 'Unsafe UNION query was allowed';
EXCEPTION WHEN OTHERS THEN
  IF SQLERRM = 'Unsafe UNION query was allowed' THEN
    RAISE;
  END IF;
END $$;
`;

const migrations = readdirSync(MIGRATIONS_DIR)
  .filter((fileName) => fileName.endsWith(".sql"))
  .sort();

try {
  run("docker", [
    "run",
    "--name",
    CONTAINER_NAME,
    "-e",
    "POSTGRES_PASSWORD=postgres",
    "-e",
    "POSTGRES_DB=postgres",
    "-d",
    IMAGE,
  ]);
  waitForPostgres();
  runPsql("bootstrap Supabase-like roles", bootstrapSql);

  for (const fileName of migrations) {
    const filePath = path.join(MIGRATIONS_DIR, fileName);
    runPsql(`apply ${fileName}`, readFileSync(filePath, "utf8"));
  }

  runPsql("assert hardened migration behavior", assertionSql);
  console.log("\nSupabase migration Postgres smoke verification completed.");
} finally {
  try {
    run("docker", ["rm", "-f", CONTAINER_NAME], { timeout: COMMAND_TIMEOUT_MS });
  } catch (error) {
    console.error(`\nFailed to remove ${CONTAINER_NAME}. Run 'docker rm -f ${CONTAINER_NAME}' manually.`);
    console.error(error instanceof Error ? error.message : error);
  }
}
