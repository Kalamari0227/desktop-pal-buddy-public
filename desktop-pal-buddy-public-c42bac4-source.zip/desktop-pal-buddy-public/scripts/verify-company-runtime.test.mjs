import assert from "node:assert/strict";
import { execFileSync, spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import {
  appendFileSync,
  cpSync,
  existsSync,
  mkdtempSync,
  mkdirSync,
  readFileSync,
  readdirSync,
  rmSync,
  writeFileSync,
} from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import test from "node:test";
import { computeCodeTreeDigest } from "./verify-company-package.mjs";

const repoRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const verifierPath = join(repoRoot, "scripts/verify-company-runtime.mjs");
const planPath = join(repoRoot, ".omo/plans/brave-new-company-future-erp.md");
const lanes = ["F1", "F2", "F3", "F4"];
const componentTaskIds = {
  C1: [12, 15, 23, 24],
  C2: [3, 6],
  C3: [7, 8, 9, 10, 13, 14, 15],
  C4: [4, 9, 13, 15, 22],
  C5: [16, 17, 18, 19, 22],
  C6: [20, 21],
};

function sha256(contents) {
  return createHash("sha256").update(contents).digest("hex");
}

function writeJson(path, value) {
  writeFileSync(path, `${JSON.stringify(value, null, 2)}\n`);
}

function fixtureComponents(records) {
  const recordsByTask = new Map(records.map((record) => [record.task, record]));
  return Object.entries(componentTaskIds).map(([id, taskIds]) => ({
    id,
    status: "PASS",
    evidence: taskIds.map((taskId) => {
      const record = recordsByTask.get(taskId);
      return {
        taskId,
        path: record.path,
        sha256: record.sha256,
        command: `fixture command for task ${taskId}`,
        exitCode: 0,
        assertions: [`task ${taskId} fixture assertion`],
        runtimeMode: taskId === 23 ? "live" : "not_applicable",
      };
    }),
  }));
}

function createTaskEvidenceFixture(root, exactSha) {
  const evidenceRoot = join(root, "evidence");
  const evidenceDir = join(evidenceRoot, "task-25");
  mkdirSync(evidenceDir, { recursive: true });
  const records = Array.from({ length: 24 }, (_, index) => {
    const task = index + 1;
    const path = `task-${task}.json`;
    const contents = `${JSON.stringify({ task, exactSha })}\n`;
    writeFileSync(join(evidenceRoot, path), contents);
    return { task, path, exactSha, sha256: sha256(contents), size: Buffer.byteLength(contents), kind: "json" };
  });
  writeJson(join(evidenceDir, "task-25-task-evidence-manifest.json"), {
    schemaVersion: 1,
    contract: "task-1-24-exact-sha-known-artifact",
    records,
  });
  const task25Path = "task-25/implementation-report.md";
  const task25Contents = `Task 25 fixture for ${exactSha}\n`;
  writeFileSync(join(evidenceRoot, task25Path), task25Contents);
  const taskRecords = records.map((record) => ({
    taskId: record.task,
    status: "PASS",
    evidence: [{
      taskId: record.task,
      path: record.path,
      sha256: record.sha256,
      command: `fixture command for task ${record.task}`,
      exitCode: 0,
      assertions: [`task ${record.task} fixture assertion`],
      runtimeMode: record.task === 23 ? "live" : "not_applicable",
    }],
  }));
  taskRecords.push({
    taskId: 25,
    status: "PASS",
    evidence: [{
      taskId: 25,
      path: task25Path,
      sha256: sha256(task25Contents),
      command: "fixture command for task 25",
      exitCode: 0,
      assertions: ["task 25 fixture assertion"],
      runtimeMode: "not_applicable",
    }],
  });
  return { evidenceDir, records, taskRecords };
}

async function createFixture() {
  const root = mkdtempSync(join(tmpdir(), "bnc-f5-test-"));
  const reviewDir = join(root, "reviews");
  mkdirSync(reviewDir);
  const exactSha = execFileSync("git", ["rev-parse", "HEAD"], { cwd: repoRoot, encoding: "utf8" }).trim();
  const planSha256 = sha256(readFileSync(planPath));
  const codeTreeDigest = await computeCodeTreeDigest(repoRoot);
  const taskEvidence = createTaskEvidenceFixture(root, exactSha);
  const preFinalPath = join(root, "acceptance.pre-final.json");
  const preFinal = {
    schemaVersion: 1,
    phase: "implementation_verified",
    ok: true,
    preFinal: true,
    exactSha,
    planSha256,
    codeTreeDigest,
    sourceRows: 18,
    tasks: { required: 25, evidenceTasks: 24, records: taskEvidence.taskRecords },
    actualAI: true,
    packageLive: { live: true, appIsPackaged: true, providerCalls: 2 },
    evidenceDir: taskEvidence.evidenceDir,
    components: fixtureComponents(taskEvidence.records),
  };
  writeJson(preFinalPath, preFinal);
  const preFinalSha256 = sha256(readFileSync(preFinalPath));
  for (const lane of lanes) {
    const reportPath = join(reviewDir, `${lane}.md`);
    writeFileSync(reportPath, `# ${lane} review\n\nAPPROVE\n`);
    writeJson(join(reviewDir, `${lane}.json`), {
      schemaVersion: 1,
      reviewId: lane,
      verdict: lane === "F3" ? "CONFIRMED" : "APPROVE",
      recommendation: "APPROVE",
      confirmed: true,
      exactSha,
      reviewedSha: exactSha,
      planSha256,
      codeTreeDigest,
      preFinalSha256,
      reportPath,
      reportSha256: sha256(readFileSync(reportPath)),
    });
  }
  return {
    root,
    reviewDir,
    preFinalPath,
    finalPath: join(root, "acceptance.json"),
    exactSha,
    planSha256,
    codeTreeDigest,
    cleanup: () => rmSync(root, { recursive: true, force: true }),
  };
}

function runImplementation(evidenceDir, writePreFinal) {
  const args = [verifierPath, "--phase", "implementation", "--evidence-dir", evidenceDir];
  if (writePreFinal) args.push("--write-pre-final", writePreFinal);
  const result = spawnSync(process.execPath, args, { cwd: repoRoot, encoding: "utf8" });
  return { ...result, output: JSON.parse(result.stdout) };
}

function createIsolatedImplementationEvidence(root) {
  const sourceRoot = join(repoRoot, ".omo/evidence/brave-new-company-future-erp");
  const evidenceRoot = join(root, "evidence");
  const evidenceDir = join(evidenceRoot, "task-25");
  cpSync(join(sourceRoot, "task-25"), evidenceDir, { recursive: true });
  cpSync(
    // Keep the current native receipt's observed facts intact.  In
    // particular, this successful receipt records quarantinedInterpretation
    // as false.
    join(sourceRoot, "task-23", "native-final-65cfddb"),
    join(evidenceRoot, "task-23", "native-fallback-7ce405a"),
    { recursive: true },
  );
  cpSync(
    join(sourceRoot, "task-24", "package-fallback-7ce405a"),
    join(evidenceRoot, "task-24", "package-fallback-7ce405a"),
    { recursive: true },
  );
  const exactSha = execFileSync("git", ["rev-parse", "HEAD"], { cwd: repoRoot, encoding: "utf8" }).trim();
  const nativeRoot = join(evidenceRoot, "task-23", "native-fallback-7ce405a");
  const nativeReportPath = join(nativeRoot, "report.json");
  rewriteJson(nativeReportPath, (value) => ({ ...value, commit: exactSha }));
  writeFileSync(join(nativeRoot, "pre-run-head.txt"), `${exactSha}\n`);
  writeFileSync(join(nativeRoot, "post-run-head.txt"), `${exactSha}\n`);
  // The current authoritative receipt has the command-exit artifact.  The
  // older fixture-only exit.code sidecar is deliberately not synthesized.
  const manifestPath = join(evidenceDir, "task-25-task-evidence-manifest.json");
  rewriteJson(manifestPath, (value) => ({
    ...value,
    records: value.records.map((record) => record.task === 23
      ? {
          ...record,
          exactSha,
          sha256: sha256(readFileSync(nativeReportPath)),
          size: readFileSync(nativeReportPath).byteLength,
        }
      : record),
  }));
  rewriteJson(join(evidenceRoot, "task-24", "package-fallback-7ce405a", "package", "company-package-receipt.json"), (value) => ({ ...value, gitCommit: exactSha }));
  rewriteJson(join(evidenceDir, "task-25-package-receipt.json"), (value) => ({ ...value, gitCommit: exactSha }));
  rewriteJson(join(evidenceDir, "task-25-package-live.json"), (value) => ({
    ...value,
    handoffCommit: exactSha,
    executionCommit: exactSha,
    handoff: { ...value.handoff, exactSha },
  }));
  const manifest = JSON.parse(readFileSync(manifestPath, "utf8"));
  for (const record of manifest.records) {
    if (record.task === 23) continue;
    const destination = join(evidenceRoot, record.path);
    mkdirSync(dirname(destination), { recursive: true });
    cpSync(join(sourceRoot, record.path), destination);
  }
  return evidenceDir;
}

function runFinal(fixture, overrides = {}) {
  const result = spawnSync(process.execPath, [
    verifierPath,
    "--phase", "final",
    "--pre-final", overrides.preFinalPath ?? fixture.preFinalPath,
    "--review-dir", overrides.reviewDir ?? fixture.reviewDir,
    "--write-final", overrides.finalPath ?? fixture.finalPath,
  ], { cwd: repoRoot, encoding: "utf8" });
  return { ...result, output: JSON.parse(result.stdout) };
}

function rewriteJson(path, update) {
  const current = JSON.parse(readFileSync(path, "utf8"));
  writeJson(path, update(current));
}

test("writes exact final acceptance when the fixed pre-final and F1-F4 reports are approved", async () => {
  const fixture = await createFixture();
  try {
    const result = runFinal(fixture);
    assert.equal(result.status, 0);
    const acceptance = JSON.parse(readFileSync(fixture.finalPath, "utf8"));
    assert.equal(acceptance.phase, "final_verified");
    assert.equal(acceptance.exactSha, fixture.exactSha);
    assert.equal(acceptance.planSha256, fixture.planSha256);
    assert.equal(acceptance.codeTreeDigest, fixture.codeTreeDigest);
    assert.equal(acceptance.preFinalRef.sha256, sha256(readFileSync(fixture.preFinalPath)));
    assert.deepEqual(acceptance.finalReviews.map(({ reviewId, verdict }) => ({ reviewId, verdict })),
      lanes.map((reviewId) => ({ reviewId, verdict: "APPROVE" })));
    assert.equal(acceptance.aggregateVerdict, "APPROVE");
  } finally {
    fixture.cleanup();
  }
});

test("implementation pre-final emits one manifest-bound component for each C1-C6", async () => {
  const root = mkdtempSync(join(tmpdir(), "bnc-components-test-"));
  const evidenceDir = createIsolatedImplementationEvidence(root);
  const preFinalPath = join(root, "acceptance.pre-final.json");
  try {
    const result = runImplementation(evidenceDir, preFinalPath);
    assert.equal(result.status, 0, JSON.stringify(result.output));
    const preFinal = JSON.parse(readFileSync(preFinalPath, "utf8"));
    assert.deepEqual(preFinal.components.map(({ id }) => id), Object.keys(componentTaskIds));
    assert.deepEqual(preFinal.components.map(({ status }) => status), ["PASS", "PASS", "PASS", "PASS", "PASS", "PASS"]);
    const manifest = JSON.parse(readFileSync(join(evidenceDir, "task-25-task-evidence-manifest.json"), "utf8"));
    const records = new Map(manifest.records.map((record) => [record.task, record]));
    for (const component of preFinal.components) {
      assert.ok(component.evidence.length > 0);
      for (const evidence of component.evidence) {
        const record = records.get(evidence.taskId);
        assert.ok(record);
        assert.equal(evidence.path, record.path);
        assert.equal(evidence.sha256, record.sha256);
        assert.equal(typeof evidence.command, "string");
        assert.equal(Number.isInteger(evidence.exitCode), true);
        assert.ok(evidence.assertions.length > 0);
        assert.ok(["stub", "live", "not_applicable"].includes(evidence.runtimeMode));
      }
    }
  } finally {
    rmSync(root, { recursive: true, force: true });
  }
});

test("implementation promotes Task23 and C1 from exact native and packaged live receipts", async () => {
  const root = mkdtempSync(join(tmpdir(), "bnc-task23-live-contract-test-"));
  const evidenceDir = createIsolatedImplementationEvidence(root);
  const attemptDir = join(evidenceDir, "verifier-attempt");
  const preFinalPath = join(attemptDir, "acceptance.pre-final.json");
  try {
    mkdirSync(attemptDir);
    assert.equal(JSON.parse(readFileSync(join(evidenceDir, "..", "task-23", "native-fallback-7ce405a", "live.json"), "utf8")).quarantinedInterpretation, false);
    assert.equal(JSON.parse(readFileSync(join(evidenceDir, "..", "task-23", "native-fallback-7ce405a", "report.json"), "utf8")).secondRequest.quarantinedInterpretation, false);
    const result = runImplementation(attemptDir, preFinalPath);
    assert.equal(result.status, 0, JSON.stringify(result.output));
    assert.equal(result.output.attemptDir, attemptDir);
    const preFinal = JSON.parse(readFileSync(preFinalPath, "utf8"));
    assert.equal(preFinal.tasks.records.find(({ taskId }) => taskId === 23)?.status, "PASS");
    assert.equal(preFinal.components.find(({ id }) => id === "C1")?.status, "PASS");
    const task23 = preFinal.tasks.records.find(({ taskId }) => taskId === 23);
    assert.equal(task23?.evidence[0].exitCode, 0);
    assert.equal(task23?.evidence[0].runtimeMode, "live");
    assert.deepEqual(preFinal.packageLive, { live: true, appIsPackaged: true, providerCalls: 2 });
    assert.equal(preFinal.actualAI, true);
  } finally {
    rmSync(root, { recursive: true, force: true });
  }
});

const implementationReceiptFailureCases = [
  {
    name: "rejects a malformed Task23 native live receipt",
    code: "invalid_evidence_json",
    mutate: (evidenceRoot) => writeFileSync(join(evidenceRoot, "..", "task-23", "native-fallback-7ce405a", "live.json"), "{\n"),
  },
  {
    name: "rejects a missing Task23 native live receipt",
    code: "invalid_evidence_json",
    mutate: (evidenceRoot) => rmSync(join(evidenceRoot, "..", "task-23", "native-fallback-7ce405a", "live.json")),
  },
  {
    name: "rejects a stale exact SHA in the Task23 native report",
    code: "task23_native_report_contract_failed",
    mutate: (evidenceRoot) => rewriteJson(join(evidenceRoot, "..", "task-23", "native-fallback-7ce405a", "report.json"), (value) => ({ ...value, commit: "0".repeat(40) })),
  },
  {
    name: "rejects a misleading PASS package receipt with the wrong provider count",
    code: "task24_package_live_contract_failed",
    mutate: (evidenceRoot) => rewriteJson(join(evidenceRoot, "..", "task-24", "package-fallback-7ce405a", "task-24-package-live.json"), (value) => ({ ...value, providerCalls: 1 })),
  },
  {
    name: "rejects a non-boolean Task23 quarantine receipt field",
    code: "task23_native_quarantine_contract_failed",
    mutate: (evidenceRoot) => rewriteJson(join(evidenceRoot, "..", "task-23", "native-fallback-7ce405a", "live.json"), (value) => ({ ...value, quarantinedInterpretation: "false" })),
  },
  {
    name: "rejects a Task23 report quarantine field that disagrees with the live receipt",
    code: "task23_native_quarantine_contract_failed",
    mutate: (evidenceRoot) => rewriteJson(join(evidenceRoot, "..", "task-23", "native-fallback-7ce405a", "report.json"), (value) => ({
      ...value,
      secondRequest: { ...value.secondRequest, quarantinedInterpretation: true },
    })),
  },
];

for (const failureCase of implementationReceiptFailureCases) {
  test(failureCase.name, async () => {
    const root = mkdtempSync(join(tmpdir(), "bnc-live-receipt-failure-test-"));
    const evidenceDir = createIsolatedImplementationEvidence(root);
    try {
      failureCase.mutate(evidenceDir);
      const result = runImplementation(evidenceDir);
      assert.equal(result.status, 1);
      assert.ok(result.output.errors.some(({ code }) => code === failureCase.code), JSON.stringify(result.output));
      assert.equal(result.output.tasks.records.find(({ taskId }) => taskId === 23)?.status, "BLOCKED");
      assert.equal(result.output.components.find(({ id }) => id === "C1")?.status, "BLOCKED");
      assert.equal(result.output.actualAI, false);
    } finally {
      rmSync(root, { recursive: true, force: true });
    }
  });
}

test("implementation writer emits a final-consumable pre-final once from isolated evidence", async () => {
  const root = mkdtempSync(join(tmpdir(), "bnc-writer-contract-test-"));
  const evidenceDir = createIsolatedImplementationEvidence(root);
  const preFinalPath = join(root, "acceptance.pre-final.json");
  const reviewDir = join(root, "reviews");
  const finalPath = join(root, "acceptance.json");
  try {
    // Given: isolated Task 1-25 evidence and the current plan/code identity.
    const expectedExactSha = execFileSync("git", ["rev-parse", "HEAD"], { cwd: repoRoot, encoding: "utf8" }).trim();
    const expectedPlanSha256 = sha256(readFileSync(planPath));
    const expectedCodeTreeDigest = await computeCodeTreeDigest(repoRoot);

    // When: the implementation CLI writes the pre-final contract.
    const result = runImplementation(evidenceDir, preFinalPath);

    // Then: the artifact is directly consumable by F5 and retains implementation evidence.
    assert.equal(result.status, 0, JSON.stringify(result.output));
    const preFinalContents = readFileSync(preFinalPath);
    const preFinal = JSON.parse(preFinalContents);
    assert.equal(preFinal.schemaVersion, 1);
    assert.equal(preFinal.phase, "implementation_verified");
    assert.equal(preFinal.preFinal, true);
    assert.equal(preFinal.exactSha, expectedExactSha);
    assert.equal(preFinal.planSha256, expectedPlanSha256);
    assert.equal(preFinal.codeTreeDigest, expectedCodeTreeDigest);
    assert.equal(preFinal.writtenBy, "verify-company-runtime");
    assert.equal(preFinal.tasks.required, 25);
    assert.equal(preFinal.tasks.evidenceTasks, 24);
    assert.deepEqual(preFinal.tasks.records.map(({ taskId }) => taskId), Array.from({ length: 25 }, (_, index) => index + 1));
    for (const record of preFinal.tasks.records) {
      assert.ok(["PASS", "FAIL", "BLOCKED"].includes(record.status));
      assert.ok(record.evidence.length > 0);
      for (const evidence of record.evidence) {
        assert.equal(evidence.taskId, record.taskId);
        assert.equal(typeof evidence.path, "string");
        assert.match(evidence.sha256, /^[0-9a-f]{64}$/);
        assert.equal(typeof evidence.command, "string");
        assert.equal(Number.isInteger(evidence.exitCode), true);
        assert.ok(evidence.assertions.length > 0);
        assert.ok(["stub", "live", "not_applicable"].includes(evidence.runtimeMode));
      }
    }
    const manifestByTask = new Map(JSON.parse(readFileSync(join(evidenceDir, "task-25-task-evidence-manifest.json"), "utf8"))
      .records.map((record) => [record.task, record]));
    for (const record of preFinal.tasks.records.slice(0, 24)) {
      assert.equal(record.evidence[0].path, manifestByTask.get(record.taskId).path);
      assert.equal(record.evidence[0].sha256, manifestByTask.get(record.taskId).sha256);
    }
    const task25Evidence = preFinal.tasks.records[24].evidence[0];
    assert.equal(task25Evidence.path, "task-25/implementation-report.md");
    assert.equal(task25Evidence.sha256, sha256(readFileSync(join(evidenceDir, "implementation-report.md"))));
    assert.deepEqual(
      { sourceRows: preFinal.sourceRows, expectedSourceRows: preFinal.expectedSourceRows },
      { sourceRows: 18, expectedSourceRows: 18 },
    );
    assert.deepEqual(preFinal.packageLive, { live: true, appIsPackaged: true, providerCalls: 2 });
    assert.deepEqual(preFinal.taskEvidenceManifest, { contract: "task-1-24-exact-sha-known-artifact", records: 24 });
    assert.deepEqual(preFinal.components.map(({ id }) => id), Object.keys(componentTaskIds));
    assert.deepEqual(readdirSync(root).filter((name) => name.includes(".tmp-")), []);

    const firstHash = sha256(preFinalContents);
    const repeated = runImplementation(evidenceDir, preFinalPath);
    assert.equal(repeated.status, 1);
    assert.ok(repeated.output.errors.some(({ code }) => code === "pre_final_output_exists"), JSON.stringify(repeated.output));
    assert.equal(sha256(readFileSync(preFinalPath)), firstHash);
    assert.deepEqual(readdirSync(root).filter((name) => name.includes(".tmp-")), []);

    mkdirSync(reviewDir);
    const preFinalSha256 = sha256(preFinalContents);
    for (const lane of lanes) {
      const reportPath = join(reviewDir, `${lane}.md`);
      writeFileSync(reportPath, `# ${lane} review\n\nAPPROVE\n`);
      writeJson(join(reviewDir, `${lane}.json`), {
        schemaVersion: 1,
        reviewId: lane,
        verdict: "APPROVE",
        exactSha: expectedExactSha,
        planSha256: expectedPlanSha256,
        codeTreeDigest: expectedCodeTreeDigest,
        preFinalSha256,
        reportPath,
        reportSha256: sha256(readFileSync(reportPath)),
      });
    }
    const finalResult = runFinal({ preFinalPath, reviewDir, finalPath });
    assert.equal(finalResult.status, 0, JSON.stringify(finalResult.output));
    assert.equal(JSON.parse(readFileSync(finalPath, "utf8")).phase, "final_verified");
  } finally {
    rmSync(root, { recursive: true, force: true });
  }
});

const failureCases = [
  {
    name: "rejects a missing F3 report",
    code: "missing_review_json",
    mutate: (fixture) => rmSync(join(fixture.reviewDir, "F3.json")),
  },
  {
    name: "rejects an F2 REJECT verdict",
    code: "review_not_approved",
    mutate: (fixture) => rewriteJson(join(fixture.reviewDir, "F2.json"), (value) => ({ ...value, verdict: "REJECT" })),
  },
  {
    name: "rejects a stale review SHA",
    code: "review_sha_mismatch",
    mutate: (fixture) => rewriteJson(join(fixture.reviewDir, "F1.json"), (value) => ({ ...value, exactSha: "0".repeat(40) })),
  },
  {
    name: "rejects a current-plan digest mismatch",
    code: "pre_final_plan_mismatch",
    mutate: (fixture) => rewriteJson(fixture.preFinalPath, (value) => ({ ...value, planSha256: "0".repeat(64) })),
  },
  {
    name: "rejects a current-code digest mismatch",
    code: "pre_final_code_tree_mismatch",
    mutate: (fixture) => rewriteJson(fixture.preFinalPath, (value) => ({ ...value, codeTreeDigest: "0".repeat(64) })),
  },
  {
    name: "rejects a lane code-tree digest mismatch",
    code: "review_code_tree_mismatch",
    mutate: (fixture) => rewriteJson(join(fixture.reviewDir, "F4.json"), (value) => ({ ...value, codeTreeDigest: "0".repeat(64) })),
  },
  {
    name: "rejects a mutated Markdown report",
    code: "review_report_hash_mismatch",
    mutate: (fixture) => appendFileSync(join(fixture.reviewDir, "F3.md"), "mutated\n"),
  },
  {
    name: "rejects a copied review directory whose immutable report paths point elsewhere",
    code: "review_report_path_mismatch",
    mutate: (fixture) => {
      const copy = join(fixture.root, "copied-reviews");
      cpSync(fixture.reviewDir, copy, { recursive: true });
      fixture.reviewDir = copy;
    },
  },
  {
    name: "rejects malformed pre-final JSON",
    code: "invalid_evidence_json",
    mutate: (fixture) => writeFileSync(fixture.preFinalPath, "{\n"),
  },
  {
    name: "rejects a pre-final without task records",
    code: "task_records_missing",
    mutate: (fixture) => rewriteJson(fixture.preFinalPath, (value) => ({
      ...value,
      tasks: { required: 25, evidenceTasks: 24 },
    })),
  },
  {
    name: "rejects duplicate task ids",
    code: "task_id_duplicate",
    mutate: (fixture) => rewriteJson(fixture.preFinalPath, (value) => ({
      ...value,
      tasks: {
        ...value.tasks,
        records: value.tasks.records.map((record, index) => index === 1
          ? { ...record, taskId: 1, evidence: record.evidence.map((evidence) => ({ ...evidence, taskId: 1 })) }
          : record),
      },
    })),
  },
  {
    name: "rejects an out-of-range task id",
    code: "task_id_unexpected",
    mutate: (fixture) => rewriteJson(fixture.preFinalPath, (value) => ({
      ...value,
      tasks: {
        ...value.tasks,
        records: value.tasks.records.map((record, index) => index === 24
          ? { ...record, taskId: 26, evidence: record.evidence.map((evidence) => ({ ...evidence, taskId: 26 })) }
          : record),
      },
    })),
  },
  {
    name: "rejects missing task evidence fields",
    code: "task_evidence_command_invalid",
    mutate: (fixture) => rewriteJson(fixture.preFinalPath, (value) => ({
      ...value,
      tasks: {
        ...value.tasks,
        records: value.tasks.records.map((record, index) => index === 0
          ? { ...record, evidence: record.evidence.map((evidence) => ({ ...evidence, command: "" })) }
          : record),
      },
    })),
  },
  {
    name: "rejects a missing task status",
    code: "task_status_invalid",
    mutate: (fixture) => rewriteJson(fixture.preFinalPath, (value) => ({
      ...value,
      tasks: {
        ...value.tasks,
        records: value.tasks.records.map((record, index) => index === 0
          ? { ...record, status: null }
          : record),
      },
    })),
  },
  {
    name: "rejects an empty task evidence array",
    code: "task_evidence_missing",
    mutate: (fixture) => rewriteJson(fixture.preFinalPath, (value) => ({
      ...value,
      tasks: {
        ...value.tasks,
        records: value.tasks.records.map((record, index) => index === 0
          ? { ...record, evidence: [] }
          : record),
      },
    })),
  },
  {
    name: "rejects a nonexistent task evidence path",
    code: "task_evidence_artifact_missing",
    mutate: (fixture) => rewriteJson(fixture.preFinalPath, (value) => ({
      ...value,
      tasks: {
        ...value.tasks,
        records: value.tasks.records.map((record, index) => index === 24
          ? { ...record, evidence: record.evidence.map((evidence) => ({ ...evidence, path: "task-25/missing.md" })) }
          : record),
      },
    })),
  },
  {
    name: "rejects a task evidence hash mismatch",
    code: "task_evidence_artifact_hash_mismatch",
    mutate: (fixture) => rewriteJson(fixture.preFinalPath, (value) => ({
      ...value,
      tasks: {
        ...value.tasks,
        records: value.tasks.records.map((record, index) => index === 24
          ? { ...record, evidence: record.evidence.map((evidence) => ({ ...evidence, sha256: "0".repeat(64) })) }
          : record),
      },
    })),
  },
  {
    name: "rejects a task artifact mutated after pre-final creation",
    code: "task_evidence_artifact_hash_mismatch",
    mutate: (fixture) => {
      const preFinal = JSON.parse(readFileSync(fixture.preFinalPath, "utf8"));
      const evidencePath = preFinal.tasks.records[0].evidence[0].path;
      appendFileSync(resolve(preFinal.evidenceDir, "..", evidencePath), "mutated\n");
    },
  },
  {
    name: "rejects inconsistent task evidence ids",
    code: "task_evidence_task_mismatch",
    mutate: (fixture) => rewriteJson(fixture.preFinalPath, (value) => ({
      ...value,
      tasks: {
        ...value.tasks,
        records: value.tasks.records.map((record, index) => index === 1
          ? { ...record, evidence: record.evidence.map((evidence) => ({ ...evidence, taskId: 1 })) }
          : record),
      },
    })),
  },
  {
    name: "rejects a task path inconsistent with the manifest",
    code: "task_evidence_manifest_path_mismatch",
    mutate: (fixture) => rewriteJson(fixture.preFinalPath, (value) => ({
      ...value,
      tasks: {
        ...value.tasks,
        records: value.tasks.records.map((record, index) => index === 1
          ? { ...record, evidence: record.evidence.map((evidence) => ({ ...evidence, path: value.tasks.records[0].evidence[0].path })) }
          : record),
      },
    })),
  },
  {
    name: "rejects a pre-final without the exact C1-C6 component set",
    code: "component_contract_missing",
    mutate: (fixture) => rewriteJson(fixture.preFinalPath, (value) => {
      const { components: _components, ...withoutComponents } = value;
      return withoutComponents;
    }),
  },
  {
    name: "rejects malformed component evidence",
    code: "component_evidence_hash_invalid",
    mutate: (fixture) => rewriteJson(fixture.preFinalPath, (value) => ({
      ...value,
      components: value.components.map((component, index) => index === 0
        ? { ...component, evidence: [{ ...component.evidence[0], sha256: "" }] }
        : component),
    })),
  },
  {
    name: "rejects duplicate component ids",
    code: "component_id_duplicate",
    mutate: (fixture) => rewriteJson(fixture.preFinalPath, (value) => ({
      ...value,
      components: value.components.map((component, index) => index === 1 ? { ...component, id: "C1" } : component),
    })),
  },
  {
    name: "rejects malformed review JSON",
    code: "invalid_evidence_json",
    mutate: (fixture) => writeFileSync(join(fixture.reviewDir, "F1.json"), "{\n"),
  },
];

for (const failureCase of failureCases) {
  test(failureCase.name, async () => {
    const fixture = await createFixture();
    try {
      failureCase.mutate(fixture);
      const result = runFinal(fixture);
      assert.equal(result.status, 1);
      assert.ok(result.output.errors.some(({ code }) => code === failureCase.code), JSON.stringify(result.output));
      assert.equal(existsSync(fixture.finalPath), false);
    } finally {
      fixture.cleanup();
    }
  });
}

test("does not overwrite an existing final acceptance", async () => {
  const fixture = await createFixture();
  try {
    writeFileSync(fixture.finalPath, "sentinel\n");
    const result = runFinal(fixture);
    assert.equal(result.status, 1);
    assert.ok(result.output.errors.some(({ code }) => code === "final_output_exists"));
    assert.equal(readFileSync(fixture.finalPath, "utf8"), "sentinel\n");
  } finally {
    fixture.cleanup();
  }
});

test("a repeated invocation fails without changing the first final acceptance", async () => {
  const fixture = await createFixture();
  try {
    assert.equal(runFinal(fixture).status, 0);
    const firstHash = sha256(readFileSync(fixture.finalPath));
    const repeated = runFinal(fixture);
    assert.equal(repeated.status, 1);
    assert.ok(repeated.output.errors.some(({ code }) => code === "final_output_exists"));
    assert.equal(sha256(readFileSync(fixture.finalPath)), firstHash);
  } finally {
    fixture.cleanup();
  }
});
