
# Knowledge Canvas Graph Architecture

Version: 1.0  
Purpose: Knowledge Canvas의 그래프 렌더링, 레이아웃, 상태 전환, 성능 전략을 정의하는 아키텍처 문서

---

# 1. Overview

Knowledge Canvas는 단순 시각화 레이어가 아니라, 데스크탑 AI 비서의 핵심 업무 지식 인터페이스다.  
이 문서는 다음을 정의한다.

- 그래프 렌더링 방식
- Opening Scene → Canvas 전환 구조
- 노드 / 엣지 / 클러스터의 화면 표현
- 레이아웃 엔진
- 상태 관리
- 성능 최적화 전략
- 확장 시 고려사항

---

# 2. Design Principles

## 2.1 제품 원칙

1. 그래프는 "보기 좋은 그림"이 아니라 **업무 맥락 탐색 도구**여야 한다.
2. 사용자는 복잡한 네트워크를 보더라도 **현재 중요한 것**을 바로 파악할 수 있어야 한다.
3. Opening Scene의 neural network는 Canvas의 초기 상태와 **동일한 세계관**을 공유해야 한다.
4. 그래프는 실시간성보다 **이해 가능성(Explainability)** 을 우선한다.
5. AI 제안은 자동 생성되더라도 사용자 검토 가능한 구조여야 한다.

---

# 3. Recommended Rendering Strategy

## 3.1 Recommended Option

**Single R3F Canvas**

Opening Scene과 Knowledge Canvas를 하나의 React Three Fiber Canvas에서 처리한다.

구조

Boot / Synapse Formation  
↓  
Flatten Transition  
↓  
Knowledge Canvas Mode  
↓  
Cluster / Detail / Action Modes  

## 3.2 Why

- Opening → Canvas 전환이 가장 자연스럽다
- 배경 network와 실제 graph가 단절되지 않는다
- 동일한 노드 객체를 연출 / 탐색 / 상호작용에 재사용할 수 있다
- 장기적으로 Ambient background, Mini graph, Full workspace를 통합하기 쉽다

---

# 4. Rendering Layers

Knowledge Canvas는 아래 5개 레이어로 분리한다.

## Layer 1. Background Field

- 약한 입자장
- depth 느낌을 주는 저강도 particle motion
- Ambient mode에서 상시 표시 가능

## Layer 2. Graph Core

- 노드
- 엣지
- 클러스터 hull / glow
- force / anchored layout 결과 반영

## Layer 3. Semantic Labels

- 노드명
- 유형 아이콘
- 중요 배지
- AI 추천 연결 표시

## Layer 4. Interaction Overlay

- hover 상태
- selection ring
- drag indicator
- edge highlight
- context target preview

## Layer 5. UI Panels

- 좌측 필터 패널
- 우측 detail / insight / action 패널
- 상단 mode switch / search / breadcrumbs

---

# 5. App Modes

## 5.1 Ambient Mode

- Background Field + 약한 Graph Core 일부만 표시
- 클릭 가능한 소수 노드만 보임
- CPU / GPU 부하를 낮게 유지
- Assistant Dock와 공존

## 5.2 Workspace Mode

- 기본 Knowledge Canvas 작업 화면
- 필터 / 검색 / 군집 탐색 가능
- 최근 문서, 고객, 회의, 액션 중심

## 5.3 Focus Mode

- 선택된 클러스터 또는 특정 주제 확대
- 관련 노드 / 링크만 강조
- 인사이트 생성 및 액션 수행 적합

## 5.4 Analysis Mode

- 리스크, 이슈 확산, 주제 흐름, 고객 히스토리 분석용
- timeline, cluster compare, evidence chain 강화

---

# 6. Graph Object Model

## 6.1 Node Categories

Primary
- memo
- meeting
- customer
- document
- action

Secondary
- product
- issue
- risk
- ai_insight
- project
- report

## 6.2 Edge Categories

- related
- same_customer
- same_project
- follow_up
- cause_effect
- evidence
- conflict
- derived_from
- mentioned_in

## 6.3 Cluster Types

- customer cluster
- project cluster
- meeting cluster
- issue cluster
- risk cluster
- time-window cluster

---

# 7. Layout Strategy

## 7.1 Hybrid Layout Recommended

단일 force layout만 사용하지 않고 아래 방식을 조합한다.

### Level A. Macro Layout

클러스터 단위 배치

- customer / project / issue cluster를 큰 단위로 먼저 분산
- 겹침 최소화
- 화면 내 주요 구역 형성

### Level B. Intra-Cluster Layout

클러스터 내부 force layout

- 관련 노드는 가까이 배치
- 고정 노드(anchor) 기준으로 퍼짐
- 새 노드 유입 시 주변만 부분 재계산

### Level C. Semantic Anchors

특정 노드는 화면상 의미 중심축 역할

예
- 고객 노드
- 프로젝트 노드
- 핵심 이슈 노드

이 anchor를 기준으로 주변 노드 정렬

## 7.2 Layout Recommendation by Mode

Ambient Mode  
- low-motion floating layout

Workspace Mode  
- stable force + anchor layout

Focus Mode  
- selected cluster recentered layout

Analysis Mode  
- alternative layouts allowed
  - timeline layout
  - evidence chain layout
  - bipartite layout

---

# 8. Opening → Canvas Transition Architecture

## 8.1 Transition States

boot  
network_forming  
network_expand  
flatten  
canvas_init  
workspace_ready  

## 8.2 Transition Logic

1. boot  
   중앙 신호 활성화

2. network_forming  
   입자와 연결 생성

3. network_expand  
   neural synapse 구조 확장

4. flatten  
   z-depth 감소, camera orthographic 전환, label 등장

5. canvas_init  
   필수 노드 / 패널 / 필터 로드

6. workspace_ready  
   사용자 상호작용 가능

## 8.3 Flatten Rules

- node z coordinate → 0 근접
- perspective camera → ortho camera 또는 유사 연출
- decorative particles opacity 감소
- semantic labels opacity 증가
- interactive nodes scale up
- cluster spacing 증가

---

# 9. Interaction Architecture

## 9.1 Core Interactions

- pan
- zoom
- node hover
- node select
- multi-select
- drag node
- open cluster
- filter by type
- search by entity / topic / date
- create / approve / reject connection

## 9.2 Click Behavior

Single click  
- node select

Double click  
- focus cluster or open node detail

Right click / long press  
- context menu

## 9.3 Hover Feedback

- node glow increase
- connected edges highlight
- related nodes soft highlight
- mini preview tooltip

---

# 10. Visual Rules

## 10.1 Node Visual Encoding

Size  
- importance score 반영

Brightness  
- recency / activity 반영

Shape / Icon  
- node type 반영

Outline  
- status 반영
  - needs review
  - unresolved
  - AI suggested
  - pinned

## 10.2 Edge Visual Encoding

Solid  
- confirmed relation

Dashed  
- AI suggested relation

Thicker line  
- stronger confidence

Pulse animation  
- active reasoning path / recent activity

## 10.3 Cluster Visual Encoding

- subtle glow field
- low-opacity hull
- cluster label
- activity ring optional

---

# 11. State Management

## 11.1 Recommended Stack

- Zustand for app / graph UI state
- React Query or equivalent for server sync
- memoized selectors for performance-sensitive slices

## 11.2 State Domains

### UI State
- mode
- selected_node_ids
- selected_cluster_id
- active_filters
- current_layout
- panel_visibility

### Graph State
- nodes
- edges
- clusters
- viewport
- layout_version
- hidden_ids
- suggested_links

### Data Sync State
- loading
- stale
- syncing
- error
- last_refreshed_at

---

# 12. Performance Strategy

## 12.1 MVP Target

- total nodes: up to 300
- visible nodes: up to 120~180
- visible edges: up to 250~400
- initial ready time: under 2 sec target
- transition duration: 4~6 sec

## 12.2 Techniques

1. Level-of-detail rendering
2. Label culling by zoom level
3. Edge rendering simplification
4. Cluster-first loading
5. Partial layout recomputation
6. Frustum / viewport based visibility
7. Debounced interaction updates

## 12.3 Large Graph Strategy

For 1,000+ nodes

- load by cluster
- collapse inactive clusters
- search-first reveal
- mini-map navigation
- async insight generation

---

# 13. Explainability Architecture

그래프는 “왜 연결됐는가”를 설명해야 한다.

## Explainability Sources

- shared entities
- semantic similarity
- shared document reference
- same meeting mention
- same customer / project
- AI inference summary

## UI Behavior

선택된 엣지 또는 노드에 대해 우측 패널에 표시

Example

"동일 고객명과 납기 관련 공통 키워드, 최근 회의 기록의 반복 언급으로 연결됨"

---

# 14. Error / Risk Handling

## Risks

1. 그래프가 과밀해짐
2. AI가 잘못된 연결 제안
3. 레이아웃이 자주 흔들림
4. 사용자가 의미를 이해하지 못함
5. GPU 부하 증가

## Countermeasures

- cluster collapse 기본값
- AI suggested edge는 dashed + review badge
- stable anchor layout 유지
- right panel에 간단 설명 제공
- ambient mode에서는 low-motion / low-density

---

# 15. Future Expansion

- multi-user collaboration graph
- agent-generated live nodes
- timeline replay
- scenario branch visualization
- evidence chain for decision audit
- customer journey graph
- organization memory map

---

# 16. Recommended MVP Scope

## Must Have

- primary node 5종
- edge type 3~5종
- workspace mode
- node select / detail panel
- AI suggested links
- opening → flatten → canvas transition
- cluster highlight

## Nice to Have

- analysis mode
- timeline layout
- mini-map
- agent overlays
- advanced compare mode

---

# End of Document
