# Agentic OS PRD

작성일: 2026-07-03

Status: v0 implementation draft

Related documents:

- `docs/agent-os/PRD_HANDOFF.md`
- `docs/agent-os/task-packet-schema.md`
- `docs/agent-os/evidence-ledger-schema.md`
- `docs/agent-os/approval-gate-policy.md`
- `docs/agent-os/OPERATING_PRINCIPLES.md`
- `docs/agent-os/COMPLETION_POLICY.md`
- `docs/agent-os/MEMORY_ROUTING_POLICY.md`
- `docs/agent-os/DELEGATION_POLICY.md`

## 1. Problem

사용자는 개발, 운영, 문서화, 배포 준비 작업을 여러 도구에 흩어져 수행해야 하며, 무엇을 확인해야 완료인지 판단하는 데 많은 피로를 느낀다.

현재 `desktop-pal-buddy`는 Lovable 중심 프로토타입에서 벗어나 Supabase, Electron, Agent OS 문서, Codex 작업 환경을 갖추는 단계에 있다. 다음 단계의 제품은 단순 LLM 채팅이 아니라 사용자의 업무 의도를 안전하게 실행 단위로 바꾸고, 실행 결과를 검증 가능한 증거와 함께 되돌려주는 운영 계층이어야 한다.

## 2. Goal

Agentic OS는 사용자의 업무 의도를 Gateway에서 표준 작업 단위로 변환하고, Codex 실행 환경에 안전하게 위임한 뒤, 검증 가능한 결과, 증거, blocker, 다음 액션을 사용자에게 되돌려주는 업무 운영 계층이다.

v0의 목표는 다음 실행 루프를 end-to-end로 증명하는 것이다.

```text
User
  -> Gateway request intake
  -> Task Packet
  -> Codex Worker Adapter
  -> Worker Events
  -> Evidence Ledger
  -> Result + Blockers + Next Action
  -> Retention Routing Suggestion
  -> User
```

## 3. Non-goals

Agentic OS는 무제한 자율 에이전트가 아니다.

v0에서 제외한다.

- Hermes/Eidolon 개인 에이전트 이름 또는 세계관 복제
- 앱 내부 Edge Function에 OpenAI API key를 넣는 직접 LLM 호출 구조
- Lovable gateway 의존
- production 자동 배포
- 자동 DB migration 실행
- 승인 없는 외부 메시지 발송
- 승인 없는 secret/API key 생성 또는 저장
- 유료 리소스 생성
- 여러 subagent의 완전 자동 orchestration
- 사용자의 최종 머지, 배포, 권한 변경 판단 대체

## 4. Users and Jobs To Be Done

### Primary user

개발, 운영, 문서화 작업을 Codex와 함께 수행하지만 매번 어떤 도구를 열고 어떤 검증을 해야 하는지 직접 판단하고 싶지 않은 프로젝트 운영자.

### Jobs

- "이 PR 검증해줘."
- "Supabase staging 상태 확인해줘."
- "이 자료 읽고 PRD 초안 만들어줘."
- "배포 전에 위험요소만 정리해줘."
- "이 작업이 완료됐다고 말해도 되는지 증거까지 확인해줘."

## 5. Product Principles

1. Gateway는 채팅창이 아니라 작업 접수대다.
2. 모든 사용자 요청은 가능한 한 Task Packet으로 구조화한다.
3. Codex Worker는 정답 생성기가 아니라 검증 가능한 실행자다.
4. 완료 보고에는 evidence가 필요하다.
5. 위험 작업은 자동 실행하지 않고 preflight와 승인 후 실행으로 나눈다.
6. Retention은 자동 저장보다 라우팅 제안부터 시작한다.
7. v0는 큰 운영체계가 아니라 세 가지 안전한 실행 루프를 완주하는 제품이다.

## 6. Core Concepts

### Gateway

사용자가 Agentic OS에 진입하는 실제 통로다.

v0 Gateway는 `desktop-pal-buddy` 내부 UI로 시작한다. Slack, Telegram, 이메일 같은 외부 메신저 Gateway는 인증, 권한, 포맷팅, 외부 발송 승인 문제가 안정된 뒤 확장한다.

Gateway의 책임:

- 사용자 요청 수신
- 첨부 파일, 링크, repo 파일, PR, Supabase project 같은 context 참조 정리
- 작업 유형 분류
- 위험도와 승인 필요 여부 판단
- Task Packet 생성
- Codex Worker Adapter에 작업 전달
- Worker Event를 Workboard 상태로 표시
- Evidence Ledger와 최종 결과 표시
- Retention Routing 제안

### Task Packet

Gateway가 Codex Worker에 전달하는 표준 작업 단위다.

Task Packet은 "무엇을 해야 하는지"뿐 아니라 "무엇을 하면 안 되는지", "완료 전 어떤 증거가 필요한지", "어떤 형식으로 보고해야 하는지"를 함께 담아야 한다.

Canonical schema는 `docs/agent-os/task-packet-schema.md`를 따른다.

### Codex Worker Adapter

Gateway와 실제 Codex 실행 환경 사이의 추상 계층이다.

Gateway는 특정 실행 backend에 고정되지 않는다. v0는 `ManualCodexAdapter`로 시작해 task packet을 사람이 Codex에 전달하기 좋은 형식으로 만들고, worker 결과를 Gateway에 다시 입력받는다. 이후 `Codex CLI`, `Codex app thread`, `remote worker`, `GitHub worker`로 교체할 수 있다.

### Workboard

진행 중인 작업의 상태를 보여주는 작업 보드다.

상태 모델:

```text
queued
triaging
waiting_for_approval
running
blocked
verifying
completed
failed
archived
```

### Evidence Ledger

완료의 근거를 저장하는 ledger다.

예:

- command/test 결과 요약
- GitHub PR, commit, CI 링크
- Supabase project, migration, Edge Function 상태
- advisor 결과
- 생성된 문서 경로
- 파일 diff
- 수동 관찰 기록

Canonical schema는 `docs/agent-os/evidence-ledger-schema.md`를 따른다.

### Approval Gate

위험 작업을 자동 실행하지 않도록 막고, read-only preflight와 승인 후 실행을 분리하는 정책이다.

Canonical policy는 `docs/agent-os/approval-gate-policy.md`를 따른다.

### Retention Router

작업 후 무엇을 어디에 저장할지 제안하는 라우터다.

v0는 자동 저장하지 않고 제안만 한다. 저장은 사용자 승인 후 수행한다.

Routing targets:

- stable preference -> memory
- repeated procedure -> skill
- architecture or decision -> docs/wiki
- active follow-up -> workboard
- evidence or receipt -> artifact/log
- one-time result -> no save

## 7. v0 Decisions

### Gateway interface

v0는 `desktop-pal-buddy` 내부 Gateway 화면으로 시작한다.

권장 화면명: Gateway Command Center

필수 UI:

- 요청 입력창
- context 첨부/선택
- 작업 유형 preview
- 위험도 badge
- 승인 필요 여부 표시
- task packet preview
- 실행 상태 timeline
- 결과 요약
- evidence 목록
- blocker 목록
- next action
- retention suggestion

### Worker backend

v0는 `CodexWorkerAdapter` 추상 계층을 둔다.

초기 구현 순서:

1. `ManualCodexAdapter`
2. `GitHubPrAdapter` for PR metadata and CI evidence
3. `RemoteCodexAdapter` or `CodexCLIAdapter`

### Storage

상태와 ledger는 Supabase에 저장한다.

권장 tables:

- `agent_tasks`
- `agent_task_events`
- `agent_context_refs`
- `agent_evidence`
- `agent_retention_decisions`

문서 산출물은 repo의 `docs/` 아래에 남길 수 있어야 한다. Supabase는 상태와 evidence의 source of truth, repo는 durable project documents의 source of truth로 나눈다.

### v0 task types

- `pr_verification`
- `supabase_staging_check`
- `document_to_prd`

### Business task catalog extension

Workspace business menus should converge on the same Gateway flow instead of remaining isolated hardcoded tools.

Initial business task types:

- `inventory_check`
- `urgent_material_risk_assessment`
- `delivery_delay_risk_check`
- `business_risk_review`
- `customer_reply_draft`
- `order_status_check`
- `material_substitution_review`

These task types map requests such as "재고 확인해줘", "긴급재 위험도 따져줘", "납기 지연 리스크 봐줘", and "고객 답장 초안 만들어줘" into Task Packets with approval gates and evidence requirements.

## 8. v0 Scope

v0에 포함한다.

- Gateway request intake
- Task Packet 생성
- rule-based task type classifier
- rule-based risk and approval classifier
- Workboard 상태 표시
- Evidence Ledger 표시와 저장
- Manual Codex Worker handoff
- PR verification flow
- Supabase staging check flow
- document-to-PRD flow
- Retention Routing 제안

v0에서 제외한다.

- production mutation
- 자동 DB migration 실행
- 자동 외부 메시지 발송
- secret 생성/저장 자동화
- complete autonomous long-running agent
- 여러 worker 간 자동 경쟁 실행

## 9. User Flows

### Flow A. PR Verification

User:

```text
PR #1 검증해줘.
```

Gateway:

- repo와 PR 번호를 context로 인식한다.
- `task_type = pr_verification`
- `risk_level = low`
- `required_approval = false`
- `forbidden_actions = ["do not merge", "do not push", "do not deploy"]`
- diff review, CI status, security/readiness review를 verification requirement로 추가한다.

Codex Worker:

- PR 상태 확인
- changed files 확인
- CI 상태 확인
- diff 요약
- 보안/운영 위험 체크
- readiness 판단

Completion criteria:

- PR open/mergeable/draft 여부 확인
- CI status 확인
- 변경 파일 범위 요약
- 위험 영역 분류
- ready 전환, merge, 추가 리뷰 중 next action 제안
- 최소 1개 이상의 evidence item 생성

Gateway result:

- 결론
- 주요 변경 범위
- evidence 목록
- risks
- blockers
- next action

### Flow B. Supabase Staging Check

User:

```text
staging 상태 확인해줘.
```

Gateway:

- Supabase project ref를 context로 포함한다.
- `task_type = supabase_staging_check`
- read-only 점검이면 `risk_level = medium`, `required_approval = false`
- mutation 요청이 포함되면 `waiting_for_approval`로 전환한다.
- `forbidden_actions = ["do not run migration", "do not change secrets", "do not deploy functions"]`

Codex Worker:

- project health 확인
- migration list 확인
- Edge Function 상태 확인
- advisor result 확인
- RLS/rate limit 관련 known warning 분류

Completion criteria:

- project status 확인
- migrations 상태 확인
- Edge Functions 상태 확인
- advisor warning 중 의도된 것과 조치 필요한 것 분리
- 최소 1개 이상의 evidence item 생성

Gateway result:

- normal/warning/blocked 분류
- evidence ledger
- next action

### Flow C. Document-to-PRD

User:

```text
이 자료 기반으로 PRD 초안 만들어줘.
```

Gateway:

- 첨부 파일을 `context_refs`로 등록한다.
- `task_type = document_to_prd`
- `risk_level = low`
- `required_approval = false`
- `forbidden_actions = ["do not overwrite existing docs without approval"]`

Codex Worker:

- 문서 읽기
- 핵심 결정 추출
- 미결정 사항 정리
- PRD 초안 생성
- 저장 위치 제안

Completion criteria:

- 입력 문서의 핵심 배경 반영
- Goals, Non-goals, Requirements, User flows 포함
- Open questions 명시
- 저장 위치 제안
- 생성된 문서 경로 또는 draft evidence 생성

Gateway result:

- PRD 초안 또는 저장된 문서 경로
- open questions
- retention suggestion

## 10. Functional Requirements

### FR1. Gateway Request Intake

Gateway는 자연어 요청과 context refs를 받아 task intent와 desired outcome을 추출해야 한다.

Acceptance criteria:

- 사용자는 자연어 요청을 입력할 수 있다.
- 사용자는 repo file, uploaded file, GitHub PR, Supabase project, external link, user note를 context로 붙일 수 있다.
- Gateway는 작업 유형, 위험도, 승인 필요 여부를 preview한다.

### FR2. Task Packet Builder

Gateway는 요청을 canonical Task Packet으로 변환해야 한다.

Acceptance criteria:

- Task Packet은 required fields를 모두 포함한다.
- 금지 작업은 `forbidden_actions`에 명시한다.
- verification requirements는 task type별 기본값을 포함한다.
- report format은 summary, evidence, blockers, next action 포함 여부를 명시한다.

### FR3. Risk and Approval Classifier

Gateway는 위험 작업을 식별하고 승인 전 mutation을 막아야 한다.

Acceptance criteria:

- external message, file delete/move, production deploy, DB migration, service restart, OAuth/model/gateway config change, paid resource creation, secret creation/storage, permission change를 승인 필요 작업으로 분류한다.
- 승인 필요 작업은 `waiting_for_approval` 상태로 진입한다.
- 승인 전에는 read-only preflight만 허용한다.

### FR4. Codex Worker Adapter

Gateway는 Task Packet을 worker backend에 전달하고 worker events와 final result를 받아야 한다.

Acceptance criteria:

- Adapter interface는 backend-specific details를 숨긴다.
- v0 Manual Adapter는 task packet을 Markdown handoff 형식으로 렌더링한다.
- v0 Manual Adapter는 pasted worker result를 evidence, blockers, next action으로 구조화할 수 있다.

### FR5. Workboard

Gateway는 task status timeline을 표시해야 한다.

Acceptance criteria:

- 상태는 canonical status model만 사용한다.
- blocker는 사용자 action 필요 여부와 함께 표시한다.
- failed와 blocked는 completed처럼 보이면 안 된다.

### FR6. Evidence Ledger

Gateway는 completed task마다 최소 1개 이상의 evidence item을 요구해야 한다.

Acceptance criteria:

- evidence 없는 작업은 `completed`가 될 수 없다.
- evidence에는 type, summary, source, status, created_at이 포함된다.
- secret, token, `.env` contents, private key는 raw excerpt에 저장하지 않는다.

### FR7. Result Reporting

Gateway는 사용자가 바로 판단할 수 있는 결과를 반환해야 한다.

Acceptance criteria:

- report는 conclusion, what changed or checked, evidence, risks, blockers, next action을 포함한다.
- full logs는 기본 표시하지 않고 evidence detail로 접근 가능하게 한다.
- high-risk action은 next action으로 사용자 승인 요청을 명시한다.

### FR8. Retention Router

Gateway는 완료 후 저장 위치를 제안해야 한다.

Acceptance criteria:

- routing suggestion은 memory, skill, docs/wiki, workboard, artifact/log, no-save 중 하나를 선택한다.
- v0는 자동 저장하지 않는다.
- persistent write는 사용자 승인 후 수행한다.

## 11. Contract Requirements

### Task Packet

Task Packet은 `docs/agent-os/task-packet-schema.md`의 schema를 따른다.

Minimum required fields:

- `task_id`
- `created_at`
- `created_by`
- `request_summary`
- `raw_user_request`
- `desired_outcome`
- `task_type`
- `context_refs`
- `risk_level`
- `required_approval`
- `forbidden_actions`
- `execution_plan`
- `verification_requirements`
- `report_format`
- `status`
- `evidence`
- `blockers`

### Worker Event

Worker Event는 Gateway status timeline과 evidence ingestion의 근거다.

Required event types:

- `accepted`
- `plan_created`
- `approval_required`
- `started`
- `progress`
- `evidence_added`
- `blocked`
- `verification_started`
- `verification_passed`
- `verification_failed`
- `completed`
- `failed`

### Evidence

Evidence는 `docs/agent-os/evidence-ledger-schema.md`의 schema를 따른다.

모든 `completed` task는 최소 1개 이상의 evidence item을 포함해야 한다. evidence를 만들 수 없는 작업은 `completed`가 아니라 `blocked`, `failed`, 또는 advisory-only result로 보고해야 한다.

### Approval

Approval Gate는 `docs/agent-os/approval-gate-policy.md`의 policy를 따른다.

모든 high-risk mutation은 실행 전 명시적 사용자 승인을 받아야 한다.

## 12. Data Model

### `agent_tasks`

- `id`
- `user_id`
- `request_summary`
- `raw_user_request`
- `desired_outcome`
- `task_type`
- `risk_level`
- `required_approval`
- `approval_reason`
- `status`
- `result_summary`
- `next_action`
- `created_at`
- `updated_at`

### `agent_task_events`

- `id`
- `task_id`
- `event_type`
- `message`
- `severity`
- `evidence_ref_id`
- `requires_user_action`
- `created_at`

### `agent_context_refs`

- `id`
- `task_id`
- `type`
- `label`
- `value`
- `created_at`

### `agent_evidence`

- `id`
- `task_id`
- `evidence_type`
- `summary`
- `source_system`
- `source_url`
- `source_path`
- `source_command`
- `source_ref`
- `status`
- `raw_excerpt`
- `artifact_path`
- `created_at`

### `agent_retention_decisions`

- `id`
- `task_id`
- `save_decision`
- `reason`
- `proposed_target`
- `requires_user_approval`
- `created_at`

### RLS requirements

- user-owned records must use `user_id = auth.uid()` where applicable.
- browser code must never receive service role keys.
- service role access is limited to server-side Edge Function or worker contexts.
- evidence and raw excerpts must avoid secrets and sensitive user data.

## 13. Implementation Plan

### Phase 0. Product contract

Deliverables:

- `docs/prd/agentic-os-prd.md`
- `docs/agent-os/task-packet-schema.md`
- `docs/agent-os/evidence-ledger-schema.md`
- `docs/agent-os/approval-gate-policy.md`

### Phase 1. Domain model

Add TypeScript models for:

- `TaskPacket`
- `ContextRef`
- `EvidenceItem`
- `WorkerEvent`
- `WorkerResult`
- `RetentionDecision`
- `Blocker`

Add unit tests for required fields and valid status transitions.

### Phase 2. Gateway UI shell

Add Gateway mode to workspace.

Components:

- `GatewayMode.tsx`
- `TaskIntakeForm.tsx`
- `TaskRiskBadge.tsx`
- `ApprovalGatePanel.tsx`
- `TaskStatusTimeline.tsx`
- `EvidenceLedgerPanel.tsx`
- `NextActionPanel.tsx`
- `RetentionSuggestionPanel.tsx`

### Phase 3. Rule-based classifiers

Files:

- `src/lib/agentic/taskPacket.ts`
- `src/lib/agentic/riskClassifier.ts`
- `src/lib/agentic/approvalPolicy.ts`
- `src/lib/agentic/contextRefs.ts`
- `src/lib/agentic/reportFormat.ts`

Initial classification rules:

- request contains `PR`, `pull request`, or `#<number>` -> `pr_verification`
- request contains `Supabase`, `staging`, `migration`, or project ref -> `supabase_staging_check`
- request contains `PRD`, `문서`, `초안`, or uploaded handoff -> `document_to_prd`
- otherwise -> `unknown`

### Phase 4. Worker Adapter

Implement `CodexWorkerAdapter`.

Initial adapter:

- `ManualCodexAdapter`
- renders task packet as Markdown
- accepts worker result pasted back into Gateway
- extracts result, evidence, blockers, and next action

### Phase 5. Evidence ingestion

Ingest evidence from:

- worker returned evidence
- Gateway direct checks such as GitHub PR metadata or CI status
- user-approved manual observations

### Phase 6. Retention Router

After completion, show one routing suggestion:

- Save to Workboard
- Create Skill Draft
- Save to Docs/Wiki
- Save Evidence
- No Save

Do not auto-save in v0.

## 14. Development Tickets

### Ticket 1. Add Agentic OS PRD

Create product contract docs for v0 scope, core concepts, schemas, approval, evidence, retention, and implementation phases.

### Ticket 2. Add Task Packet domain model

Add TypeScript models and tests for required fields and status transitions.

### Ticket 3. Add Gateway UI shell

Add request input, task type preview, risk badge, task packet preview, status timeline placeholder, and evidence panel placeholder.

### Ticket 4. Add risk and approval classifier

Implement rule-based classifier for approval-required actions.

### Ticket 5. Add Supabase tables for tasks and evidence

Add migration for agent tasks, task events, evidence, context refs, and retention decisions with owner-based RLS.

### Ticket 6. Add Manual Codex Worker Adapter

Implement Markdown handoff and pasted result ingestion.

### Ticket 7. Implement PR verification flow

Build task packet from repo and PR number, collect available GitHub metadata, and return readiness recommendation.

### Ticket 8. Implement Supabase staging check flow

Build read-only staging check packet, collect status evidence, and separate intended warnings from action-required warnings.

### Ticket 9. Implement Document-to-PRD flow

Build PRD draft from uploaded or repo document, capture open questions, and suggest docs save path.

### Ticket 10. Add Retention Router suggestions

Suggest memory, skill, docs, workboard, artifact, or no-save after every completed task.

## 15. Success Metrics

- A user can start a PR verification task from the Gateway and receive a structured result with evidence and next action.
- A user can start a Supabase staging check from the Gateway and receive normal/warning/blocked classification with evidence.
- A user can provide a handoff document and receive a PRD draft with open questions and save-location recommendation.
- 100% of completed tasks include at least one evidence item.
- 100% of high-risk mutation tasks enter `waiting_for_approval` before execution.
- After every completed task, the system proposes a retention decision.

## 16. Open Questions

These are intentionally deferred beyond the v0 contract.

1. Which automated worker backend replaces `ManualCodexAdapter` first: Codex CLI, Codex app thread, remote worker, or GitHub worker?
2. Should artifacts live in Supabase Storage, repo artifacts, or a dedicated artifact service?
3. How much raw log detail should the Gateway expose by default versus behind evidence detail views?
4. Which flows should receive direct GitHub/Supabase API evidence collection before full worker automation?
5. When should retention suggestions become one-click writes instead of proposal-only?
