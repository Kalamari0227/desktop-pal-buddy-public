# Electron Release Guide

Prometheus Desktop Pal은 Vite 빌드 결과를 Electron shell에 패키징합니다. 릴리스는 `demo`, `staging`, `production` 런타임 모드를 명확히 정한 뒤 진행합니다.

## Local Package Check

```sh
npm ci
npm run electron:package -- --linux --x64
```

이 명령은 `dist/`를 만든 뒤 `release/linux-unpacked/` 형태로 패키징 설정을 검증합니다. macOS나 Windows 설치 파일은 각 운영체제에서 `npm run electron:dist -- --mac`, `npm run electron:dist -- --win`처럼 실행합니다.

## Required Environment

앱 연결:

```sh
VITE_APP_MODE=production
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_PUBLISHABLE_KEY=...
ELECTRON_EXTERNAL_HOSTS=github.com,supabase.com,electronjs.org,vite.dev
ELECTRON_UPDATE_FEED_URL=https://updates.example.com/prometheus-desktop-pal
ELECTRON_UPDATE_CHANNEL=latest
```

macOS 서명/공증:

```sh
CSC_LINK=/secure/path/developer-id-application.p12
CSC_KEY_PASSWORD=...
APPLE_ID=release@example.com
APPLE_APP_SPECIFIC_PASSWORD=...
APPLE_TEAM_ID=...
```

인증서와 비밀번호는 로컬 `.env`나 저장소에 넣지 않습니다. CI에서는 GitHub Actions secrets 또는 배포 전용 secret store만 사용합니다.

## Security Gates

릴리스 전에 아래 명령을 통과시킵니다.

```sh
npm run lint
npm test
npm run typecheck
npm run build
npm run electron:package -- --linux --x64
npm audit --audit-level=moderate
```

Electron shell은 다음 제한을 기본값으로 둡니다.

- `contextIsolation: true`, `nodeIntegration: false`, `sandbox: true`
- preload IPC enum validation
- 외부 링크는 HTTPS allowlist만 허용
- navigation은 개발 서버 origin 또는 패키지된 `dist/index.html`만 허용
- 권한 요청은 기본 거부
- Content Security Policy에서 script, frame, object, form action을 제한

## macOS Signing And Notarization

`package.json`의 `build.mac` 설정은 hardened runtime과 `electron/entitlements.mac.plist`를 사용합니다. macOS 릴리스 머신에서 다음 순서로 진행합니다.

```sh
npm ci
npm run electron:dist -- --mac
```

공증은 Apple 인증 정보가 주입된 CI 또는 릴리스 머신에서만 수행합니다. 공증 후에는 생성된 `release/` 산출물을 설치해 다음을 확인합니다.

- 앱 실행과 Dock/Workspace 전환
- 외부 URL allowlist 동작
- Supabase staging/production 로그인 세션 연결
- Gatekeeper 경고 없이 실행

## Auto-Update Policy

자동 업데이트는 릴리스 채널을 분리한 뒤 켭니다.

- `demo`: 자동 업데이트 비활성, 로컬 검증용
- `staging`: pre-release feed만 구독
- `production`: 서명/공증된 stable feed만 구독

업데이트 feed는 `ELECTRON_UPDATE_FEED_URL`로 주입합니다. 앱은 HTTPS feed URL만 허용하고, 개발 모드나 URL 미설정 상태에서는 업데이트 확인을 하지 않습니다. 업데이트 적용은 사용자가 작업 중일 때 즉시 재시작하지 않고, 다운로드 후 다음 종료/실행 흐름에서 적용하는 정책을 기본으로 둡니다.

## Release Checklist

- version bump와 changelog 작성
- `npm audit` 결과 검토
- CI `Electron package smoke` 통과
- staging 패키지 설치 검증
- production 인증서로 서명/공증
- 릴리스 산출물 checksum 기록
