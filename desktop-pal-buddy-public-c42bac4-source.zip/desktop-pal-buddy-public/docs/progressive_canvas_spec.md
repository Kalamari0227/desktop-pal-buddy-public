# Progressive Knowledge Canvas Specification

Version: 1.0  
Purpose: Opening Scene → Knowledge Canvas 전환 및 3단계 확장 구조 정의  
Date: 2026-03-12

---

# 1. Overview

Knowledge Canvas는 **기능이 아니라 환경**이다.

사용자의 업무 지식이 항상 연결되어 있음을 시각적으로 표현하며,  
부팅 시퀀스의 Neural Synapse Network가 앱 전체 생명주기 동안 유지된다.

핵심 원칙:

> Canvas is not a feature. Canvas is the environment.

---

# 2. Progressive Expansion Structure

Canvas는 3단계로 확장된다.

```
Level 0 — Boot
│  Neural Synapse Network 3D animation
│  R3F Canvas 생성
│
├──── morph ────►
│
Level 1 — Ambient Background Canvas
│  R3F Canvas 유지, 카메라 flatten
│  네트워크가 배경으로 은은하게 살아있음
│  노드 hover → 작은 tooltip
│  시계 + Ambient Dock이 위에 overlay
│  "내 업무가 항상 연결되어 있다"
│
├──── click/zoom ────►
│
Level 2 — Workspace Canvas
│  노드 클릭 시 카메라 줌인, UI chrome 등장
│  좌측 필터 + 우측 디테일 패널 slide-in
│  노드 드래그, 연결 생성, 클러스터 탐색
│  독에서 다른 워크스페이스 모드와 동일 레벨
│
├──── expand ────►
│
Level 3 — Deep Analysis Canvas (향후)
│  전체화면 + AI 인사이트 레이어
│  클러스터 분석, 시나리오 시뮬레이션
│  타임라인 뷰 전환
```

---

# 3. Technical Architecture

## Single R3F Canvas

R3F Canvas는 앱 전체 생명주기 동안 **단 하나만 존재**한다.  
Boot, Ambient, Workspace 모두 동일한 Canvas 위에서 카메라와 노드 상태만 변경한다.

```
App mount
  ↓
R3F Canvas 생성 (Boot)
  ↓
Boot 완료 → Canvas 유지, 카메라 변경 (Level 1)
  ↓
Canvas 활성화 → 같은 Canvas, 카메라/노드 상태 변경 (Level 2)
  ↓
Canvas 닫기 → 카메라 복귀, 노드 dimming (Level 1)
```

## Tech Stack

- React Three Fiber (@react-three/fiber ^8.18)
- Three.js (^0.170)
- @react-three/drei (^9.122)
- React 18

---

# 4. Transition: Boot → Level 1

## Scene 5 → Ambient (t=8s ~ t=10s)

```
[Camera Flatten] 0.8s
├─ perspective → orthographic 전환
├─ 노드 z축이 0으로 수렴
├─ 깊이감 제거, 2D 평면화
├─ 노드 opacity 100% → 40% (배경화)
└─ 연결선 opacity 감소

[UI Overlay 등장] 0.5s
├─ 시계 fade-in (중앙)
├─ Ambient Dock slide-up (하단)
└─ 네트워크는 배경에서 계속 미세 움직임 유지
```

### Ambient Background 상태

- 노드: opacity 40%, 미세한 breathing animation
- 연결선: opacity 20%, 간헐적 signal pulse
- 카메라: 매우 느린 drift (자동 패닝)
- 인터랙션: 노드 hover 시 opacity 80%로 증가 + tooltip

---

# 5. Transition: Level 1 → Level 2

## 사용자 트리거

- 배경 노드 클릭
- Ambient Dock에서 "Canvas" 모드 선택

## 전환 연출

```
[Network 활성화] 0.5s
├─ 노드 opacity 40% → 100%
├─ 연결선 밝아짐 (opacity 20% → 60%)
├─ 카메라 살짝 줌인
└─ 노드 크기 약간 증가

[Chrome 등장] 0.3s
├─ 좌측 필터 패널 slide-in
├─ 우측 디테일 패널 slide-in
├─ 시계 fade-out
└─ Ambient Dock → 최소화 모드
```

---

# 6. Transition: Level 2 → Level 1

## 사용자 트리거

- Canvas 닫기 버튼
- ESC 키
- Dock에서 다른 모드 선택

## 전환 연출

```
[Chrome 퇴장] 0.3s
├─ 좌측/우측 패널 slide-out
├─ 시계 fade-in
└─ Dock 복원

[Network dimming] 0.5s
├─ 노드 opacity 100% → 40%
├─ 연결선 dimming
├─ 카메라 줌아웃
└─ 느린 drift 재개
```

---

# 7. Level 2 — Workspace Canvas Layout

```
┌─────────────────────────────────────────────────┐
│  Toolbar (검색, 줌, 필터 토글)                    │
├────────┬──────────────────────┬──────────────────┤
│        │                      │                  │
│ Filter │   Knowledge Graph    │  Detail Panel    │
│ Panel  │   (R3F interactive)  │  (선택된 노드)    │
│        │                      │                  │
│ 노드타입 │  드래그, 줌, 패닝     │  AI 설명         │
│ 시간범위 │  클러스터 표시        │  관련 문서        │
│ 고객    │  연결 생성/삭제       │  제안 액션        │
│        │                      │                  │
├────────┴──────────────────────┴──────────────────┤
│  Ambient Dock (최소화)                            │
└─────────────────────────────────────────────────┘
```

---

# 8. Node Visualization Rules

## Level 1 (Ambient Background)

| 속성 | 값 |
|------|-----|
| 노드 크기 | 작음 (0.02-0.05) |
| 노드 색상 | Soft White (#E6F1FF) |
| 노드 opacity | 40% |
| 연결선 opacity | 20% |
| 인터랙션 | hover tooltip만 |
| 애니메이션 | breathing + slow drift |

## Level 2 (Workspace Canvas)

| 속성 | 값 |
|------|-----|
| 노드 크기 | 중간 (타입별 차등) |
| 노드 색상 | 타입별 컬러 |
| 노드 opacity | 100% |
| 연결선 opacity | 60% |
| 인터랙션 | 클릭, 드래그, 연결 생성 |
| 라벨 | 항상 표시 |

## Node Type Colors

| 타입 | 색상 |
|------|------|
| Memo | Soft White (#E6F1FF) |
| Meeting | Electric Blue (#4DA3FF) |
| Customer | Cyan (#00E5FF) |
| Document | Soft Violet (#9A7DFF) |
| Action | POSCO Gold (hsl(43, 65%, 47%)) |
| Risk | Alert Red (hsl(0, 72%, 51%)) |
| AI Insight | Signal Pulse (#00E5FF) |

---

# 9. App Structure Integration

```
현재 구조:
  Boot → Ambient (시계 + 독) → Workspace 모드들

변경 후:
  Boot (R3F) → Ambient + Background Canvas (R3F 유지)
                    ↓ 독에서 선택
              Workspace 모드들 (기존 유지)
              + Knowledge Canvas 모드 (Level 2, 신규)
```

기존 워크스페이스 모드(홈, 작업, 고객, 에이전트 등)는 그대로 유지.
Knowledge Canvas가 워크스페이스 모드 중 하나로 추가됨.  
동시에 Ambient 배경에서도 축소 버전이 항상 표시됨.

---

# 10. Performance Constraints

| 항목 | Level 1 | Level 2 |
|------|---------|---------|
| 노드 수 | ≤ 200 (visible) | ≤ 300 |
| 연결선 수 | ≤ 400 | ≤ 600 |
| FPS 목표 | 30+ | 60 |
| GPU 메모리 | 최소화 (dimmed) | 적극 활용 |

---

# 11. UX Rules

1. Ambient 배경 Canvas는 **절대 사용자 작업을 방해하지 않는다**
2. Level 1에서 노드는 hover 외 클릭 반응 없음 (오클릭 시 Level 2 전환)
3. Level 2 진입/퇴장은 항상 애니메이션 동반
4. Canvas 상태(카메라 위치, 선택 노드)는 Level 전환 시 보존
5. 저사양 디바이스에서는 Level 1 애니메이션 감소 (prefers-reduced-motion 존중)

---

# 12. Future Expansion (Level 3)

Level 3 — Deep Analysis Canvas:

- 전체화면 몰입 모드
- AI 인사이트 레이어 활성화
- 클러스터 자동 분석
- 시나리오 시뮬레이션
- 타임라인 뷰 전환
- Agent 생성 노드 실시간 반영

---

# 13. Design Philosophy

이 구조가 Notion, Obsidian, Cursor, Perplexity와 다른 점:

> 다른 제품: 기능을 실행하면 결과가 보인다.  
> 우리 제품: **환경 자체가 지능이다.**

Canvas는 열고 닫는 기능이 아니라,  
항상 존재하며 사용자의 업무 맥락을 시각적으로 보여주는 **살아있는 배경**이다.

```
Apple — 환경이 곧 인터페이스
Notion — 문서가 곧 데이터베이스
우리 — 배경이 곧 지식 네트워크
```

---

# 14. Related Documents

## Data Schema (→ knowledge_canvas_data_schema.md)

Canvas의 데이터 모델을 정의한다. 핵심 엔티티:

| 엔티티 | 역할 | MVP |
|--------|------|-----|
| Node | 메모, 회의, 고객, 문서, 액션 등 업무 객체 | ✅ |
| Edge | 노드 간 연결 (related, same_customer, cause_effect 등 9종) | ✅ |
| Evidence | Edge/Insight의 근거 (shared_entity, embedding_similarity 등) | ✅ |
| Review Decision | AI 제안에 대한 사용자 승인/거절 기록 | ✅ |
| Graph Snapshot | 화면 상태 저장/복원/공유용 | ✅ |
| Cluster | 노드 그룹 (customer, project, issue 등 6종) | Phase 2 |
| Insight | AI 생성 인사이트 카드 (pattern, risk, opportunity 등) | Phase 2 |
| Embedding Record | 벡터 검색용 메타데이터 | Phase 2 |

### End-to-End Flow

```
사용자 메모 생성 → node 저장 → embedding 생성 → 유사 노드 검색
→ edge suggestion 생성 → evidence 생성 → UI에 suggested edge 표시
→ 사용자 승인 → review decision 저장 → edge confirmed
```

### Validation Rules

- Node: id unique, type valid enum, title required
- Edge: source_id ≠ target_id, confidence 0.0~1.0
- Insight: related_node_ids ≥ 1, summary required

---

## Graph Architecture (→ knowledge_canvas_graph_architecture.md)

Canvas의 렌더링, 레이아웃, 상호작용 구조를 정의한다.

### 5-Layer Rendering

| Layer | 내용 | Level 1 | Level 2 |
|-------|------|---------|---------|
| 1. Background Field | 약한 입자장, depth 느낌 | ✅ 표시 | ✅ 표시 |
| 2. Graph Core | 노드, 엣지, 클러스터 hull | dimmed | ✅ 활성 |
| 3. Semantic Labels | 노드명, 아이콘, 배지 | ❌ 숨김 | ✅ 표시 |
| 4. Interaction Overlay | hover, selection, drag | hover만 | ✅ 전체 |
| 5. UI Panels | 필터, 디테일, 검색 | ❌ 숨김 | ✅ 표시 |

### Hybrid Layout Strategy

- **Macro**: 클러스터 단위 배치, 겹침 최소화
- **Intra-Cluster**: 클러스터 내부 force layout, anchor 기준 배치
- **Semantic Anchors**: 고객/프로젝트/이슈 노드가 화면 중심축 역할

### Visual Encoding Rules

| 속성 | 인코딩 |
|------|--------|
| 노드 크기 | importance_score 반영 |
| 노드 밝기 | recency / activity 반영 |
| 노드 아이콘 | type 반영 |
| 노드 외곽선 | status (needs_review, AI suggested, pinned) |
| 엣지 실선 | confirmed relation |
| 엣지 점선 | AI suggested relation |
| 엣지 두께 | confidence 반영 |
| 엣지 펄스 | active reasoning path |

### Interaction Model

| 동작 | 결과 |
|------|------|
| Single click | node select |
| Double click | focus cluster / open detail |
| Right click | context menu |
| Hover | glow + connected edges highlight + tooltip |
| Drag | node 이동 |

### State Management

- **Zustand** for app/graph UI state
- **React Query** for server sync
- State domains: UI State, Graph State, Data Sync State

### Transition States (6단계, 기존 3단계에서 확장)

```
boot → network_forming → network_expand → flatten → canvas_init → workspace_ready
```

### Error/Risk Countermeasures

| 리스크 | 대응 |
|--------|------|
| 그래프 과밀 | cluster collapse 기본값 |
| 잘못된 AI 연결 | dashed + review badge |
| 레이아웃 흔들림 | stable anchor layout |
| 의미 불명확 | right panel 설명 제공 |
| GPU 부하 | ambient mode low-motion |

---

End of Document
