# Strategy → Task → Evidence Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development to implement this plan task-by-task. Steps use checkbox syntax for tracking.

**Goal:** In explicit demo mode, create a Gateway task tied to one immutable strategy version, find it in Workboard, and inspect its correctly associated result/evidence.

**Architecture:** Extend the existing TaskPacket contract with an optional strategy reference. Preserve accepted packets as demo-only metadata on in-memory Workboard rows, and resolve them before the legacy reconstruction path. Reuse existing policy, evidence gates, screens and routing.

**Tech Stack:** Existing React 18, TypeScript, Zod, Vitest, Playwright, Vite; no new dependencies.

**Spec:** `docs/superpowers/specs/2026-09-18-strategy-loop-design.md` (user approved 2026-09-18).

## Global Constraints

- Work only in this worktree on `codex/brave-new-company-strategy-loop`, based on `90d0bb2` main. Preserve original checkout, uncommitted work, PR #43, and dependency-security worktree.
- No production/staging data mutation, migrations, deployment, external messaging, credentials/permissions changes, paid resources, push, or merge.
- No generated database type edits, dependencies upgrades, new workspace modes, broad rewrites, employee data collection, learning approvals or cross-division sharing.
- Strategy features are explicit-demo-only. Staging/production must not receive demo rows or strategy metadata through a live provider.
- Keep raw user request, policy approval state, forbidden actions, verification requirements, and completed-with-evidence gates intact.
- Existing tasks without strategy remain usable and unlinked. Missing/corrupt required intake must fail closed, never reconstruct a replacement packet as valid.
- Demo state lasts for the current page session and resets on reload. Mark fixtures and this lifetime in Korean UI copy.
- New tasks are pending, not auto-completed. Keep evidence isolated by both Workboard and packet identifiers.
- Use meaningful failing tests before business changes, then focused green tests. Existing TypeScript diagnostics are the failing baseline for type-only fixes; avoid redundant tests of configuration text.
- Do not spawn subagents from implementers/reviewers. Local commits only. Commit only owned files.

## File responsibilities

- Existing `package.json`, seven type-error files: repair actual type checking without widening contracts or disabling strict checks.
- Existing domain `types.ts`, `schemas.ts`, `taskTemplates.ts`, `manualCodexHandoff.ts`, `index.ts`; new `strategy.ts`: strategy contracts, validation and Gateway wrapper.
- New `src/data/demoStrategyData.ts`: one fictional strategy with two immutable versions and linked pending/completed tasks with valid evidence/results.
- New `src/lib/agentic/demoTaskPackets.ts`: demo row metadata and safe original-packet resolution. No network calls or global runtime mode detection in domain logic.
- Existing `demoClient.ts`, new focused tests: explicit opt-in strategy fixtures and in-memory operations needed by existing task/evidence/event/result/approval flows. No generic database emulator.
- Existing `GatewayMode.tsx`, `TasksMode.tsx`; new small `StrategySelect.tsx` and `StrategySummary.tsx`: version selection, Workboard filtering and labels.
- Existing `taskWorkboardRouting.ts` may add optional validated packet handling if needed; keep the legacy helper pure and do not import demo fixtures into it.
- Colocated domain/UI tests and `tests/e2e/strategy-loop.spec.ts`: end-to-end proof and negative cases.

### Task 1: Restore a real TypeScript gate

**Files:** `package.json`, `src/components/ui/calendar.tsx`, `src/components/workspace/TasksMode.tsx`, `TasksMode.test.tsx`, `src/integrations/supabase/client.ts`, `src/lib/agentic/manualCodexResultGuide.test.ts`, `resultPersistence.ts`, `resultPersistence.test.ts`. Add narrowly necessary tests/utilities in these areas only.

**Interfaces:** Existing exported interfaces and runtime behavior remain unchanged. Produces a reliable `npm run typecheck` gate for all later tasks.

- [ ] Run `node node_modules/typescript/bin/tsc --noEmit -p tsconfig.app.json` and record the expected 28 diagnostics. Full evidence exists outside this repository in the parent's `outputs/evidence/main-app-types.log`.
- [ ] Make the script traverse the real projects explicitly:

```json
"typecheck": "tsc --noEmit -p tsconfig.app.json && tsc --noEmit -p tsconfig.node.json && npm run check:electron && npm run check:scripts"
```

- [ ] Fix unused calendar args by omitting them. Use typed `querySelector<HTMLElement>`/actual DOM narrowing for test elements. Narrow nullable packets and optional dates before consuming them.
- [ ] The four query chains in TasksMode return `PromiseLike` without `.finally`; use `Promise.resolve(query)` before native promise chaining so SDK thenables also work. Preserve loading cleanup and cancellation guards. Cover any runtime change with a focused regression test using a true thenable (no `.finally`).
- [ ] Narrow Supabase URL/key locally before `createClient`. Keep `SupabaseClient<Database>` explicit; adapt the demo structural subset at one documented boundary if required, rather than weakening consumers. Preserve current mode behavior in this task; feature isolation comes in Task 3.
- [ ] Replace unsafe RetentionDecision/Blocker-to-Json coercions with explicit JSON-safe serialization (the fields are JSON primitives/objects). Update fixtures through the real payload helpers and fix the invalid `required_approval` input test by creating the appropriate approval-requiring request.
- [ ] Run focused TasksMode/result tests, then `npm run typecheck`, `npm run lint`, and `npm test`. Inspect the diff; commit `fix: restore application type checking`.

### Task 2: Strategy contracts and session-backed demo intake

**Files:** Domain/data/demo provider files in the File responsibilities section, associated tests, `docs/agent-os/task-packet-schema.md`. No workspace UI edits in this task.

**Interfaces produced:**

```ts
interface Strategy { strategy_id: string; title: string }
interface StrategyVersion {
  strategy_version_id: string; strategy_id: string; version: number;
  objective: string; review_question: string;
}
interface StrategyRef { strategy_id: string; strategy_version_id: string }
// Optional strategy_ref on TaskPacket and CreateTaskPacketInput.
// Strict schemas exported with the domain types.
function validateStrategyReference(ref: StrategyRef, versions: readonly StrategyVersion[]): ValidationResult;
function createStrategyGatewayDraft(
  input: GatewayCodexDraftInput,
  ref: StrategyRef | undefined,
  versions: readonly StrategyVersion[],
): GatewayCodexDraft;
// Wrapper uses the existing Gateway policy engine. Invalid reference returns
// packet:null, needs_manual_review, no handoff and a Korean reason.
// Distinct strategy versions must not collide at Gateway deduplication.

interface DemoPacketMetadata {
  demo_intake_required: true;
  demo_intake_packet: TaskPacket;
}
function withDemoTaskPacket<T extends TaskWorkboardRouteInput>(task: T, packet: TaskPacket): T & DemoPacketMetadata;
function resolveDemoTaskDraft(task: TaskWorkboardRouteInput & {
  demo_intake_required?: unknown; demo_intake_packet?: unknown;
}): GatewayCodexDraft;
// Runtime-safe parsing detects metadata beyond the base TS row type.
// Stored packet: validate schema, task/source IDs and strategy membership;
// clone on write/read; render handoff from preserved packet. Required but
// missing/corrupt packet => needs_manual_review, packet:null, no handoff.
// Neither marker nor packet: use existing createTaskWorkboardDraft(task).

// demoStrategyData exports demoStrategies, demoStrategyVersions and a
// factory createDemoStrategyRows() returning tasks/evidence/events/results.
// createDemoSupabaseClient(options?: { includeStrategyFixtures?: boolean })
// defaults includeStrategyFixtures to false; only explicit demo client setup opts in.
```

- [ ] Add failing tests in `strategy.test.ts`, `demoTaskPackets.test.ts`, and `demoClient.test.ts` covering validation, legacy compatibility, immutable version pinning, invalid/mismatched versions, snapshot loss/corruption/ID mismatch, original request/policy preservation, clone isolation, and write→read behavior. Example:

```ts
const draft = createStrategyGatewayDraft({ raw_user_request: '가상 고객 납기 지연 확인해줘' }, refV1, demoStrategyVersions);
const linked = withDemoTaskPacket(workboardRowFor(draft.packet!), draft.packet!);
expect(resolveDemoTaskDraft({ ...linked, title: '수정된 표시 제목' }).packet?.raw_user_request)
  .toBe('가상 고객 납기 지연 확인해줘');
expect(resolveDemoTaskDraft({ ...linked, demo_intake_packet: undefined }).packet).toBeNull();
```

- [ ] Implement strict strategy schemas, the optional packet field, helper validation and Gateway wrapper; export via `index.ts`. Validate nonempty IDs, positive integer version and meaningful text. Compare membership by both IDs; reject malformed references. Do not mutate input refs or let the worker suggestion set strategy/approval policy.
- [ ] Keep strategy identity in manual handoff. Unlinked requests follow the existing Gateway implementation unchanged. Linked requests receive separate stable-for-that-draft task identities; v1 and v2 must not be deduplicated as one.
- [ ] Implement original demo intake preservation using row metadata. Metadata is only added by the explicit demo caller, never by the shared live payload builder. Read should reject dangling/invalid/mismatched metadata instead of guessing. Avoid import cycles: fixture construction uses base helpers, metadata resolver may consume the version catalog separately or through a small catalog module.
- [ ] Add one strategy ‘납기 위험 조기 확인’ with v1 and v2. Use fictional companies. Seed a completed v1 task with passing required delivery evidence plus WorkerResult, and a pending v2 task without evidence. Use existing payload builders and validate the completed fixture with the real completion gate. Retain existing unlinked fixtures.
- [ ] Make a fresh demo client initialize its own session rows. Add an optional `includeStrategyFixtures` flag, default false; seed new strategy rows only when true. This prevents the existing missing-live-config fallback from exposing strategy fixtures. Persist insert/upsert/update/delete for the small supported task-related table set; apply chained filters before update/delete on await. Select/read results and stored packets must not alias callers' mutable objects. Preserve the existing API subset and other demo screens. Do not add a network call.
- [ ] Run focused domain/provider tests red→green, full tests, typecheck and lint. Update schema docs with optional reference, session-only metadata and live-storage limitation. Commit `feat: preserve strategy-linked demo task packets`. Report exact interfaces to Task 3.

### Task 3: Wire strategy exploration into Gateway and Workboard

**Files:** `GatewayMode.tsx`, `GatewayMode.test.tsx`, `TasksMode.tsx`, `TasksMode.test.tsx`, new `StrategySelect.tsx`, `StrategySummary.tsx`, corresponding focused UI tests, `tests/e2e/strategy-loop.spec.ts`. Also `src/integrations/supabase/client.ts` and a focused `client.test.ts` for fixture opt-in. May add a small demo-only boundary module if essential; no new mode or DB schema.

**Consumes:** Task 2 exports above, existing `resolveAppRuntimeMode()`, `gatewayPacketToWorkboardTaskInsert()`, evidence/result gate and display helpers.

**Produces:** A working visible strategy→version→task→evidence loop, plus browser verification in explicit demo and negative non-demo unit tests.

- [ ] Write failing UI tests for version selection, preserved Workboard packet after navigation/title change, filtering, invalid snapshot blocking and staging/production exclusion. Use real domain and demo client logic for persistence integration; mocks only for network/runtime boundaries.
- [ ] In Gateway add an accessible optional strategy/version selector in demo mode. Build with `createStrategyGatewayDraft`; preserve the created-task guard when inputs unchanged and reset it when strategy/version changes. Before insert validate, and attach metadata using `withDemoTaskPacket` only in explicit demo. Live payloads must not carry demo metadata or strategy refs.
- [ ] In Workboard add a small strategy/version filter (all/unlinked/specific version), a strategy summary, and ‘전략 미연결’ on legacy tasks. Resolve packets using `resolveDemoTaskDraft` only in explicit demo at every existing packet-consumption path (including card results, status changes, evidence, approvals and handoff), so actions cannot bypass preserved metadata. Keep non-demo reads on the legacy path.
- [ ] Show a clear Korean ‘검토 필요’ blocked state when required intake is missing/corrupt. Hide/disable execution, completion, evidence/result mutation and handoff for that invalid packet; do not select another packet. Filter evidence rows by both workboard task ID and packet_task_id. Keep result/event/approval associations consistent.
- [ ] Integrate the small components with existing UI primitives, calm spacing, accessible labels. Show ‘가상 데이터 · 새로고침 시 초기화’ in the strategy area. No new top-level routing modes or strategy editing.
- [ ] Browser test sequence using real demo store: open workspace Gateway; select v1; create a task; open Workboard; assert pinned v1 and original request; navigate away/back; select v2 and verify its different task set; inspect seeded v1 result/evidence; inspect new task with no evidence and blocked completion. Register a network observer/route guard asserting no Supabase/ERP requests. Example assertions:

```ts
await expect(page.getByText('가상 데이터 · 새로고침 시 초기화')).toBeVisible();
await expect(page.getByText('전략 미연결').first()).toBeVisible();
expect(realServiceRequests).toEqual([]);
```

- [ ] In client setup opt in to strategy fixtures only when `resolveAppRuntimeMode() === "demo"`. Add non-demo tests for both staging and production (including missing configuration fallback): no strategy selectors, no demo metadata in insert payloads, and no loading of demo strategy rows by the UI boundary. Do not broaden this into rewriting the repository's pre-existing missing-config fallback policy.
- [ ] Run focused UI tests red→green, `npm run typecheck`, `npm run lint`, `npm test`, `VITE_APP_MODE=demo npm run build`, and existing plus new E2E. Browser binary lives at the parent work directory's `playwright-browsers`; use `PLAYWRIGHT_BROWSERS_PATH` and local-server escalation if needed. Record commands and outputs.
- [ ] Self-review layout and flow in a real browser, save screenshots/evidence under this plan's scratch directory for the controller, and commit `feat: explore strategy versions through workboard evidence`.

## Final verification

Review the complete branch against the approved spec, inspect the resulting code and browser evidence, and run any additional check only for a new concern. Preserve the branch and worktree for user review. Export a patch, implementation report, test logs and screenshots to the parent task's outputs. Do not push or merge.
