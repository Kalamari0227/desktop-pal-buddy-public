# Supabase Hardening Rollout

이 문서는 demo-friendly 설정을 staging/production에 올리기 전에 확인할 순서입니다.

## 1. 적용 전 확인

- `tasks`, `alert_dismissals`, `installed_items`, `debate_history`, `canvas_*`, `marketplace_*_reviews`에 기존 데이터가 있으면 먼저 소유자를 정합니다.
- 기존 행의 `owner_id`가 비어 있으면 새 RLS 정책 적용 뒤 그 행은 일반 사용자가 볼 수 없습니다.
- 데모 전용 데이터만 있는 새 프로젝트라면 바로 마이그레이션을 적용해도 됩니다.

예시:

```sql
-- 운영 정책에 맞는 실제 사용자 id로 바꿔서 실행하세요.
update public.tasks set owner_id = '00000000-0000-0000-0000-000000000000' where owner_id is null;
update public.alert_dismissals set owner_id = '00000000-0000-0000-0000-000000000000' where owner_id is null;
update public.installed_items set owner_id = '00000000-0000-0000-0000-000000000000' where owner_id is null;
update public.debate_history set owner_id = '00000000-0000-0000-0000-000000000000' where owner_id is null;
update public.canvas_nodes set owner_id = '00000000-0000-0000-0000-000000000000' where owner_id is null;
update public.canvas_edges set owner_id = '00000000-0000-0000-0000-000000000000' where owner_id is null;
update public.canvas_evidences set owner_id = '00000000-0000-0000-0000-000000000000' where owner_id is null;
update public.canvas_review_decisions set owner_id = '00000000-0000-0000-0000-000000000000' where owner_id is null;
update public.canvas_graph_snapshots set owner_id = '00000000-0000-0000-0000-000000000000' where owner_id is null;
update public.marketplace_reviews set owner_id = '00000000-0000-0000-0000-000000000000' where owner_id is null;
update public.marketplace_workflow_reviews set owner_id = '00000000-0000-0000-0000-000000000000' where owner_id is null;
update public.marketplace_skill_reviews set owner_id = '00000000-0000-0000-0000-000000000000' where owner_id is null;
update public.marketplace_mcp_reviews set owner_id = '00000000-0000-0000-0000-000000000000' where owner_id is null;
```

## 2. 환경 변수 확인

Edge Function에는 아래 값을 설정합니다.

```sh
ALLOWED_ORIGINS=https://your-app.example.com,null
SUPABASE_URL=...
SUPABASE_ANON_KEY=...
SUPABASE_SERVICE_ROLE_KEY=...
CHAT_RATE_LIMIT_PER_MINUTE=30
DATA_QUERY_RATE_LIMIT_PER_MINUTE=10
```

- 웹만 배포하면 `null`은 빼도 됩니다.
- 패키징된 Electron 앱이 `file://`에서 호출하면 `null` origin이 필요합니다.
- `SUPABASE_SERVICE_ROLE_KEY`는 Edge Function 서버 환경에만 둡니다.
- 실서비스 비서 실행은 Hermes/Codex 운영 브리지에서 다루며, 앱/Edge Function에 모델 provider 키를 직접 넣지 않습니다.

## 3. 적용 순서

로컬에서 먼저 검증합니다.

```sh
npm run verify:supabase:postgres
npm run verify:supabase
```

`verify:supabase:postgres`는 일반 Postgres 컨테이너에 모든 SQL migration을 적용하고 핵심 보안 조건을 확인하는 빠른 smoke test입니다. 이 검증은 Supabase 전체 스택을 대체하지는 않지만, SQL 문법 오류, 제거되지 않은 legacy public write 정책, 누락된 `owner_id`, review `owner_id` 공개 노출, `execute_readonly_query` 보안 회귀를 잡습니다.

`verify:supabase`는 기본적으로 Supabase CLI로 로컬 DB를 시작해 migration reset과 DB lint를 확인합니다. 첫 실행은 Docker 이미지 다운로드 때문에 오래 걸릴 수 있습니다. 이미지 다운로드나 registry credential 조회가 멈추면 Docker Desktop, Docker credential helper, 네트워크를 확인한 뒤 다시 실행하세요.

전체 Supabase 스택까지 확인하려면 아래처럼 실행합니다.

```sh
SUPABASE_VERIFY_FULL_STACK=1 npm run verify:supabase
```

staging/production에는 아래 순서로 적용합니다.

```sh
supabase db push
supabase functions deploy chat
supabase functions deploy data-query
```

적용 뒤에는 staging 사용자로 로그인해서 아래를 확인합니다.

- Workspace 상단 연결 배지가 `Staging`/`Live`와 인증된 사용자 이메일을 표시한다.
- `설정 > 실서비스 연결`에서 로그인/로그아웃이 정상 동작한다.
- 다른 사용자의 작업, 알림, 캔버스 데이터가 보이지 않는다.
- Marketplace 항목 목록은 읽히지만, 리뷰 작성/수정/삭제는 로그인 사용자 권한으로 제한된다.
- Data Query가 `tasks` 조회만 허용하고, 거절/성공 결과가 `data_query_audit_logs`에 남는다.
- Chat/Data Query rate limit 요청 기록이 `edge_rate_limit_events`에 남고 제한 초과 시 429로 막힌다.
- 허용하지 않은 Origin에서 Edge Function 호출이 403으로 막힌다.
- 너무 많은 요청은 429로 막힌다.

## 4. 문제 발생 시

- 데이터가 갑자기 안 보이면 먼저 `owner_id is null` 행이 남았는지 확인합니다.
- Edge Function이 401을 반환하면 클라이언트 세션 토큰 전달을 확인합니다.
- 403이면 `ALLOWED_ORIGINS`에 실제 앱 도메인 또는 Electron용 `null`이 들어 있는지 확인합니다.
- SQL 조회가 거절되면 `tasks` 단일 테이블 SELECT인지, join/union/comment/semicolon/function 호출이 없는지 확인합니다.
