# Approval Gate Policy

작성일: 2026-07-03

Status: v0 canonical policy

Related documents:

- `docs/prd/agentic-os-prd.md`
- `docs/agent-os/task-packet-schema.md`
- `docs/agent-os/OPERATING_PRINCIPLES.md`

## 1. Purpose

Approval Gate는 Agentic OS가 위험 작업을 무심코 실행하지 않도록 막는 정책이다.

중요한 점은 Approval Gate가 일을 멈추는 기능이 아니라는 것이다. 위험 작업을 read-only preflight와 승인 후 mutation으로 나누는 기능이다.

Example:

```text
DB migration 요청
  -> 자동 실행하지 않음
  -> migration 파일 읽기
  -> 영향 범위 요약
  -> dry-run 계획 작성
  -> rollback 고려사항 정리
  -> 사용자 승인 요청
  -> 승인 후 staging 실행 가능
```

## 2. Actions That Require Approval

다음 action은 기본적으로 명시적 사용자 승인이 필요하다.

```ts
export type ApprovalActionType =
  | "external_message"
  | "file_delete_or_move"
  | "production_deploy"
  | "database_migration"
  | "service_restart"
  | "oauth_or_gateway_config_change"
  | "paid_resource_creation"
  | "secret_create_or_store"
  | "permission_change";
```

Policy contract:

```ts
export interface ApprovalPolicy {
  action_type: ApprovalActionType;
  default_required: true;
  approval_mode: "explicit_user_confirmation";
  allowed_without_approval?: false;
}
```

## 3. Default Policy Table

| Action | Approval required | Preflight allowed without approval |
|---|---:|---|
| Send external message | Yes | Draft only |
| Delete, move, or bulk reorganize files | Yes | List targets and impact |
| Production deploy | Yes | Build, test, deploy plan |
| Database migration | Yes | Read migration, explain impact, dry-run plan |
| Service restart | Yes | Identify service and restart reason |
| OAuth/model/gateway config change | Yes | Read current config if safe, propose diff |
| Paid resource creation | Yes | Cost/risk estimate |
| Secret/API key creation or storage | Yes | Explain required secret and destination |
| Permission change | Yes | Summarize scope and risk |

## 4. Risk Levels

```ts
export type RiskLevel = "low" | "medium" | "high" | "blocked";
```

Risk guidance:

| Risk | Meaning | Default behavior |
|---|---|---|
| `low` | Read-only or local reversible work | Can run without approval |
| `medium` | Read-only external checks or local changes with limited scope | Can run if no mutation or secret exposure |
| `high` | Mutation, production, billing, auth, secret, permission, external-facing action | Must enter `waiting_for_approval` before mutation |
| `blocked` | Cannot safely proceed with available context or permissions | Ask for user action |

## 5. Gateway Requirements

Gateway must:

- classify approval-required actions during task intake;
- set `required_approval = true` when required;
- populate `approval_reason`;
- add relevant forbidden actions to `forbidden_actions`;
- move the task to `waiting_for_approval` before mutation;
- show what can be done before approval;
- show what will happen after approval;
- record approval or rejection as a task event.

Gateway must not:

- hide approval-required actions inside a broad task summary;
- treat implied user intent as approval for high-risk actions;
- execute mutation because a worker suggested it;
- store secrets without explicit approval and a confirmed destination.

## 6. Worker Requirements

Codex Worker must:

- respect `forbidden_actions`;
- stop and emit `approval_required` when it detects a high-risk mutation not already approved;
- perform only read-only preflight before approval;
- report blockers instead of guessing credentials or secrets;
- return evidence for preflight findings.

Codex Worker must not:

- merge PRs unless explicitly approved;
- deploy production unless explicitly approved;
- run DB migrations unless explicitly approved;
- send external messages unless explicitly approved;
- create or store secrets unless explicitly approved;
- change OAuth, model, gateway, billing, or permission settings unless explicitly approved.

## 7. UI Requirements

Approval UI must include:

- clear "승인 필요" state;
- action type;
- approval reason;
- preflight actions already performed or allowed;
- mutation actions that will run after approval;
- risks;
- confirmation button;
- cancel or block button.

Suggested copy:

```text
승인 필요

이 작업은 DB migration을 포함할 수 있습니다.
자동 실행하지 않습니다.

승인 전 Codex가 할 수 있는 일:
- migration 파일 읽기
- 영향 범위 요약
- dry-run 계획 작성
- 위험 요소 정리

승인 후 가능한 일:
- staging migration 실행
```

## 8. Status Transitions

Approval-required path:

```text
queued
  -> triaging
  -> waiting_for_approval
  -> running
  -> verifying
  -> completed
```

Rejected or missing approval path:

```text
waiting_for_approval
  -> blocked
```

If a worker discovers an approval-required action while running:

```text
running
  -> waiting_for_approval
```

## 9. Default Forbidden Actions by v0 Flow

### PR verification

```json
[
  "do not merge PR",
  "do not push commits",
  "do not deploy"
]
```

### Supabase staging check

```json
[
  "do not run migration",
  "do not change secrets",
  "do not deploy functions",
  "do not modify production systems"
]
```

### Document-to-PRD

```json
[
  "do not overwrite existing docs without approval",
  "do not expose secrets from uploaded files"
]
```

## 10. Approval Records

Approval decisions should be recorded as worker or Gateway events.

## 11. Local Company Runtime Exact-Scope Approval

The local company runtime uses a separate `Approval` contract for `ProductionPlan.priority` changes. It binds one immutable intent revision, proposal digest, epoch, sorted read-set digest, policy version, skill version, strategy version, requester, approver, and a 15-minute expiry. Apply consumes that approval atomically with `consumedByExecutionId`; a changed target, priority, object version, epoch, policy, skill, strategy, digest, revocation, expiry, or second logical execution requires a new approval.

This exact-scope runtime approval is not the legacy Agentic OS approval event. The legacy event still gates existing TaskPacket/Workboard flows, while the runtime approval authorizes only the persisted virtual-ERP intent. Neither renderer booleans nor model output can create either authority. The existing Supabase approval action enum and deployed schema remain unchanged.

Recommended event fields:

- `event_type = "approval_required"` when approval is requested
- `message` explaining why approval is required
- `requires_user_action = true`
- `severity = "warning"`

When user approves:

- record approval event
- include approver user id when available
- include action type
- include approved scope
- include timestamp

When user rejects:

- record rejection event
- move task to `blocked`
- provide safe next action

## 11. Security Notes

- Approval does not bypass secret handling rules.
- Approval should be scoped, not blanket permission.
- Approval for staging does not imply approval for production.
- Approval for reading a config does not imply approval for changing it.
- Approval for drafting an external message does not imply approval to send it.
- If requested action could expose secrets, the system should ask for a safer destination or redact output.

## 12. Completion Rule

A task that required approval can be completed only when:

1. approval was recorded before mutation;
2. mutation stayed within the approved scope;
3. evidence was captured;
4. remaining risks were reported;
5. next action is clear.
