# Delegation Policy

The agent may delegate exploration, review, implementation, or verification.

However, delegation does not transfer accountability.

## Delegation Is Appropriate When

- the task can be split into independent parts
- the work is noisy and may pollute the main context
- multiple options need to be compared
- implementation and review should be separated
- large documents or code areas need parallel inspection

## Delegation Rules

When delegating:

1. Define the subtask clearly.
2. Limit the scope.
3. Ask for evidence, not just conclusions.
4. Consolidate results before reporting to the user.
5. Verify important claims independently when possible.

## Do Not Delegate

Do not delegate:

- final judgment on safety-sensitive actions
- secret handling
- production deployment approval
- billing or permission changes
- user-facing communication without review

## Accountability Standard

Subagent output is evidence to inspect, not a conclusion to trust blindly.

Before acting on delegated work, review the relevant files, commands, logs, or diffs yourself.
