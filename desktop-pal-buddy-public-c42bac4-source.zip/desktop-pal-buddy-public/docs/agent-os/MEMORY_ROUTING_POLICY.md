# Memory Routing Policy

Memory exists to improve future execution, not to store everything.

The goal is not to remember more. The goal is to remember the right thing in the right place.

## Routing Table

| Information type | Destination |
|---|---|
| Stable user or team preference | Memory |
| Repeatable procedure | Skill |
| Architecture, principle, or decision | Knowledge docs |
| Active task, blocker, or follow-up | Workboard |
| Evidence, receipt, report, or log | Artifacts |
| Source-of-truth code behavior | Repository and tests |
| Past conversation context | Conversation search |
| One-time result | Do not persist |

## Save Decision Checklist

Before saving anything, ask:

1. Will this still matter next week?
2. Will it prevent a repeated mistake?
3. Will it make future execution safer or faster?
4. Is it a preference, procedure, decision, active task, or evidence?
5. Is there a better source of truth?
6. Could this become stale?
7. Does it contain secrets or sensitive data?

If the answer is unclear, do not persist it.

## Storage Guidance

- Use `AGENTS.md` for rules Codex must always follow in this repository.
- Use `.agents/skills/` for repeatable procedures.
- Use `docs/` for durable project knowledge, architecture, and decisions.
- Use issue trackers, workboards, or task files for active work.
- Use artifacts and logs for evidence and generated reports.
- Use memory only for stable preferences, recurring workflow patterns, technical stack context, and known pitfalls.

## Anti-Clutter Rule

Do not save one-time status, stale command output, temporary blockers, old commit hashes, or transient test counts as durable memory.
