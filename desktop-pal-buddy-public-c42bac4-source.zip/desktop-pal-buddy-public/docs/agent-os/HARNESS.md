# Prometheus Harness

Created: 2026-07-03

Status: Codex/ECC adaptation of `revfactory/harness`

Source reference:

- https://github.com/revfactory/harness

## 1. Purpose

Prometheus Harness defines a reusable agent team and skill set for this repository.

The upstream `revfactory/harness` project is a Claude Code team-architecture factory. It generates project-specific agents and skills from six patterns: pipeline, fan-out/fan-in, expert pool, producer-reviewer, supervisor, and hierarchical delegation.

Prometheus runs on Codex/ECC conventions, so this harness maps the same idea into:

- `.codex/config.toml`
- `.codex/agents/*.toml`
- `.agents/skills/*/SKILL.md`
- `AGENTS.md`
- `docs/agent-os/*`

## 2. Runtime Mapping

| Upstream Harness concept | Claude path | Prometheus Codex path |
|---|---|---|
| Agent definitions | `.claude/agents/*.md` | `.codex/agents/*.toml` |
| Skills | `.claude/skills/*/SKILL.md` | `.agents/skills/*/SKILL.md` |
| Harness pointer | `CLAUDE.md` | `AGENTS.md` |
| Orchestrator skill | `.claude/skills/{domain}-orchestrator` | `.agents/skills/prometheus-harness-orchestrator` |
| Intermediate workspace | `_workspace/` | `_workspace/prometheus-harness/` |
| Team mode | Agent Teams | Codex custom agents and subagent workflows when explicitly requested |
| Evidence gate | Skill validation phase | `verification-evidence` plus completion policy |

## 3. Architecture Pattern

Prometheus uses a fan-out/fan-in plus producer-reviewer pattern.

Why:

- Gateway contracts, frontend UI, Supabase, Electron, and QA can be inspected independently.
- Cross-boundary bugs require review after each owner slice.
- Safety-sensitive changes need explicit approval gates.
- The main operator must remain accountable for final integration.

Default flow:

```text
User request
  -> Main operator triage
  -> Context scout if scope is unclear
  -> Owner agents work on bounded slices
  -> QA auditor verifies contracts and commands
  -> Main operator integrates, verifies, and reports
```

## 4. Agent Roster

### `prometheus-context-scout`

Read-only evidence scout. Maps files, patterns, tests, docs, and safety boundaries before implementation.

Use when:

- scope is unclear;
- multiple modules may be involved;
- existing patterns or tests need mapping;
- risk boundaries need a first pass.

### `prometheus-gateway-architect`

Agentic OS Gateway and task-contract architect.

Use when:

- Task Packet, Worker Event, Evidence Ledger, Approval Gate, Workboard, Retention Router, or Manual Codex handoff changes are involved;
- PRD, docs, or schema decisions affect Gateway behavior.

### `prometheus-frontend-builder`

React/Vite workspace UI builder.

Use when:

- editing workspace modes, Gateway Command Center, task intake, evidence panels, timelines, hooks, stores, or UI states.

### `prometheus-supabase-guardian`

Supabase data and Edge Function safety guardian.

Use when:

- editing migrations, RLS, Edge Functions, request guards, SQL safety, Supabase clients, staging checks, or advisor handling.

### `prometheus-electron-guardian`

Electron runtime boundary guardian.

Use when:

- editing Electron main/preload, IPC validation, shell URL allowlists, context isolation, sandbox, CSP, or desktop package behavior.

### `prometheus-qa-auditor`

Cross-boundary QA and evidence auditor.

Use when:

- work is near completion;
- producer/consumer contracts need comparison;
- verification strategy is non-obvious;
- PR readiness or regression risk needs review.

## 5. Skill Roster

| Skill | Purpose |
|---|---|
| `prometheus-harness-orchestrator` | Top-level coordination and routing |
| `gateway-task-packet` | Gateway, Task Packet, Manual Codex handoff, approval, evidence, retention |
| `frontend-workspace` | React/Vite workspace UI implementation |
| `supabase-edge-guard` | Supabase and Edge Function safety |
| `electron-safety` | Electron runtime boundary safety |
| `verification-evidence` | Completion verification and evidence quality |
| `after-action-review` | Post-work retention routing |

## 6. Operating Rules

1. Do not delegate accountability.
2. Delegate only bounded, independent slices.
3. Do not use agents for tiny local edits.
4. Do not delegate secret handling, production approval, billing, or permission changes.
5. Run read-only preflight before approval-required mutation.
6. Completed work requires evidence.
7. Preserve user changes and do not revert unrelated work.
8. Keep `_workspace/prometheus-harness/` free of secrets.

## 7. Suggested Agent Routing

| Request | Primary owner | Review owner |
|---|---|---|
| "PR 검증해줘" | `prometheus-context-scout` or `prometheus-qa-auditor` | Main operator |
| "Gateway UI 만들어줘" | `prometheus-frontend-builder` | `prometheus-gateway-architect`, `prometheus-qa-auditor` |
| "Task Packet schema 바꿔줘" | `prometheus-gateway-architect` | `prometheus-qa-auditor` |
| "Supabase staging 점검해줘" | `prometheus-supabase-guardian` | `prometheus-qa-auditor` |
| "Electron shell allowlist 수정해줘" | `prometheus-electron-guardian` | `prometheus-qa-auditor` |
| "문서 기반 PRD 작성해줘" | `prometheus-gateway-architect` | Main operator |

## 8. Validation Checklist

Structural validation:

- `.codex/config.toml` exists and defines global `[agents]` limits.
- Every `[agents.*]` entry uses `config_file` and points to an existing custom agent file.
- Every `.codex/agents/*.toml` file has the official required fields: `name`, `description`, and `developer_instructions`.
- Every `.codex/agents/*.toml` file declares an intentional `sandbox_mode`.
- Every skill has YAML frontmatter with `name` and `description`.
- Every project skill has `agents/openai.yaml` metadata.
- `AGENTS.md` contains only a compact harness pointer.

Operational validation:

- Agent roles do not duplicate `after-action-review`.
- Skills do not override root safety boundaries.
- Approval gates are consistent with `docs/agent-os/approval-gate-policy.md`.
- Evidence rules are consistent with `docs/agent-os/evidence-ledger-schema.md`.
- Verification rules are consistent with `docs/agent-os/COMPLETION_POLICY.md`.

## 9. Change Log

| Date | Change | Target | Reason |
|---|---|---|---|
| 2026-07-03 | Initial Codex/ECC harness configuration | `.codex`, `.agents/skills`, `AGENTS.md`, `docs/agent-os/HARNESS.md` | User requested `revfactory/harness` setup for Prometheus |
