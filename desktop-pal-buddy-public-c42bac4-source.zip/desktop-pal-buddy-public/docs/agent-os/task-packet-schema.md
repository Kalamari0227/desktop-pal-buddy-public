# Task Packet Schema

작성일: 2026-07-03

Status: v0 canonical contract

Related documents:

- `docs/prd/agentic-os-prd.md`
- `docs/agent-os/evidence-ledger-schema.md`
- `docs/agent-os/approval-gate-policy.md`

## 1. Purpose

Task Packet은 Gateway가 Codex Worker 또는 worker adapter에 전달하는 표준 작업 단위다.

이 schema의 목적은 세 가지다.

1. 사용자의 자연어 요청을 실행 가능한 계약으로 변환한다.
2. 위험 작업과 금지 작업을 worker에 명확히 전달한다.
3. 완료 전 필요한 evidence와 보고 형식을 고정한다.

Gateway는 사용자 요청을 worker에 그대로 넘기지 않는다. 항상 가능한 범위에서 Task Packet으로 정규화한 뒤 전달한다.

## 2. Invariants

- `task_id`는 immutable이다.
- `strategy_ref`가 있으면 `strategy_id`와 해당 전략에 소속된 immutable `strategy_version_id`를 함께 고정한다.
- 기존 packet에는 `strategy_ref`가 없어도 되며, Gateway나 Workboard가 이를 추정해 채우지 않는다.
- `raw_user_request`는 원 요청을 보존한다.
- `request_summary`는 한 문장으로 읽히는 실행 요약이어야 한다.
- `desired_outcome`은 사용자가 완료로 받아들일 결과를 설명해야 한다.
- `forbidden_actions`는 비어 있을 수 있지만, mutation 가능성이 있는 작업에서는 명시해야 한다.
- `verification_requirements`는 completed 전에 확인할 증거를 정의한다.
- `completed` 상태의 task는 evidence item을 최소 1개 이상 가져야 한다.
- high-risk mutation은 승인 전 `waiting_for_approval` 상태를 거쳐야 한다.
- worker는 `forbidden_actions`를 넘어서는 행동을 해서는 안 된다.
- `production_priority_change` packet은 runtime 전용 factory가 main이 생성한 UUID/time과 저장된 strategy ref를 주입받아 만든다. 기존 Gateway의 `manual_only` template이나 28-bit/meeting ID 생성기를 실행 어댑터로 사용하지 않는다.
- `production_readiness_review`는 read-only이며 `required_approval=false`, `risk_assessment` 검증을 사용한다. 검사·포장 미확인은 `needs_review`로 남고 ERP mutation이나 가짜 readback을 만들지 않는다.
- `production_priority_change` 완료는 기본 capture/legacy completion 입력만으로 통과하지 않는다. Electron main이 실제 저장소에서 execution/readback을 다시 읽고 epoch·execution·readSet·예상/관측 priority/version을 교차 확인한 `trusted_production_state_contexts`를 함께 투영해야 한다. JSON context나 ERP label 자체는 영속 증거가 아니다.

## 3. TypeScript Contract

```ts
export type TaskType =
  | "pr_verification"
  | "supabase_staging_check"
  | "document_to_prd"
  | "inventory_check"
  | "urgent_material_risk_assessment"
  | "delivery_delay_risk_check"
  | "business_risk_review"
  | "customer_reply_draft"
  | "order_status_check"
  | "material_substitution_review"
  | "production_priority_change"
  | "production_readiness_review"
  | "repo_doc_update"
  | "general_research"
  | "unknown";

export type ContextRefType =
  | "github_repo"
  | "github_pr"
  | "github_commit"
  | "supabase_project"
  | "uploaded_file"
  | "repo_file"
  | "external_link"
  | "user_note"
  | "customer_account"
  | "material_item"
  | "warehouse"
  | "sales_order"
  | "due_date";

export type RiskLevel = "low" | "medium" | "high" | "blocked";

export type TaskStatus =
  | "queued"
  | "triaging"
  | "waiting_for_approval"
  | "running"
  | "blocked"
  | "verifying"
  | "completed"
  | "failed"
  | "archived";

export type VerificationType =
  | "test"
  | "lint"
  | "typecheck"
  | "build"
  | "ci_status"
  | "diff_review"
  | "supabase_status"
  | "manual_review"
  | "document_created"
  | "inventory_status"
  | "order_status"
  | "delivery_status"
  | "risk_assessment"
  | "reply_draft"
  | "substitution_review"
  | "production_state";

export type ReportDetailLevel = "brief" | "standard" | "full";

export type WorkerOutcome =
  | "passed"
  | "passed_with_warnings"
  | "blocked"
  | "failed"
  | "advisory_only";

export type BlockerType =
  | "missing_context"
  | "missing_credentials"
  | "approval_required"
  | "tool_unavailable"
  | "verification_failed"
  | "ambiguous_request"
  | "policy_blocked";

export type RetentionSaveDecision =
  | "memory"
  | "skill"
  | "docs_or_wiki"
  | "workboard"
  | "artifact_or_log"
  | "no_save";

export interface ContextRef {
  type: ContextRefType;
  label: string;
  value: string;
}

export interface ExecutionStep {
  step_id: string;
  summary: string;
  expected_evidence?: string;
}

export interface VerificationRequirement {
  type: VerificationType;
  required: boolean;
  command_or_source?: string;
}

export interface ReportFormat {
  include_summary: boolean;
  include_evidence: boolean;
  include_blockers: boolean;
  include_next_action: boolean;
  max_detail_level: ReportDetailLevel;
}

export interface Blocker {
  blocker_id: string;
  type: BlockerType;
  summary: string;
  requires_user_action: boolean;
  suggested_resolution?: string;
}

export interface WorkerResult {
  outcome: WorkerOutcome;
  summary: string;
  details?: string;
  changed_paths?: string[];
  checked_refs?: ContextRef[];
  risks?: string[];
}

export interface Strategy {
  strategy_id: string;
  title: string;
}

export interface StrategyVersion {
  strategy_version_id: string;
  strategy_id: string;
  version: number;
  objective: string;
  review_question: string;
}

export interface StrategyRef {
  strategy_id: string;
  strategy_version_id: string;
}

export interface RetentionDecision {
  task_id: string;
  save_decision: RetentionSaveDecision;
  reason: string;
  proposed_target?: {
    path?: string;
    table?: string;
    issue_id?: string;
    skill_name?: string;
  };
  requires_user_approval: boolean;
}

export interface TaskPacket {
  task_id: string;
  created_at: string;
  created_by: string;

  request_summary: string;
  raw_user_request: string;
  desired_outcome: string;

  task_type: TaskType;
  context_refs: ContextRef[];
  strategy_ref?: StrategyRef;

  risk_level: RiskLevel;
  required_approval: boolean;
  approval_reason?: string;
  forbidden_actions: string[];

  execution_plan: ExecutionStep[];
  verification_requirements: VerificationRequirement[];
  report_format: ReportFormat;

  status: TaskStatus;
  evidence: EvidenceItem[];
  result?: WorkerResult;
  blockers: Blocker[];
  next_action?: string;

  retention_decision?: RetentionDecision;
}
```

`EvidenceItem` is defined in `docs/agent-os/evidence-ledger-schema.md`.

`strategy_ref`는 선택 필드다. 값이 있으면 두 ID가 비어 있지 않아야 하고, `strategy_version_id`가 같은 `strategy_id`의 버전 catalog에 속해야 한다. 전략이 연결된 Gateway draft는 전략 버전별로 별도의 안정적인 `task_id`를 사용해 서로 다른 버전이 deduplication에서 충돌하지 않게 한다. 전략 선택은 `raw_user_request`, approval policy, `forbidden_actions`, `verification_requirements`를 변경할 수 없다.

## 3.1 Demo Session Intake Metadata

첫 전략 탐색의 데모 Workboard row는 다음 metadata로 최초 검증된 packet snapshot을 현재 페이지 세션에만 보존할 수 있다.

```ts
export interface DemoPacketMetadata {
  demo_intake_required: true;
  demo_intake_packet: TaskPacket;
}
```

이 metadata는 canonical `tasks` 테이블 schema가 아니며 명시적으로 전략 fixture를 켠 demo client에서만 사용한다. 공유 live payload builder와 실제 Supabase client는 이를 추가하거나 저장하지 않는다. 새 demo client가 만들어지거나 페이지가 새로고침되면 fixture 상태로 초기화된다.

읽을 때는 packet schema, Workboard `source`/`source_id`, packet 내부 task ID, 전략과 버전의 소속을 다시 검증한다. `demo_intake_required`가 있는데 packet이 누락·손상됐거나 ID/전략이 불일치하면 `needs_manual_review`로 닫고 worker handoff를 만들지 않는다. 저장된 packet 대신 수정된 Workboard 제목이나 설명에서 새 packet을 추정하지 않는다. 반환 값과 세션 저장 값은 깊은 복사로 분리한다.

현재 단계에는 전략 참조를 위한 DB column, table, migration이 없다. 따라서 staging/production 저장, 장기 보존, 다른 세션 간 공유를 지원하거나 보장하지 않는다. 화면 copy는 fixture가 가상 데이터이고 새로고침 시 현재 세션 변경이 초기화된다는 점을 한국어로 표시해야 한다.

## 4. Worker Event Contract

Codex Worker는 최종 결과만 반환하지 않는다. Gateway가 상태를 보여주고 중간 blocker를 처리하려면 worker event stream이 필요하다.

```ts
export type WorkerEventType =
  | "accepted"
  | "plan_created"
  | "approval_required"
  | "started"
  | "progress"
  | "evidence_added"
  | "blocked"
  | "verification_started"
  | "verification_passed"
  | "verification_failed"
  | "completed"
  | "failed";

export type EventSeverity = "info" | "warning" | "error";

export interface WorkerEvent {
  event_id: string;
  task_id: string;
  created_at: string;
  event_type: WorkerEventType;
  message: string;
  evidence_ref_id?: string;
  severity?: EventSeverity;
  requires_user_action?: boolean;
}
```

## 5. Status Model

```text
queued
  -> triaging
  -> waiting_for_approval
  -> running
  -> verifying
  -> completed
```

Alternative terminal paths:

```text
running -> blocked
running -> failed
verifying -> failed
completed -> archived
blocked -> running
waiting_for_approval -> running
waiting_for_approval -> blocked
```

Rules:

- `queued` means Gateway received the request but has not built a full plan.
- `triaging` means Gateway is classifying task type, context, risk, and approval.
- `waiting_for_approval` means no risky mutation may run.
- `running` means worker execution is active.
- `blocked` means progress requires user input, missing access, or policy decision.
- `verifying` means execution is complete enough to check evidence.
- `completed` means requested outcome was addressed and evidence exists.
- `failed` means the requested outcome was not achieved.
- `archived` means completed or failed work is no longer active.

## 6. Default Task Packet Templates

### PR verification

```json
{
  "task_type": "pr_verification",
  "risk_level": "low",
  "required_approval": false,
  "forbidden_actions": [
    "do not merge PR",
    "do not push commits",
    "do not deploy"
  ],
  "verification_requirements": [
    { "type": "ci_status", "required": true, "command_or_source": "GitHub PR checks" },
    { "type": "diff_review", "required": true, "command_or_source": "GitHub PR diff or local git diff" },
    { "type": "manual_review", "required": true, "command_or_source": "Codex review summary" }
  ],
  "report_format": {
    "include_summary": true,
    "include_evidence": true,
    "include_blockers": true,
    "include_next_action": true,
    "max_detail_level": "standard"
  }
}
```

### Supabase staging check

```json
{
  "task_type": "supabase_staging_check",
  "risk_level": "medium",
  "required_approval": false,
  "forbidden_actions": [
    "do not run migration",
    "do not change secrets",
    "do not deploy functions",
    "do not modify production systems"
  ],
  "verification_requirements": [
    { "type": "supabase_status", "required": true, "command_or_source": "Supabase project health" },
    { "type": "supabase_status", "required": true, "command_or_source": "migration list" },
    { "type": "manual_review", "required": true, "command_or_source": "advisor warning classification" }
  ],
  "report_format": {
    "include_summary": true,
    "include_evidence": true,
    "include_blockers": true,
    "include_next_action": true,
    "max_detail_level": "standard"
  }
}
```

### Document-to-PRD

```json
{
  "task_type": "document_to_prd",
  "risk_level": "low",
  "required_approval": false,
  "forbidden_actions": [
    "do not overwrite existing docs without approval",
    "do not expose secrets from uploaded files"
  ],
  "verification_requirements": [
    { "type": "manual_review", "required": true, "command_or_source": "source document read-through" },
    { "type": "document_created", "required": true, "command_or_source": "generated draft path or draft content" }
  ],
  "report_format": {
    "include_summary": true,
    "include_evidence": true,
    "include_blockers": true,
    "include_next_action": true,
    "max_detail_level": "standard"
  }
}
```

### Business task catalog extension

These task types connect the same Gateway contract to business workspace modes.

| Task type | Use when | Default risk | Required evidence |
|---|---|---:|---|
| `inventory_check` | User asks for available stock or warehouse availability | medium | `inventory_status`, `manual_review` |
| `urgent_material_risk_assessment` | User asks about urgent material risk, emergency stock, or expedite feasibility | medium | `inventory_status`, `delivery_status`, `risk_assessment` |
| `delivery_delay_risk_check` | User asks whether delivery, shipment, or due date is at risk | medium | `order_status`, `delivery_status`, `risk_assessment` |
| `business_risk_review` | User asks for a general business risk review that does not fit a more specific task type | medium | `risk_assessment`, `manual_review` |
| `customer_reply_draft` | User asks for a customer reply, email, or response draft | medium | `reply_draft`, `manual_review` |
| `order_status_check` | User asks for sales order, purchase order, or order progress status | medium | `order_status`, `manual_review` |
| `material_substitution_review` | User asks whether a substitute material can be proposed | medium | `substitution_review`, `inventory_status`, `manual_review` |

Business task templates must preserve these v0 safety rules:

- Inventory and order checks are read-only by default.
- Customer replies are draft-only; sending requires explicit approval.
- Delivery commitments, stock reservations, ERP updates, specification changes, and purchase/sales order creation are forbidden unless a later approved task explicitly scopes them.
- Gateway should return evidence, blockers, risks, and next action rather than silently treating stale or missing data as success.

## 7. Validation Rules

Gateway validation must reject or block a Task Packet when:

- `task_id`, `created_at`, `created_by`, `request_summary`, `raw_user_request`, or `desired_outcome` is missing.
- `task_type` is `unknown` and no manual review is requested.
- `required_approval` is true but `approval_reason` is missing.
- `risk_level` is `high` and status is not `waiting_for_approval`, `blocked`, or a post-approval execution state.
- `status` is `completed` and `evidence.length === 0`.
- `report_format.include_evidence` is false for any task that can produce evidence.

Worker result validation must reject or downgrade completion when:

- worker claims completion without evidence.
- worker reports actions listed in `forbidden_actions`.
- worker includes secrets, tokens, private keys, or `.env` contents in raw evidence.
- required verification failed and no blocker or risk is reported.

## 8. Storage Mapping

`TaskPacket` maps to Supabase tables as follows.

| Task Packet field | Storage |
|---|---|
| `task_id`, request fields, status, risk | `agent_tasks` |
| `context_refs` | `agent_context_refs` |
| `execution_plan` | `agent_tasks.execution_plan` JSON or child table in later versions |
| `verification_requirements` | `agent_tasks.verification_requirements` JSON or child table in later versions |
| `evidence` | `agent_evidence` |
| `blockers` | `agent_tasks.blockers` JSON or child table in later versions |
| `retention_decision` | `agent_retention_decisions` |
| worker events | `agent_task_events` |

For v0, JSON fields are acceptable for execution plan, verification requirements, and blockers if table normalization slows delivery. Evidence and events should be separate rows from the start.

## 9. Manual Codex Handoff Format

`ManualCodexAdapter` should render a task packet as Markdown with this structure.

```md
# Codex Task Packet

## Request
<request_summary>

## Desired Outcome
<desired_outcome>

## Context Refs
- [type] label: value

## Forbidden Actions
- ...

## Execution Plan
1. ...

## Verification Requirements
- [required] type: command/source

## Report Back With
- conclusion
- evidence
- blockers
- next action
```

The pasted result parser should look for the same report fields and preserve any evidence items it can safely structure.
