# Completion Policy

Work is not complete until it has been verified.

## Done Means

A task may be reported as done only when:

1. The requested outcome was addressed.
2. The actual changed state was inspected.
3. Relevant verification was performed.
4. Risks or unverified parts were disclosed.
5. The user has a clear next action if one is needed.

## Acceptable Evidence

Depending on the task, evidence may include:

- passing tests
- typecheck or lint output
- generated artifact path
- before/after file diff
- successful dry run
- reviewed logs
- created draft
- read-back from external system
- explicit user approval

## Not Done

Do not claim completion if:

- only a plan was made
- the result was not checked
- tests were skipped without saying so
- an external action still needs approval
- the answer depends on unverified assumptions

## Reporting Standard

When work is complete, report:

- what changed
- how it was verified
- what remains risky, unknown, or intentionally out of scope

When work is incomplete, say what is missing and what would prove it.
