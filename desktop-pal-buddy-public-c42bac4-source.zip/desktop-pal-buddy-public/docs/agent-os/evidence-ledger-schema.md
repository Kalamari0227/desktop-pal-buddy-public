# Evidence Ledger Schema

작성일: 2026-07-03

Status: v0 canonical contract

Related documents:

- `docs/prd/agentic-os-prd.md`
- `docs/agent-os/task-packet-schema.md`
- `docs/agent-os/COMPLETION_POLICY.md`

## 1. Purpose

Evidence Ledger는 Agentic OS가 "완료했다"고 말할 수 있는 근거를 저장하는 ledger다.

Agentic OS의 신뢰는 자연어 설명이 아니라 evidence에서 나온다. 따라서 모든 completed task는 최소 1개 이상의 evidence item을 포함해야 한다.

## 2. Core Rule

모든 `completed` task는 최소 1개 이상의 evidence item을 포함해야 한다.

Evidence를 만들 수 없는 작업은 `completed`가 아니라 다음 중 하나로 보고한다.

- `blocked`
- `failed`
- `advisory_only` worker result

## 3. TypeScript Contract

```ts
export type EvidenceType =
  | "command_output"
  | "test_result"
  | "ci_status"
  | "github_pr"
  | "github_commit"
  | "file_diff"
  | "supabase_project_status"
  | "supabase_migration_status"
  | "edge_function_status"
  | "advisor_result"
  | "generated_document"
  | "manual_observation"
  | "inventory_snapshot"
  | "order_status"
  | "delivery_schedule"
  | "risk_assessment"
  | "generated_reply"
  | "substitution_option"
  | "production_state";

export type EvidenceSourceSystem =
  | "github"
  | "supabase"
  | "local_shell"
  | "repo"
  | "gateway"
  | "codex_worker"
  | "user"
  | "erp"
  | "crm"
  | "spreadsheet";

export type EvidenceStatus = "passed" | "failed" | "warning" | "info";

export interface EvidenceSource {
  system: EvidenceSourceSystem;
  url?: string;
  path?: string;
  command?: string;
  ref?: string;
}

export interface EvidenceItem {
  evidence_id: string;
  task_id: string;
  created_at: string;
  evidence_type: EvidenceType;
  summary: string;
  source: EvidenceSource;
  status: EvidenceStatus;
  raw_excerpt?: string;
  artifact_path?: string;
}
```

## 4. Evidence Types

| Type | Use when | Example |
|---|---|---|
| `command_output` | local command output proves state | lint command completed |
| `test_result` | test suite or targeted test proves behavior | unit tests passed |
| `ci_status` | GitHub or CI check proves branch/PR health | PR checks success |
| `github_pr` | PR metadata proves review target state | PR open, draft, mergeable |
| `github_commit` | commit hash proves exact code state | reviewed commit SHA |
| `file_diff` | diff proves changed files or doc changes | generated PRD added |
| `supabase_project_status` | project health proves operational state | ACTIVE_HEALTHY |
| `supabase_migration_status` | migration list proves DB state | migrations applied |
| `edge_function_status` | function deployment/JWT state proves runtime state | chat function JWT enabled |
| `advisor_result` | advisor result proves security/performance finding | RLS warning classified |
| `generated_document` | generated artifact proves output | PRD file path |
| `manual_observation` | human/operator observation is the best available evidence | user-approved review note |
| `inventory_snapshot` | available, allocated, or inbound stock proves inventory state | GA steel stock at Ulsan warehouse |
| `order_status` | order system state proves current progress | SO-1234 allocated, not shipped |
| `delivery_schedule` | delivery, shipment, or inbound plan proves timing | inbound ETA before customer due date |
| `risk_assessment` | Gateway or worker risk analysis proves risk classification | urgent material risk marked high |
| `generated_reply` | draft content proves customer-response output | reviewed email draft |
| `substitution_option` | substitute material comparison proves reviewed options | GA alternative meets required spec pending approval |
| `production_state` | runtime readback proves the expected production priority and version | PP-DEMO-1001 priority/version match after persisted readback |

## 5. Evidence Quality Bar

Good evidence is:

- specific
- timestamped
- tied to a task
- tied to a source
- summarized in human-readable language
- safe to store
- enough for the user to understand why the conclusion is justified

Weak evidence should be marked `info` or `warning`, not used alone to prove completion of high-risk work.

`production_state` is created only after the company runtime validates the persisted ERP readback against the same epoch, execution, read-set, expected priority, and expected version. It must use `source.system="erp"`, the packet task ID, and a `company-runtime/<epoch UUID>/execution/<execution UUID>` source ref. Source labels and ref syntax alone are metadata, not proof. Manual capture and legacy completion fail closed unless Electron main supplies `trusted_production_state_contexts` obtained by loading and cross-checking the persisted execution/readback. That context binds the evidence ID, packet task ID, epoch, execution, read-set digest, expected and observed priority/version, and `matches=true`. Pure JSON does not prove persistence; Task 9/10 main code must perform the repository lookup before projecting this context into the existing completion gate. Renderer input, manual evidence, legacy approval booleans, or model prose cannot mint this evidence type.

Bad evidence:

- "확인했습니다."
- "문제 없어 보입니다."
- raw logs with secrets
- old output that does not match the current task
- unlinked claims with no source

Good evidence:

- "GitHub PR #1 checks succeeded at 2026-07-03T04:12:00Z."
- "`npm test` completed successfully for the local working tree."
- "`docs/prd/agentic-os-prd.md` was created and inspected."
- "Supabase project `your-project-ref` reported ACTIVE_HEALTHY."

## 6. Storage Schema

Recommended Supabase table: `agent_evidence`.

Fields:

- `id`
- `task_id`
- `evidence_type`
- `summary`
- `source_system`
- `source_url`
- `source_path`
- `source_command`
- `source_ref`
- `status`
- `raw_excerpt`
- `artifact_path`
- `created_at`

Recommended constraints:

- `task_id` references `agent_tasks.id`
- `evidence_type` uses an enum or checked text value
- `source_system` uses an enum or checked text value
- `status` uses an enum or checked text value
- `summary` is required
- `created_at` defaults to current timestamp

## 7. RLS and Access

Evidence access must follow task ownership.

Rules:

- Users can read evidence for tasks they own.
- Users can write evidence only through Gateway or approved worker paths.
- Service role writes are allowed only in server-side contexts.
- Browser bundles must never contain service role keys.
- Evidence must not expose another user's task, file path, or private source.

## 8. Raw Excerpt Policy

`raw_excerpt` is optional and should be short.

Allowed:

- short command summary
- relevant test result lines
- non-sensitive CI check status
- non-sensitive advisor warning text

Forbidden:

- secrets
- tokens
- OAuth credentials
- API keys
- private keys
- `.env` contents
- full logs that may contain sensitive data
- direct personal contact/payment identifiers unless explicitly needed and approved

If raw output is large or risky, store a safe `summary` and point `artifact_path` to a scrubbed artifact instead.

## 9. Completion Rules

A task can enter `completed` only when:

1. requested outcome was addressed;
2. all required verification requirements passed or were explicitly marked not applicable with a blocker/risk;
3. at least one evidence item exists;
4. evidence does not violate raw excerpt policy;
5. remaining risks are reported.

A task must not enter `completed` when:

- evidence is missing;
- required verification failed;
- worker performed a forbidden action;
- user approval is still pending;
- result depends on unverified external state;
- task produced only a plan when execution was requested.

## 10. Evidence Examples

### PR verification

```json
{
  "evidence_type": "ci_status",
  "summary": "GitHub PR checks are passing.",
  "source": {
    "system": "github",
    "url": "https://github.com/Kalamari0227/desktop-pal-buddy/pull/1"
  },
  "status": "passed"
}
```

### Supabase staging check

```json
{
  "evidence_type": "supabase_project_status",
  "summary": "Staging project is ACTIVE_HEALTHY.",
  "source": {
    "system": "supabase",
    "ref": "your-project-ref"
  },
  "status": "passed"
}
```

### Document-to-PRD

```json
{
  "evidence_type": "generated_document",
  "summary": "Agentic OS PRD was created.",
  "source": {
    "system": "repo",
    "path": "docs/prd/agentic-os-prd.md"
  },
  "status": "passed"
}
```

## 11. Evidence Ingestion Paths

Evidence can enter the ledger through three paths.

### Worker-returned evidence

Codex Worker returns evidence in the final result.

### Gateway direct evidence

Gateway collects evidence directly from integrated APIs such as GitHub or Supabase.

### User-approved manual evidence

The user or operator provides a manual observation that Gateway records as `manual_observation`.

Manual evidence should be used carefully. It is acceptable for document review or business judgment, but it should not replace available machine evidence for tests, CI, migrations, or project health.

## 12. Retention

Evidence is not the same as memory.

Routing:

- Evidence for the task -> Evidence Ledger
- Repeated procedure discovered from evidence -> Skill suggestion
- Architecture or product decision shown by evidence -> Docs/Wiki suggestion
- Follow-up needed because evidence failed -> Workboard suggestion
- One-time noisy output -> Do not persist beyond task artifact

Retention suggestions should follow `docs/agent-os/MEMORY_ROUTING_POLICY.md`.
