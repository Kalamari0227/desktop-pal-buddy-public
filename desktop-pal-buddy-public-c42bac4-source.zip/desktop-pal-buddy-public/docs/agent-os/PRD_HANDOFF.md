# Agentic OS PRD Handoff

작성일: 2026-07-03

## 1. 목적

이 문서는 `desktop-pal-buddy` 프로젝트에서 회사용 Agentic OS PRD를 작성하기 위한 인수인계서다.

핵심 목적은 기존 Lovable 중심 프로토타입을 벗어나, 사용자가 Gateway를 통해 Codex 실행 환경을 업무 비서처럼 사용할 수 있는 운영 구조를 정의하는 것이다.

이 문서는 PRD가 바로 이어받아야 할 배경, 현재 상태, 확정된 방향, 시스템 경계, 미결정 사항을 정리한다.

## 2. 한 줄 방향

사용자는 Gateway에 업무 의도를 전달하고, Gateway는 표준 작업 단위로 Codex 실행 환경에 위임하며, Codex는 검증 가능한 결과와 증거, 다음 액션을 Gateway로 반환한다.

```text
User
  -> Gateway
  -> Codex Worker / Execution Environment
  -> Result + Evidence + Blockers + Next Action
  -> Gateway
  -> User
```

## 3. 중요한 용어 정리

### Agentic OS

사용자의 업무 요청을 단순 채팅 답변이 아니라 실행 가능한 작업 단위로 받아, 상태 추적, 실행, 검증, 보고, 학습까지 이어주는 운영 체계다.

### Gateway

사용자가 Agentic OS에 진입하는 실제 통로다.

Gateway의 역할:

- 사용자 요청 수신
- 요청을 표준 작업 단위로 변환
- 위험도와 승인 필요 여부 판단
- Codex 실행 환경에 작업 전달
- 결과, 증거, blocker, 다음 액션을 사용자에게 반환
- 작업 상태와 운영 기록을 저장소에 라우팅

### Codex Worker / Execution Environment

실제 파일, 코드, 테스트, Git, Supabase, 문서 작업을 처리하는 실행 환경이다.

Codex는 Gateway가 넘긴 작업을 수행하고, 완료 여부를 증거와 함께 보고해야 한다.

### Hermes / Eidolon

이 프로젝트의 직접 구성 요소가 아니다.

Hermes/Eidolon은 개인 에이전트 운영 모델에서 차용한 참고 사례다. 회사용 Agentic OS는 동일한 이름이나 세계관을 복제하지 않고, 아래 형식만 참고한다.

- 헌법/운영 원칙
- 작업 매뉴얼
- 정책 파일
- 스킬
- 장기 지식 문서
- 진행 중인 작업 보드
- 증거/영수증

## 4. 현재 프로젝트 상태

### 코드/PR 상태

- GitHub repo: `Kalamari0227/desktop-pal-buddy`
- PR: `#1`
- Branch: `codex/implement-improvement-plan`
- 현재 PR CI: success
- 최근 핵심 커밋:
  - Agent OS 문서/정책/스킬 추가
  - Supabase staging 연결
  - Supabase hardening migration 적용
  - Lovable runtime dependencies 제거

### Supabase 연결 상태 (공개 반입본)

이 공개 스냅샷에는 기존 운영/staging 프로젝트의 이름, 참조 ID, 지역 및 배포 상태를 포함하지 않습니다.
기본 실행은 로컬 demo 모드이며, `.env.example`의 연결값은 비어 있습니다.
AI/DB 연결과 실제 환경 설정은 반입 후 회사 내부에서 별도로 진행합니다.
`chat`과 `data-query` Edge Function 소스 및 마이그레이션은 유지하지만 이 배포본에서 실행하거나 배포하지 않았습니다.

### 보안/데이터 상태

적용된 주요 방향:

- public read/write RLS 제거
- owner 기반 RLS 적용
- service role key는 browser bundle에 넣지 않음
- Edge Function rate limit table 추가
- 자연어 SQL 실행은 안전한 RPC 경로로 제한하는 기반 마련
- rating trigger function direct execute 권한 제한

현재 남은 Supabase advisor 정보:

- `edge_rate_limit_events`는 RLS enabled but no policy 정보성 알림이 남을 수 있다.
- 이 테이블은 Edge Function 내부 service-side rate limit용이므로 사용자 직접 접근 policy가 없는 것이 의도다.

## 5. Lovable 탈피 상태

Lovable에 종속된 요소는 제거 또는 비활성화됐다.

제거/정리된 것:

- `lovable-tagger`
- Lovable gateway 호출
- Lovable API key 환경 변수
- Lovable 메타데이터
- Lovable 외부 링크 allowlist

중요한 정정:

이 프로젝트는 앱 내부 Edge Function에 OpenAI API key를 넣어 LLM을 직접 호출하는 방향이 아니다.

LLM/비서 실행은 Gateway를 통해 Codex 실행 환경을 사용하는 운영 레이어에서 다룬다.

## 6. 현재 Edge Function 의미

현재 `chat`과 `data-query` Edge Function은 실서비스 LLM gateway를 직접 호출하지 않는다.

현재 역할:

- Supabase Auth 확인
- Origin/CORS 확인
- rate limit 확인
- 요청 payload 검증
- Hermes/Codex 운영 브리지 대기 상태임을 명확히 반환

즉, 이 함수들은 아직 최종 비서 기능이 아니라, 앞으로 Gateway/Codex 브리지와 연결될 자리를 안전하게 막아둔 상태다.

## 7. Agent OS 문서 구조

현재 repo에 Agent OS 초안이 들어 있다.

```text
AGENTS.md
docs/agent-os/OPERATING_PRINCIPLES.md
docs/agent-os/MEMORY_ROUTING_POLICY.md
docs/agent-os/COMPLETION_POLICY.md
docs/agent-os/DELEGATION_POLICY.md
.agents/skills/after-action-review/SKILL.md
```

각 파일의 역할:

- `AGENTS.md`: Codex가 이 repo에서 어떻게 일해야 하는지 정의
- `OPERATING_PRINCIPLES.md`: 회사용 Agentic OS 운영 원칙
- `MEMORY_ROUTING_POLICY.md`: 무엇을 어디에 저장할지 판단하는 기준
- `COMPLETION_POLICY.md`: 완료라고 말하기 전 필요한 검증 기준
- `DELEGATION_POLICY.md`: Codex, subagent, 외부 실행자에게 위임할 때의 책임 기준
- `after-action-review`: 작업 후 회고와 저장 위치 분류 절차

## 8. PRD가 정의해야 할 제품 목표

PRD는 아래 목표를 명확히 해야 한다.

### 목표 1. 사용자의 판단 피로 감소

사용자는 기술적 실행 절차를 몰라도 Gateway에 업무 의도를 말할 수 있어야 한다.

예:

- "이 PR 검증해줘"
- "Supabase staging 상태 확인해줘"
- "이 자료 읽고 PRD 초안 만들어줘"
- "배포 전 위험요소만 정리해줘"

### 목표 2. 요청을 작업 단위로 표준화

모든 요청은 다음 구조로 변환되어야 한다.

```text
task_id
request_summary
desired_outcome
context_refs
risk_level
required_approval
execution_plan
status
evidence
result
blockers
next_action
retention_decision
```

### 목표 3. 완료 전 검증

Agentic OS는 실행했다고 끝내면 안 된다. 완료 보고 전 증거가 있어야 한다.

예:

- 테스트 결과
- GitHub CI 상태
- Supabase advisor 결과
- migration list
- deployed function version
- 파일 diff
- 생성된 문서 경로

### 목표 4. 위험 작업 승인 게이트

아래 작업은 자동 실행하지 않고 사용자 확인이 필요하다.

- 외부 메시지 발송
- 파일 삭제/이동/대량 정리
- production 배포
- DB migration
- service restart
- OAuth/model/gateway 설정 변경
- 유료 리소스 생성
- secret/API key 생성 또는 저장

### 목표 5. 학습 루프

작업 후 결과를 올바른 저장소로 분류해야 한다.

```text
안정적인 선호 -> memory
반복 절차 -> skill
설계/결정 -> docs/wiki
진행 중인 일 -> workboard
실행 증거 -> artifact/log
일회성 결과 -> 저장하지 않음
```

## 9. PRD가 정의해야 할 핵심 기능

### 9.1 Gateway Request Intake

사용자 요청을 받고 작업 의도와 성공 조건을 추출한다.

필요 기능:

- 자연어 요청 입력
- 첨부 파일/링크/context 참조
- 작업 유형 분류
- 위험도 분류
- 승인 필요 여부 판단

### 9.2 Task Packet 생성

Gateway가 Codex 실행 환경에 전달할 표준 작업 패킷을 생성한다.

필수 필드:

- 요청 요약
- 목표 결과
- 사용할 repo/context
- 금지 작업
- 필요한 검증
- 보고 형식
- 승인 조건

### 9.3 Codex Execution Bridge

Codex 실행 환경과 Gateway 사이의 연결 계층이다.

필요 기능:

- 작업 전달
- 상태 업데이트 수신
- 중간 blocker 표시
- 최종 결과 수신
- evidence 저장
- retry/resume 지원

### 9.4 Workboard

진행 중인 작업 상태를 보여준다.

상태 예:

```text
queued
triaging
waiting_for_approval
running
blocked
verifying
completed
failed
archived
```

### 9.5 Evidence Ledger

완료의 근거를 저장한다.

예:

- command/test 결과 요약
- PR/commit/CI 링크
- Supabase project/function/migration 상태
- 생성 파일 경로
- 결정 기록

### 9.6 Retention Router

작업 후 무엇을 저장할지 결정한다.

저장 위치:

- Memory
- Skill
- Docs/Wiki
- Workboard
- Artifact/log
- No-save

## 10. PRD에서 제외해야 할 것

이번 PRD의 범위를 흐리지 않기 위해 아래는 제외한다.

- Hermes/Eidolon 개인 에이전트 이름 복제
- 앱 내부에 OpenAI API key를 넣는 직접 LLM 호출 구조
- Lovable gateway 의존
- 모든 업무 자동화의 완전 자율 실행
- production 자동 배포
- 승인 없는 외부 발송
- 승인 없는 secret 생성/저장

## 11. 핵심 사용자 시나리오

### 시나리오 A. PR 검증 요청

1. 사용자가 Gateway에 "이 PR 검증해줘"라고 요청
2. Gateway가 repo/PR/context를 task packet으로 정리
3. Codex 실행 환경이 테스트, diff, CI, 보안 체크 수행
4. 결과와 증거를 Gateway에 반환
5. Gateway가 사용자가 이해하기 쉬운 요약과 다음 액션 제공

### 시나리오 B. Supabase staging 점검

1. 사용자가 "staging 상태 확인해줘"라고 요청
2. Gateway가 project ref와 확인 기준을 task packet에 포함
3. Codex가 migration, Edge Function, advisor, auth 상태 확인
4. 위험/정상/다음 조치 분류
5. evidence ledger에 결과 저장

### 시나리오 C. 문서 기반 PRD 작성

1. 사용자가 자료를 첨부
2. Gateway가 문서 요약/핵심 결정/미결정 질문을 추출
3. Codex가 PRD 초안 작성
4. 검토 포인트와 open questions 반환
5. 필요한 경우 docs에 저장

## 12. 시스템 경계

### Gateway가 해야 하는 일

- 요청 접수
- context 정리
- 승인 게이트
- 상태 표시
- 결과 전달
- 저장 위치 라우팅

### Codex 실행 환경이 해야 하는 일

- repo 읽기
- 코드/문서 수정
- 테스트/빌드/검증
- Supabase/GitHub 등 도구 작업
- 결과와 증거 반환

### 사용자가 해야 하는 일

- 위험 작업 승인
- secret/OAuth 같은 민감 작업 확인
- 애매한 비즈니스 판단 제공
- 최종 머지/배포 판단

## 13. 미결정 사항

PRD 작성 전 결정이 필요한 질문이다.

1. Gateway는 어떤 인터페이스인가?
   - 웹 앱
   - 데스크톱 앱
   - Telegram/Slack 같은 메신저
   - 기존 Hermes gateway 확장

2. Codex 실행 환경은 어떻게 호출되는가?
   - Codex app thread
   - Codex CLI
   - GitHub/remote worker
   - 별도 queue worker

3. task packet 저장소는 어디인가?
   - Supabase table
   - GitHub issue/PR comment
   - Paperclip/Workboard
   - local artifact

4. Evidence ledger 저장소는 어디인가?
   - Supabase
   - repo artifacts
   - docs/wiki
   - external storage

5. 첫 v0 범위는 어디까지인가?
   - PR 검증만
   - Supabase 운영 점검만
   - 문서/PRD 생성까지
   - 통합 Workboard까지

6. Gateway가 Codex 결과를 사용자에게 보여줄 때 어느 정도까지 요약할 것인가?
   - 핵심 결론만
   - 결론 + 증거
   - 전체 로그 접근 가능

## 14. 추천 v0 범위

가장 안전한 v0는 아래로 제한한다.

```text
Gateway request intake
  -> task packet 생성
  -> Codex 실행 요청
  -> 상태/결과/evidence 반환
  -> after-action routing 제안
```

v0에서 다룰 작업 유형:

- PR 검증
- repo 문서 생성
- Supabase staging 상태 점검
- PRD/인수인계 문서 생성

v0에서 제외할 작업:

- production 배포
- 외부 메시지 발송
- 자동 DB migration
- secret 생성/저장 자동화
- 완전 자율 장기 작업

## 15. PRD 작성자가 바로 사용할 수 있는 요구사항 문장

### Problem

사용자는 개발, 운영, 문서화, 배포 준비 작업을 여러 도구에 흩어져 수행해야 하며, 무엇을 확인해야 완료인지 판단하는 데 많은 피로를 느낀다.

### Goal

Agentic OS는 사용자의 업무 의도를 Gateway에서 받아 Codex 실행 환경에 안전하게 위임하고, 검증 가능한 결과와 다음 액션을 되돌려주는 업무 운영 체계를 제공한다.

### Non-goal

Agentic OS는 무제한 자율 에이전트가 아니다. 위험 작업은 승인 후 실행하며, 완료 보고에는 증거가 필요하다.

### Success Metric

- 사용자가 PR/운영 점검/문서화 작업을 한 요청으로 시작할 수 있다.
- 완료 보고의 100%가 evidence를 포함한다.
- 위험 작업의 100%가 승인 게이트를 통과한다.
- 반복 작업 후 skill/docs/workboard 중 적절한 저장 위치가 제안된다.

## 16. 다음 액션

1. 이 문서를 기준으로 PRD 작성
2. Gateway 인터페이스 결정
3. Codex 실행 방식 결정
4. task packet schema 초안 작성
5. workboard/evidence ledger 저장소 결정
6. v0 user flow 2~3개를 end-to-end로 구현
