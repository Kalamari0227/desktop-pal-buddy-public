
# Knowledge Canvas Data Schema

Version: 1.0  
Purpose: Knowledge Canvas의 노드, 엣지, 클러스터, AI 추론, 동기화용 데이터 스키마 정의

---

# 1. Overview

Knowledge Canvas는 다양한 업무 객체를 통합된 지식 그래프로 저장하고 표시한다.  
이 문서는 다음 스키마를 정의한다.

- node schema
- edge schema
- cluster schema
- insight schema
- source / evidence schema
- embedding / search schema
- sync / versioning schema

본 문서는 구현 언어와 무관한 **논리 스키마(logical schema)** 기준이다.

---

# 2. Entity Model Summary

Core Entities

- Node
- Edge
- Cluster
- Insight
- Evidence
- EmbeddingRecord
- GraphSnapshot
- ReviewDecision

---

# 3. Node Schema

## 3.1 Required Fields

```json
{
  "id": "node_123",
  "type": "memo",
  "title": "동북 도요타 방문 메모",
  "content": "단기 신규 수주보다 납기 안정화 신뢰 회복이 우선",
  "created_at": "2026-03-13T08:00:00Z",
  "updated_at": "2026-03-13T08:10:00Z",
  "status": "active",
  "importance_score": 0.82,
  "confidence_score": 0.91,
  "source_refs": ["src_001"]
}
```

## 3.2 Node Fields Definition

- id: 고유 식별자
- type: 노드 유형
- title: 짧은 표시명
- content: 본문 또는 요약
- created_at: 생성 시각
- updated_at: 수정 시각
- status: active / archived / deleted / needs_review
- importance_score: UI 중요도 가중치
- confidence_score: AI 생성/추론 신뢰도
- source_refs: 원천 데이터 참조 목록

## 3.3 Optional Fields

```json
{
  "summary": "회의 핵심 요약",
  "tags": ["납기", "품질", "동북 도요타"],
  "owner": "user_01",
  "assignee": "user_02",
  "customer_id": "customer_tohoku",
  "project_id": "project_alpha",
  "meeting_id": "meeting_783",
  "doc_uri": "file://...",
  "external_url": "https://...",
  "metadata": {
    "language": "ko",
    "priority": "high",
    "channel": "meeting"
  }
}
```

---

# 4. Node Types

Recommended enum

- memo
- meeting
- customer
- document
- action
- product
- issue
- risk
- ai_insight
- project
- report

---

# 5. Edge Schema

## 5.1 Required Fields

```json
{
  "id": "edge_1001",
  "source_id": "node_123",
  "target_id": "node_555",
  "type": "same_customer",
  "status": "suggested",
  "confidence_score": 0.77,
  "created_at": "2026-03-13T08:12:00Z",
  "created_by": "ai"
}
```

## 5.2 Optional Fields

```json
{
  "weight": 0.63,
  "explanation": "동일 고객명과 납기 관련 공통 키워드",
  "evidence_refs": ["ev_1", "ev_2"],
  "review_state": "pending",
  "reviewed_by": null,
  "reviewed_at": null,
  "metadata": {
    "rule_name": "shared_customer_and_topic",
    "embedding_similarity": 0.81
  }
}
```

## 5.3 Edge Type Enum

- related
- same_customer
- same_project
- follow_up
- cause_effect
- evidence
- conflict
- derived_from
- mentioned_in

## 5.4 Edge Status Enum

- suggested
- confirmed
- rejected
- hidden
- archived

---

# 6. Cluster Schema

## 6.1 Cluster Object

```json
{
  "id": "cluster_customer_tohoku",
  "type": "customer_cluster",
  "label": "동북 도요타",
  "node_ids": ["node_123", "node_555", "node_777"],
  "center_node_id": "node_555",
  "importance_score": 0.88,
  "activity_score": 0.71,
  "time_range": {
    "start": "2026-02-01T00:00:00Z",
    "end": "2026-03-13T08:00:00Z"
  }
}
```

## 6.2 Cluster Type Enum

- customer_cluster
- project_cluster
- issue_cluster
- meeting_cluster
- risk_cluster
- time_window_cluster

---

# 7. Insight Schema

AI가 그래프를 분석해 만든 인사이트 카드용 스키마

```json
{
  "id": "ins_001",
  "type": "pattern",
  "title": "품질 이슈 반복 감지",
  "summary": "최근 3개 회의에서 납기보다 품질 우려가 더 반복적으로 언급됨",
  "related_node_ids": ["node_101", "node_102", "node_103"],
  "related_edge_ids": ["edge_1001"],
  "confidence_score": 0.84,
  "severity": "medium",
  "created_at": "2026-03-13T08:20:00Z",
  "generated_by": "ai"
}
```

Insight type enum

- pattern
- risk
- opportunity
- anomaly
- missing_link
- recommendation

Severity enum

- low
- medium
- high
- critical

---

# 8. Evidence Schema

Edge나 Insight의 근거를 설명하는 스키마

```json
{
  "id": "ev_001",
  "type": "shared_entity",
  "label": "동일 고객명",
  "description": "두 노드 모두 동북 도요타를 포함",
  "source_refs": ["src_001", "src_002"],
  "score": 0.92,
  "metadata": {
    "matched_entity": "동북 도요타"
  }
}
```

Evidence type enum

- shared_entity
- shared_keyword
- embedding_similarity
- same_document
- temporal_proximity
- user_confirmed
- ai_reasoning

---

# 9. Source Reference Schema

원천 데이터 추적용

```json
{
  "id": "src_001",
  "source_type": "meeting_note",
  "source_name": "2026-03-11 고객 방문 회의록",
  "source_uri": "file://notes/2026-03-11.md",
  "external_id": "meeting_20260311",
  "created_at": "2026-03-11T09:00:00Z",
  "metadata": {
    "owner": "sales_team",
    "channel": "desktop_assistant"
  }
}
```

Source type examples

- memo
- meeting_note
- email
- report
- crm_record
- task
- uploaded_file
- ai_generated

---

# 10. Embedding Record Schema

벡터 검색용 메타 스키마

```json
{
  "id": "emb_001",
  "entity_type": "node",
  "entity_id": "node_123",
  "embedding_model": "text-embedding-3-large",
  "vector_dim": 3072,
  "content_hash": "abc123",
  "created_at": "2026-03-13T08:05:00Z",
  "metadata": {
    "language": "ko",
    "chunk_index": 0
  }
}
```

---

# 11. Review Decision Schema

AI 제안 링크 / 인사이트에 대한 사용자 검토 기록

```json
{
  "id": "review_001",
  "target_type": "edge",
  "target_id": "edge_1001",
  "decision": "approved",
  "reason": "실제 동일 고객 맥락 확인",
  "reviewed_by": "user_01",
  "reviewed_at": "2026-03-13T08:25:00Z"
}
```

Decision enum

- approved
- rejected
- edited
- deferred

---

# 12. Graph Snapshot Schema

화면 상태 복원, 공유, 버전관리용

```json
{
  "id": "snapshot_001",
  "name": "도요타 납기 이슈 분석",
  "node_ids": ["node_123", "node_555"],
  "edge_ids": ["edge_1001"],
  "filters": {
    "types": ["memo", "meeting", "risk"],
    "date_from": "2026-02-01",
    "date_to": "2026-03-13"
  },
  "layout": {
    "mode": "workspace",
    "viewport": {
      "x": 120,
      "y": 80,
      "zoom": 1.2
    }
  },
  "created_by": "user_01",
  "created_at": "2026-03-13T08:30:00Z"
}
```

---

# 13. Relational Storage Recommendation

## 13.1 Core Tables

- nodes
- edges
- clusters
- insights
- evidences
- source_refs
- embedding_records
- review_decisions
- graph_snapshots

## 13.2 Suggested Approach

Relational DB  
- metadata / state / review / filters 저장

Vector DB  
- semantic similarity / retrieval

Optional Graph DB  
- 고급 탐색 / 경로 질의가 많을 때 검토

---

# 14. Versioning Rules

- node content 변경 시 updated_at 갱신
- embedding content_hash가 달라지면 재임베딩
- edge suggestion은 immutable log 유지 권장
- review decision은 append-only 권장
- snapshot은 공유 / 복원 기준으로 별도 저장

---

# 15. Validation Rules

## Node Validation

- id unique
- type must be valid enum
- title required
- created_at required

## Edge Validation

- source_id and target_id must exist
- source_id != target_id
- type valid enum
- confidence_score range 0.0 ~ 1.0

## Insight Validation

- related_node_ids at least 1
- summary required
- confidence_score range 0.0 ~ 1.0

---

# 16. Example End-to-End Flow

1. 사용자가 메모 생성
2. node row 저장
3. embedding record 생성
4. 유사 노드 검색
5. edge suggestion 생성
6. evidence 생성
7. UI에서 suggested edge 표시
8. 사용자가 승인
9. review decision 저장
10. edge status = confirmed 반영

---

# 17. MVP Scope Recommendation

## Must Have

- Node
- Edge
- Source Reference
- Evidence
- Review Decision
- Graph Snapshot

## Next Phase

- Cluster
- Insight
- Embedding Record
- advanced metadata

---

# End of Document
