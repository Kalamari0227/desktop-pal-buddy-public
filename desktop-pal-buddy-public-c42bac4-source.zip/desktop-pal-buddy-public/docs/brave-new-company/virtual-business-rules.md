# 가상 업무 규칙과 결정론적 seed

상태: 향후 가상 ERP 도메인의 계약이다. 이 seed는 실제 고객·재고·생산 데이터를 읽거나 변경하지 않는다.

## seed와 정확한 우선순위 규칙

`SO-DEMO-1001`과 `PP-DEMO-1001`은 주문 `20,000kg`, 사용 가능 재고 `25,000kg`, `queued`, `qualityHold=false`, `priority=5`로 시작한다. 승인된 첫 시나리오의 요청만 `5 → 1`이다. 생산계획은 `id`, `orderId`, `version`, `priority(1–9, 1이 가장 높음)`, `status(queued/running/completed)`, `qualityHold`, `materialId`, `requiredKg`를 가진다. 재고·검사·출하·주문은 id/version을 가진 읽기 전용 객체다.

같은 생산 그룹에는 `PP-DEMO-1002(priority=2)`, `PP-DEMO-1003(priority=3)`가 있다. 변경 전 순서는 `1002 → 1003 → 1001`, 변경 후 순서는 `1001 → 1002 → 1003`이며 영향 ID는 `1002`, `1003`이다. 영향 분석은 `priority,id` 순서만 계산한다. 다른 계획 값이나 약속일은 바꾸지 않으며 생산 여력·가동 시간은 미모델링이다.

`completed` 또는 `running`, `qualityHold=true`, 재고 부족, 필수 객체/버전 누락은 변경 제안을 막는다. 동일 priority는 `already_satisfied`이고 apply를 만들지 않는다. 검사 pending·출하 준비 미완료는 우선순위 변경과 구분해 표시하며 출하 가능 또는 납기 단축을 보장하지 않는다. `SO-DEMO-1002`는 검사 pending이다.

첫 업무는 영업 요청 뒤 생산 승인의 priority 변경이다. 두 번째 업무는 production의 완료 안내 준비 검토(`read_only`)다. 기본 readSet은 생산·주문·재고이고 누락 검사/포장은 미확인으로 남는다. 작성자가 공유에 동의한 “완료 안내 전 검사와 포장을 확인” 자산을 적용한 경우에만 두 번째 업무는 검사·출하 객체를 추가 조회하고 전후 readSet 및 asset version으로 그 영향을 보인다.

## 스킬·증거·사업 결과

실행 가능한 `SkillDescriptor`는 `assess-order-priority@1`, `change-production-priority@1`, `review-production-readiness@1`뿐이다. descriptor는 input/output schema version, required capabilities, allowed connector IDs, policy version, review state를 가진다. 모델은 새 스킬이나 connector를 등록하지 못한다.

priority 변경의 필수 검증은 `production_state`다. 예상 priority/version과 재조회 관측값이 일치하고 evidence 저장 및 기존 완료 gate가 통과할 때만 verified/done이다. production readiness review는 `required_approval=false`, `risk_assessment`이며 mutationCount는 0이다. `passed_with_warnings` 또는 근거 `passed`는 조회·평가 성공일 뿐 출하 준비 완료가 아니다.

`BusinessOutcome`은 `unobserved` 또는 `observed_simulated`만 허용하고 입력자·근거·관찰시각을 남긴다. priority 변경 완료를 실제 고객 납품 완료로 바꾸지 않는다. 모르는 규칙 또는 조건 충돌은 `needs_review`로 반환하며 공유 자산은 승인 규칙을 약화하거나 자동 실행 권한을 만들 수 없다.

## 재시작과 reset의 실패 규칙

snapshot은 userData 아래 `company-runtime/snapshot.json`에만 두고 main의 단일 writer가 원자 교체한다. 변경 뒤에는 파일을 새로 열어 readback한다. rename 이후 동기화 오류나 손상 snapshot은 자동 seed/rollback하지 않고 `stopped` 또는 `verification_required`로 차단한다. commit 전 stop은 적용을 막고, commit 후 stop은 재조회·사실 기록만 허용한다. resume은 production의 명시 동작이며 새 승인·검증을 대신하지 않는다.

reset은 현재 ERP·업무·승인·증거·학습·전략 검토를 새 seed epoch으로 교체하지만, 이전 epoch은 작성자/공유 필터가 적용된 읽기 전용 이력으로 보존한다. 저장하지 않은 직원 입력은 snapshot에 남기지 않는다.

## Task25 한계와 남은 검토

검증된 역할은 `sales-demo`, `production-demo`, `management-demo`라는 가상 actor뿐이다. 이 actor와 가상 seed는 회사 인증, 직원별 접근 권한, 실제 ERP connector 권한 또는 실제 사업 결과 관찰을 증명하지 않는다. Task24 패키지 live 영수증은 승인된 가상 변경과 readback, 실제 AI 설명을 보여주지만 외부 ERP 원장 쓰기를 포함하지 않는다.

실제 ERP/운영 DB 변경, 외부 메시지 발송, 배포, 결제·자격증명·권한 변경은 계속 제외한다. 미확정 설계는 connector별 업무 규칙과 권한, 실제 원장 readback 계약, 직원 인증·보존·철회, 사업 결과 관찰 기준이다. PR43 기존 H1 owner-scoped UUID collision, H2 collision-prone lineage hash, H3 retry의 extraction 재호출, M1 partial insertion은 별도 기존 문제로 남긴다.
