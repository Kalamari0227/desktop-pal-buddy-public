# Brave New Company 미래 ERP 구조 계약

상태: 최종 인계 문서. 이 문서는 가상 업무 런타임의 확인된 경계와 향후 ERP 연결의 경계를 고정한다. 실제 ERP 원장이나 외부 메시지 연결이 구현되었다고 주장하지 않는다.

## Task25 implementation 인계 기준

- 역사적 native/package receipt: [Task23 native report](../../.omo/evidence/brave-new-company-future-erp/task-23/native-fallback-7ce405a/report.json)의 `commit`과 [Task24 package receipt](../../.omo/evidence/brave-new-company-future-erp/task-24/package-fallback-7ce405a/package/company-package-receipt.json)의 `gitCommit`은 `7ce405a3404e7173046bf18aadcb0e90f2fd5a56`이다. 이 수신증명은 현재 HEAD의 증명이 아니며, 현재 SHA로 재생성되기 전에는 implementation verifier가 C1/Task23을 `BLOCKED`로 기록한다.
- 역사적 패키지 identity: [Task24 package receipt](../../.omo/evidence/brave-new-company-future-erp/task-24/package-fallback-7ce405a/package/company-package-receipt.json)의 exact `gitCommit`, `codeTreeDigest`, `runtimeBundle`, `schemas`, `bundleSha256`는 7ce 실행의 패키지 identity다.
- 역사적 실제 AI receipt: [Task23 native live](../../.omo/evidence/brave-new-company-future-erp/task-23/native-fallback-7ce405a/live.json)는 `live=true`, `actualAI=true`, `providerCalls=3`, 한 번의 승인 후 virtual apply와 readback match를 기록한다. [Task24 package live](../../.omo/evidence/brave-new-company-future-erp/task-24/package-fallback-7ce405a/task-24-package-live.json)는 `live=true`, `actualAI=true`, `appIsPackaged=true`, `providerCalls=2`, readback match를 기록하며 두 cleanup receipt는 남은 process/temp/port가 0임을 기록한다. 이 사실은 새 SHA의 PASS를 대신하지 않는다.

7ce 실행 마일스톤에서는 결정론적 가상 역할·승인·apply·readback·공유·전략 검토와 exact-SHA native/package live 검증이 확인되었다. 이전 Task23 timeout receipt와 Task25 `c8c869f` blocked package receipt도 당시 실패와 제한의 역사적 기록으로 보존한다. 현재 SHA의 C1/Task23 상태는 새 native/package receipt의 exact-SHA 검증으로만 PASS가 될 수 있다.

## 책임 C1–C6

| 책임 | 앞으로 제공할 결과 | 권위 경계 |
|---|---|---|
| C1 업무 창구와 부문 판단 | 자연어 요청, 근거 있는 영업·생산 판단, 기존 Workboard 투영 | 모델은 후보와 설명만 낸다. 원장 사실은 코드가 확인한다. |
| C2 업무 객체와 스킬 | 버전 있는 주문·재고·생산·검사·출하 객체와 등록 스킬 | 등록된 skill/connector/capability만 dispatch한다. |
| C3 승인과 실행 통제 | Shadow, 정확 범위의 사람 승인, 중복 방지, 정지 | 승인 없는 apply와 모델 생성 승인은 거부한다. |
| C4 지속 결과와 증거 | snapshot 복원, 파일 재조회, 증거와 사업 결과의 구분 | readback·증거·완료 게이트 전에는 done이 아니다. |
| C5 직원 선택 공유와 재사용 | 작성자 선택 공유, 철회, 다른 부문의 조건부 재사용 | private 본문은 작성자만 보고, 철회는 다음 재사용을 막는다. |
| C6 전략 검토 | 허용된 근거 검토와 명시적인 새 전략 버전 | 전략 텍스트는 실행 권한이나 policy를 자동 변경하지 않는다. |

## 주 권위와 모듈 경계

향후 Electron **main**이 actor, clock, epoch, 단일 직렬 queue, snapshot 경로와 모든 변경 권위를 가진다. renderer는 요청/표시 계층이고 호출자가 보낸 actor·role·경로·승인 boolean을 신뢰하지 않는다. Node 파일 접근과 Codex subprocess는 main 어댑터에만 둔다. 순수 도메인 계약은 `src/lib/company-runtime/`에서 browser/Electron이 공유하고, main은 `electron/companyRuntime.mjs`·`companyPersistence.mjs`·`companyIpc.mjs`에서 그 계약을 집행한다. 이 파일 배치는 향후 작업의 seam이며 현재 생성된 런타임이 아니다.

모든 런타임 요청/응답은 strict `schemaVersion=1` 봉투로 `requestId`, `epoch`, `actorSessionRevision`, 성공 또는 오류를 포함한다. 오류는 `unavailable`, `invalid_input`, `unauthorized_role`, `stale_context`, `approval_required`, `stopped`, `persistence_failed`, `verification_required`, `ai_failed`, `conflict`, `adapter_unproven`이다. `needs_review`와 `already_satisfied`는 오류가 아닌 업무 판단 상태다.

## 역할과 변경 권한

고정 가상 인물은 `sales-demo/sales`, `production-demo/production`, `management-demo/management`이다. 영업은 제안·개인 경험, 생산은 승인·실행·재개, 경영은 전략 검토를 담당한다. 정지는 모든 역할이 요청할 수 있다. 역할 전환은 `actorSessionRevision`을 올리고 진행 중 AI 응답을 폐기하지만 유효한 기존 승인을 자동 취소하지는 않는다.

실제 쓰기는 `ProductionPlan.priority` 한 필드로 제한한다. `Customer`, `SalesOpportunity`, `Quote`, `SalesOrder`는 서로 다른 객체이며, 수량은 정수 `quantityKg`로 저장하고 화면에서만 톤으로 바꾼다. `ExecutionMode`는 `read_only`/`shadow`/`apply`이고 승인 상태와 별개다. Shadow는 전후 차이이며 납기 예측이나 원장 변경이 아니다.

`ActionIntent`는 intent/revision, epoch, target, priority, 정렬된 readSet, strategy/skill/policy ref, evidence ref, requester를 고정하고 main의 canonical SHA-256으로 digest를 만든다. `Approval`은 그 exact intent/digest/readSet/epoch/version을 15분 동안만 묶고, apply에서 `consumedByExecutionId`와 함께 소비된다. `Execution`은 epoch+intentId+proposalDigest idempotency key를 사용하며 `prepared`, `applied_pending_readback`, `verified`, `failed_before_apply`, `verification_required` 상태를 가진다.

## 초기화·공유·철회

명시 reset은 production 또는 management의 확인이 있어야 하며 새 UUID epoch의 seed snapshot을 원자 저장하고 `stopped=true`로 시작한다. 이전 epoch의 기록은 삭제하지 않고 읽기 전용으로 보관하지만 새 검색, AI 입력, 학습 재사용에는 쓰지 않는다. 늦은 AI/IPC callback, 승인, retry는 오래된 epoch으로 거절한다.

startup recovery가 commit된 실행의 readback을 확인하지 못해 `stopped=true`를 저장한 경우, 모든 actor의 `execute`와 `reconcile`은 상태를 바꾸지 않고 `verification_required`(`committed=true`)로 닫힌다. production actor가 명시적으로 resume한 뒤에만 pending readback을 재조정할 수 있고, 새 변경에는 별도의 새 승인이 필요하다.

`LearningAsset`은 작성자, source/evidence/correction, applicability, requiredChecks, allowedAudiences, provenance, versioned consent를 가진다. 작성자만 private 또는 선택 부문 공유를 publish/withdraw할 수 있고, management 포함은 전략 검토 포함 여부로 별도 표시한다. 철회는 향후 검색·추천·AI·전략 검토와 아직 실행 전인 의존 제안을 막는다. 과거 실행·증거와 ERP 값은 보존한다. 공유 동의는 회사 정책 승인이나 실행 승인이 아니다.

## 비목표

이번 계약은 실제 ERP/운영 DB 변경, 외부 메시지, 배포, 결제·자격증명·권한 변경, 직원 기록의 자동 수집·공유, 전략 자동 변경, Marketplace 설치, 그래프 DB, 외부 저장소 전체 통합, 오케스트라 영상 제작을 구현하지 않는다. 한 컴퓨터의 역할 전환은 회사 인증·접근 통제가 아니다.

구체적 seed와 업무 차단 규칙은 [virtual-business-rules.md](virtual-business-rules.md), 출처 상태는 [source-map.md](source-map.md), 검증/실패 표현은 [verification.md](verification.md)에 있다.

## C1–C6 최종 상태

| 기준 | 상태 | 확인된 경계 | 직접 근거 |
|---|---|---|---|
| C1 업무 창구와 부문 판단 | BLOCKED | 7ce receipt는 actual AI, 승인 뒤 virtual apply, readback, 설명, 재사용을 보이지만 현재 SHA에는 exact-SHA native/package receipt가 없다. | [Task23 native report (7ce 역사)](../../.omo/evidence/brave-new-company-future-erp/task-23/native-fallback-7ce405a/report.json), [Task23 live (7ce 역사)](../../.omo/evidence/brave-new-company-future-erp/task-23/native-fallback-7ce405a/live.json), [Task24 package live (7ce 역사)](../../.omo/evidence/brave-new-company-future-erp/task-24/package-fallback-7ce405a/task-24-package-live.json) |
| C2 업무 객체와 스킬 | PASS | strict schema, skill descriptor, 객체·단위·버전 계약이 실제 모듈과 테스트로 확인되었다. | [Task3 review](../../.omo/evidence/brave-new-company-future-erp/task-3-review-r2.md), [Task6](../../.omo/evidence/brave-new-company-future-erp/task-6-happy.json), [Task18](../../.omo/evidence/brave-new-company-future-erp/task-18-final-library.json) |
| C3 승인과 실행 통제 | PASS | shadow→정확 scope approval→단일 apply→stop/stale/guard 경계가 확인되었다. | [Task7](../../.omo/evidence/brave-new-company-future-erp/task-7-happy.json), [Task22](../../.omo/evidence/brave-new-company-future-erp/task-22-happy.json) |
| C4 지속 결과와 증거 | PASS | main persistence, file readback, verified 상태, unobserved business outcome과 package readback이 확인되었다. | [Task10](../../.omo/evidence/brave-new-company-future-erp/task-10-verification.md), [Task21](../../.omo/evidence/brave-new-company-future-erp/task-21/verification.md), [Task24 final](../../.omo/evidence/brave-new-company-future-erp/task-24/task-24-final-verification.json) |
| C5 선택 공유와 재사용 | PASS | author consent, audience, withdrawal, exact asset version과 read-only readSet 확장이 확인되었다. | [Task17](../../.omo/evidence/brave-new-company-future-erp/task-17-happy.json), [Task19](../../.omo/evidence/brave-new-company-future-erp/task-19/evidence-summary.md) |
| C6 전략 검토 | PASS | management-only review가 v1을 자동 변경하지 않고 명시 선택된 v2와 lineage를 남긴다. | [Task20](../../.omo/evidence/brave-new-company-future-erp/task-20-fix1/verification.md), [Task21](../../.omo/evidence/brave-new-company-future-erp/task-21/verification.md) |

남은 설계 검토는 실제 ERP connector의 업무 규칙·권한·원장 readback, 직원 인증/부문별 접근 통제, 사업 결과 관찰 기준, 그리고 F1–F4 독립 검토다. 가상 역할(`sales-demo`, `production-demo`, `management-demo`)은 테스트 actor이며 회사 인증이나 실제 직원 권한을 증명하지 않는다. PR43의 기존 H1 owner-scoped UUID collision, H2 28-bit lineage hash, H3 extraction 재호출 retry, M1 partial insertion 문제는 이 제품의 새 경계가 해결했다고 간주하지 않는다 ([원본 검토](../../.omo/evidence/pr43-integration-code-review.md)).
