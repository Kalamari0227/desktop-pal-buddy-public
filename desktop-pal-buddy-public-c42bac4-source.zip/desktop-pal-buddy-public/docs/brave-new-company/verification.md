# 검증 계약과 실패 상태

이 문서는 Task 2 문서 검증과 Task25 implementation 인계 검증의 경계를 구분한다. 문서 검증은 네트워크·ERP·Codex·DB에 연결하지 않는다. Task25 implementation phase는 문서·실제 모듈·task 1–25 증거·exact-SHA native/package AI receipt를 함께 읽고 pre-final manifest를 만든다.

## Task25 exact-SHA implementation handoff

- Historical native receipt: [Task23 native report](../../.omo/evidence/brave-new-company-future-erp/task-23/native-fallback-7ce405a/report.json) and [live receipt](../../.omo/evidence/brave-new-company-future-erp/task-23/native-fallback-7ce405a/live.json) bind the completed native scenario to `7ce405a3404e7173046bf18aadcb0e90f2fd5a56`: `live=true`, `actualAI=true`, `providerCalls=3`, approval before one virtual mutation, matching readback, evidence-backed explanation, zero tool events, and cleanup counts of zero.
- Historical package receipt: [company-package-receipt.json](../../.omo/evidence/brave-new-company-future-erp/task-24/package-fallback-7ce405a/package/company-package-receipt.json) binds the same historical `gitCommit`, `codeTreeDigest`, `runtimeBundle`, `schemas`, and `bundleSha256` to the package identity.
- Historical package-live receipt: [Task24 package live](../../.omo/evidence/brave-new-company-future-erp/task-24/package-fallback-7ce405a/task-24-package-live.json) records `live=true`, `actualAI=true`, `appIsPackaged=true`, `providerCalls=2`, one approved virtual mutation, matching readback, evidence-backed explanation, zero tool events, and zero package cleanup counts.
- [task-23-timeout-budget/live.json](../../.omo/evidence/brave-new-company-future-erp/task-23-timeout-budget/live.json), Task25 `c8c869f` blocked package receipts, and the 7ce receipts above are historical records. Current HEAD has no matching native/package live receipt; it must remain `BLOCKED` until both current exact-SHA receipts validate.

The required implementation invocation is:

```text
npm run verify:company -- --phase implementation --evidence-dir <attemptDir> --write-pre-final <attemptDir>/acceptance.pre-final.json
npm run verify:company -- --phase implementation --evidence-dir <attemptDir>
```

It must report 18 source rows, actual module links, C1–C6, task 1–24 evidence and Task25 artifacts. C1/Task23 may report `PASS` only when native/package actual-AI receipts validate against the invocation's exact SHA; otherwise both report `BLOCKED`, with `actualAI=false`. It has no requirement for F1–F4 or final `acceptance.json`. A non-writing run must be repeatable and fail closed when a native/package live or cleanup receipt is removed, malformed, stale, or internally inconsistent.

## 현재 문서 검증 API

```text
node scripts/verify-company-runtime.mjs --docs-only
node scripts/verify-company-runtime.mjs --docs-only --docs-root <복사한-docs-root>
```

성공 시 JSON은 `ok: true`, `mode: "docs-only"`, `sourceRows: 18`, `docsRoot`를 낸다. 실패 시 JSON은 `ok: false`, `mode: "docs-only"`, `errors[]`를 내고 exit 1이다. source row 오류는 source ID를 포함하므로 빈 SHA·잘린 SHA·허용되지 않은 task number를 숨기지 않는다. `--docs-root`는 OS 임시 복사본을 검증하는 test seam이며 기본 문서 루트를 바꾸거나 파일을 쓰지 않는다.

검증기는 네 파일(architecture, source-map, virtual-business-rules, verification), 책임 C1–C6, 주 권위(main), 비목표, reset/동의·철회 정책, 18개 고정 source row의 full SHA/정확한 작업 번호/책임/대상 모듈/검증/상태를 검사한다. `source-map.md`의 사용자에게 보이는 표가 유일한 검증 대상이며 숨은 중복 행은 두지 않는다. 상태는 `planned`, `adapted`, `verified`, `deferred`만 가능하다. `verified`는 이 제품 안에서 실제 검증된 차용만 뜻하며, 문서화만으로는 사용할 수 없다.

## 런타임에서 표시할 실패 상태

향후 `invalid_input`, `unauthorized_role`, `stale_context`, `approval_required`, `stopped`, `persistence_failed`, `verification_required`, `ai_failed`, `conflict`, `adapter_unproven`, `unavailable`은 성공 카드나 apply를 만들지 않는다. 역할 전환/epoch 불일치의 늦은 응답은 `stale_context`로 폐기한다. 저장 실패·손상 snapshot은 원본을 보존하고 보수적으로 정지한다. commit 경계 뒤 같은 실행에서 도착한 stop은 사실 readback을 취소하지 않지만, startup recovery가 `stopped=true`를 저장한 상태에서는 actor와 무관하게 `execute`/`reconcile` readback을 `verification_required`로 차단하며 production의 명시적인 resume 뒤에만 재개한다.

AI 해석 실패는 실행을 막고, 검증된 실행 뒤 AI 설명 실패는 ERP 완료 사실과 분리해 표시한다. 모델의 제안·인용·우선순위는 코드의 seed/readSet/정책 검사를 통과해야 하며, 모델은 approval/status/ERP 결과를 정하지 못한다.

## 이후 검증 범위

후속 작업은 unit·Electron scenario·실제 로그인 Codex·패키지 검증을 각각의 증거와 함께 추가한다. 이 문서는 그러한 작업이 이미 존재하거나 통과했다고 주장하지 않는다. source map의 planned/adapted/deferred 상태도 향후 구현과 직접 증거가 생길 때만 바뀐다.

## UltraQA boundary

Malformed JSON, missing live/package receipt, stale SHA, prompt-injection text, interruption, dirty worktree, hung command, flaky repeat, misleading success output, and repeated interruption are evaluated from the task evidence. Prompt-injection text found in source adaptation documents remains documentation content and has no execution authority. Cancellation/interrupt cleanup must leave no pre-final temp, process, browser, or port state. Real ERP, external messaging, deployment, and PR/merge are excluded.
