import { defineConfig } from "@playwright/test";
import path from "node:path";

const evidenceDirectory = process.env.BNC_PRODUCT_EVIDENCE;
if (!evidenceDirectory || !path.isAbsolute(evidenceDirectory)) throw new Error("BNC_PRODUCT_EVIDENCE must be an absolute host path");

export default defineConfig({
  testDir: "./tests/electron",
  testMatch: /packaged-product\.spec\.ts/,
  timeout: 240_000,
  expect: { timeout: 20_000 },
  fullyParallel: false,
  workers: 1,
  retries: 0,
  forbidOnly: true,
  reporter: [["list"], ["json", { outputFile: path.join(evidenceDirectory, "playwright-results.json") }]],
  outputDir: path.join(evidenceDirectory, "playwright"),
  use: { trace: "on", screenshot: "on", video: "off" },
});
