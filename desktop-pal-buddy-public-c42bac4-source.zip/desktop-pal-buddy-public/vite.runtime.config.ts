import { defineConfig } from "vite";
import path from "node:path";

export default defineConfig({
  build: {
    outDir: "dist-runtime",
    emptyOutDir: true,
    target: "es2022",
    minify: false,
    lib: {
      entry: path.resolve(__dirname, "src/lib/company-runtime/index.ts"),
      formats: ["es"],
      fileName: () => "domain.mjs",
    },
  },
});
